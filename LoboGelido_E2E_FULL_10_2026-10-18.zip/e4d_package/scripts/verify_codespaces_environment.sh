#!/usr/bin/env bash
set -u
fail=0
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/.android/sdk}}"

echo "=== Lobo Gélido: verificación del entorno ==="

if command -v java >/dev/null 2>&1; then
  JAVA_MAJOR="$(java -version 2>&1 | sed -n 's/.*version "\([0-9][0-9]*\).*/\1/p' | head -1)"
  echo "Java: ${JAVA_MAJOR:-unknown}"
  [[ "${JAVA_MAJOR:-0}" == "17" ]] || { echo "[FALTA] JDK 17"; fail=1; }
else
  echo "[FALTA] JDK 17"; fail=1
fi

echo "Android SDK: $SDK"
[[ -d "$SDK/platforms/android-36" ]] || { echo "[FALTA] SDK Platform 36"; fail=1; }
[[ -d "$SDK/build-tools/36.0.0" ]] || { echo "[FALTA] Build Tools 36.0.0"; fail=1; }
[[ -d "$SDK/ndk/27.3.13750724" ]] || { echo "[FALTA] NDK 27.3.13750724"; fail=1; }
[[ -x "$SDK/cmake/3.22.1/bin/cmake" ]] || { echo "[FALTA] CMake 3.22.1"; fail=1; }

required=(
 "$ROOT/android/app/build.gradle.kts"
 "$ROOT/android/app/src/main/cpp/CMakeLists.txt"
 "$ROOT/android/build-apk.sh"
 "$ROOT/android/gradlew"
 "$ROOT/scripts/setup_android_env.sh"
)
for f in "${required[@]}"; do
  if [[ -f "$f" ]]; then echo "[OK] ${f#$ROOT/}"; else echo "[FALTA] ${f#$ROOT/}"; fail=1; fi
done

if grep -q 'kotlin {' "$ROOT/android/app/build.gradle.kts" &&
   grep -q 'jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)' "$ROOT/android/app/build.gradle.kts" &&
   ! grep -q '^    compilerOptions {' "$ROOT/android/app/build.gradle.kts"; then
  echo "[OK] Kotlin compilerOptions scope"
else
  echo "[FALTA] Kotlin compilerOptions mal ubicado"; fail=1
fi

if [[ "$fail" -eq 0 ]]; then
  echo "RESULTADO: entorno listo."
  exit 0
fi
echo "RESULTADO: falta al menos un componente. Ejecuta ./android/build-apk.sh para preparar el toolchain."
exit 1
