#!/usr/bin/env bash
set -euo pipefail

SDK_VERSION="36"
BUILD_TOOLS_VERSION="36.0.0"
NDK_VERSION="27.3.13750724"
CMAKE_VERSION="3.22.1"
CMDLINE_TOOLS_VERSION="15859902"

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/.android/sdk}}"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_NDK_HOME="$SDK_ROOT/ndk/$NDK_VERSION"
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$SDK_ROOT/cmake/$CMAKE_VERSION/bin:$PATH"

mkdir -p "$SDK_ROOT"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: JDK 17 no está instalado." >&2
  exit 2
fi
JAVA_MAJOR="$(java -version 2>&1 | sed -n 's/.*version "\([0-9][0-9]*\).*/\1/p' | head -1)"
if [[ "$JAVA_MAJOR" != "17" ]]; then
  echo "ERROR: se requiere JDK 17; detectado ${JAVA_MAJOR:-unknown}." >&2
  exit 2
fi

if [[ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  zip="/tmp/lobo-gelido-commandlinetools.zip"
  url="https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_TOOLS_VERSION}_latest.zip"
  echo "Instalando Android Command-line Tools ${CMDLINE_TOOLS_VERSION}..."
  curl -fsSL --retry 3 --retry-delay 2 "$url" -o "$zip"
  unzip -q "$zip" -d "$tmp"
  rm -rf "$SDK_ROOT/cmdline-tools/latest"
  mkdir -p "$SDK_ROOT/cmdline-tools/latest"
  cp -a "$tmp/cmdline-tools/." "$SDK_ROOT/cmdline-tools/latest/"
  rm -f "$zip"
fi

SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKMANAGER" --sdk_root="$SDK_ROOT" --licenses >/dev/null 2>&1 || true

"$SDKMANAGER" --sdk_root="$SDK_ROOT" \
  "platform-tools" \
  "platforms;android-${SDK_VERSION}" \
  "build-tools;${BUILD_TOOLS_VERSION}" \
  "ndk;${NDK_VERSION}" \
  "cmake;${CMAKE_VERSION}"

[[ -d "$SDK_ROOT/platforms/android-${SDK_VERSION}" ]]
[[ -d "$SDK_ROOT/ndk/${NDK_VERSION}" ]]
[[ -x "$SDK_ROOT/cmake/${CMAKE_VERSION}/bin/cmake" ]]

echo "Toolchain Android listo."
echo "ANDROID_SDK_ROOT=$SDK_ROOT"
echo "ANDROID_NDK_HOME=$ANDROID_NDK_HOME"
echo "CMAKE=$SDK_ROOT/cmake/$CMAKE_VERSION/bin/cmake"
