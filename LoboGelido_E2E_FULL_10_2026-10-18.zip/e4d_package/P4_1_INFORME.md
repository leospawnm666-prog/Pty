# P4.1 — Informe: recompilador de *shaders* Maxwell para *compute* (hito H7)

Estado: **P4.1 implementado y verificado. Hito H7 alcanzado en este entorno** (oráculo
SwiftShader; ver los límites en §6).

| Métrica (P4_DISENO.md §2) | Meta de P4.1 | Resultado |
|---|---|---|
| M1 — decodificación del ISA | 296/296 | **296/296 (100 %)** |
| M1 — traducción | (100 % es la meta de P4.4) | 173/296 codificaciones (58,4 %); de la lista de P4.1, **173/186**; las 13 restantes son formas que P4.1 deja fuera con error explícito (§5) |
| M2 — corpus diferencial *compute* | 100 % | **50/50** *shaders* (26 escritos a mano + 24 aleatorios con semilla fija), 3 912 instrucciones Maxwell |
| M3 — etapas | CS | **1/6** (CS); VS…FS son P4.2 |
| M4 — SPIR-V válido | 100 % | **731/731** módulos aceptados por `spirv-val --target-env vulkan1.1` |
| T1 — decodificador frente a envydis | todo | **2 368/2 368** palabras |
| T2 — una prueba por instrucción | todas las de P4.1 | **521/521** casos × 64 invocaciones, todas las instrucciones de la lista de P4.1 |

Meta H7: "M1-decodificación 100 %, M4 100 %, T2 de todas las instrucciones de P4.1 y corpus
*compute* T3 100 %". **Cumplida.**

**Contexto:**
- **Base:** `LoboGelido_beta_0.1_GLASS_PLAY_BUILD_FIX.zip` + la cadena hasta P3.6.
- **Especificación:** `P4_DISENO.md`, aprobada ("Hazlo") con D-P4-1 a D-P4-6 tal como se
  recomendaban.
- **Método:** protocolo de 12 pasos y Regla de Oro. Todo es aditivo: **no se ha modificado ni
  eliminado ningún archivo existente** salvo los dos `CMakeLists.txt`, a los que solo se añaden
  líneas.
- **Política *clean-room* (D-P4-2):** el recompilador es código propio. Referencias usadas, todas
  permisivas: tabla de codificaciones de envytools (MIT, generada a un `.inc` con su licencia),
  comentarios del IR y del emisor GM107 de nouveau (MIT), documentación pública de PTX (modos de
  `PRMT`) y la especificación de SPIR-V. Nada copiado de yuzu, Eden ni Ryujinx.
- **No se ha tocado:** `gpu/` existente, CPU, kernel, IPC, cargadores, Android/Kotlin, `crypto/`.
  La integración con `ShaderProgramManager` y los motores de la GPU es de P5.

## 1. Qué se entrega
| Pieza | Contenido |
|---|---|
| `shader/maxwell/isa.{h,cpp}`, `isa_table.inc`, `ENVYTOOLS_LICENSE` | las 296 codificaciones Maxwell (valor, máscara, mnemónico, operandos, SM mínimo, si llevan predicado de guarda); `find_encoding()`, `bits()` |
| `shader/spirv/builder.{h,cpp}` | emisor de módulos SPIR-V 1.3 propio (tipos y constantes sin duplicados, funciones, bloques) |
| `shader/translate.{h,cpp}` | `lg::shader::translate(code, info) -> {ok, error, spirv, resources, warnings}`; puro, sin estado global, se puede llamar desde varios hilos |
| `CMakeLists.txt` | biblioteca `lobogelido_shader`; tests `shader_static` (siempre) y `shader_t2`, `shader_t3` (con `LOBOGELIDO_SHADER_ORACLE`) |
| `android/app/src/main/cpp/CMakeLists.txt` | los tres `.cpp` nuevos se compilan para el dispositivo (todavía nadie los llama) |
| `tests/test_shader_static.cpp` | T1, M1, M4, D1 (determinismo, 4 hilos), E1 (errores) |
| `tests/test_shader_t2.cpp` | T2 |
| `tests/test_shader_t3.cpp` | T3 |
| `tests/shader/maxwell_ref.{h,cpp}` | **intérprete de referencia** escalar de las instrucciones de P4.1 (solo tests, §3.2) |
| `tests/shader/vk_compute.{h,cpp}`, `dksh.h`, `t3_runner.h` | ejecución en Vulkan cargado con `dlopen`, lector de `.dksh`, comparación A/B/R |
| `tests/shader/t1_golden.h`, `t2_fixtures.h`, `t3_fixtures.h` | *fixtures* generados (los tests no necesitan envytools, uam ni glslang) |
| `tests/shader/tsan_oracle.supp` | supresión de TSan **solo** para la biblioteca del oráculo (§4) |
| `tests/data/shader/corpus/*.comp` | los 50 *shaders* del corpus T3 |
| `tools/gpu_toolchain/` | `build_toolchain.sh` (cadena con versiones fijadas) y los generadores `gen_maxwell_isa.py`, `gen_shader_t1.py`, `gen_shader_t2.py`, `gen_random_shaders.py`, `gen_shader_corpus.py` |

## 2. Cómo traduce
### 2.1 Interfaz
- **Entrada:** las palabras de 64 bits del programa desde su primera palabra de planificación, y
  `ShaderInfo`: tamaño del grupo, memoria compartida y local, qué banco de *constbuffer* va a qué
  *binding* y las **tablas de direcciones de búfer** del *constbuffer* del *driver*.
- La disposición de deko3d/uam viene preparada (`deko3d_compute_tables()`): SSBO en `c0[0x140]`
  (dirección de 64 bits y tamaño), UBO 6+ en `c0[0x20]` (solo dirección).
- **Salida:** SPIR-V 1.3 (GLCompute, `LocalSize`), la lista de recursos usados (banco/entrada →
  *binding*) y avisos.
- **Errores:** primera instrucción no soportada, con dirección y mnemónico (`0x0128: tex:
  instrucción fuera de P4.1`). Nunca hay traducción silenciosa.

### 2.2 Estructura del módulo (D-P4-3, D-P4-4)
- **Registros:** `R0..R254`, `P0..P6` y las banderas `CC` (Z, S, C, O) son variables `Function`
  inicializadas a cero. `RZ` y `PT` son constantes.
- **Flujo de control:** un despachador `loop { switch (pc) }` con un `case` por bloque básico.
  Los líderes son la entrada, los destinos de salto y la instrucción que sigue a un salto. Con
  `BRX`/`JMX`, cada instrucción es un bloque. Sirve para cualquier grafo, también irreducible.
- **Pila CRS por invocación** (`Private`, 64 entradas):
  - `SSY`/`PBK`/`PCNT`/`PRET`/`CAL` apilan entradas con tipo.
  - `SYNC` desapila hasta la entrada `SSY`; `BRK` hasta la `PBK`; `CONT` hasta la `PCNT` (nouveau
    vuelve a ejecutar `PCNT` en la cabecera del bucle); `RET` hasta la `CAL`.
- **Predicación:** cada instrucción va dentro de un `if` estructurado. Las codificaciones sin
  guarda (`PBK`, `SSY`, `PCNT`, `CAL`…) usan los bits 16–19 como operando: la tabla marca cuáles
  tienen guarda (columna nueva del generador).
- **Constbuffers:** cada banco es un UBO `uvec4[4096]` (64 KiB). `LDC` con índice lee de forma
  dinámica y devuelve 0 fuera de rango.
- **Memoria global:** funciones auxiliares (`gld`, `gst`, una por cada operación atómica usada).
  - Comparan la dirección de 64 bits con cada búfer de las tablas que el programa lee del
    *constbuffer*.
  - Así cualquier aritmética de direcciones funciona (acarreos, punteros calculados).
  - Si el programa accede a memoria global sin leer ninguna tabla, error "no rastreable".
  - Los almacenamientos de 8/16 bits usan `AtomicAnd`/`AtomicOr`, sin carreras con los vecinos.
- **Memoria compartida y local:** un array `Workgroup` y otro `Private` por invocación (con una
  palabra extra que absorbe los accesos fuera de rango).

### 2.3 Instrucciones traducidas
Toda la lista de P4_DISENO.md §7, con todas sus formas (registro, *constbuffer*, inmediato,
inmediato de 32 bits) y modificadores:
- **Movimientos y sistema:** `MOV`, `MOV32I`, `S2R`, `CS2R`, `SEL`.
- **Suma y desplazamiento:** `IADD` (+`.X`, `.CC`, `.SAT`, negaciones), `IADD3` (modos `RS/LS`,
  mitades), `IADD32I` (+`PO`), `ISCADD(32I)`, `LEA`/`LEA.HI`.
- **Multiplicación:** `IMAD(32I)`, `IMUL(32I)` con signos mixtos, `XMAD` (`PSL`, `MRG`,
  `CLO/CHI/CSFU/CBCC`, `.X`).
- **Lógica y bits:** `IMNMX`, `LOP(32I)` con predicado de salida, `LOP3` (cualquier LUT), `SHL`,
  `SHR` (`.W`, `BREV`), `SHF` (L/R, 32/U64/S64, `HI`, `W`), `BFE`, `BFI`, `FLO`, `POPC`, `PRMT`
  (los 7 modos).
- **Comparaciones enteras:** `ISETP`/`ISET`/`ICMP` (+`.X` sobre `CC`).
- **Coma flotante:** `FADD(32I)`, `FMUL(32I)` (`FTZ`/`FMZ`, escalas `D2…M8`), `FFMA(32I)`,
  `FMNMX`, `FSETP`/`FSET`/`FCMP` (las 16 condiciones), `MUFU`, `RRO`.
- **Conversiones:** `F2F` (incluido f16↔f32 y redondeos a entero), `F2I` (saturante), `I2F`,
  `I2I`.
- **Predicados:** `PSETP`, `PSET`, `P2R`, `R2P`.
- **Memoria:** `LDG`/`STG`, `LD`/`ST` genéricos, `LDS`/`STS`, `LDL`/`STL` (u8…b128), `LDC`,
  `ATOM` (add/min/max/inc/dec/and/or/xor/exch/cas, u32/s32), `RED`, `ATOMS` (+cas).
- **Barreras y sin efecto:** `BAR.SYNC`, `MEMBAR`, `DEPBAR`, `NOP`, `CCTL*`.
- **Flujo:** `BRA` (con predicado y condición de `CC`), `BRX`, `JMP`, `JMX`, `SSY`, `SYNC`, `PBK`,
  `BRK`, `PCNT`, `CONT`, `CAL`, `JCAL`, `PRET`, `RET`, `EXIT`, `KIL`.

### 2.4 Semántica explícita (riesgo R4)
- **FTZ y FMZ:** se emulan con operaciones enteras sobre los bits (no dependen del *driver*).
- **Saturación:** `NaN` da 0. **`FMNMX`:** devuelve el operando que no es `NaN` (`NMin/NMax`).
- **`F2I`:** satura al rango del destino y `NaN` da 0. **`F2F` a f16:** `NaN` da `0x7fff`,
  |x| ≥ 65520 da ±inf.
- **`I2F` u32:** se convierte como (hi·65536 + lo) para redondear bien en cualquier *driver*
  (SwiftShader trunca).
- **`MUFU`:** modelo FTZ en entrada y salida, con los casos especiales explícitos, porque
  Vulkan los deja indefinidos: lg2(0) = −inf, lg2(x<0) = NaN, rcp(±0) = ±inf, rsq(±0) = ±inf,
  ex2(NaN) = NaN.
- **`SIN`/`COS`:** se reduce el argumento a la fracción de x/2π (como el par `RRO` + `MUFU`); el
  *driver* solo ve [−π, π], donde su precisión está definida. `RRO` es un paso directo.
- **Redondeo distinto de RN** en `FADD`/`FMUL`/`FFMA`/`I2F`, y `SHL.X`/`SHR.X`/`SHF.X`: aviso en
  `warnings` y se aproxima. Ningún *shader* del corpus los usa.

## 3. Verificación
### 3.1 Herramientas (P4_DISENO.md §3)
`tools/gpu_toolchain/build_toolchain.sh` reconstruye todo con commits fijados:
- envytools `f102b823`: `envyas`/`envydis`, compilados a mano porque su CMake pide libxml2.
- uam `5a5afc2b`.
- glslang y SPIRV-Tools `vulkan-sdk-1.3.290.0`.
- Vulkan-Loader `40b8e6ee`.
- SwiftShader `cddb5c91` (Subzero).

Se comprobó que `envyas`/`envydis` recompilados con el *script* regeneran los *fixtures* de T1,
T2 y la tabla del ISA **byte a byte**. uam no es determinista en sus palabras de planificación
(sí en las instrucciones, comprobado en 50×3 compilaciones). El recompilador las ignora.

### 3.2 El intérprete de referencia
- `tests/shader/maxwell_ref.cpp` ejecuta el mismo código Maxwell en C++ escalar, con un grupo de
  trabajo completo (barreras cooperativas, pila CRS, memorias).
- Es una implementación independiente de la misma semántica: en T2 caza los errores de
  implementación del traductor y el emisor.
- Se valida a sí mismo en T3: con el código **real** de uam, el intérprete debe dar lo mismo que
  glslang en SwiftShader.

### 3.3 T1 — decodificador
- Cada una de las 296 codificaciones con su palabra de valor más 7 palabras con bits libres
  aleatorios: 2 368 palabras, las mismas mnemónicas que `envydis -V sm60`.
- Se usa `-V sm60` porque envytools marca como SM60 las FP16 (`HADD2`…), que el SM53 de Tegra X1
  también tiene.
- Ninguna fila de la tabla queda tapada por otra anterior.

### 3.4 T2 — una prueba por instrucción
- 521 casos: cada uno, un programa ensamblado con `envyas`.
  - **Andamio común:** carga A/B/C/predicados/CC de `c2` para cada una de 64 invocaciones, ejecuta
    la instrucción y guarda R5–R8, los predicados, CF y ZF.
  - Algunas formas que `envyas` no sabe escribir se parchean bit a bit: `MUFU.SQRT` (SM52+),
    `SHF.L` inmediato y `F2F` de la mitad alta.
- **Entradas:** casos límite (0, −0, ±inf, NaN, desnormales, `INT_MIN`, desbordes, límites de
  conversión, desplazamientos de 0 a 0xffffffff, campos de bits fuera de rango) y aleatorias.
- **Comparación:** traducido en SwiftShader frente al intérprete.
  - Exacta en enteros.
  - En flotantes, la tolerancia del caso (0 salvo `MUFU`); cualquier `NaN` equivale a cualquier
    `NaN`.
  - Seno y coseno: error absoluto 2⁻¹¹, lo que garantiza Vulkan.
  - Como SwiftShader vacía desnormales y su `Fma` no es fusionada, cada palabra vale también si
    coincide con el intérprete en esos modos (DAZ/FTZ y/o multiplicación + suma). El
    comportamiento del *hardware* (desnormales y FMA fusionada) es el modelo por defecto.
- **Errores que T2 encontró y se corrigieron:**
  - lecturas globales de 8/16 bits (acarreo mal calculado al alinear);
  - `I2F` u32 mal redondeado por SwiftShader;
  - `ConvertSToF` de una constante con tipo u32, que SwiftShader pliega como sin signo;
  - casos especiales de `MUFU`;
  - reducción de seno y coseno;
  - f32→f16 con desbordamiento y `NaN`.

### 3.5 T3 — corpus diferencial
50 *shaders* GLSL propios:
- **26 escritos a mano:** aritmética entera y flotante, bucles con `break`/`continue`, `switch`
  con caída, retorno anticipado, funciones, división por constantes, UBO directos e indirectos,
  SSBO con estructuras std430, memoria compartida con barreras, atómicas globales y compartidas,
  arrays locales indexados, tablas constantes, conversiones, empaquetado, NaN/inf, `frexp`/`ldexp`,
  vectores y matrices, funciones trascendentes, despacho 3D y `gl_NumWorkGroups`.
- **24 aleatorios:** generados con semilla fija.

Tres caminos con las mismas entradas: A (uam → traductor → SwiftShader), B (glslang → SwiftShader)
y R (intérprete):
- **A = B:** enteros bit a bit, flotantes con la tolerancia de cada *shader*.
- **R = A.**

Cubren 56 mnemónicos y 79 codificaciones de lo que uam emite realmente.

**Problemas de uam encontrados** (no del traductor; el corpus los evita y lo documenta en cada
`.comp`):
- índice dinámico de componente de un `vec4` de UBO: siempre lee `.x`;
- `x / -5`: falta la corrección de signo;
- la división entera por una variable se emula con `rcp` en coma flotante (inexacta; uam lo avisa);
- `asin`/`acos` aproximados (~1e-4);
- `%` con negativos está indefinido en GLSL.

### 3.6 M4, D1, E1
- **M4:** los 731 módulos generados (uno por codificación traducible, los 521 de T2 y los 50 de
  T3) pasan `spirv-val --target-env vulkan1.1`. Sin `spirv-val` en el sistema, el test comprueba
  la estructura.
- **D1:** 4 hilos traducen el corpus 3 veces cada uno, con resultado idéntico (también bajo TSan).
- **E1:** palabra no decodificable, salto fuera del programa, *constbuffer* sin *binding*, memoria
  global no rastreable e instrucción fuera de P4.1: todas dan error con dirección.

## 4. Matriz
| *Build* | Resultado |
|---|---|
| *Host*, sin JIT, con oráculo | **85/85** (82 de P3.6 + `shader_static`, `shader_t2`, `shader_t3`) |
| JIT (Release, Dynarmic) con oráculo | **88/88** |
| ASan + UBSan (*host*) | **85/85** |
| ASan + UBSan (JIT) | **88/88** |
| TSan (*host*) | **85/85** |
| TSan (JIT) | **88/88** |
| Dynarmic descargado (`LOBOGELIDO_FETCH_DYNARMIC`) | **88/88** |
| Compilación modo Android (`-Wall -Wextra -Wpedantic`) | 100 archivos OK; los 2 de siempre fallan por falta de cabeceras del NDK en este entorno (`aaudio_sink`, `android_display_adapter`); los 3 nuevos, sin avisos |
| ARM64 (`clang --target=aarch64`, solo compilación) | `lobogelido_shader` y el intérprete compilan |
| Mutación (§4.1) | **28/30** mutantes matados; los 2 restantes son equivalentes en el oráculo |

- UBSan detectó un `memcpy` con origen nulo y tamaño 0 en el *harness* de T3 (programa sin
  *constbuffer* 1). Corregido.
- TSan informa de carreras **dentro** de `libvk_swiftshader.so`: se carga con `dlopen` sin
  instrumentar y TSan no ve su sincronización interna. Se suprimen solo los *frames* de esa
  biblioteca (`tests/shader/tsan_oracle.supp`, aplicado solo a `shader_t2`/`shader_t3`). El
  traductor, con 4 hilos (D1), está limpio.

### 4.1 Mutación
30 mutantes del decodificador, el emisor SPIR-V y el traductor, cada uno compilado y contrastado
con `shader_static` + `shader_t2` + `shader_t3` (`/tmp`, fuera del árbol):

| Resultado | Mutantes |
|---|---|
| **Matados (28)** | destino de salto sin normalizar; `IADD` negado sin +1; campo de desplazamiento de `ISCADD`; bit de `abs` de `FSETP`*; signo de `XMAD.CSFU`; `SHF` alto/bajo; `BFE` con signo sin extender; réplica de signo de `PRMT`; saturación superior de `F2I`; tipo de entrada CRS al desapilar; `SSY` que apila `PBK`; negación del predicado de guarda; orden de operandos de `LOP3`; desplazamiento de `LEA.HI`; corrección de signo de la multiplicación alta; índice de palabra de la memoria compartida; saturación de `I2I` con fuente sin signo negada*; `FMNMX` mín/máx; `ICMP` sobre A en vez de C; bit `PT` de `P2R`; almacenamiento global completo/parcial; modo C de `XMAD`; `S2R` del tid combinado; condición de `CC` en saltos; bit 63 del decodificador; `bits()` corto; cadena SPIR-V sin terminador; *stride* del UBO |
| **Equivalentes en el oráculo (2)** | sin el caso especial `MUFU.RCP(±0)` (SwiftShader ya da ±inf en 1/0; otro *driver* podría no hacerlo, por eso se mantiene); sin vaciar el resultado de `FADD.FTZ` (SwiftShader vacía todos los desnormales) |

\* Sobrevivieron a la primera pasada y llevaron a añadir casos a T2 (`fsetp_absa`, `fsetp_negb`,
`fsetp_absa_negb`, `fset_absa_negb`, `fmnmx_absa_negb`, `i2i_sat_neg_u32_*`).

## 5. Qué queda fuera de P4.1 (error explícito)
| Forma | Fase |
|---|---|
| Destinos de salto en *constbuffer* (`BRA/SSY/PBK/PCNT/CAL/PRET/JMP/JCAL c[]`, `BRX/JMX c[]`) | P4.4 (falta confirmar la base de la dirección) |
| `LD`/`ST` de atributos (`a[]`), `IPA`, `OUT`, `ALD/AST` | P4.2 |
| Texturas e imágenes (`TEX`, `TLD`, `TLD4`, `TXQ`, `SULD/SUST/SUATOM`…) | P4.3 |
| `VOTE`, `SHFL`, `BAR` distinta de `SYNC`, `ATOMS.CAST`, `ATOM`/`RED` de 64 bits y f32, `IMNMX` extendido, `P2R/R2P` sobre `CC`, `LDG` con predicado de salida, `LD/ST` genérico con predicado, `LEA.HI` con negación, modos de índice de `LDC`, `VMAD/VADD/VABSDIFF…`, `HADD2/HMUL2/HFMA2`, dobles (`DADD/DMUL/DFMA…`), conversiones de 64 bits | P4.4 |
| Relojes (`S2R CLOCK…`) | devuelven 0 con aviso |

## 6. Límites (honestos)
- **El oráculo es SwiftShader** (Vulkan en la CPU), no la GPU del teléfono ni un Maxwell real.
  - Las diferencias conocidas de SwiftShader están cubiertas en las comparaciones: vacía
    desnormales, `Fma` no fusionada, precisión de seno y coseno, carga útil de los `NaN`.
  - Las dos que cambiaban resultados (`I2F` u32 y `ConvertSToF` de constantes) se esquivan en el
    traductor, lo que también protege de *drivers* reales con el mismo fallo.
- **La semántica sale de documentación pública**, no de pruebas en *hardware*.
  - T2 compara dos implementaciones del mismo modelo: encuentra errores de implementación, no
    malentendidos del *hardware*.
  - T3 valida el modelo con código real de uam, pero solo en lo que nouveau emite.
- **Supuestos documentados** que solo un Maxwell real confirmaría:
  - `ISETP.X` sobre `CC`; el acarreo de `IADD3`; el `CSFU` de `XMAD` (según el comentario de
    nouveau);
  - la base de `BRX`/`JMP`/`JMX`; la profundidad (64) y el desapilado de la pila CRS;
  - el modelo de `MUFU`; `F2F` a f16 con `NaN` = `0x7fff`; el `C` de `LOP3` inmediato en
    `REG_39` (envydis no lo imprime).
- **Rendimiento (P4.5):** el SPIR-V es correcto, no rápido.
  - Despachador `loop+switch`, registros como variables.
  - Cada acceso global compara con cada búfer usado.
- **Lo que solo se puede comprobar en el teléfono** (como en fases anteriores): compilación
  real con el NDK y ejecución en Adreno.

## 7. Siguiente fase
P4.2 (etapas gráficas: SPH, atributos, salidas, `OUT`, teselación) con su diseño, o primero la
integración mínima del traductor en `ShaderProgramManager`.
