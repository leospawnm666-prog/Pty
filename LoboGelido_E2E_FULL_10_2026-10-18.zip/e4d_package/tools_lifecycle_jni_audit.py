#!/usr/bin/env python3
"""Reproducible static checks for the Lobo Gélido Kotlin/JNI lifecycle boundary.
This script does not claim ABI signature or runtime correctness; it checks names and
critical source-level ownership invariants only.
"""
from collections import Counter
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parent
kt_path = ROOT / 'android/app/src/main/java/com/lobogelido/RuntimeBridge.kt'
cpp_path = ROOT / 'android/app/src/main/cpp/native.cpp'
surface_path = ROOT / 'android/app/src/main/java/com/lobogelido/GameSurfaceView.kt'
wrapper_props = ROOT / 'android/gradle/wrapper/gradle-wrapper.properties'
wrapper_jar = ROOT / 'android/gradle/wrapper/gradle-wrapper.jar'

errors = []
kt = kt_path.read_text(encoding='utf-8')
cpp = cpp_path.read_text(encoding='utf-8')
surface = surface_path.read_text(encoding='utf-8')
methods = re.findall(r'\bexternal\s+fun\s+(\w+)\s*\(', kt)
exports = re.findall(r'Java_com_lobogelido_RuntimeBridge_(\w+)\s*\(', cpp)
km, cm = Counter(methods), Counter(exports)
missing, extra = sorted((km - cm).elements()), sorted((cm - km).elements())
if missing: errors.append(f'JNI exports missing for Kotlin declarations: {missing}')
if extra: errors.append(f'C++ JNI exports without Kotlin declarations: {extra}')
if any(n > 1 for n in km.values()): errors.append('Duplicate Kotlin external method names found')
if any(n > 1 for n in cm.values()): errors.append('Duplicate C++ JNI export names found')

start = surface.find('override fun surfaceDestroyed')
end = surface.find('/** Stop the renderer first', start)
if start < 0 or end < 0:
    errors.append('Could not isolate surfaceDestroyed implementation')
else:
    destroyed = surface[start:end]
    if 'stopSession' in destroyed:
        errors.append('surfaceDestroyed directly stops runtime session; violates Surface/Runtime separation')
    if 'stopAndShutdownPresentation()' not in destroyed:
        errors.append('surfaceDestroyed does not route teardown through presentation owner')

print(f'Kotlin external declarations: {len(methods)} ({len(km)} unique)')
print(f'C++ JNI exports by name: {len(exports)} ({len(cm)} unique)')
print(f'Unmatched Kotlin names: {missing}')
print(f'Unmatched C++ names: {extra}')
print('Surface/runtime separation check: ' + ('PASS' if not errors else 'CHECK'))
print(f'Gradle wrapper properties present: {wrapper_props.is_file()}')
print(f'Gradle wrapper JAR present: {wrapper_jar.is_file()}')
if not wrapper_props.is_file() or not wrapper_jar.is_file():
    print('BUILD BLOCKER: checked-in Gradle wrapper is incomplete; Android build was not run.')
if errors:
    print('\n'.join('FAIL: ' + e for e in errors))
    sys.exit(1)
print('STATIC NAME/OWNERSHIP CHECKS: PASS (not a Kotlin/C++ ABI or device E2E certification)')
