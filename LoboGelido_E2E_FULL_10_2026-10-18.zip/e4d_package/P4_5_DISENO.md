# P4.5 — Diseño: las instrucciones de vídeo de Maxwell como modelos

Estado: **implementado** (pedido del 15-oct, "completemos el 100 %"; el usuario no eligió entre
las opciones y se tomó la recomendada: modelos con aviso donde los campos están documentados).
Resultado en `P4_5_INFORME.md`.

## 1. Objetivo
P4.4 dejó 14 filas sin traducir porque ninguna fuente pública permitida las describe. Nueve son
instrucciones de vídeo. Para estas, PTX define la semántica (`vadd`, `vabsdiff`, `vmad`, `vset`,
`vshl`, `vshr`, `vmin`/`vmax`, `vabsdiff4`) y envydis da los campos. Lo que no está publicado es
la correspondencia exacta entre ambos. P4.5 traduce como **modelo con aviso** las filas cuyos
campos envydis describe sin contradicciones.

| Meta | P4.4 | P4.5 |
|---|---|---|
| M1 | 282/296 (95,3 %) | **288/296 (97,3 %)** |
| Filas con error razonado | 14 | 8 |

## 2. Qué se traduce y qué no
| Fila | P4.5 | Por qué |
|---|---|---|
| `VADD`, `VABSDIFF`, `VMAD`, `VSETP`, `VSHL`, `VSHR` | **modelo** | envydis describe todos sus campos y PTX su semántica |
| `VMNMX` | error | ningún campo de envydis distingue mínimo de máximo |
| `VSET` | error | envydis asigna el bit 47 a la vez a la condición y a `.CC` |
| `VABSDIFF4` | error | la tabla de máscara de carriles de envydis tiene entradas repetidas (erratas) y no dice si el valor 0 es "ninguno" o "todos" |
| `TXA`, `IDE`, `STP`, `VOTE.VTG`, `LDG` con predicado | error | sin ninguna descripción pública (P4.4 §2.4) |

Las 8 filas restantes no se pueden traducir sin inventar. Sin *hardware* real ni documentación
pública, el 100 % literal no es alcanzable de forma honesta.

## 3. Decisiones
| # | Decisión |
|---|---|
| D-P4.5-1 | **Semántica de PTX** ("Scalar Video Instructions"): extracción de la parte de A/B con extensión de signo según su tipo; operación en precisión suficiente (34 bits en suma y resta, 64 en `vmad`); saturación con el rango del destino (del campo combinado en los modos de mezcla); operación secundaria (`acc`, `min`, `max`) o mezcla (`mrg_16h/16l/8b0/8b2` = `h1`/`h0`/`b0`/`b2` de PTX) con C. `vmad`: `signedFinal` = A o B con signo, C con ese signo, `.shr7/.shr15` aritmético o lógico. `vshl`/`vshr`: `.wrap` = `n & 31`, `.clamp` = `min(n, 32)` |
| D-P4.5-2 | **Campos (envydis):** tipo de A en los bits 38 (16 bits) y 48 (signo), selector de byte en 36-37 (en 16 bits solo 0 y 2: medias palabras); B registro (bit 50) con tamaño y selector en 28-30, o inmediato de 16 bits; signo de B en el bit 49; destino con signo en el bit 54; operación secundaria en 51-53; `sat` en 55 (`VABSDIFF`, `VMAD`, `VSHL/VSHR`); escala de `VMAD` en 51-52; condición de `VSETP` en 43-44 + 47 y operación booleana en 45-46 |
| D-P4.5-3 | **Bits no descritos:** si una codificación tiene a 1 un bit que envydis no describe (por ejemplo el 55 de `VADD`, probablemente `.sat`, o los 53-54 de `VMAD`, probablemente las negaciones de PTX), es **error explícito** "bits sin descripción". Lo mismo con un valor reservado (`OOPS` en envydis) o un selector impar en 16 bits |
| D-P4.5-4 | **Sin `Int64`:** la aritmética de 64 bits usa pares de palabras de 32 bits, como en P4.1, para no exigir `shaderInt64` |
| D-P4.5-5 | **CC:** PTX no tiene CC. Con `.CC`, Z/S salen del resultado y C/O valen 0 (modelo) |

## 4. Pruebas
- **T2-X:** 45 casos nuevos (302 en total), con expectativas calculadas en Python a partir de
  PTX: todos los tipos y selectores, B como registro e inmediato, cada operación secundaria y
  mezcla, saturación, escalas de `VMAD`, `.wrap`/`.clamp`, las 8 condiciones de `VSETP` y sus 3
  operaciones booleanas. Pasan en los dos oráculos.
- **Estática:** M4 de todos los módulos; error de "bits sin descripción" (`VADD` con el bit 55);
  `VMNMX` sigue con error.
- **Límite:** las expectativas salen de la misma lectura de PTX que el traductor. Prueban que la
  traducción es coherente con el modelo, no que el modelo coincida con el *hardware*.

## 5. Riesgos e impacto
| Riesgo | Mitigación |
|---|---|
| Correspondencia de campos equivocada | Solo filas sin contradicciones en envydis; bits no descritos → error; aviso en cada traducción |
| Regresión | El SPIR-V de los módulos de P4.4 sale idéntico (comparación de *hashes*) |

**Impacto:** `shader/translate_video.inc` (nuevo); en `translate.cpp`, el despacho, las
declaraciones y la inclusión (solo añadidos); `tests/` (casos T2-X, comprobaciones estáticas).
