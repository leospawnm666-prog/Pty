# Auditoría de arquitectura — Lobo Gélido P6 E2E BUILD READY

Fecha: 2026-10-16  
Rol: Arquitecto Senior / Tech Lead

## 1. Estructura del árbol

| Área | Ruta | Rol |
|------|------|-----|
| Shell Android | `android/` | UI, JNI, Gradle |
| Nativo host | `android/app/src/main/cpp/` | RuntimeHost, JNI |
| Loader | `loader/` | NSP/XCI/NCA |
| Memoria | `memory/` | MMU, PagePool, fastmem |
| CPU | `cpu/` | JIT/interpret |
| GPU | `gpu/` | Vulkan, pipelines async |
| Shader | `shader/` | Maxwell→SPIR-V |
| Audio | `audio/` | AAudio / engine |
| Runtime | `runtime/` | sesión guest |
| Tests | `tests/` (~18 MB) | unitarios nativos |

**Punto fuerte:** separación bottom-up Loader → MMU → CPU → JNI → GPU.  
**Deuda:** `MainActivity.kt` ~3900 líneas (God Activity). No se partió en esta pasada para no romper el shell.

## 2. Hallazgos y correcciones

| Severidad | Hallazgo | Acción |
|-----------|----------|--------|
| Media | `Handler.postDelayed` de welcome **sin cancelar** → fuga de Activity | **Corregido:** `welcomeAdvance` + `removeCallbacks` en `onDestroy` |
| Baja | `CoverPipeline` batches sin cancelación | **Corregido:** `cancelPending()` + llamada en `onDestroy` / invalidate keys |
| Info | `gradle-wrapper.jar` ausente en ZIP original | Ya restaurado en E2E_BUILD_READY |
| Info | FD SAF: `detachFd` + native `dup` + close JNI | Correcto (sin fuga de FD) |
| Info | `close_owned_fd_locked` bajo `runtime_mutex_` | Correcto |
| Deuda | Monolito MainActivity | Documentado; refactor por fases |
| Deuda | Docs P4/P6 numerosos en raíz | No afectan runtime |
| Riesgo host | Build NDK necesita ≥4–8 GiB RAM | No es bug de código |

## 3. Gates verificados

- JNI external ↔ exports: **39/39**
- CMake: `-fPIC`, `-Wl,-z,notext`, page-size 16 KB
- onDestroy: runtimeLaunch, artwork, library, setup, handlers, surface, Vulkan order

## 4. Qué no es fuga pero parece

- Executor de CoverPipeline / Artwork **daemon** = vida de proceso (aceptable).
- PagePool / ResourceTracker: shrink en `stop_session`.

## 5. Recomendación de arquitectura (siguiente ciclo)

1. Extraer `LibraryScreen`, `SettingsRouter`, `BootFlow` fuera de MainActivity.
2. Mantener `RuntimeLaunchController` como único dueño de SAF→FD→sesión.
3. No reintroducir `setImageURI` en UI thread (ya mitigado por `LibraryArtworkLoader`).
