#include "audio_engine.h"
#include <algorithm>
#include <sstream>

namespace lg::audio {
AudioEngine::AudioEngine(std::unique_ptr<IAudioSink> sink) : sink_(std::move(sink)) {}
AudioEngine::~AudioEngine() { stop(); }
bool AudioEngine::start(const DeviceAudioCaps& caps, uint32_t desired_channels) {
    std::lock_guard lock(lifecycle_mutex_);
    if (running_.load(std::memory_order_acquire)) return true;
    if (!sink_) return false;
    route_ = plan_route(caps, desired_channels);
    const size_t capacity = static_cast<size_t>(route_.frames_per_burst) * route_.channels * 8u;
    ring_ = std::make_unique<AudioRingBuffer>(capacity);
    submitted_frames_.store(0); consumed_frames_.store(0); underruns_.store(0); drift_ms_.store(0.0);
    master_frame_.store(0); master_budget_ns_.store(16666667);
    if (!sink_->open(route_, &AudioEngine::render_callback, this)) { ring_.reset(); return false; }
    running_.store(true, std::memory_order_release);
    return true;
}
void AudioEngine::stop() noexcept {
    std::lock_guard lock(lifecycle_mutex_);
    if (!running_.exchange(false, std::memory_order_acq_rel)) return;
    if (sink_) sink_->close();
    ring_.reset();
}
size_t AudioEngine::submit(const float* interleaved, size_t frames) noexcept {
    if (!interleaved || frames == 0 || !running_.load(std::memory_order_acquire) || !ring_) return 0;
    const size_t written_samples = ring_->write(interleaved, frames * route_.channels);
    const size_t written_frames = written_samples / std::max(1u, route_.channels);
    submitted_frames_.fetch_add(written_frames, std::memory_order_relaxed);
    return written_frames;
}
void AudioEngine::on_frame_presented(uint64_t frame_index, int64_t frame_budget_ns) noexcept {
    if (!running_.load(std::memory_order_acquire)) return;
    if (!av_sync_.load(std::memory_order_relaxed)) return;
    if (frame_budget_ns <= 0) frame_budget_ns = 16666667;
    master_frame_.store(frame_index, std::memory_order_release);
    master_budget_ns_.store(frame_budget_ns, std::memory_order_release);
    const double fps = 1e9 / static_cast<double>(frame_budget_ns);
    const double expected = static_cast<double>(frame_index) * route_.sample_rate / std::max(1.0, fps);
    const double actual = static_cast<double>(consumed_frames_.load(std::memory_order_acquire));
    drift_ms_.store((actual - expected) * 1000.0 / std::max(1u, route_.sample_rate), std::memory_order_release);
}
size_t AudioEngine::render_callback(void* user, float* out, size_t frames) noexcept { return user ? static_cast<AudioEngine*>(user)->render(out, frames) : 0; }
size_t AudioEngine::render(float* out, size_t frames) noexcept {
    if (!out || frames == 0 || !ring_) return 0;
    const size_t wanted = frames * route_.channels;
    const size_t got = ring_->read(out, wanted);
    const size_t got_frames = got / std::max(1u, route_.channels);
    consumed_frames_.fetch_add(got_frames, std::memory_order_relaxed);
    if (got < wanted) { std::fill(out + got, out + wanted, 0.0f); underruns_.fetch_add(1, std::memory_order_relaxed); }
    if (muted_.load(std::memory_order_relaxed)) {
        std::fill(out, out + wanted, 0.0f);
        return frames;
    }
    const float vol = master_volume_.load(std::memory_order_relaxed);
    if (vol != 1.0f) {
        for (size_t i = 0; i < got; ++i) out[i] *= vol;
    }
    return frames;
}
size_t AudioEngine::queued_frames() const noexcept { return ring_ ? ring_->available_read() / std::max(1u, route_.channels) : 0; }
std::string AudioEngine::diagnostics() const {
    std::ostringstream s; s << "audio=" << (running() ? "RUNNING" : "OFF") << ";rate=" << route_.sample_rate
      << ";channels=" << route_.channels << ";burst=" << route_.frames_per_burst << ";queued=" << queued_frames()
      << ";submitted=" << submitted_frames_.load() << ";consumed=" << consumed_frames_.load()
      << ";underruns=" << underruns_.load() << ";avDriftMs=" << drift_ms_.load();
    return s.str();
}
} // namespace lg::audio
