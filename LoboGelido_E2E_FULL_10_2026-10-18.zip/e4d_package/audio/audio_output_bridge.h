#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <mutex>
#include <vector>

namespace lg::audio {

/**
 * Process-wide bridge: guest AudOut HLE pushes interleaved float PCM here;
 * NativeRuntimeHost registers the sink that feeds AudioEngine::submit.
 *
 * This closes the previous gap where AudioEngine existed but nothing in the
 * guest service layer could reach the ring buffer.
 */
class AudioOutputBridge {
public:
    using SubmitFn = std::function<size_t(const float* interleaved, size_t frames)>;

    static AudioOutputBridge& instance() {
        static AudioOutputBridge b;
        return b;
    }

    void set_submitter(SubmitFn fn) {
        std::lock_guard lock(mutex_);
        submitter_ = std::move(fn);
    }

    void clear_submitter() {
        std::lock_guard lock(mutex_);
        submitter_ = nullptr;
    }

    /** Guest / HLE path: interleaved float frames (channels decided by host route). */
    size_t submit(const float* interleaved, size_t frames) noexcept {
        if (!interleaved || frames == 0) return 0;
        SubmitFn local;
        {
            std::lock_guard lock(mutex_);
            local = submitter_;
        }
        if (!local) {
            dropped_frames_.fetch_add(frames, std::memory_order_relaxed);
            return 0;
        }
        const size_t n = local(interleaved, frames);
        submitted_frames_.fetch_add(n, std::memory_order_relaxed);
        return n;
    }

    uint64_t submitted_frames() const noexcept { return submitted_frames_.load(); }
    uint64_t dropped_frames() const noexcept { return dropped_frames_.load(); }

    void reset_counters() noexcept {
        submitted_frames_.store(0);
        dropped_frames_.store(0);
    }

private:
    AudioOutputBridge() = default;
    std::mutex mutex_;
    SubmitFn submitter_;
    std::atomic<uint64_t> submitted_frames_{0};
    std::atomic<uint64_t> dropped_frames_{0};
};

} // namespace lg::audio
