#include "audio_backend.h"
#include <algorithm>

namespace lg::audio {

AudioRoute plan_route(const DeviceAudioCaps& caps, uint32_t desired_channels) {
    AudioRoute r;
    r.sample_rate = caps.native_sample_rate ? caps.native_sample_rate : 48000;
    r.frames_per_burst = caps.native_burst ? caps.native_burst : 192;
    r.low_latency = caps.low_latency_path;

    if (caps.spatializer_available) {
        // Object-based path: feed the 7.1.4 bed to the platform spatializer (Atmos-capable).
        r.spatialized = true;
        const uint32_t max_channels = caps.max_channels ? caps.max_channels : 2;
        r.channels = std::min<uint32_t>(2u, max_channels);
        r.hardware_offload = false;      // interactive spatialization stays on the low-latency path
    } else {
        r.spatialized = false;
        // Fall back to the widest layout the device and the caller both support.
        uint32_t ch = desired_channels ? desired_channels : 2;
        if (caps.max_channels && ch > caps.max_channels) ch = caps.max_channels;
        if (ch == 0) ch = 2;
        r.channels = ch;
        // Offload only when supported and we are not on the interactive low-latency path.
        r.hardware_offload = caps.offload_supported && !caps.low_latency_path;
    }
    return r;
}

} // namespace lg::audio
