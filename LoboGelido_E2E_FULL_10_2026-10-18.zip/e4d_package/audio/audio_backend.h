#pragma once
#include <cstddef>
#include <cstdint>

// Platform audio routing contract. The concrete sink (AAudio callback stream on Android)
// lives in the platform adapter; this header defines the backend-neutral route and the
// policy that chooses it, so the decision is host-testable.
//
// Hardware routing vs software mixing: when the device exposes a spatializer or an offload
// path we request it, so mixing/spatialization runs on dedicated hardware/DSP instead of
// burning CPU on the main thread.

namespace lg::audio {

struct AudioRoute {
    uint32_t sample_rate{48000};
    uint32_t channels{2};             // output channels: 2, 6 (5.1), 8 (7.1) or 12 (7.1.4 bed)
    bool low_latency{true};           // AAudio PerformanceMode::LOW_LATENCY, callback driven
    bool spatialized{false};          // hand the object bed to the platform Spatializer (Atmos-capable)
    bool hardware_offload{false};     // offload mixing/decoding to hardware/DSP (no CPU software mix)
    uint32_t frames_per_burst{192};   // device-preferred burst; buffer sized to a small multiple of this
};

// What the device reports it can do (filled from the platform on the device).
struct DeviceAudioCaps {
    bool spatializer_available{false};   // Spatializer immersive level > NONE (Atmos-capable output)
    bool low_latency_path{true};         // AAudio low-latency path present
    bool offload_supported{false};       // hardware offload available
    uint32_t native_sample_rate{48000};
    uint32_t native_burst{192};
    uint32_t max_channels{2};            // max output channels the active device supports
};

// Pick the best route for the device. Spatialization takes priority (12-ch object bed to
// the spatializer); otherwise fall back to the widest native channel layout. Low latency
// follows the device path; offload is only requested when it does not conflict with the
// low-latency interactive path.
AudioRoute plan_route(const DeviceAudioCaps& caps, uint32_t desired_channels);

// Real-time output sink. Implemented by the platform adapter (e.g. AAudio); defined here
// so the core can target it without depending on the platform.
class IAudioSink {
public:
    using RenderCallback = size_t (*)(void* user, float* interleaved, size_t frames) noexcept;
    virtual ~IAudioSink() = default;
    virtual bool open(const AudioRoute& route, RenderCallback callback, void* user) = 0;
    virtual size_t submit(const float* interleaved, size_t frames) = 0;
    virtual void close() = 0;
    virtual AudioRoute route() const = 0;
};

} // namespace lg::audio
