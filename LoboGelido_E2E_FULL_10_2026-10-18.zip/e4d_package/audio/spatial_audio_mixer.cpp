#include "spatial_audio_mixer.h"

#include <cmath>

namespace lg::audio {
namespace {

Vec3 from_az_el(float az_deg, float el_deg) {
    const float az = az_deg * 3.14159265358979f / 180.0f;
    const float el = el_deg * 3.14159265358979f / 180.0f;
    Vec3 v;
    v.x = std::cos(el) * std::sin(az);
    v.y = std::sin(el);
    v.z = std::cos(el) * std::cos(az);
    return v;
}

float dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
float length(const Vec3& v) { return std::sqrt(dot(v, v)); }

} // namespace

SpatialAudioMixer::SpatialAudioMixer() {
    // 7.1.4 layout (azimuth from front, + to the right; elevation up).
    speakers_[FL]  = {from_az_el(-30, 0),   false};
    speakers_[FR]  = {from_az_el(30, 0),    false};
    speakers_[C]   = {from_az_el(0, 0),     false};
    speakers_[LFE] = {from_az_el(0, 0),     true};   // not panned into
    speakers_[SL]  = {from_az_el(-90, 0),   false};
    speakers_[SR]  = {from_az_el(90, 0),    false};
    speakers_[RL]  = {from_az_el(-150, 0),  false};
    speakers_[RR]  = {from_az_el(150, 0),   false};
    speakers_[TFL] = {from_az_el(-45, 45),  false};
    speakers_[TFR] = {from_az_el(45, 45),   false};
    speakers_[TRL] = {from_az_el(-135, 45), false};
    speakers_[TRR] = {from_az_el(135, 45),  false};
}

std::array<float, SpatialAudioMixer::kChannels> SpatialAudioMixer::compute_gains(Vec3 pos, float gain) const {
    std::array<float, kChannels> g{};
    const float dist = length(pos);
    Vec3 dir = pos;
    if (dist > 1e-6f) { dir.x /= dist; dir.y /= dist; dir.z /= dist; }
    else { dir = Vec3{0, 0, 1}; }   // degenerate: treat as front

    // Directional weights: cosine lobe, sharpened, positive hemisphere only.
    const float sharpness = 2.0f;
    float sumsq = 0.0f;
    for (int i = 0; i < kChannels; ++i) {
        if (speakers_[i].lfe) { g[i] = 0.0f; continue; }
        float c = dot(dir, speakers_[i].dir);
        if (c < 0.0f) c = 0.0f;
        const float w = std::pow(c, sharpness);
        g[i] = w;
        sumsq += w * w;
    }
    // Constant-power normalization (sum of squares == 1 before attenuation).
    if (sumsq > 1e-12f) {
        const float inv = 1.0f / std::sqrt(sumsq);
        for (int i = 0; i < kChannels; ++i) g[i] *= inv;
    }
    // Distance attenuation (unity within the unit sphere, 1/d beyond).
    float atten = 1.0f;
    if (dist > 1.0f) atten = 1.0f / dist;
    const float scale = atten * gain;
    for (int i = 0; i < kChannels; ++i) g[i] *= scale;
    return g;
}

void SpatialAudioMixer::render(const std::vector<std::pair<uint32_t, const float*>>& sources,
                               size_t frames, float* out_bed) const {
    for (size_t i = 0; i < frames * static_cast<size_t>(kChannels); ++i) out_bed[i] = 0.0f;
    for (const auto& src : sources) {
        const AudioObject* obj = find(src.first);
        if (!obj || src.second == nullptr) continue;
        const std::array<float, kChannels> g = compute_gains(obj->pos, obj->gain);
        const float* mono = src.second;
        for (size_t f = 0; f < frames; ++f) {
            const float s = mono[f];
            float* dst = out_bed + f * kChannels;
            for (int ch = 0; ch < kChannels; ++ch) dst[ch] += s * g[ch];
        }
    }
}

uint32_t SpatialAudioMixer::add_object(Vec3 pos, float gain) {
    AudioObject o; o.id = next_id_++; o.pos = pos; o.gain = gain;
    objects_.push_back(o);
    return o.id;
}

bool SpatialAudioMixer::set_position(uint32_t id, Vec3 pos) {
    if (AudioObject* o = find(id)) { o->pos = pos; return true; }
    return false;
}

bool SpatialAudioMixer::set_gain(uint32_t id, float gain) {
    if (AudioObject* o = find(id)) { o->gain = gain; return true; }
    return false;
}

bool SpatialAudioMixer::remove_object(uint32_t id) {
    for (auto it = objects_.begin(); it != objects_.end(); ++it) {
        if (it->id == id) { objects_.erase(it); return true; }
    }
    return false;
}

const AudioObject* SpatialAudioMixer::find(uint32_t id) const {
    for (const auto& o : objects_) if (o.id == id) return &o;
    return nullptr;
}
AudioObject* SpatialAudioMixer::find(uint32_t id) {
    for (auto& o : objects_) if (o.id == id) return &o;
    return nullptr;
}

} // namespace lg::audio
