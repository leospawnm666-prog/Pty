#pragma once
#include <atomic>
#include <cstddef>
#include <vector>

// Wait-free single-producer / single-consumer ring for float PCM samples.
//
// The audio callback (consumer) and the emulation/mixer thread (producer) never share a
// lock, so the real-time audio path has no priority-inversion or blocking risk — the key
// to an ultra-low-latency backend (AAudio LOW_LATENCY / callback driven). Capacity is
// rounded up to a power of two so index wrapping is a mask. The unit is a sample (for
// N-channel interleaved audio, one frame is N samples).

namespace lg::audio {

class AudioRingBuffer {
public:
    explicit AudioRingBuffer(size_t capacity_samples) {
        cap_ = next_pow2(capacity_samples < 2 ? 2 : capacity_samples);
        mask_ = cap_ - 1;
        buf_.assign(cap_, 0.0f);
    }

    // Producer side. Returns the number of samples actually written (<= available space).
    size_t write(const float* data, size_t samples) {
        const size_t head = head_.load(std::memory_order_relaxed);
        const size_t tail = tail_.load(std::memory_order_acquire);
        const size_t space = cap_ - (head - tail);
        const size_t n = samples < space ? samples : space;
        for (size_t i = 0; i < n; ++i) buf_[(head + i) & mask_] = data[i];
        head_.store(head + n, std::memory_order_release);
        return n;
    }

    // Consumer side. Returns the number of samples actually read (<= available data).
    size_t read(float* out, size_t samples) {
        const size_t tail = tail_.load(std::memory_order_relaxed);
        const size_t head = head_.load(std::memory_order_acquire);
        const size_t avail = head - tail;
        const size_t n = samples < avail ? samples : avail;
        for (size_t i = 0; i < n; ++i) out[i] = buf_[(tail + i) & mask_];
        tail_.store(tail + n, std::memory_order_release);
        return n;
    }

    size_t available_read() const {
        return head_.load(std::memory_order_acquire) - tail_.load(std::memory_order_acquire);
    }
    size_t available_write() const { return cap_ - available_read(); }
    size_t capacity() const { return cap_; }

    // Not thread-safe: only call while both sides are stopped.
    void reset() { head_.store(0); tail_.store(0); }

private:
    static size_t next_pow2(size_t n) {
        size_t p = 1;
        while (p < n) p <<= 1;
        return p;
    }
    std::vector<float> buf_;
    size_t cap_{0};
    size_t mask_{0};
    std::atomic<size_t> head_{0};   // producer-owned write cursor
    std::atomic<size_t> tail_{0};   // consumer-owned read cursor
};

} // namespace lg::audio
