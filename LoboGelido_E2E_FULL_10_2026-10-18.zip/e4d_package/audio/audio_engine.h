#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include "audio_backend.h"
#include "audio_ring_buffer.h"

namespace lg::audio {

class AudioEngine final {
public:
    explicit AudioEngine(std::unique_ptr<IAudioSink> sink);
    ~AudioEngine();
    AudioEngine(const AudioEngine&) = delete;
    AudioEngine& operator=(const AudioEngine&) = delete;
    bool start(const DeviceAudioCaps& caps, uint32_t desired_channels = 2);
    void stop() noexcept;
    size_t submit(const float* interleaved, size_t frames) noexcept;
    void on_frame_presented(uint64_t frame_index, int64_t frame_budget_ns) noexcept;
    bool running() const noexcept { return running_.load(std::memory_order_acquire); }
    size_t queued_frames() const noexcept;
    uint64_t submitted_frames() const noexcept { return submitted_frames_.load(); }
    uint64_t consumed_frames() const noexcept { return consumed_frames_.load(); }
    uint64_t underruns() const noexcept { return underruns_.load(); }
    double av_drift_ms() const noexcept { return drift_ms_.load(); }
    AudioRoute route() const noexcept { return route_; }
    std::string diagnostics() const;
    void set_master_volume(float v) noexcept { master_volume_.store(v < 0.f ? 0.f : (v > 1.f ? 1.f : v)); }
    void set_muted(bool m) noexcept { muted_.store(m); }
    void set_av_sync_enabled(bool e) noexcept { av_sync_.store(e); }
private:
    static size_t render_callback(void* user, float* out, size_t frames) noexcept;
    size_t render(float* out, size_t frames) noexcept;
    std::unique_ptr<IAudioSink> sink_;
    AudioRoute route_{};
    std::unique_ptr<AudioRingBuffer> ring_;
    std::atomic<bool> running_{false};
    std::atomic<uint64_t> submitted_frames_{0};
    std::atomic<uint64_t> consumed_frames_{0};
    std::atomic<uint64_t> underruns_{0};
    std::atomic<double> drift_ms_{0.0};
    std::atomic<uint64_t> master_frame_{0};
    std::atomic<int64_t> master_budget_ns_{16666667};
    std::mutex lifecycle_mutex_;
    std::atomic<float> master_volume_{1.0f};
    std::atomic<bool> muted_{false};
    std::atomic<bool> av_sync_{true};
};

} // namespace lg::audio
