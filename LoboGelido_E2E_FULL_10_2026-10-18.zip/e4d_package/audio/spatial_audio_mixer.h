#pragma once
#include <array>
#include <cstdint>
#include <utility>
#include <vector>

// Object-based spatial audio mixer feeding a 7.1.4 (12-channel) bed.
//
// SCOPE / honesty: "Dolby Atmos" playback on the platform is performed by the OS
// Spatializer (Android 12+ Spatializer / AAudio spatialization), which on a capable
// device renders through Dolby Atmos. This mixer does the part that belongs to the
// emulator: it places positional audio OBJECTS in 3D and produces (a) a channel bed for
// direct multichannel output and (b) the per-object positional metadata the platform
// spatializer consumes. It does NOT implement or claim Dolby's proprietary codec.
//
// Panning is constant-power: per object the speaker weights are normalized so the sum of
// squared gains is 1 (before distance attenuation), so moving a source around does not
// change its loudness. LFE is not panned into.

namespace lg::audio {

struct Vec3 { float x{0}, y{0}, z{0}; };   // x=right, y=up, z=forward (listener space)

struct AudioObject {
    uint32_t id{0};
    Vec3 pos;
    float gain{1.0f};
};

class SpatialAudioMixer {
public:
    static constexpr int kChannels = 12;   // 7.1.4: FL FR C LFE SL SR RL RR TFL TFR TRL TRR
    enum Channel { FL, FR, C, LFE, SL, SR, RL, RR, TFL, TFR, TRL, TRR };

    SpatialAudioMixer();

    uint32_t add_object(Vec3 pos, float gain = 1.0f);
    bool set_position(uint32_t id, Vec3 pos);
    bool set_gain(uint32_t id, float gain);
    bool remove_object(uint32_t id);
    size_t object_count() const { return objects_.size(); }
    const std::vector<AudioObject>& objects() const { return objects_; }

    // Constant-power per-speaker gains for a position (LFE stays 0). Used both for mixing
    // and as the metadata a platform spatializer would consume.
    std::array<float, kChannels> compute_gains(Vec3 pos, float gain = 1.0f) const;

    // Accumulate each source's mono block [frames] into the interleaved 12-ch [out_bed]
    // ([frames*kChannels] floats). out_bed is zeroed first. Sources pair an object id with
    // its mono sample pointer; unknown ids are skipped.
    void render(const std::vector<std::pair<uint32_t, const float*>>& sources,
                size_t frames, float* out_bed) const;

private:
    struct Speaker { Vec3 dir; bool lfe; };
    std::array<Speaker, kChannels> speakers_;
    std::vector<AudioObject> objects_;
    uint32_t next_id_{1};

    const AudioObject* find(uint32_t id) const;
    AudioObject* find(uint32_t id);
};

} // namespace lg::audio
