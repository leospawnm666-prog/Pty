#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <iostream>
#include "../gpu/vulkan_resource_backend.h"
int main(){
    lg::gpu::VulkanResourceBackend b;
    auto r=b.initialize(nullptr,nullptr); LG_CHECK(!r.ok());
    LG_CHECK(b.diagnostics()=="vkResources=OFF;buffers=0;images=0;memory=0");
    std::cout<<"vulkan resource backend host contract ok\n";
}
