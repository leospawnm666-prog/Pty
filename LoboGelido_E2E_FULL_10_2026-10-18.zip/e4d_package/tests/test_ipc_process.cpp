// P3.4: IPC end to end with real code.
//  H4 h4.nro = libnx 146c3d1's own IPC clients (sm.c, time.c, fs.c, sessionmgr.c, mutex.c,
//     condvar.c, svc.s, hosversion.c, diag.c; unmodified) + a minimal crt: smInitialize,
//     timeInitialize, timeGetCurrentTime, timeToCalendarTimeWithMyRule, fsInitialize (domain +
//     2 clones), fsOpenSdCardFileSystem (no SD: 0xFA202), fsExit, timeExit, smExit. On Block,
//     Block 16 KiB, JIT, JIT+fastmem, JIT+fastmem 16 KiB and on the plain interpreter driven
//     by hand through the dispatcher, the thread kernel and the IPC kernel, where every session
//     and handle must be gone at the end
//  N1 negative paths end to end: an unknown service defers (deadlock report names it) and
//     wakes when the host registers it; an unimplemented command is fatal with a dump
//  D1 diagnostics (ipc=, sessions=, domains=, last_ipc=)
#include "lg_check.h"
#include "vm_test_process.h"
#include "../cpu/guest_clock.h"
#include "../cpu/interpreter.h"
#include "../runtime/runtime_coordinator.h"
#include "../system/guest_thread_context.h"
#include "../system/hle/hle_services.h"
#include "../system/kipc.h"
#include "../system/kthread.h"
#include "../system/scheduler.h"
#include "../system/svc_dispatcher.h"
#include "../system/thread_manager.h"
#include "data/nro/h4/h4_fixture.h"
#include "data/nro/nro_fixtures.h"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace {
namespace fs = std::filesystem;
using lg::cpu::ExceptionKind;
using lg::runtime::RuntimeCoordinator;
using lg::runtime::State;
using lg::system::ProcessLayout;
constexpr uint64_t MiB = 1ull << 20;

template <size_t N> std::vector<uint8_t> bytes(const unsigned char (&a)[N]) { return {a, a + N}; }
std::string write_nro(const std::string& name, const std::vector<uint8_t>& b) {
    const auto p = fs::temp_directory_path() / ("lobo_p34_" + name + ".nro");
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(b.data()), long(b.size()));
    return p.string();
}
struct Engine { const char* name; bool force_interpreter; bool fastmem; size_t host_page; };
std::vector<Engine> engines() {
    std::vector<Engine> e = {{"Block", true, false, 0}, {"Block, 16 KiB host pages", true, false, 16384}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    e.push_back({"JIT", false, false, 0});
    e.push_back({"JIT + fastmem", false, true, 0});
    e.push_back({"JIT + fastmem, 16 KiB host pages", false, true, 16384});
#endif
    return e;
}
std::string run_to_end(RuntimeCoordinator& rt, int max_frames = 5'000'000) {
    for (int i = 0; i < max_frames && rt.state() == State::Running; ++i) {
        const auto r = rt.run_frame(rt.entry_point());
        if (!r.ok()) return r.error();
    }
    return {};
}
std::vector<uint64_t> words(const std::string& blob) {
    std::vector<uint64_t> w(blob.size() / 8);
    std::memcpy(w.data(), blob.data(), w.size() * 8);
    return w;
}
int64_t wall_now() {
    return std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}

void check_h4(const std::vector<uint64_t>& r, int64_t t0, int64_t t1, const char* engine) {
    LG_CHECK(r.size() == 12);
    if (r.size() != 12) { std::printf("  [%s] %zu words\n", engine, r.size()); return; }
    const auto show = [&](int i, uint64_t want) {
        if (r[static_cast<size_t>(i)] != want)
            std::printf("  [%s] results[%d] = 0x%llx, want 0x%llx\n", engine, i, (unsigned long long)r[static_cast<size_t>(i)],
                        (unsigned long long)want);
        LG_CHECK(r[static_cast<size_t>(i)] == want);
    };
    show(0, 0);                                            // smInitialize
    show(1, 0);                                            // timeInitialize
    show(2, 0);                                            // timeGetCurrentTime
    const auto now = static_cast<int64_t>(r[3]);
    if (now < t0 || now > t1) std::printf("  [%s] time %lld not in [%lld, %lld]\n", engine, (long long)now, (long long)t0, (long long)t1);
    LG_CHECK(now >= t0 && now <= t1);                      // D-P3.4-5: the host's wall clock
    show(4, 0);                                            // timeToCalendarTimeWithMyRule
    lg::system::hle::CivilTime c{};
    LG_CHECK(lg::system::hle::civil_from_posix(now, c));
    show(5, uint64_t(c.year) | (uint64_t(c.month) << 16) | (uint64_t(c.day) << 24) | (uint64_t(c.hour) << 32) |
                (uint64_t(c.minute) << 40) | (uint64_t(c.second) << 48));
    show(6, uint64_t(c.wday) | (uint64_t(c.yday) << 32));
    show(7, 0x435455);                                     // "UTC"
    show(8, 0);                                            // offset 0, no DST
    show(9, 0);                                            // fsInitialize
    show(10, lg::system::hle::result::FsSdCardNotPresent); // fsOpenSdCardFileSystem
    show(11, 0x4834);
}

void h4_engines() {
    std::printf("[H4] libnx's real IPC clients against Lobo, on every engine\n");
    const std::string path = write_nro("h4", bytes(nro_fixtures::h4));
    for (const auto& e : engines()) {
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            const int64_t t0 = wall_now();
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            LG_CHECK(rt.ipc_for_testing().active() && rt.ipc_for_testing().session_count() == 0);
            const auto start = std::chrono::steady_clock::now();
            const auto err = run_to_end(rt);
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            if (!err.empty() || rt.state() != State::Stopped) std::printf("  %s | %s\n", err.c_str(), rt.diagnostics().c_str());
            LG_CHECK(err.empty() && rt.state() == State::Stopped && rt.guest_exit().has_code && rt.guest_exit().code == 0);
            check_h4(words(rt.guest_log()), t0, wall_now() + 1, e.name);
            std::printf("  %-34s %6.1f ms  ConnectToNamedPort=%llu SendSyncRequest=%llu CloseHandle=%llu\n", e.name, ms,
                        (unsigned long long)rt.svc_calls(0x1F), (unsigned long long)rt.svc_calls(0x21),
                        (unsigned long long)rt.svc_calls(0x16));
            LG_CHECK(rt.svc_calls(0x1F) == 1);
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

/** The plain interpreter + dispatcher + KernelThreads + KernelIpc, driven by hand. */
struct Plain {
    vm_test::Process p;
    lg::cpu::GuestClock clock;
    lg::cpu::Interpreter cpu{p.as, p.mmu};
    lg::system::Scheduler sched;
    lg::system::ThreadManager tm{sched};
    lg::system::GuestThreadContextManager ctxs;
    lg::system::SvcDispatcher d{p.as, p.mmu};
    lg::system::KernelThreads k;
    lg::system::KernelIpc ipc;
    uint64_t main{};
    uint32_t main_handle{};
    explicit Plain(std::vector<uint8_t> image) : p(64 * MiB, std::move(image)) {
        cpu.set_guest_clock(&clock);
        lg::system::KernelThreadsConfig c{};
        c.process_id = 1;
        c.priority_mask = lg::system::SvcDispatcher::kPriorityMask;
        c.tls_region_base = ProcessLayout::kConfigVa + 0x20000;
        c.tls_region_end = ProcessLayout::kStackRegion + ProcessLayout::kStackRegionSize;
        c.clock = &clock;
        c.handles = &d.handles();
        c.memory = &d.guest_memory();
        c.vm = &p.vm;
        c.threads = &tm;
        c.contexts = &ctxs;
        c.host.spawn = [this](uint64_t pc, uint64_t sp) -> uint64_t {
            const auto id = tm.create("guest", 1, [](uint64_t) {});
            return id && ctxs.create(id, pc, sp) ? id : 0;
        };
        LG_CHECK(k.begin(c));
        lg::system::KernelIpcConfig ic{};
        ic.process_id = 1;
        ic.clock = &clock;
        ic.handles = &d.handles();
        ic.memory = &d.guest_memory();
        ic.vm = &p.vm;
        ic.kthreads = &k;
        ic.wall_clock_base = wall_now();
        LG_CHECK(ipc.begin(ic) && lg::system::hle::register_boot_services(ipc));
        d.begin_session({1, 0, p.l.exit_stub_va, &clock, {}, &p.vm, &k, &ipc});
        main = tm.create("main", 1, [](uint64_t) {});
        auto* m = ctxs.create(main, p.l.code_va, p.l.stack_top_va);
        main_handle = *d.handles().add({lg::system::KObjectType::Thread, main});
        LG_CHECK(k.register_main_thread(main, main_handle, 44, p.l.tls_va));
        const uint64_t cfg[9] = {1, main_handle, 0, 16, 0x00050100, 0, 0, 0, 0};   // MainThreadHandle, HosVersion, EndOfList
        LG_CHECK(d.guest_memory().write(p.l.config_va, cfg, sizeof cfg));
        m->x[0] = p.l.config_va;
        m->x[1] = ~0ull;
        m->x[30] = p.l.exit_stub_va;
        m->tpidrro_el0 = p.l.tls_va;
    }
    /** Runs until ExitProcess; "" or the fatal message. */
    std::string run(uint64_t max_turns = 5'000'000) {
        for (uint64_t turns = 0; turns < max_turns;) {
            k.update(clock.ticks());
            bool ran = false;
            for (int core = 0; core < lg::system::kNumVirtualCores; ++core) {
                lg::system::KThread* t = k.top(core);
                if (!t) continue;
                ran = true;
                auto& s = *ctxs.get(t->id);
                k.begin_turn(core, t, clock.ticks());
                for (int i = 0; i < 97; ++i) {
                    if (cpu.step(s)) continue;
                    if (s.exception.kind != ExceptionKind::Svc) return "fault";
                    const auto o = d.handle(t->id, s);
                    if (o.kind == lg::system::SvcOutcome::Kind::Fatal) return o.message;
                    if (o.kind == lg::system::SvcOutcome::Kind::ExitProcess) { k.end_turn(clock.ticks()); return {}; }
                    break;
                }
                k.end_turn(clock.ticks());
                k.update(clock.ticks());
                ++turns;
                clock.advance(3);
                const std::string inv = ipc.check_invariants();
                if (!inv.empty()) return "ipc invariant: " + inv;
            }
            if (!ran) {
                if (!k.next_deadline()) return "deadlock: " + k.describe_waits();
                clock.advance(k.next_deadline() - clock.ticks());
            }
        }
        return "too many turns";
    }
};

void h4_plain_interpreter() {
    std::printf("[H4] plain interpreter + dispatcher + KernelThreads + KernelIpc\n");
    const int64_t t0 = wall_now();
    Plain pl(bytes(nro_fixtures::h4));
    const size_t handles0 = pl.d.handles().size();
    const std::string err = pl.run();
    if (!err.empty()) std::printf("  %s\n", err.c_str());
    LG_CHECK(err.empty() && pl.d.exit().has_code && pl.d.exit().code == 0);
    check_h4(words(pl.d.log().contents()), t0, wall_now() + 1, "plain interpreter");
    // Every session libnx opened (sm:, time:u + 5 interfaces, fsp-srv + 2 clones) was closed.
    LG_CHECK(pl.ipc.session_count() == 0 && pl.d.handles().size() == handles0);
    LG_CHECK(pl.ipc.check_invariants().empty() && pl.k.check_invariants().empty());
    std::printf("  %llu requests, last %s\n", (unsigned long long)pl.ipc.request_count(), pl.ipc.last_request().c_str());
    LG_CHECK(pl.ipc.request_count() >= 20);
}
class Probe final : public lg::system::hle::HleService {
public:
    Probe() : HleService("lobo:x") {}
};

void n1_negative() {
    std::printf("[N1] deferral and unimplemented commands, end to end\n");
    const std::string defer = write_nro("ipc_defer", bytes(nro_fixtures::ipc_defer));
    for (const auto& e : engines()) {
        // (a) nobody registers "lobo:x": the guest kernel reports a deadlock that names it
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            LG_CHECK(rt.prepare(defer).ok() && rt.start().ok());
            const auto err = run_to_end(rt);
            const bool ok = rt.state() == State::Error &&
                            err.find("guest deadlock: no runnable thread and no pending timeout [1:ipc@sm::GetServiceHandle(\"lobo:x\")]") == 0;
            if (!ok) std::printf("  [%s] %s\n", e.name, err.c_str());
            LG_CHECK(ok);
        }
        // (b) the host registers it while the thread waits: the request completes and the guest exits
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            LG_CHECK(rt.prepare(defer).ok() && rt.start().ok());
            for (int i = 0; i < 100000 && rt.ipc_for_testing().deferred_count() == 0; ++i) LG_CHECK(rt.run_frame(rt.entry_point()).ok());
            LG_CHECK(rt.ipc_for_testing().deferred_count() == 1 && rt.kthreads_for_testing().waiting_count() == 1);
            const std::string d = rt.diagnostics();
            LG_CHECK(d.find(" waits=1 ") != std::string::npos && d.find(" last_ipc=sm::GetServiceHandle") != std::string::npos);
            LG_CHECK(d.find(" ipc=2 sessions=1 domains=0 ") != std::string::npos);
            LG_CHECK(rt.ipc_for_testing().register_service("lobo:x", [] { return std::make_shared<Probe>(); }));
            const auto err = run_to_end(rt);
            if (!err.empty()) std::printf("  [%s] %s\n", e.name, err.c_str());
            LG_CHECK(err.empty() && rt.state() == State::Stopped && rt.guest_log() == "woken\n" && rt.guest_exit().code == 0);
        }
    }
    // An unimplemented command: fatal, with the service, the command and the message.
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(true);
    LG_CHECK(rt.prepare(write_nro("ipc_unimpl", bytes(nro_fixtures::ipc_unimpl))).ok() && rt.start().ok());
    const auto err = run_to_end(rt);
    LG_CHECK(rt.state() == State::Error && err.find("IPC no implementada: sm: cmd 2 [00000004 00000008 ") == 0);
    LG_CHECK(rt.last_guest_fault().kind == ExceptionKind::Svc && rt.last_guest_fault().syndrome == 0x21);
    const auto marker = rt.debug_read_guest64(rt.process_layout()->code_va + nro_fixtures::ipc_unimpl_after_fault_offset);
    LG_CHECK(marker.has_value() && *marker == 0);
}

void d1_diagnostics() {
    std::printf("[D1] IPC diagnostics\n");
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(true);
    LG_CHECK(rt.prepare(write_nro("h4_d1", bytes(nro_fixtures::h4))).ok());
    LG_CHECK(rt.diagnostics().find(" ipc=0 sessions=0 domains=0 last_ipc=none ") != std::string::npos);
    // synthetic images have no guest IPC: no fields
    RuntimeCoordinator syn;
    syn.set_guest_memory_budget(64 * MiB);
    LG_CHECK(syn.prepare().ok() && syn.diagnostics().find(" ipc=") == std::string::npos);
}
} // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    h4_engines();
    h4_plain_interpreter();
    n1_negative();
    d1_diagnostics();
    std::puts("ipc process ok");
    return 0;
}
