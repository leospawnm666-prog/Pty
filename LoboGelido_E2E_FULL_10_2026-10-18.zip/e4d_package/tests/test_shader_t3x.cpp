// P4.4 T3-X (P4_4_DISENO.md §5.2): the differential corpus of the instructions P4.4 adds,
// tests/data/shader/xcorpus (double precision, votes, PIXLD, gradients of cube and 3D textures,
// interpolateAtOffset), with the T3-T runner. Oracle: lavapipe (SwiftShader has no shaderFloat64;
// it runs the graphics pipelines, f04_ipaoff_mix included, which lavapipe gets wrong).
// Usage: test_shader_t3x <libvulkan.so> [name-filter]   (VK_ICD_FILENAMES: the lavapipe ICD)
#define LG_T3T_CNS t3xfx
#define LG_T3T_GNS t3xgfx
#define LG_T3T_CHEADER "shader/t3x_fixtures.h"
#define LG_T3T_GHEADER "shader/t3xg_fixtures.h"
#define LG_T3T_LABEL "T3-X"
#define LG_T3T_WHAT "doble precisión, votes, PIXLD, gradientes, IPA.OFFSET"
#include "test_shader_t3t.cpp"
