#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <cstdint>
#include "../memory/mmu.h"
#include "../memory/address_space.h"
#include "../cpu/interpreter.h"
using namespace lg;
int main(){
    memory::Mmu m;
    const auto generation0 = m.generation();
    LG_CHECK(m.map(0x1000,0x8000,0x2000,memory::Read|memory::Write|memory::Execute));
    LG_CHECK(m.generation() != generation0);
    auto a=m.translate(0x1abc,false); LG_CHECK(a.ok() && a.value().physical==0x8abc);
    auto b=m.translate(0x1004,true); LG_CHECK(b.ok());
    LG_CHECK(m.translate(0x1004,true).value().permissions&memory::Write);
    LG_CHECK(m.translate(0x1004,true,true).ok());
    LG_CHECK(!m.translate(0x3000,false).ok());
    LG_CHECK(m.translate(0x1004,false,true).ok());
    LG_CHECK(m.map(0x4000,0xA000,0x1000,memory::Read));
    LG_CHECK(m.translate(0x4ABC,false).value().physical == 0xAABC);
    LG_CHECK(!m.translate(0x4ABC,true).ok());
    LG_CHECK(m.unmap(0x4000,0x1000));
    LG_CHECK(!m.translate(0x4ABC,false).ok());
    memory::AddressSpace mem; LG_CHECK(mem.map(0x8000,0x2000));
    cpu::Interpreter cpu(mem,m); cpu::CpuState st{}; st.pc=0x1000;
    mem.write32(0x8000,0xD2800020u); // MOV X0, #1
    LG_CHECK(cpu.step(st)); // MMU translates VA 0x1000 to the host-backed 0x8000 page.
    LG_CHECK(st.x[0] == 1);
    const auto generation1 = m.generation();
    LG_CHECK(m.unmap(0x1000,0x2000));
    LG_CHECK(m.generation() != generation1);
    LG_CHECK(!m.translate(0x1000,false).ok());

    // Decode-cache coherence: non-strict mode must discard a cached instruction
    // after guest code is rewritten.
    memory::AddressSpace code_mem; LG_CHECK(code_mem.map(0x1000, 0x1000));
    code_mem.write32(0x1000, 0xD2800020u); // mov x0,#1
    cpu::Interpreter cached(code_mem); cached.set_strict_code_validation(false);
    cpu::CpuState cs{}; cs.pc = 0x1000; LG_CHECK(cached.step(cs)); LG_CHECK(cs.x[0] == 1);
    cs.pc = 0x1000; code_mem.write32(0x1000, 0xD2800040u); // mov x0,#2
    LG_CHECK(cached.step(cs)); LG_CHECK(cs.x[0] == 2);
    return 0;
}
