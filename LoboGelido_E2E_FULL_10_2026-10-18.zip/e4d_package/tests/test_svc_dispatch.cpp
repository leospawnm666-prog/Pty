// P3.1: the system-call dispatcher in isolation (no CPU engine).
//  U1 the table: 0xC0 entries named after libnx, exactly the P3.1 set implemented, hints
//     generated from it
//  U2 handle table: format, generations (a closed handle never comes back), capacity,
//     pseudo-handles, clear
//  U3 guest log: 64 KiB ring, byte count, the escaped last line
//  U4 Result / Break decoding
//  U5 the engine contract: Continue -> pc + 4, no exception, not halted, reservation cleared;
//     terminal/fatal outcomes leave the context alone; D3 (never an invented success)
//  U6 guest memory: user permission, all-or-nothing ranges, wrap-around; OutputDebugString
//     limits (64 KiB, [truncated], len 0, bad pointer) and the log sink
//  U7 GetInfo/GetProcessId/CloseHandle rules (Horizon kernel semantics)
//  U8 ExitProcess: code from the exit stub, none otherwise
//  F1 fuzzing (R4): 10^5 SVCs with random numbers and hostile arguments; run under ASan/UBSan
#include "lg_check.h"
#include "../cpu/guest_clock.h"
#include "../system/handle_table.h"
#include "../system/svc_dispatcher.h"
#include "../system/svc_table.h"

#include <cstdio>
#include <cstring>
#include <random>
#include <set>
#include <string>
#include <vector>

namespace {
using namespace lg::system;
using lg::cpu::CpuState;
using lg::cpu::ExceptionKind;
using Kind = SvcOutcome::Kind;

constexpr uint64_t kUserRw = 0x100000;     // 2 pages RW + User
constexpr uint64_t kUserRo = 0x102000;     // 1 page R + User
constexpr uint64_t kKernel = 0x103000;     // 1 page RW, no User bit
constexpr uint64_t kBig = 0x200000;        // 80 KiB RW + User (OutputDebugString limit)
constexpr uint64_t kBigSize = 80 * 1024;
constexpr uint64_t kStub = 0x300000;

struct Rig {
    lg::memory::AddressSpace as;
    lg::memory::Mmu mmu;
    lg::cpu::GuestClock clock;
    SvcDispatcher d{as, mmu};
    Rig() {
        using namespace lg::memory;
        LG_CHECK(as.map(kUserRw, 0x4000) && as.map(kBig, kBigSize) && as.map(kStub, 0x1000));
        LG_CHECK(mmu.map(kUserRw, kUserRw, 0x2000, Read | Write | User));
        LG_CHECK(mmu.map(kUserRo, kUserRo, 0x1000, Read | User));
        LG_CHECK(mmu.map(kKernel, kKernel, 0x1000, Read | Write));
        LG_CHECK(mmu.map(kBig, kBig, kBigSize, Read | Write | User));
        LG_CHECK(mmu.map(kStub, kStub, 0x1000, Read | Execute | User));
        d.begin_session({77, 0x0100000000001234ull, kStub, &clock, {11, 22, 33, 44}});
    }
    SvcOutcome call(CpuState& s, uint32_t id, uint64_t pc = 0x8000100, uint64_t thread = 1) {
        s.exception = {};
        s.exception.kind = ExceptionKind::Svc;
        s.exception.address = pc;
        s.exception.syndrome = id;
        s.pc = pc;
        return d.handle(thread, s);
    }
    uint32_t w0(const CpuState& s) const { return static_cast<uint32_t>(s.x[0]); }
};

void u1_table() {
    std::printf("[U1] SVC table\n");
    const auto& t = svc_table();
    LG_CHECK(t.size() == 0xC0 && kSvcCount == 0xC0);
    std::set<uint32_t> implemented;
    for (uint32_t i = 0; i < t.size(); ++i) {
        LG_CHECK(t[i].id == i && t[i].name && *t[i].name);
        LG_CHECK(std::strncmp(t[i].name, "svc", 3) != 0);            // libnx name without the prefix
        if (t[i].handler) implemented.insert(i);
    }
    // P3.1 + P3.2 (memory: 0x01-0x06, 0x2A, 0x2B) + P3.3 (threads and synchronization) + P3.4
    // (IPC), then P6.0 (P6_0_DISENO.md): EVERY assigned SVC number has a handler; only the
    // Unassigned numbers stay without one (68 of 0xC0; 124 assigned).
    const std::set<uint32_t> unassigned = [] {
        std::set<uint32_t> u{0x00, 0x38, 0x3B, 0x3E, 0x3F, 0x6E};
        for (uint32_t i = 0x80; i <= 0x8F; ++i) u.insert(i);
        for (uint32_t i = 0x92; i <= 0xBF; ++i) u.insert(i);
        return u;
    }();
    std::set<uint32_t> expect_impl;
    for (uint32_t i = 0; i < 0xC0; ++i) if (!unassigned.count(i)) expect_impl.insert(i);
    for (uint32_t i : expect_impl) if (!implemented.count(i)) std::printf("  sin handler: 0x%02X\n", i);
    for (uint32_t i : implemented) if (!expect_impl.count(i)) std::printf("  handler de más: 0x%02X\n", i);
    LG_CHECK(implemented == expect_impl && implemented.size() == 124);
    for (uint32_t i : unassigned) LG_CHECK(std::strncmp(t[i].name, "Unassigned", 10) == 0);
    // the P3 set is still there (Regla de Oro)
    for (uint32_t id : {0x01u, 0x07u, 0x16u, 0x1Eu, 0x21u, 0x29u, 0x45u}) LG_CHECK(implemented.count(id));
    LG_CHECK(std::string(t[0x01].name) == "SetHeapSize" && std::string(t[0x27].name) == "OutputDebugString");
    LG_CHECK(std::string(t[0x2C].name) == "MapPhysicalMemory" && std::string(t[0x7F].name) == "CallSecureMonitor");
    LG_CHECK(std::string(t[0x00].name) == "Unassigned00" && t[0x00].klass == SvcClass::Unimplemented);
    LG_CHECK(t[0x07].klass == SvcClass::Terminal && t[0x0A].klass == SvcClass::Terminal);
    LG_CHECK(t[0x18].klass == SvcClass::Blocking && t[0x21].klass == SvcClass::Blocking);
    LG_CHECK(t[0x27].klass == SvcClass::Neutral && t[0x29].klass == SvcClass::Immediate);
    LG_CHECK(svc_entry(0xBF) != nullptr && svc_entry(0xC0) == nullptr && svc_entry(0xFFFF) == nullptr);
    uint64_t expect0 = 0, expect1 = 0, expect2 = 0;
    for (uint32_t id : implemented) (id < 64 ? expect0 : id < 128 ? expect1 : expect2) |= 1ull << (id % 64);
    LG_CHECK(expect2 == 0x30000ull);   // 0x90, 0x91
    LG_CHECK(syscall_hint_word(0) == expect0 && syscall_hint_word(1) == expect1 && syscall_hint_word(2) == 0x30000ull &&
             syscall_hint_word(3) == 0);
    LG_CHECK(expect0 == ~(1ull | (1ull << 0x38) | (1ull << 0x3B) | (1ull << 0x3E) | (1ull << 0x3F)));   // P6.0
    LG_CHECK(expect1 == ~(1ull << (0x6E - 64)));   // ids 0x40-0x7F: all but 0x6E
}

void u2_handles() {
    std::printf("[U2] handle table\n");
    HandleTable h;
    const auto a = h.add({KObjectType::Thread, 5});
    const auto b = h.add({KObjectType::Process, 9});
    LG_CHECK(a && b && *a != *b && *a != 0 && *a < 0xFFFF8000u && (*a & HandleTable::kIndexMask) == 1);
    LG_CHECK(h.size() == 2 && h.get(*a) && h.get(*a)->id == 5 && h.get(*b)->type == KObjectType::Process);
    LG_CHECK(!h.add({KObjectType::None, 1}));
    // Pseudo-handles resolve but are not in the table and cannot be closed.
    LG_CHECK(h.resolve(HandleTable::kCurrentThread, 3, 4)->type == KObjectType::Thread && h.resolve(HandleTable::kCurrentThread, 3, 4)->id == 3);
    LG_CHECK(h.resolve(HandleTable::kCurrentProcess, 3, 4)->type == KObjectType::Process && h.resolve(HandleTable::kCurrentProcess, 3, 4)->id == 4);
    LG_CHECK(!h.get(HandleTable::kCurrentThread) && !h.close(HandleTable::kCurrentThread) && !h.close(HandleTable::kCurrentProcess));
    LG_CHECK(!h.get(0) && !h.close(0) && !h.resolve(0, 3, 4));
    // Close: the handle dies; its slot is reused with a new generation, the old value stays dead.
    LG_CHECK(h.close(*a) && !h.get(*a) && !h.close(*a) && h.size() == 1);
    const auto c = h.add({KObjectType::Thread, 6});
    LG_CHECK(c && (*c & HandleTable::kIndexMask) == (*a & HandleTable::kIndexMask) && *c != *a);
    LG_CHECK(!h.get(*a) && h.get(*c)->id == 6);
    // Garbage never resolves.
    for (uint32_t g : {0x40000001u, 0x80000001u, (*c & HandleTable::kIndexMask), *c ^ (1u << 16), 0x7FFFu | (1u << 15)})
        LG_CHECK(!h.get(g));
    // Capacity 1024 (OutOfHandles after that).
    HandleTable full;
    std::set<uint32_t> seen;
    for (uint32_t i = 0; i < HandleTable::kCapacity; ++i) {
        const auto x = full.add({KObjectType::Thread, i});
        LG_CHECK(x.has_value());
        seen.insert(*x);
    }
    LG_CHECK(seen.size() == HandleTable::kCapacity && !full.add({KObjectType::Thread, 1}));
    // One slot recycled 70000 times: the generation wraps without ever being 0, and no value
    // repeats within a generation cycle.
    HandleTable w;
    std::set<uint32_t> values;
    uint32_t prev = 0;
    for (int i = 0; i < 70000; ++i) {
        const auto x = w.add({KObjectType::Thread, 1});
        LG_CHECK(x && ((*x >> HandleTable::kIndexBits) & HandleTable::kGenerationMask) != 0 && *x != prev);
        if (i < int(HandleTable::kGenerationMask)) LG_CHECK(values.insert(*x).second);
        prev = *x;
        LG_CHECK(w.close(*x));
    }
    // clear(): every old handle dies.
    const auto d = full.get(*seen.begin());
    LG_CHECK(d != nullptr);
    full.clear();
    LG_CHECK(full.size() == 0);
    for (uint32_t v : seen) LG_CHECK(!full.get(v));
    LG_CHECK(full.add({KObjectType::Thread, 1}).has_value());
}

void u3_log() {
    std::printf("[U3] guest log\n");
    GuestLog log;
    LG_CHECK(log.last_line().empty() && log.total_bytes() == 0);
    log.append("uno\n");
    log.append("dos\n\n");
    LG_CHECK(log.last_line() == "dos" && log.total_bytes() == 9);
    log.append("con \"comillas\" y \\ y \x01\xC3\xB1");
    LG_CHECK(log.last_line() == "con \\\"comillas\\\" y \\\\ y \\x01\\xC3\\xB1");
    log.append(std::string(200, 'a'));
    const auto l = log.last_line();
    LG_CHECK(l.size() == 80 && l.substr(77) == "...");
    // Ring: the last 64 KiB stay, byte exact.
    GuestLog ring;
    std::string all;
    for (int i = 0; i < 10000; ++i) { const std::string s = "linea " + std::to_string(i) + "\n"; ring.append(s); all += s; }
    LG_CHECK(ring.total_bytes() == all.size() && all.size() > GuestLog::kCapacity);
    LG_CHECK(ring.contents() == all.substr(all.size() - GuestLog::kCapacity));
    ring.append(std::string(GuestLog::kCapacity + 5, 'z'));
    LG_CHECK(ring.contents() == std::string(GuestLog::kCapacity, 'z'));
    ring.clear();
    LG_CHECK(ring.contents().empty() && ring.total_bytes() == 0);
}

void u4_decoding() {
    std::printf("[U4] Result / Break decoding\n");
    LG_CHECK(SvcDispatcher::result_text(0x3D59) == "2345-0030");
    LG_CHECK(SvcDispatcher::result_text(kresult::InvalidHandle) == "2001-0114");
    LG_CHECK(SvcDispatcher::result_text(0) == "2000-0000");
    LG_CHECK(std::string(SvcDispatcher::break_reason_name(0)) == "Panic");
    LG_CHECK(std::string(SvcDispatcher::break_reason_name(0x80000007u)) == "CppException");
    LG_CHECK(SvcDispatcher::break_reason_name(8) == nullptr);
    LG_CHECK(kresult::InvalidHandle == (1u | (114u << 9)) && kresult::InvalidPointer == (1u | (115u << 9)) &&
             kresult::InvalidCombination == (1u | (116u << 9)) && kresult::InvalidEnumValue == (1u | (120u << 9)) &&
             kresult::OutOfHandles == (1u | (105u << 9)) && kresult::OutOfRange == (1u | (119u << 9)));
}

void u5_contract() {
    std::printf("[U5] engine contract\n");
    Rig r;
    CpuState s{};
    for (int i = 0; i < 31; ++i) s.x[i] = 0x1000 + i;
    s.halted = true;
    s.reservation_valid = true;
    s.x[0] = kUserRw; s.x[1] = 0;                       // OutputDebugString(ptr, 0)
    const auto out = r.call(s, 0x27, 0x8000100);
    LG_CHECK(out.kind == Kind::Continue && s.pc == 0x8000104 && s.exception.kind == ExceptionKind::None);
    LG_CHECK(!s.halted && !s.reservation_valid && s.x[0] == 0);
    for (int i = 2; i < 31; ++i) LG_CHECK(s.x[i] == 0x1000u + i);   // nothing else moved
    LG_CHECK(r.d.calls(0x27) == 1 && r.d.total_calls() == 1 && r.d.last().valid && r.d.last().id == 0x27 &&
             r.d.last().pc == 0x8000100 && r.d.last().x0 == kUserRw);
    // D3: every id without a handler is fatal and names the call; the context is untouched.
    for (uint32_t id = 0; id < 0xC0; ++id) {
        if (svc_implemented(id)) continue;
        CpuState z{};
        const auto o = r.call(z, id, 0x8000200);
        LG_CHECK(o.kind == Kind::Fatal && o.message.find("no implementada @0x8000200") != std::string::npos);
        LG_CHECK(o.message.find(svc_entry(id)->name) != std::string::npos);
        LG_CHECK(z.pc == 0x8000200 && z.exception.kind == ExceptionKind::Svc && z.x[0] == 0);
    }
    CpuState z{};
    auto o = r.call(z, 0x38, 0x8000300);   // P6.0: only the unassigned numbers are left without a handler
    LG_CHECK(o.message == "SVC 0x38 (Unassigned38) no implementada @0x8000300");
    for (uint32_t id : {0xC0u, 0xFFu, 0xFFFFu}) {
        o = r.call(z, id, 0x8000400);
        LG_CHECK(o.kind == Kind::Fatal && o.message.find("inválida @0x8000400") != std::string::npos);
    }
    LG_CHECK(r.d.invalid_calls() == 3);
    // Break: NotificationOnly goes on; a real one is fatal and decoded.
    CpuState b{};
    b.x[0] = 0x80000002u;
    LG_CHECK(r.call(b, 0x26).kind == Kind::Continue && b.x[0] == 0 && r.d.break_notifications() == 1);
    const uint32_t rc = 0x3D59;
    LG_CHECK(r.d.guest_memory().write(kUserRw + 0x10, &rc, 4));
    b = {}; b.x[0] = 0; b.x[1] = kUserRw + 0x10; b.x[2] = 4;
    o = r.call(b, 0x26, 0x8000500);
    LG_CHECK(o.kind == Kind::Fatal && o.message == "guest_abort=Panic result=2345-0030 (0x3d59) @0x8000500");
    LG_CHECK(b.pc == 0x8000500 && b.exception.kind == ExceptionKind::Svc);
    b = {}; b.x[0] = 2; b.x[1] = 0x1234; b.x[2] = 8;
    o = r.call(b, 0x26, 0x8000600);
    LG_CHECK(o.message == "guest_abort=User addr=0x1234 size=0x8 @0x8000600");
    b = {}; b.x[0] = 1; b.x[1] = 0x10; b.x[2] = 4;          // unreadable Result pointer
    LG_CHECK(r.call(b, 0x26).message.find("guest_abort=Assert addr=0x10 size=0x4") == 0);
    b = {}; b.x[0] = 0x55;
    LG_CHECK(r.call(b, 0x26).message.find("guest_abort=reason_0x55") == 0);
}

void u6_memory_and_debug_string() {
    std::printf("[U6] guest memory and OutputDebugString\n");
    Rig r;
    auto& gm = r.d.guest_memory();
    uint8_t buf[64] = {};
    LG_CHECK(gm.accessible(kUserRw, 0x2000, true) && gm.accessible(kUserRo, 0x1000, false));
    LG_CHECK(!gm.accessible(kUserRo, 1, true));                       // read-only
    LG_CHECK(!gm.accessible(kKernel, 1, false));                      // no User bit
    LG_CHECK(!gm.accessible(0x10, 1, false) && gm.accessible(0x10, 0, false));
    LG_CHECK(!gm.accessible(~0ull - 4, 16, false));                   // wraps
    LG_CHECK(!gm.read(kKernel, buf, 4));
    // All-or-nothing across a page boundary: RW page then RO page -> nothing is written.
    const std::string msg(32, 'Q');
    LG_CHECK(!gm.write(kUserRo - 16, msg.data(), msg.size()));
    LG_CHECK(gm.read(kUserRo - 16, buf, 16) && std::memcmp(buf, std::string(16, '\0').data(), 16) == 0);
    LG_CHECK(gm.write(kUserRw + 0xFF0, msg.data(), msg.size()));      // straddles two RW pages
    LG_CHECK(gm.read(kUserRw + 0xFF0, buf, 32) && std::memcmp(buf, msg.data(), 32) == 0);
    LG_CHECK(gm.read32(kUserRw + 0xFF0) == 0x51515151u && !gm.read32(kKernel).has_value());

    std::vector<std::string> sunk;
    r.d.set_log_sink([&](const std::string& t) { sunk.push_back(t); });
    const char text[] = "hola\n";
    LG_CHECK(gm.write(kUserRw, text, 5));
    CpuState s{};
    s.x[0] = kUserRw; s.x[1] = 5;
    LG_CHECK(r.call(s, 0x27).kind == Kind::Continue && r.w0(s) == kresult::Success);
    LG_CHECK(r.d.log().contents() == "hola\n" && sunk.size() == 1 && sunk[0] == "hola\n");
    for (const auto& [ptr, len] : {std::pair<uint64_t, uint64_t>{0x10, 4}, {kKernel, 4}, {kUserRw, 0x4000},
                                   {~0ull - 8, 64}, {kUserRw, ~0ull}}) {
        s = {}; s.x[0] = ptr; s.x[1] = len;
        LG_CHECK(r.call(s, 0x27).kind == Kind::Continue && r.w0(s) == kresult::InvalidPointer);
    }
    s = {}; s.x[0] = 0x10; s.x[1] = 0;
    LG_CHECK(r.call(s, 0x27).kind == Kind::Continue && r.w0(s) == kresult::Success);   // len 0: nothing to check
    LG_CHECK(r.d.log().contents() == "hola\n" && sunk.size() == 1);
    // 64 KiB limit: 80 KiB readable -> the first 64 KiB + " [truncated]".
    std::string big(kBigSize, 'b');
    big[0] = 'B';
    LG_CHECK(gm.write(kBig, big.data(), big.size()));
    s = {}; s.x[0] = kBig; s.x[1] = kBigSize;
    LG_CHECK(r.call(s, 0x27).kind == Kind::Continue && r.w0(s) == kresult::Success);
    LG_CHECK(sunk.size() == 2 && sunk[1].size() == SvcDispatcher::kMaxDebugString + 12 && sunk[1][0] == 'B' &&
             sunk[1].substr(SvcDispatcher::kMaxDebugString) == " [truncated]");
    LG_CHECK(r.d.log().total_bytes() == 5 + SvcDispatcher::kMaxDebugString + 12);
    LG_CHECK(r.d.log().contents().size() == GuestLog::kCapacity);
    // A length past the mapping but a readable first 64 KiB: logged (only what is copied is validated).
    s = {}; s.x[0] = kBig; s.x[1] = kBigSize + 0x100000;
    LG_CHECK(r.call(s, 0x27).kind == Kind::Continue && r.w0(s) == kresult::Success);
}

void u7_info_rules() {
    std::printf("[U7] GetInfo / GetProcessId / CloseHandle\n");
    Rig r;
    const auto main = r.d.handles().add({KObjectType::Thread, 1});
    const auto proc = r.d.handles().add({KObjectType::Process, 77});
    LG_CHECK(main && proc);
    auto info = [&](uint32_t id0, uint32_t handle, uint64_t id1, uint64_t& value) {
        CpuState s{};
        s.x[0] = 0xDEAD; s.x[1] = id0; s.x[2] = handle; s.x[3] = id1;
        LG_CHECK(r.call(s, 0x29).kind == Kind::Continue);
        value = s.x[1];
        return r.w0(s);
    };
    uint64_t v = 0;
    const uint32_t cur = HandleTable::kCurrentProcess;
    LG_CHECK(info(0, cur, 0, v) == 0 && v == 0x7);
    LG_CHECK(info(0, *proc, 0, v) == 0 && v == 0x7);                   // a real process handle too
    LG_CHECK(info(1, cur, 0, v) == 0 && v == 0x0FFFFFFFF0000000ull);   // priorities 28..59
    LG_CHECK(info(18, cur, 0, v) == 0 && v == 0x0100000000001234ull);
    LG_CHECK(info(0, cur, 1, v) == kresult::InvalidCombination && v == 0);
    LG_CHECK(info(0, 0, 0, v) == kresult::InvalidHandle);
    LG_CHECK(info(0, HandleTable::kCurrentThread, 0, v) == kresult::InvalidHandle);
    LG_CHECK(info(0, *main, 0, v) == kresult::InvalidHandle);
    LG_CHECK(info(8, 0, 0, v) == 0 && v == 0);
    LG_CHECK(info(8, cur, 0, v) == kresult::InvalidHandle && info(8, 0, 1, v) == kresult::InvalidCombination);
    for (uint64_t i = 0; i < 4; ++i) LG_CHECK(info(11, 0, i, v) == 0 && v == (i + 1) * 11);
    LG_CHECK(info(11, 0, 4, v) == kresult::InvalidCombination && info(11, cur, 0, v) == kresult::InvalidHandle);
    for (uint32_t id0 : {2u, 3u, 4u, 5u, 6u, 7u, 9u, 10u, 12u, 20u, 21u, 28u, 0xF0000002u})
        LG_CHECK(info(id0, cur, 0, v) == kresult::InvalidEnumValue && v == 0);
    // GetProcessId: process -> its id, thread -> its owner's id (Horizon), otherwise InvalidHandle.
    auto pid = [&](uint32_t handle, uint64_t& out) {
        CpuState s{};
        s.x[1] = handle;
        LG_CHECK(r.call(s, 0x24).kind == Kind::Continue);
        out = s.x[1];
        return r.w0(s);
    };
    LG_CHECK(pid(cur, v) == 0 && v == 77 && pid(HandleTable::kCurrentThread, v) == 0 && v == 77);
    LG_CHECK(pid(*main, v) == 0 && v == 77 && pid(*proc, v) == 0 && v == 77);
    LG_CHECK(pid(0, v) == kresult::InvalidHandle && pid(0x1234, v) == kresult::InvalidHandle && v == 0);
    // CloseHandle.
    auto close = [&](uint32_t handle) { CpuState s{}; s.x[0] = handle; r.call(s, 0x16); return r.w0(s); };
    LG_CHECK(close(cur) == kresult::InvalidHandle && close(HandleTable::kCurrentThread) == kresult::InvalidHandle);
    LG_CHECK(close(0) == kresult::InvalidHandle && close(*main) == 0 && close(*main) == kresult::InvalidHandle);
    LG_CHECK(pid(*main, v) == kresult::InvalidHandle);
    // GetSystemTick: the session clock, monotonic.
    CpuState t{};
    LG_CHECK(r.call(t, 0x1E).kind == Kind::Continue);
    const uint64_t t1 = t.x[0];
    const uint64_t c = r.clock.ticks();
    LG_CHECK(r.call(t, 0x1E).kind == Kind::Continue && t1 <= c && c <= t.x[0]);
    // end_session drops handles (and the clock); begin_session clears the rest.
    r.d.end_session();
    LG_CHECK(r.d.handles().size() == 0 && r.d.log().total_bytes() == 0 && r.d.total_calls() > 0);
    LG_CHECK(r.call(t, 0x1E).kind == Kind::Continue && t.x[0] == 0);
    r.d.begin_session({});
    LG_CHECK(r.d.total_calls() == 0 && !r.d.last().valid && r.d.calls(0x1E) == 0);
}

void u8_exit() {
    std::printf("[U8] ExitProcess\n");
    Rig r;
    CpuState s{};
    s.x[0] = 0xFFFFFFFF00000007ull;                                   // exit(7): the upper half is not the code
    LG_CHECK(r.call(s, 0x07, kStub).kind == Kind::ExitProcess);
    LG_CHECK(r.d.exit().exited && r.d.exit().has_code && r.d.exit().code == 7 && r.d.exit().pc == kStub);
    LG_CHECK(s.pc == kStub && s.exception.kind == ExceptionKind::Svc);
    s = {}; s.x[0] = 0xFFFFFFFFu;
    LG_CHECK(r.call(s, 0x07, kStub).kind == Kind::ExitProcess && r.d.exit().code == -1);
    s = {}; s.x[0] = 9;
    LG_CHECK(r.call(s, 0x07, 0x8000100).kind == Kind::ExitProcess);
    LG_CHECK(r.d.exit().exited && !r.d.exit().has_code && r.d.exit().pc == 0x8000100);
    // Without a stub (NSO/NCA) there is never a code.
    Rig n;
    n.d.begin_session({1, 0, 0, &n.clock, {}});
    s = {}; s.x[0] = 3;
    LG_CHECK(n.call(s, 0x07, 0).kind == Kind::ExitProcess && !n.d.exit().has_code);
}

void f1_fuzz() {
    std::printf("[F1] fuzzing: 10^5 SVCs with random numbers and hostile arguments\n");
    Rig r;
    std::vector<std::string> sunk;
    r.d.set_log_sink([&](const std::string& t) { sunk.push_back(t.substr(0, 8)); });
    const auto main = r.d.handles().add({KObjectType::Thread, 1});
    LG_CHECK(main.has_value());
    std::mt19937_64 rng(0x5EED);
    const uint64_t pointers[] = {0, 0x10, kUserRw, kUserRw + 0xFFF, kUserRw + 0x1FFF, kUserRo, kUserRo + 0xFFC, kKernel,
                                 kBig, kBig + kBigSize - 1, kStub, ~0ull, ~0ull - 7, 1ull << 63, 0x0800'0000};
    const uint64_t sizes[] = {0, 1, 4, 8, 0x1000, 0x2000, 0x2001, kBigSize, kBigSize + 1, ~0ull, 1ull << 40};
    const uint64_t handles[] = {0, 0xFFFF8000u, 0xFFFF8001u, 0xFFFF8002u, *main, *main + 1, 0x1234, ~0ull};
    auto pick = [&](const auto& a) { return a[rng() % (sizeof a / sizeof a[0])]; };
    uint64_t counts[5] = {};
    for (int i = 0; i < 100000; ++i) {
        CpuState s{};
        uint32_t id;
        switch (rng() % 4) {
            case 0: id = static_cast<uint32_t>(rng() % 0x200); break;                 // anything, incl. invalid
            default: { static const uint32_t impl[] = {0x07, 0x16, 0x1E, 0x24, 0x26, 0x27, 0x29}; id = pick(impl); }
        }
        for (int k = 0; k < 8; ++k) {
            switch (rng() % 4) {
                case 0: s.x[k] = pick(pointers); break;
                case 1: s.x[k] = pick(sizes); break;
                case 2: s.x[k] = pick(handles); break;
                default: s.x[k] = rng() % 3 ? rng() % 40 : rng();
            }
        }
        static const std::set<uint32_t> p3_ids = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D,
                                                  0x0E, 0x0F, 0x10, 0x11, 0x12, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D,
                                                  0x1E, 0x1F, 0x21, 0x24, 0x25, 0x26, 0x27, 0x29, 0x2A, 0x2B, 0x34, 0x35, 0x45};
        const uint64_t pc = 0x8000000 + 4 * (rng() % 0x1000);
        const CpuState before = s;
        const auto o = r.call(s, id, pc);
        ++counts[static_cast<int>(o.kind)];
        if (id >= 0xC0) LG_CHECK(o.kind == Kind::Fatal && o.message.find("inválida") != std::string::npos);
        else if (!svc_implemented(id)) LG_CHECK(o.kind == Kind::Fatal && o.message.find("no implementada") != std::string::npos);
        else if (id == 0x07) LG_CHECK(o.kind == Kind::ExitProcess);
        else if (id >= 0x01 && id <= 0x06)   // P3.2: this rig has no process map (like a synthetic image)
            LG_CHECK(o.kind == Kind::Fatal && o.message.find("memoria del proceso no disponible") != std::string::npos);
        else if ((id >= 0x08 && id <= 0x12) || id == 0x17 || (id >= 0x18 && id <= 0x1D) || id == 0x25 || id == 0x34 ||
                 id == 0x35 || id == 0x45 || id == 0x1F || id == 0x21)   // P3.3/P3.4: nor guest kernel threads, nor IPC
            LG_CHECK(o.kind == Kind::Fatal && o.message.find("hilos del kernel no disponibles") != std::string::npos);
        else if (id == 0x26 && !(before.x[0] & 0x80000000u)) LG_CHECK(o.kind == Kind::Fatal && o.message.rfind("guest_abort=", 0) == 0);
        else if (!p3_ids.count(id)) {
            // P6.0 (P6_0_DISENO.md): fail closed without the native kernel, the retail answers
            // otherwise; outputs may use x1-x7. TerminateProcess(own process) ends the process.
            const bool ok = (o.kind == Kind::Continue && s.pc == pc + 4 && s.exception.kind == ExceptionKind::None) ||
                            (o.kind == Kind::Fatal && (o.message.find("no disponible") != std::string::npos ||
                                                       o.message.find("UndefinedSystemCall") != std::string::npos)) ||
                            (id == 0x7B && o.kind == Kind::ExitProcess);
            if (!ok) std::printf("  0x%02X: kind %d '%s'\n", id, static_cast<int>(o.kind), o.message.c_str());
            LG_CHECK(ok);
            if (o.kind == Kind::Continue) for (int k = 8; k < 31; ++k) LG_CHECK(s.x[k] == before.x[k]);
        }
        else {
            LG_CHECK(o.kind == Kind::Continue && s.pc == pc + 4 && s.exception.kind == ExceptionKind::None);
            for (int k = 2; k < 31; ++k) LG_CHECK(s.x[k] == before.x[k]);   // only x0/x1 are outputs
        }
        if (o.kind != Kind::Continue) LG_CHECK(s.pc == pc);
        LG_CHECK(r.d.log().contents().size() <= GuestLog::kCapacity);
        if (id == 0x16 && r.d.handles().size() == 0) {                 // keep a handle around
            const auto again = r.d.handles().add({KObjectType::Thread, 1});
            LG_CHECK(again.has_value());
        }
    }
    std::printf("  continue=%llu exit=%llu fatal=%llu, log %llu bytes\n", (unsigned long long)counts[0],
                (unsigned long long)counts[3], (unsigned long long)counts[4], (unsigned long long)r.d.log().total_bytes());
    LG_CHECK(counts[0] > 40000 && counts[3] > 5000 && counts[4] > 20000 && counts[1] == 0 && counts[2] == 0);
    LG_CHECK(r.d.total_calls() == 100000);
}
} // namespace

int main() {
    u1_table();
    u2_handles();
    u3_log();
    u4_decoding();
    u5_contract();
    u6_memory_and_debug_string();
    u7_info_rules();
    u8_exit();
    f1_fuzz();
    std::puts("svc dispatch ok");
    return 0;
}
