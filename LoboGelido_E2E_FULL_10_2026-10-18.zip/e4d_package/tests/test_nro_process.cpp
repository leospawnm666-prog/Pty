// P3.0: real NRO processes, the process layout, the guest clock and "nobody runnable".
//  T1  detection: real NRO vs Lobo's synthetic NRO/NSO; load_plaintext refuses a real NRO
//  T4  64 MiB .bss reads as zero and does not raise RSS
//  T5  a real NRO runs up to its first SVC with the right registers and memory
//  T6  the same on every engine (interpreter, Block, JIT, JIT+fastmem, 16 KiB host pages);
//      stack guard and read-only .text fault
//  T7  GuestClock: monotonic across threads, 19.2 MHz, frozen while paused; engines use it
//  T8  a sleeping thread is not a fault; a blocked one without events is a reported deadlock
//  T9  an image that does not fit the guest memory budget fails cleanly
//  T10 prepare/stop cycles (clock lifetime) under the sanitizers
// P3.1: the SVC 0x27 is now SERVICED (the text reaches the guest log) and the program goes
// on to its "b .": the checks read the serviced call (last_svc) instead of a fault, and the
// entry registers follow nx-hbloader's ABI (x0 = ConfigEntry list, x1 = -1).
#include "../cpu/guest_clock.h"
#include "../cpu/interpreter.h"
#include "../loader/content_loader.h"
#include "../loader/nro_loader.h"
#include "../runtime/runtime_coordinator.h"
#include "../system/process_layout.h"
#include "data/nro/nro_fixtures.h"
#if defined(LOBOGELIDO_HAS_DYNARMIC)
#include "../cpu/dynarmic_provider.h"
#endif

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

namespace {
int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("  FAIL %s:%d %s\n", __FILE__, __LINE__, #c); std::fflush(stdout); if (++g_fail > 40) std::exit(1); } } while (0)

namespace fs = std::filesystem;
using lg::cpu::ExceptionKind;
using lg::runtime::RuntimeCoordinator;
using lg::system::ProcessLayout;
constexpr uint64_t MiB = 1ull << 20;
constexpr uint32_t kSvc27 = 0xD4000001u | (0x27u << 5);

template <size_t N> std::string write_fixture(const char* name, const unsigned char (&a)[N]) {
    const auto p = fs::temp_directory_path() / (std::string("lobo_p30_") + name + ".nro");
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(a), N);
    return p.string();
}
std::string synthetic_nro() {   // Lobo's own test format: "NRO0" at offset 0 (test_runtime_e2e_synthetic)
    const auto p = fs::temp_directory_path() / "lobo_p30_synthetic.nro";
    constexpr size_t kText = 2048;
    std::vector<uint8_t> b(0x80 + kText, 0);
    auto put32 = [&](size_t o, uint32_t v) { for (int i = 0; i < 4; ++i) b[o + i] = uint8_t(v >> (8 * i)); };
    auto put64 = [&](size_t o, uint64_t v) { put32(o, uint32_t(v)); put32(o + 4, uint32_t(v >> 32)); };
    b[0] = 'N'; b[1] = 'R'; b[2] = 'O'; b[3] = '0';
    put64(0x10, 0x80); put64(0x18, kText);
    for (size_t o = 0x80; o < b.size(); o += 4) put32(o, 0xD503201Fu);
    put32(0x80 + kText - 4, 0x14000000u | (uint32_t(-int32_t(kText / 4 - 1)) & 0x03FFFFFFu));
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(b.data()), long(b.size()));
    return p.string();
}
std::string synthetic_nso() {   // Lobo's own synthetic NSO header (content_loader.cpp)
    const auto p = fs::temp_directory_path() / "lobo_p30_synthetic.nso";
    std::vector<uint8_t> b(0x200, 0);
    auto put32 = [&](size_t o, uint32_t v) { for (int i = 0; i < 4; ++i) b[o + i] = uint8_t(v >> (8 * i)); };
    b[0] = 'N'; b[1] = 'S'; b[2] = 'O'; b[3] = '0';
    put32(0x10, 0x100); put32(0x14, 0x100);   // text: file offset 0x100, size 0x100
    put32(0x20, 0x100000);                    // text load address (low word)
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(b.data()), long(b.size()));
    return p.string();
}
long rss_kib() {
    std::ifstream f("/proc/self/status");
    std::string l;
    while (std::getline(f, l)) if (l.rfind("VmRSS:", 0) == 0) return std::stol(l.substr(6));
    return -1;
}
int run_until_stop(RuntimeCoordinator& rt, int max_frames = 100000) {
    // Until a fault, a clean exit, or the first serviced svcOutputDebugString (P3.1).
    for (int i = 0; i < max_frames; ++i) {
        if (!rt.run_frame(rt.entry_point()).ok()) return i;
        if (rt.svc_calls(0x27) > 0 || rt.state() == lg::runtime::State::Stopped) return i + 1;
    }
    return max_frames;
}
uint64_t result(RuntimeCoordinator& rt, int i) {
    const auto l = rt.process_layout();
    return rt.debug_read_guest64(l->code_va + nro_fixtures::hello_results_offset + 8ull * i).value_or(~0ull);
}

// ---------------------------------------------------------------------------------------
void t1_detection() {
    std::printf("[T1] real NRO vs synthetic formats\n");
    using lg::loader::ContentLoader;
    using lg::loader::Format;
    const auto real = ContentLoader::inspect(write_fixture("hello", nro_fixtures::hello));
    CHECK(real.valid && real.format == Format::Nro && real.native_nro);
    CHECK(real.segments.size() == 3 && real.nro_bss_size == 0x2000 && !real.secure_container);
    CHECK(real.segments[0].file_offset == 0 && real.segments[2].file_offset == 0x2000);
    lg::memory::AddressSpace as;
    lg::loader::LoadResult lr;
    CHECK(!ContentLoader::load_plaintext(real, as, lr));             // mapped only by ProcessLayout
    const auto syn = ContentLoader::inspect(synthetic_nro());
    CHECK(syn.valid && syn.format == Format::Nro && !syn.native_nro);
    CHECK(!syn.segments.empty() && syn.segments.front().load_address == 0x100000);
    const auto nso = ContentLoader::inspect(synthetic_nso());
    CHECK(nso.valid && nso.format == Format::Nso && !nso.native_nro);
    // A real-NRO signature with a broken header is recognised but not valid.
    std::vector<unsigned char> bad(nro_fixtures::hello, nro_fixtures::hello + sizeof nro_fixtures::hello);
    bad[0x24] = 0x10;                                                 // text size not page aligned
    const auto p = fs::temp_directory_path() / "lobo_p30_bad.nro";
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(bad.data()), long(bad.size()));
    const auto b = ContentLoader::inspect(p.string());
    CHECK(b.format == Format::Nro && b.native_nro && !b.valid);
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    CHECK(!rt.prepare(p.string()).ok());
    // The synthetic formats still run exactly as before (identity mapped).
    RuntimeCoordinator rs;
    rs.set_guest_memory_budget(64 * MiB);
    CHECK(rs.prepare(synthetic_nro()).ok());
    CHECK(rs.entry_point() == 0x100000 && !rs.process_layout().has_value());
    CHECK(rs.diagnostics().find("image=nro-synthetic") != std::string::npos);
}

// ---------------------------------------------------------------------------------------
struct Engine { const char* name; bool force_interpreter; bool fastmem; size_t host_page; };

void check_hello(RuntimeCoordinator& rt, const char* engine) {
    const auto l = rt.process_layout();
    CHECK(l.has_value());
    if (!l) return;
    CHECK(l->code_va == ProcessLayout::kCodeBase && rt.entry_point() == l->code_va);
    const int frames = run_until_stop(rt);
    CHECK(frames > 0 && frames < 100000);
    const auto f = rt.last_svc();
    const bool ok = f.valid && f.id == 0x27 && rt.last_guest_fault().kind == ExceptionKind::None;
    if (!ok) std::printf("  [%s] last svc/fault: %s\n", engine, rt.diagnostics().c_str());
    CHECK(ok);
    CHECK((rt.debug_read_guest64(f.pc).value_or(0) & 0xFFFFFFFFu) == kSvc27);        // the serviced SVC
    CHECK(f.pc >= l->code_va && f.pc < l->code_va + 0x1000);
    // svcOutputDebugString(msg, 22): msg lives in .rodata
    CHECK(f.x1 == 22);
    CHECK(f.x0 >= l->code_va + 0x1000 && f.x0 < l->code_va + 0x2000);
    char text[9] = {};
    const uint64_t w = rt.debug_read_guest64(f.x0).value_or(0);
    std::memcpy(text, &w, 8);
    CHECK(std::string(text) == "hola des");
    CHECK(rt.guest_log() == "hola desde un NRO real");               // P3.1: serviced
    const auto* ctx = rt.kernel_for_testing().contexts().get(1);
    CHECK(ctx && ctx->x[0] == 0 && ctx->pc == f.pc + 4);              // Result 0, resumed after the SVC
    CHECK(result(rt, 0) == l->config_va);                             // x0: ConfigEntry list (P3.1)
    CHECK(result(rt, 1) == ~0ull);                                    // x1 = -1 (nx-hbloader)
    CHECK(result(rt, 2) == l->stack_top_va);                          // SP
    CHECK(result(rt, 2) % 16 == 0);
    CHECK(result(rt, 3) == l->tls_va);                                // TPIDRRO_EL0
    CHECK(result(rt, 4) == 0x1122334455667788ull);                    // .rodata via ADRP
    CHECK(result(rt, 5) == 0);                                        // .bss is zero
    CHECK(result(rt, 6) == l->code_va);                               // ADR _start = image base
    CHECK(result(rt, 7) == 0);                                        // TLS starts zeroed
    CHECK(result(rt, 8) == 0x5A);                                     // TLS writable
    CHECK(result(rt, 9) == 0xCAFEF00Dull);                            // initialised .data
    CHECK(result(rt, 10) == 0xBEEF);                                  // reached the SVC
    // CNTPCT comes from the session's GuestClock on every engine (the E.1 per-thread model
    // would give exactly 1 for the first read).
    CHECK(rt.guest_clock() != nullptr);
    CHECK(result(rt, 11) > 100 && result(rt, 11) <= rt.guest_clock()->ticks());
    const std::string d = rt.diagnostics();
    CHECK(d.find("image=nro ") != std::string::npos);
    CHECK(d.find("last_svc=0x27@0x") != std::string::npos && d.find("last_fault=none") != std::string::npos);
    CHECK(d.find("guest_log=\"hola desde un NRO real\"") != std::string::npos);
    CHECK(d.find("code_va=0x8000000") != std::string::npos);
}

void expect_fault(const std::string& path, const Engine& e, ExceptionKind kind, uint64_t lo, uint64_t hi, const char* what,
                  uint64_t after_fault_offset) {
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(e.force_interpreter);
    rt.set_jit_fastmem(e.fastmem);
    CHECK(rt.prepare(path).ok());
    CHECK(rt.start().ok());
    run_until_stop(rt);
    const auto f = rt.last_guest_fault();
    const bool ok = f.kind == kind && f.address >= lo && f.address < hi &&
                    f.address == (kind == ExceptionKind::DataAbort && hi - lo == ProcessLayout::kGuardSize ? hi - 8 : lo + 0x100);   // H-P3.2-1: exact byte
    if (!ok) std::printf("  [%s] %s: kind=%d address=0x%llx\n", e.name, what, int(f.kind), (unsigned long long)f.address);
    CHECK(ok);
    // Precise fault: the store right after the faulting one never happened.
    const auto marker = rt.debug_read_guest64(rt.process_layout()->code_va + after_fault_offset);
    CHECK(marker.has_value() && *marker == 0);
}

void t5_t6_engines() {
    std::printf("[T5/T6] real NRO up to its first SVC, on every engine\n");
    const std::string hello = write_fixture("hello", nro_fixtures::hello);
    const std::string guard = write_fixture("guard", nro_fixtures::guard);
    const std::string write_text = write_fixture("write_text", nro_fixtures::write_text);
    std::vector<Engine> engines = {{"Block (interpreter)", true, false, 0}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    engines.push_back({"JIT", false, false, 0});
    engines.push_back({"JIT + fastmem", false, true, 0});
    engines.push_back({"JIT + fastmem, 16 KiB host pages", false, true, 16384});
#endif
    engines.push_back({"Block, 16 KiB host pages", true, false, 16384});
    for (const auto& e : engines) {
        std::printf("  engine: %s\n", e.name);
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            CHECK(rt.prepare(hello).ok());
            CHECK(rt.start().ok());
            if (e.fastmem) CHECK(rt.diagnostics().find("arena=shared") != std::string::npos);
            check_hello(rt, e.name);
            if (e.force_interpreter) {                                // the Block cache really works on VA != PA
                const std::string d = rt.diagnostics();
                const auto at = d.find(" blocks=");
                CHECK(at != std::string::npos && std::strtoull(d.c_str() + at + 8, nullptr, 10) > 0);
            }
            const auto l = *rt.process_layout();
            expect_fault(guard, e, ExceptionKind::DataAbort, l.stack_bottom_va - ProcessLayout::kGuardSize, l.stack_bottom_va,
                         "store below the stack", nro_fixtures::guard_after_fault_offset);
            expect_fault(write_text, e, ExceptionKind::DataAbort, l.code_va, l.code_va + 0x1000, "store to .text",
                         nro_fixtures::write_text_after_fault_offset);
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

// The fourth engine: the plain interpreter driven directly on the same layout.
void t6_plain_interpreter() {
    std::printf("[T6] plain interpreter on the same layout\n");
    const std::vector<uint8_t> file(nro_fixtures::hello, nro_fixtures::hello + sizeof nro_fixtures::hello);
    const auto img = lg::loader::NroLoader::parse(file);
    CHECK(img.ok());
    lg::memory::AddressSpace as;
    lg::memory::Mmu mmu;
    constexpr uint64_t kArena = 0x10000000, kSize = 16 * MiB;
    CHECK(as.enable_fastmem(kSize, kArena) && as.map(kArena, kSize));
    const auto l = lg::system::build_nro_process(img.value(), file, as, mmu, kArena, kSize);
    CHECK(l.ok());
    if (!l.ok()) return;
    lg::cpu::GuestClock clock;
    lg::cpu::Interpreter cpu(as, mmu);
    cpu.set_guest_clock(&clock);
    lg::cpu::CpuState s{};
    s.pc = l.value().code_va; s.sp = l.value().stack_top_va; s.tpidrro_el0 = l.value().tls_va;
    int steps = 0;
    while (steps < 1000 && cpu.step(s)) ++steps;
    CHECK(s.exception.kind == ExceptionKind::Svc && s.exception.syndrome == 0x27);
    auto rd = [&](int i) {
        const auto t = mmu.translate(l.value().code_va + nro_fixtures::hello_results_offset + 8ull * i, false, false);
        return t.ok() ? as.read64(t.value().physical).value_or(~0ull) : ~0ull;
    };
    CHECK(rd(4) == 0x1122334455667788ull && rd(5) == 0 && rd(9) == 0xCAFEF00Dull && rd(10) == 0xBEEF);
    CHECK(rd(2) == l.value().stack_top_va && rd(3) == l.value().tls_va && rd(6) == l.value().code_va);
    // Layout invariants: every region 64 KiB aligned (VA and PA), guards unmapped.
    for (uint64_t v : {l.value().code_va, l.value().stack_bottom_va - ProcessLayout::kGuardSize, l.value().tls_va,
                       l.value().image_pa, l.value().stack_pa, l.value().tls_pa})
        CHECK(v % ProcessLayout::kAlign == 0 || v == l.value().stack_bottom_va - ProcessLayout::kGuardSize);
    CHECK(l.value().image_pa % ProcessLayout::kAlign == 0 && l.value().stack_pa % ProcessLayout::kAlign == 0 &&
          l.value().tls_pa % ProcessLayout::kAlign == 0);
    CHECK(!mmu.translate(l.value().stack_bottom_va - 8, true, false).ok());
    // The lower guard belongs to the stack region (spec 2.3): later stack-region mappings
    // (thread stacks, P3.3) can never abut the main stack from below.
    CHECK(l.value().stack_bottom_va - ProcessLayout::kGuardSize >= ProcessLayout::kStackRegion);
    CHECK(l.value().stack_bottom_va == ProcessLayout::kStackRegion + ProcessLayout::kGuardSize);
    CHECK(!mmu.translate(l.value().stack_top_va, false, false).ok());          // upper guard
    CHECK(!mmu.translate(l.value().code_va, true, false).ok());                // .text not writable
    CHECK(mmu.translate(l.value().code_va, false, true).ok());                 // .text executable
    CHECK(!mmu.translate(l.value().code_va + 0x1000, false, true).ok());       // .rodata not executable
    CHECK(!mmu.translate(l.value().code_va + 0x1000, true, false).ok());       // .rodata read-only
    CHECK(mmu.translate(l.value().code_va + 0x4FF8, true, false).ok());        // last .bss page RW
    CHECK(!mmu.translate(l.value().code_va + 0x5000, false, false).ok());      // nothing after .bss
    CHECK(lg::system::hz_to_lobo_priority(0) == 127 && lg::system::hz_to_lobo_priority(44) == 83 &&
          lg::system::hz_to_lobo_priority(63) == 64 && lg::system::hz_to_lobo_priority(200) == 64);
}

// ---------------------------------------------------------------------------------------
void t4_big_bss() {
    std::printf("[T4] 64 MiB .bss\n");
    const std::string path = write_fixture("bigbss", nro_fixtures::bigbss);
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(256 * MiB);
    // Warm-up session: one-off costs (the JIT's code cache, services) are paid here, so the
    // measurement below only sees what loading and running the 64 MiB .bss costs.
    CHECK(rt.prepare(write_fixture("hello", nro_fixtures::hello)).ok());
    CHECK(rt.start().ok());
    run_until_stop(rt);
    (void)rt.stop();
    const long before = rss_kib();
    CHECK(rt.prepare(path).ok());
    const long loaded = rss_kib();
    CHECK(rt.start().ok());
    run_until_stop(rt);
    const long after = rss_kib();
    const auto f = rt.last_svc();
    CHECK(f.valid && f.id == 0x27 && f.x0 == 0);                        // first | last .bss word
    std::printf("  RSS: +%ld KiB to load, +%ld KiB after running (64 MiB .bss)\n", loaded - before, after - before);
#if defined(__SANITIZE_ADDRESS__) || defined(__SANITIZE_THREAD__)
    // Sanitizer allocators keep freed memory in quarantine (e.g. the previous JIT's 16 MiB):
    // RSS is not a measure of guest memory there. Checked in the normal builds.
    (void)loaded; (void)after;
#else
    CHECK(loaded - before < 16 * 1024);
    CHECK(after - before < 16 * 1024);
#endif
}

void t9_budget() {
    std::printf("[T9] image larger than the guest memory budget\n");
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(16 * MiB);                                // 64 MiB .bss cannot fit
    const auto r = rt.prepare(write_fixture("bigbss", nro_fixtures::bigbss));
    CHECK(!r.ok() && r.error().find("does not fit") != std::string::npos);
    CHECK(rt.state() == lg::runtime::State::Error);
    RuntimeCoordinator ok;
    ok.set_guest_memory_budget(16 * MiB);                                // the small one fits
    CHECK(ok.prepare(write_fixture("hello", nro_fixtures::hello)).ok());
}

// ---------------------------------------------------------------------------------------
void t7_clock() {
    std::printf("[T7] guest clock\n");
    lg::cpu::GuestClock c;
    CHECK(lg::cpu::GuestClock::ns_to_ticks(1'000'000'000) == 19'200'000);
    __extension__ typedef unsigned __int128 u128;
    CHECK(lg::cpu::GuestClock::ns_to_ticks(~0ull) == uint64_t(u128(~0ull) * 12 / 625));   // no 64-bit overflow
    // Monotonic across threads.
    std::atomic<int> bad{0};
    auto reader = [&] { uint64_t prev = 0; for (int i = 0; i < 200000; ++i) { const uint64_t t = c.ticks(); if (t < prev) ++bad; prev = t; } };
    std::thread a(reader), b(reader);
    a.join(); b.join();
    CHECK(bad == 0);
    // Rate: 19.2 MHz against the host clock.
    const auto h0 = std::chrono::steady_clock::now();
    const uint64_t t0 = c.ticks();
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    const uint64_t t1 = c.ticks();
    const double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - h0).count();
    const double rate = double(t1 - t0) / secs;
    std::printf("  measured %.4f MHz\n", rate / 1e6);
    CHECK(rate > 19.2e6 * 0.98 && rate < 19.2e6 * 1.02);
    // Pause freezes guest time; resume continues without a jump.
    c.pause();
    const uint64_t p0 = c.ticks();
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    CHECK(c.ticks() == p0 && c.paused());
    c.resume();
    const uint64_t r0 = c.ticks();
    CHECK(r0 >= p0 && r0 - p0 < 19'200'000 / 100);                       // < 10 ms of guest time
    // Engines: without a clock the E.1 model (increment per read) is unchanged.
    lg::memory::AddressSpace as;
    lg::memory::Mmu mmu;
    CHECK(as.map(0x100000, 0x1000) && mmu.map(0x100000, 0x100000, 0x1000, lg::memory::Read | lg::memory::Execute));
    const uint32_t prog[] = {0xD53BE020u, 0xD53BE021u};                    // mrs x0, cntvct_el0 ; mrs x1, cntvct_el0
    for (int i = 0; i < 2; ++i) as.write32(0x100000 + 4 * i, prog[i]);
    {
        lg::cpu::Interpreter cpu(as, mmu);
        lg::cpu::CpuState s{}; s.pc = 0x100000;
        CHECK(cpu.step(s) && cpu.step(s));
        CHECK(s.x[0] == 1 && s.x[1] == 2);
        cpu.set_guest_clock(&c);
        s.pc = 0x100000;
        const uint64_t before = c.ticks();
        CHECK(cpu.step(s) && cpu.step(s));
        CHECK(s.x[0] >= before && s.x[1] >= s.x[0] && s.x[1] <= c.ticks());
    }
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    {
        const uint32_t loop[] = {0xD53BE020u, 0xD53BE021u, 0x14000000u};    // ... ; b .
        CHECK(as.map(0x200000, 0x1000) && mmu.map(0x200000, 0x200000, 0x1000, lg::memory::Read | lg::memory::Execute));
        for (int i = 0; i < 3; ++i) as.write32(0x200000 + 4 * i, loop[i]);
        lg::cpu::Interpreter fb(as, mmu);
        lg::cpu::DynarmicProvider jit(as, mmu, fb);
        CHECK(jit.initialize().ok());
        lg::cpu::CpuState s{}; s.pc = 0x200000;
        CHECK(jit.execute(s, 8).ok());
        CHECK(s.x[0] == 1 && s.x[1] == 2);                                 // E.1 model
        jit.set_guest_clock(&c);
        s.pc = 0x200000;
        const uint64_t before = c.ticks();
        CHECK(jit.execute(s, 8).ok());
        CHECK(s.x[0] >= before && s.x[1] >= s.x[0] && s.x[1] <= c.ticks());
        jit.set_guest_clock(nullptr);
    }
#endif
    // The coordinator's clock stops while the session is paused.
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    CHECK(rt.guest_clock() == nullptr);
    CHECK(rt.prepare(synthetic_nro()).ok());
    CHECK(rt.guest_clock() != nullptr);
    CHECK(rt.start().ok());
    CHECK(rt.pause().ok());
    const uint64_t q0 = rt.guest_clock()->ticks();
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    CHECK(rt.guest_clock()->ticks() == q0);
    CHECK(rt.resume().ok());
    CHECK(rt.run_frame(rt.entry_point()).ok());
    CHECK(rt.diagnostics().find("guest_tick=") != std::string::npos);
    CHECK(rt.stop().ok());
    CHECK(rt.guest_clock() == nullptr);                                  // uninstalled and destroyed
}

// ---------------------------------------------------------------------------------------
void t8_idle() {
    std::printf("[T8] nobody runnable\n");
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    CHECK(rt.prepare(synthetic_nro()).ok());
    CHECK(rt.start().ok());
    CHECK(rt.run_frame(rt.entry_point()).ok());
    auto& threads = rt.kernel_for_testing().threads();
    const uint64_t main = 1;
    CHECK(threads.info(main) && threads.info(main)->name == "main");
    const uint64_t instr0 = rt.metrics().instructions;
    CHECK(threads.sleep(main, 5000));
    CHECK(rt.run_frame(rt.entry_point()).ok());                          // was: "no runnable guest thread"
    CHECK(rt.idle_skips() == 1);
    CHECK(rt.metrics().instructions > instr0);                           // woke up and ran in the same frame
    CHECK(rt.diagnostics().find("idle_skips=1") != std::string::npos);
    // Blocked with no event that could wake it: a deadlock, reported with the thread list.
    const auto pending = rt.kernel_for_testing().scheduler().pending();
    CHECK(threads.block(main));
    const auto r = rt.run_frame(rt.entry_point());
    if (pending == 0) {
        CHECK(!r.ok() && r.error().find("guest deadlock") != std::string::npos &&
              r.error().find("1:main:blocked") != std::string::npos);
    } else {
        std::printf("  (the scheduler has %zu background events: no deadlock possible)\n", size_t(pending));
        CHECK(r.ok());
    }
    // No live thread at all keeps the old behaviour (an error).
    RuntimeCoordinator rd;
    rd.set_guest_memory_budget(64 * MiB);
    CHECK(rd.prepare(synthetic_nro()).ok());
    CHECK(rd.start().ok());
    CHECK(rd.kernel_for_testing().threads().terminate(1));
    CHECK(!rd.run_frame(rd.entry_point()).ok());
    CHECK(rd.idle_skips() == 0);
}

void t10_cycles() {
    std::printf("[T10] prepare/stop cycles\n");
    const std::string hello = write_fixture("hello", nro_fixtures::hello);
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(32 * MiB);
    for (int i = 0; i < 20; ++i) {
        CHECK(rt.prepare(i % 2 ? synthetic_nro() : hello).ok());
        CHECK(rt.start().ok());
        for (int f = 0; f < 3; ++f) (void)rt.run_frame(rt.entry_point());
        (void)rt.stop();
        CHECK(rt.guest_clock() == nullptr && !rt.process_layout().has_value());
    }
}
} // namespace

int main() {
    t1_detection();
    t4_big_bss();
    t5_t6_engines();
    t6_plain_interpreter();
    t7_clock();
    t8_idle();
    t9_budget();
    t10_cycles();
    if (g_fail) { std::printf("nro process: %d FAILED\n", g_fail); return 1; }
    std::puts("nro process ok");
    return 0;
}
