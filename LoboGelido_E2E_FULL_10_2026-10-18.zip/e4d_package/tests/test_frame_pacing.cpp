#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "../graphics/frame_pacing/cadence_calculator.h"
#include "../graphics/frame_pacing/frame_pacing_controller.h"
#include <cassert>
#include <chrono>
#include <cmath>

int main() {
    using namespace lg::graphics::frame_pacing;
    using namespace std::chrono_literals;

    const auto exact = CadenceCalculator::calculate({120.0, 60.0});
    LG_CHECK(exact.valid);
    LG_CHECK(exact.base_refreshes == 2);
    LG_CHECK(std::llround(exact.frame_interval.count()) == 16'666'667);

    const auto fractional = CadenceCalculator::calculate({120.0, 50.0});
    LG_CHECK(fractional.valid);
    LG_CHECK(fractional.base_refreshes == 2);
    LG_CHECK(fractional.fractional_refreshes > 0.39 && fractional.fractional_refreshes < 0.41);

    const auto ninety = CadenceCalculator::calculate({90.0, 60.0});
    LG_CHECK(ninety.valid);
    LG_CHECK(ninety.base_refreshes == 1);
    LG_CHECK(ninety.frame_interval == 16'666'667ns);

    const auto oneFortyFour = CadenceCalculator::calculate({144.0, 60.0});
    LG_CHECK(oneFortyFour.valid);
    LG_CHECK(oneFortyFour.base_refreshes == 2);
    LG_CHECK(oneFortyFour.frame_interval == 16'666'667ns);

    const auto invalid = CadenceCalculator::calculate({0.0, 60.0});
    LG_CHECK(!invalid.valid);

    FramePacingController controller({60.0, 250ms});
    const auto t0 = std::chrono::steady_clock::time_point{};
    controller.reset(t0);
    controller.update_refresh_metrics({90.0, true});
    LG_CHECK(controller.cadence().refresh_rate_hz == 90.0);
    LG_CHECK(controller.cadence().target_fps == 60.0);
    controller.update_refresh_metrics({120.0, true});
    LG_CHECK(controller.cadence().refresh_rate_hz == 120.0);
    LG_CHECK(controller.cadence().target_fps == 60.0);
    auto first = controller.begin_frame(t0);
    LG_CHECK(first.valid);
    LG_CHECK(first.recommended_wait.count() == 0);
    controller.end_frame(t0 + 1ms);

    auto second = controller.begin_frame(t0 + 1ms);
    LG_CHECK(second.valid);
    LG_CHECK(second.recommended_wait == 15'666'667ns);
    controller.update_synchronization_metrics({4ms, 8ms, 0ns, true});
    auto third = controller.begin_frame(t0 + 2ms);
    LG_CHECK(third.estimated_slack == 8'666'667ns);

    return 0;
}
