#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <barrier>
#include <chrono>
#include <thread>

#include "../runtime/runtime_coordinator.h"
#include "../runtime/runtime_worker.h"

using namespace std::chrono_literals;


int main() {
    // The coordinator is deliberately used as a black-box execution authority.
    // This test does not alter CPU, scheduler, MMU or graphics behavior.
    lg::runtime::RuntimeCoordinator runtime;
    LG_CHECK(runtime.prepare().ok());
    LG_CHECK(runtime.state() == lg::runtime::State::Ready);
    LG_CHECK(runtime.start().ok());
    LG_CHECK(runtime.state() == lg::runtime::State::Running);

    lg::runtime::RuntimeWorker worker(runtime);
    LG_CHECK(worker.is_stopped());

    // Worker may start only after the coordinator is Running.
    LG_CHECK(worker.start());

    // The current synthetic coordinator image eventually rejects a guest
    // quantum once its only runnable guest thread terminates. The worker must
    // contain that failure instead of throwing from the std::thread entry.
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    // With the JIT, the first quantum also builds Dynarmic's A64 decoder tables
    // (one-time static initialisation, ~2 s in a -O0 + sanitizer build), so the
    // "eventually" of this check needs a larger budget there (P2 phase B.2).
    constexpr auto kErrorBudget = 10000ms;
#else
    constexpr auto kErrorBudget = 1000ms;
#endif
    LG_CHECK(worker.wait_until_state(lg::runtime::RuntimeWorker::State::Error, kErrorBudget));
    LG_CHECK(!worker.is_running());
    LG_CHECK(worker.state() == lg::runtime::RuntimeWorker::State::Error);

    // A failed worker cannot be resumed or started again. Stop remains the
    // terminal cleanup operation and must join the underlying std::thread.
    LG_CHECK(!worker.resume());
    LG_CHECK(!worker.start());

    // Deterministic contention: both callers cross the same barrier before
    // attempting to stop/join the same std::thread. Exactly one caller may
    // own join(); the other must observe the completed cleanup safely.
    std::barrier stop_gate(3);
    bool stop_result_a = false;
    bool stop_result_b = false;
    std::thread stop_a([&] {
        stop_gate.arrive_and_wait();
        stop_result_a = worker.stop();
    });
    std::thread stop_b([&] {
        stop_gate.arrive_and_wait();
        stop_result_b = worker.stop();
    });
    stop_gate.arrive_and_wait();
    stop_a.join();
    stop_b.join();
    LG_CHECK(stop_result_a);
    LG_CHECK(stop_result_b);
    LG_CHECK(worker.is_stopped());
    LG_CHECK(worker.stop());

    // A worker cannot start against a non-running coordinator.
    LG_CHECK(runtime.stop().ok());
    lg::runtime::RuntimeWorker stopped_worker(runtime);
    LG_CHECK(!stopped_worker.start());
    LG_CHECK(stopped_worker.is_stopped());

    return 0;
}
