#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "../gpu/async_pipeline_cache.h"
#include <cassert>
#include <chrono>
#include <thread>
#include <atomic>

int main() {
    std::atomic<int> compiles{0};
    lg::gpu::AsyncPipelineCache cache([&](uint64_t key, lg::gpu::PipelineHandle& out) {
        ++compiles;
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        out = key ^ 0x55;
        return true;
    }, 2);

    lg::gpu::PipelineHandle h{};
    auto s = cache.get(0x11, h);
    LG_CHECK(s == lg::gpu::PipelineStatus::Compiling);
    cache.wait_idle();
    LG_CHECK(cache.ready_count() == 1);
    LG_CHECK(cache.compiled() == 1);
    LG_CHECK(cache.get(0x11, h) == lg::gpu::PipelineStatus::Ready);
    LG_CHECK(h == (0x11 ^ 0x55));

    const auto blob = cache.serialize();
    LG_CHECK(blob.size() == 12); // u32 count + one semantic u64 key

    lg::gpu::AsyncPipelineCache second([&](uint64_t key, lg::gpu::PipelineHandle& out) {
        ++compiles;
        out = key + 1;
        return true;
    }, 1);
    LG_CHECK(second.load(blob) == 1);
    LG_CHECK(second.has_known_key(0x11));
    // Persisted Vulkan handles are intentionally NOT restored as Ready handles.
    LG_CHECK(second.get(0x11, h) == lg::gpu::PipelineStatus::Compiling);
    second.wait_idle();
    LG_CHECK(second.ready_count() == 1);
    LG_CHECK(second.get(0x11, h) == lg::gpu::PipelineStatus::Ready);
    LG_CHECK(h == 0x12);

    cache.invalidate_runtime_handles();
    LG_CHECK(cache.get(0x11, h) == lg::gpu::PipelineStatus::Compiling);
    cache.wait_idle();
    LG_CHECK(compiles.load() >= 3);
    return 0;
}
