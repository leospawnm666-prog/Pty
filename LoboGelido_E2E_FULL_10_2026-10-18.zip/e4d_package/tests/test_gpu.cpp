#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <filesystem>
#include <vector>
#include "../gpu/gpu_device.h"
#include "../gpu/render_graph.h"
#include "../graphics/shader_cache.h"

int main() {
    lg::gpu::GpuDevice device;
    LG_CHECK(!device.initialize().ok());
    lg::gpu::DeviceInfo actual{};
    actual.backend = lg::gpu::Backend::Vulkan;
    actual.api = "Vulkan";
    actual.api_version = 0x00403000;
    actual.timeline_semaphore = true;
    actual.dynamic_rendering = true;
    actual.descriptor_indexing = true;
    actual.shader_int16 = true;
    actual.initialized = true;
    LG_CHECK(device.initialize(actual).ok());
    LG_CHECK(device.ready());
    LG_CHECK(device.info().backend == lg::gpu::Backend::Vulkan);
    LG_CHECK(device.info().dynamic_rendering);
    LG_CHECK(device.info().descriptor_indexing);

    lg::gpu::RenderGraph graph;
    LG_CHECK(graph.add({lg::gpu::PassType::Transfer, 1, {}}).ok());
    LG_CHECK(graph.add({lg::gpu::PassType::Compute, 2, {1}}).ok());
    LG_CHECK(graph.add({lg::gpu::PassType::Graphics, 3, {2}}).ok());
    auto order = graph.compile();
    LG_CHECK(order.ok() && order.value().size() == 3);
    LG_CHECK(order.value()[0] == 1 && order.value()[1] == 2 && order.value()[2] == 3);

    lg::gpu::RenderGraph cycle;
    LG_CHECK(cycle.add({lg::gpu::PassType::Compute, 10, {11}}).ok());
    LG_CHECK(cycle.add({lg::gpu::PassType::Compute, 11, {10}}).ok());
    LG_CHECK(!cycle.compile().ok());

    const auto root = std::filesystem::temp_directory_path() / "lobogelido_shader_cache_test";
    lg::graphics::ShaderCache cache(root);
    const lg::graphics::ShaderCacheKey key{0x11, 0x22, 7};
    const std::vector<uint8_t> payload{1, 2, 3, 4};
    LG_CHECK(cache.put(key, payload));
    std::vector<uint8_t> loaded;
    LG_CHECK(cache.get(key, loaded) && loaded == payload);
    cache.clear();
    return 0;
}
