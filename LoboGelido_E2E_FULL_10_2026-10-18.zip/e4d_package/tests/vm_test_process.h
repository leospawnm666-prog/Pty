#pragma once
// P3.2 test helper: a process built like RuntimeCoordinator builds it (the P3.0 layout of
// hello.nro, or any NRO given) plus the P3.2 VmManager seeding. Shared by test_vm_manager and
// test_mem_process.
#include "lg_check.h"
#include "../loader/nro_loader.h"
#include "../system/process_layout.h"
#include "../system/vm_manager.h"
#include "data/nro/nro_fixtures.h"

#include <optional>
#include <vector>

namespace vm_test {
using namespace lg::system;
namespace km = lg::system::kmem;
constexpr uint64_t MiB = 1ull << 20;
constexpr uint64_t P = km::PageSize;

// A process built like the coordinator does (P3.0 layout of hello.nro + the P3.2 seeding).
struct Process {
    static constexpr uint64_t kArena = 0x10000000;
    lg::memory::AddressSpace as;
    lg::memory::Mmu mmu;
    VmManager vm{as, mmu};
    ProcessLayout l{};
    explicit Process(uint64_t arena_size = 64 * MiB,
                     std::vector<uint8_t> file = std::vector<uint8_t>(nro_fixtures::hello, nro_fixtures::hello + sizeof nro_fixtures::hello)) {
        const auto img = lg::loader::NroLoader::parse(file);
        LG_CHECK(img.ok());
        LG_CHECK(as.enable_fastmem(arena_size, kArena) && as.map(kArena, arena_size));
        const auto built = build_nro_process(img.value(), file, as, mmu, kArena, arena_size);
        LG_CHECK(built.ok());
        l = built.value();
        VmConfig c{};
        c.space_begin = ProcessLayout::kAslrBase; c.space_end = ProcessLayout::kAslrEnd;
        c.heap_base = ProcessLayout::kHeapRegion; c.heap_size = ProcessLayout::kHeapRegionSize;
        c.alias_base = ProcessLayout::kAliasRegion; c.alias_size = ProcessLayout::kAliasRegionSize;
        c.stack_base = ProcessLayout::kStackRegion; c.stack_size = ProcessLayout::kStackRegionSize;
        c.arena_free_base = kArena + l.arena_used; c.arena_free_size = arena_size - l.arena_used;
        c.total_memory = arena_size; c.static_used = l.arena_used;
        LG_CHECK(vm.begin(c));
        for (const auto& r : l.image_regions) {
            if (!r.size) continue;
            const bool w = r.perms & lg::memory::Write;
            LG_CHECK(vm.seed(l.code_va + r.offset, (r.size + P - 1) & ~(P - 1), w ? km::AliasCodeData : km::AliasCode,
                             w ? km::PermRW : ((r.perms & lg::memory::Execute) ? km::PermRX : km::PermR)));
        }
        LG_CHECK(vm.seed(l.stack_bottom_va, ProcessLayout::kMainStackSize, km::Stack, km::PermRW));
        LG_CHECK(vm.seed(l.tls_va, ProcessLayout::kTlsPageSize, km::ThreadLocal, km::PermRW));
        LG_CHECK(vm.seed(l.exit_stub_va, P, km::Code, km::PermRX));
        LG_CHECK(vm.seed(l.config_va, P, km::CodeData, km::PermRW));
    }
    bool readable(uint64_t va) const { return mmu.translate(va, false, false).ok(); }
    bool writable(uint64_t va) const { return mmu.translate(va, true, false).ok(); }
    std::optional<uint64_t> read64(uint64_t va) const {
        const auto t = mmu.translate(va, false, false);
        return t.ok() ? as.read64(t.value().physical) : std::nullopt;
    }
    bool write64(uint64_t va, uint64_t v) {
        const auto t = mmu.translate(va, true, false);
        if (!t.ok()) return false;
        as.write64(t.value().physical, v);
        return true;
    }
};

} // namespace vm_test
