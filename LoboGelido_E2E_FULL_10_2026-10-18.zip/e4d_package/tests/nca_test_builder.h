#pragma once
// P3.0 (D-A-1): builds a Program NCA with TEST keys whose ExeFS holds `nso` as "main",
// the same construction as tests/test_nca_loader.cpp. Writes <root>/keys/prod.keys, creates
// <root>/nand/system and returns the path of <root>/game.nca. Test-only: the keys are fixed
// test vectors and nothing here is part of the product.
#include "../crypto/aes128.h"
#include "../crypto/sha256.h"
#include <array>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

namespace nca_test {
inline void p32(std::vector<uint8_t>& b, size_t o, uint32_t v){for(int i=0;i<4;i++)b[o+i]=uint8_t(v>>(8*i));}
inline void p64(std::vector<uint8_t>& b, size_t o, uint64_t v){for(int i=0;i<8;i++)b[o+i]=uint8_t(v>>(8*i));}
inline std::vector<uint8_t> hex(const char* s){std::vector<uint8_t> o;for(size_t i=0;s[i];i+=2)o.push_back(uint8_t(std::stoul(std::string(s+i,2),nullptr,16)));return o;}

inline std::filesystem::path write_test_nca(const std::filesystem::path& root, const std::vector<uint8_t>& nso) {
    namespace fs=std::filesystem; fs::remove_all(root); fs::create_directories(root/"keys"); fs::create_directories(root/"nand"/"system");
    const auto header_key=hex("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f");
    const auto kaek=hex("202122232425262728292a2b2c2d2e2f");
    const auto content_key=hex("303132333435363738393a3b3c3d3e3f");
    std::ofstream k(root/"keys"/"prod.keys");
    auto emit=[&](const char*n,const std::vector<uint8_t>&v){k<<n<<"=";static const char*h="0123456789abcdef";for(auto x:v)k<<h[x>>4]<<h[x&15];k<<"\n";};
    emit("nca_header_key",header_key); emit("nca_key_area_key_application_00",kaek); k.close();

    const std::string name="main"; const uint32_t strings=5; const uint32_t pfs_data=0x10+0x18+strings; std::vector<uint8_t> exefs(pfs_data+nso.size(),0); std::memcpy(exefs.data(),"PFS0",4); p32(exefs,4,1); p32(exefs,8,strings); p64(exefs,0x10,0); p64(exefs,0x18,nso.size()); p32(exefs,0x20,0); std::memcpy(exefs.data()+0x28,name.c_str(),name.size()); std::memcpy(exefs.data()+pfs_data,nso.data(),nso.size());
    const uint64_t section_size=((exefs.size()+0x1ff)/0x200)*0x200; exefs.resize(section_size,0);
    std::vector<uint8_t> plain(0xc00,0); std::memcpy(plain.data()+0x200,"NCA3",4); plain[0x204]=0; plain[0x205]=0; plain[0x207]=0; plain[0x220]=1; p64(plain,0x210,0x0100000000000000ull); p32(plain,0x240,6); p32(plain,0x244,6+uint32_t(section_size/0x200));
    plain[0x400]=2; plain[0x402]=1; plain[0x403]=2; plain[0x404]=3; plain[0x540]=0x11; // section CTR seed
    const auto fs_hash = lg::crypto::Sha256::digest(plain.data()+0x400, 0x200); std::copy(fs_hash.begin(), fs_hash.end(), plain.begin()+0x280);
    std::copy(content_key.begin(),content_key.end(),plain.begin()+0x320);
    std::array<uint8_t,16> kaek_a{}; std::copy(kaek.begin(),kaek.end(),kaek_a.begin()); lg::crypto::Aes128 ka(kaek_a); std::array<uint8_t,0x40> enc_keys{}; ka.encrypt_block(plain.data()+0x300,enc_keys.data()); ka.encrypt_block(plain.data()+0x310,enc_keys.data()+0x10); ka.encrypt_block(plain.data()+0x320,enc_keys.data()+0x20); ka.encrypt_block(plain.data()+0x330,enc_keys.data()+0x30); std::copy(enc_keys.begin(),enc_keys.end(),plain.begin()+0x300);
    plain.resize(0xc00 + exefs.size(), 0); std::copy(exefs.begin(), exefs.end(), plain.begin()+0xc00);
    std::array<uint8_t,16> ctr{}; ctr[0]=0; ctr[1]=0; ctr[2]=0; ctr[3]=0; ctr[4]=0; ctr[5]=0; ctr[6]=0; ctr[7]=0x11; uint64_t ctr_ofs=0xc00>>4; for(int j=0;j<8;j++){ctr[15-j]=static_cast<uint8_t>(ctr_ofs); ctr_ofs>>=8;}
    std::array<uint8_t,16> content_key_a{}; std::copy(content_key.begin(), content_key.end(), content_key_a.begin());
    lg::crypto::aes128_ctr_xor(content_key_a, plain.data()+0xc00, exefs.size(), ctr);
    std::array<uint8_t,32> hk{}; std::copy(header_key.begin(),header_key.end(),hk.begin()); lg::crypto::aes128_xts_encrypt(hk,plain.data(),0xc00,0,0x200);
    const auto nca=root/"game.nca"; std::ofstream(nca,std::ios::binary).write(reinterpret_cast<const char*>(plain.data()),plain.size());
    return nca;
}
/** Wraps the NCA from write_test_nca() in an NSP (a PFS0 container with one "game.nca"
 *  entry), the way encrypted content reaches the coordinator: a loose .nca is not
 *  recognised by ContentLoader::inspect because its header is encrypted. */
inline std::filesystem::path write_test_nsp(const std::filesystem::path& root, const std::vector<uint8_t>& nso) {
    const auto nca_path = write_test_nca(root, nso);
    std::ifstream in(nca_path, std::ios::binary);
    std::vector<uint8_t> nca((std::istreambuf_iterator<char>(in)), {});
    const std::string name = "game.nca";
    const uint32_t strings = 0x10;                                   // name + padding
    const uint32_t header = 0x10 + 0x18 + strings;
    std::vector<uint8_t> nsp(header, 0);
    std::memcpy(nsp.data(), "PFS0", 4);
    p32(nsp, 4, 1); p32(nsp, 8, strings);
    p64(nsp, 0x10, 0); p64(nsp, 0x18, nca.size()); p32(nsp, 0x20, 0);
    std::memcpy(nsp.data() + 0x28, name.c_str(), name.size());
    nsp.insert(nsp.end(), nca.begin(), nca.end());
    const auto out = root / "game.nsp";
    std::ofstream(out, std::ios::binary).write(reinterpret_cast<const char*>(nsp.data()), long(nsp.size()));
    return out;
}
} // namespace nca_test
