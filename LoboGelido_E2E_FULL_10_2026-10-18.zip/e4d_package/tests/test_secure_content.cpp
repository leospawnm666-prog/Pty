#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "../loader/content_loader.h"
#include "../runtime/runtime_storage.h"
#include <cassert>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

static void put32(std::vector<uint8_t>& b, size_t o, uint32_t v) {
    for (int i = 0; i < 4; ++i) b[o + i] = static_cast<uint8_t>(v >> (8 * i));
}
static void put64(std::vector<uint8_t>& b, size_t o, uint64_t v) {
    for (int i = 0; i < 8; ++i) b[o + i] = static_cast<uint8_t>(v >> (8 * i));
}

int main() {
    namespace fs = std::filesystem;
    const fs::path root = fs::temp_directory_path() / "lobo_secure_runtime_test";
    fs::remove_all(root);
    fs::create_directories(root / "keys");
    fs::create_directories(root / "nand" / "system");
    std::ofstream(root / "keys" / "prod.keys") << "master_key_00=00112233445566778899aabbccddeeff\n";

    // Minimal PFS0 containing one NCA-named entry. The bytes are deliberately
    // not executable: this test verifies container routing and safety checks.
    const std::string name = "main.nca";
    const uint32_t count = 1;
    const uint32_t str_size = static_cast<uint32_t>(name.size() + 1);
    const uint64_t data_offset = 0x10 + 0x18 + str_size;
    std::vector<uint8_t> pfs(static_cast<size_t>(data_offset + 4), 0);
    std::memcpy(pfs.data(), "PFS0", 4);
    put32(pfs, 4, count); put32(pfs, 8, str_size); put32(pfs, 12, 0);
    put64(pfs, 0x10, 0); put64(pfs, 0x18, 4); put32(pfs, 0x20, 0); put32(pfs, 0x24, 0);
    std::memcpy(pfs.data() + 0x28, name.c_str(), name.size());
    pfs[data_offset] = 'N'; pfs[data_offset + 1] = 'C'; pfs[data_offset + 2] = 'A'; pfs[data_offset + 3] = '3';
    const auto nsp = root / "game.nsp";
    std::ofstream(nsp, std::ios::binary).write(reinterpret_cast<const char*>(pfs.data()), pfs.size());

    const auto info = lg::loader::ContentLoader::inspect(nsp.string());
    LG_CHECK(info.valid && info.format == lg::loader::Format::Nsp && info.secure_container);
    LG_CHECK(info.entries.size() == 1 && info.entries.front().name == name);

    lg::runtime::RuntimeStorage storage;
    LG_CHECK(storage.configure({(root / "keys").string(), (root / "nand").string()}).ok());
    LG_CHECK(storage.load_key_material().ok());
    LG_CHECK(storage.refresh_firmware_state().ok());
    LG_CHECK(storage.validate_for_secure_content().ok());
    LG_CHECK(storage.has_key("master_key_00"));

    fs::remove_all(root);
    return 0;
}
