// Synthetic stress / concurrency test for the JNI bridge's shared state.
//
// The JNI layer (native.cpp) is a thin, stateless wrapper: its concurrency
// correctness reduces to NativeRuntimeHost being safe under concurrent calls
// from many threads — exactly what happens when Kotlin drives the bridge from
// the render thread, the UI thread and input callbacks at once.
//
// This test hammers the host from several thread classes simultaneously and
// asserts: no crash, no deadlock (it is bounded — a hang trips the CTest
// timeout), no torn reads of state/metrics, correct atomic input aggregation,
// and no file-descriptor leak under churn. Host-buildable (no NDK/JVM needed):
// on host, Vulkan calls take the unavailable fallback but still exercise the
// graphics lock against teardown.

#include <atomic>
#include <chrono>
#include <cstdio>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>

#include "native_runtime_host.h"

namespace {

std::atomic<int> g_failures{0};

#define CHECK(cond, msg)                                                      \
    do {                                                                      \
        if (!(cond)) {                                                        \
            g_failures.fetch_add(1, std::memory_order_relaxed);              \
            std::printf("  [FAIL] %s (%s:%d)\n", (msg), __FILE__, __LINE__); \
        }                                                                     \
    } while (0)

bool is_valid_state(const std::string& s) {
    static const char* kStates[] = {"CREATED", "PREPARING", "READY", "RUNNING",
                                    "PAUSED",  "RECOVERING", "STOPPED", "ERROR",
                                    "UNKNOWN"};
    for (const char* k : kStates)
        if (s == k) return true;
    return false;
}

// Count open file descriptors for this process (Linux). Returns -1 if the
// /proc interface is unavailable, in which case the caller skips the leak check.
int open_fd_count() {
    DIR* d = ::opendir("/proc/self/fd");
    if (!d) return -1;
    int n = 0;
    while (::readdir(d) != nullptr) ++n;
    ::closedir(d);
    return n;  // includes '.' and '..' and the opendir handle; only the delta matters
}

using Host = lg::android::NativeRuntimeHost;

// ---- Scenario A: mixed concurrency against a single shared host ----
void scenario_mixed() {
    std::printf("[A] Mixed concurrency (lifecycle + render + graphics + query + input)...\n");
    Host host;
    constexpr int kIters = 3000;
    std::atomic<bool> go{false};

    auto spin = [&](auto body) {
        while (!go.load(std::memory_order_acquire)) std::this_thread::yield();
        body();
    };

    std::vector<std::thread> threads;

    // Lifecycle churn.
    for (int t = 0; t < 2; ++t)
        threads.emplace_back([&] {
            spin([&] {
                for (int i = 0; i < kIters; ++i) {
                    host.select_content("/synthetic/rom.nro");
                    host.prepare_session();
                    host.start_session();
                    host.run_frame();
                    host.pause_session();
                    host.resume_session();
                    if ((i & 15) == 0) host.stop_session();
                }
            });
        });

    // Render loop (competes with graphics teardown for graphics_mutex_).
    for (int t = 0; t < 2; ++t)
        threads.emplace_back([&] {
            spin([&] {
                for (int i = 0; i < kIters; ++i) {
                    host.run_frame();
                    host.draw_vulkan_frame();
                    host.draw_vulkan_clear_frame();
                }
            });
        });

    // Graphics init/teardown churn (nullptr surface → fast, host fallback).
    threads.emplace_back([&] {
        spin([&] {
            for (int i = 0; i < kIters; ++i) {
                host.initialize_vulkan(nullptr);
                host.shutdown_vulkan();
            }
        });
    });

    // Query threads: must never observe a torn/invalid value.
    for (int t = 0; t < 2; ++t)
        threads.emplace_back([&] {
            spin([&] {
                for (int i = 0; i < kIters; ++i) {
                    CHECK(is_valid_state(host.session_state()), "session_state torn/invalid");
                    const std::string m = host.runtime_metrics();
                    CHECK(m.find("input_mask=0x") != std::string::npos, "metrics missing input_mask");
                    const std::string d = host.diagnostics();
                    CHECK(d.find("Estado:") != std::string::npos, "diagnostics missing Estado");
                    (void)host.runtime_diagnostics();
                    (void)host.presenter_diagnostics();
                    (void)host.vulkan_diagnostics();
                    (void)host.selected_content();
                }
            });
        });

    // Input flood (atomic, lock-free path).
    threads.emplace_back([&] {
        std::mt19937 rng(1234);
        spin([&] {
            for (int i = 0; i < kIters * 4; ++i) {
                const int action = static_cast<int>(rng() % 31);
                host.submit_input(action, (rng() & 1) != 0);
            }
        });
    });

    const auto t0 = std::chrono::steady_clock::now();
    go.store(true, std::memory_order_release);
    for (auto& th : threads) th.join();
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                        std::chrono::steady_clock::now() - t0).count();

    // Host must return to a coherent state after the storm.
    host.stop_session();
    CHECK(is_valid_state(host.session_state()), "final state invalid");
    std::printf("    done in %lld ms, %zu threads\n", static_cast<long long>(ms), threads.size());
}

// ---- Scenario B: atomic correctness of the input mask ----
void scenario_input_mask() {
    std::printf("[B] Input-mask atomicity (concurrent distinct bits)...\n");
    Host host;
    host.stop_session();  // clears mask to 0

    // Deterministic single-thread press/release round-trip.
    for (int b = 0; b < 31; ++b) host.submit_input(b, true);
    {
        const std::string m = host.runtime_metrics();
        const auto pos = m.find("input_mask=0x");
        CHECK(pos != std::string::npos, "no input_mask after press");
        if (pos != std::string::npos) {
            const unsigned long mask = std::stoul(m.substr(pos + 13), nullptr, 16);
            CHECK(mask == 0x7fffffffUL, "press did not set all 31 bits");
        }
    }
    for (int b = 0; b < 31; ++b) host.submit_input(b, false);
    {
        const std::string m = host.runtime_metrics();
        const auto pos = m.find("input_mask=0x");
        if (pos != std::string::npos) {
            const unsigned long mask = std::stoul(m.substr(pos + 13), nullptr, 16);
            CHECK(mask == 0UL, "release did not clear the mask");
        }
    }

    // Concurrent: each thread owns one bit; hammer it, leave it pressed.
    std::atomic<bool> go{false};
    std::vector<std::thread> threads;
    for (int b = 0; b < 31; ++b)
        threads.emplace_back([&, b] {
            while (!go.load(std::memory_order_acquire)) std::this_thread::yield();
            for (int i = 0; i < 5000; ++i) {
                host.submit_input(b, true);
                host.submit_input(b, (i == 4999));  // final write leaves it pressed
            }
        });
    go.store(true, std::memory_order_release);
    for (auto& th : threads) th.join();

    const std::string m = host.runtime_metrics();
    const auto pos = m.find("input_mask=0x");
    CHECK(pos != std::string::npos, "no input_mask after concurrent run");
    if (pos != std::string::npos) {
        const unsigned long mask = std::stoul(m.substr(pos + 13), nullptr, 16);
        CHECK(mask == 0x7fffffffUL, "concurrent bit aggregation lost updates");
    }
    std::printf("    ok\n");
}

// ---- Scenario C: file-descriptor churn must not leak ----
void scenario_fd_churn() {
    std::printf("[C] FD churn via select_content_fd (leak check)...\n");
    const int devnull = ::open("/dev/null", O_RDONLY);
    if (devnull < 0) {
        std::printf("    skipped (no /dev/null)\n");
        return;
    }
    const int baseline = open_fd_count();

    {
        Host host;
        std::atomic<bool> go{false};
        std::vector<std::thread> threads;
        for (int t = 0; t < 4; ++t)
            threads.emplace_back([&] {
                while (!go.load(std::memory_order_acquire)) std::this_thread::yield();
                for (int i = 0; i < 1000; ++i) {
                    host.select_content_fd(devnull);   // dups internally; caller keeps devnull
                    if ((i & 7) == 0) host.select_content("/synthetic/rom.nro");
                    if ((i & 31) == 0) host.stop_session();  // closes owned dup
                    (void)host.selected_content();
                }
            });
        go.store(true, std::memory_order_release);
        for (auto& th : threads) th.join();
        host.stop_session();  // final owned-fd close
    }  // host destroyed → any remaining owned fd closed

    const int after = open_fd_count();
    ::close(devnull);

    if (baseline >= 0 && after >= 0) {
        // Allow a tiny slack for readdir handle timing; a real leak is >> a few.
        CHECK(after <= baseline + 1, "file-descriptor leak under fd churn");
        std::printf("    fd baseline=%d after=%d\n", baseline, after);
    } else {
        std::printf("    skipped fd delta (no /proc)\n");
    }
}

}  // namespace

int main() {
    std::printf("== JNI bridge concurrency / stress (synthetic) ==\n");
    scenario_mixed();
    scenario_input_mask();
    scenario_fd_churn();

    const int failures = g_failures.load(std::memory_order_relaxed);
    if (failures == 0) {
        std::printf("ALL PASS — bridge shared-state is concurrency-safe under stress\n");
        return 0;
    }
    std::printf("FAILURES: %d\n", failures);
    return 1;
}
