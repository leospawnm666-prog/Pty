#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "../audio/audio_backend.h"
#include "../audio/audio_engine.h"
#include <cassert>
#include <memory>
#include <vector>

class FakeSink final : public lg::audio::IAudioSink {
public:
    bool open(const lg::audio::AudioRoute& route, RenderCallback cb, void* user) override { route_=route; cb_=cb; user_=user; return true; }
    size_t submit(const float*, size_t) override { return 0; }
    void close() override { cb_=nullptr; user_=nullptr; }
    lg::audio::AudioRoute route() const override { return route_; }
    size_t pull(float* out, size_t frames) { return cb_ ? cb_(user_, out, frames) : 0; }
private:
    lg::audio::AudioRoute route_{};
    RenderCallback cb_{nullptr}; void* user_{nullptr};
};

int main() {
    lg::audio::DeviceAudioCaps caps{};
    caps.native_sample_rate = 48000; caps.native_burst = 192; caps.max_channels = 2;
    auto sink = std::make_unique<FakeSink>();
    auto* raw = sink.get();
    lg::audio::AudioEngine engine(std::move(sink));
    LG_CHECK(engine.start(caps, 2));
    std::vector<float> pcm(16 * 2, 0.25f);
    LG_CHECK(engine.submit(pcm.data(), 16) == 16);
    std::vector<float> out(16 * 2, 0.0f);
    LG_CHECK(raw->pull(out.data(), 16) == 16);
    LG_CHECK(out[0] == 0.25f);
    engine.on_frame_presented(1, 16666667);
    LG_CHECK(engine.av_drift_ms() < 0.0 || engine.av_drift_ms() >= 0.0);
    engine.stop();
    return 0;
}
