#pragma once
// Shared by test_a64_corpus (interpreter vs native C) and test_interpreter_vs_jit
// (interpreter vs Dynarmic). Runs one function of tests/data/a64_corpus.h on a guest
// machine: code at 0x100000, data at 0x200000, stack below 0x800000, LR = a sentinel.
#include "../memory/address_space.h"
#include "../memory/mmu.h"
#include "../cpu/interpreter.h"
#include "data/a64_corpus.h"

#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace a64_corpus {

constexpr uint64_t kCode = 0x100000, kData = 0x200000, kDataSize = 0x1000;
constexpr uint64_t kStackTop = 0x800000, kSentinel = 0x0F0000;

inline uint8_t data_byte(uint64_t i) { return uint8_t(i * 37 + 11); }

struct Args { uint64_t x[8]{}; };
// Arguments per function: pointers into the data area, counts, scalar inputs.
inline Args args_for(const std::string& name) {
    Args a;
    a.x[0] = kData; a.x[1] = 16;
    if (name == "fib") a.x[0] = 40;
    if (name == "collatz") a.x[0] = 27;
    if (name == "copy_bytes") { a.x[0] = kData + 0x800; a.x[1] = kData; a.x[2] = 64; }
    if (name == "crc32ish") a.x[1] = 100;
    if (name == "clamp_sum") { a.x[1] = 16; a.x[2] = uint64_t(-5); a.x[3] = 0x40000000; }
    if (name == "call_chain" || name == "bitops" || name == "sw" || name == "helper") a.x[0] = 0x123456789ABCDEFull;
    if (name == "divs") { a.x[0] = 1000003; a.x[1] = 97; }
    return a;
}
// Functions returning a 32-bit type: only W0 is defined by the ABI.
inline bool returns_32(const std::string& name) { return name == "crc32ish" || name == "sort3"; }

struct Machine {
    lg::memory::AddressSpace as;
    lg::memory::Mmu mmu;
    // arena = guest memory inside the fastmem arena (the coordinator's layout, and what
    // the JIT's page table covers); otherwise sparse pages (callbacks only).
    // arena: 0 = sparse, 1 = Private arena, 2 = Shared (memfd) arena = JIT fastmem window.
    explicit Machine(const Image& img, int arena = 0) {
        if (arena == 1) as.enable_fastmem(kStackTop - kSentinel, kSentinel);
        if (arena == 2) as.enable_fastmem(kStackTop - kSentinel, kSentinel,
                                          lg::memory::AddressSpace::ArenaBacking::Shared);
        as.map(kCode, 0x10000); as.map(kData, 0x10000); as.map(kStackTop - 0x10000, 0x10000); as.map(kSentinel, 0x1000);
        mmu.map(kCode, kCode, 0x10000, lg::memory::Read | lg::memory::Execute);
        mmu.map(kData, kData, 0x10000, lg::memory::Read | lg::memory::Write);
        mmu.map(kStackTop - 0x10000, kStackTop - 0x10000, 0x10000, lg::memory::Read | lg::memory::Write);
        mmu.map(kSentinel, kSentinel, 0x1000, lg::memory::Read | lg::memory::Execute);
        for (unsigned i = 0; i < img.size; ++i) as.write8(kCode + i, img.bytes[i]);
        as.write32(kSentinel, 0x14000000u);                  // B . (the JIT needs code there)
        for (uint64_t i = 0; i < kDataSize; ++i) as.write8(kData + i, data_byte(i));
    }
    std::vector<uint8_t> data() const {
        std::vector<uint8_t> out(kDataSize);
        for (uint64_t i = 0; i < kDataSize; ++i) out[i] = as.read8(kData + i).value_or(0xEE);
        return out;
    }
};

inline lg::cpu::CpuState initial_state(uint64_t pc, const Args& a) {
    lg::cpu::CpuState s{};
    s.pc = pc; s.sp = kStackTop - 0x100; s.x[30] = kSentinel;
    for (int i = 0; i < 8; ++i) s.x[i] = a.x[i];
    for (int i = 8; i < 30; ++i) s.x[i] = 0x1111111111111111ull * uint64_t(i % 7 + 1);   // garbage
    return s;
}

struct Outcome { bool ok{}; uint64_t x0{}; uint64_t sp{}; std::vector<uint8_t> data; };

inline Outcome run_interpreter(const Image& img, const Function& fn, int arena = 0) {
    Machine m(img, arena);
    lg::cpu::Interpreter cpu(m.as, m.mmu);
    auto s = initial_state(fn.address, args_for(fn.name));
    Outcome o;
    for (uint64_t steps = 0; s.pc != kSentinel && steps < 50'000'000; ++steps)
        if (!cpu.step(s)) return o;
    o.ok = s.pc == kSentinel;
    o.x0 = s.x[0]; o.sp = s.sp; o.data = m.data();
    return o;
}

} // namespace a64_corpus
