#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <cstring>
#include <string>
#include <vector>
#include "../loader/romfs.h"
static void put32(std::vector<unsigned char>&b,size_t p,uint32_t v){for(int i=0;i<4;i++)b[p+i]=static_cast<unsigned char>(v>>(8*i));}
static void put64(std::vector<unsigned char>&b,size_t p,uint64_t v){for(int i=0;i<8;i++)b[p+i]=static_cast<unsigned char>(v>>(8*i));}
int main(){
 std::vector<unsigned char>d(0x200,0);
 put32(d,0,0x28); put32(d,4,0x28); put32(d,8,4); put32(d,12,0x2c); put32(d,16,0x18); put32(d,20,0x44); put32(d,24,4); put32(d,28,0x5c); put32(d,32,0x30); put32(d,36,0x8c);
 put32(d,0x2c,0xffffffff);put32(d,0x30,0xffffffff);put32(d,0x34,0xffffffff);put32(d,0x38,0);put32(d,0x3c,0xffffffff);put32(d,0x40,0);put32(d,0x44,0);
 put32(d,0x5c,0);put32(d,0x60,0xffffffff);put64(d,0x64,0);put64(d,0x6c,5);put32(d,0x74,0xffffffff);put32(d,0x78,16);
 const char* n="test.bin"; for(int i=0;i<8;i++){d[0x7c+i*2]=static_cast<unsigned char>(n[i]);d[0x7c+i*2+1]=0;}
 const char data[]="hello";std::memcpy(d.data()+0x8c,data,5);
 auto parsed=lg::loader::RomFsImage::parse(d);LG_CHECK(parsed.ok());auto x=parsed.value().read_file("/test.bin");LG_CHECK(x.ok()&&std::string(x.value().begin(),x.value().end())=="hello");return 0;}
