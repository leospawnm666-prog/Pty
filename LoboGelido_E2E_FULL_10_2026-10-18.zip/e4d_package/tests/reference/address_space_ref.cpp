#include <cstring>
#include <limits>
#include <algorithm>
#include <cerrno>
#include <new>

#if defined(__linux__) || defined(__ANDROID__)
#  include <sys/mman.h>
#  include <unistd.h>
#  define LOBO_HAS_MMAP 1
#else
#  define LOBO_HAS_MMAP 0
#endif

#include "address_space_ref.h"
#include "../../memory/page_pool.h"

namespace lg::memory::reference {

void AddressSpaceRef::release_fastmem() noexcept {
    if (!fastmem_) return;
#if LOBO_HAS_MMAP
    if (fastmem_is_mmap_) {
        ::munmap(fastmem_, static_cast<size_t>(fastmem_size_));
    } else
#endif
    {
        delete[] fastmem_;
    }
    fastmem_ = nullptr;
    fastmem_is_mmap_ = false;
    fastmem_size_ = 0;
    fastmem_guest_base_ = 0;
    fastmem_mapped_pages_.clear();
}

bool AddressSpaceRef::enable_fastmem(uint64_t size, uint64_t guest_base) {
    if (size == 0 || (size & (P - 1)) != 0) return false;
    if (size > (1ull << 32)) return false; // bounded mobile-friendly arena

    release_fastmem();

    uint8_t* storage = nullptr;
    bool used_mmap = false;
#if LOBO_HAS_MMAP
    // Demand-zero anonymous mapping: physical pages only fault in on first touch.
    void* mapped = ::mmap(nullptr, static_cast<size_t>(size),
                          PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mapped != MAP_FAILED) {
        storage = static_cast<uint8_t*>(mapped);
        used_mmap = true;
    }
#endif
    if (!storage) {
        storage = new (std::nothrow) uint8_t[static_cast<size_t>(size)];
        if (!storage) return false;
        std::memset(storage, 0, static_cast<size_t>(size));
    }

    fastmem_ = storage;
    fastmem_is_mmap_ = used_mmap;
    fastmem_size_ = size;
    fastmem_mapped_pages_.assign(static_cast<size_t>(size / P), 0);
    fastmem_guest_base_ = guest_base;
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

bool AddressSpaceRef::fastmem_contains(uint64_t a, uint64_t size) const noexcept {
    if (!fastmem_ || size == 0 || a < fastmem_guest_base_) return false;
    const uint64_t off = a - fastmem_guest_base_;
    return off < fastmem_size_ && size <= fastmem_size_ - off;
}

bool AddressSpaceRef::map(uint64_t g, uint64_t size) {
    if (!size || g > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t first = g & ~(P - 1);
    const uint64_t pages = ((size - 1) / P) + 1;
    if (pages - 1 > (std::numeric_limits<uint64_t>::max() - first) / P) return false;
    for (uint64_t i = 0; i < pages; ++i) {
        const uint64_t p = first + i * P;
        if (pages_.contains(p) || mapped_pages_.contains(p)) return false;
    }
    // Acquire pages first so a mid-loop OOM does not leave a partial map.
    std::vector<std::pair<uint64_t, uint8_t*>> acquired;
    acquired.reserve(static_cast<size_t>(pages));
    try {
        for (uint64_t i = 0; i < pages; ++i) {
            const uint64_t p = first + i * P;
            if (fastmem_contains(p, P)) {
                acquired.emplace_back(p, nullptr); // fastmem path
            } else {
                acquired.emplace_back(p, PagePool::instance().acquire());
            }
        }
    } catch (...) {
        for (auto& [_, ptr] : acquired) {
            if (ptr) PagePool::instance().release(ptr);
        }
        return false;
    }
    for (auto& [p, ptr] : acquired) {
        mapped_pages_.insert(p);
        if (ptr) {
            pages_.emplace(p, ptr);
        } else {
            fastmem_mapped_pages_[static_cast<size_t>((p - fastmem_guest_base_) / P)] = 1;
        }
    }
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

bool AddressSpaceRef::unmap(uint64_t g, uint64_t size) {
    if (!size || g > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t first = g & ~(P - 1);
    const uint64_t pages = ((size - 1) / P) + 1;
    if (pages - 1 > (std::numeric_limits<uint64_t>::max() - first) / P) return false;
    for (uint64_t i = 0; i < pages; ++i) {
        const uint64_t p = first + i * P;
        auto it = pages_.find(p);
        if (it != pages_.end()) {
            PagePool::instance().release(it->second);
            pages_.erase(it);
        }
        mapped_pages_.erase(p);
        if (fastmem_contains(p, P)) {
            fastmem_mapped_pages_[static_cast<size_t>((p - fastmem_guest_base_) / P)] = 0;
        }
    }
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

uint8_t* AddressSpaceRef::host_ptr(uint64_t a) {
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        auto page = a & ~(P - 1);
        const auto page_index = static_cast<size_t>((page - fastmem_guest_base_) / P);
        if (page_index < fastmem_mapped_pages_.size() && fastmem_mapped_pages_[page_index])
            return fastmem_ + (a - fastmem_guest_base_);
    }
    auto it = pages_.find(a & ~(P - 1));
    return it == pages_.end() ? nullptr : it->second + (a & (P - 1));
}

const uint8_t* AddressSpaceRef::host_ptr(uint64_t a) const {
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        auto page = a & ~(P - 1);
        const auto page_index = static_cast<size_t>((page - fastmem_guest_base_) / P);
        if (page_index < fastmem_mapped_pages_.size() && fastmem_mapped_pages_[page_index])
            return fastmem_ + (a - fastmem_guest_base_);
    }
    auto it = pages_.find(a & ~(P - 1));
    return it == pages_.end() ? nullptr : it->second + (a & (P - 1));
}

std::optional<uint8_t> AddressSpaceRef::read8(uint64_t a) const {
    auto p = host_ptr(a);
    return p ? std::optional<uint8_t>(*p) : std::nullopt;
}

std::optional<uint32_t> AddressSpaceRef::read32(uint64_t a) const {
    if (a > std::numeric_limits<uint64_t>::max() - 3) return std::nullopt;
    if (const auto* p = host_ptr(a); p && ((a & (P - 1)) <= P - 4)) {
        uint32_t value{};
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    uint32_t value{};
    for (unsigned i = 0; i < 4; ++i) {
        const auto byte = read8(a + i);
        if (!byte) return std::nullopt;
        value |= uint32_t(*byte) << (8 * i);
    }
    return value;
}

std::optional<uint64_t> AddressSpaceRef::read64(uint64_t a) const {
    if (a > std::numeric_limits<uint64_t>::max() - 7) return std::nullopt;
    if (const auto* p = host_ptr(a); p && ((a & (P - 1)) <= P - 8)) {
        uint64_t value{};
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    uint64_t value{};
    for (unsigned i = 0; i < 8; ++i) {
        const auto byte = read8(a + i);
        if (!byte) return std::nullopt;
        value |= uint64_t(*byte) << (8 * i);
    }
    return value;
}

void AddressSpaceRef::write8(uint64_t a, uint8_t v) {
    if (auto p = host_ptr(a)) {
        *p = v;
        write_epoch_.fetch_add(1, std::memory_order_relaxed);
    }
}

void AddressSpaceRef::write32(uint64_t a, uint32_t v) {
    if (a > std::numeric_limits<uint64_t>::max() - 3) return;
    if (auto p = host_ptr(a); p && ((a & (P - 1)) <= P - 4)) {
        std::memcpy(p, &v, 4);
        write_epoch_.fetch_add(1, std::memory_order_relaxed);
        return;
    }
    for (unsigned i = 0; i < 4; i++) write8(a + i, uint8_t(v >> (8 * i)));
}

void AddressSpaceRef::write64(uint64_t a, uint64_t v) {
    if (a > std::numeric_limits<uint64_t>::max() - 7) return;
    if (auto p = host_ptr(a); p && ((a & (P - 1)) <= P - 8)) {
        std::memcpy(p, &v, 8);
        write_epoch_.fetch_add(1, std::memory_order_relaxed);
        return;
    }
    for (unsigned i = 0; i < 8; i++) write8(a + i, uint8_t(v >> (8 * i)));
}

void AddressSpaceRef::clear() noexcept {
    for (auto& [_, ptr] : pages_) {
        PagePool::instance().release(ptr);
    }
    pages_.clear();
    mapped_pages_.clear();
    std::fill(fastmem_mapped_pages_.begin(), fastmem_mapped_pages_.end(), uint8_t{0});
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
}

} // namespace lg::memory
