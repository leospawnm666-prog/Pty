#pragma once
// TEST ORACLE ONLY (Regla de Oro): the per-page Mmu (unordered_map, one node per page)
// as it was before P2 phase C, preserved verbatim except for the class rename. Used by
// test_mmu_regions for differential testing. Never linked into the app.
#include <cstdint>
#include <array>
#include <unordered_map>
#include "../../core/result.h"
#include "../../memory/mmu.h"   // Permission, Translation (shared types)

namespace lg::memory::reference {

class MmuRef {
public:
    static constexpr uint64_t PageBits = 12;
    static constexpr uint64_t PageSize = 1ull << PageBits;
    static constexpr uint64_t PageMask = PageSize - 1;
    bool map(uint64_t virtual_base, uint64_t physical_base, uint64_t size, uint32_t permissions);
    bool unmap(uint64_t virtual_base, uint64_t size);
    void invalidate_all() noexcept;
    void clear() noexcept;
    void invalidate_page(uint64_t virtual_address) noexcept;
    uint64_t generation() const noexcept { return generation_; }
    core::Result<Translation> translate(uint64_t virtual_address, bool write, bool execute=false) const;
private:
    struct Entry { uint64_t physical{}; uint32_t permissions{}; };
    // Generation-stamped TLB: invalidate_all is O(1) (bump generation_), not O(1024).
    struct TlbEntry {
        uint64_t virtual_page{};
        uint64_t physical_page{};
        uint32_t permissions{};
        uint64_t gen{};
    };
    std::unordered_map<uint64_t, Entry> page_table_;
    mutable std::array<TlbEntry, 1024> tlb_{};
    uint64_t generation_{1};
    static size_t slot(uint64_t vpn) noexcept { return static_cast<size_t>((vpn * 11400714819323198485ull) >> 54); }
};

} // namespace lg::memory::reference
