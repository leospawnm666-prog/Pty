#pragma once
// P3.0-A: VERBATIM copy of NsoLoader::parse() (and its helpers) as it was before the .bss
// fix, kept only as the oracle of the differential test (tests/test_nso_loader.cpp): for
// every input it accepts WITHOUT a .bss, the fixed parser must return an identical image.
// Do not edit; do not link into the product.
#include <vector>
#include "../../loader/nso_loader.h"

namespace lg::loader::ref {
core::Result<NsoImage> parse(const std::vector<uint8_t>& file);
}
