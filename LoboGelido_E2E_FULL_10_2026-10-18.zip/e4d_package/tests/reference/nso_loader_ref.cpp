// P3.0-A: verbatim pre-fix NsoLoader::parse (see nso_loader_ref.h).
#include "nso_loader_ref.h"

#include <algorithm>
#include <cstring>
#include <limits>
#include <string>
#include "../../memory/mmu.h"

namespace lg::loader::ref {
namespace {
uint32_t u32(const uint8_t* p) { return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24); }

core::Result<std::vector<uint8_t>> lz4_decompress_block(const uint8_t* src, size_t src_size, size_t dst_size) {
    std::vector<uint8_t> dst(dst_size);
    size_t si = 0, di = 0;
    while (si < src_size) {
        const uint8_t token = src[si++];
        size_t literal_len = token >> 4;
        if (literal_len == 15) {
            uint8_t b = 255;
            while (b == 255) {
                if (si >= src_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 literal length is truncated");
                b = src[si++]; literal_len += b;
            }
        }
        if (literal_len > src_size - si || literal_len > dst_size - di)
            return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 literal exceeds section bounds");
        std::memcpy(dst.data() + di, src + si, literal_len);
        si += literal_len; di += literal_len;
        if (si == src_size) break;
        if (si + 2 > src_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match offset is truncated");
        const uint16_t offset = uint16_t(src[si]) | (uint16_t(src[si + 1]) << 8); si += 2;
        if (offset == 0 || offset > di) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match offset is invalid");
        size_t match_len = token & 0x0F;
        if (match_len == 15) {
            uint8_t b = 255;
            while (b == 255) {
                if (si >= src_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match length is truncated");
                b = src[si++]; match_len += b;
            }
        }
        match_len += 4;
        if (match_len > dst_size - di) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match exceeds section bounds");
        for (size_t n = 0; n < match_len; ++n) { const uint8_t value = dst[di - offset]; dst[di++] = value; }
    }
    if (di != dst_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 output size does not match header");
    return core::Result<std::vector<uint8_t>>::Ok(std::move(dst));
}

core::Result<std::vector<uint8_t>> section(const std::vector<uint8_t>& file, uint32_t file_offset, uint32_t file_size, uint32_t memory_size, bool compressed, const char* name) {
    if (uint64_t(file_offset) > file.size() || uint64_t(file_size) > file.size() - file_offset)
        return core::Result<std::vector<uint8_t>>::Error((std::string("NSO ") + name + " file range is invalid").c_str());
    if (memory_size == 0) return core::Result<std::vector<uint8_t>>::Ok({});
    if (!compressed) {
        if (file_size != memory_size) return core::Result<std::vector<uint8_t>>::Error((std::string("NSO ") + name + " uncompressed size mismatch").c_str());
        return core::Result<std::vector<uint8_t>>::Ok(std::vector<uint8_t>(file.begin() + file_offset, file.begin() + file_offset + file_size));
    }
    return lz4_decompress_block(file.data() + file_offset, file_size, memory_size);
}
}

core::Result<NsoImage> parse(const std::vector<uint8_t>& file) {
    if (file.size() < 0x100 || std::memcmp(file.data(), "NSO0", 4) != 0)
        return core::Result<NsoImage>::Error("invalid NSO header");
    const uint32_t version = u32(file.data() + 4);
    const uint32_t flags = u32(file.data() + 0x0C);
    if (version != 0) return core::Result<NsoImage>::Error("unsupported NSO version");
    if (flags & (1u << 7)) return core::Result<NsoImage>::Error("NSO ZBIC compression is not implemented in this loader");

    struct H { uint32_t fo, mo, size, csize; const char* name; uint32_t perms; } h[3] = {
        {u32(file.data()+0x10), u32(file.data()+0x14), u32(file.data()+0x18), u32(file.data()+0x60), "text", memory::Read|memory::Execute|memory::User},
        {u32(file.data()+0x20), u32(file.data()+0x24), u32(file.data()+0x28), u32(file.data()+0x64), "rodata", memory::Read|memory::User},
        {u32(file.data()+0x30), u32(file.data()+0x34), u32(file.data()+0x38) + u32(file.data()+0x3C), u32(file.data()+0x68), "data", memory::Read|memory::Write|memory::User}
    };
    NsoImage image{}; image.flags = flags; std::memcpy(image.module_id.data(), file.data()+0x40, 0x20);
    uint64_t base = std::numeric_limits<uint64_t>::max(), end = 0;
    for (int i=0;i<3;i++) {
        if (h[i].size == 0) continue;
        if ((h[i].mo & 0xFFFu) != 0) return core::Result<NsoImage>::Error("NSO segment memory offset is not page aligned");
        if (uint64_t(h[i].mo) + h[i].size < h[i].mo) return core::Result<NsoImage>::Error("NSO segment address overflow");
        const bool compressed = (flags & (1u << i)) != 0;
        auto bytes = section(file, h[i].fo, h[i].csize, h[i].size, compressed, h[i].name);
        if (!bytes.ok()) return core::Result<NsoImage>::Error(bytes.error().c_str());
        NsoSegmentImage seg{}; seg.name=h[i].name; seg.memory_offset=h[i].mo; seg.memory_size=h[i].size; seg.permissions=h[i].perms; seg.bytes=std::move(bytes.value());
        image.segments.push_back(std::move(seg)); base=std::min(base,uint64_t(h[i].mo)); end=std::max(end,uint64_t(h[i].mo)+h[i].size);
    }
    if (image.segments.empty() || end <= base) return core::Result<NsoImage>::Error("NSO has no loadable segments");
    image.image_base=base; image.image_size=end-base; image.entry_point=image.segments.front().memory_offset;
    return core::Result<NsoImage>::Ok(std::move(image));
}

} // namespace lg::loader::ref
