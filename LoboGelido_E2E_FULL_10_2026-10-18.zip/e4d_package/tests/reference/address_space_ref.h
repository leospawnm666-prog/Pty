#pragma once
// TEST ORACLE ONLY (Regla de Oro): the pre-bitmap AddressSpace, preserved verbatim
// except for the namespace/class rename, used by test_address_space_bitmap for
// differential testing. Never linked into the app.
#include <cstdint>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <atomic>
#include <memory>
namespace lg::memory::reference {
class AddressSpaceRef { public:
    AddressSpaceRef() = default;
    explicit AddressSpaceRef(uint64_t fastmem_size) { enable_fastmem(fastmem_size); }
    ~AddressSpaceRef() { clear(); release_fastmem(); }

    AddressSpaceRef(const AddressSpaceRef&) = delete;
    AddressSpaceRef& operator=(const AddressSpaceRef&) = delete;
    AddressSpaceRef(AddressSpaceRef&&) = delete;
    AddressSpaceRef& operator=(AddressSpaceRef&&) = delete;

    bool map(uint64_t guest, uint64_t size); bool unmap(uint64_t guest, uint64_t size); void clear() noexcept;
    std::optional<uint8_t> read8(uint64_t a) const; std::optional<uint32_t> read32(uint64_t a) const; std::optional<uint64_t> read64(uint64_t a) const;
    void write8(uint64_t a,uint8_t v); void write32(uint64_t a,uint32_t v); void write64(uint64_t a,uint64_t v);
    uint8_t* host_ptr(uint64_t a); const uint8_t* host_ptr(uint64_t a) const;
    uint64_t write_epoch() const noexcept { return write_epoch_.load(std::memory_order_relaxed); }

    // Optional contiguous guest arena used by JIT fastmem backends. It is deliberately
    // separate from the page map so correctness never depends on fastmem being enabled.
    // Backed by anonymous mmap so untouched regions cost almost no physical RAM.
    bool enable_fastmem(uint64_t size, uint64_t guest_base = 0);
    bool has_fastmem() const noexcept { return fastmem_ != nullptr; }
    uint64_t fastmem_size() const noexcept { return fastmem_size_; }
    uint64_t fastmem_guest_base() const noexcept { return fastmem_guest_base_; }
    bool fastmem_contains(uint64_t a, uint64_t size = 1) const noexcept;
    uint8_t* fastmem_base() noexcept { return fastmem_; }
    const uint8_t* fastmem_base() const noexcept { return fastmem_; }

    /** Diagnostics for the sparse page pool. */
    std::size_t sparse_page_count() const noexcept { return pages_.size(); }
private:
    void release_fastmem() noexcept;

    // Sparse pages: host pointer owned by PagePool (not std::vector).
    std::unordered_map<uint64_t, uint8_t*> pages_;
    std::unordered_set<uint64_t> mapped_pages_;
    uint8_t* fastmem_{nullptr};
    bool fastmem_is_mmap_{false};
    std::vector<uint8_t> fastmem_mapped_pages_;
    uint64_t fastmem_size_{};
    uint64_t fastmem_guest_base_{};
    static constexpr uint64_t P=4096;
    std::atomic<uint64_t> write_epoch_{0};
};
}
