// P3.5-H1, hito H5: the real homebrew. tools/homebrew/hola_libnx/source/main.c, unmodified,
// linked with the whole devkitPro runtime built from source (libnx 146c3d1, devkitPro newlib
// with libsysbase, compiler-rt; clang/lld: see data/nro/h5/gen_h5_fixture.sh).
//  H5a on the JIT (plain, fastmem, fastmem + 16 KiB host pages): the guest log is exactly the
//      H5 criterion (tools/homebrew/hola_libnx/README.md) and the session ends in exit=guest
//      code=0 with no IPC session left
//  H5b on the interpreter engines: it stops at the first AdvSIMD/FP instruction, and the error
//      and the summary say so (the program itself is the same)
#include "lg_check.h"
#include "../memory/address_space.h"
#include "../runtime/runtime_coordinator.h"
#include "data/nro/h5/h5_fixture.h"

#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace {
namespace fs = std::filesystem;
using lg::runtime::RuntimeCoordinator;
using lg::runtime::State;
constexpr uint64_t MiB = 1ull << 20;

std::string write_nro() {
    const auto p = fs::temp_directory_path() / "lobo_p35h1_hola_libnx.nro";
    std::ofstream(p, std::ios::binary | std::ios::trunc)
        .write(reinterpret_cast<const char*>(nro_fixtures::h5_hola_libnx), long(sizeof nro_fixtures::h5_hola_libnx));
    return p.string();
}
struct Engine { const char* name; bool force_interpreter; bool fastmem; size_t host_page; };
std::vector<Engine> engines() {
    std::vector<Engine> e = {{"Block", true, false, 0}, {"Block, 16 KiB host pages", true, false, 16384}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    e.push_back({"JIT", false, false, 0});
    e.push_back({"JIT + fastmem", false, true, 0});
    e.push_back({"JIT + fastmem, 16 KiB host pages", false, true, 16384});
#endif
    return e;
}
std::string run_to_end(RuntimeCoordinator& rt) {
    for (int i = 0; i < 5'000'000 && rt.state() == State::Running; ++i) {
        const auto r = rt.run_frame(rt.entry_point());
        if (!r.ok()) return r.error();
    }
    return {};
}
int64_t wall_now() {
    return std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}

void h5() {
    std::printf("[H5] hola_libnx (devkitPro runtime) on every engine\n");
    const std::string path = write_nro();
    for (const auto& e : engines()) {
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            rt.set_content_display_name("hola_libnx.nro");
            const int64_t t0 = wall_now();
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            const auto start = std::chrono::steady_clock::now();
            const std::string err = run_to_end(rt);
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            const int64_t t1 = wall_now() + 1;
            const std::string log = rt.guest_log();
            if (!e.force_interpreter) {
                long long t = -1;
                char tail[16] = {};
                const bool parsed = std::sscanf(log.c_str(), "Hola desde libnx: argc=1 HOS=5.1.0\ntime=%lld\n%15[^\n]", &t, tail) == 2;
                const bool ok = err.empty() && rt.state() == State::Stopped && rt.guest_exit().has_code && rt.guest_exit().code == 0 &&
                                parsed && t >= t0 && t <= t1 && std::string(tail) == "adios" &&
                                log == "Hola desde libnx: argc=1 HOS=5.1.0\ntime=" + std::to_string(t) + "\nadios\n";
                if (!ok) std::printf("  [%s] err='%s' log:\n%s\n%s\n", e.name, err.c_str(), log.c_str(), rt.diagnostics().c_str());
                LG_CHECK(ok);
                LG_CHECK(rt.ipc_for_testing().session_count() == 0);
                LG_CHECK(rt.guest_summary().rfind("Estado: terminado (código 0)\nÚltimo log: adios\n", 0) == 0);
                std::printf("  %-34s %7.1f ms  exit=guest code=0  SendSyncRequest=%llu\n", e.name, ms,
                            (unsigned long long)rt.svc_calls(0x21));
            } else {
                const auto f = rt.last_guest_fault();
                const bool ok = rt.state() == State::Error && log.empty() && f.kind == lg::cpu::ExceptionKind::UndefinedInstruction &&
                                err.find(" [AdvSIMD/FP: no soportada por el intérprete; usa la JIT]") != std::string::npos;
                if (!ok) std::printf("  [%s] %s\n", e.name, err.c_str());
                LG_CHECK(ok);
                std::printf("  %-34s %s\n", e.name, err.c_str());
            }
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}
} // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    h5();
    std::puts("h5 ok");
    return 0;
}
