#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include "../core/session.h"

int main() {
    lg::core::Session s;
    LG_CHECK(s.prepare().ok());
    LG_CHECK(s.start().ok());
    LG_CHECK(s.pause().ok());
    LG_CHECK(s.resume().ok());
    LG_CHECK(s.stop().ok());
    LG_CHECK(s.prepare().ok());
    return 0;
}
