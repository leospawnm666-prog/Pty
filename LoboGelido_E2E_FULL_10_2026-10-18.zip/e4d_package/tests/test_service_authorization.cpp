#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <iostream>
#include "../system/kernel.h"
#include "../system/hl_services.h"

int main() {
    lg::system::Kernel kernel;
    LG_CHECK(kernel.services().register_service(
        "secure:", lg::system::make_system_service(kernel.scheduler()), "svc:secure"));

    const auto process_a = kernel.processes().create("a", "/romfs/a.nro", 0x1000, 0x1000, 0x1000, 1);
    const auto process_b = kernel.processes().create("b", "/romfs/b.nro", 0x2000, 0x2000, 0x1000, 1);
    LG_CHECK(process_a && process_b && process_a != process_b);

    LG_CHECK(kernel.connect_service(process_a, "secure:") == nullptr);
    LG_CHECK(kernel.connect_service(process_b, "secure:") == nullptr);

    LG_CHECK(kernel.capabilities().grant(process_a, "svc:secure"));
    LG_CHECK(kernel.connect_service(process_a, "secure:") != nullptr);
    LG_CHECK(kernel.connect_service(process_b, "secure:") == nullptr);

    LG_CHECK(kernel.capabilities().revoke(process_a, "svc:secure"));
    LG_CHECK(kernel.connect_service(process_a, "secure:") == nullptr);

    LG_CHECK(kernel.capabilities().grant(process_b, "svc:other"));
    LG_CHECK(kernel.connect_service(process_b, "secure:") == nullptr);

    std::cout << "service authorization ok\n";
}
