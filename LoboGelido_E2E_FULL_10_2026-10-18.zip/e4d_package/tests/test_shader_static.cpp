// P4.1 (P4_DISENO.md §5.1, §2): recompiler checks that need no GPU.
//  T1  the decoder agrees with envydis on 2368 words (every encoding: its value + 7 random fills)
//  M1  decoding coverage: each of the 296 encodings decodes to itself; translation coverage:
//      a one-instruction program per encoding; every P4.1 form translates, the rest fail with an
//      explicit "fuera de P4.1" error (never a silent translation); percentages printed
//  M4  every emitted module (M1 programs, T2 cases, T3 corpus) is valid SPIR-V: header, ids,
//      and, given a spirv-val path as argv[1], `spirv-val --target-env vulkan1.1`
//  D1  translation is deterministic and thread-safe (4 threads translate the corpus at once)
//  E1  errors: undecodable word, branch out of the program, missing constant buffer binding,
//      unsupported stage, empty program, untraceable global memory
// P4.2 (P4_2_DISENO.md §4): M4 and D1 also over every stage of the graphics corpus (T3-G) and the
// T2-G cases; M1 reports the P4.2 forms (only translatable in graphics stages); E1 adds the SPH
// and stage errors.
// P4.3 (P4_3_DISENO.md §5): the same over the T2-T cases and the texture corpus (T3-T); M1 reports
// the texture and image forms; E1 adds their explicit errors.
#include "lg_check.h"
#include "shader/dksh.h"
#include "shader/t1_golden.h"
#include "shader/t2_fixtures.h"
#include "shader/t3_fixtures.h"
#include "shader/t2g_fixtures.h"
#include "shader/t3g_fixtures.h"
#include "shader/t3g_runner.h"
#include "shader/t2t_fixtures.h"
#include "shader/t3t_fixtures.h"
#include "shader/t3tg_fixtures.h"
#include "shader/t2x_fixtures.h"
#include "shader/t3x_fixtures.h"
#include "shader/t3xg_fixtures.h"
#include "../shader/maxwell/isa.h"
#include "../shader/translate.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <set>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>

namespace {

using lg::shader::ShaderInfo;
using lg::shader::translate;
namespace isa = lg::shader::maxwell;

constexpr uint64_t kSched = 0x001f8000fc0007e0ull;
constexpr uint64_t kExit = 0xe30000000007000full;
constexpr uint64_t kNop = 0x50b0000000070f00ull;

ShaderInfo base_info() {
    ShaderInfo info;
    info.local_size[0] = 32;
    info.shared_memory_bytes = 256;
    info.local_memory_bytes = 64;
    for (uint32_t b = 0; b < 18; ++b) info.cbufs.push_back({b, 32 + b});
    return info;
}

std::string spirv_val;   // optional
uint32_t modules_checked = 0;
std::vector<bool> translated_enc(296, false);   // encodings emitted semantically, without soft NOP fallback

void mark_program(std::span<const uint64_t> code, const lg::shader::TranslationResult& result) {
    // Coverage means that the translator emitted semantics, not that soft mode kept
    // the module alive by replacing an instruction with NOP.
    if (!result.ok || result.soft_skipped != 0 || result.undecoded_soft != 0) return;
    for (size_t i = 0; i < code.size(); ++i) {
        if (isa::is_sched_slot(i)) continue;
        if (const isa::Encoding* e = isa::find_encoding(code[i])) translated_enc[isa::encoding_index(e)] = true;
    }
}

void check_module(const std::vector<uint32_t>& m, const std::string& what) {
    LG_CHECK(m.size() > 5);
    LG_CHECK(m[0] == 0x07230203u);
    LG_CHECK(m[1] == 0x00010300u);
    LG_CHECK(m[4] == 0);
    // every instruction's word count stays inside the module; every result id < bound
    size_t i = 5;
    while (i < m.size()) {
        const uint32_t wc = m[i] >> 16;
        LG_CHECK(wc >= 1 && i + wc <= m.size());
        i += wc;
    }
    LG_CHECK(i == m.size());
    ++modules_checked;
    if (spirv_val.empty()) return;
    const std::string path = "/tmp/lg_shader_m4_" + std::to_string(::getpid()) + ".spv";
    {
        std::ofstream f(path, std::ios::binary);
        f.write(reinterpret_cast<const char*>(m.data()), static_cast<std::streamsize>(m.size() * 4));
    }
    const std::string cmd = spirv_val + " --target-env vulkan1.1 " + path + " > /dev/null 2>&1";
    const int rc = std::system(cmd.c_str());
    if (rc != 0) {
        std::fprintf(stderr, "M4: spirv-val rechaza %s (%s)\n", what.c_str(), path.c_str());
        LG_CHECK(rc == 0);
    }
    std::remove(path.c_str());
}

// ---------------------------------------------------------------- T1
void t1() {
    uint32_t ok = 0;
    for (const auto& g : lg_test::t1::kGolden) {
        const isa::Encoding* e = isa::find_encoding(g.word);
        LG_CHECK(e != nullptr);
        if (std::strcmp(e->mnemonic, g.mnemonic) != 0) {
            std::fprintf(stderr, "T1: 0x%016llx: nuestro %s, envydis %s\n", static_cast<unsigned long long>(g.word),
                         e->mnemonic, g.mnemonic);
            LG_CHECK(false);
        }
        ++ok;
    }
    std::printf("T1: %u/%zu palabras decodificadas igual que envydis\n", ok, std::size(lg_test::t1::kGolden));
}

// ---------------------------------------------------------------- M1
const std::set<std::string> kP41 = {
    "mov", "mov32i", "cs2r", "sel", "iadd", "iadd3", "iadd32i", "iscadd", "iscadd32i", "imad", "imad32i", "imul",
    "imul32i", "xmad", "imnmx", "lop", "lop3", "lop32i", "shl", "shr", "shf", "bfe", "bfi", "flo", "popc", "prmt",
    "lea", "isetp", "iset", "icmp", "fadd", "fadd32i", "fmul", "fmul32i", "ffma", "ffma32i", "fmnmx", "fsetp", "fset",
    "fcmp", "mufu", "rro", "f2f", "f2i", "i2f", "i2i", "psetp", "pset", "p2r", "r2p", "ldg", "stg", "ld", "st",
    "atom", "atoms", "red", "bar", "membar", "depbar", "bra", "brx", "ssy", "sync", "pbk", "brk", "pcnt", "cont",
    "exit", "kil", "nop", "cal", "ret", "jmp", "jmx", "jcal", "pret", "cctl", "cctll", "cctlt"};

// P4.2 forms: attribute memory, interpolation, GS output, quad operations (graphics stages)
const std::set<std::string> kP42 = {"ipa", "out", "isberd", "al2p", "shfl", "fswzadd"};

// P4.3 forms: textures and images
const std::set<std::string> kP43 = {"tex", "texs", "tld", "tlds", "tld4", "tld4s", "txd", "tmml", "txq",
                                    "suld", "sust", "suatom", "sured"};

// P4.1 mnemonics whose encoding here is a form P4.1 leaves out (reported, not silent):
// attribute memory (ld/st a[], P4.2), LDG with predicate output, 64-bit/double forms, BAR other
// than SYNC, constant-buffer branch targets, P2R/R2P on CC, extended IMNMX.
bool known_out_of_scope(const isa::Encoding& e) {
    const std::string n = e.mnemonic;
    if ((n == "ld" || n == "st") && e.has("AMEM")) return true;
    if (n == "ldg" && e.has("NCGMEM_20")) return true;
    if (e.has("C36_RZ_S16_20") || ((n == "brx" || n == "jmx") && e.has("C36_08_S16_20"))) return true;
    if (n == "bar") return true;   // the value word encodes BAR.RED.POPC (mode 0); BAR.SYNC is T2's
    return false;
}

void m1() {
    const auto all = isa::encodings();
    LG_CHECK(all.size() == 296);
    uint32_t decoded = 0, translated = 0, out_of_scope = 0, in_list = 0, in_list_ok = 0;
    std::set<std::string> mnems, mnems_ok;
    for (const isa::Encoding& e : all) {
        // decoding: the value word decodes to this row (no row shadows another)
        LG_CHECK(isa::find_encoding(e.value) == &e);
        ++decoded;
        mnems.insert(e.mnemonic);
        // translation: a one-instruction program (guard PT, registers R0, c0[0], offsets 0), after a
        // read of the global buffer table (mov r0, c0[0x140]) so global memory forms are traceable
        uint64_t w = e.value;
        if (e.predicated) w |= uint64_t{7} << 16;
        const uint64_t mov_table = 0x4c98000000000000ull | (uint64_t{0x140 / 4} << 20) | (uint64_t{0xf} << 39) | (uint64_t{7} << 16);
        const std::vector<uint64_t> prog = {kSched, mov_table, w, kExit};
        ShaderInfo info = base_info();
        // M1 is semantic coverage. Keep the product's soft-playable default for corpus
        // tests, but never count a soft NOP as a translated ISA encoding.
        info.soft_unknown_as_nop = false;
        info.soft_undecodable_as_skip = false;
        const auto r = translate(prog, info);
        const bool listed = kP41.count(e.mnemonic) != 0;
        in_list += listed;
        if (r.ok) {
            ++translated;
            in_list_ok += listed;
            translated_enc[isa::encoding_index(&e)] = true;
            mnems_ok.insert(e.mnemonic);
            check_module(r.spirv, std::string("M1 ") + e.mnemonic + " " + e.operands);
        } else {
            ++out_of_scope;
            const bool explicit_error = r.error.find("0x0010: ") == 0;
            if (!explicit_error) std::fprintf(stderr, "M1: error sin dirección: %s: %s\n", e.mnemonic, r.error.c_str());
            LG_CHECK(explicit_error);
            // a P4.1 mnemonic may still fail here: its value word selects a sub-mode outside P4.1
            // (ATOMS.CAST, BAR.RED...), or the form itself is out (known_out_of_scope); the error must
            // then say so explicitly. The P4.1 forms themselves are exercised by T2.
            if (listed) {
                // P4.4: or a sub-form with no public semantics / that needs a device feature
                const bool reasoned = r.error.find("fuera de P4.1") != std::string::npos ||
                                      r.error.find("sin semántica pública") != std::string::npos ||
                                      r.error.find("requiere") != std::string::npos;
                if (!(reasoned || known_out_of_scope(e))) std::fprintf(stderr, "M1: %s: %s\n", e.mnemonic, r.error.c_str());
                LG_CHECK(reasoned || known_out_of_scope(e));
                std::printf("    M1 info: %s [%s] -> %s\n", e.mnemonic, e.operands, r.error.c_str() + 8);
            }
        }
    }
    std::printf("M1: decodificación %u/296 (100 %%); traducción %u/296 codificaciones (%.1f %%), %zu/%zu mnemónicos;\n"
                "    lista de P4.1: %u/%u codificaciones traducidas (las demás: formas fuera de P4.1 documentadas)\n",
                decoded, translated, 100.0 * translated / 296.0, mnems_ok.size(), mnems.size(), in_list_ok, in_list);
}

// ---------------------------------------------------------------- M4 over T2 and T3, D1
std::vector<lg_test::dksh::Compute> corpus() {
    std::vector<lg_test::dksh::Compute> out;
    for (const auto& s : lg_test::t3fx::kShaders) {
        lg_test::dksh::Compute c;
        std::string err;
        LG_CHECK(lg_test::dksh::parse_compute(std::vector<uint8_t>(s.dksh, s.dksh + s.dksh_size), c, err));
        out.push_back(std::move(c));
    }
    return out;
}

ShaderInfo info_for(const lg_test::dksh::Compute& c) {
    ShaderInfo info = base_info();
    for (int i = 0; i < 3; ++i) info.local_size[i] = c.block_dims[i];
    info.shared_memory_bytes = c.shared_mem;
    info.local_memory_bytes = c.local_mem;
    info.global_tables = lg::shader::deko3d_compute_tables(0, 64);
    return info;
}

void m4_and_d1() {
    uint32_t t2 = 0, t3 = 0;
    for (const auto& tc : lg_test::t2::kCases) {
        ShaderInfo info = base_info();
        info.local_size[0] = 64;
        info.shared_memory_bytes = tc.shared;
        info.local_memory_bytes = tc.local;
        info.global_tables = lg::shader::deko3d_compute_tables(0, 64);
        const auto r = translate(std::span<const uint64_t>(tc.code, tc.words), info);
        if (!r.ok) std::fprintf(stderr, "T2 %s: %s\n", tc.name, r.error.c_str());
        LG_CHECK(r.ok);
        check_module(r.spirv, std::string("T2 ") + tc.name);
        mark_program(std::span<const uint64_t>(tc.code, tc.words), r);
        ++t2;
    }
    const auto progs = corpus();
    std::vector<std::vector<uint32_t>> first;
    for (size_t i = 0; i < progs.size(); ++i) {
        const auto r = translate(progs[i].code, info_for(progs[i]));
        if (!r.ok) std::fprintf(stderr, "T3 %s: %s\n", lg_test::t3fx::kShaders[i].name, r.error.c_str());
        LG_CHECK(r.ok);
        check_module(r.spirv, std::string("T3 ") + lg_test::t3fx::kShaders[i].name);
        mark_program(progs[i].code, r);
        first.push_back(r.spirv);
        ++t3;
    }
    // D1: deterministic, and safe from several threads at once
    std::vector<std::thread> threads;
    std::vector<int> mismatches(4, 0);
    for (int t = 0; t < 4; ++t)
        threads.emplace_back([&, t] {
            for (int rep = 0; rep < 3; ++rep)
                for (size_t i = 0; i < progs.size(); ++i)
                    if (translate(progs[i].code, info_for(progs[i])).spirv != first[i]) ++mismatches[t];
        });
    for (auto& th : threads) th.join();
    for (int m : mismatches) LG_CHECK(m == 0);
    std::printf("M4: %u módulos válidos (M1 + %u T2 + %u T3)%s; D1: 4 hilos x 3 repeticiones idénticos\n",
                modules_checked, t2, t3, spirv_val.empty() ? " (sin spirv-val: solo estructura)" : " con spirv-val");
    // M1 (translation), counted over every successfully translated program: the one-instruction
    // programs plus the T2 cases and the T3 corpus
    uint32_t total = 0, listed = 0, listed_ok = 0;
    for (size_t i = 0; i < 296; ++i) {
        const isa::Encoding& e = isa::encodings()[i];
        const bool l = kP41.count(e.mnemonic) != 0;
        total += translated_enc[i];
        listed += l;
        listed_ok += l && translated_enc[i];
        if (l && !translated_enc[i] && !known_out_of_scope(e))
            std::printf("    M1: codificación de P4.1 sin programa traducido: %s [%s]\n", e.mnemonic, e.operands);
    }
    std::printf("M1 (traducción, programas M1 + T2 + T3): %u/296 codificaciones (%.1f %%); lista de P4.1: %u/%u\n",
                total, 100.0 * total / 296.0, listed_ok, listed);
}

// ---------------------------------------------------------------- M4 / D1 over the graphics stages
ShaderInfo graphics_info(const lg_test::t3g::Spec& spec, int stage, const uint32_t (&sph)[20]) {
    ShaderInfo info;
    info.stage = lg_test::t3g::stage_enum(stage);
    std::copy(std::begin(sph), std::end(sph), info.sph.begin());
    info.graphics = spec.gfx;
    lg::shader::Sph h;
    LG_CHECK(lg::shader::parse_sph(info.sph, h));
    info.local_memory_bytes = h.local_mem_bytes;
    for (uint32_t b = 0; b < 18; ++b) info.cbufs.push_back({b, 32 + 20 * static_cast<uint32_t>(stage) + b});
    info.global_tables = {lg::shader::GlobalBufferTable{0, lg_test::t3g::kResbase[stage] + 0xa0, 16, 16, 8, 0x10000, 0}};
    return info;
}

void m4_graphics() {
    struct Prog { std::vector<uint64_t> code; ShaderInfo info; std::string name; };
    std::vector<Prog> progs;
    uint32_t stages[5] = {}, t2g = 0;
    for (const auto& p : lg_test::t3gfx::kPipelines) {
        const auto spec = lg_test::t3g::parse_spec(p.stages[0].glsl);
        for (int s = 0; s < 5; ++s) {
            if (!p.stages[s].glsl) continue;
            lg_test::dksh::Graphics g;
            std::string err;
            LG_CHECK(lg_test::dksh::parse_graphics(std::vector<uint8_t>(p.stages[s].dksh, p.stages[s].dksh + p.stages[s].dksh_size), g, err));
            progs.push_back({g.code, graphics_info(spec, s, g.sph), std::string(p.name) + "." + lg_test::t3g::stage_ext(s)});
            ++stages[s];
        }
    }
    std::vector<std::vector<uint32_t>> first;
    uint32_t tcs_reads = 0;
    for (const auto& pr : progs) {
        const auto r = translate(pr.code, pr.info);
        if (!r.ok) std::fprintf(stderr, "T3-G %s: %s\n", pr.name.c_str(), r.error.c_str());
        LG_CHECK(r.ok);
        check_module(r.spirv, "T3-G " + pr.name);
        // a TCS that reads outputs (ld a[] .o / .p: other invocations' values, lock-step on the
        // hardware) must synchronize them with OpControlBarrier in Vulkan; the oracle cannot
        // show a missing one (lavapipe runs the invocations of a patch in SIMD lanes)
        if (pr.info.stage == lg::shader::Stage::TessControl) {
            bool reads = false;
            for (size_t i = 0; i < pr.code.size(); ++i) {
                if (isa::is_sched_slot(i)) continue;
                const isa::Encoding* e = isa::find_encoding(pr.code[i]);
                if (e && std::string(e->mnemonic) == "ld" && e->has("AMEM") && ((pr.code[i] >> 31) & 3)) reads = true;
            }
            bool barrier = false;
            for (size_t w = 5; w < r.spirv.size(); w += r.spirv[w] >> 16)
                if ((r.spirv[w] & 0xffff) == 224 /* OpControlBarrier */) barrier = true;
            if (reads && !barrier) std::fprintf(stderr, "T3-G %s: lee salidas del TCS sin OpControlBarrier\n", pr.name.c_str());
            LG_CHECK(!reads || barrier);
            tcs_reads += reads;
        }
        mark_program(pr.code, r);
        first.push_back(r.spirv);
    }
    for (const auto& c : lg_test::t2g::kCases) {
        static const lg::shader::Stage kSt[5] = {lg::shader::Stage::Vertex, lg::shader::Stage::TessControl,
                                                 lg::shader::Stage::TessEval, lg::shader::Stage::Geometry,
                                                 lg::shader::Stage::Fragment};
        ShaderInfo info;
        info.stage = kSt[c.stage];
        std::copy(c.sph, c.sph + 20, info.sph.begin());
        for (uint32_t k = 0; k < 4; ++k)
            info.graphics.vertex_attrib_types[k] = c.attr_types[k] == 2 ? lg::shader::AttribType::Uint : lg::shader::AttribType::Float;
        for (uint32_t k = 0; k < 2; ++k)
            info.graphics.varying_types[k] = c.varying_types[k] == 2 ? lg::shader::AttribType::Uint : lg::shader::AttribType::Float;
        info.graphics.render_target_types[0] = lg::shader::AttribType::Uint;
        info.graphics.instance_id_includes_base = c.instance_includes_base;
        info.graphics.gs_input = static_cast<lg::shader::GraphicsState::GsInput>(c.gs_input);
        for (uint32_t b = 0; b < 18; ++b) info.cbufs.push_back({b, 32 + b});
        const auto r = translate(std::span<const uint64_t>(c.code, c.words), info);
        if (!r.ok) std::fprintf(stderr, "T2-G %s: %s\n", c.name, r.error.c_str());
        LG_CHECK(r.ok);
        check_module(r.spirv, std::string("T2-G ") + c.name);
        mark_program(std::span<const uint64_t>(c.code, c.words), r);
        ++t2g;
    }
    // D1 over the graphics stages too
    std::vector<std::thread> threads;
    std::vector<int> mismatches(4, 0);
    for (int t = 0; t < 4; ++t)
        threads.emplace_back([&, t] {
            for (int rep = 0; rep < 2; ++rep)
                for (size_t i = 0; i < progs.size(); ++i)
                    if (translate(progs[i].code, progs[i].info).spirv != first[i]) ++mismatches[t];
        });
    for (auto& th : threads) th.join();
    for (int m : mismatches) LG_CHECK(m == 0);
    std::printf("M4 (gráficos): %zu etapas de T3-G (VS %u, TCS %u, TES %u, GS %u, FS %u) + %u casos T2-G válidos%s; "
                "D1: 4 hilos x 2 repeticiones idénticos; %u TCS que leen salidas, todos con barrera\n", progs.size(), stages[0],
                stages[1], stages[2], stages[3], stages[4], t2g, spirv_val.empty() ? " (solo estructura)" : " con spirv-val",
                tcs_reads);
    uint32_t listed = 0, listed_ok = 0;
    for (size_t i = 0; i < 296; ++i) {
        const isa::Encoding& e = isa::encodings()[i];
        const bool l = kP42.count(e.mnemonic) != 0 || ((std::string(e.mnemonic) == "ld" || std::string(e.mnemonic) == "st") && e.has("AMEM"));
        listed += l;
        listed_ok += l && translated_enc[i];
        if (l && !translated_enc[i]) std::printf("    M1: codificación de P4.2 sin programa traducido: %s [%s]\n", e.mnemonic, e.operands);
    }
    uint32_t total = 0;
    for (size_t i = 0; i < 296; ++i) total += translated_enc[i];
    std::printf("M1 (traducción, + programas gráficos): %u/296 codificaciones (%.1f %%); lista de P4.2: %u/%u\n", total,
                100.0 * total / 296.0, listed_ok, listed);
}

// ---------------------------------------------------------------- M4 / D1 over the texture tests (P4.3)
void m4_textures() {
    struct Prog { std::vector<uint64_t> code; ShaderInfo info; std::string name; };
    std::vector<Prog> progs;
    for (const auto& c : lg_test::t2t::kCases) {
        ShaderInfo info;
        info.local_size[0] = 64;
        for (uint32_t b = 0; b < 18; ++b) info.cbufs.push_back({b, 32 + b});
        info.global_tables = lg::shader::deko3d_compute_tables(0, 64);
        info.texture_first_binding = 96;
        for (uint32_t i = 0; i < c.ntex; ++i) {
            const auto& t = c.texs[i];
            const auto at = t.fmt == 's' ? lg::shader::AttribType::Sint : t.fmt == 'f' || t.fmt == 'd' ? lg::shader::AttribType::Float
                                                                                                      : lg::shader::AttribType::Uint;
            const auto fmt = t.fmt == 'r' ? lg::shader::ImageFormat::R32ui : t.fmt == 's' ? lg::shader::ImageFormat::R32i
                           : t.fmt == 'v' ? lg::shader::ImageFormat::Rg32ui : t.fmt == 'u' ? lg::shader::ImageFormat::Rgba32ui
                                                                             : lg::shader::ImageFormat::Unknown;
            if (t.storage) info.images.push_back({0, t.handle, fmt, at});
            else info.textures.push_back({0, t.handle, at});
        }
        progs.push_back({std::vector<uint64_t>(c.code, c.code + c.words), info, std::string("T2-T ") + c.name});
    }
    uint32_t t3c = 0, t3g = 0;
    for (const auto& sh : lg_test::t3tfx::kShaders) {
        lg_test::dksh::Compute c;
        std::string err;
        LG_CHECK(lg_test::dksh::parse_compute(std::vector<uint8_t>(sh.dksh, sh.dksh + sh.dksh_size), c, err));
        ShaderInfo info = info_for(c);
        for (const auto& t : lg_test::tex::parse(sh.glsl)) {
            if (t.storage) info.images.push_back({0, 0xa0 + 0x80 + 4 * t.binding, lg_test::tex::image_format(t.fmt), lg_test::tex::attrib_type(t.fmt)});
            else info.textures.push_back({0, 0xa0 + 4 * t.binding, lg_test::tex::attrib_type(t.fmt)});
        }
        info.texture_first_binding = 96;
        progs.push_back({c.code, info, std::string("T3-T ") + sh.name});
        ++t3c;
    }
    for (const auto& p : lg_test::t3tgfx::kPipelines) {
        const auto spec = lg_test::t3g::parse_spec(p.stages[0].glsl);
        std::vector<lg_test::tex::TexSpec> ts;
        for (int st = 0; st < 5; ++st)
            if (p.stages[st].glsl) for (const auto& t : lg_test::tex::parse(p.stages[st].glsl)) ts.push_back(t);
        for (int st = 0; st < 5; ++st) {
            if (!p.stages[st].glsl) continue;
            lg_test::dksh::Graphics g;
            std::string err;
            LG_CHECK(lg_test::dksh::parse_graphics(std::vector<uint8_t>(p.stages[st].dksh, p.stages[st].dksh + p.stages[st].dksh_size), g, err));
            ShaderInfo info = graphics_info(spec, st, g.sph);
            for (const auto& t : ts) {
                const uint32_t rb = lg_test::t3g::kResbase[st];
                if (t.storage) info.images.push_back({0, rb + 0x80 + 4 * t.binding, lg_test::tex::image_format(t.fmt), lg_test::tex::attrib_type(t.fmt)});
                else info.textures.push_back({0, rb + 4 * t.binding, lg_test::tex::attrib_type(t.fmt)});
            }
            info.texture_first_binding = 160 + 16 * static_cast<uint32_t>(st);
            progs.push_back({g.code, info, std::string("T3-T ") + p.name + "." + lg_test::t3g::stage_ext(st)});
            ++t3g;
        }
    }
    {   // TMML exists only in the fragment shader: a synthetic FS with the bindless form (the handle
        // traced to c0[0x200]: mov $r20 c0[0x200]; tmml.b lod $r0 $r8 $r20 t2d 0x3)
        ShaderInfo info;
        info.stage = lg::shader::Stage::Fragment;
        info.sph[0] = 2 | (3u << 5) | (5u << 10);
        info.sph[18] = 0xf;   // render target 0
        for (uint32_t b = 0; b < 18; ++b) info.cbufs.push_back({b, 32 + b});
        const uint64_t mov = 0x4c98078008070014ull;
        const uint64_t tmml_b = 0xdf60000000000000ull | (uint64_t{3} << 31) | (uint64_t{1} << 29) | (uint64_t{20} << 20) |
                                (uint64_t{7} << 16) | (uint64_t{8} << 8);
        progs.push_back({{kSched, mov, tmml_b, kExit}, info, "TMML.B (FS)"});
    }
    std::vector<std::vector<uint32_t>> first;
    for (const auto& pr : progs) {
        const auto r = translate(pr.code, pr.info);
        if (!r.ok) std::fprintf(stderr, "%s: %s\n", pr.name.c_str(), r.error.c_str());
        LG_CHECK(r.ok);
        check_module(r.spirv, pr.name);
        mark_program(pr.code, r);
        first.push_back(r.spirv);
    }
    std::vector<std::thread> threads;
    std::vector<int> mismatches(4, 0);
    for (int t = 0; t < 4; ++t)
        threads.emplace_back([&, t] {
            for (size_t i = 0; i < progs.size(); ++i)
                if (translate(progs[i].code, progs[i].info).spirv != first[i]) ++mismatches[t];
        });
    for (auto& th : threads) th.join();
    for (int m : mismatches) LG_CHECK(m == 0);
    std::printf("M4 (texturas): %zu casos T2-T + %u shaders compute y %u etapas gráficas de T3-T válidos%s; D1: 4 hilos idénticos\n",
                std::size(lg_test::t2t::kCases), t3c, t3g, spirv_val.empty() ? " (solo estructura)" : " con spirv-val");
    uint32_t listed = 0, listed_ok = 0, total = 0;
    for (size_t i = 0; i < 296; ++i) {
        const isa::Encoding& e = isa::encodings()[i];
        total += translated_enc[i];
        const bool l = kP43.count(e.mnemonic) != 0;
        listed += l;
        listed_ok += l && translated_enc[i];
        if (l && !translated_enc[i]) std::printf("    M1: codificación de P4.3 sin programa traducido: %s [%s]\n", e.mnemonic, e.operands);
    }
    std::printf("M1 (traducción, + texturas): %u/296 codificaciones (%.1f %%); lista de P4.3: %u/%u\n", total, 100.0 * total / 296.0,
                listed_ok, listed);
    // P4.4: LOBOGELIDO_M1_DUMP=1 lists the encodings no translated program covers yet
    if (const char* d = std::getenv("LOBOGELIDO_M1_DUMP"); d && *d == '1')
        for (size_t i = 0; i < 296; ++i)
            if (!translated_enc[i]) std::printf("    M1 pendiente: %s [%s]\n", isa::encodings()[i].mnemonic, isa::encodings()[i].operands);
}

// ---------------------------------------------------------------- P4.4: M4, D1 and M1 of the rest of the ISA
// P4.4 rows (P4_4_DISENO.md §2.1-§2.3): the new mnemonics and the constant-buffer-target flow rows
bool p44_row(const isa::Encoding& e) {
    static const std::set<std::string> m = {"dadd", "dmul", "dfma", "dmnmx", "dset", "dsetp", "hadd2", "hmul2", "hfma2",
        "hset2", "hsetp2", "hadd2_32i", "hmul2_32i", "hfma2_32i", "cset", "csetp", "fchk", "pixld", "imadsp", "idp", "lepc",
        "getcrsptr", "setcrsptr", "getlmembase", "setlmembase", "b2r", "r2b", "sam", "ram", "bpt", "rtt", "pexit", "plongjmp",
        "longjmp"};
    const std::string n = e.mnemonic;
    if (m.count(n)) return true;
    if (n == "vote") return !e.has("T(50e0_0)");   // VOTE.VTG: no public semantics
    static const std::set<std::string> flow = {"bra", "brx", "jmp", "jmx", "cal", "jcal", "ssy", "pbk", "pcnt", "pret"};
    return flow.count(n) && (e.has("C36_RZ_S16_20") || ((n == "brx" || n == "jmx") && e.has("C36_08_S16_20")));
}

void m4_p44() {
    struct Prog { std::vector<uint64_t> code; ShaderInfo info; std::string name; };
    std::vector<Prog> progs;
    uint32_t t2x = 0, t3c = 0, t3g = 0;
    for (const auto& c : lg_test::t2x::kCases) {
        ShaderInfo info;
        info.local_size[0] = 64;
        for (uint32_t b = 0; b < 18; ++b) info.cbufs.push_back({b, 32 + b});
        info.global_tables = lg::shader::deko3d_compute_tables(0, 64);
        info.texture_first_binding = 96;
        if (std::strstr(c.flags, "lossy")) info.fp64 = ShaderInfo::Fp64Mode::Lossy32;
        for (uint32_t i = 0; i < c.ntex; ++i) {
            const auto& t = c.texs[i];
            const auto at = t.fmt == 's' ? lg::shader::AttribType::Sint : t.fmt == 'f' || t.fmt == 'd' ? lg::shader::AttribType::Float
                                                                                                      : lg::shader::AttribType::Uint;
            if (t.table) continue;   // an element of a run-time table
            if (t.storage) info.images.push_back({0, t.handle, lg::shader::ImageFormat::Unknown, at});
            else info.textures.push_back({0, t.handle, at, t.view == 7});
        }
        if (std::strstr(c.flags, "bindless")) info.bindless = {200, 201, 202, 4, 2};
        if (std::strstr(c.flags, "smem")) info.shared_memory_bytes = 4096;
        if (std::strstr(c.flags, "i64atom")) info.int64_atomics = true;
        progs.push_back({std::vector<uint64_t>(c.code, c.code + c.words), info, std::string("T2-X ") + c.name});
        ++t2x;
    }
    for (const auto& sh : lg_test::t3xfx::kShaders) {
        lg_test::dksh::Compute c;
        std::string err;
        LG_CHECK(lg_test::dksh::parse_compute(std::vector<uint8_t>(sh.dksh, sh.dksh + sh.dksh_size), c, err));
        progs.push_back({c.code, info_for(c), std::string("T3-X ") + sh.name});
        ++t3c;
    }
    for (const auto& p : lg_test::t3xgfx::kPipelines) {
        const auto spec = lg_test::t3g::parse_spec(p.stages[0].glsl);
        std::vector<lg_test::tex::TexSpec> ts;
        for (int st = 0; st < 5; ++st)
            if (p.stages[st].glsl) for (const auto& t : lg_test::tex::parse(p.stages[st].glsl)) ts.push_back(t);
        for (int st = 0; st < 5; ++st) {
            if (!p.stages[st].glsl) continue;
            lg_test::dksh::Graphics g;
            std::string err;
            LG_CHECK(lg_test::dksh::parse_graphics(std::vector<uint8_t>(p.stages[st].dksh, p.stages[st].dksh + p.stages[st].dksh_size), g, err));
            ShaderInfo info = graphics_info(spec, st, g.sph);
            for (const auto& t : ts)
                if (!t.storage) info.textures.push_back({0, lg_test::t3g::kResbase[st] + 4 * t.binding, lg_test::tex::attrib_type(t.fmt)});
            info.texture_first_binding = 160 + 16 * static_cast<uint32_t>(st);
            progs.push_back({g.code, info, std::string("T3-X ") + p.name + "." + lg_test::t3g::stage_ext(st)});
            ++t3g;
        }
    }
    ShaderInfo fsi;   // a fragment shader for the FS-only forms
    fsi.stage = lg::shader::Stage::Fragment;
    fsi.sph[0] = 2 | (3u << 5) | (5u << 10);
    fsi.sph[18] = 0xf;
    for (uint32_t b = 0; b < 18; ++b) fsi.cbufs.push_back({b, 32 + b});
    // PIXLD MY_INDEX and COVMASK; VOTE in a fragment shader
    progs.push_back({{kSched, 0xefe8000280070000ull, 0xefe8000081070001ull, 0x50d8000000070002ull | (uint64_t{0x380} << 32),
                      kSched, kExit, kNop, kNop}, fsi, "PIXLD/VOTE (FS)"});
    {   // IPA.SC (as MULTIPLY) and IPA.OFFSET of a[0x80] (NAK's field layout)
        const uint64_t ipa = (uint64_t{0xe000} << 48) | (uint64_t{0x80} << 28) | (uint64_t{7} << 47) | (uint64_t{0xff} << 8) |
                             (uint64_t{7} << 16);
        const uint64_t sc = ipa | (uint64_t{3} << 54) | (uint64_t{0xff} << 20) | (uint64_t{0xff} << 39);
        const uint64_t off = ipa | (uint64_t{2} << 52) | (uint64_t{1} << 54) | (uint64_t{0xff} << 20) | (uint64_t{8} << 39) | 1;
        ShaderInfo info = fsi;
        info.sph[6] = 0xaa;   // generic 0 xyzw perspective (ps_imap, SPH byte 0x18)
        progs.push_back({{kSched, sc, off, kExit}, info, "IPA.SC/IPA.OFFSET (FS)"});
    }
    {   // general bindless (D-P4.4-10): TEX.B and SULD.D with handles computed at run time
        ShaderInfo info = base_info();
        info.bindless = {8, 9, 10, 64, 16};
        const uint64_t iadd_h = 0x1c00000000070000ull | (uint64_t{20} << 8) | 20 | (uint64_t{1} << 20);   // r20 = r20 + 1
        const uint64_t tex_b = 0xdeb8000000000000ull | (uint64_t{3} << 37) | (uint64_t{0xf} << 31) | (uint64_t{1} << 29) |
                               (uint64_t{20} << 20) | (uint64_t{7} << 16) | (uint64_t{8} << 8);
        const uint64_t suld_b = 0xeb10000000000000ull | (uint64_t{3} << 33) | (uint64_t{4} << 20) | (uint64_t{20} << 39) |
                                (uint64_t{7} << 16) | (uint64_t{8} << 8) | 4;
        progs.push_back({{kSched, iadd_h, tex_b, suld_b, kSched, kExit, kNop, kNop}, info, "bindless general"});
    }
    {   // texel buffers: TLD from a samplerBuffer, SUST.D to a b1d image
        ShaderInfo info = base_info();
        info.textures.push_back({0, 0x28 * 4, lg::shader::AttribType::Uint, true});
        const uint64_t tld = 0xdc380000a1470800ull | (uint64_t{0xf} << 31) | (uint64_t{0} << 29);   // tld lz t1d 0x28
        const uint64_t sust = 0xeb38000000000000ull | (uint64_t{1} << 33) | (uint64_t{4} << 20) | (uint64_t{0x30} << 36) |
                              (uint64_t{7} << 16) | (uint64_t{8} << 8);
        progs.push_back({{kSched, tld, sust, kExit}, info, "buffers de texels"});
    }
    {   // 64-bit image atomics (SUATOM.D u64 ADD, s64 MIN): validated only, no oracle has shaderImageInt64Atomics
        ShaderInfo info = base_info();
        info.image_int64_atomics = true;
        info.images.push_back({0, 0x48 * 4, lg::shader::ImageFormat::Unknown, lg::shader::AttribType::Uint});
        const uint64_t low_add = 0x0000048601470800ull, low_min = 0x0000048621470800ull;   // envyas: suatom d u32 t2d add/min ... 0x48
        const uint64_t u64_add = (uint64_t{0xea00} << 48) | (uint64_t{2} << 51) | low_add;
        const uint64_t s64_min = (uint64_t{0xea00} << 48) | (uint64_t{5} << 51) | low_min;
        progs.push_back({{kSched, u64_add, s64_min, kExit}, info, "atómicas de imagen de 64 bits"});
        ShaderInfo binfo = base_info();   // the same through the run-time image table (handle in R20)
        binfo.image_int64_atomics = true;
        binfo.bindless = {8, 9, 10, 64, 16};
        const uint64_t reg_handle = (uint64_t{0xea60} << 48) | (uint64_t{20} << 39) | (uint64_t{2} << 36) |
                                    (low_add & 0x0000000fffffffffull);   // ea60 row: handle register, type u64 in 36-38
        progs.push_back({{kSched, reg_handle, kExit, kNop}, binfo, "atómicas de imagen de 64 bits (bindless general)"});
    }
    {   // P4.5: a video instruction with bits envydis does not describe is an explicit error
        const uint64_t vadd = 0x2000000000000000ull | (uint64_t{8} << 8) | (uint64_t{7} << 16) | (uint64_t{9} << 39) | (uint64_t{7} << 51);
        const auto ok = translate(std::vector<uint64_t>{kSched, vadd, kExit, kNop}, base_info());
        LG_CHECK(ok.ok);
        const auto bad = translate(std::vector<uint64_t>{kSched, vadd | (uint64_t{1} << 55), kExit, kNop}, base_info());
        LG_CHECK(!bad.ok && bad.error.find("bits sin describir") != std::string::npos);
        // a 16-bit A with an odd selector has no public meaning (D-P4.5-3)
        const auto odd = translate(std::vector<uint64_t>{kSched, vadd | (uint64_t{1} << 38) | (uint64_t{1} << 36), kExit, kNop}, base_info());
        LG_CHECK(!odd.ok && odd.error.find("selector de A de 16 bits impar") != std::string::npos);
        const auto even = translate(std::vector<uint64_t>{kSched, vadd | (uint64_t{1} << 38) | (uint64_t{2} << 36), kExit, kNop}, base_info());
        LG_CHECK(even.ok);
        const std::vector<uint64_t> vmnmx_code = {kSched, 0x3a00000000070000ull, kExit, kNop};
        const auto vmnmx_soft = translate(vmnmx_code, base_info());
        LG_CHECK(vmnmx_soft.ok);
        LG_CHECK(vmnmx_soft.soft_skipped == 1);
        LG_CHECK(vmnmx_soft.undecoded_soft == 0);
        LG_CHECK(!vmnmx_soft.warnings.empty());

        ShaderInfo strict_info = base_info();
        strict_info.soft_unknown_as_nop = false;
        strict_info.soft_undecodable_as_skip = false;
        const auto vmnmx = translate(vmnmx_code, strict_info);
        LG_CHECK(!vmnmx.ok && vmnmx.error.find("sin semántica pública") != std::string::npos);
        LG_CHECK(vmnmx.soft_skipped == 0);

        const uint64_t undecodable = ~uint64_t{0};
        LG_CHECK(isa::find_encoding(undecodable) == nullptr);
        const std::vector<uint64_t> undecodable_code = {kSched, undecodable, kExit, kNop};
        const auto undecodable_soft = translate(undecodable_code, base_info());
        LG_CHECK(undecodable_soft.ok);
        LG_CHECK(undecodable_soft.undecoded_soft == 1);
        LG_CHECK(undecodable_soft.soft_skipped == 0);
        const auto undecodable_strict = translate(undecodable_code, strict_info);
        LG_CHECK(!undecodable_strict.ok);
        LG_CHECK(undecodable_strict.error.find("palabra no decodificable") != std::string::npos);
        LG_CHECK(undecodable_strict.undecoded_soft == 0);
    }
    std::vector<std::vector<uint32_t>> first;
    for (const auto& pr : progs) {
        const auto r = translate(pr.code, pr.info);
        if (!r.ok) std::fprintf(stderr, "%s: %s\n", pr.name.c_str(), r.error.c_str());
        LG_CHECK(r.ok);
        check_module(r.spirv, pr.name);
        mark_program(pr.code, r);
        first.push_back(r.spirv);
    }
    std::vector<std::thread> threads;
    std::vector<int> mismatches(4, 0);
    for (int t = 0; t < 4; ++t)
        threads.emplace_back([&, t] {
            for (size_t i = 0; i < progs.size(); ++i)
                if (translate(progs[i].code, progs[i].info).spirv != first[i]) ++mismatches[t];
        });
    for (auto& th : threads) th.join();
    for (int m : mismatches) LG_CHECK(m == 0);
    std::printf("M4 (P4.4): %u casos T2-X + %u shaders compute y %u etapas gráficas de T3-X + %zu programas sintéticos válidos%s; D1: 4 hilos idénticos\n",
                t2x, t3c, t3g, progs.size() - t2x - t3c - t3g, spirv_val.empty() ? " (solo estructura)" : " con spirv-val");
    uint32_t listed = 0, listed_ok = 0, total = 0;
    for (size_t i = 0; i < 296; ++i) {
        const isa::Encoding& e = isa::encodings()[i];
        total += translated_enc[i];
        const bool l = p44_row(e);
        listed += l;
        listed_ok += l && translated_enc[i];
        if (l && !translated_enc[i]) std::printf("    M1: codificación de P4.4 sin programa traducido: %s [%s]\n", e.mnemonic, e.operands);
    }
    std::printf("M1 (traducción, + P4.4): %u/296 codificaciones (%.1f %%); lista de P4.4: %u/%u\n", total, 100.0 * total / 296.0,
                listed_ok, listed);
    LG_CHECK(listed_ok == listed);
    {   // P4.5 (P4_5_DISENO.md): the scalar video instructions translated as models
        static const std::set<std::string> v = {"vadd", "vabsdiff", "vmad", "vsetp", "vshl", "vshr"};
        uint32_t l5 = 0, ok5 = 0;
        for (size_t i = 0; i < 296; ++i)
            if (v.count(isa::encodings()[i].mnemonic)) { ++l5; ok5 += translated_enc[i]; }
        std::printf("M1 (P4.5): lista de P4.5 (vídeo como modelos): %u/%u\n", ok5, l5);
        LG_CHECK(ok5 == l5 && l5 == 6);
    }
    if (const char* d = std::getenv("LOBOGELIDO_M1_DUMP"); d && *d == '1')
        for (size_t i = 0; i < 296; ++i)
            if (!translated_enc[i]) std::printf("    M1 sin traducción: %s [%s]\n", isa::encodings()[i].mnemonic, isa::encodings()[i].operands);
}

// ---------------------------------------------------------------- E1
void e1() {
    ShaderInfo info = base_info();
    // Error-path tests must disable the product's soft-playable fallback; otherwise an
    // unknown word or unsupported instruction may intentionally become a warned NOP.
    info.soft_unknown_as_nop = false;
    info.soft_undecodable_as_skip = false;
    {   // empty
        const auto r = translate({}, info);
        LG_CHECK(!r.ok && !r.error.empty());
    }
    {   // undecodable word (all zero)
        const std::vector<uint64_t> p = {kSched, 0, kExit, kNop};
        const auto r = translate(p, info);
        LG_CHECK(!r.ok && r.error.find("0x0008") != std::string::npos);
    }
    {   // branch outside the program: bra +0x1000
        const std::vector<uint64_t> p = {kSched, 0xe240000100000f0full | (uint64_t{7} << 16), kExit, kNop};
        const auto r = translate(p, info);
        LG_CHECK(!r.ok && r.error.find("fuera del programa") != std::string::npos);
    }
    {   // constant buffer without binding: mov r0, c5[0x0] with only bank 0 bound
        ShaderInfo i2 = info;
        i2.cbufs = {{0, 0}};
        const uint64_t mov_c5 = 0x4c98000000000000ull | (uint64_t{5} << 34) | (uint64_t{0xf} << 39) | (uint64_t{7} << 16);
        const std::vector<uint64_t> p = {kSched, mov_c5, kExit, kNop};
        const auto r = translate(p, i2);
        LG_CHECK(!r.ok && r.error.find("c5") != std::string::npos);
    }
    {   // global memory whose buffer address never comes from the table: ldg r0, [r2]
        const uint64_t ldg = 0xeed4200000000200ull | (uint64_t{7} << 16);
        const std::vector<uint64_t> p = {kSched, ldg, kExit, kNop};
        const auto r = translate(p, info);
        LG_CHECK(!r.ok && r.error.find("no rastreable") != std::string::npos);
    }
    {   // instruction without public semantics: TXA (this case used TEX until P4.3, VOTE until P4.4
        // translated them)
        const std::vector<uint64_t> p = {kSched, 0xdf40000000000000ull | (uint64_t{7} << 16), kExit, kNop};
        const auto r = translate(p, info);
        LG_CHECK(!r.ok && r.error.find("0x0008: txa") != std::string::npos &&
                 r.error.find("sin semántica pública") != std::string::npos);
    }
    // P4.2: the SPH and the stage
    const uint64_t ipa_pass = 0xe003ff870ff7ff00ull;            // ipa pass $r0 a[0x70]
    const uint64_t ld_attr = 0xefd8ff800807ff00ull;             // ld b32 $r0 a[0x80]
    auto vs_sph = [] {
        std::array<uint32_t, 20> w{};
        w[0] = 1 | (3u << 5) | (1u << 10);
        return w;
    };
    {   // graphics stage without a valid SPH
        ShaderInfo i2 = info;
        i2.stage = lg::shader::Stage::Vertex;
        const std::vector<uint64_t> p = {kSched, kExit, kNop, kNop};
        const auto r = translate(p, i2);
        LG_CHECK(!r.ok && r.error.find("SPH no válida") != std::string::npos);
    }
    {   // the SPH says VS, the caller asks for FS
        ShaderInfo i2 = info;
        i2.stage = lg::shader::Stage::Fragment;
        i2.sph = vs_sph();
        const std::vector<uint64_t> p = {kSched, kExit, kNop, kNop};
        const auto r = translate(p, i2);
        LG_CHECK(!r.ok && r.error.find("no corresponde a la etapa") != std::string::npos);
    }
    {   // attribute memory in compute
        const std::vector<uint64_t> p = {kSched, ld_attr, kExit, kNop};
        const auto r = translate(p, info);
        LG_CHECK(!r.ok && r.error.find("0x0008") != std::string::npos && r.error.find("compute") != std::string::npos);
    }
    {   // IPA outside the fragment shader
        ShaderInfo i2 = info;
        i2.stage = lg::shader::Stage::Vertex;
        i2.sph = vs_sph();
        const std::vector<uint64_t> p = {kSched, ipa_pass, kExit, kNop};
        const auto r = translate(p, i2);
        LG_CHECK(!r.ok && r.error.find("IPA fuera del fragment shader") != std::string::npos);
    }
    {   // OUT outside the geometry shader
        ShaderInfo i2 = info;
        i2.stage = lg::shader::Stage::Vertex;
        i2.sph = vs_sph();
        const std::vector<uint64_t> p = {kSched, 0xfbe000800ff71616ull, kExit, kNop};   // out emit $r22 $r22 0x0
        const auto r = translate(p, i2);
        LG_CHECK(!r.ok && r.error.find("OUT fuera del geometry shader") != std::string::npos);
    }
    {   // a built-in that does not exist in this stage: the vertex id in a fragment shader
        ShaderInfo i2 = info;
        i2.stage = lg::shader::Stage::Fragment;
        i2.sph = vs_sph();
        i2.sph[0] = 2 | (3u << 5) | (5u << 10);
        const std::vector<uint64_t> p = {kSched, 0xe003ffafcff7ff00ull /* ipa pass $r0 a[0x2fc] */, kExit, kNop};
        const auto r = translate(p, i2);
        LG_CHECK(!r.ok && r.error.find("a[0x2fc] fuera de P4.2") != std::string::npos);
    }
    // P4.3: textures and images
    auto e1_tex = [&](uint64_t w, const char* what, std::initializer_list<uint64_t> pre = {}) {
        std::vector<uint64_t> p = {kSched};
        for (uint64_t x : pre) p.push_back(x);
        p.push_back(w);
        while (p.size() % 4) p.push_back(kNop);
        p.push_back(kSched);
        p.push_back(kExit);
        const auto r = translate(p, info);
        if (!*what) { LG_CHECK(r.ok); return; }   // P4.4: a form that must translate
        if (r.ok || r.error.find(what) == std::string::npos) std::fprintf(stderr, "E1 (texturas): esperado '%s', obtenido '%s'\n", what, r.error.c_str());
        LG_CHECK(!r.ok && r.error.find(what) != std::string::npos);
    };
    e1_tex(0xdf581a40a0070000ull | (uint64_t{7} << 16), "TMML fuera del fragment shader");          // tmml lod in compute
    e1_tex(0xdeb8006000000000ull | (uint64_t{0xf} << 31) | (uint64_t{1} << 29) | (uint64_t{20} << 20) | (uint64_t{7} << 16),
           "bindless con handle no rastreable");                                                     // tex.b, handle not traced
    // P4.4 translates TXQ texture type, partial SUST.P, b1d, register offsets, INC/DEC and f32 ADD:
    // these cases now use forms without public semantics or needing a device feature
    e1_tex((0xdf48038780870800ull & ~(uint64_t{0x3f} << 22)) | (uint64_t{5} << 22), "sin semántica pública");   // txq 5
    e1_tex(0xdc780287a1470800ull, "TLD.CL sin semántica pública");                                    // tld.cl
    e1_tex((0xc0b80287a1470800ull & ~(uint64_t{7} << 55)) | (uint64_t{6} << 55), ".LBA/.LLA sin semántica pública");   // tex.lba
    e1_tex(0xea30048600070800ull, "sin semántica pública");                                           // suatom.d sd32
    e1_tex(0xea10048600070800ull, "requiere shaderImageInt64Atomics");                                // suatom.d u64 add
    e1_tex(0xea18048600070800ull | (uint64_t{1} << 29), "f32 distinta de ADD/EXCH");                  // suatom.d f32 min
    // P4.4: the rest of the ISA without public semantics, and forms needing their stage
    e1_tex(0x50e0000000070000ull, "VOTE.VTG sin semántica pública");
    e1_tex(0xe390000000000000ull, "ide: sin semántica pública");
    e1_tex(0xe3a0000000000000ull | 0x100, "");   // BPT.TRAP translates (ends the invocation): checked below
    e1_tex(0xefe8000280070000ull, "PIXLD fuera del fragment shader");                                 // pixld my_index
    e1_tex(0xf0a8000300070000ull | (uint64_t{3} << 43), "BAR.SCAN sin semántica pública");
    e1_tex(0x5098000000071800ull | (uint64_t{7} << 39), "sin semántica pública");                     // cset csm_ta
    std::printf("E1: errores explícitos con dirección y mnemónico (también SPH, etapa, atributos, texturas e imágenes)\n");
}

} // namespace

int main(int argc, char** argv) {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    if (argc > 1) spirv_val = argv[1];
    t1();
    m1();
    m4_and_d1();
    m4_graphics();
    m4_textures();
    m4_p44();
    e1();
    std::printf("shader_static: OK\n");
    return 0;
}
