#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include "../gpu/gpu_resource_manager.h"
int main(){ lg::gpu::GpuResourceManager r; auto b=r.create_buffer({4096,1},"vertices"); LG_CHECK(b.ok()); auto i=r.create_image({128,128,1,1,2},"color"); LG_CHECK(i.ok()); auto s=r.create_descriptor_set(); LG_CHECK(s.ok()); LG_CHECK(r.bind_descriptor(s.value(),0,b.value(),1).ok()); LG_CHECK(r.bind_descriptor(s.value(),1,i.value(),2).ok()); LG_CHECK(r.descriptor_binding_count(s.value())==2); LG_CHECK(r.resource_count()==3); LG_CHECK(r.destroy(b.value()).ok()); LG_CHECK(r.descriptor_binding_count(s.value())==1); r.reset(); LG_CHECK(r.resource_count()==0); return 0; }
