// P3.1: the dispatcher end to end, with real NROs/NSOs (tests/data/nro, built with elf2nro/elf2nso).
//  H1 "hola": svcOutputDebugString + return 0 -> the text in the guest log, the session in
//     STOPPED with exit=guest code=0; on Block, Block 16 KiB, JIT, JIT+fastmem, JIT+fastmem
//     16 KiB, and on the plain interpreter driving the dispatcher over the same layout
//  E1 exits: return 7 -> code=7; svcExitProcess -> code=none; a new prepare() after an exit
//  A1 the homebrew ABI walked by the guest like libnx's envSetup (R7)
//  S1 every P3.1 SVC executed by the guest, as an NRO, a plain NSO and an NSO inside an NCA
//     (ProgramId = the NCA's title id, D-P3.1-1) (R1)
//  S2 fatal SVCs: not implemented, invalid, Break(Panic) decoded -> Error, never resumed (R5)
//  L1 10^4 SVCs interleaved with code: identical results on every engine (R2)
//  W1 the worker: guest exit -> worker STOPPED (not Error) -> a new session starts without
//     stop() (A3/A4, R3); a fatal SVC still ends in Error
#include "lg_check.h"
#include "nca_test_builder.h"
#include "../cpu/guest_clock.h"
#include "../cpu/interpreter.h"
#include "../loader/nro_loader.h"
#include "../runtime/runtime_coordinator.h"
#include "../runtime/runtime_worker.h"
#include "../system/process_layout.h"
#include "../system/svc_dispatcher.h"
#include "data/nro/nro_fixtures.h"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

namespace {
namespace fs = std::filesystem;
using lg::cpu::ExceptionKind;
using lg::runtime::RuntimeCoordinator;
using lg::runtime::State;
using lg::system::HandleTable;
using lg::system::ProcessLayout;
namespace kr = lg::system::kresult;
constexpr uint64_t MiB = 1ull << 20;

template <size_t N> std::vector<uint8_t> bytes(const unsigned char (&a)[N]) { return {a, a + N}; }
std::string write_file(const std::string& name, const std::vector<uint8_t>& b) {
    const auto p = fs::temp_directory_path() / ("lobo_p31_" + name);
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(b.data()), long(b.size()));
    return p.string();
}
template <size_t N> std::string nro(const char* name, const unsigned char (&a)[N]) { return write_file(std::string(name) + ".nro", bytes(a)); }
template <size_t N> std::string nso(const char* name, const unsigned char (&a)[N]) { return write_file(std::string(name) + ".nso", bytes(a)); }

struct Engine { const char* name; bool force_interpreter; bool fastmem; size_t host_page; };
std::vector<Engine> engines() {
    std::vector<Engine> e = {{"Block", true, false, 0}, {"Block, 16 KiB host pages", true, false, 16384}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    e.push_back({"JIT", false, false, 0});
    e.push_back({"JIT + fastmem", false, true, 0});
    e.push_back({"JIT + fastmem, 16 KiB host pages", false, true, 16384});
#endif
    return e;
}
void configure(RuntimeCoordinator& rt, const Engine& e) {
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(e.force_interpreter);
    rt.set_jit_fastmem(e.fastmem);
}
/** Runs frames while the session is Running. Returns the error of the last frame ("" if none). */
std::string run_to_end(RuntimeCoordinator& rt, int max_frames = 2'000'000) {
    for (int i = 0; i < max_frames && rt.state() == State::Running; ++i) {
        const auto r = rt.run_frame(rt.entry_point());
        if (!r.ok()) return r.error();
    }
    return {};
}
std::vector<uint64_t> words(const std::string& blob) {
    std::vector<uint64_t> w(blob.size() / 8);
    std::memcpy(w.data(), blob.data(), w.size() * 8);
    return w;
}

// ---------------------------------------------------------------------------------------
void h1_hola() {
    std::printf("[H1] hola desde un NRO real, on every engine\n");
    const std::string path = nro("hola", nro_fixtures::hola);
    for (const auto& e : engines()) {
        std::printf("  engine: %s\n", e.name);
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            configure(rt, e);
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            const auto err = run_to_end(rt);
            if (!err.empty() || rt.state() != State::Stopped) std::printf("  %s | %s\n", err.c_str(), rt.diagnostics().c_str());
            LG_CHECK(err.empty() && rt.state() == State::Stopped);
            LG_CHECK(rt.guest_log() == "hola desde un NRO real");
            const auto x = rt.guest_exit();
            LG_CHECK(x.exited && x.has_code && x.code == 0 && x.pc == ProcessLayout::kExitStubVa);
            const std::string d = rt.diagnostics();
            LG_CHECK(d.find("Runtime=STOPPED") != std::string::npos && d.find("exit=guest code=0 ") != std::string::npos);
            LG_CHECK(d.find("guest_log=\"hola desde un NRO real\" guest_log_bytes=22 ") != std::string::npos);
            LG_CHECK(d.find("svc_calls=2 last_svc=0x7@0x40140000") != std::string::npos);
            LG_CHECK(d.find("error=none") != std::string::npos && d.find("last_fault=none") != std::string::npos);
            LG_CHECK(rt.svc_calls(0x27) == 1 && rt.svc_calls(0x07) == 1);
            LG_CHECK(!rt.run_frame(rt.entry_point()).ok() && rt.state() == State::Stopped);   // over, not an Error
            LG_CHECK(rt.stop().ok() && rt.state() == State::Stopped);
            // A new session after the exit: clean log, runs again.
            LG_CHECK(rt.prepare(path).ok() && rt.guest_log().empty() && !rt.guest_exit().exited);
            LG_CHECK(rt.diagnostics().find("exit=none") != std::string::npos);
            LG_CHECK(rt.start().ok() && run_to_end(rt).empty() && rt.guest_exit().code == 0);
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

/** The fourth engine: the plain interpreter and the dispatcher driven by hand on the same map. */
void h1_plain_interpreter() {
    std::printf("[H1] plain interpreter + dispatcher on the same layout\n");
    const auto file = bytes(nro_fixtures::hola);
    const auto img = lg::loader::NroLoader::parse(file);
    LG_CHECK(img.ok());
    lg::memory::AddressSpace as;
    lg::memory::Mmu mmu;
    constexpr uint64_t kArena = 0x10000000, kSize = 16 * MiB;
    LG_CHECK(as.enable_fastmem(kSize, kArena) && as.map(kArena, kSize));
    const auto l = lg::system::build_nro_process(img.value(), file, as, mmu, kArena, kSize);
    LG_CHECK(l.ok());
    // The P3.1 pages: stub R-X with its two instructions, configuration page RW, guards around.
    LG_CHECK(l.value().exit_stub_va == ProcessLayout::kExitStubVa && l.value().config_va == ProcessLayout::kConfigVa);
    LG_CHECK(mmu.translate(ProcessLayout::kExitStubVa, false, true).ok() && !mmu.translate(ProcessLayout::kExitStubVa, true, false).ok());
    LG_CHECK(mmu.translate(ProcessLayout::kConfigVa, true, false).ok() && !mmu.translate(ProcessLayout::kConfigVa, false, true).ok());
    LG_CHECK(!mmu.translate(ProcessLayout::kExitStubVa + 0x1000, false, false).ok() && !mmu.translate(ProcessLayout::kConfigVa - 8, false, false).ok());
    LG_CHECK(l.value().exit_stub_pa % ProcessLayout::kAlign == 0 && l.value().config_pa % ProcessLayout::kAlign == 0);
    const auto stub = as.read64(mmu.translate(ProcessLayout::kExitStubVa, false, false).value().physical);
    LG_CHECK(stub && *stub == (uint64_t{0x14000000u} << 32 | 0xD40000E1u));   // svc #0x07 ; b .
    lg::cpu::GuestClock clock;
    lg::cpu::Interpreter cpu(as, mmu);
    cpu.set_guest_clock(&clock);
    lg::system::SvcDispatcher d(as, mmu);
    d.begin_session({1, 0, l.value().exit_stub_va, &clock, {}});
    lg::cpu::CpuState s{};
    s.pc = l.value().code_va; s.sp = l.value().stack_top_va; s.tpidrro_el0 = l.value().tls_va;
    s.x[30] = l.value().exit_stub_va;
    bool exited = false;
    for (int steps = 0; steps < 10000 && !exited; ++steps) {
        if (cpu.step(s)) continue;
        LG_CHECK(s.exception.kind == ExceptionKind::Svc);
        const auto o = d.handle(1, s);
        LG_CHECK(o.kind != lg::system::SvcOutcome::Kind::Fatal);
        exited = o.kind == lg::system::SvcOutcome::Kind::ExitProcess;
    }
    LG_CHECK(exited && d.log().contents() == "hola desde un NRO real");
    LG_CHECK(d.exit().has_code && d.exit().code == 0 && d.exit().pc == ProcessLayout::kExitStubVa);
}

// ---------------------------------------------------------------------------------------
void e1_exits() {
    std::printf("[E1] exit codes\n");
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    LG_CHECK(rt.prepare(nro("exit7", nro_fixtures::exit7)).ok() && rt.start().ok() && run_to_end(rt).empty());
    LG_CHECK(rt.state() == State::Stopped && rt.guest_exit().has_code && rt.guest_exit().code == 7);
    LG_CHECK(rt.diagnostics().find("exit=guest code=7 ") != std::string::npos && rt.guest_log().empty());
    LG_CHECK(rt.prepare(nro("exit_direct", nro_fixtures::exit_direct)).ok() && rt.start().ok() && run_to_end(rt).empty());
    const auto x = rt.guest_exit();
    LG_CHECK(rt.state() == State::Stopped && x.exited && !x.has_code && x.pc >= ProcessLayout::kCodeBase && x.pc < ProcessLayout::kCodeBase + 0x1000);
    LG_CHECK(rt.diagnostics().find("exit=guest code=none ") != std::string::npos);
    // The same program as a plain NSO: Horizon's convention, svcExitProcess, no code.
    LG_CHECK(rt.prepare(nso("exit_direct", nro_fixtures::exit_direct_nso)).ok() && rt.start().ok() && run_to_end(rt).empty());
    LG_CHECK(rt.state() == State::Stopped && rt.guest_exit().exited && !rt.guest_exit().has_code);
    // An NSO has no loader to return to: "return" jumps to 0 and faults (x30 = 0 as on Horizon).
    LG_CHECK(rt.prepare(nso("exit7", nro_fixtures::exit7_nso)).ok() && rt.start().ok());
    const auto err = run_to_end(rt);
    LG_CHECK(!err.empty() && rt.state() == State::Error && !rt.guest_exit().exited);
    LG_CHECK(rt.last_guest_fault().kind == ExceptionKind::InstructionAbort && rt.last_guest_fault().address == 0);
}

void a1_abi() {
    std::printf("[A1] homebrew ABI as libnx's envSetup reads it\n");
    for (const auto& e : engines()) {
        std::printf("  engine: %s\n", e.name);
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            configure(rt, e);
            LG_CHECK(rt.prepare(nro("abi", nro_fixtures::abi)).ok() && rt.start().ok());
            const uint32_t main_handle = rt.main_thread_handle();
            LG_CHECK(main_handle != 0 && main_handle < 0xFFFF8000u);
            LG_CHECK(run_to_end(rt).empty() && rt.guest_exit().has_code && rt.guest_exit().code == 0);
            const auto r = words(rt.guest_log());
            LG_CHECK(r.size() == 43);
            if (r.size() != 43) continue;
            auto v = [&](int key, int i) { return r[3 + 2 * key + i]; };
            LG_CHECK(r[0] == ProcessLayout::kConfigVa && r[1] == ~0ull && r[2] == ProcessLayout::kExitStubVa);
            LG_CHECK(v(1, 0) == main_handle);                                          // MainThreadHandle
            LG_CHECK(v(7, 0) == uint64_t(int64_t{-2}) && v(7, 1) == 0);                // AppletType_None
            LG_CHECK(v(16, 0) == 0x00050100u && v(16, 1) == 0);                        // HosVersion 5.1.0
            LG_CHECK(v(6, 0) == lg::system::syscall_hint_word(0) && v(6, 1) == lg::system::syscall_hint_word(1));
            LG_CHECK(v(17, 0) == lg::system::syscall_hint_word(2));
            // P6.0: every assigned SVC (the Unassigned numbers 0x00, 0x38, 0x3B, 0x3E, 0x3F, 0x6E,
            // 0x80-0x8F, 0x92-0xBF are the only ones not hinted)
            LG_CHECK(v(6, 0) == ~(1ull | (1ull << 0x38) | (1ull << 0x3B) | (1ull << 0x3E) | (1ull << 0x3F)));
            LG_CHECK(v(6, 1) == ~(1ull << (0x6E - 64)));
            LG_CHECK(v(17, 0) == ((1ull << (0x90 - 128)) | (1ull << (0x91 - 128))));
            LG_CHECK(v(5, 0) == 0 && v(5, 1) == ProcessLayout::kConfigVa + 0x400);    // Argv
            LG_CHECK(v(2, 0) == 0 && v(3, 0) == 0 && v(4, 0) == 0 && v(10, 0) == 0);   // no entries Lobo does not give
            LG_CHECK(r[39] == ProcessLayout::kConfigVa + 0x300 && r[40] == 16);       // loader info "Lobo Gelido P3.1"
            LG_CHECK(r[41] == 6);                                                     // entries before EndOfList
            char argv[9] = {};
            std::memcpy(argv, &r[42], 8);
            LG_CHECK(std::string(argv) == "lobo_p31");                                // "lobo_p31_abi.nro"
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

// ---------------------------------------------------------------------------------------
void check_svcs(const std::vector<uint64_t>& s, uint64_t pid, uint64_t program_id, const char* what) {
    LG_CHECK(s.size() == 60);
    if (s.size() != 60) { std::printf("  [%s] %zu words\n", what, s.size()); return; }
    auto w0 = [&](int p) { return s[2 * p]; };
    auto x1 = [&](int p) { return s[2 * p + 1]; };
    LG_CHECK(w0(0) <= w0(1) && w0(1) <= w0(2) && w0(2) > 0);                   // GetSystemTick ~ CNTPCT, monotonic
    LG_CHECK(w0(3) == 0 && x1(3) == pid && w0(4) == 0 && x1(4) == pid);        // GetProcessId (process, thread)
    LG_CHECK(w0(5) == kr::InvalidHandle && x1(5) == 0);
    LG_CHECK(w0(6) == 0 && x1(6) == 0x7);                                      // CoreMask
    LG_CHECK(w0(7) == 0 && x1(7) == 0x0FFFFFFFF0000000ull);                    // PriorityMask
    LG_CHECK(w0(8) == 0 && x1(8) == program_id);                               // ProgramId
    LG_CHECK(w0(9) == 0 && x1(9) == 0);                                        // DebuggerAttached
    for (int p = 10; p <= 13; ++p) LG_CHECK(w0(p) == 0);
    LG_CHECK(x1(10) | x1(11) | x1(12) | x1(13));                                // RandomEntropy
    LG_CHECK(w0(14) == kr::InvalidCombination && w0(15) == kr::InvalidHandle && w0(16) == kr::InvalidCombination);
    LG_CHECK(w0(17) == kr::InvalidHandle && w0(19) == kr::InvalidHandle);
    LG_CHECK(w0(18) == 0 && x1(18) == 64 * MiB);                               // P3.2: TotalMemorySize = the arena (D-P3.2-1)
    LG_CHECK(w0(20) == kr::InvalidHandle && w0(21) == kr::InvalidHandle);      // CloseHandle(pseudo / 0)
    LG_CHECK(w0(22) == 0 && w0(23) == kr::InvalidHandle);                      // main thread handle, twice
    LG_CHECK(w0(24) == 0);                                                     // Break(NotificationOnly)
    LG_CHECK(w0(25) == kr::InvalidPointer && w0(26) == 0 && w0(27) == 0);      // OutputDebugString
    LG_CHECK(w0(28) == 0 && x1(28) == x1(10));                                 // entropy fixed per session
    LG_CHECK(w0(29) == 0xD0E);
}

void s1_svcs() {
    std::printf("[S1] every P3.1 SVC from the guest\n");
    for (const auto& e : engines()) {
        std::printf("  engine: %s\n", e.name);
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        for (int kind = 0; kind < 2; ++kind) {
            RuntimeCoordinator rt;
            configure(rt, e);
            const std::string path = kind == 0 ? nro("svcs", nro_fixtures::svcs) : nso("svcs", nro_fixtures::svcs_nso);
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            const uint64_t pid = rt.process() ? rt.process()->id : 0;
            LG_CHECK(pid != 0);
            const auto err = run_to_end(rt);
            if (!err.empty()) std::printf("  %s\n", rt.diagnostics().c_str());
            LG_CHECK(err.empty() && rt.state() == State::Stopped);
            LG_CHECK(rt.guest_exit().exited && rt.guest_exit().has_code == (kind == 0));
            const std::string log = rt.guest_log();
            LG_CHECK(log.rfind("svcs ok\n", 0) == 0);
            check_svcs(words(log.substr(std::min<size_t>(8, log.size()))), pid, 0, kind == 0 ? "nro" : "nso");
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
    // The same program inside an NCA: ProgramId is the NCA's title id (D-P3.1-1).
    const fs::path root = fs::temp_directory_path() / "lobo_p31_nca";
    const std::string nca = nca_test::write_test_nsp(root, bytes(nro_fixtures::svcs_nso)).string();
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    LG_CHECK(rt.configure_storage({(root / "keys").string(), (root / "nand").string()}).ok());
    LG_CHECK(rt.prepare(nca).ok() && rt.start().ok());
    const uint64_t pid = rt.process()->id;
    LG_CHECK(run_to_end(rt).empty() && rt.state() == State::Stopped && !rt.guest_exit().has_code);
    const std::string log = rt.guest_log();
    LG_CHECK(log.rfind("svcs ok\n", 0) == 0);
    check_svcs(words(log.substr(8)), pid, 0x0100000000000000ull, "nca");
    std::error_code ec;
    fs::remove_all(root, ec);
}

void s2_fatal() {
    // P6.0: the old "unimpl" program (svc 0x2C MapPhysicalMemory) now gets Horizon's answer
    // for a process without a system resource (InvalidState) and goes on.
    std::printf("[S2b] MapPhysicalMemory without a system resource: InvalidState, the program goes on\n");
    for (const auto& e : engines()) {
        RuntimeCoordinator rt;
        configure(rt, e);
        LG_CHECK(rt.prepare(write_file("unimpl.nro", bytes(nro_fixtures::unimpl))).ok() && rt.start().ok());
        for (int i = 0; i < 200 && rt.state() == State::Running; ++i) LG_CHECK(rt.run_frame(rt.entry_point()).ok());
        LG_CHECK(rt.state() == State::Running);
        const auto marker = rt.debug_read_guest64(rt.process_layout()->code_va + nro_fixtures::unimpl_after_fault_offset);
        LG_CHECK(marker.has_value() && *marker == 0x77);
        LG_CHECK(rt.stop().ok());
    }
    std::printf("[S2] fatal SVCs end the session in Error, never resumed\n");
    struct Case { const char* name; std::vector<uint8_t> image; uint64_t after_fault; const char* message; uint32_t id; };
    const Case cases[] = {
        // P6.0: 0x2C has a handler now; an unassigned number keeps the fatal path tested
        {"unassigned", bytes(nro_fixtures::unassigned), nro_fixtures::unassigned_after_fault_offset, "SVC 0x38 (Unassigned38) no implementada @0x", 0x38},
        {"invalid", bytes(nro_fixtures::invalid), nro_fixtures::invalid_after_fault_offset, "SVC 0xc0 inválida @0x", 0xC0},
        {"panic", bytes(nro_fixtures::panic), nro_fixtures::panic_after_fault_offset, "guest_abort=Panic result=2345-0030 (0x3d59) @0x", 0x26},
    };
    for (const auto& e : engines()) {
        std::printf("  engine: %s\n", e.name);
        for (const auto& c : cases) {
            RuntimeCoordinator rt;
            configure(rt, e);
            LG_CHECK(rt.prepare(write_file(std::string(c.name) + ".nro", c.image)).ok() && rt.start().ok());
            const auto err = run_to_end(rt);
            if (err.find(c.message) == std::string::npos) std::printf("  [%s] %s\n", c.name, err.c_str());
            LG_CHECK(err.find(c.message) != std::string::npos && rt.state() == State::Error);
            const auto f = rt.last_guest_fault();
            LG_CHECK(f.kind == ExceptionKind::Svc && f.syndrome == c.id);
            const std::string d = rt.diagnostics();
            LG_CHECK(d.find("error=" + std::string(c.message)) != std::string::npos && d.find("last_fault=svc_0x") != std::string::npos);
            LG_CHECK(!rt.guest_exit().exited);
            const auto marker = rt.debug_read_guest64(rt.process_layout()->code_va + c.after_fault);
            LG_CHECK(marker.has_value() && *marker == 0);                     // the program never went on
        }
    }
}

// ---------------------------------------------------------------------------------------
void l1_loop() {
    std::printf("[L1] 10^4 SVCs interleaved with code\n");
    uint64_t expect = 0x1234;
    for (uint64_t i = 0; i < 10000; ++i) { expect = expect * 31 + i; expect ^= expect >> 7; }
    std::vector<std::vector<uint64_t>> all;
    for (const auto& e : engines()) {
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            configure(rt, e);
            LG_CHECK(rt.prepare(nro("loop", nro_fixtures::loop)).ok() && rt.start().ok());
            const auto t0 = std::chrono::steady_clock::now();
            const auto err = run_to_end(rt);
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
            LG_CHECK(err.empty() && rt.state() == State::Stopped && rt.guest_exit().code == 0);
            LG_CHECK(rt.svc_calls(0x1E) == 20000);
            const auto r = words(rt.guest_log());
            std::printf("  %-34s %.1f ms  checksum=%016llx stxr(svc)=%llu stxr=%llu\n", e.name, ms,
                        r.size() == 6 ? (unsigned long long)r[0] : 0ull, r.size() == 6 ? (unsigned long long)r[3] : 0ull,
                        r.size() == 6 ? (unsigned long long)r[5] : 0ull);
            LG_CHECK(r.size() == 6);
            if (r.size() == 6) {
                LG_CHECK(r[0] == expect && r[1] == 0 && r[2] == 0 && r[4] == 10000);
                LG_CHECK(r[3] == 0);           // the SVC cleared every reservation
                LG_CHECK(r[5] == 10000);       // without an SVC in between, every STXR succeeds
            }
            all.push_back(r);
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
    for (const auto& r : all) LG_CHECK(r == all.front());
}

// ---------------------------------------------------------------------------------------
// P6.0 (P6_0_DISENO.md §6): the P6.0 SVCs that need no second thread, from the guest, on
// every engine (tests/data/nro/p6_svcs.S).
void p1_p6_svcs() {
    std::printf("[P1] P6.0 SVCs from the guest on every engine\n");
    for (const auto& e : engines()) {
        std::printf("  engine: %s\n", e.name);
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            configure(rt, e);
            LG_CHECK(rt.prepare(nro("p6_svcs", nro_fixtures::p6_svcs)).ok() && rt.start().ok());
            const std::string err = run_to_end(rt);
            const std::string log = rt.guest_log();
            LG_CHECK(err.empty() && rt.guest_exit().exited && log.size() == 31 * 16);
            if (log.size() != 31 * 16) { std::printf("  [%s] err='%s'\n", e.name, err.c_str()); continue; }
            std::vector<uint64_t> r(62);
            std::memcpy(r.data(), log.data(), log.size());
            auto x0 = [&](int s) { return r[static_cast<size_t>(2 * s)]; };
            auto x1 = [&](int s) { return r[static_cast<size_t>(2 * s + 1)]; };
            namespace km = lg::system::kmem::result;
            const bool ok =
                x0(0) == 0 && x1(0) == 0 &&                                   // IsApplication (NRO)
                x0(1) == 0 && x1(1) > 0 &&                                    // FreeThreadCount
                x0(2) == 0 && x1(2) == 1 && x0(3) == 0 && x1(3) == 0 &&       // IsSvcPermitted, AliasRegionExtraSize
                x0(4) == 0 && x1(4) != 0 && x0(5) == 0 &&                     // ResourceLimit handle, closed
                x0(6) == km::NotImplemented && x0(7) == km::NoThread &&       // retail
                x0(8) == km::NotFound && x0(9) == km::NotFound && x0(10) == km::InvalidEnumValue &&
                x0(11) == km::NotImplemented && x0(12) == km::InvalidMemoryRegion &&
                x0(13) == 0 && x1(13) == 2 &&                                 // Running
                x0(14) == km::Busy && x0(15) == km::InvalidEnumValue &&
                x0(16) == 1 && x1(16) == 0x1234 &&                            // the SMC frontier
                x0(17) == 0 && x1(17) != 0 && x0(18) != 0 &&                  // CreateSession
                x0(19) == 0 && x0(20) == km::SessionClosed && x0(21) == 0 &&
                x0(22) == 0 && x1(22) != 0 && x0(23) == 0 && x1(23) != 0 &&   // named port, connect
                x0(24) == 0 && x1(24) != 0 && x0(25) == km::NotFound && x0(26) == 0 &&
                x0(27) == 0 && x0(28) == km::NotFound &&
                x0(29) == 0 && x1(29) >= 0x80000000ull &&                     // QueryPhysicalAddress
                x0(30) == 0x600D;
            if (!ok)
                for (int s = 0; s < 31; ++s) std::printf("    slot %2d: 0x%llx 0x%llx\n", s, (unsigned long long)x0(s), (unsigned long long)x1(s));
            LG_CHECK(ok);
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

void w1_worker() {
    std::printf("[W1] worker: a guest exit is a clean end, and the next session starts\n");
    using WS = lg::runtime::RuntimeWorker::State;
    using namespace std::chrono_literals;
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    lg::runtime::RuntimeWorker worker(rt);
    LG_CHECK(rt.prepare(nro("hola", nro_fixtures::hola)).ok() && rt.start().ok());
    LG_CHECK(worker.start());
    LG_CHECK(worker.wait_until_state(WS::Stopped, 20000ms));
    LG_CHECK(worker.state() == WS::Stopped && rt.state() == State::Stopped);     // not Error (A3)
    LG_CHECK(rt.guest_exit().code == 0 && rt.guest_log() == "hola desde un NRO real");
    // A4: the worker thread ended by itself; start() joins it instead of refusing.
    LG_CHECK(rt.prepare(nro("exit7", nro_fixtures::exit7)).ok() && rt.start().ok());
    LG_CHECK(worker.start());
    LG_CHECK(worker.wait_until_state(WS::Stopped, 20000ms) && rt.guest_exit().code == 7);
    // Many sessions in a row, never calling stop().
    for (int i = 0; i < 10; ++i) {
        LG_CHECK(rt.prepare(nro("hola", nro_fixtures::hola)).ok() && rt.start().ok() && worker.start());
        LG_CHECK(worker.wait_until_state(WS::Stopped, 20000ms) && rt.guest_exit().exited);
    }
    // A fatal SVC still ends in Error (unchanged), and stop() recovers the worker.
    LG_CHECK(rt.prepare(nro("unassigned", nro_fixtures::unassigned)).ok() && rt.start().ok() && worker.start());
    const auto deadline = std::chrono::steady_clock::now() + 20s;
    while (worker.state() != WS::Error && std::chrono::steady_clock::now() < deadline) std::this_thread::sleep_for(1ms);
    LG_CHECK(worker.state() == WS::Error && rt.state() == State::Error);
    LG_CHECK(!worker.start());
    LG_CHECK(worker.stop() && worker.state() == WS::Stopped);
    LG_CHECK(rt.stop().ok());
    // stop() while a guest is still running (hello spins on "b ." after its SVC).
    LG_CHECK(rt.prepare(nro("hello", nro_fixtures::hello)).ok() && rt.start().ok() && worker.start());
    std::this_thread::sleep_for(20ms);
    LG_CHECK(worker.stop() && worker.state() == WS::Stopped && rt.state() == State::Running);
    LG_CHECK(rt.guest_log() == "hola desde un NRO real" && !rt.guest_exit().exited);
    LG_CHECK(rt.stop().ok());
}
} // namespace

int main() {
    p1_p6_svcs();
    h1_hola();
    h1_plain_interpreter();
    e1_exits();
    a1_abi();
    s1_svcs();
    s2_fatal();
    l1_loop();
    w1_worker();
    std::puts("svc process ok");
    return 0;
}
