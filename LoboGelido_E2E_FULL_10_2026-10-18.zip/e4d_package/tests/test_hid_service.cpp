#include "lg_check.h"
#include "../system/hid_service.h"
#include <cstdint>
#include <vector>

int main() {
    lg::system::HidService hid;
    hid.set_button(0, true);   // A
    hid.set_button(13, true);  // D-pad up
    LG_CHECK((hid.buttons() & (uint64_t(1) << 0)) != 0);
    LG_CHECK((hid.buttons() & (uint64_t(1) << 13)) != 0);

    // Guest-facing GetControllerState sees frontend-injected state.
    auto state = hid.dispatch({0, {}});
    LG_CHECK(state.ok());
    LG_CHECK(state.value().payload.size() == 24);
    uint64_t buttons = 0;
    for (int i = 0; i < 8; ++i)
        buttons |= uint64_t(state.value().payload[static_cast<size_t>(i)]) << (8 * i);
    LG_CHECK((buttons & (uint64_t(1) << 0)) != 0);
    LG_CHECK((buttons & (uint64_t(1) << 13)) != 0);

    hid.set_button(0, false);
    LG_CHECK((hid.buttons() & (uint64_t(1) << 0)) == 0);
    LG_CHECK((hid.buttons() & (uint64_t(1) << 13)) != 0);
    hid.set_button(64, true); // invalid index must not corrupt state
    LG_CHECK((hid.buttons() & (uint64_t(1) << 13)) != 0);

    // Analog stick values injected by the frontend are visible in the same guest state.
    hid.set_analog(32767, -16384, 0, -32767);
    auto analog = hid.dispatch({0, {}});
    LG_CHECK(analog.ok());
    const auto& payload = analog.value().payload;
    auto read_i32 = [&payload](size_t off) {
        uint32_t value = 0;
        for (int i = 0; i < 4; ++i) value |= uint32_t(payload[off + static_cast<size_t>(i)]) << (8 * i);
        return static_cast<int32_t>(value);
    };
    LG_CHECK(read_i32(8) == 32767);
    LG_CHECK(read_i32(12) == -16384);
    LG_CHECK(read_i32(16) == 0);
    LG_CHECK(read_i32(20) == -32767);
    return 0;
}
