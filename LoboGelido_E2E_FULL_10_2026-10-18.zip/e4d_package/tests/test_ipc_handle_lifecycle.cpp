#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <iostream>
#include "../system/kernel.h"

class Endpoint final : public lg::system::IpcEndpoint {
public:
    lg::core::Result<lg::system::IpcMessage> dispatch(const lg::system::IpcMessage& r) override {
        return lg::core::Result<lg::system::IpcMessage>::Ok(r);
    }
};

int main() {
    lg::system::Kernel k;
    LG_CHECK(k.services().register_service("secure:", std::make_unique<Endpoint>(), "svc:secure"));
    const auto p = k.processes().create("P", "p.nro", 0x1000, 0x1000, 0x100, 1);
    LG_CHECK(p);
    LG_CHECK(k.capabilities().grant(p, "svc:secure"));

    const auto old = k.connect_service_channel(p, "secure:");
    LG_CHECK(old);
    lg::system::IpcMessage msg{9, {4,5}}, out;
    LG_CHECK(k.send_service(old, p, msg));

    // Process destruction closes all of its IPC channels.
    LG_CHECK(k.processes().stop(p) || true);
    LG_CHECK(k.destroy_process(p));
    LG_CHECK(!k.send_service(old, p, msg));
    LG_CHECK(!k.receive_service(old, p, out));
    LG_CHECK(!k.dispatch_service(old, p, msg).ok());

    // Reset must not make an old opaque handle valid again.
    k.reset();
    LG_CHECK(k.services().register_service("secure:", std::make_unique<Endpoint>(), "svc:secure"));
    const auto p2 = k.processes().create("P2", "p2.nro", 0x2000, 0x2000, 0x100, 1);
    LG_CHECK(p2);
    LG_CHECK(k.capabilities().grant(p2, "svc:secure"));
    const auto fresh = k.connect_service_channel(p2, "secure:");
    LG_CHECK(fresh);
    LG_CHECK(fresh != old);
    LG_CHECK(!k.send_service(old, p2, msg));

    std::cout << "ipc handle lifecycle ok\n";
    return 0;
}
