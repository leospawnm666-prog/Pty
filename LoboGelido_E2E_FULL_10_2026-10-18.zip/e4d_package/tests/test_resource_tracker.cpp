#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "../memory/resource_tracker.h"

#include <cassert>
#include <string>

int main() {
    lg::memory::ResourceTracker tracker;
    LG_CHECK(tracker.live_count() == 0);
    LG_CHECK(tracker.live_bytes() == 0);
    LG_CHECK(tracker.peak_bytes() == 0);

    const auto texture = tracker.track(lg::memory::ResourceKind::Texture, 1024, "test-texture");
    const auto buffer = tracker.track(lg::memory::ResourceKind::Buffer, 2048, "test-buffer");
    LG_CHECK(texture != 0 && buffer != 0 && texture != buffer);
    LG_CHECK(tracker.live_count() == 2);
    LG_CHECK(tracker.live_count(lg::memory::ResourceKind::Texture) == 1);
    LG_CHECK(tracker.live_bytes() == 3072);
    LG_CHECK(tracker.peak_bytes() == 3072);

    LG_CHECK(tracker.untrack(texture));
    LG_CHECK(!tracker.untrack(texture));
    LG_CHECK(tracker.double_frees() == 1);
    LG_CHECK(tracker.live_count() == 1);
    LG_CHECK(tracker.live_bytes() == 2048);

    LG_CHECK(tracker.untrack(buffer));
    LG_CHECK(!tracker.has_leaks());
    LG_CHECK(tracker.live_bytes() == 0);
    return 0;
}
