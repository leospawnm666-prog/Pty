#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include "performance/adaptive_scaler.h"
using namespace lg::performance;
int main() {
    AdaptiveScaler s({true,60,60,100});
    LG_CHECK(s.update(25.0, 20.0, 0) == 95);
    LG_CHECK(s.update(25.0, 20.0, 0) == 90);
    for (int i=0;i<45;i++) s.update(14.0, 10.0, 0);
    LG_CHECK(s.state().scale >= 90);
    s.set_enabled(false);
    LG_CHECK(s.state().scale == 100);
    return 0;
}
