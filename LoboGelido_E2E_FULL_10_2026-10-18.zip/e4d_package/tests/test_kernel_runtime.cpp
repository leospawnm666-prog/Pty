#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <cstring>
#include "../runtime/runtime_coordinator.h"
#include "../system/kernel.h"
#include "../system/hl_services.h"
using namespace lg;
int main(){
    system::Kernel k;
    auto svc=k.services().register_service("sm:", system::make_system_service(k.scheduler()));
    LG_CHECK(svc);
    auto* ep=k.services().find("sm:"); LG_CHECK(ep);
    LG_CHECK(k.services().required_capability("sm:") == nullptr ||
           *k.services().required_capability("sm:") == "");
    auto tick=ep->dispatch(system::IpcMessage{0,{}}); LG_CHECK(tick.ok()&&tick.value().payload.size()==8);
    LG_CHECK(k.services().size()==1);
    LG_CHECK(k.services().contains("sm:"));
    auto pid=k.processes().create("test", "/romfs/test.nro", 0x1000, 0x1000, 0x1000, 1);
    LG_CHECK(pid);
    LG_CHECK(k.services().register_service("secure:", system::make_system_service(k.scheduler()), "svc:secure"));
    LG_CHECK(k.connect_service(pid, "secure:") == nullptr);
    LG_CHECK(k.capabilities().grant(pid, "svc:secure"));
    LG_CHECK(k.connect_service(pid, "secure:") != nullptr);
    LG_CHECK(k.capabilities().revoke(pid, "svc:secure"));
    LG_CHECK(k.connect_service(pid, "secure:") == nullptr);
    const auto service_names=k.services().names();
    LG_CHECK(service_names.size()==2 && service_names.front()=="secure:" && service_names.back()=="sm:");
    auto version=ep->dispatch(system::IpcMessage{2,{}}); LG_CHECK(version.ok());
    LG_CHECK(std::string(version.value().payload.begin(),version.value().payload.end())=="LoboGelido-SystemService-v1");

    auto ch=k.ipc().create_channel(); LG_CHECK(ch);
    system::IpcMessage msg{7,{1,2,3}}; LG_CHECK(k.ipc().send(ch,msg,k.threads()));
    system::IpcMessage out; LG_CHECK(k.ipc().receive(ch,out,0,k.threads())); LG_CHECK(out.command_id==7&&out.payload.size()==3);
    auto tid=k.threads().create("guest",64,[](uint64_t){}); LG_CHECK(tid);
    LG_CHECK(k.contexts().create(tid,0x1000,0x2000));
    LG_CHECK(k.contexts().get(tid)->pc==0x1000);
    auto timer=k.timers().create(10); LG_CHECK(k.timers().armed(timer)); k.timers().pump(10); LG_CHECK(k.timers().expired(timer));
    return 0;
}
