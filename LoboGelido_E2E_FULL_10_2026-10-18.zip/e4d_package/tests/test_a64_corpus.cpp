// P2 phase E.1: the interpreter must run real compiler output correctly.
// tests/data/a64_corpus.c is compiled by clang for AArch64 at -O0/-O1/-O2 (embedded in
// tests/data/a64_corpus.h) and run on the interpreter; the SAME C source is compiled
// natively into this test and gives the expected results (return value and every byte
// of the data area). Before phase E.1 the interpreter got 0 of 34 right.
#include "a64_corpus_runner.h"

#include <cstdio>
#include <cstdlib>

namespace native {
#include "data/a64_corpus.c"
}

namespace {
int g_fail = 0;

struct Expected { uint64_t x0; std::vector<uint8_t> data; };

Expected run_native(const std::string& name) {
    using namespace a64_corpus;
    std::vector<uint8_t> mem(0x10000);
    for (uint64_t i = 0; i < kDataSize; ++i) mem[i] = data_byte(i);
    const Args a = args_for(name);
    // Guest pointers into the data area become host pointers into `mem`.
    auto ptr = [&](uint64_t guest) { return mem.data() + (guest - kData); };
    uint64_t r = 0;
    using u64 = native::u64; using i64 = native::i64; using u8 = native::u8;
    if (name == "sum_array") r = native::sum_array(reinterpret_cast<const u64*>(ptr(a.x[0])), a.x[1]);
    else if (name == "fib") r = uint64_t(native::fib(i64(a.x[0])));
    else if (name == "collatz") r = native::collatz(a.x[0]);
    else if (name == "copy_bytes") { native::copy_bytes(ptr(a.x[0]), ptr(a.x[1]), a.x[2]); r = a.x[0]; }
    else if (name == "crc32ish") r = native::crc32ish(reinterpret_cast<const u8*>(ptr(a.x[0])), a.x[1]);
    else if (name == "clamp_sum") r = uint64_t(native::clamp_sum(reinterpret_cast<const i64*>(ptr(a.x[0])), a.x[1], i64(a.x[2]), i64(a.x[3])));
    else if (name == "call_chain") r = native::call_chain(a.x[0]);
    else if (name == "helper") r = native::helper(a.x[0]);
    else if (name == "divs") r = native::divs(a.x[0], a.x[1]);
    else if (name == "sort3") r = uint64_t(uint32_t(native::sort3(reinterpret_cast<i64*>(ptr(a.x[0])))));
    else if (name == "bitops") r = native::bitops(a.x[0]);
    else if (name == "sw") r = native::sw(a.x[0]);
    else { std::printf("  no native mapping for %s\n", name.c_str()); std::exit(2); }
    (void)sizeof(u64);
    return {r, std::vector<uint8_t>(mem.begin(), mem.begin() + kDataSize)};
}
} // namespace

int main() {
    using namespace a64_corpus;
    unsigned total = 0, passed = 0;
    for (const Image& img : kImages) {
        for (unsigned f = 0; f < img.count; ++f) {
            const Function& fn = img.functions[f];
            const Expected e = run_native(fn.name);
            const Outcome o = run_interpreter(img, fn);
            const uint64_t mask = returns_32(fn.name) ? 0xFFFFFFFFull : ~0ull;
            const bool ok = o.ok && (o.x0 & mask) == (e.x0 & mask) && o.data == e.data && o.sp == kStackTop - 0x100;
            ++total; passed += ok;
            if (!ok) {
                ++g_fail;
                std::printf("  FAIL %s %-12s ran=%d x0=%llx expected=%llx data=%s\n", img.opt, fn.name, o.ok,
                            (unsigned long long)o.x0, (unsigned long long)e.x0, o.data == e.data ? "same" : "DIFF");
            }
        }
    }
    std::printf("a64 corpus on the interpreter: %u/%u functions correct\n", passed, total);
    return g_fail ? 1 : 0;
}
