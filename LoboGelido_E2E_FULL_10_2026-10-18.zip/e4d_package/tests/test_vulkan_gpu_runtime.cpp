#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <string>
#include "../gpu/vulkan_gpu_runtime.h"
int main(){ lg::gpu::VulkanGpuRuntime g; LG_CHECK(!g.ready()); LG_CHECK(!g.timestamp_supported()); LG_CHECK(g.diagnostics().find("pipelineCache=OFF")!=std::string::npos); LG_CHECK(!g.write_begin_timestamp(nullptr)); LG_CHECK(!g.write_end_timestamp(nullptr)); return 0; }
