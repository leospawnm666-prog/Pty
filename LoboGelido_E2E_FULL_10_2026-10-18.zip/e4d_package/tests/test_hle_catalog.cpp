// P6.0 (P6_DISENO.md §3.1): the HLE catalog. Every entry builds its service and names a libnx
// client file and interface; the test checks the catalog is well formed and prints it as JSON
// (one line, "CATALOG {...}") for tools/hle/hle_coverage.py, which measures M-SRV / M-CMD
// against the libnx inventory (libnx_inventory.py).
#include "lg_check.h"
#include "../system/hle/hle_services.h"

#include <cstdio>
#include <set>
#include <string>

int main() {
    using namespace lg::system::hle;
    std::printf("[C1] the catalog of HLE services\n");
    const auto entries = catalog();
    LG_CHECK(!entries.empty());
    std::set<std::string> keys;
    std::string json = "{";
    bool first = true;
    for (const auto& e : entries) {
        LG_CHECK(e.libnx_file && e.libnx_interface && e.make);
        const std::string key = std::string(e.libnx_file) + "|" + e.libnx_interface;
        LG_CHECK(keys.insert(key).second);   // one class per libnx interface
        const auto object = e.make();
        LG_CHECK(object != nullptr);
        if (!first) json += ",";
        first = false;
        json += "\"" + key + "\":[";
        bool f2 = true;
        for (uint32_t id : object->command_ids()) {
            LG_CHECK(object->has(id) && object->command_name(id) != nullptr);
            json += (f2 ? "" : ",") + std::to_string(id);
            f2 = false;
        }
        json += "]";
    }
    json += "}";
    std::printf("CATALOG %s\n", json.c_str());
    std::puts("hle catalog ok");
    return 0;
}
