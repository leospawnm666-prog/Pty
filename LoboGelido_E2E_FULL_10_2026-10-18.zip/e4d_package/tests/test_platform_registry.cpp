#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "platform_registry.h"
#include <cassert>
#include <vector>
#include <cstdint>
int main() {
    using namespace lg::platform;
    LG_CHECK(detect_path("game.gbc").platform == Platform::GameBoyColor);
    LG_CHECK(detect_path("game.gba").platform == Platform::GameBoyAdvance);
    LG_CHECK(detect_path("game.z64").platform == Platform::Nintendo64);
    LG_CHECK(detect_path("game.nds").platform == Platform::NintendoDS);
    LG_CHECK(detect_path("game.3ds").platform == Platform::Nintendo3DS);
    LG_CHECK(detect_path("game.nsp").platform == Platform::NintendoSwitch);
    LG_CHECK(detect_path("game.rvz").platform == Platform::Wii);
    std::vector<uint8_t> n64 = {0x80,0x37,0x12,0x40};
    LG_CHECK(detect_magic(n64, "unknown.bin").platform == Platform::Nintendo64);
    std::vector<uint8_t> nro = {'N','R','O','0'};
    LG_CHECK(detect_magic(nro).platform == Platform::NintendoSwitch);
    LG_CHECK(CoreRegistry::find(Platform::Nintendo64));
    LG_CHECK(CoreRegistry::all().size() == 8);
    return 0;
}
