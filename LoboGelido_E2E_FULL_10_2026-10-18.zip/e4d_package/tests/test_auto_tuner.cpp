#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include "performance/auto_tuner.h"
using namespace lg::performance;
int main() {
    AutoTuner t;
    auto stable = t.update({5.0, 6.0, 14.0, 0});
    LG_CHECK(stable.resolution_scale == 100);
    LG_CHECK(stable.pipeline_workers == 4);
    LG_CHECK(stable.target_fps == 60);
    LG_CHECK(stable.confidence >= 80);

    auto gpu = t.update({7.0, 18.0, 24.0, 0});
    LG_CHECK(gpu.resolution_scale == 85);
    LG_CHECK(gpu.pipeline_workers == 4);
    LG_CHECK(gpu.gpu_async);
    LG_CHECK(gpu.dynamic_resolution);

    auto thermal = t.update({8.0, 9.0, 29.0, 4});
    LG_CHECK(thermal.resolution_scale == 75);
    LG_CHECK(!thermal.async_shaders);
    LG_CHECK(!thermal.gpu_async);
    LG_CHECK(!thermal.async_present);
    LG_CHECK(thermal.target_fps == 30);
    LG_CHECK(thermal.dynamic_resolution);
    return 0;
}
