#pragma once
// P4.1 T3 (P4_DISENO.md §5.3): differential run of one compute shader.
//   Path A: GLSL -> uam -> Maxwell (.dksh) -> lg::shader::translate -> SPIR-V
//   Path B: GLSL -> glslang -> SPIR-V
// Both run on the oracle (SwiftShader) with the same inputs; outputs must match (bit for bit for
// integer buffers, within `tol` ULP for float buffers).
//
// The GLSL carries its test setup in comments:
//   // dispatch: X Y Z
//   // buffer: <binding> <u|i|f|z|w> <words>    storage buffer (z: zeros, exact; w: zeros, float)
//   // ubo: <binding> <u|i|f> <words>           uniform buffer
//   // tol: <ulp>                               float tolerance (default 4)
//   // atol: <x>                                also accept an absolute float difference <= x
//   // rtol: <ulp> / ratol: <x>                 the same against the reference interpreter
// SSBO bindings are < 8 and UBO bindings in 8..15 (uam: UBO binding N -> c[N + 2]).
// P4.3: textures and storage images (tex_spec.h: `// tex:` / `// img:`); with them the reference
// interpreter (no texture unit) is not run, and storage images are compared like buffers.
#include "dksh.h"
#include "tex_spec.h"
#include "maxwell_ref.h"
#include "vk_compute.h"
#include "../../shader/translate.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace lg_test::t3 {

struct BufSpec { uint32_t binding; bool uniform; char kind; uint32_t words; };
struct Spec {
    uint32_t groups[3]{1, 1, 1};
    std::vector<BufSpec> bufs;
    uint32_t tol{4};
    float atol{0.f};   // also accept |a - b| <= atol (fused vs unfused multiply-add)
    // Against the reference interpreter (libm transcendental functions, fused FFMA) instead of
    // SwiftShader's approximations: own tolerances (default: the ones above).
    uint32_t rtol{0};
    float ratol{0.f};
    // P4.4: 'd' buffers (doubles) match when equal, both NaN, or within this relative difference
    double drel{0.0};
};

inline Spec parse_spec(const std::string& glsl) {
    Spec s;
    std::istringstream in(glsl);
    std::string line;
    while (std::getline(in, line)) {
        unsigned a, b, c;
        char k;
        if (line.rfind("// ", 0) != 0) continue;
        if (std::sscanf(line.c_str(), "// dispatch: %u %u %u", &a, &b, &c) == 3) { s.groups[0] = a; s.groups[1] = b; s.groups[2] = c; }
        else if (std::sscanf(line.c_str(), "// buffer: %u %c %u", &a, &k, &b) == 3) s.bufs.push_back({a, false, k, b});
        else if (std::sscanf(line.c_str(), "// ubo: %u %c %u", &a, &k, &b) == 3) s.bufs.push_back({a, true, k, b});
        else if (std::sscanf(line.c_str(), "// tol: %u", &a) == 1) s.tol = a;
        else if (float t; std::sscanf(line.c_str(), "// atol: %f", &t) == 1) s.atol = t;
        else if (std::sscanf(line.c_str(), "// rtol: %u", &a) == 1) s.rtol = a;
        else if (float t2; std::sscanf(line.c_str(), "// ratol: %f", &t2) == 1) s.ratol = t2;
        else if (double t3; std::sscanf(line.c_str(), "// drel: %lf", &t3) == 1) s.drel = t3;
    }
    s.rtol = std::max(s.rtol, s.tol);
    s.ratol = std::max(s.ratol, s.atol);
    return s;
}

inline std::vector<uint8_t> make_data(const BufSpec& b) {
    std::vector<uint8_t> d(static_cast<size_t>(b.words) * 4, 0);
    uint32_t x = 0x9E3779B9u ^ (b.binding * 0x85EBCA6Bu) ^ (b.uniform ? 0x1234567u : 0);
    for (uint32_t i = 0; i < b.words; ++i) {
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        uint32_t v = 0;
        switch (b.kind) {
            case 'u': v = x; break;
            case 'i': v = static_cast<uint32_t>(static_cast<int32_t>(x % 2001) - 1000); break;
            case 'f': {
                const float f = (static_cast<float>(x % 160001) - 80000.f) / 10000.f;   // [-8, 8]
                std::memcpy(&v, &f, 4);
                break;
            }
            case 'd': {   // P4.4: doubles in [-8, 8] (two words each)
                if (i % 2) continue;
                const double f = (static_cast<double>(x % 1600001) - 800000.0) / 100000.0 + static_cast<double>(x >> 21) * 1e-9;
                if (i + 1 < b.words) std::memcpy(&d[i * 4], &f, 8);
                continue;
            }
            default: v = 0; break;
        }
        std::memcpy(&d[i * 4], &v, 4);
    }
    return d;
}

inline uint32_t ulp_diff(uint32_t a, uint32_t b) {
    if (a == b) return 0;
    float fa, fb;
    std::memcpy(&fa, &a, 4);
    std::memcpy(&fb, &b, 4);
    if (std::isnan(fa) && std::isnan(fb)) return 0;
    if (std::isnan(fa) || std::isnan(fb)) return ~0u;
    auto key = [](uint32_t u) -> int64_t { return (u & 0x80000000u) ? -static_cast<int64_t>(u & 0x7fffffffu) : static_cast<int64_t>(u); };
    const int64_t d = key(a) - key(b);
    return static_cast<uint32_t>(std::min<int64_t>(d < 0 ? -d : d, 0xffffffff));
}

struct Outcome {
    bool ok{false};
    std::string message;
    bool reference_ok{false};       // the scalar reference interpreter agreed too
    std::string reference_message;
    lg::shader::TranslationResult tr;
};

constexpr uint32_t kCbufBindingBase = 32;   // path A: constant buffer bank b -> binding 32 + b
constexpr uint32_t kUboTableBinding = 64;   // path A: UBO binding N >= 6 (global) -> 64 + N
constexpr uint64_t kFakeIova = 0x1'2340'0000ull;

inline Outcome run(vk::ComputeRunner& runner, const std::string& glsl, const std::vector<uint8_t>& dksh_bytes,
                   const std::vector<uint32_t>& ref_spirv) {
    Outcome o;
    const Spec spec = parse_spec(glsl);
    dksh::Compute prog;
    if (!dksh::parse_compute(dksh_bytes, prog, o.message)) return o;
    // ---- path A: translate ----
    lg::shader::ShaderInfo info;
    const std::vector<tex::TexSpec> texspecs = tex::parse(glsl);
    constexpr uint32_t kResbase = 0x0a0;   // deko3d compute resources in c0
    for (const auto& t : texspecs) {
        if (t.storage) info.images.push_back({0, kResbase + 0x80 + 4 * t.binding, tex::image_format(t.fmt), tex::attrib_type(t.fmt)});
        else info.textures.push_back({0, kResbase + 4 * t.binding, tex::attrib_type(t.fmt)});
    }
    info.texture_first_binding = 96;
    for (int i = 0; i < 3; ++i) info.local_size[i] = prog.block_dims[i];
    info.shared_memory_bytes = prog.shared_mem;
    info.local_memory_bytes = prog.local_mem;
    info.global_tables = lg::shader::deko3d_compute_tables(0, kUboTableBinding);
    for (uint32_t bank = 0; bank < 18; ++bank) info.cbufs.push_back({bank, kCbufBindingBase + bank});
    o.tr = lg::shader::translate(prog.code, info);
    if (!o.tr.ok) { o.message = "traducción: " + o.tr.error; return o; }
    // inputs shared by both paths
    std::vector<vk::Buffer> base;
    for (const BufSpec& b : spec.bufs) base.push_back({b.binding, b.uniform, make_data(b)});
    // path A buffers: SSBOs at their GLSL binding; UBO binding N -> bank N + 2; bank 0 (driver), 1
    std::vector<vk::Buffer> a_bufs;
    std::vector<uint8_t> drv(0x10000, 0);
    auto put = [&](uint32_t off, uint32_t v) { std::memcpy(&drv[off], &v, 4); };
    for (int i = 0; i < 3; ++i) { put(0x0 + 4 * i, prog.block_dims[i]); put(0xc + 4 * i, spec.groups[i]); }
    for (const vk::Buffer& b : base) {
        if (b.uniform) {
            std::vector<uint8_t> d(0x10000, 0);
            std::memcpy(d.data(), b.data.data(), std::min(d.size(), b.data.size()));
            if (b.binding < 6) {   // hardware constant buffer c[N + 2]
                a_bufs.push_back({kCbufBindingBase + b.binding + 2, true, d});
            } else {               // compute UBOs 6+: read from global memory (uboInfoBase 0x20)
                const uint64_t iova = kFakeIova + (uint64_t{0x40 + b.binding} << 24);
                put(0x20 + 8 * b.binding, static_cast<uint32_t>(iova));
                put(0x24 + 8 * b.binding, static_cast<uint32_t>(iova >> 32));
                a_bufs.push_back({kUboTableBinding + b.binding, false, d});
            }
        } else {
            const uint64_t iova = kFakeIova + (uint64_t{b.binding} << 24);
            put(0x140 + 16 * b.binding, static_cast<uint32_t>(iova));
            put(0x144 + 16 * b.binding, static_cast<uint32_t>(iova >> 32));
            put(0x148 + 16 * b.binding, static_cast<uint32_t>(b.data.size()));
            a_bufs.push_back(b);
        }
    }
    {
        std::vector<uint8_t> cb1(0x10000, 0);
        if (!prog.constbuf1.empty())
            std::memcpy(cb1.data(), prog.constbuf1.data(), std::min(cb1.size(), prog.constbuf1.size()));
        a_bufs.push_back({kCbufBindingBase + 1, true, cb1});
        a_bufs.push_back({kCbufBindingBase + 0, true, drv});
    }
    // only bind what the translated shader declares (+ every SSBO, which both paths write)
    std::vector<vk::Buffer> a_used;
    for (vk::Buffer& b : a_bufs) {
        bool used = !b.uniform && b.binding < kCbufBindingBase;
        for (const auto& r : o.tr.resources)
            if (r.binding == b.binding) used = true;
        if (used) a_used.push_back(b);
    }
    std::vector<vk::Texture> a_tex, b_tex;
    std::vector<int> a_primary;
    if (!tex::for_translation(texspecs, o.tr, kResbase, a_tex, a_primary, o.message)) return o;
    for (const auto& t : texspecs) b_tex.push_back(tex::make(t, t.binding));
    for (const auto& r : o.tr.resources) {
        if (r.kind == lg::shader::ResourceUse::Kind::Texture || r.kind == lg::shader::ResourceUse::Kind::Image) continue;
        bool found = false;
        for (const auto& b : a_used) found = found || b.binding == r.binding;
        if (!found) { o.message = "recurso sin buffer: binding " + std::to_string(r.binding); return o; }
    }
    std::vector<vk::Buffer> b_bufs = base;
    if (!runner.run(o.tr.spirv, a_used, spec.groups, a_tex)) { o.message = "ejecución A: " + runner.error(); return o; }
    if (!runner.run(ref_spirv, b_bufs, spec.groups, b_tex)) { o.message = "ejecución B: " + runner.error(); return o; }
    // compare every storage buffer of two runs
    auto compare = [&](const std::vector<vk::Buffer>& X, const std::vector<vk::Buffer>& Y, const char* nx,
                       const char* ny, std::string& msg, uint32_t tol, float atol) -> bool {
        for (const BufSpec& bs : spec.bufs) {
            if (bs.uniform) continue;
            const vk::Buffer* A = nullptr;
            const vk::Buffer* Bb = nullptr;
            for (const auto& b : X) if (!b.uniform && b.binding == bs.binding) A = &b;
            for (const auto& b : Y) if (!b.uniform && b.binding == bs.binding) Bb = &b;
            if (!A || !Bb) { msg = "buffer ausente"; return false; }
            if (bs.kind == 'd') {   // P4.4: doubles
                for (uint32_t i = 0; i + 1 < bs.words; i += 2) {
                    double da, db;
                    std::memcpy(&da, &A->data[i * 4], 8);
                    std::memcpy(&db, &Bb->data[i * 4], 8);
                    if (std::memcmp(&da, &db, 8) == 0 || (std::isnan(da) && std::isnan(db))) continue;
                    if (spec.drel > 0 && std::fabs(da - db) <= spec.drel * std::max(std::fabs(da), std::fabs(db))) continue;
                    char buf[200];
                    std::snprintf(buf, sizeof buf, "buffer %u[%u] (double): %s %.17g, %s %.17g", bs.binding, i / 2, nx, da, ny, db);
                    msg = buf;
                    return false;
                }
                continue;
            }
            for (uint32_t i = 0; i < bs.words; ++i) {
                uint32_t va, vb;
                std::memcpy(&va, &A->data[i * 4], 4);
                std::memcpy(&vb, &Bb->data[i * 4], 4);
                const bool float_buf = bs.kind == 'f' || bs.kind == 'w';
                const uint32_t d = float_buf ? ulp_diff(va, vb) : (va == vb ? 0 : ~0u);
                bool close = float_buf && d <= tol;
                if (float_buf && !close && atol > 0.f) {
                    float fa, fb;
                    std::memcpy(&fa, &va, 4);
                    std::memcpy(&fb, &vb, 4);
                    close = std::fabs(fa - fb) <= atol;
                }
                if (va != vb && !close) {
                    char buf[160];
                    std::snprintf(buf, sizeof buf, "buffer %u[%u]: %s 0x%08x, %s 0x%08x", bs.binding, i, nx, va, ny, vb);
                    msg = buf;
                    return false;
                }
            }
        }
        return true;
    };
    if (!compare(a_used, b_bufs, "recompilado", "glslang", o.message, spec.tol, spec.atol)) return o;
    // storage images: the image each spec names (path A: its first view), word by word
    for (size_t k = 0; k < texspecs.size(); ++k) {
        if (!texspecs[k].storage || a_primary[k] < 0) continue;
        const auto& A = a_tex[static_cast<size_t>(a_primary[k])].data;
        const auto& Bd = b_tex[k].data;
        const bool flt = texspecs[k].fmt == 'f' || texspecs[k].fmt == 'g';
        for (size_t i = 0; i + 4 <= std::min(A.size(), Bd.size()); i += 4) {
            uint32_t va, vb;
            std::memcpy(&va, &A[i], 4);
            std::memcpy(&vb, &Bd[i], 4);
            if (va == vb || (flt && ulp_diff(va, vb) <= spec.tol)) continue;
            char buf[160];
            std::snprintf(buf, sizeof buf, "imagen %u, palabra %zu: recompilado 0x%08x, glslang 0x%08x", texspecs[k].binding, i / 4, va, vb);
            o.message = buf;
            return o;
        }
    }
    if (!texspecs.empty()) {   // the reference interpreter has no texture unit
        o.reference_ok = true;
        o.reference_message = "sin referencia (texturas)";
        o.ok = true;
        return o;
    }
    // ---- path R: the scalar reference interpreter on the same Maxwell code and inputs ----
    {
        std::vector<vk::Buffer> r_bufs = base;   // fresh inputs
        mref::Memory mem;
        mem.cbufs.assign(18, std::vector<uint8_t>());
        for (const vk::Buffer& b : a_bufs)
            if (b.uniform && b.binding >= kCbufBindingBase && b.binding < kCbufBindingBase + 18)
                mem.cbufs[b.binding - kCbufBindingBase] = b.data;
        std::vector<std::vector<uint8_t>> ubo_copies;
        ubo_copies.reserve(16);
        for (vk::Buffer& b : r_bufs) {
            if (!b.uniform) {
                mem.globals.push_back({kFakeIova + (uint64_t{b.binding} << 24), &b.data});
            } else if (b.binding >= 6) {
                std::vector<uint8_t> d(0x10000, 0);
                std::memcpy(d.data(), b.data.data(), std::min(d.size(), b.data.size()));
                ubo_copies.push_back(std::move(d));
                mem.globals.push_back({kFakeIova + (uint64_t{0x40 + b.binding} << 24), &ubo_copies.back()});
            }
        }
        mref::Dispatch dd;
        for (int i = 0; i < 3; ++i) { dd.local_size[i] = prog.block_dims[i]; dd.groups[i] = spec.groups[i]; }
        dd.shared_bytes = prog.shared_mem;
        dd.local_bytes = prog.local_mem;
        const std::string err = mref::run(prog.code, dd, mem);
        if (!err.empty()) o.reference_message = "referencia: " + err;
        else if (compare(r_bufs, a_used, "referencia", "recompilado", o.reference_message, spec.rtol, spec.ratol))
            o.reference_ok = true;
    }
    o.ok = true;
    return o;
}

} // namespace lg_test::t3
