#include "vk_graphics.h"

#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.h>

#include <dlfcn.h>
#include <link.h>

#include "vk_textures.h"

#include <cstring>

namespace lg_test::vk {

struct GraphicsRunner::Impl {
    void* so{nullptr};
    std::string error;
    VkInstance inst{VK_NULL_HANDLE};
    VkPhysicalDevice pd{VK_NULL_HANDLE};
    VkDevice dev{VK_NULL_HANDLE};
    VkQueue queue{VK_NULL_HANDLE};
    VkCommandPool pool{VK_NULL_HANDLE};
    VkPhysicalDeviceMemoryProperties mp{};
    VkPhysicalDeviceProperties props{};
    VkPhysicalDeviceFeatures feats{};
    bool draw_parameters{false};
    PFN_vkGetDeviceProcAddr gdpa_{nullptr};
    PFN_vkDestroyInstance vkDestroyInstance{nullptr};
#define LG_FNS(X) X(vkDestroyDevice) X(vkGetDeviceQueue) X(vkCreateBuffer) X(vkDestroyBuffer) \
    X(vkGetBufferMemoryRequirements) X(vkAllocateMemory) X(vkFreeMemory) X(vkBindBufferMemory) X(vkMapMemory) \
    X(vkCreateImage) X(vkDestroyImage) X(vkGetImageMemoryRequirements) X(vkBindImageMemory) X(vkCreateImageView) \
    X(vkDestroyImageView) X(vkCreateRenderPass) X(vkDestroyRenderPass) X(vkCreateFramebuffer) X(vkDestroyFramebuffer) \
    X(vkCreateShaderModule) X(vkDestroyShaderModule) X(vkCreateDescriptorSetLayout) X(vkDestroyDescriptorSetLayout) \
    X(vkCreatePipelineLayout) X(vkDestroyPipelineLayout) X(vkCreateGraphicsPipelines) X(vkDestroyPipeline) \
    X(vkCreateDescriptorPool) X(vkDestroyDescriptorPool) X(vkAllocateDescriptorSets) X(vkUpdateDescriptorSets) \
    X(vkCreateCommandPool) X(vkDestroyCommandPool) X(vkAllocateCommandBuffers) X(vkFreeCommandBuffers) \
    X(vkBeginCommandBuffer) X(vkEndCommandBuffer) X(vkCmdBeginRenderPass) X(vkCmdEndRenderPass) X(vkCmdBindPipeline) \
    X(vkCmdBindDescriptorSets) X(vkCmdBindVertexBuffers) X(vkCmdDraw) X(vkCmdCopyImageToBuffer) \
    X(vkCmdPipelineBarrier) X(vkQueueSubmit) X(vkQueueWaitIdle)
#define LG_DECL(name) PFN_##name name{nullptr};
    LG_FNS(LG_DECL)
#undef LG_DECL

    bool fail(const char* what, VkResult r) {
        error = std::string(what) + " = " + std::to_string(static_cast<int>(r));
        return false;
    }

    bool init(const std::string& loader) {
        so = dlopen(loader.c_str(), RTLD_NOW | RTLD_LOCAL);
        if (!so) { error = std::string("dlopen: ") + dlerror(); return false; }
        auto gipa = reinterpret_cast<PFN_vkGetInstanceProcAddr>(dlsym(so, "vkGetInstanceProcAddr"));
        if (!gipa) { error = "vkGetInstanceProcAddr missing"; return false; }
        auto create_instance = reinterpret_cast<PFN_vkCreateInstance>(gipa(VK_NULL_HANDLE, "vkCreateInstance"));
        VkApplicationInfo app{};
        app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
        app.apiVersion = VK_API_VERSION_1_1;
        VkInstanceCreateInfo ici{};
        ici.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
        ici.pApplicationInfo = &app;
        if (VkResult r = create_instance(&ici, nullptr, &inst); r != VK_SUCCESS) return fail("vkCreateInstance", r);
        vkDestroyInstance = reinterpret_cast<PFN_vkDestroyInstance>(gipa(inst, "vkDestroyInstance"));
        auto enumerate = reinterpret_cast<PFN_vkEnumeratePhysicalDevices>(gipa(inst, "vkEnumeratePhysicalDevices"));
        auto get_mem = reinterpret_cast<PFN_vkGetPhysicalDeviceMemoryProperties>(gipa(inst, "vkGetPhysicalDeviceMemoryProperties"));
        auto get_props = reinterpret_cast<PFN_vkGetPhysicalDeviceProperties>(gipa(inst, "vkGetPhysicalDeviceProperties"));
        auto get_feats2 = reinterpret_cast<PFN_vkGetPhysicalDeviceFeatures2>(gipa(inst, "vkGetPhysicalDeviceFeatures2"));
        auto create_device = reinterpret_cast<PFN_vkCreateDevice>(gipa(inst, "vkCreateDevice"));
        auto gdpa = reinterpret_cast<PFN_vkGetDeviceProcAddr>(gipa(inst, "vkGetDeviceProcAddr"));
        gdpa_ = gdpa;
        uint32_t n = 1;
        if (VkResult r = enumerate(inst, &n, &pd); (r != VK_SUCCESS && r != VK_INCOMPLETE) || n == 0)
            return fail("vkEnumeratePhysicalDevices", r);
        get_mem(pd, &mp);
        get_props(pd, &props);
        VkPhysicalDeviceShaderDrawParametersFeatures dp{};
        dp.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_DRAW_PARAMETERS_FEATURES;
        VkPhysicalDeviceFeatures2 f2{};
        f2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
        f2.pNext = &dp;
        get_feats2(pd, &f2);
        // enable what the tests can use, if present
        VkPhysicalDeviceFeatures en{};
        en.geometryShader = f2.features.geometryShader;
        en.tessellationShader = f2.features.tessellationShader;
        en.vertexPipelineStoresAndAtomics = f2.features.vertexPipelineStoresAndAtomics;
        en.fragmentStoresAndAtomics = f2.features.fragmentStoresAndAtomics;
        en.shaderClipDistance = f2.features.shaderClipDistance;
        en.largePoints = f2.features.largePoints;
        en.shaderTessellationAndGeometryPointSize = f2.features.shaderTessellationAndGeometryPointSize;
        en.sampleRateShading = f2.features.sampleRateShading;
        en.imageCubeArray = f2.features.imageCubeArray;   // P4.3: what the texture tests can use
        en.shaderImageGatherExtended = f2.features.shaderImageGatherExtended;
        en.shaderStorageImageExtendedFormats = f2.features.shaderStorageImageExtendedFormats;
        en.shaderStorageImageReadWithoutFormat = f2.features.shaderStorageImageReadWithoutFormat;
        en.shaderStorageImageWriteWithoutFormat = f2.features.shaderStorageImageWriteWithoutFormat;
        feats = en;
        VkPhysicalDeviceShaderDrawParametersFeatures dp_en{};
        dp_en.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_DRAW_PARAMETERS_FEATURES;
        dp_en.shaderDrawParameters = dp.shaderDrawParameters;
        draw_parameters = dp.shaderDrawParameters;
        const float prio = 1.0f;
        VkDeviceQueueCreateInfo q{};
        q.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        q.queueCount = 1;
        q.pQueuePriorities = &prio;
        VkDeviceCreateInfo dci{};
        dci.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
        dci.pNext = &dp_en;
        dci.queueCreateInfoCount = 1;
        dci.pQueueCreateInfos = &q;
        dci.pEnabledFeatures = &en;
        if (VkResult r = create_device(pd, &dci, nullptr, &dev); r != VK_SUCCESS) return fail("vkCreateDevice", r);
        // Pin the ICD and what it loaded (LLVM for lavapipe) until the process exits. The loader
        // unloads the ICD in vkDestroyInstance; lavapipe and LLVM keep allocations reachable only
        // from their own static data, which LeakSanitizer can no longer scan once unmapped, and
        // reports them as leaks (checked: with the libraries kept there is none; this harness
        // destroys every object it creates).
        dl_iterate_phdr([](dl_phdr_info* i, size_t, void*) -> int {
            if (i->dlpi_name && i->dlpi_name[0]) dlopen(i->dlpi_name, RTLD_LAZY | RTLD_NOLOAD | RTLD_NODELETE);
            return 0;
        }, nullptr);
#define LG_LOAD(name) name = reinterpret_cast<PFN_##name>(gdpa(dev, #name)); if (!name) { error = #name " missing"; return false; }
        LG_FNS(LG_LOAD)
#undef LG_LOAD
        vkGetDeviceQueue(dev, 0, 0, &queue);
        VkCommandPoolCreateInfo cpci{};
        cpci.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
        if (VkResult r = vkCreateCommandPool(dev, &cpci, nullptr, &pool); r != VK_SUCCESS) return fail("vkCreateCommandPool", r);
        return true;
    }

    ~Impl() {
        if (dev) {
            if (pool) vkDestroyCommandPool(dev, pool, nullptr);
            vkDestroyDevice(dev, nullptr);
        }
        if (inst && vkDestroyInstance) vkDestroyInstance(inst, nullptr);
        if (so) dlclose(so);
    }

    uint32_t mem_type(uint32_t bits, VkMemoryPropertyFlags want) {
        for (uint32_t t = 0; t < mp.memoryTypeCount; ++t)
            if ((bits & (1u << t)) && (mp.memoryTypes[t].propertyFlags & want) == want) return t;
        return 0;
    }
};

GraphicsRunner::GraphicsRunner(const std::string& loader) : impl_(std::make_unique<Impl>()) {
    if (!impl_->init(loader) && impl_->error.empty()) impl_->error = "init failed";
}
GraphicsRunner::~GraphicsRunner() = default;
bool GraphicsRunner::ok() const noexcept { return impl_->dev != VK_NULL_HANDLE && impl_->error.empty(); }
const std::string& GraphicsRunner::error() const noexcept { return impl_->error; }
std::string GraphicsRunner::device_name() const { return impl_->props.deviceName; }
bool GraphicsRunner::has_geometry() const noexcept { return impl_->feats.geometryShader; }
bool GraphicsRunner::has_tessellation() const noexcept { return impl_->feats.tessellationShader; }
bool GraphicsRunner::has_draw_parameters() const noexcept { return impl_->draw_parameters; }

bool GraphicsRunner::run(GraphicsJob& job, GraphicsResult& out) {
    Impl& I = *impl_;
    I.error.clear();
    constexpr uint32_t S = kSize;
    struct Res {
        Impl& I;
        std::vector<VkBuffer> bufs;
        std::vector<VkDeviceMemory> mems;
        std::vector<VkImage> images;
        std::vector<VkImageView> views;
        std::vector<VkShaderModule> modules;
        VkRenderPass rp{VK_NULL_HANDLE};
        VkFramebuffer fb{VK_NULL_HANDLE};
        VkDescriptorSetLayout dsl{VK_NULL_HANDLE};
        VkPipelineLayout pl{VK_NULL_HANDLE};
        VkPipeline pipe{VK_NULL_HANDLE};
        VkDescriptorPool dp{VK_NULL_HANDLE};
        VkCommandBuffer cb{VK_NULL_HANDLE};
        ~Res() {
            if (cb) I.vkFreeCommandBuffers(I.dev, I.pool, 1, &cb);
            if (dp) I.vkDestroyDescriptorPool(I.dev, dp, nullptr);
            if (pipe) I.vkDestroyPipeline(I.dev, pipe, nullptr);
            if (pl) I.vkDestroyPipelineLayout(I.dev, pl, nullptr);
            if (dsl) I.vkDestroyDescriptorSetLayout(I.dev, dsl, nullptr);
            if (fb) I.vkDestroyFramebuffer(I.dev, fb, nullptr);
            if (rp) I.vkDestroyRenderPass(I.dev, rp, nullptr);
            for (auto m : modules) I.vkDestroyShaderModule(I.dev, m, nullptr);
            for (auto v : views) I.vkDestroyImageView(I.dev, v, nullptr);
            for (auto i : images) I.vkDestroyImage(I.dev, i, nullptr);
            for (auto b : bufs) I.vkDestroyBuffer(I.dev, b, nullptr);
            for (auto m : mems) I.vkFreeMemory(I.dev, m, nullptr);
        }
    } R{I};
    auto make_buf = [&](VkDeviceSize size, VkBufferUsageFlags usage, const void* init, VkBuffer& b, void*& map) -> bool {
        VkBufferCreateInfo bi{};
        bi.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
        bi.size = size ? size : 16;
        bi.usage = usage;
        if (VkResult r = I.vkCreateBuffer(I.dev, &bi, nullptr, &b); r != VK_SUCCESS) return I.fail("vkCreateBuffer", r);
        R.bufs.push_back(b);
        VkMemoryRequirements req;
        I.vkGetBufferMemoryRequirements(I.dev, b, &req);
        VkMemoryAllocateInfo ai{};
        ai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        ai.allocationSize = req.size;
        ai.memoryTypeIndex = I.mem_type(req.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        VkDeviceMemory m;
        if (VkResult r = I.vkAllocateMemory(I.dev, &ai, nullptr, &m); r != VK_SUCCESS) return I.fail("vkAllocateMemory", r);
        R.mems.push_back(m);
        I.vkBindBufferMemory(I.dev, b, m, 0);
        if (VkResult r = I.vkMapMemory(I.dev, m, 0, VK_WHOLE_SIZE, 0, &map); r != VK_SUCCESS) return I.fail("vkMapMemory", r);
        std::memset(map, 0, bi.size);
        if (init && size) std::memcpy(map, init, size);
        return true;
    };
    auto make_image = [&](VkFormat fmt, VkImageUsageFlags usage, VkImageAspectFlags aspect, VkImageView& view) -> bool {
        VkImageCreateInfo ii{};
        ii.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
        ii.imageType = VK_IMAGE_TYPE_2D;
        ii.format = fmt;
        ii.extent = {S, S, 1};
        ii.mipLevels = 1;
        ii.arrayLayers = 1;
        ii.samples = VK_SAMPLE_COUNT_1_BIT;
        ii.tiling = VK_IMAGE_TILING_OPTIMAL;
        ii.usage = usage | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
        VkImage img;
        if (VkResult r = I.vkCreateImage(I.dev, &ii, nullptr, &img); r != VK_SUCCESS) return I.fail("vkCreateImage", r);
        R.images.push_back(img);
        VkMemoryRequirements req;
        I.vkGetImageMemoryRequirements(I.dev, img, &req);
        VkMemoryAllocateInfo ai{};
        ai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        ai.allocationSize = req.size;
        ai.memoryTypeIndex = I.mem_type(req.memoryTypeBits, 0);
        VkDeviceMemory m;
        if (VkResult r = I.vkAllocateMemory(I.dev, &ai, nullptr, &m); r != VK_SUCCESS) return I.fail("vkAllocateMemory", r);
        R.mems.push_back(m);
        I.vkBindImageMemory(I.dev, img, m, 0);
        VkImageViewCreateInfo vi{};
        vi.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        vi.image = img;
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format = fmt;
        vi.subresourceRange = {aspect, 0, 1, 0, 1};
        if (VkResult r = I.vkCreateImageView(I.dev, &vi, nullptr, &view); r != VK_SUCCESS) return I.fail("vkCreateImageView", r);
        R.views.push_back(view);
        return true;
    };
    // ---- attachments
    static const VkFormat kFmt[3] = {VK_FORMAT_R32G32B32A32_SFLOAT, VK_FORMAT_R32G32B32A32_SINT, VK_FORMAT_R32G32B32A32_UINT};
    std::vector<VkAttachmentDescription> atts;
    std::vector<VkAttachmentReference> color_refs;
    std::vector<VkImageView> fb_views;
    uint32_t max_loc = 0;
    for (const auto& t : job.targets) max_loc = std::max(max_loc, t.location + 1);
    color_refs.assign(max_loc, {VK_ATTACHMENT_UNUSED, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL});
    std::vector<VkImage> target_images;
    for (const auto& t : job.targets) {
        VkImageView v;
        if (!make_image(kFmt[t.type], VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, VK_IMAGE_ASPECT_COLOR_BIT, v)) return false;
        target_images.push_back(R.images.back());
        VkAttachmentDescription a{};
        a.format = kFmt[t.type];
        a.samples = VK_SAMPLE_COUNT_1_BIT;
        a.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        a.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        a.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        a.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        a.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        a.finalLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        color_refs[t.location] = {static_cast<uint32_t>(atts.size()), VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        atts.push_back(a);
        fb_views.push_back(v);
    }
    VkAttachmentReference depth_ref{VK_ATTACHMENT_UNUSED, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkImage depth_image = VK_NULL_HANDLE;
    if (job.depth) {
        VkImageView v;
        if (!make_image(VK_FORMAT_D32_SFLOAT, VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT, VK_IMAGE_ASPECT_DEPTH_BIT, v)) return false;
        depth_image = R.images.back();
        VkAttachmentDescription a{};
        a.format = VK_FORMAT_D32_SFLOAT;
        a.samples = VK_SAMPLE_COUNT_1_BIT;
        a.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        a.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        a.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        a.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        a.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        a.finalLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
        depth_ref.attachment = static_cast<uint32_t>(atts.size());
        atts.push_back(a);
        fb_views.push_back(v);
    }
    VkSubpassDescription sub{};
    sub.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sub.colorAttachmentCount = static_cast<uint32_t>(color_refs.size());
    sub.pColorAttachments = color_refs.data();
    sub.pDepthStencilAttachment = job.depth ? &depth_ref : nullptr;
    VkRenderPassCreateInfo rpi{};
    rpi.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    rpi.attachmentCount = static_cast<uint32_t>(atts.size());
    rpi.pAttachments = atts.data();
    rpi.subpassCount = 1;
    rpi.pSubpasses = &sub;
    if (VkResult r = I.vkCreateRenderPass(I.dev, &rpi, nullptr, &R.rp); r != VK_SUCCESS) return I.fail("vkCreateRenderPass", r);
    VkFramebufferCreateInfo fbi{};
    fbi.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    fbi.renderPass = R.rp;
    fbi.attachmentCount = static_cast<uint32_t>(fb_views.size());
    fbi.pAttachments = fb_views.data();
    fbi.width = S;
    fbi.height = S;
    fbi.layers = 1;
    if (VkResult r = I.vkCreateFramebuffer(I.dev, &fbi, nullptr, &R.fb); r != VK_SUCCESS) return I.fail("vkCreateFramebuffer", r);
    // ---- descriptors
    TextureSet texset(I.gdpa_, I.dev, I.queue, I.pool, I.mp);
    if (!job.textures.empty() && !texset.create(job.textures)) { I.error = texset.error(); return false; }
    std::vector<VkDescriptorSetLayoutBinding> binds;
    std::vector<void*> maps;
    uint32_t nu = 0, ns = 0;
    for (const Buffer& b : job.buffers) {
        binds.push_back({b.binding, b.uniform ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER : VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1,
                         VK_SHADER_STAGE_ALL_GRAPHICS, nullptr});
        (b.uniform ? nu : ns)++;
        VkBuffer vb;
        void* m;
        if (!make_buf(b.data.size(), b.uniform ? VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT : VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                      b.data.data(), vb, m))
            return false;
        maps.push_back(m);
    }
    const size_t nbufs = job.buffers.size();
    std::vector<VkDescriptorPoolSize> tps;
    texset.layout(job.textures, VK_SHADER_STAGE_ALL_GRAPHICS, binds, tps);
    VkDescriptorSetLayoutCreateInfo dli{};
    dli.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
    dli.bindingCount = static_cast<uint32_t>(binds.size());
    dli.pBindings = binds.data();
    if (VkResult r = I.vkCreateDescriptorSetLayout(I.dev, &dli, nullptr, &R.dsl); r != VK_SUCCESS) return I.fail("vkCreateDescriptorSetLayout", r);
    VkPipelineLayoutCreateInfo pli{};
    pli.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    pli.setLayoutCount = 1;
    pli.pSetLayouts = &R.dsl;
    if (VkResult r = I.vkCreatePipelineLayout(I.dev, &pli, nullptr, &R.pl); r != VK_SUCCESS) return I.fail("vkCreatePipelineLayout", r);
    VkDescriptorSet ds = VK_NULL_HANDLE;
    if (nbufs || !job.textures.empty()) {
        std::vector<VkDescriptorPoolSize> ps;
        if (nu) ps.push_back({VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, nu});
        if (ns) ps.push_back({VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, ns});
        ps.insert(ps.end(), tps.begin(), tps.end());
        VkDescriptorPoolCreateInfo dpi{};
        dpi.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
        dpi.maxSets = 1;
        dpi.poolSizeCount = static_cast<uint32_t>(ps.size());
        dpi.pPoolSizes = ps.data();
        if (VkResult r = I.vkCreateDescriptorPool(I.dev, &dpi, nullptr, &R.dp); r != VK_SUCCESS) return I.fail("vkCreateDescriptorPool", r);
        VkDescriptorSetAllocateInfo dai{};
        dai.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
        dai.descriptorPool = R.dp;
        dai.descriptorSetCount = 1;
        dai.pSetLayouts = &R.dsl;
        if (VkResult r = I.vkAllocateDescriptorSets(I.dev, &dai, &ds); r != VK_SUCCESS) return I.fail("vkAllocateDescriptorSets", r);
        std::vector<VkDescriptorBufferInfo> infos(nbufs);
        std::vector<VkWriteDescriptorSet> writes(nbufs);
        for (size_t i = 0; i < nbufs; ++i) {
            infos[i] = {R.bufs[i], 0, VK_WHOLE_SIZE};
            writes[i] = {};
            writes[i].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
            writes[i].dstSet = ds;
            writes[i].dstBinding = job.buffers[i].binding;
            writes[i].descriptorCount = 1;
            writes[i].descriptorType = job.buffers[i].uniform ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER : VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
            writes[i].pBufferInfo = &infos[i];
        }
        texset.writes(job.textures, ds, writes);
        I.vkUpdateDescriptorSets(I.dev, static_cast<uint32_t>(writes.size()), writes.data(), 0, nullptr);
    }
    // ---- vertex buffers (one binding per attribute, vec4 of 32-bit per vertex)
    static const VkFormat kVfmt[3] = {VK_FORMAT_R32G32B32A32_SFLOAT, VK_FORMAT_R32G32B32A32_SINT, VK_FORMAT_R32G32B32A32_UINT};
    std::vector<VkVertexInputBindingDescription> vbind;
    std::vector<VkVertexInputAttributeDescription> vattr;
    std::vector<VkBuffer> vbufs;
    std::vector<VkDeviceSize> voffs;
    for (size_t i = 0; i < job.attrs.size(); ++i) {
        const auto& a = job.attrs[i];
        vbind.push_back({static_cast<uint32_t>(i), 16, VK_VERTEX_INPUT_RATE_VERTEX});
        vattr.push_back({a.location, static_cast<uint32_t>(i), kVfmt[a.type], 0});
        VkBuffer vb;
        void* m;
        if (!make_buf(a.data.size(), VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, a.data.data(), vb, m)) return false;
        vbufs.push_back(vb);
        voffs.push_back(0);
    }
    // ---- pipeline
    std::vector<VkPipelineShaderStageCreateInfo> stages;
    auto add_stage = [&](const std::vector<uint32_t>& code, VkShaderStageFlagBits st) -> bool {
        if (code.empty()) return true;
        VkShaderModuleCreateInfo smi{};
        smi.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
        smi.codeSize = code.size() * 4;
        smi.pCode = code.data();
        VkShaderModule sm;
        if (VkResult r = I.vkCreateShaderModule(I.dev, &smi, nullptr, &sm); r != VK_SUCCESS) return I.fail("vkCreateShaderModule", r);
        R.modules.push_back(sm);
        VkPipelineShaderStageCreateInfo s{};
        s.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        s.stage = st;
        s.module = sm;
        s.pName = "main";
        stages.push_back(s);
        return true;
    };
    if (!add_stage(job.vs, VK_SHADER_STAGE_VERTEX_BIT) || !add_stage(job.tcs, VK_SHADER_STAGE_TESSELLATION_CONTROL_BIT) ||
        !add_stage(job.tes, VK_SHADER_STAGE_TESSELLATION_EVALUATION_BIT) || !add_stage(job.gs, VK_SHADER_STAGE_GEOMETRY_BIT) ||
        !add_stage(job.fs, VK_SHADER_STAGE_FRAGMENT_BIT))
        return false;
    VkPipelineVertexInputStateCreateInfo vis{};
    vis.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
    vis.vertexBindingDescriptionCount = static_cast<uint32_t>(vbind.size());
    vis.pVertexBindingDescriptions = vbind.data();
    vis.vertexAttributeDescriptionCount = static_cast<uint32_t>(vattr.size());
    vis.pVertexAttributeDescriptions = vattr.data();
    VkPipelineInputAssemblyStateCreateInfo ias{};
    ias.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    static const VkPrimitiveTopology kTopo[6] = {VK_PRIMITIVE_TOPOLOGY_POINT_LIST, VK_PRIMITIVE_TOPOLOGY_LINE_LIST,
                                                VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST, VK_PRIMITIVE_TOPOLOGY_PATCH_LIST,
                                                VK_PRIMITIVE_TOPOLOGY_LINE_LIST_WITH_ADJACENCY,
                                                VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST_WITH_ADJACENCY};
    ias.topology = kTopo[static_cast<int>(job.topology)];
    VkPipelineTessellationStateCreateInfo tss{};
    tss.sType = VK_STRUCTURE_TYPE_PIPELINE_TESSELLATION_STATE_CREATE_INFO;
    tss.patchControlPoints = job.patch_points;
    VkViewport vp{0, 0, static_cast<float>(S), static_cast<float>(S), 0.0f, 1.0f};
    VkRect2D sc{{0, 0}, {S, S}};
    VkPipelineViewportStateCreateInfo vps{};
    vps.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    vps.viewportCount = 1;
    vps.pViewports = &vp;
    vps.scissorCount = 1;
    vps.pScissors = &sc;
    VkPipelineRasterizationStateCreateInfo rs{};
    rs.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    rs.cullMode = VK_CULL_MODE_NONE;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rs.lineWidth = 1.0f;
    VkPipelineMultisampleStateCreateInfo ms{};
    ms.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo dss{};
    dss.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
    dss.depthTestEnable = job.depth;
    dss.depthWriteEnable = job.depth;
    dss.depthCompareOp = VK_COMPARE_OP_ALWAYS;
    std::vector<VkPipelineColorBlendAttachmentState> blend(color_refs.size());
    for (auto& b : blend) {
        b = {};
        b.colorWriteMask = 0xf;
    }
    VkPipelineColorBlendStateCreateInfo cbs{};
    cbs.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    cbs.attachmentCount = static_cast<uint32_t>(blend.size());
    cbs.pAttachments = blend.data();
    VkGraphicsPipelineCreateInfo gpi{};
    gpi.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    gpi.stageCount = static_cast<uint32_t>(stages.size());
    gpi.pStages = stages.data();
    gpi.pVertexInputState = &vis;
    gpi.pInputAssemblyState = &ias;
    gpi.pTessellationState = job.tcs.empty() ? nullptr : &tss;
    gpi.pViewportState = &vps;
    gpi.pRasterizationState = &rs;
    gpi.pMultisampleState = &ms;
    gpi.pDepthStencilState = &dss;
    gpi.pColorBlendState = &cbs;
    gpi.layout = R.pl;
    gpi.renderPass = R.rp;
    if (VkResult r = I.vkCreateGraphicsPipelines(I.dev, VK_NULL_HANDLE, 1, &gpi, nullptr, &R.pipe); r != VK_SUCCESS)
        return I.fail("vkCreateGraphicsPipelines", r);
    // ---- readback buffers
    std::vector<VkBuffer> rb;
    std::vector<void*> rbm;
    for (size_t i = 0; i < target_images.size() + (job.depth ? 1 : 0); ++i) {
        VkBuffer b;
        void* m;
        if (!make_buf(static_cast<VkDeviceSize>(S) * S * 16, VK_BUFFER_USAGE_TRANSFER_DST_BIT, nullptr, b, m)) return false;
        rb.push_back(b);
        rbm.push_back(m);
    }
    // ---- record
    VkCommandBufferAllocateInfo cbi{};
    cbi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    cbi.commandPool = I.pool;
    cbi.commandBufferCount = 1;
    if (VkResult r = I.vkAllocateCommandBuffers(I.dev, &cbi, &R.cb); r != VK_SUCCESS) return I.fail("vkAllocateCommandBuffers", r);
    VkCommandBufferBeginInfo bbi{};
    bbi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    I.vkBeginCommandBuffer(R.cb, &bbi);
    std::vector<VkClearValue> clears(atts.size());
    for (auto& c : clears) std::memset(&c, 0, sizeof c);
    if (job.depth) clears[depth_ref.attachment].depthStencil = {1.0f, 0};
    VkRenderPassBeginInfo rbi{};
    rbi.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    rbi.renderPass = R.rp;
    rbi.framebuffer = R.fb;
    rbi.renderArea = sc;
    rbi.clearValueCount = static_cast<uint32_t>(clears.size());
    rbi.pClearValues = clears.data();
    I.vkCmdBeginRenderPass(R.cb, &rbi, VK_SUBPASS_CONTENTS_INLINE);
    I.vkCmdBindPipeline(R.cb, VK_PIPELINE_BIND_POINT_GRAPHICS, R.pipe);
    if (ds) I.vkCmdBindDescriptorSets(R.cb, VK_PIPELINE_BIND_POINT_GRAPHICS, R.pl, 0, 1, &ds, 0, nullptr);
    if (!vbufs.empty()) I.vkCmdBindVertexBuffers(R.cb, 0, static_cast<uint32_t>(vbufs.size()), vbufs.data(), voffs.data());
    I.vkCmdDraw(R.cb, job.vertex_count, job.instance_count, 0, job.first_instance);
    I.vkCmdEndRenderPass(R.cb);
    for (size_t i = 0; i < target_images.size(); ++i) {
        VkBufferImageCopy c{};
        c.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
        c.imageExtent = {S, S, 1};
        I.vkCmdCopyImageToBuffer(R.cb, target_images[i], VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, rb[i], 1, &c);
    }
    if (job.depth) {
        VkBufferImageCopy c{};
        c.imageSubresource = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 0, 1};
        c.imageExtent = {S, S, 1};
        I.vkCmdCopyImageToBuffer(R.cb, depth_image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, rb.back(), 1, &c);
    }
    VkMemoryBarrier mb{};
    mb.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
    mb.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_TRANSFER_WRITE_BIT;
    mb.dstAccessMask = VK_ACCESS_HOST_READ_BIT;
    I.vkCmdPipelineBarrier(R.cb, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_HOST_BIT, 0, 1, &mb, 0, nullptr, 0, nullptr);
    I.vkEndCommandBuffer(R.cb);
    VkSubmitInfo si{};
    si.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    si.commandBufferCount = 1;
    si.pCommandBuffers = &R.cb;
    if (VkResult r = I.vkQueueSubmit(I.queue, 1, &si, VK_NULL_HANDLE); r != VK_SUCCESS) return I.fail("vkQueueSubmit", r);
    if (VkResult r = I.vkQueueWaitIdle(I.queue); r != VK_SUCCESS) return I.fail("vkQueueWaitIdle", r);
    out.targets.clear();
    for (size_t i = 0; i < target_images.size(); ++i) {
        const auto* p = static_cast<const uint8_t*>(rbm[i]);
        out.targets.emplace_back(p, p + static_cast<size_t>(S) * S * 16);
    }
    out.depth.clear();
    if (job.depth) {
        const auto* p = static_cast<const uint8_t*>(rbm.back());
        out.depth.assign(p, p + static_cast<size_t>(S) * S * 4);
    }
    for (size_t i = 0; i < nbufs; ++i)
        if (!job.buffers[i].data.empty()) std::memcpy(job.buffers[i].data.data(), maps[i], job.buffers[i].data.size());
    if (!job.textures.empty() && !texset.readback(job.textures)) { I.error = texset.error(); return false; }
    return true;
}

} // namespace lg_test::vk
