#pragma once
// P4.2 T3-G (P4_2_DISENO.md §4.1): differential run of one graphics pipeline.
//   A: every stage GLSL -> uam -> Maxwell (.dksh) -> lg::shader::translate -> SPIR-V
//   B: every stage GLSL -> glslang -> SPIR-V
//   mixed: one stage from A, the others from B (localizes a failure)
// Same vertex data, same buffers; render targets, depth and storage buffers must match.
//
// The vertex shader carries the setup in comments:
//   // draw: triangles|points|lines|patches|lines_adj|triangles_adj <vertices> <instances> [first_instance]
//   // attr: <location> <f|i|u> <pos|posw|pts|rand>  vertex attribute (vec4 per vertex)
//   // rt: <location> <f|i|u>                        render target (RGBA32)
//   // varying: <location> <f|i|u>                   generic varying type (default f)
//   // depth                                         depth attachment (D32, test always)
//   // buffer: <binding> <z|w|u|f> <words>           storage buffer (z: zeros exact, w: zeros float)
//   // ubo: <binding> <f|u> <words>                  uniform buffer (binding < 14)
//   // tess: <tri|quad|iso> <equal|even|odd> <ccw|cw> [point]
//   // patch: <vertices>                             patch control points
//   // gsin: <points|lines|lines_adj|triangles|triangles_adj>
//   // tol: <ulp>                                    float tolerance (default 4)
//   // tex: / img:  (any stage; tex_spec.h)           P4.3 textures and storage images
//   // needs: <geometry|tessellation|draw_parameters>  device feature (GS/TCS/TES stages imply theirs);
//   //     without it the case is skipped (reported), not failed
//   // atol: <abs>                                   absolute float tolerance (default 0)
//   // cb1: <vert|tesc|tese|geom|frag> <byte> <float> sets a word of uam's constbuf1 (path A). uam
//   //     leaves GL state variables (e.g. STATE_FB_WPOS_Y_TRANSFORM, the dFdy sign) at 0: the GL
//   //     driver fills them; here the case does (1.0 = upper-left origin, like Vulkan).
#include "dksh.h"
#include "t3_runner.h"
#include "tex_spec.h"
#include "vk_graphics.h"
#include "../../shader/translate.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace lg_test::t3g {

enum StageKind { kVert = 0, kTesc, kTese, kGeom, kFrag, kStages };
inline const char* stage_ext(int s) {
    static const char* e[] = {"vert", "tesc", "tese", "geom", "frag"};
    return e[s];
}

struct StageSrc {
    bool present{false};
    std::string glsl;
    std::vector<uint8_t> dksh;
    std::vector<uint32_t> spirv;   // glslang
};

struct Spec {
    vk::GraphicsJob::Topology topo{vk::GraphicsJob::Topology::Triangles};
    uint32_t vertices{3}, instances{1}, first_instance{0};
    struct Attr { uint32_t loc; int type; std::string kind; };
    std::vector<Attr> attrs;
    std::vector<vk::GraphicsJob::Target> targets;
    lg::shader::GraphicsState gfx;
    bool depth{false};
    std::vector<t3::BufSpec> bufs;
    uint32_t patch{3};
    uint32_t tol{4};
    float atol{0.0f};
    struct Cb1 { int stage; uint32_t offset; float value; };
    std::vector<Cb1> cb1;
    bool need_geometry{false}, need_tessellation{false}, need_draw_parameters{false};
};

inline int type_of(char c) { return c == 'i' ? 1 : c == 'u' ? 2 : 0; }
inline lg::shader::AttribType at_of(int t) {
    return t == 1 ? lg::shader::AttribType::Sint : t == 2 ? lg::shader::AttribType::Uint : lg::shader::AttribType::Float;
}

inline Spec parse_spec(const std::string& glsl) {
    Spec s;
    std::istringstream in(glsl);
    std::string line;
    while (std::getline(in, line)) {
        if (line.rfind("// ", 0) != 0) continue;
        char w1[32] = {}, w2[32] = {}, w3[32] = {}, w4[32] = {};
        unsigned a, b, c;
        char k;
        float fv;
        if (std::sscanf(line.c_str(), "// draw: %31s %u %u %u", w1, &a, &b, &c) >= 3) {
            const std::string t = w1;
            using T = vk::GraphicsJob::Topology;
            s.topo = t == "points" ? T::Points : t == "lines" ? T::Lines : t == "patches" ? T::Patches
                   : t == "lines_adj" ? T::LinesAdjacency : t == "triangles_adj" ? T::TrianglesAdjacency : T::Triangles;
            s.vertices = a;
            s.instances = b;
            if (std::sscanf(line.c_str(), "// draw: %31s %u %u %u", w1, &a, &b, &c) == 4) s.first_instance = c;
        } else if (std::sscanf(line.c_str(), "// attr: %u %c %31s", &a, &k, w1) == 3) {
            s.attrs.push_back({a, type_of(k), w1});
            s.gfx.vertex_attrib_types[a] = at_of(type_of(k));
        } else if (std::sscanf(line.c_str(), "// rt: %u %c", &a, &k) == 2) {
            s.targets.push_back({a, type_of(k)});
            s.gfx.render_target_types[a] = at_of(type_of(k));
        } else if (std::sscanf(line.c_str(), "// varying: %u %c", &a, &k) == 2) {
            s.gfx.varying_types[a] = at_of(type_of(k));
        } else if (line == "// depth") {
            s.depth = true;
        } else if (std::sscanf(line.c_str(), "// buffer: %u %c %u", &a, &k, &b) == 3) {
            s.bufs.push_back({a, false, k, b});
        } else if (std::sscanf(line.c_str(), "// ubo: %u %c %u", &a, &k, &b) == 3) {
            s.bufs.push_back({a, true, k, b});
        } else if (std::sscanf(line.c_str(), "// tess: %31s %31s %31s %31s", w1, w2, w3, w4) >= 3) {
            using G = lg::shader::GraphicsState;
            const std::string d = w1, sp = w2, o = w3;
            s.gfx.tess_domain = d == "quad" ? G::TessDomain::Quads : d == "iso" ? G::TessDomain::Isolines : G::TessDomain::Triangles;
            s.gfx.tess_spacing = sp == "even" ? G::TessSpacing::FractionalEven : sp == "odd" ? G::TessSpacing::FractionalOdd : G::TessSpacing::Equal;
            s.gfx.tess_ccw = o != "cw";
            s.gfx.tess_point_mode = std::string(w4) == "point";
        } else if (std::sscanf(line.c_str(), "// patch: %u", &a) == 1) {
            s.patch = a;
            s.gfx.patch_input_vertices = a;
        } else if (std::sscanf(line.c_str(), "// gsin: %31s", w1) == 1) {
            using G = lg::shader::GraphicsState;
            const std::string t = w1;
            s.gfx.gs_input = t == "points" ? G::GsInput::Points : t == "lines" ? G::GsInput::Lines
                           : t == "lines_adj" ? G::GsInput::LinesAdjacency : t == "triangles_adj" ? G::GsInput::TrianglesAdjacency
                                                                          : G::GsInput::Triangles;
        } else if (std::sscanf(line.c_str(), "// tol: %u", &a) == 1) {
            s.tol = a;
        } else if (std::sscanf(line.c_str(), "// needs: %31s", w1) == 1) {
            const std::string n = w1;
            if (n == "geometry") s.need_geometry = true;
            else if (n == "tessellation") s.need_tessellation = true;
            else if (n == "draw_parameters") s.need_draw_parameters = true;
        } else if (std::sscanf(line.c_str(), "// atol: %f", &fv) == 1) {
            s.atol = fv;
        } else if (std::sscanf(line.c_str(), "// cb1: %31s %u %f", w1, &a, &fv) == 3) {
            for (int st = 0; st < kStages; ++st)
                if (std::string(w1) == stage_ext(st)) s.cb1.push_back({st, a, fv});
        }
    }
    return s;
}

inline std::vector<uint8_t> attr_data(const Spec::Attr& a, uint32_t n) {
    std::vector<uint8_t> d(static_cast<size_t>(n) * 16, 0);
    uint32_t x = 0x2545F491u ^ (a.loc * 0x9E3779B9u);
    auto rnd = [&]() { x ^= x << 13; x ^= x >> 17; x ^= x << 5; return x; };
    auto rf = [&](float lo, float hi) { return lo + (hi - lo) * static_cast<float>(rnd() % 100001) / 100000.f; };
    for (uint32_t v = 0; v < n; ++v) {
        float f[4] = {0, 0, 0, 1};
        uint32_t u[4] = {0, 0, 0, 0};
        if (a.kind == "pos" || a.kind == "posw") {
            f[0] = rf(-0.95f, 0.95f); f[1] = rf(-0.95f, 0.95f); f[2] = rf(0.05f, 0.95f);
            if (a.kind == "posw") { f[3] = rf(0.5f, 2.0f); for (int i = 0; i < 3; ++i) f[i] *= f[3]; }
        } else if (a.kind == "pts") {   // one point per pixel centre, row by row
            const uint32_t px = v % 64, py = v / 64;
            f[0] = (2.0f * (static_cast<float>(px) + 0.5f) / 64.0f) - 1.0f;
            f[1] = (2.0f * (static_cast<float>(py) + 0.5f) / 64.0f) - 1.0f;
            f[2] = 0.5f;
        } else {
            for (int i = 0; i < 4; ++i) f[i] = rf(-2.0f, 2.0f);
            for (int i = 0; i < 4; ++i) u[i] = rnd() % 2001 - 1000;
        }
        if (a.type == 0) std::memcpy(&d[v * 16], f, 16);
        else std::memcpy(&d[v * 16], u, 16);
    }
    return d;
}

constexpr uint32_t kResbase[kStages] = {0x010, 0x1b0, 0x350, 0x4f0, 0x690};
constexpr uint32_t kCbufBase = 32, kCbufPerStage = 20;
constexpr uint64_t kIova = 0x1'4000'0000ull;

struct Outcome {
    bool ok{false};
    bool skipped{false};   // the device lacks a feature the case needs (ok stays true)
    std::string message;
    std::vector<std::string> warnings;
};

inline lg::shader::Stage stage_enum(int s) {
    using lg::shader::Stage;
    static const Stage m[] = {Stage::Vertex, Stage::TessControl, Stage::TessEval, Stage::Geometry, Stage::Fragment};
    return m[s];
}

/** Builds the job for a mix: translated[s] picks path A for stage s, else path B. */
inline bool build_job(const StageSrc (&st)[kStages], const Spec& spec, const bool (&translated)[kStages],
                      vk::GraphicsJob& job, std::string& error, std::vector<std::string>& warnings) {
    job = vk::GraphicsJob{};
    job.topology = spec.topo;
    job.patch_points = spec.patch;
    job.vertex_count = spec.vertices;
    job.instance_count = spec.instances;
    job.first_instance = spec.first_instance;
    for (const auto& a : spec.attrs) job.attrs.push_back({a.loc, a.type, attr_data(a, spec.vertices)});
    job.targets = spec.targets;
    job.depth = spec.depth;
    std::vector<uint8_t> drv(0x10000, 0);
    std::vector<vk::Buffer> ssbos, ubos;
    for (const auto& b : spec.bufs) {
        vk::Buffer vb{b.binding, b.uniform, t3::make_data(b)};
        (b.uniform ? ubos : ssbos).push_back(vb);
    }
    job.buffers = ssbos;   // SSBOs keep their GLSL binding in both paths
    for (const auto& u : ubos) job.buffers.push_back({u.binding, true, u.data});   // path B layout (glslang)
    // P4.3: textures and storage images, from the comments of every stage (path B: GLSL bindings)
    std::vector<tex::TexSpec> texspecs;
    for (int s = 0; s < kStages; ++s)
        if (st[s].present)
            for (const auto& t : tex::parse(st[s].glsl)) {
                bool dup = false;
                for (const auto& o : texspecs) dup = dup || (o.binding == t.binding && o.storage == t.storage);
                if (!dup) texspecs.push_back(t);
            }
    bool any_translated = false;
    for (int s = 0; s < kStages; ++s) {
        if (st[s].present && !translated[s]) {
            for (const auto& t : texspecs) {
                bool have = false;
                for (const auto& v : job.textures) have = have || (v.binding == t.binding && v.share < 0 && v.storage == t.storage);
                if (!have) job.textures.push_back(tex::make(t, t.binding));
            }
        }
    }
    for (int s = 0; s < kStages; ++s) {
        if (!st[s].present) continue;
        std::vector<uint32_t>* dst = s == kVert ? &job.vs : s == kTesc ? &job.tcs : s == kTese ? &job.tes : s == kGeom ? &job.gs : &job.fs;
        if (!translated[s]) { *dst = st[s].spirv; continue; }
        any_translated = true;
        dksh::Graphics g;
        if (!dksh::parse_graphics(st[s].dksh, g, error)) return false;
        lg::shader::ShaderInfo info;
        info.stage = stage_enum(s);
        std::copy(std::begin(g.sph), std::end(g.sph), info.sph.begin());
        info.graphics = spec.gfx;
        lg::shader::Sph sph;
        lg::shader::parse_sph(info.sph, sph);
        info.local_memory_bytes = sph.local_mem_bytes;
        for (uint32_t bank = 0; bank < 18; ++bank) info.cbufs.push_back({bank, kCbufBase + kCbufPerStage * s + bank});
        info.global_tables = {lg::shader::GlobalBufferTable{0, kResbase[s] + 0xa0, 16, 16, 8, 0x10000, 0}};
        for (const auto& t : texspecs) {
            if (t.storage) info.images.push_back({0, kResbase[s] + 0x80 + 4 * t.binding, tex::image_format(t.fmt), tex::attrib_type(t.fmt)});
            else info.textures.push_back({0, kResbase[s] + 4 * t.binding, tex::attrib_type(t.fmt)});
        }
        info.texture_first_binding = 160 + 16 * static_cast<uint32_t>(s);
        const auto tr = lg::shader::translate(g.code, info);
        for (const auto& w : tr.warnings) warnings.push_back(std::string(stage_ext(s)) + ": " + w);
        if (!tr.ok) { error = std::string("traducción ") + stage_ext(s) + ": " + tr.error; return false; }
        *dst = tr.spirv;
        {   // this stage's textures, at the bindings it was given (shared images stay within the stage)
            std::vector<vk::Texture> mine;
            std::vector<int> primary;
            if (!tex::for_translation(texspecs, tr, kResbase[s], mine, primary, error)) return false;
            const int base = static_cast<int>(job.textures.size());
            for (auto& v : mine) {
                if (v.share >= 0) v.share += base;
                job.textures.push_back(std::move(v));
            }
        }
        // this stage's constant buffers: c0 (driver), c1 (compiler), c2+N (UBO N)
        std::vector<uint8_t> cb1(0x10000, 0);
        if (!g.constbuf1.empty()) std::memcpy(cb1.data(), g.constbuf1.data(), std::min(cb1.size(), g.constbuf1.size()));
        for (const auto& c : spec.cb1)
            if (c.stage == s && c.offset + 4 <= cb1.size()) std::memcpy(&cb1[c.offset], &c.value, 4);
        for (const auto& r : tr.resources) {
            if (r.kind != lg::shader::ResourceUse::Kind::ConstantBuffer) continue;
            std::vector<uint8_t> d(0x10000, 0);
            if (r.index == 0) d = drv;
            else if (r.index == 1) d = cb1;
            else
                for (const auto& u : ubos)
                    if (u.binding + 2 == r.index) std::memcpy(d.data(), u.data.data(), std::min(d.size(), u.data.size()));
            job.buffers.push_back({r.binding, true, d});
            if (r.index == 0) job.buffers.back().data.clear();   // filled below, once the table is known
        }
    }
    if (any_translated) {
        // the driver constant buffer: every stage's SSBO table (resbase + 0xa0)
        for (const auto& b : ssbos)
            for (int s = 0; s < kStages; ++s) {
                const uint64_t iova = kIova + (uint64_t{b.binding} << 24);
                const uint32_t at = kResbase[s] + 0xa0 + 16 * b.binding;
                const uint32_t lo = static_cast<uint32_t>(iova), hi = static_cast<uint32_t>(iova >> 32);
                const uint32_t sz = static_cast<uint32_t>(b.data.size());
                std::memcpy(&drv[at], &lo, 4);
                std::memcpy(&drv[at + 4], &hi, 4);
                std::memcpy(&drv[at + 8], &sz, 4);
            }
        for (auto& b : job.buffers)
            if (b.uniform && b.data.empty()) b.data = drv;
    }
    (void)warnings;
    return true;
}

inline bool float_close(uint32_t x, uint32_t y, const Spec& spec) {
    if (t3::ulp_diff(x, y) <= spec.tol) return true;
    float fx, fy;
    std::memcpy(&fx, &x, 4);
    std::memcpy(&fy, &y, 4);
    return spec.atol > 0.0f && std::fabs(fx - fy) <= spec.atol;
}

inline bool compare(const vk::GraphicsResult& a, const vk::GraphicsResult& b, const std::vector<vk::Buffer>& ba,
                    const std::vector<vk::Buffer>& bb, const Spec& spec, const char* na, const char* nb, std::string& msg) {
    for (size_t t = 0; t < spec.targets.size(); ++t) {
        for (uint32_t i = 0; i < 64 * 64 * 4; ++i) {
            uint32_t x, y;
            std::memcpy(&x, &a.targets[t][i * 4], 4);
            std::memcpy(&y, &b.targets[t][i * 4], 4);
            if (x == y) continue;
            if (spec.targets[t].type == 0 && float_close(x, y, spec)) continue;
            char buf[200];
            std::snprintf(buf, sizeof buf, "rt%u pixel (%u,%u).%c: %s 0x%08x, %s 0x%08x", spec.targets[t].location, (i / 4) % 64,
                          (i / 4) / 64, "xyzw"[i % 4], na, x, nb, y);
            msg = buf;
            return false;
        }
    }
    for (uint32_t i = 0; i < a.depth.size() / 4; ++i) {
        uint32_t x, y;
        std::memcpy(&x, &a.depth[i * 4], 4);
        std::memcpy(&y, &b.depth[i * 4], 4);
        if (x != y && !float_close(x, y, spec)) {
            char buf[160];
            std::snprintf(buf, sizeof buf, "profundidad (%u,%u): %s 0x%08x, %s 0x%08x", i % 64, i / 64, na, x, nb, y);
            msg = buf;
            return false;
        }
    }
    for (const auto& bs : spec.bufs) {
        if (bs.uniform) continue;
        const vk::Buffer* A = nullptr;
        const vk::Buffer* B = nullptr;
        for (const auto& x : ba) if (!x.uniform && x.binding == bs.binding) A = &x;
        for (const auto& x : bb) if (!x.uniform && x.binding == bs.binding) B = &x;
        if (!A || !B) { msg = "buffer ausente"; return false; }
        for (uint32_t i = 0; i < bs.words; ++i) {
            uint32_t x, y;
            std::memcpy(&x, &A->data[i * 4], 4);
            std::memcpy(&y, &B->data[i * 4], 4);
            if (x == y) continue;
            if ((bs.kind == 'f' || bs.kind == 'w') && float_close(x, y, spec)) continue;
            char buf[160];
            std::snprintf(buf, sizeof buf, "buffer %u[%u]: %s 0x%08x, %s 0x%08x", bs.binding, i, na, x, nb, y);
            msg = buf;
            return false;
        }
    }
    return true;
}

/** Runs B, A and every single-stage mix; ok when all equal B. */
inline Outcome run(vk::GraphicsRunner& runner, const StageSrc (&st)[kStages]) {
    Outcome o;
    const Spec spec = parse_spec(st[kVert].glsl);
    const bool geo = spec.need_geometry || st[kGeom].present;
    const bool tess = spec.need_tessellation || st[kTesc].present || st[kTese].present;
    if ((geo && !runner.has_geometry()) || (tess && !runner.has_tessellation()) ||
        (spec.need_draw_parameters && !runner.has_draw_parameters())) {
        o.ok = true;
        o.skipped = true;
        o.message = "omitido: el dispositivo no tiene " + std::string(geo && !runner.has_geometry() ? "geometryShader"
                                                                      : tess && !runner.has_tessellation() ? "tessellationShader"
                                                                                                             : "shaderDrawParameters");
        return o;
    }
    bool none[kStages] = {};
    vk::GraphicsJob jb;
    if (!build_job(st, spec, none, jb, o.message, o.warnings)) return o;
    vk::GraphicsResult rb;
    if (!runner.run(jb, rb)) { o.message = "ejecución B: " + runner.error(); return o; }
    // A: every stage translated, then each stage alone
    std::vector<std::pair<std::string, std::vector<int>>> mixes;
    std::vector<int> all;
    for (int s = 0; s < kStages; ++s) if (st[s].present) all.push_back(s);
    mixes.push_back({"A", all});
    if (all.size() > 1)
        for (int s : all) mixes.push_back({std::string("solo ") + stage_ext(s), {s}});
    for (const auto& [label, list] : mixes) {
        bool tr[kStages] = {};
        for (int s : list) tr[s] = true;
        vk::GraphicsJob ja;
        std::vector<std::string> w;
        if (!build_job(st, spec, tr, ja, o.message, label == "A" ? o.warnings : w)) { o.message = label + ": " + o.message; return o; }
        vk::GraphicsResult ra;
        if (!runner.run(ja, ra)) { o.message = label + ": ejecución: " + runner.error(); return o; }
        std::string msg;
        if (!compare(ra, rb, ja.buffers, jb.buffers, spec, "recompilado", "glslang", msg)) { o.message = label + ": " + msg; return o; }
    }
    o.ok = true;
    return o;
}

} // namespace lg_test::t3g
