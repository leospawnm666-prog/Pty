#pragma once
// P4.1 test oracle (P4_DISENO.md §5.4): runs a SPIR-V compute shader on a real Vulkan
// implementation (SwiftShader in CI) through a dlopen'd loader. Test-only code.
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace lg_test::vk {

struct Buffer {
    uint32_t binding{0};
    bool uniform{false};          // uniform buffer (else storage buffer)
    std::vector<uint8_t> data;    // in: initial contents; out: contents after the dispatch
};

/** P4.3: a texture (combined image sampler) or storage image of a test. */
struct Texture {
    uint32_t binding{0};
    bool storage{false};                  // storage image (else combined image sampler)
    uint32_t view_type{1};                // VkImageViewType (1 = 2D)
    uint32_t format{109};                 // VkFormat of the image (109 = R32G32B32A32_SFLOAT)
    uint32_t view_format{0};              // VkFormat of the view if different (raw storage views)
    uint32_t width{1}, height{1}, depth{1}, layers{1}, levels{1}, samples{1};
    std::vector<uint8_t> data;            // every level, its layers, tightly packed; storage: contents after the run
    bool linear{false}, mip_linear{false};
    uint32_t address{2};                  // VkSamplerAddressMode (2 = clamp to edge)
    bool compare{false};
    uint32_t compare_op{1};               // VkCompareOp (1 = less)
    float max_lod{16.0f};
    int32_t share{-1};                    // >= 0: a view of that (earlier) texture's image, not a new image
    // P4.4: texel buffers (data = the buffer; storage: read back), descriptor arrays (general
    // bindless: separate sampled images and samplers at an element of their binding's array)
    bool texel_buffer{false};
    enum class Kind : uint8_t { Combined, SampledImage, SamplerOnly } kind{Kind::Combined};
    uint32_t array_element{0};
    uint32_t array_size{1};               // the binding's descriptor count (the same for its elements)
};

/** Bytes per texel of the VkFormats the texture tests use. */
inline uint32_t texel_bytes(uint32_t f) {
    switch (f) {
        case 107: case 108: case 109: return 16;   // R32G32B32A32 UINT/SINT/SFLOAT
        case 101: case 102: case 103: case 95: case 97: return 8;   // R32G32 UINT/SINT/SFLOAT, RGBA16 UINT/SFLOAT
        case 13: case 9: return 1;                 // R8_UINT, R8_UNORM
        case 74: case 76: return 2;                // R16_UINT, R16_SFLOAT
        default: return 4;                          // RGBA8, R32, D32
    }
}

class ComputeRunner {
public:
    /** `loader`: path of libvulkan.so (the ICD is chosen by VK_ICD_FILENAMES). */
    explicit ComputeRunner(const std::string& loader);
    ~ComputeRunner();
    ComputeRunner(const ComputeRunner&) = delete;
    ComputeRunner& operator=(const ComputeRunner&) = delete;

    bool ok() const noexcept;
    const std::string& error() const noexcept;
    std::string device_name() const;
    /** P4.4: shaderFloat64 is enabled (the device has it). */
    bool float64() const noexcept;
    /** P4.4: non-uniform indexing of sampled and storage image arrays is enabled. */
    bool descriptor_indexing() const noexcept;
    /** P4.4: 64-bit atomics on storage buffers and shared memory are enabled. */
    bool int64_atomics() const noexcept;
    /** Builds a pipeline from `spirv`, binds `buffers` (set 0) and dispatches `groups`.
     *  Returns false (and error()) on any Vulkan failure. */
    bool run(const std::vector<uint32_t>& spirv, std::vector<Buffer>& buffers, const uint32_t groups[3]);
    /** P4.3: the same with textures and storage images (storage images are read back). */
    bool run(const std::vector<uint32_t>& spirv, std::vector<Buffer>& buffers, const uint32_t groups[3],
             std::vector<Texture>& textures);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace lg_test::vk
