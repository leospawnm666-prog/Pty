#pragma once
// P4.1 tests: a scalar reference interpreter of the Maxwell instructions of P4.1 (test-only).
//
// It is the C++ reference model of P4_DISENO.md §5.2 (T2): written from the same public
// documentation as the recompiler (envytools, nouveau) but as an independent scalar
// implementation. It is itself validated by running the whole T3 corpus (real uam output) and
// comparing with glslang; then T2 uses it as the oracle for edge cases instruction by instruction.
#include <cstdint>
#include <functional>
#include <span>
#include <string>
#include <vector>

#include "../../shader/translate.h"

namespace lg_test::mref {

/** Memory seen by a dispatch: constant buffers (64 KiB banks) and the global buffers. */
struct Memory {
    std::vector<std::vector<uint8_t>> cbufs;            // index = bank
    struct Global { uint64_t base; std::vector<uint8_t>* data; };
    std::vector<Global> globals;                         // by address range
    uint32_t cbuf32(unsigned bank, uint32_t off) const;
    uint32_t* global_word(uint64_t addr);                // nullptr: unmapped
};

struct Dispatch {
    uint32_t local_size[3]{1, 1, 1};
    uint32_t groups[3]{1, 1, 1};
    uint32_t shared_bytes{0};
    uint32_t local_bytes{0};
    /** Flush denormal float inputs and results to zero (the oracle, SwiftShader, does). */
    bool flush_denormals{false};
    /** FFMA as a multiply then an add (SwiftShader's Fma is not fused; the hardware's is). */
    bool unfused_fma{false};
};

/** Runs `code` (from its first scheduling word) for a whole dispatch. Returns "" or an error. */
std::string run(std::span<const uint64_t> code, const Dispatch& d, Memory& mem, uint64_t max_steps = 50'000'000);

} // namespace lg_test::mref
