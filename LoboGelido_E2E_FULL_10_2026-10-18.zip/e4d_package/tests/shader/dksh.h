#pragma once
// P4.1 tests: reads the compute program of a deko3d .dksh module produced by uam (format from
// uam's public dksh.h, re-declared here: control section = header + program headers, then the
// code section with the program code and the compiler constant buffer, "constbuf1").
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace lg_test::dksh {

struct Compute {
    std::vector<uint64_t> code;        // from the program's entry point (first scheduling word)
    std::vector<uint8_t> constbuf1;    // bank 1
    uint32_t block_dims[3]{1, 1, 1};
    uint32_t shared_mem{0};
    uint32_t local_mem{0};             // local_pos_mem_sz + local_neg_mem_sz
    uint32_t num_gprs{0};
};

inline bool parse_compute(const std::vector<uint8_t>& f, Compute& out, std::string& error) {
    auto rd = [&](size_t at) -> uint32_t {
        uint32_t v = 0;
        if (at + 4 <= f.size()) std::memcpy(&v, &f[at], 4);
        return v;
    };
    if (f.size() < 24 || rd(0) != 0x48534B44u) { error = "no es un DKSH"; return false; }
    const uint32_t control_sz = rd(8), code_sz = rd(12), programs_off = rd(16), num_programs = rd(20);
    if (num_programs < 1 || programs_off + 64 > f.size() || control_sz + code_sz > f.size()) {
        error = "DKSH truncado";
        return false;
    }
    const size_t ph = programs_off;
    if (rd(ph + 0) != 5) { error = "el programa no es compute"; return false; }
    const uint32_t entry = rd(ph + 4);
    out.num_gprs = rd(ph + 8);
    const uint32_t cb1_off = rd(ph + 12), cb1_sz = rd(ph + 16);
    // comp: block_dims[3], shared_mem_sz, local_pos_mem_sz, local_neg_mem_sz, crs_sz, num_barriers
    const size_t comp = ph + 24;
    for (int i = 0; i < 3; ++i) out.block_dims[i] = rd(comp + 4 * i);
    out.shared_mem = rd(comp + 12);
    out.local_mem = rd(comp + 16) + rd(comp + 20);
    const uint32_t code_end = cb1_sz ? cb1_off : code_sz;
    if (entry >= code_end || code_end > code_sz) { error = "DKSH: código fuera de rango"; return false; }
    const size_t base = control_sz;
    out.code.resize((code_end - entry) / 8);
    std::memcpy(out.code.data(), &f[base + entry], out.code.size() * 8);
    while (!out.code.empty() && out.code.back() == 0) out.code.pop_back();   // 256-byte padding
    out.constbuf1.assign(f.begin() + static_cast<long>(base + cb1_off), f.begin() + static_cast<long>(base + cb1_off + cb1_sz));
    if (!cb1_sz) out.constbuf1.clear();
    return true;
}

/** A graphics program (VS/TCS/TES/GS/FS): the program header points at the SPH; the code
 *  follows it at +0x50. */
struct Graphics {
    uint32_t type{0};                  // DkshProgramType: 0 VS, 1 FS, 2 GS, 3 TCS, 4 TES
    uint32_t sph[20]{};
    std::vector<uint64_t> code;
    std::vector<uint8_t> constbuf1;
};

inline bool parse_graphics(const std::vector<uint8_t>& f, Graphics& out, std::string& error) {
    auto rd = [&](size_t at) -> uint32_t {
        uint32_t v = 0;
        if (at + 4 <= f.size()) std::memcpy(&v, &f[at], 4);
        return v;
    };
    if (f.size() < 24 || rd(0) != 0x48534B44u) { error = "no es un DKSH"; return false; }
    const uint32_t control_sz = rd(8), code_sz = rd(12), programs_off = rd(16);
    const size_t ph = programs_off;
    out.type = rd(ph + 0);
    if (out.type == 5) { error = "es compute"; return false; }
    const uint32_t entry = rd(ph + 4);
    const uint32_t cb1_off = rd(ph + 12), cb1_sz = rd(ph + 16);
    const uint32_t code_end = cb1_sz ? cb1_off : code_sz;
    if (entry + 0x50 >= code_end || control_sz + code_end > f.size()) { error = "DKSH: código fuera de rango"; return false; }
    for (int i = 0; i < 20; ++i) out.sph[i] = rd(control_sz + entry + 4 * i);
    const size_t code_at = control_sz + entry + 0x50;
    out.code.resize((code_end - entry - 0x50) / 8);
    std::memcpy(out.code.data(), &f[code_at], out.code.size() * 8);
    while (!out.code.empty() && out.code.back() == 0) out.code.pop_back();
    out.constbuf1.clear();
    if (cb1_sz) out.constbuf1.assign(f.begin() + static_cast<long>(control_sz + cb1_off), f.begin() + static_cast<long>(control_sz + cb1_off + cb1_sz));
    return true;
}

} // namespace lg_test::dksh
