#pragma once
// P4.3 T3-T (P4_3_DISENO.md §5.1): textures and storage images of a differential test, from
// comments in the GLSL:
//   // tex: <binding> <view> <fmt> <w> <h> <d> <levels> [linear] [miplinear] [repeat|mirror|clamp] [cmp:<op>]
//   // img: <binding> <view> <fmt> <w> <h> <d>
// view: 1d 2d 3d cube 1da 2da cubea (d = depth for 3D, layers for arrays, 6·n for cubes)
// fmt:  f RGBA32F, u RGBA32UI, i RGBA32I, n RGBA8 (unorm), d D32 (depth), r R32UI, s R32I, g R32F
// The contents are deterministic (a hash of the binding). Path A (translated) binds them at the
// bindings the translator returns: a texture/image resource names its handle's cbuf word, which
// for deko3d is resbase + 4·binding (textures) or resbase + 0x80 + 4·binding (images).
#include "vk_compute.h"
#include "../../shader/translate.h"

#include <cstdio>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace lg_test::tex {

struct TexSpec {
    uint32_t binding{0};
    bool storage{false};
    uint32_t view{1};            // VkImageViewType
    char fmt{'f'};
    uint32_t w{1}, h{1}, d{1}, levels{1};
    bool linear{false}, miplinear{false};
    uint32_t address{2};
    bool compare{false};
    uint32_t cmp{1};
};

inline uint32_t vk_format(char f) {
    switch (f) {
        case 'u': return 107;   // R32G32B32A32_UINT
        case 'i': return 108;   // R32G32B32A32_SINT
        case 'n': return 37;    // R8G8B8A8_UNORM
        case 'd': return 126;   // D32_SFLOAT
        case 'r': return 98;    // R32_UINT
        case 's': return 99;    // R32_SINT
        case 'g': return 100;   // R32_SFLOAT
        default: return 109;    // R32G32B32A32_SFLOAT
    }
}

inline lg::shader::AttribType attrib_type(char f) {
    return f == 'u' || f == 'r' ? lg::shader::AttribType::Uint
         : f == 'i' || f == 's' ? lg::shader::AttribType::Sint : lg::shader::AttribType::Float;
}

inline lg::shader::ImageFormat image_format(char f) {
    using I = lg::shader::ImageFormat;
    switch (f) {
        case 'u': return I::Rgba32ui;
        case 'i': return I::Rgba32i;
        case 'n': return I::Rgba8;
        case 'r': return I::R32ui;
        case 's': return I::R32i;
        case 'g': return I::R32f;
        default: return I::Rgba32f;
    }
}

inline std::vector<TexSpec> parse(const std::string& glsl) {
    std::vector<TexSpec> out;
    std::istringstream in(glsl);
    std::string line;
    while (std::getline(in, line)) {
        const bool tex = line.rfind("// tex: ", 0) == 0, img = line.rfind("// img: ", 0) == 0;
        if (!tex && !img) continue;
        std::istringstream ls(line.substr(8));
        TexSpec t;
        std::string view, fmt;
        ls >> t.binding >> view >> fmt >> t.w >> t.h >> t.d;
        if (tex) ls >> t.levels;
        t.storage = img;
        t.fmt = fmt.empty() ? 'f' : fmt[0];
        t.view = view == "1d" ? 0 : view == "3d" ? 2 : view == "cube" ? 3 : view == "1da" ? 4 : view == "2da" ? 5
               : view == "cubea" ? 6 : 1;
        std::string opt;
        while (ls >> opt) {
            if (opt == "linear") t.linear = true;
            else if (opt == "miplinear") t.miplinear = true;
            else if (opt == "repeat") t.address = 0;
            else if (opt == "mirror") t.address = 1;
            else if (opt == "clamp") t.address = 2;
            else if (opt.rfind("cmp:", 0) == 0) { t.compare = true; t.cmp = static_cast<uint32_t>(std::stoul(opt.substr(4))); }
        }
        out.push_back(t);
    }
    return out;
}

/** The test texture (contents included) at `binding`. */
inline vk::Texture make(const TexSpec& t, uint32_t binding) {
    vk::Texture v;
    v.binding = binding;
    v.storage = t.storage;
    v.view_type = t.view;
    v.format = vk_format(t.fmt);
    v.width = t.w;
    const bool layered = t.view == 4 || t.view == 5 || t.view == 6 || t.view == 3;
    v.height = t.view == 0 || t.view == 4 ? 1 : t.h;
    v.depth = t.view == 2 ? t.d : 1;
    v.layers = layered ? t.d : 1;
    if (t.view == 4) v.layers = t.h;   // 1D array: <w> <layers> ...
    v.levels = t.levels;
    v.linear = t.linear;
    v.mip_linear = t.miplinear;
    v.address = t.address;
    v.compare = t.compare;
    v.compare_op = t.cmp;
    uint64_t bytes = 0;
    for (uint32_t l = 0; l < v.levels; ++l)
        bytes += uint64_t{std::max(1u, v.width >> l)} * std::max(1u, v.height >> l) * std::max(1u, v.depth >> l) * v.layers *
                 vk::texel_bytes(v.format);
    v.data.resize(bytes);
    uint32_t x = 0x9E3779B9u ^ (t.binding * 0x85EBCA6Bu) ^ (t.storage ? 0x1234567u : 0u);
    auto rnd = [&]() { x ^= x << 13; x ^= x >> 17; x ^= x << 5; return x; };
    const bool flt = t.fmt == 'f' || t.fmt == 'd' || t.fmt == 'g';
    for (size_t i = 0; i + 4 <= v.data.size(); i += 4) {
        uint32_t w;
        if (flt) {
            const float f = static_cast<float>(rnd() % 100001) / 100000.0f;
            std::memcpy(&w, &f, 4);
        } else if (t.fmt == 'i' || t.fmt == 's') {
            w = static_cast<uint32_t>(static_cast<int32_t>(rnd() % 2001) - 1000);
        } else {
            w = rnd();
        }
        std::memcpy(&v.data[i], &w, 4);
    }
    return v;
}

/** Path A: the textures at the bindings of the translated shader's resources. `resbase`: the
 *  stage's deko3d resource base in c0. Storage images used through several views (raw,
 *  formatted, atomic) are one image. Returns false (and a message) if a resource has no spec. */
inline bool for_translation(const std::vector<TexSpec>& specs, const lg::shader::TranslationResult& tr, uint32_t resbase,
                            std::vector<vk::Texture>& out, std::vector<int>& primary_of_spec, std::string& msg) {
    using R = lg::shader::ResourceUse;
    primary_of_spec.assign(specs.size(), -1);
    for (const R& r : tr.resources) {
        if (r.kind != R::Kind::Texture && r.kind != R::Kind::Image) continue;
        const bool image = r.kind == R::Kind::Image;
        const uint32_t base = resbase + (image ? 0x80 : 0);
        const uint32_t glsl_binding = (r.offset - base) / 4;
        size_t si = specs.size();
        for (size_t k = 0; k < specs.size(); ++k)
            if (specs[k].binding == glsl_binding && specs[k].storage == image) si = k;
        if (si == specs.size()) { msg = "recurso de textura sin especificación: offset " + std::to_string(r.offset); return false; }
        vk::Texture v = make(specs[si], r.binding);
        if (image) {
            if (r.access == R::Access::Raw)
                v.view_format = r.raw_bytes == 1 ? 13 : r.raw_bytes == 2 ? 74 : r.raw_bytes == 8 ? 101 : r.raw_bytes == 16 ? 107 : 98;
            else if (r.access == R::Access::Atomic)
                v.view_format = r.type == lg::shader::AttribType::Sint ? 99 : 98;
        }
        if (primary_of_spec[si] >= 0) {
            v.share = primary_of_spec[si];
            v.data.clear();
        } else {
            primary_of_spec[si] = static_cast<int>(out.size());
        }
        out.push_back(std::move(v));
    }
    return true;
}

} // namespace lg_test::tex
