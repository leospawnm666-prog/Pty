#pragma once
// P4.2 test oracle: draws with a graphics pipeline (VS, optional TCS/TES/GS, FS) into 64x64
// offscreen targets and reads them back. Test-only code (like vk_compute).
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "vk_compute.h"

namespace lg_test::vk {

struct GraphicsJob {
    std::vector<uint32_t> vs, tcs, tes, gs, fs;   // SPIR-V; tcs/tes/gs may be empty
    enum class Topology { Points, Lines, Triangles, Patches, LinesAdjacency, TrianglesAdjacency } topology{Topology::Triangles};
    uint32_t patch_points{3};
    uint32_t vertex_count{3}, instance_count{1}, first_instance{0};
    struct Attr { uint32_t location; int type; std::vector<uint8_t> data; };   // type 0 f, 1 s, 2 u; vec4 per vertex
    std::vector<Attr> attrs;
    struct Target { uint32_t location; int type; };                            // RGBA32 F/SINT/UINT
    std::vector<Target> targets;
    bool depth{false};                                                         // D32_SFLOAT, test ALWAYS, cleared to 1
    std::vector<Buffer> buffers;                                               // descriptors, all stages
    std::vector<Texture> textures;                                             // P4.3: textures / storage images
};

struct GraphicsResult {
    std::vector<std::vector<uint8_t>> targets;   // 64*64*16 bytes each
    std::vector<uint8_t> depth;                  // 64*64*4 bytes
};

class GraphicsRunner {
public:
    explicit GraphicsRunner(const std::string& loader);
    ~GraphicsRunner();
    GraphicsRunner(const GraphicsRunner&) = delete;
    GraphicsRunner& operator=(const GraphicsRunner&) = delete;
    bool ok() const noexcept;
    const std::string& error() const noexcept;
    std::string device_name() const;
    bool has_geometry() const noexcept;
    bool has_tessellation() const noexcept;
    bool has_draw_parameters() const noexcept;
    /** Runs the job; buffers are updated with their contents after the draw. */
    bool run(GraphicsJob& job, GraphicsResult& out);

    static constexpr uint32_t kSize = 64;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace lg_test::vk
