#pragma once
// P4.3 test oracle: textures (combined image samplers) and storage images for the compute and
// graphics runners. Test-only code; included by vk_compute.cpp and vk_graphics.cpp after
// <vulkan/vulkan.h> (VK_NO_PROTOTYPES): it loads its own entry points with vkGetDeviceProcAddr.
#include "vk_compute.h"

#include <algorithm>
#include <cstring>
#include <string>
#include <vector>

namespace lg_test::vk {

class TextureSet {
public:
    TextureSet(PFN_vkGetDeviceProcAddr gdpa, VkDevice dev, VkQueue queue, VkCommandPool pool,
               const VkPhysicalDeviceMemoryProperties& mp)
        : dev_(dev), queue_(queue), pool_(pool), mp_(mp) {
#define LG_TL(name) name = reinterpret_cast<PFN_##name>(gdpa(dev, #name));
        LG_TL(vkCreateImage) LG_TL(vkDestroyImage) LG_TL(vkGetImageMemoryRequirements) LG_TL(vkBindImageMemory)
        LG_TL(vkCreateImageView) LG_TL(vkDestroyImageView) LG_TL(vkCreateSampler) LG_TL(vkDestroySampler)
        LG_TL(vkAllocateMemory) LG_TL(vkFreeMemory) LG_TL(vkMapMemory) LG_TL(vkCreateBuffer) LG_TL(vkDestroyBuffer)
        LG_TL(vkGetBufferMemoryRequirements) LG_TL(vkBindBufferMemory) LG_TL(vkAllocateCommandBuffers)
        LG_TL(vkFreeCommandBuffers) LG_TL(vkBeginCommandBuffer) LG_TL(vkEndCommandBuffer) LG_TL(vkCmdPipelineBarrier)
        LG_TL(vkCmdCopyBufferToImage) LG_TL(vkCmdCopyImageToBuffer) LG_TL(vkQueueSubmit) LG_TL(vkQueueWaitIdle)
        LG_TL(vkCreateBufferView) LG_TL(vkDestroyBufferView)
#undef LG_TL
    }
    ~TextureSet() {
        for (auto bv : bviews_) vkDestroyBufferView(dev_, bv, nullptr);
        for (auto s : samplers_) vkDestroySampler(dev_, s, nullptr);
        for (auto v : views_) vkDestroyImageView(dev_, v, nullptr);
        for (auto i : images_) vkDestroyImage(dev_, i, nullptr);
        for (auto b : bufs_) vkDestroyBuffer(dev_, b, nullptr);
        for (auto m : mems_) vkFreeMemory(dev_, m, nullptr);
    }
    TextureSet(const TextureSet&) = delete;
    TextureSet& operator=(const TextureSet&) = delete;

    const std::string& error() const { return error_; }

    /** Creates and uploads every texture (one submission). */
    bool create(std::vector<Texture>& texs) {
        for (Texture& t : texs) {
            const bool depth = t.format == VK_FORMAT_D32_SFLOAT;
            if (t.kind == Texture::Kind::SamplerOnly) {   // P4.4: a sampler of a sampler array
                VkSampler smp;
                if (!make_sampler(t, smp)) return false;
                entries_.push_back({VK_NULL_HANDLE, VK_NULL_HANDLE, smp, false});
                continue;
            }
            if (t.texel_buffer) {   // P4.4: a uniform or storage texel buffer, host visible
                VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
                bi.size = std::max<uint64_t>(16, static_cast<uint64_t>(t.width) * texel_bytes(t.format));
                bi.usage = t.storage ? VK_BUFFER_USAGE_STORAGE_TEXEL_BUFFER_BIT : VK_BUFFER_USAGE_UNIFORM_TEXEL_BUFFER_BIT;
                VkBuffer b;
                if (VkResult r = vkCreateBuffer(dev_, &bi, nullptr, &b); r != VK_SUCCESS) return fail("vkCreateBuffer", r);
                bufs_.push_back(b);
                VkMemoryRequirements req;
                vkGetBufferMemoryRequirements(dev_, b, &req);
                VkDeviceMemory m;
                if (!alloc(req, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, m)) return false;
                vkBindBufferMemory(dev_, b, m, 0);
                void* p;
                if (VkResult r = vkMapMemory(dev_, m, 0, VK_WHOLE_SIZE, 0, &p); r != VK_SUCCESS) return fail("vkMapMemory", r);
                std::memset(p, 0, bi.size);
                std::memcpy(p, t.data.data(), std::min<size_t>(t.data.size(), bi.size));
                VkBufferViewCreateInfo vi{VK_STRUCTURE_TYPE_BUFFER_VIEW_CREATE_INFO};
                vi.buffer = b;
                vi.format = static_cast<VkFormat>(t.format);
                vi.range = VK_WHOLE_SIZE;
                VkBufferView bv;
                if (VkResult r = vkCreateBufferView(dev_, &vi, nullptr, &bv); r != VK_SUCCESS) return fail("vkCreateBufferView", r);
                bviews_.push_back(bv);
                entries_.push_back({VK_NULL_HANDLE, VK_NULL_HANDLE, VK_NULL_HANDLE, false, bv, p, bi.size});
                continue;
            }
            if (t.share >= 0) {   // another view (and sampler) of an earlier texture's image
                const Texture& o = texs[static_cast<size_t>(t.share)];
                VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
                vi.image = entries_[static_cast<size_t>(t.share)].image;
                vi.viewType = static_cast<VkImageViewType>(t.view_type);
                vi.format = static_cast<VkFormat>(t.view_format ? t.view_format : o.format);
                vi.subresourceRange = {static_cast<VkImageAspectFlags>(depth ? VK_IMAGE_ASPECT_DEPTH_BIT : VK_IMAGE_ASPECT_COLOR_BIT),
                                       0, o.levels, 0, o.layers};
                VkImageView view;
                if (VkResult r = vkCreateImageView(dev_, &vi, nullptr, &view); r != VK_SUCCESS) return fail("vkCreateImageView", r);
                views_.push_back(view);
                VkSampler smp = VK_NULL_HANDLE;
                if (!t.storage && t.kind == Texture::Kind::Combined && !make_sampler(t, smp)) return false;
                entries_.push_back({vi.image, view, smp, depth});
                continue;
            }
            const bool cube = t.view_type == VK_IMAGE_VIEW_TYPE_CUBE || t.view_type == VK_IMAGE_VIEW_TYPE_CUBE_ARRAY;
            VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
            ii.flags = (cube ? VK_IMAGE_CREATE_CUBE_COMPATIBLE_BIT : 0) |
                       ((t.view_format && t.view_format != t.format) || t.storage ? VK_IMAGE_CREATE_MUTABLE_FORMAT_BIT : 0);
            ii.imageType = t.view_type == VK_IMAGE_VIEW_TYPE_3D ? VK_IMAGE_TYPE_3D
                         : (t.view_type == VK_IMAGE_VIEW_TYPE_1D || t.view_type == VK_IMAGE_VIEW_TYPE_1D_ARRAY) ? VK_IMAGE_TYPE_1D
                                                                                                                 : VK_IMAGE_TYPE_2D;
            ii.format = static_cast<VkFormat>(t.format);
            ii.extent = {t.width, t.height, t.depth};
            ii.mipLevels = t.levels;
            ii.arrayLayers = t.layers;
            ii.samples = static_cast<VkSampleCountFlagBits>(t.samples);
            ii.tiling = VK_IMAGE_TILING_OPTIMAL;
            ii.usage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT |
                       (t.storage ? VK_IMAGE_USAGE_STORAGE_BIT : VK_IMAGE_USAGE_SAMPLED_BIT);
            ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            VkImage img;
            if (VkResult r = vkCreateImage(dev_, &ii, nullptr, &img); r != VK_SUCCESS) return fail("vkCreateImage", r);
            images_.push_back(img);
            VkMemoryRequirements req;
            vkGetImageMemoryRequirements(dev_, img, &req);
            VkDeviceMemory m;
            if (!alloc(req, 0, m)) return false;
            vkBindImageMemory(dev_, img, m, 0);
            VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
            vi.image = img;
            vi.viewType = static_cast<VkImageViewType>(t.view_type);
            vi.format = static_cast<VkFormat>(t.view_format ? t.view_format : t.format);
            vi.subresourceRange = {static_cast<VkImageAspectFlags>(depth ? VK_IMAGE_ASPECT_DEPTH_BIT : VK_IMAGE_ASPECT_COLOR_BIT),
                                   0, t.levels, 0, t.layers};
            VkImageView view;
            if (VkResult r = vkCreateImageView(dev_, &vi, nullptr, &view); r != VK_SUCCESS) return fail("vkCreateImageView", r);
            views_.push_back(view);
            VkSampler smp = VK_NULL_HANDLE;
            if (!t.storage && t.kind == Texture::Kind::Combined && !make_sampler(t, smp)) return false;
            entries_.push_back({img, view, smp, depth});
        }
        return transfer(texs, true);
    }

    /** Descriptor layout bindings / pool sizes / writes for the textures (call after create). */
    static VkDescriptorType dtype(const Texture& t) {
        if (t.texel_buffer) return t.storage ? VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER : VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER;
        if (t.storage) return VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
        if (t.kind == Texture::Kind::SampledImage) return VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
        if (t.kind == Texture::Kind::SamplerOnly) return VK_DESCRIPTOR_TYPE_SAMPLER;
        return VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
    }
    void layout(const std::vector<Texture>& texs, VkShaderStageFlags stages, std::vector<VkDescriptorSetLayoutBinding>& binds,
                std::vector<VkDescriptorPoolSize>& ps) const {
        for (const Texture& t : texs) {
            bool seen = false;   // P4.4: the elements of an array share one binding
            for (const auto& b : binds) seen = seen || b.binding == t.binding;
            if (!seen) binds.push_back({t.binding, dtype(t), std::max(1u, t.array_size), stages, nullptr});
            ps.push_back({dtype(t), 1});
        }
    }
    void writes(const std::vector<Texture>& texs, VkDescriptorSet ds, std::vector<VkWriteDescriptorSet>& out) {
        infos_.resize(texs.size());
        for (size_t i = 0; i < texs.size(); ++i) {
            const Texture& t = texs[i];
            infos_[i] = {entries_[i].sampler, entries_[i].view,
                         t.storage ? VK_IMAGE_LAYOUT_GENERAL : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
            VkWriteDescriptorSet w{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
            w.dstSet = ds;
            w.dstBinding = t.binding;
            w.dstArrayElement = t.array_element;
            w.descriptorCount = 1;
            w.descriptorType = dtype(t);
            if (t.texel_buffer) w.pTexelBufferView = &entries_[i].bview;
            else w.pImageInfo = &infos_[i];
            out.push_back(w);
        }
    }

    /** Reads every storage image back into its data (after the work). */
    bool readback(std::vector<Texture>& texs) { return transfer(texs, false); }

private:
    struct Entry {
        VkImage image; VkImageView view; VkSampler sampler; bool depth;
        VkBufferView bview{VK_NULL_HANDLE}; void* mapped{nullptr}; uint64_t size{0};   // P4.4: texel buffers
    };

    bool make_sampler(const Texture& t, VkSampler& smp) {
        VkSamplerCreateInfo si{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
        si.magFilter = si.minFilter = t.linear ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
        si.mipmapMode = t.mip_linear ? VK_SAMPLER_MIPMAP_MODE_LINEAR : VK_SAMPLER_MIPMAP_MODE_NEAREST;
        si.addressModeU = si.addressModeV = si.addressModeW = static_cast<VkSamplerAddressMode>(t.address);
        si.compareEnable = t.compare;
        si.compareOp = static_cast<VkCompareOp>(t.compare_op);
        si.minLod = 0.0f;
        si.maxLod = t.max_lod;
        si.borderColor = VK_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK;
        if (VkResult r = vkCreateSampler(dev_, &si, nullptr, &smp); r != VK_SUCCESS) return fail("vkCreateSampler", r);
        samplers_.push_back(smp);
        return true;
    }

    static uint64_t level_bytes(const Texture& t, uint32_t l) {
        const uint64_t w = std::max(1u, t.width >> l), h = std::max(1u, t.height >> l), d = std::max(1u, t.depth >> l);
        return w * h * d * t.layers * texel_bytes(t.format);
    }
    static uint64_t total_bytes(const Texture& t) {
        uint64_t s = 0;
        for (uint32_t l = 0; l < t.levels; ++l) s += level_bytes(t, l);
        return s;
    }

    bool fail(const char* what, VkResult r) {
        error_ = std::string(what) + " = " + std::to_string(static_cast<int>(r));
        return false;
    }
    bool alloc(const VkMemoryRequirements& req, VkMemoryPropertyFlags want, VkDeviceMemory& m) {
        uint32_t type = 0;
        for (; type < mp_.memoryTypeCount; ++type)
            if ((req.memoryTypeBits & (1u << type)) && (mp_.memoryTypes[type].propertyFlags & want) == want) break;
        VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        ai.allocationSize = req.size;
        ai.memoryTypeIndex = type;
        if (VkResult r = vkAllocateMemory(dev_, &ai, nullptr, &m); r != VK_SUCCESS) return fail("vkAllocateMemory", r);
        mems_.push_back(m);
        return true;
    }

    // upload (to SHADER_READ_ONLY / GENERAL) or read back (storage images, from GENERAL)
    bool transfer(std::vector<Texture>& texs, bool upload) {
        std::vector<std::pair<size_t, void*>> stage;   // texture index, mapped staging buffer
        std::vector<VkBuffer> sbufs;
        for (size_t i = 0; i < texs.size(); ++i) {
            const Texture& t = texs[i];
            if (t.texel_buffer || t.kind == Texture::Kind::SamplerOnly) {   // P4.4: no image to copy
                if (!upload && t.texel_buffer && t.storage) {
                    texs[i].data.resize(entries_[i].size);
                    std::memcpy(texs[i].data.data(), entries_[i].mapped, entries_[i].size);
                }
                continue;
            }
            if (!upload && !t.storage) continue;
            if (t.share >= 0) continue;    // a view of another texture's image: copied with that one
            if (t.samples > 1) continue;   // multisampled images are not copied (cleared contents are not tested)
            VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
            bi.size = std::max<uint64_t>(16, total_bytes(t));
            bi.usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
            VkBuffer b;
            if (VkResult r = vkCreateBuffer(dev_, &bi, nullptr, &b); r != VK_SUCCESS) return fail("vkCreateBuffer", r);
            bufs_.push_back(b);
            VkMemoryRequirements req;
            vkGetBufferMemoryRequirements(dev_, b, &req);
            VkDeviceMemory m;
            if (!alloc(req, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, m)) return false;
            vkBindBufferMemory(dev_, b, m, 0);
            void* p;
            if (VkResult r = vkMapMemory(dev_, m, 0, VK_WHOLE_SIZE, 0, &p); r != VK_SUCCESS) return fail("vkMapMemory", r);
            if (upload) {
                std::memset(p, 0, bi.size);
                std::memcpy(p, t.data.data(), std::min<size_t>(t.data.size(), total_bytes(t)));
            }
            stage.push_back({i, p});
            sbufs.push_back(b);
        }
        VkCommandBufferAllocateInfo cbi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cbi.commandPool = pool_;
        cbi.commandBufferCount = 1;
        VkCommandBuffer cb;
        if (VkResult r = vkAllocateCommandBuffers(dev_, &cbi, &cb); r != VK_SUCCESS) return fail("vkAllocateCommandBuffers", r);
        VkCommandBufferBeginInfo bbi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        vkBeginCommandBuffer(cb, &bbi);
        for (size_t i = 0; i < texs.size(); ++i) {
            const Texture& t = texs[i];
            if (t.texel_buffer || t.kind == Texture::Kind::SamplerOnly) continue;
            if (!upload && !t.storage) continue;
            if (t.share >= 0) continue;
            const VkImageAspectFlags aspect = entries_[i].depth ? VK_IMAGE_ASPECT_DEPTH_BIT : VK_IMAGE_ASPECT_COLOR_BIT;
            const VkImageLayout final_layout = t.storage ? VK_IMAGE_LAYOUT_GENERAL : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
            auto barrier = [&](VkImageLayout from, VkImageLayout to) {
                VkImageMemoryBarrier mb{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
                mb.srcAccessMask = VK_ACCESS_MEMORY_WRITE_BIT;
                mb.dstAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
                mb.oldLayout = from;
                mb.newLayout = to;
                mb.srcQueueFamilyIndex = mb.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
                mb.image = entries_[i].image;
                mb.subresourceRange = {aspect, 0, t.levels, 0, t.layers};
                vkCmdPipelineBarrier(cb, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, 0, 0, nullptr, 0,
                                     nullptr, 1, &mb);
            };
            VkBuffer b = VK_NULL_HANDLE;
            for (size_t s = 0; s < stage.size(); ++s) if (stage[s].first == i) b = sbufs[s];
            std::vector<VkBufferImageCopy> regions;
            uint64_t off = 0;
            for (uint32_t l = 0; l < t.levels; ++l) {
                VkBufferImageCopy c{};
                c.bufferOffset = off;
                c.imageSubresource = {aspect, l, 0, t.layers};
                c.imageExtent = {std::max(1u, t.width >> l), std::max(1u, t.height >> l), std::max(1u, t.depth >> l)};
                regions.push_back(c);
                off += level_bytes(t, l);
            }
            if (upload) {
                barrier(VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);
                if (b) vkCmdCopyBufferToImage(cb, b, entries_[i].image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                              static_cast<uint32_t>(regions.size()), regions.data());
                barrier(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, final_layout);
            } else if (b) {
                barrier(final_layout, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL);
                vkCmdCopyImageToBuffer(cb, entries_[i].image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, b,
                                       static_cast<uint32_t>(regions.size()), regions.data());
                barrier(VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, final_layout);
            }
        }
        vkEndCommandBuffer(cb);
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1;
        si.pCommandBuffers = &cb;
        VkResult r = vkQueueSubmit(queue_, 1, &si, VK_NULL_HANDLE);
        if (r == VK_SUCCESS) r = vkQueueWaitIdle(queue_);
        vkFreeCommandBuffers(dev_, pool_, 1, &cb);
        if (r != VK_SUCCESS) return fail(upload ? "subida de texturas" : "lectura de imágenes", r);
        if (!upload)
            for (auto& [i, p] : stage) {
                texs[i].data.resize(total_bytes(texs[i]));
                std::memcpy(texs[i].data.data(), p, texs[i].data.size());
            }
        return true;
    }

    VkDevice dev_;
    VkQueue queue_;
    VkCommandPool pool_;
    VkPhysicalDeviceMemoryProperties mp_;
    std::string error_;
    std::vector<Entry> entries_;
    std::vector<VkImage> images_;
    std::vector<VkImageView> views_;
    std::vector<VkSampler> samplers_;
    std::vector<VkBuffer> bufs_;
    std::vector<VkDeviceMemory> mems_;
    std::vector<VkDescriptorImageInfo> infos_;
    std::vector<VkBufferView> bviews_;
#define LG_TL(name) PFN_##name name{nullptr};
    LG_TL(vkCreateImage) LG_TL(vkDestroyImage) LG_TL(vkGetImageMemoryRequirements) LG_TL(vkBindImageMemory)
    LG_TL(vkCreateImageView) LG_TL(vkDestroyImageView) LG_TL(vkCreateSampler) LG_TL(vkDestroySampler)
    LG_TL(vkAllocateMemory) LG_TL(vkFreeMemory) LG_TL(vkMapMemory) LG_TL(vkCreateBuffer) LG_TL(vkDestroyBuffer)
    LG_TL(vkGetBufferMemoryRequirements) LG_TL(vkBindBufferMemory) LG_TL(vkAllocateCommandBuffers)
    LG_TL(vkFreeCommandBuffers) LG_TL(vkBeginCommandBuffer) LG_TL(vkEndCommandBuffer) LG_TL(vkCmdPipelineBarrier)
    LG_TL(vkCmdCopyBufferToImage) LG_TL(vkCmdCopyImageToBuffer) LG_TL(vkQueueSubmit) LG_TL(vkQueueWaitIdle)
    LG_TL(vkCreateBufferView) LG_TL(vkDestroyBufferView)
#undef LG_TL
};

} // namespace lg_test::vk
