#include "vk_compute.h"

#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.h>

#include <dlfcn.h>

#include "vk_textures.h"

#include <cstring>

namespace lg_test::vk {

struct ComputeRunner::Impl {
    void* so{nullptr};
    std::string error;
    PFN_vkGetInstanceProcAddr gipa{nullptr};
    VkInstance inst{VK_NULL_HANDLE};
    VkPhysicalDevice pd{VK_NULL_HANDLE};
    VkDevice dev{VK_NULL_HANDLE};
    VkQueue queue{VK_NULL_HANDLE};
    VkCommandPool pool{VK_NULL_HANDLE};
    VkPhysicalDeviceMemoryProperties mp{};
    VkPhysicalDeviceProperties props{};
    VkPhysicalDeviceFeatures enabled{};   // P4.4: what the device was created with
    bool descriptor_indexing{false};      // P4.4: non-uniform image array indexing enabled
    bool int64_atomics{false};            // P4.4: shaderBufferInt64Atomics + shaderSharedInt64Atomics
    PFN_vkGetDeviceProcAddr gdpa{nullptr};
#define LG_FN(name) PFN_##name name{nullptr};
    LG_FN(vkDestroyInstance) LG_FN(vkDestroyDevice) LG_FN(vkGetDeviceQueue) LG_FN(vkCreateBuffer)
    LG_FN(vkDestroyBuffer) LG_FN(vkGetBufferMemoryRequirements) LG_FN(vkAllocateMemory) LG_FN(vkFreeMemory)
    LG_FN(vkBindBufferMemory) LG_FN(vkMapMemory) LG_FN(vkUnmapMemory) LG_FN(vkCreateShaderModule)
    LG_FN(vkDestroyShaderModule) LG_FN(vkCreateDescriptorSetLayout) LG_FN(vkDestroyDescriptorSetLayout)
    LG_FN(vkCreatePipelineLayout) LG_FN(vkDestroyPipelineLayout) LG_FN(vkCreateComputePipelines)
    LG_FN(vkDestroyPipeline) LG_FN(vkCreateDescriptorPool) LG_FN(vkDestroyDescriptorPool)
    LG_FN(vkAllocateDescriptorSets) LG_FN(vkUpdateDescriptorSets) LG_FN(vkCreateCommandPool)
    LG_FN(vkDestroyCommandPool) LG_FN(vkAllocateCommandBuffers) LG_FN(vkFreeCommandBuffers)
    LG_FN(vkBeginCommandBuffer) LG_FN(vkCmdBindPipeline) LG_FN(vkCmdBindDescriptorSets) LG_FN(vkCmdDispatch)
    LG_FN(vkEndCommandBuffer) LG_FN(vkQueueSubmit) LG_FN(vkQueueWaitIdle)
#undef LG_FN

    bool fail(const char* what, VkResult r) {
        error = std::string(what) + " = " + std::to_string(static_cast<int>(r));
        return false;
    }

    bool init(const std::string& loader) {
        so = dlopen(loader.c_str(), RTLD_NOW | RTLD_LOCAL);
        if (!so) { error = std::string("dlopen: ") + dlerror(); return false; }
        gipa = reinterpret_cast<PFN_vkGetInstanceProcAddr>(dlsym(so, "vkGetInstanceProcAddr"));
        if (!gipa) { error = "vkGetInstanceProcAddr missing"; return false; }
        auto create_instance = reinterpret_cast<PFN_vkCreateInstance>(gipa(VK_NULL_HANDLE, "vkCreateInstance"));
        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        app.apiVersion = VK_API_VERSION_1_1;
        VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        ici.pApplicationInfo = &app;
        if (VkResult r = create_instance(&ici, nullptr, &inst); r != VK_SUCCESS) return fail("vkCreateInstance", r);
        vkDestroyInstance = reinterpret_cast<PFN_vkDestroyInstance>(gipa(inst, "vkDestroyInstance"));
        auto enumerate = reinterpret_cast<PFN_vkEnumeratePhysicalDevices>(gipa(inst, "vkEnumeratePhysicalDevices"));
        auto get_mem = reinterpret_cast<PFN_vkGetPhysicalDeviceMemoryProperties>(gipa(inst, "vkGetPhysicalDeviceMemoryProperties"));
        auto get_props = reinterpret_cast<PFN_vkGetPhysicalDeviceProperties>(gipa(inst, "vkGetPhysicalDeviceProperties"));
        auto create_device = reinterpret_cast<PFN_vkCreateDevice>(gipa(inst, "vkCreateDevice"));
        auto gdpa = reinterpret_cast<PFN_vkGetDeviceProcAddr>(gipa(inst, "vkGetDeviceProcAddr"));
        uint32_t n = 1;
        if (VkResult r = enumerate(inst, &n, &pd); (r != VK_SUCCESS && r != VK_INCOMPLETE) || n == 0)
            return fail("vkEnumeratePhysicalDevices", r);
        get_mem(pd, &mp);
        get_props(pd, &props);
        const float prio = 1.0f;
        VkDeviceQueueCreateInfo q{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        q.queueCount = 1;
        q.pQueuePriorities = &prio;
        VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        dci.queueCreateInfoCount = 1;
        dci.pQueueCreateInfos = &q;
        // P4.3: the image features the texture tests can use, if present
        auto get_feats = reinterpret_cast<PFN_vkGetPhysicalDeviceFeatures>(gipa(inst, "vkGetPhysicalDeviceFeatures"));
        VkPhysicalDeviceFeatures have{}, en{};
        if (get_feats) get_feats(pd, &have);
        en.imageCubeArray = have.imageCubeArray;
        en.shaderImageGatherExtended = have.shaderImageGatherExtended;
        en.shaderStorageImageExtendedFormats = have.shaderStorageImageExtendedFormats;
        en.shaderStorageImageReadWithoutFormat = have.shaderStorageImageReadWithoutFormat;
        en.shaderStorageImageWriteWithoutFormat = have.shaderStorageImageWriteWithoutFormat;
        en.shaderStorageImageMultisample = have.shaderStorageImageMultisample;
        en.shaderFloat64 = have.shaderFloat64;   // P4.4: double precision (not in SwiftShader)
        en.shaderInt64 = have.shaderInt64;
        en.shaderSampledImageArrayDynamicIndexing = have.shaderSampledImageArrayDynamicIndexing;
        en.shaderStorageImageArrayDynamicIndexing = have.shaderStorageImageArrayDynamicIndexing;
        enabled = en;
        dci.pEnabledFeatures = &en;
        // P4.4 (D-P4.4-10): general bindless indexes descriptor arrays with non-uniform values
        auto enum_ext = reinterpret_cast<PFN_vkEnumerateDeviceExtensionProperties>(gipa(inst, "vkEnumerateDeviceExtensionProperties"));
        auto get_feats2 = reinterpret_cast<PFN_vkGetPhysicalDeviceFeatures2>(gipa(inst, "vkGetPhysicalDeviceFeatures2"));
        std::vector<const char*> exts;
        VkPhysicalDeviceDescriptorIndexingFeaturesEXT di_have{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DESCRIPTOR_INDEXING_FEATURES_EXT};
        VkPhysicalDeviceDescriptorIndexingFeaturesEXT di_en{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DESCRIPTOR_INDEXING_FEATURES_EXT};
        VkPhysicalDeviceShaderAtomicInt64FeaturesKHR a64_have{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_ATOMIC_INT64_FEATURES_KHR};
        VkPhysicalDeviceShaderAtomicInt64FeaturesKHR a64_en{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_ATOMIC_INT64_FEATURES_KHR};
        const void* chain_head = nullptr;
        if (enum_ext && get_feats2) {
            uint32_t ne = 0;
            enum_ext(pd, nullptr, &ne, nullptr);
            std::vector<VkExtensionProperties> ep(ne);
            enum_ext(pd, nullptr, &ne, ep.data());
            bool di = false, m3 = false, a64 = false;
            for (const auto& e : ep) {
                di = di || std::strcmp(e.extensionName, VK_EXT_DESCRIPTOR_INDEXING_EXTENSION_NAME) == 0;
                m3 = m3 || std::strcmp(e.extensionName, VK_KHR_MAINTENANCE3_EXTENSION_NAME) == 0;
                a64 = a64 || std::strcmp(e.extensionName, VK_KHR_SHADER_ATOMIC_INT64_EXTENSION_NAME) == 0;
            }
            VkPhysicalDeviceFeatures2 f2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
            di_have.pNext = &a64_have;
            f2.pNext = &di_have;
            get_feats2(pd, &f2);
            if (di && m3) {
                di_en.shaderSampledImageArrayNonUniformIndexing = di_have.shaderSampledImageArrayNonUniformIndexing;
                di_en.shaderStorageImageArrayNonUniformIndexing = di_have.shaderStorageImageArrayNonUniformIndexing;
                di_en.runtimeDescriptorArray = di_have.runtimeDescriptorArray;
                exts.push_back(VK_KHR_MAINTENANCE3_EXTENSION_NAME);
                exts.push_back(VK_EXT_DESCRIPTOR_INDEXING_EXTENSION_NAME);
                di_en.pNext = const_cast<void*>(chain_head);
                chain_head = &di_en;
                descriptor_indexing = di_en.shaderSampledImageArrayNonUniformIndexing == VK_TRUE &&
                                      di_en.shaderStorageImageArrayNonUniformIndexing == VK_TRUE;
            }
            // P4.4: 64-bit atomics on storage buffers and shared memory (ATOM/RED/ATOMS .64)
            if (a64 && en.shaderInt64) {
                a64_en.shaderBufferInt64Atomics = a64_have.shaderBufferInt64Atomics;
                a64_en.shaderSharedInt64Atomics = a64_have.shaderSharedInt64Atomics;
                exts.push_back(VK_KHR_SHADER_ATOMIC_INT64_EXTENSION_NAME);
                a64_en.pNext = const_cast<void*>(chain_head);
                chain_head = &a64_en;
                int64_atomics = a64_en.shaderBufferInt64Atomics == VK_TRUE && a64_en.shaderSharedInt64Atomics == VK_TRUE;
            }
        }
        dci.pNext = chain_head;
        dci.enabledExtensionCount = static_cast<uint32_t>(exts.size());
        dci.ppEnabledExtensionNames = exts.data();
        this->gdpa = gdpa;
        if (VkResult r = create_device(pd, &dci, nullptr, &dev); r != VK_SUCCESS) return fail("vkCreateDevice", r);
#define LG_LOAD(name) name = reinterpret_cast<PFN_##name>(gdpa(dev, #name)); if (!name) { error = #name " missing"; return false; }
        LG_LOAD(vkDestroyDevice) LG_LOAD(vkGetDeviceQueue) LG_LOAD(vkCreateBuffer) LG_LOAD(vkDestroyBuffer)
        LG_LOAD(vkGetBufferMemoryRequirements) LG_LOAD(vkAllocateMemory) LG_LOAD(vkFreeMemory)
        LG_LOAD(vkBindBufferMemory) LG_LOAD(vkMapMemory) LG_LOAD(vkUnmapMemory) LG_LOAD(vkCreateShaderModule)
        LG_LOAD(vkDestroyShaderModule) LG_LOAD(vkCreateDescriptorSetLayout) LG_LOAD(vkDestroyDescriptorSetLayout)
        LG_LOAD(vkCreatePipelineLayout) LG_LOAD(vkDestroyPipelineLayout) LG_LOAD(vkCreateComputePipelines)
        LG_LOAD(vkDestroyPipeline) LG_LOAD(vkCreateDescriptorPool) LG_LOAD(vkDestroyDescriptorPool)
        LG_LOAD(vkAllocateDescriptorSets) LG_LOAD(vkUpdateDescriptorSets) LG_LOAD(vkCreateCommandPool)
        LG_LOAD(vkDestroyCommandPool) LG_LOAD(vkAllocateCommandBuffers) LG_LOAD(vkFreeCommandBuffers)
        LG_LOAD(vkBeginCommandBuffer) LG_LOAD(vkCmdBindPipeline) LG_LOAD(vkCmdBindDescriptorSets)
        LG_LOAD(vkCmdDispatch) LG_LOAD(vkEndCommandBuffer) LG_LOAD(vkQueueSubmit) LG_LOAD(vkQueueWaitIdle)
#undef LG_LOAD
        vkGetDeviceQueue(dev, 0, 0, &queue);
        VkCommandPoolCreateInfo cpci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        if (VkResult r = vkCreateCommandPool(dev, &cpci, nullptr, &pool); r != VK_SUCCESS) return fail("vkCreateCommandPool", r);
        return true;
    }

    ~Impl() {
        if (dev) {
            if (pool) vkDestroyCommandPool(dev, pool, nullptr);
            vkDestroyDevice(dev, nullptr);
        }
        if (inst && vkDestroyInstance) vkDestroyInstance(inst, nullptr);
        if (so) dlclose(so);
    }
};

ComputeRunner::ComputeRunner(const std::string& loader) : impl_(std::make_unique<Impl>()) {
    if (!impl_->init(loader) && impl_->error.empty()) impl_->error = "init failed";
}
ComputeRunner::~ComputeRunner() = default;
bool ComputeRunner::ok() const noexcept { return impl_->dev != VK_NULL_HANDLE && impl_->error.empty(); }
const std::string& ComputeRunner::error() const noexcept { return impl_->error; }
std::string ComputeRunner::device_name() const { return impl_->props.deviceName; }
bool ComputeRunner::float64() const noexcept { return impl_->enabled.shaderFloat64 == VK_TRUE; }
bool ComputeRunner::descriptor_indexing() const noexcept { return impl_->descriptor_indexing; }
bool ComputeRunner::int64_atomics() const noexcept { return impl_->int64_atomics; }

bool ComputeRunner::run(const std::vector<uint32_t>& spirv, std::vector<Buffer>& buffers, const uint32_t groups[3]) {
    std::vector<Texture> none;
    return run(spirv, buffers, groups, none);
}

bool ComputeRunner::run(const std::vector<uint32_t>& spirv, std::vector<Buffer>& buffers, const uint32_t groups[3],
                        std::vector<Texture>& textures) {
    Impl& I = *impl_;
    TextureSet texset(I.gdpa, I.dev, I.queue, I.pool, I.mp);
    if (!textures.empty() && !texset.create(textures)) { I.error = texset.error(); return false; }
    I.error.clear();
    struct Res {
        Impl& I;
        std::vector<VkBuffer> bufs;
        std::vector<VkDeviceMemory> mems;
        VkShaderModule sm{VK_NULL_HANDLE};
        VkDescriptorSetLayout dsl{VK_NULL_HANDLE};
        VkPipelineLayout pl{VK_NULL_HANDLE};
        VkPipeline pipe{VK_NULL_HANDLE};
        VkDescriptorPool dp{VK_NULL_HANDLE};
        VkCommandBuffer cb{VK_NULL_HANDLE};
        ~Res() {
            if (cb) I.vkFreeCommandBuffers(I.dev, I.pool, 1, &cb);
            if (dp) I.vkDestroyDescriptorPool(I.dev, dp, nullptr);
            if (pipe) I.vkDestroyPipeline(I.dev, pipe, nullptr);
            if (pl) I.vkDestroyPipelineLayout(I.dev, pl, nullptr);
            if (dsl) I.vkDestroyDescriptorSetLayout(I.dev, dsl, nullptr);
            if (sm) I.vkDestroyShaderModule(I.dev, sm, nullptr);
            for (auto b : bufs) I.vkDestroyBuffer(I.dev, b, nullptr);
            for (auto m : mems) I.vkFreeMemory(I.dev, m, nullptr);
        }
    } R{I};
    std::vector<void*> maps;
    for (const Buffer& b : buffers) {
        VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bi.size = b.data.empty() ? 16 : b.data.size();
        bi.usage = b.uniform ? VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT : VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
        VkBuffer vb;
        if (VkResult r = I.vkCreateBuffer(I.dev, &bi, nullptr, &vb); r != VK_SUCCESS) return I.fail("vkCreateBuffer", r);
        R.bufs.push_back(vb);
        VkMemoryRequirements req;
        I.vkGetBufferMemoryRequirements(I.dev, vb, &req);
        uint32_t type = 0;
        const VkMemoryPropertyFlags want = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
        for (; type < I.mp.memoryTypeCount; ++type)
            if ((req.memoryTypeBits & (1u << type)) && (I.mp.memoryTypes[type].propertyFlags & want) == want) break;
        VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        ai.allocationSize = req.size;
        ai.memoryTypeIndex = type;
        VkDeviceMemory m;
        if (VkResult r = I.vkAllocateMemory(I.dev, &ai, nullptr, &m); r != VK_SUCCESS) return I.fail("vkAllocateMemory", r);
        R.mems.push_back(m);
        I.vkBindBufferMemory(I.dev, vb, m, 0);
        void* p;
        if (VkResult r = I.vkMapMemory(I.dev, m, 0, VK_WHOLE_SIZE, 0, &p); r != VK_SUCCESS) return I.fail("vkMapMemory", r);
        std::memset(p, 0, bi.size);
        if (!b.data.empty()) std::memcpy(p, b.data.data(), b.data.size());
        maps.push_back(p);
    }
    VkShaderModuleCreateInfo smi{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smi.codeSize = spirv.size() * 4;
    smi.pCode = spirv.data();
    if (VkResult r = I.vkCreateShaderModule(I.dev, &smi, nullptr, &R.sm); r != VK_SUCCESS) return I.fail("vkCreateShaderModule", r);
    std::vector<VkDescriptorSetLayoutBinding> binds;
    uint32_t n_uniform = 0, n_storage = 0;
    for (const Buffer& b : buffers) {
        binds.push_back({b.binding, b.uniform ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER : VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1,
                         VK_SHADER_STAGE_COMPUTE_BIT, nullptr});
        (b.uniform ? n_uniform : n_storage)++;
    }
    std::vector<VkDescriptorPoolSize> tps;
    texset.layout(textures, VK_SHADER_STAGE_COMPUTE_BIT, binds, tps);
    VkDescriptorSetLayoutCreateInfo dli{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dli.bindingCount = static_cast<uint32_t>(binds.size());
    dli.pBindings = binds.data();
    if (VkResult r = I.vkCreateDescriptorSetLayout(I.dev, &dli, nullptr, &R.dsl); r != VK_SUCCESS) return I.fail("vkCreateDescriptorSetLayout", r);
    VkPipelineLayoutCreateInfo pli{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pli.setLayoutCount = 1;
    pli.pSetLayouts = &R.dsl;
    if (VkResult r = I.vkCreatePipelineLayout(I.dev, &pli, nullptr, &R.pl); r != VK_SUCCESS) return I.fail("vkCreatePipelineLayout", r);
    VkComputePipelineCreateInfo cpi{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    cpi.stage = {VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0, VK_SHADER_STAGE_COMPUTE_BIT, R.sm, "main", nullptr};
    cpi.layout = R.pl;
    if (VkResult r = I.vkCreateComputePipelines(I.dev, VK_NULL_HANDLE, 1, &cpi, nullptr, &R.pipe); r != VK_SUCCESS)
        return I.fail("vkCreateComputePipelines", r);
    std::vector<VkDescriptorPoolSize> ps;
    if (n_uniform) ps.push_back({VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, n_uniform});
    if (n_storage) ps.push_back({VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, n_storage});
    ps.insert(ps.end(), tps.begin(), tps.end());
    VkDescriptorPoolCreateInfo dpi{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpi.maxSets = 1;
    dpi.poolSizeCount = static_cast<uint32_t>(ps.size());
    dpi.pPoolSizes = ps.data();
    if (VkResult r = I.vkCreateDescriptorPool(I.dev, &dpi, nullptr, &R.dp); r != VK_SUCCESS) return I.fail("vkCreateDescriptorPool", r);
    VkDescriptorSetAllocateInfo dai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dai.descriptorPool = R.dp;
    dai.descriptorSetCount = 1;
    dai.pSetLayouts = &R.dsl;
    VkDescriptorSet ds;
    if (VkResult r = I.vkAllocateDescriptorSets(I.dev, &dai, &ds); r != VK_SUCCESS) return I.fail("vkAllocateDescriptorSets", r);
    std::vector<VkDescriptorBufferInfo> infos(buffers.size());
    std::vector<VkWriteDescriptorSet> writes(buffers.size());
    for (size_t i = 0; i < buffers.size(); ++i) {
        infos[i] = {R.bufs[i], 0, VK_WHOLE_SIZE};
        writes[i] = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET, nullptr, ds, buffers[i].binding, 0, 1,
                     buffers[i].uniform ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER : VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
                     nullptr, &infos[i], nullptr};
    }
    texset.writes(textures, ds, writes);
    I.vkUpdateDescriptorSets(I.dev, static_cast<uint32_t>(writes.size()), writes.data(), 0, nullptr);
    VkCommandBufferAllocateInfo cbi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cbi.commandPool = I.pool;
    cbi.commandBufferCount = 1;
    if (VkResult r = I.vkAllocateCommandBuffers(I.dev, &cbi, &R.cb); r != VK_SUCCESS) return I.fail("vkAllocateCommandBuffers", r);
    VkCommandBufferBeginInfo bbi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    I.vkBeginCommandBuffer(R.cb, &bbi);
    I.vkCmdBindPipeline(R.cb, VK_PIPELINE_BIND_POINT_COMPUTE, R.pipe);
    I.vkCmdBindDescriptorSets(R.cb, VK_PIPELINE_BIND_POINT_COMPUTE, R.pl, 0, 1, &ds, 0, nullptr);
    I.vkCmdDispatch(R.cb, groups[0], groups[1], groups[2]);
    I.vkEndCommandBuffer(R.cb);
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1;
    si.pCommandBuffers = &R.cb;
    if (VkResult r = I.vkQueueSubmit(I.queue, 1, &si, VK_NULL_HANDLE); r != VK_SUCCESS) return I.fail("vkQueueSubmit", r);
    if (VkResult r = I.vkQueueWaitIdle(I.queue); r != VK_SUCCESS) return I.fail("vkQueueWaitIdle", r);
    for (size_t i = 0; i < buffers.size(); ++i)
        if (!buffers[i].data.empty()) std::memcpy(buffers[i].data.data(), maps[i], buffers[i].data.size());
    if (!textures.empty() && !texset.readback(textures)) { I.error = texset.error(); return false; }
    return true;
}

} // namespace lg_test::vk
