#include "maxwell_ref.h"

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>
#include <map>
#include <string_view>

#include "../../shader/maxwell/isa.h"

namespace lg_test::mref {
namespace {

using lg::shader::maxwell::Encoding;

uint64_t fld(uint64_t w, unsigned pos, unsigned len) { return (w >> pos) & ((len >= 64) ? ~0ull : ((1ull << len) - 1)); }
bool bt(uint64_t w, unsigned pos) { return (w >> pos) & 1; }
int32_t sx(uint32_t v, unsigned width) {
    const uint32_t m = 1u << (width - 1);
    return static_cast<int32_t>((v ^ m) - m);
}
float asf(uint32_t u) { return std::bit_cast<float>(u); }
uint32_t asu(float f) { return std::bit_cast<uint32_t>(f); }
float ftz(float f) {
    uint32_t u = asu(f);
    if ((u & 0x7f800000u) == 0) u &= 0x80000000u;
    return asf(u);
}
float fsat(float f) { return f > 0.f ? (f < 1.f ? f : 1.f) : 0.f; }
float fna(float f, bool neg, bool abs) {
    if (abs) f = std::fabs(f);
    if (neg) f = -f;
    return f;
}

std::vector<std::string_view> tokens_of(const Encoding& e) {
    std::vector<std::string_view> out;
    std::string_view s(e.operands);
    if (auto c = s.find("/*"); c != std::string_view::npos) s = s.substr(0, c);
    int depth = 0;
    size_t start = 0;
    for (size_t i = 0; i <= s.size(); ++i) {
        if (i < s.size() && s[i] == '(') ++depth;
        if (i < s.size() && s[i] == ')') --depth;
        if (i == s.size() || (s[i] == ',' && depth == 0)) {
            std::string_view t = s.substr(start, i - start);
            while (!t.empty() && t.front() == ' ') t.remove_prefix(1);
            while (!t.empty() && t.back() == ' ') t.remove_suffix(1);
            if (!t.empty()) out.push_back(t);
            start = i + 1;
        }
    }
    return out;
}

struct Op {
    uint32_t addr;
    uint64_t w;
    const Encoding* e;
    std::vector<std::string_view> toks;
    std::vector<std::string_view> vals;
    bool has(std::string_view t) const { return std::find(toks.begin(), toks.end(), t) != toks.end(); }
    uint32_t f(unsigned p, unsigned l) const { return static_cast<uint32_t>(fld(w, p, l)); }
    bool b(unsigned p) const { return bt(w, p); }
};

struct Inv {
    uint32_t r[256]{};
    bool p[8]{};
    bool zf{}, sf{}, cf{}, of{};
    uint32_t pc{};
    std::vector<uint32_t> crs;
    std::vector<uint32_t> lmem;
    uint32_t tid[3]{}, ctaid[3]{}, index{};
    enum { Run, Barrier, Done } state{Run};
};

uint32_t norm(uint32_t t) { return ((t >> 3) & 3) == 0 ? t + 8 : t; }

class Machine {
public:
    Machine(std::span<const uint64_t> code, const Dispatch& d, Memory& mem) : d_(d), mem_(mem), daz_(d.flush_denormals) {
        for (size_t i = 0; i < code.size(); ++i) {
            if ((i & 3) == 0) continue;
            Op op{static_cast<uint32_t>(i * 8), code[i], lg::shader::maxwell::find_encoding(code[i]), {}, {}};
            if (!op.e) { err("palabra no decodificable", op); return; }
            op.toks = tokens_of(*op.e);
            for (auto t : op.toks)
                if (t == "REG_20" || t == "REG_39" || t == "C34_RZ_O14_20" || t == "S20_20" || t == "F20_20" ||
                    t == "U32_20" || t == "S32_20" || t == "F32_20" || t == "U16_20" || t == "U06_20" || t == "D20_20")
                    op.vals.push_back(t);
            index_[op.addr] = ops_.size();
            ops_.push_back(std::move(op));
        }
    }
    std::string error;

    void run_all(uint64_t max_steps) {
        if (!error.empty() || ops_.empty()) return;
        steps_left_ = max_steps;
        for (uint32_t gz = 0; gz < d_.groups[2]; ++gz)
            for (uint32_t gy = 0; gy < d_.groups[1]; ++gy)
                for (uint32_t gx = 0; gx < d_.groups[0]; ++gx) {
                    run_group(gx, gy, gz);
                    if (!error.empty()) return;
                }
    }

private:
    const Dispatch& d_;
    Memory& mem_;
    bool daz_;
    float fin(uint32_t u) const { return daz_ ? ftz(asf(u)) : asf(u); }   // float operand
    uint32_t fout(float f) const { return asu(daz_ ? ftz(f) : f); }        // float result
    std::vector<Op> ops_;
    std::map<uint32_t, size_t> index_;
    std::vector<uint32_t> shared_;
    uint64_t steps_left_{0};

    void err(const std::string& why, const Op& op) {
        if (!error.empty()) return;
        char b[64];
        std::snprintf(b, sizeof b, "0x%04x: %s: ", op.addr, op.e ? op.e->mnemonic : "?");
        error = b + why;
    }

    void run_group(uint32_t gx, uint32_t gy, uint32_t gz) {
        shared_.assign((d_.shared_bytes + 3) / 4, 0);
        std::vector<Inv> invs;
        const uint32_t n = d_.local_size[0] * d_.local_size[1] * d_.local_size[2];
        invs.resize(n);
        for (uint32_t i = 0; i < n; ++i) {
            Inv& v = invs[i];
            v.tid[0] = i % d_.local_size[0];
            v.tid[1] = (i / d_.local_size[0]) % d_.local_size[1];
            v.tid[2] = i / (d_.local_size[0] * d_.local_size[1]);
            v.ctaid[0] = gx; v.ctaid[1] = gy; v.ctaid[2] = gz;
            v.index = i;
            v.pc = ops_.front().addr;
            v.lmem.assign((d_.local_bytes + 3) / 4, 0);
            v.p[7] = true;
        }
        for (;;) {
            bool any_running = false;
            for (Inv& v : invs) {
                if (v.state != Inv::Run) continue;
                any_running = true;
                while (v.state == Inv::Run && error.empty()) {
                    if (steps_left_-- == 0) { error = "límite de pasos"; return; }
                    step(v);
                }
                if (!error.empty()) return;
            }
            bool waiting = false;
            for (Inv& v : invs) if (v.state == Inv::Barrier) { v.state = Inv::Run; waiting = true; }
            if (!waiting) {
                if (!any_running) return;
                bool all_done = true;
                for (Inv& v : invs) all_done = all_done && v.state == Inv::Done;
                if (all_done) return;
            }
        }
    }

    // ---- operands ----
    uint32_t R(const Inv& v, unsigned r) const { return r == 255 ? 0 : v.r[r]; }
    void W(Inv& v, unsigned r, uint32_t x) { if (r != 255) v.r[r] = x; }
    bool P(const Inv& v, unsigned p, bool neg = false) const { return (p == 7 ? true : v.p[p]) != neg; }
    void WP(Inv& v, unsigned p, bool x) { if (p != 7) v.p[p] = x; }
    uint32_t val(const Inv& v, const Op& op, size_t k) {
        if (k >= op.vals.size()) { err("falta operando", op); return 0; }
        const std::string_view t = op.vals[k];
        if (t == "REG_20") return R(v, op.f(20, 8));
        if (t == "REG_39") return R(v, op.f(39, 8));
        if (t == "C34_RZ_O14_20") return mem_.cbuf32(op.f(34, 5), op.f(20, 14) * 4);
        const uint32_t i20 = op.f(20, 19) | (op.f(56, 1) << 19);
        if (t == "S20_20") return static_cast<uint32_t>(sx(i20, 20));
        if (t == "F20_20") return i20 << 12;
        if (t == "U16_20") return op.f(20, 16);
        if (t == "U06_20") return op.f(20, 6);
        if (t == "U32_20" || t == "S32_20" || t == "F32_20") return op.f(20, 32);
        err("operando no soportado", op);
        return 0;
    }
    void cc_int(Inv& v, uint32_t r, bool c, bool o, bool x = false) {
        v.zf = (r == 0) && (!x || v.zf);
        v.sf = static_cast<int32_t>(r) < 0;
        v.cf = c;
        v.of = o;
    }
    void cc_float(Inv& v, float f) {
        v.zf = f == 0.f;
        v.sf = f < 0.f;
        v.cf = false;
        v.of = std::isnan(f);
    }
    bool fcond(unsigned c, float a, float b) {
        const bool un = std::isnan(a) || std::isnan(b);
        switch (c & 15) {
            case 0: return false;
            case 1: return a < b;
            case 2: return a == b;
            case 3: return a <= b;
            case 4: return a > b;
            case 5: return !un && a != b;
            case 6: return a >= b;
            case 7: return !un;
            case 8: return un;
            case 9: return un || a < b;
            case 10: return un || a == b;
            case 11: return un || a <= b;
            case 12: return un || a > b;
            case 13: return a != b;
            case 14: return un || a >= b;
            default: return true;
        }
    }
    bool icond(unsigned c, bool s, uint32_t a, uint32_t b) {
        const int32_t sa = static_cast<int32_t>(a), sb = static_cast<int32_t>(b);
        switch (c & 7) {
            case 0: return false;
            case 1: return s ? sa < sb : a < b;
            case 2: return a == b;
            case 3: return s ? sa <= sb : a <= b;
            case 4: return s ? sa > sb : a > b;
            case 5: return a != b;
            case 6: return s ? sa >= sb : a >= b;
            default: return true;
        }
    }
    bool icond_x(const Inv& v, unsigned c, bool s, uint32_t a, uint32_t b) {
        const bool eq = a == b;
        const bool lt = s ? static_cast<int32_t>(a) < static_cast<int32_t>(b) : a < b;
        const bool gt = s ? static_cast<int32_t>(a) > static_cast<int32_t>(b) : a > b;
        switch (c & 7) {
            case 0: return false;
            case 1: return lt || (eq && !v.cf);
            case 2: return eq && v.zf;
            case 3: return lt || (eq && (!v.cf || v.zf));
            case 4: return gt || (eq && v.cf && !v.zf);
            case 5: return !(eq && v.zf);
            case 6: return gt || (eq && v.cf);
            default: return true;
        }
    }
    static bool bop(unsigned o, bool a, bool b) {
        switch (o & 3) { case 1: return a || b; case 2: return a != b; default: return a && b; }
    }
    bool cc_test(const Inv& v, const Op& op, unsigned c) {
        if (c == 15) return true;
        if (c == 0) return false;
        const bool lt = v.sf != v.of;
        switch (c) {
            case 1: case 9: return lt && !v.zf;
            case 2: case 10: return v.zf;
            case 3: case 11: return lt || v.zf;
            case 4: case 12: return !lt && !v.zf;
            case 5: case 13: return !v.zf;
            case 6: case 14: return !lt || v.zf;
            default: err("condición CC no soportada", op); return false;
        }
    }
    uint32_t sysreg(const Inv& v, const Op& op, unsigned s) {
        const uint32_t lane = v.index & 31;
        switch (s) {
            case 0x00: return lane;
            case 0x20: return v.tid[0] | (v.tid[1] << 16) | (v.tid[2] << 26);
            case 0x21: case 0x22: case 0x23: return v.tid[s - 0x21];
            case 0x25: case 0x26: case 0x27: return v.ctaid[s - 0x25];
            case 0x28: return d_.local_size[0] | (d_.local_size[1] << 16) | (d_.local_size[2] << 26);
            case 0x32: return d_.shared_bytes;
            case 0x38: return 1u << lane;
            case 0x39: return (1u << lane) - 1;
            case 0x3a: return lane == 31 ? ~0u : (2u << lane) - 1;
            case 0x3b: return lane == 31 ? 0u : ~((2u << lane) - 1);
            case 0x3c: return ~((1u << lane) - 1);
            case 0x01: case 0x50: case 0x51: case 0x52: case 0x53: return 0;
            default: err("registro de sistema no soportado", op); return 0;
        }
    }
    // ---- memory ----
    uint32_t* shared_word(uint32_t addr) {
        const uint32_t i = addr >> 2;
        static uint32_t dummy;
        return i < shared_.size() ? &shared_[i] : &(dummy = 0);
    }
    uint32_t* local_word(Inv& v, uint32_t addr) {
        const uint32_t i = addr >> 2;
        static uint32_t dummy;
        return i < v.lmem.size() ? &v.lmem[i] : &(dummy = 0);
    }
    uint32_t gread(uint64_t a) {
        const uint32_t* p = mem_.global_word(a);
        return p ? *p : 0;
    }
    void gwrite(uint64_t a, uint32_t val, uint32_t mask) {
        uint32_t* p = mem_.global_word(a);
        if (p) *p = (*p & ~mask) | (val & mask);
    }
    static uint32_t sized(uint32_t w, uint32_t addr, unsigned size) {
        const unsigned sh = (size >= 2 ? (addr & 2) : (addr & 3)) * 8;
        const uint32_t v = w >> sh;
        switch (size) {
            case 0: return v & 0xff;
            case 1: return static_cast<uint32_t>(static_cast<int8_t>(v & 0xff));
            case 2: return v & 0xffff;
            default: return static_cast<uint32_t>(static_cast<int16_t>(v & 0xffff));
        }
    }
    template <class Rd> void load_n(Inv& v, unsigned dst, unsigned size, uint64_t addr, Rd rd) {
        if (size <= 3) { W(v, dst, sized(rd(addr & ~3ull), static_cast<uint32_t>(addr), size)); return; }
        const unsigned n = size == 4 ? 1 : size == 5 ? 2 : 4;
        uint32_t tmp[4];
        for (unsigned i = 0; i < n; ++i) tmp[i] = rd(addr + 4 * i);
        if (dst != 255) for (unsigned i = 0; i < n; ++i) W(v, dst + i, tmp[i]);
    }

    void step(Inv& v);
    void exec(Inv& v, const Op& op);
    void flow(Inv& v, const Op& op, uint32_t& next);
};

void Machine::step(Inv& v) {
    auto it = index_.find(v.pc);
    if (it == index_.end()) { v.state = Inv::Done; return; }
    const Op& op = ops_[it->second];
    uint32_t next = it->second + 1 < ops_.size() ? ops_[it->second + 1].addr : 0xffffffffu;
    const std::string_view n = op.e->mnemonic;
    const bool is_flow = n == "bra" || n == "brx" || n == "jmp" || n == "jmx" || n == "sync" || n == "brk" ||
                         n == "cont" || n == "exit" || n == "kil" || n == "ret" || n == "cal" || n == "jcal" ||
                         n == "ssy" || n == "pbk" || n == "pcnt" || n == "pret";
    const bool guard = op.e->predicated ? P(v, op.f(16, 3), op.b(19)) : true;
    if (guard) {
        if (is_flow) flow(v, op, next);
        else exec(v, op);
    }
    if (v.state == Inv::Done) return;
    v.pc = next;
    if (next == 0xffffffffu) v.state = Inv::Done;
}

void Machine::flow(Inv& v, const Op& op, uint32_t& next) {
    const std::string_view n = op.e->mnemonic;
    if (op.has("C36_RZ_S16_20") || op.has("C36_08_S16_20")) { err("destino en constbuffer", op); return; }
    const uint32_t btarg = norm(static_cast<uint32_t>(static_cast<int64_t>(op.addr) + 8 + sx(op.f(20, 24), 24)));
    const bool cc_ok = op.has("T(f0f8_0)") ? cc_test(v, op, op.f(0, 5)) : true;
    auto pop_to = [&](uint32_t kind) -> uint32_t {
        while (!v.crs.empty()) {
            const uint32_t e = v.crs.back();
            v.crs.pop_back();
            if ((e >> 30) == kind) return e & 0x3fffffff;
        }
        return 0xffffffffu;
    };
    if (n == "ssy") v.crs.push_back(btarg);
    else if (n == "pbk") v.crs.push_back(btarg | (1u << 30));
    else if (n == "pcnt") v.crs.push_back(btarg | (2u << 30));
    else if (n == "pret") v.crs.push_back(btarg | (3u << 30));
    else if (n == "bra") { if (cc_ok) next = btarg; }
    else if (n == "jmp") { if (cc_ok) next = norm(op.f(20, 32)); }
    else if (n == "brx" || n == "jmx") {
        if (cc_ok) {
            const uint32_t t = n == "brx" ? R(v, op.f(8, 8)) + static_cast<uint32_t>(static_cast<int64_t>(op.addr) + 8 + sx(op.f(20, 24), 24))
                                          : R(v, op.f(8, 8)) + op.f(20, 32);
            next = norm(t);
        }
    } else if (n == "cal" || n == "jcal") {
        v.crs.push_back((op.addr + 8) | (3u << 30));
        next = n == "cal" ? btarg : norm(op.f(20, 32));
    } else if (n == "sync") { if (cc_ok) next = pop_to(0); }
    else if (n == "brk") { if (cc_ok) next = pop_to(1); }
    else if (n == "cont") { if (cc_ok) next = pop_to(2); }
    else if (n == "ret") { if (cc_ok) next = pop_to(3); }
    else if (n == "exit" || n == "kil") { if (cc_ok) { v.state = Inv::Done; } }
    if (v.crs.size() > 64) v.crs.erase(v.crs.begin());
}

void Machine::exec(Inv& v, const Op& op) {
    const std::string_view n = op.e->mnemonic;
    const unsigned dst = op.f(0, 8);
    const uint32_t A = R(v, op.f(8, 8));
    const uint32_t top = static_cast<uint32_t>(op.e->value >> 48);
    auto add3 = [&](uint32_t a, uint32_t b, uint32_t cin, bool& carry) {
        const uint64_t s = uint64_t{a} + b + cin;
        carry = (s >> 32) != 0;
        return static_cast<uint32_t>(s);
    };
    auto ovf = [](uint32_t a, uint32_t b, uint32_t r) { return static_cast<int32_t>((a ^ r) & (b ^ r)) < 0; };
    auto mulhi = [](uint32_t a, uint32_t b, bool sa, bool sb) {
        if (!sa && !sb) return static_cast<uint32_t>((uint64_t{a} * b) >> 32);
        // at least one signed 32-bit operand: |product| <= (2^32 - 1) * 2^31 < 2^63 fits in int64
        const int64_t x = sa ? int64_t{static_cast<int32_t>(a)} : int64_t{a};
        const int64_t y = sb ? int64_t{static_cast<int32_t>(b)} : int64_t{b};
        return static_cast<uint32_t>(static_cast<uint64_t>(x * y) >> 32);
    };
    if (n == "mov") { W(v, dst, op.has("SYS_20") ? sysreg(v, op, op.f(20, 8)) : val(v, op, 0)); return; }
    if (n == "mov32i") { W(v, dst, op.f(20, 32)); return; }
    if (n == "cs2r") { W(v, dst, sysreg(v, op, op.f(20, 8))); return; }
    if (n == "sel") { W(v, dst, P(v, op.f(39, 3), op.b(42)) ? A : val(v, op, 0)); return; }
    if (n == "iadd" || n == "iadd32i") {
        const bool i32 = n == "iadd32i";
        const bool po = op.e->value == 0x1d80000000000000ull;
        const bool na = i32 ? (!po && op.b(56)) : op.b(49), nb = i32 ? false : op.b(48);
        const bool sat = i32 ? op.b(54) : op.b(50), x = i32 ? op.b(53) : op.b(43), cc = i32 ? op.b(52) : op.b(47);
        const uint32_t a = na ? ~A : A;
        const uint32_t bb0 = i32 ? op.f(20, 32) : val(v, op, 0);
        const uint32_t b = nb ? ~bb0 : bb0;
        const uint32_t cin = x ? (v.cf ? 1 : 0) : (na ? 1 : 0) + (nb ? 1 : 0) + (po ? 1 : 0);
        bool c;
        uint32_t r = add3(a, b, cin, c);
        const bool o = ovf(a, b, r);
        if (sat && o) r = (static_cast<int32_t>(a) < 0) ? 0x80000000u : 0x7fffffffu;
        if (cc) cc_int(v, r, c, o, x);
        W(v, dst, r);
        return;
    }
    if (n == "iadd3") {
        const bool regf = top == 0x5cc0;
        uint32_t a = A, b = val(v, op, 0), c = val(v, op, 1);
        unsigned mode = 0;
        if (regf) {
            mode = op.f(37, 2);
            auto h = [](uint32_t x, unsigned s) { return s == 1 ? (x & 0xffff) : s == 2 ? (x >> 16) : x; };
            a = h(a, op.f(35, 2)); b = h(b, op.f(33, 2)); c = h(c, op.f(31, 2));
        }
        const bool na = op.b(51), nb = op.b(50), nc = op.b(49), x = op.b(48);
        if (na) a = ~a;
        if (nb) b = ~b;
        if (nc) c = ~c;
        uint64_t ab = uint64_t{a} + b;
        bool carry = (ab >> 32) != 0;
        uint32_t t = static_cast<uint32_t>(ab);
        if (mode == 1) { t >>= 16; carry = false; }
        if (mode == 2) { t <<= 16; carry = false; }
        const uint64_t s = uint64_t{t} + c + (x ? (v.cf ? 1 : 0) : (na + nb + nc));
        carry = carry || (s >> 32) != 0;
        const uint32_t r = static_cast<uint32_t>(s);
        if (op.b(47)) cc_int(v, r, carry, false, x);
        W(v, dst, r);
        return;
    }
    if (n == "iscadd" || n == "iscadd32i") {
        const bool i32 = n == "iscadd32i";
        uint32_t a = A, b = val(v, op, 0);
        if (!i32) { if (op.b(49)) a = 0u - a; if (op.b(48)) b = 0u - b; }
        const uint32_t sa = a << (i32 ? op.f(53, 5) : op.f(39, 5));
        const uint32_t r = sa + b;
        if (i32 ? op.b(52) : op.b(47)) cc_int(v, r, r < sa, false);
        W(v, dst, r);
        return;
    }
    if (n == "lea") {
        const bool hi = op.has("N(\"hi\")");
        uint32_t r;
        bool carry;
        if (!hi) {
            const uint32_t a = op.b(45) ? 0u - A : A;
            r = add3(a << op.f(39, 5), val(v, op, 0), op.b(46) ? (v.cf ? 1 : 0) : 0, carry);
        } else {
            const bool regf = top == 0x5bd8;
            if (regf ? op.b(37) : op.b(56)) { err("LEA.HI neg", op); return; }
            const unsigned s = regf ? op.f(28, 5) : op.f(51, 5);
            const uint32_t b = val(v, op, 0), c = val(v, op, 1);
            const uint32_t h = s == 0 ? c : (c << s) | (A >> (32 - s));
            r = add3(h, b, (regf ? op.b(38) : op.b(57)) ? (v.cf ? 1 : 0) : 0, carry);
        }
        if (op.b(47)) cc_int(v, r, carry, false);
        WP(v, op.f(48, 3), carry);
        W(v, dst, r);
        return;
    }
    if (n == "imad" || n == "imad32i") {
        const bool i32 = n == "imad32i";
        const uint32_t b = val(v, op, 0);
        uint32_t c = i32 ? R(v, dst) : val(v, op, 1);
        const bool sa = i32 ? op.b(54) : op.b(48), sb = i32 ? op.b(57) : op.b(53);
        const bool hi = i32 ? op.b(53) : op.b(54);
        const bool nab = i32 ? op.b(56) : op.b(52), nc = i32 ? op.b(55) : op.b(51);
        const bool sat = !i32 && op.b(50), x = !i32 && op.b(49), cc = i32 ? op.b(52) : op.b(47);
        uint32_t p = hi ? mulhi(A, b, sa, sb) : A * b;
        if (nab) p = 0u - p;
        if (nc) c = 0u - c;
        bool carry;
        uint32_t r = add3(p, c, x ? (v.cf ? 1 : 0) : 0, carry);
        const bool o = ovf(p, c, r);
        if (sat && o) r = static_cast<int32_t>(p) < 0 ? 0x80000000u : 0x7fffffffu;
        if (cc) cc_int(v, r, carry, o, x);
        W(v, dst, r);
        return;
    }
    if (n == "imul" || n == "imul32i") {
        const bool i32 = n == "imul32i";
        const uint32_t b = val(v, op, 0);
        const bool sa = i32 ? op.b(54) : op.b(40), sb = i32 ? op.b(55) : op.b(41), hi = i32 ? op.b(53) : op.b(39);
        const uint32_t r = hi ? mulhi(A, b, sa, sb) : A * b;
        if (i32 ? op.b(52) : op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "xmad") {
        const bool regf = top == 0x5b00, immf = top == 0x3600, cbb = top == 0x4e00;
        bool psl = false, mrg = false, x, h1b = false;
        unsigned cm;
        if (regf || immf) { psl = op.b(36); mrg = op.b(37); cm = op.f(50, 3); x = op.b(38); if (regf) h1b = op.b(35); }
        else { cm = op.f(50, 2); x = op.b(54); h1b = op.b(52); if (cbb) { psl = op.b(55); mrg = op.b(56); } }
        const bool sa = op.b(48), sb = op.b(49), h1a = op.b(53);
        const uint32_t B = val(v, op, 0), C = val(v, op, 1);
        auto h16 = [](uint32_t x16, bool h1, bool s) -> uint32_t {
            const uint32_t q = h1 ? x16 >> 16 : x16 & 0xffff;
            return s ? static_cast<uint32_t>(static_cast<int32_t>(static_cast<int16_t>(q))) : q;
        };
        const uint32_t a16 = h16(A, h1a, sa), b16 = h16(B, immf ? false : h1b, sb);
        uint32_t prod = a16 * b16;
        if (psl) prod <<= 16;
        uint32_t c = C;
        if (cm == 1) c = C & 0xffff;
        else if (cm == 2) c = C >> 16;
        else if (cm == 3) {
            uint32_t adj = 0;
            if (sa && static_cast<int32_t>(a16) < 0) adj += 0x10000;
            if (sb && static_cast<int32_t>(b16) < 0) adj += 0x10000;
            if (a16 != 0 && b16 != 0) c = C - adj;
        } else if (cm == 4) c = C + (B << 16);
        else if (cm != 0) { err("XMAD cmode", op); return; }
        bool carry;
        uint32_t r = add3(prod, c, x ? (v.cf ? 1 : 0) : 0, carry);
        if (mrg) r = (r & 0xffff) | (B << 16);
        if (op.b(47)) cc_int(v, r, carry, false, x);
        W(v, dst, r);
        return;
    }
    if (n == "imnmx") {
        if (op.f(43, 2)) { err("IMNMX extendido", op); return; }
        const uint32_t b = val(v, op, 0);
        const bool s = op.b(48);
        const bool lt = s ? static_cast<int32_t>(A) < static_cast<int32_t>(b) : A < b;
        const uint32_t mn = lt ? A : b, mx = lt ? b : A;
        const uint32_t r = P(v, op.f(39, 3), op.b(42)) ? mn : mx;
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "lop" || n == "lop32i") {
        const bool i32 = n == "lop32i";
        uint32_t a = A, b = i32 ? op.f(20, 32) : val(v, op, 0);
        if (i32 ? op.b(55) : op.b(39)) a = ~a;
        if (i32 ? op.b(56) : op.b(40)) b = ~b;
        const unsigned l = i32 ? op.f(53, 2) : op.f(41, 2);
        const uint32_t r = l == 0 ? (a & b) : l == 1 ? (a | b) : l == 2 ? (a ^ b) : b;
        if (!i32) {
            const unsigned pm = op.f(44, 2);
            WP(v, op.f(48, 3), pm == 1 ? true : pm == 2 ? r == 0 : pm == 3 ? r != 0 : false);
        }
        if (i32 ? op.b(52) : op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "lop3") {
        const bool regf = top == 0x5be0;
        const bool immf = (op.e->value >> 58) == (0x3c00ull >> 10);
        const unsigned lut = regf ? op.f(28, 8) : op.f(48, 8);
        const uint32_t b = val(v, op, 0), c = immf ? R(v, op.f(39, 8)) : val(v, op, 1);
        uint32_t r = 0;
        for (unsigned bitn = 0; bitn < 32; ++bitn) {
            const unsigned idx = (((A >> bitn) & 1) << 2) | (((b >> bitn) & 1) << 1) | ((c >> bitn) & 1);
            r |= ((lut >> idx) & 1u) << bitn;
        }
        if (regf) {
            const unsigned pm = op.f(36, 2);
            WP(v, op.f(48, 3), pm == 1 ? true : pm == 2 ? r == 0 : pm == 3 ? r != 0 : false);
        }
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "shl" || n == "shr") {
        uint32_t a = A;
        const uint32_t s = val(v, op, 0);
        const bool wrap = op.b(39);
        uint32_t r;
        if (n == "shl") r = wrap ? a << (s & 31) : (s >= 32 ? 0 : a << s);
        else {
            if (op.b(40)) { uint32_t q = 0; for (int k = 0; k < 32; ++k) q |= ((a >> k) & 1) << (31 - k); a = q; }
            const bool sg = op.b(48);
            const uint32_t se = wrap ? (s & 31) : std::min<uint32_t>(s, sg ? 31 : 32);
            r = sg ? static_cast<uint32_t>(static_cast<int32_t>(a) >> se) : (se >= 32 ? 0 : a >> se);
        }
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "shf") {
        const bool left = op.has("N(\"l\")");
        const unsigned type = op.f(37, 2);
        const bool is64 = type >= 2, sg = type == 3;
        uint32_t s = val(v, op, 0);
        s = op.b(50) ? (s & (is64 ? 63 : 31)) : std::min<uint32_t>(s, is64 ? 64 : 32);
        const uint64_t pair = (uint64_t{R(v, op.f(39, 8))} << 32) | A;
        uint64_t res;
        if (left) res = s >= 64 ? 0 : pair << s;
        else if (sg) res = static_cast<uint64_t>(static_cast<int64_t>(pair) >> std::min<uint32_t>(s, 63));
        else res = s >= 64 ? 0 : pair >> s;
        const uint32_t r = op.b(48) ? static_cast<uint32_t>(res >> 32) : static_cast<uint32_t>(res);
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "popc") { W(v, dst, static_cast<uint32_t>(std::popcount(op.b(40) ? ~val(v, op, 0) : val(v, op, 0)))); return; }
    if (n == "flo") {
        uint32_t x = val(v, op, 0);
        if (op.b(40)) x = ~x;
        const bool sg = op.b(48);
        uint32_t q = sg && static_cast<int32_t>(x) < 0 ? ~x : x;
        uint32_t r = q == 0 ? 0xffffffffu : 31u - static_cast<uint32_t>(std::countl_zero(q));
        if (op.b(41) && r != 0xffffffffu) r = 31 - r;
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "bfe") {
        uint32_t a = A;
        if (op.b(40)) { uint32_t q = 0; for (int k = 0; k < 32; ++k) q |= ((a >> k) & 1) << (31 - k); a = q; }
        const uint32_t bb = val(v, op, 0), pos = bb & 0xff, len = (bb >> 8) & 0xff;
        const bool sg = op.b(48);
        uint32_t r;
        if (len == 0) r = 0;
        else if (pos >= 32) r = sg ? static_cast<uint32_t>(static_cast<int32_t>(a) >> 31) : 0;
        else {
            const uint32_t n2 = std::min<uint32_t>(len, 32 - pos);
            const uint64_t raw = (uint64_t{a} >> pos) & ((n2 == 32) ? 0xffffffffull : ((1ull << n2) - 1));
            r = static_cast<uint32_t>(raw);
            if (sg) {
                if (pos + n2 >= 32) r = static_cast<uint32_t>(static_cast<int32_t>(a) >> pos);
                else r = static_cast<uint32_t>(sx(r, n2));
            }
        }
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "bfi") {
        const uint32_t bb = val(v, op, 0), base = val(v, op, 1), pos = bb & 0xff, len = (bb >> 8) & 0xff;
        uint32_t r = base;
        if (pos < 32) {
            const uint32_t n2 = std::min<uint32_t>(len, 32 - pos);
            const uint32_t mask = static_cast<uint32_t>(((n2 >= 32) ? 0xffffffffull : ((1ull << n2) - 1)) << pos);
            r = (base & ~mask) | ((A << pos) & mask);
        }
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "prmt") {
        const uint32_t sel = val(v, op, 0), C = val(v, op, 1);
        const unsigned mode = op.f(48, 4);
        const uint64_t pair = (uint64_t{C} << 32) | A;
        auto byte = [&](unsigned i) { return static_cast<uint32_t>((pair >> (8 * (i & 7))) & 0xff); };
        uint32_t r = 0;
        const unsigned s = sel & 3;
        for (unsigned i = 0; i < 4; ++i) {
            uint32_t by;
            switch (mode) {
                case 0: {
                    const unsigned nib = (sel >> (4 * i)) & 0xf;
                    by = byte(nib);
                    if (nib & 8) by = (by & 0x80) ? 0xff : 0;
                    break;
                }
                case 1: by = byte(s + i); break;
                case 2: by = byte((s - i) & 7); break;
                case 3: by = byte(s); break;
                case 4: by = byte(std::max(s, i)); break;
                case 5: by = byte(std::min(s, i)); break;
                case 6: by = byte(((s & 1) << 1) + (i & 1)); break;
                default: err("PRMT modo", op); return;
            }
            r |= by << (8 * i);
        }
        W(v, dst, r);
        return;
    }
    if (n == "isetp" || n == "iset" || n == "icmp") {
        const unsigned c = op.f(49, 3);
        const bool s = op.b(48);
        if (n == "icmp") {
            const uint32_t b = val(v, op, 0), cc2 = val(v, op, 1);
            W(v, dst, icond(c, s, cc2, 0) ? A : b);
            return;
        }
        const uint32_t b = val(v, op, 0);
        const bool t = op.b(43) ? icond_x(v, c, s, A, b) : icond(c, s, A, b);
        const bool p = P(v, op.f(39, 3), op.b(42));
        const unsigned bo = op.f(45, 2);
        if (n == "isetp") { WP(v, op.f(3, 3), bop(bo, t, p)); WP(v, op.f(0, 3), bop(bo, !t, p)); return; }
        const uint32_t r = bop(bo, t, p) ? (op.b(44) ? 0x3f800000u : 0xffffffffu) : 0;
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    // ---- float ----
    if (n == "fadd" || n == "fadd32i") {
        const bool i32 = n == "fadd32i";
        float a = fin(A), b = fin(i32 ? op.f(20, 32) : val(v, op, 0));
        const bool z = i32 ? op.b(55) : op.b(44);
        if (z) { a = ftz(a); b = ftz(b); }
        a = i32 ? fna(a, op.b(56), op.b(54)) : fna(a, op.b(48), op.b(46));
        b = i32 ? fna(b, op.b(53), op.b(57)) : fna(b, op.b(45), op.b(49));
        float r = a + b;
        if (z) r = ftz(r);
        if (!i32 && op.b(50)) r = fsat(r);
        if (i32 ? op.b(52) : op.b(47)) cc_float(v, r);
        W(v, dst, fout(r));
        return;
    }
    if (n == "fmul" || n == "fmul32i") {
        const bool i32 = n == "fmul32i";
        float a = fin(A), b = fin(i32 ? op.f(20, 32) : val(v, op, 0));
        const unsigned fz = i32 ? op.f(53, 2) : op.f(44, 2);
        if (fz) { a = ftz(a); b = ftz(b); }
        if (!i32 && op.b(48)) b = -b;
        float r = a * b;
        static const float sc[8] = {1.f, 0.5f, 0.25f, 0.125f, 8.f, 4.f, 2.f, 1.f};
        if (!i32 && op.f(41, 3)) r *= sc[op.f(41, 3)];
        if (fz == 2 && (a == 0.f || b == 0.f)) r = 0.f;
        if (fz) r = ftz(r);
        if (i32 ? op.b(55) : op.b(50)) r = fsat(r);
        if (i32 ? op.b(52) : op.b(47)) cc_float(v, r);
        W(v, dst, fout(r));
        return;
    }
    if (n == "ffma" || n == "ffma32i") {
        const bool i32 = n == "ffma32i";
        float a = fin(A), b = fin(i32 ? op.f(20, 32) : val(v, op, 0)), c = fin(i32 ? R(v, dst) : val(v, op, 1));
        const unsigned fz = op.f(53, 2);
        if (fz) { a = ftz(a); b = ftz(b); c = ftz(c); }
        if (i32 ? op.b(56) : op.b(48)) b = -b;
        if (i32 ? op.b(57) : op.b(49)) c = -c;
        float r = d_.unfused_fma ? (a * b + c) : std::fma(a, b, c);
        if (fz == 2 && (a == 0.f || b == 0.f)) r = 0.f + c;
        if (fz) r = ftz(r);
        if (i32 ? op.b(55) : op.b(50)) r = fsat(r);
        if (i32 ? op.b(52) : op.b(47)) cc_float(v, r);
        W(v, dst, fout(r));
        return;
    }
    if (n == "fmnmx") {
        float a = fin(A), b = fin(val(v, op, 0));
        if (op.b(44)) { a = ftz(a); b = ftz(b); }
        a = fna(a, op.b(48), op.b(46));
        b = fna(b, op.b(45), op.b(49));
        float r;
        if (std::isnan(a)) r = b;
        else if (std::isnan(b)) r = a;
        else r = P(v, op.f(39, 3), op.b(42)) ? std::fmin(a, b) : std::fmax(a, b);
        if (op.b(47)) cc_float(v, r);
        W(v, dst, fout(r));
        return;
    }
    if (n == "fsetp" || n == "fset" || n == "fcmp") {
        const unsigned c = op.f(48, 4);
        if (n == "fcmp") {
            const uint32_t b = val(v, op, 0);
            float cv = fin(val(v, op, 1));
            if (op.b(47)) cv = ftz(cv);
            W(v, dst, fcond(c, cv, 0.f) ? A : b);
            return;
        }
        float a = fin(A), b = fin(val(v, op, 0));
        const bool set = n == "fset";
        if (set ? op.b(55) : op.b(47)) { a = ftz(a); b = ftz(b); }
        if (set) { a = fna(a, op.b(43), op.b(54)); b = fna(b, op.b(53), op.b(44)); }
        else { a = fna(a, op.b(43), op.b(7)); b = fna(b, op.b(6), op.b(44)); }
        const bool t = fcond(c, a, b);
        const bool p = P(v, op.f(39, 3), op.b(42));
        const unsigned bo = op.f(45, 2);
        if (!set) { WP(v, op.f(3, 3), bop(bo, t, p)); WP(v, op.f(0, 3), bop(bo, !t, p)); return; }
        const uint32_t r = bop(bo, t, p) ? (op.b(52) ? 0x3f800000u : 0xffffffffu) : 0;
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "mufu") {
        // model: FTZ in and out, explicit special cases, SIN/COS on the argument reduced to [-pi, pi]
        const float a = ftz(fna(fin(A), op.b(48), op.b(46)));
        const float nan = asf(0x7fffffffu), inf = std::numeric_limits<float>::infinity();
        float r;
        switch (op.f(20, 4)) {
            case 0: case 1: {
                const float two_pi = 6.28318530717958647692f, inv_two_pi = 0.159154943091895335769f;
                const float y = a * inv_two_pi;
                const float red = (y - std::nearbyint(y)) * two_pi;
                r = (std::isnan(a) || std::isinf(a)) ? nan : (op.f(20, 4) == 0 ? std::cos(red) : std::sin(red));
                break;
            }
            case 2: r = std::isnan(a) ? nan : std::exp2(a); break;
            case 3: r = (std::isnan(a) || a < 0.f) ? nan : a == 0.f ? -inf : std::log2(a); break;
            case 4: r = std::isnan(a) ? nan : a == 0.f ? std::copysign(inf, a) : std::isinf(a) ? std::copysign(0.f, a) : 1.f / a; break;
            case 5: r = (std::isnan(a) || (a < 0.f)) ? nan : a == 0.f ? std::copysign(inf, a) : std::isinf(a) ? 0.f : 1.f / std::sqrt(a); break;
            case 8: r = (std::isnan(a) || (a < 0.f)) ? nan : (a == 0.f || std::isinf(a)) ? a : std::sqrt(a); break;
            default: err("MUFU no soportado", op); return;
        }
        r = ftz(r);
        if (op.b(50)) r = fsat(r);
        W(v, dst, asu(r));
        return;
    }
    if (n == "rro") { W(v, dst, asu(fna(fin(val(v, op, 0)), op.b(45), op.b(49)))); return; }
    if (n == "f2f") {
        const unsigned dt = op.f(8, 2), st = op.f(10, 2), mode = op.f(39, 2);
        if (dt == 3 || st == 3 || dt == 0 || st == 0) { err("F2F f64", op); return; }
        const uint32_t x = val(v, op, 0);
        float f;
        if (st == 1) {
            const uint32_t h = op.b(41) ? x >> 16 : x & 0xffff;
            // half -> float
            const uint32_t s = (h >> 15) & 1, e = (h >> 10) & 0x1f, m = h & 0x3ff;
            if (e == 0) f = std::ldexp(static_cast<float>(m), -24);
            else if (e == 31) f = m ? std::numeric_limits<float>::quiet_NaN() : std::numeric_limits<float>::infinity();
            else f = std::ldexp(static_cast<float>(m | 0x400), static_cast<int>(e) - 25);
            if (s) f = -f;
        } else f = fin(x);
        if (op.b(44)) f = ftz(f);
        f = fna(f, op.b(45), op.b(49));
        if (op.b(42)) {
            switch (mode) {
                case 0: f = std::nearbyint(f); break;
                case 1: f = std::floor(f); break;
                case 2: f = std::ceil(f); break;
                default: f = std::trunc(f); break;
            }
        }
        if (op.b(50)) f = fsat(f);
        if (op.b(44)) f = ftz(f);
        uint32_t r;
        if (dt == 1) {
            // float -> half, round to nearest even
            const uint32_t u = asu(f), s = (u >> 16) & 0x8000;
            const int e = static_cast<int>((u >> 23) & 0xff) - 127 + 15;
            uint32_t m = u & 0x7fffff;
            if (std::isnan(f)) r = 0x7fff;
            else if (e >= 31) r = s | 0x7c00;
            else if (e <= 0) {
                if (e < -10) r = s;
                else {
                    m |= 0x800000;
                    const unsigned shift = static_cast<unsigned>(14 - e);
                    uint32_t hm = m >> shift;
                    const uint32_t rem = m & ((1u << shift) - 1), half = 1u << (shift - 1);
                    if (rem > half || (rem == half && (hm & 1))) ++hm;
                    r = s | hm;
                }
            } else {
                uint32_t hm = m >> 13;
                const uint32_t rem = m & 0x1fff;
                uint32_t he = static_cast<uint32_t>(e);
                if (rem > 0x1000 || (rem == 0x1000 && (hm & 1))) { ++hm; if (hm == 0x400) { hm = 0; ++he; } }
                r = he >= 31 ? (s | 0x7c00) : (s | (he << 10) | hm);
            }
        } else r = asu(f);
        if (op.b(47)) cc_float(v, f);
        W(v, dst, r);
        return;
    }
    if (n == "f2i") {
        const unsigned isz = op.f(8, 2), st = op.f(10, 2);
        if (isz == 3 || st != 2) { err("F2I 64/no f32", op); return; }
        float f = fin(val(v, op, 0));
        if (op.b(44)) f = ftz(f);
        f = fna(f, op.b(45), op.b(49));
        switch (op.f(39, 2)) {
            case 0: f = std::nearbyint(f); break;
            case 1: f = std::floor(f); break;
            case 2: f = std::ceil(f); break;
            default: f = std::trunc(f); break;
        }
        const bool sg = op.b(12);
        const unsigned w = isz == 0 ? 8 : isz == 1 ? 16 : 32;
        const double lo = sg ? -std::ldexp(1.0, static_cast<int>(w) - 1) : 0.0;
        const double hi = sg ? std::ldexp(1.0, static_cast<int>(w) - 1) - 1 : std::ldexp(1.0, static_cast<int>(w)) - 1;
        uint32_t r;
        if (std::isnan(f)) r = 0;
        else {
            const double c = std::min(std::max(static_cast<double>(f), lo), hi);
            r = sg ? static_cast<uint32_t>(static_cast<int64_t>(c)) : static_cast<uint32_t>(static_cast<uint64_t>(c));
        }
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "i2f") {
        const unsigned dt = op.f(8, 2), isz = op.f(10, 2);
        const bool sg = op.b(13);
        if (dt == 3 || dt == 0 || isz == 3) { err("I2F 64", op); return; }
        uint32_t x = val(v, op, 0);
        const unsigned bs = op.f(41, 2);
        if (isz == 0) x = sg ? static_cast<uint32_t>(static_cast<int8_t>((x >> (8 * bs)) & 0xff)) : (x >> (8 * bs)) & 0xff;
        else if (isz == 1) x = sg ? static_cast<uint32_t>(static_cast<int16_t>((x >> (8 * (bs & 2))) & 0xffff)) : (x >> (8 * (bs & 2))) & 0xffff;
        if (op.b(49) && sg && static_cast<int32_t>(x) < 0) x = 0u - x;
        if (op.b(45)) x = 0u - x;
        const float f = sg ? static_cast<float>(static_cast<int32_t>(x)) : static_cast<float>(x);
        uint32_t r = asu(f);
        if (dt == 1) {   // f32 -> f16, round to nearest even (integers: never NaN or denormal)
            const uint32_t u = asu(f), s = (u >> 16) & 0x8000;
            const int e = static_cast<int>((u >> 23) & 0xff) - 127 + 15;
            uint32_t m = u & 0x7fffff;
            if (f == 0.f) r = s;
            else if (e >= 31) r = s | 0x7c00;
            else {
                uint32_t hm = m >> 13;
                const uint32_t rem = m & 0x1fff;
                uint32_t he = static_cast<uint32_t>(e);
                if (rem > 0x1000 || (rem == 0x1000 && (hm & 1))) { ++hm; if (hm == 0x400) { hm = 0; ++he; } }
                r = he >= 31 ? (s | 0x7c00) : (s | (he << 10) | hm);
            }
        }
        if (op.b(47)) cc_float(v, f);
        W(v, dst, r);
        return;
    }
    if (n == "i2i") {
        const unsigned dsz = op.f(8, 2), ssz = op.f(10, 2);
        const bool dsg = op.b(12), ssg = op.b(13);
        if (dsz == 3 || ssz == 3) { err("I2I 64", op); return; }
        uint32_t x = val(v, op, 0);
        const unsigned bs = op.f(41, 2);
        const unsigned sw = ssz == 0 ? 8 : ssz == 1 ? 16 : 32;
        if (sw == 8) x = ssg ? static_cast<uint32_t>(static_cast<int8_t>((x >> (8 * bs)) & 0xff)) : (x >> (8 * bs)) & 0xff;
        if (sw == 16) x = ssg ? static_cast<uint32_t>(static_cast<int16_t>((x >> (8 * (bs & 2))) & 0xffff)) : (x >> (8 * (bs & 2))) & 0xffff;
        if (op.b(49) && ssg && static_cast<int32_t>(x) < 0) x = 0u - x;
        if (op.b(45)) x = 0u - x;
        const unsigned dw = dsz == 0 ? 8 : dsz == 1 ? 16 : 32;
        const bool src_signed = ssg || op.b(45);
        if (op.b(50)) {
            const int64_t lo = dsg ? -(int64_t{1} << (dw - 1)) : 0;
            const int64_t hi = dsg ? (int64_t{1} << (dw - 1)) - 1 : (int64_t{1} << dw) - 1;
            int64_t q = src_signed ? int64_t{static_cast<int32_t>(x)} : int64_t{x};
            q = std::min(std::max(q, lo), hi);
            x = static_cast<uint32_t>(q);
        }
        if (dw == 8) x = dsg ? static_cast<uint32_t>(static_cast<int8_t>(x & 0xff)) : x & 0xff;
        if (dw == 16) x = dsg ? static_cast<uint32_t>(static_cast<int16_t>(x & 0xffff)) : x & 0xffff;
        if (op.b(47)) cc_int(v, x, false, false);
        W(v, dst, x);
        return;
    }
    if (n == "psetp" || n == "pset") {
        const bool a = P(v, op.f(12, 3), op.b(15)), b = P(v, op.f(29, 3), op.b(32)), c = P(v, op.f(39, 3), op.b(42));
        const bool ab = bop(op.f(24, 2), a, b);
        const unsigned b2 = op.f(45, 2);
        if (n == "psetp") { WP(v, op.f(3, 3), bop(b2, ab, c)); WP(v, op.f(0, 3), bop(b2, !ab, c)); return; }
        const uint32_t r = bop(b2, ab, c) ? (op.b(44) ? 0x3f800000u : 0xffffffffu) : 0;
        if (op.b(47)) cc_int(v, r, false, false);
        W(v, dst, r);
        return;
    }
    if (n == "p2r" || n == "r2p") {
        if (op.b(40)) { err("P2R/R2P CC", op); return; }
        const unsigned by = op.f(41, 2);
        const uint32_t mask = val(v, op, 0) & 0xff;
        if (n == "p2r") {
            uint32_t pk = 0x80;
            for (unsigned i = 0; i < 7; ++i) pk |= (v.p[i] ? 1u : 0u) << i;
            const uint32_t m = mask << (8 * by);
            W(v, dst, (A & ~m) | ((pk << (8 * by)) & m));
        } else {
            for (unsigned i = 0; i < 7; ++i)
                if (mask & (1u << i)) WP(v, i, (A >> (8 * by + i)) & 1);
        }
        return;
    }
    // ---- memory ----
    if (n == "ld" && op.has("C36_08_S16_20")) {
        if (op.f(44, 2)) { err("LDC modo", op); return; }
        const unsigned bank = op.f(36, 5);
        const uint32_t addr = A + static_cast<uint32_t>(sx(op.f(20, 16), 16));
        load_n(v, dst, op.f(48, 3), addr, [&](uint64_t a) -> uint32_t {
            return a < 0x10000 ? mem_.cbuf32(bank, static_cast<uint32_t>(a) & 0xfffc) : 0;
        });
        return;
    }
    if (op.has("SMEM") || op.has("LMEM")) {
        const bool sh = op.has("SMEM");
        const unsigned size = op.f(48, 3);
        const uint32_t addr = A + static_cast<uint32_t>(sx(op.f(20, 24), 24));
        auto word = [&](uint32_t a) { return sh ? shared_word(a) : local_word(v, a); };
        if (n == "ld") {
            load_n(v, dst, size, addr, [&](uint64_t a) { return *word(static_cast<uint32_t>(a)); });
        } else if (size <= 3) {
            const unsigned w = size >= 2 ? 16 : 8;
            const unsigned shf = (w == 16 ? (addr & 2) : (addr & 3)) * 8;
            const uint32_t m = (w == 16 ? 0xffffu : 0xffu) << shf;
            uint32_t* p = word(addr);
            *p = (*p & ~m) | ((R(v, dst) << shf) & m);
        } else {
            const unsigned cnt = size == 4 ? 1 : size == 5 ? 2 : 4;
            for (unsigned i = 0; i < cnt; ++i) *word(addr + 4 * i) = R(v, dst == 255 ? 255 : dst + i);
        }
        return;
    }
    if (n == "ldg" || n == "stg" || ((n == "ld" || n == "st") && op.has("GMEM"))) {
        const bool g = n == "ldg" || n == "stg";
        if (op.has("NCGMEM_20")) { err("LDG con predicado", op); return; }
        const bool e = g ? op.b(45) : op.b(52);
        const int64_t imm = g ? sx(op.f(20, 24), 24) : static_cast<int32_t>(op.f(20, 32));
        unsigned size = g ? op.f(48, 3) : op.f(53, 3);
        const unsigned ar = op.f(8, 8);
        const uint64_t base = (e && ar != 255) ? ((uint64_t{R(v, ar + 1)} << 32) | R(v, ar)) : uint64_t{R(v, ar)};
        const uint64_t addr = e ? base + static_cast<uint64_t>(imm) : uint64_t{static_cast<uint32_t>(base + static_cast<uint64_t>(imm))};
        if (n == "ldg" || n == "ld") {
            if (size == 7) size = 6;
            load_n(v, dst, size, addr, [&](uint64_t a) { return gread(a); });
        } else if (size <= 3) {
            const unsigned w = size >= 2 ? 16 : 8;
            const unsigned shf = static_cast<unsigned>(w == 16 ? (addr & 2) : (addr & 3)) * 8;
            const uint32_t m = (w == 16 ? 0xffffu : 0xffu) << shf;
            gwrite(addr & ~3ull, R(v, dst) << shf, m);
        } else {
            const unsigned cnt = size == 4 ? 1 : size == 5 ? 2 : 4;
            for (unsigned i = 0; i < cnt; ++i) gwrite(addr + 4 * i, R(v, dst == 255 ? 255 : dst + i), ~0u);
        }
        return;
    }
    if (n == "atoms") {
        const uint32_t addr = A + static_cast<uint32_t>(sx(op.f(30, 22), 22) * 4);
        uint32_t* p = shared_word(addr);
        const uint32_t x = R(v, op.f(20, 8));
        const uint32_t old = *p;
        if ((op.e->value >> 48) == 0xee00) {
            if (op.f(53, 2) != 2 || op.b(52)) { err("ATOMS.CAST", op); return; }
            const uint32_t nv = R(v, op.f(20, 8) == 255 ? 255 : op.f(20, 8) + 1);
            if (old == x) *p = nv;
            W(v, dst, old);
            return;
        }
        const unsigned ty = op.f(28, 2), ao = op.f(52, 4);
        if (ty >= 2) { err("ATOMS 64", op); return; }
        const bool s = ty == 1;
        switch (ao) {
            case 0: *p = old + x; break;
            case 1: *p = s ? static_cast<uint32_t>(std::min(static_cast<int32_t>(old), static_cast<int32_t>(x))) : std::min(old, x); break;
            case 2: *p = s ? static_cast<uint32_t>(std::max(static_cast<int32_t>(old), static_cast<int32_t>(x))) : std::max(old, x); break;
            case 5: *p = old & x; break;
            case 6: *p = old | x; break;
            case 7: *p = old ^ x; break;
            case 8: *p = x; break;
            default: err("ATOMS op", op); return;
        }
        W(v, dst, old);
        return;
    }
    if (n == "atom" || n == "red") {
        const bool red = n == "red";
        const bool cas = !red && (op.e->value >> 48) == 0xeef0;
        unsigned ao, ty;
        if (cas) { ao = 15; ty = op.b(49) ? 2 : 0; }
        else if (red) { ao = op.f(23, 3); ty = op.f(20, 3); }
        else { ao = op.f(52, 4); ty = op.f(49, 3); }
        if (ty > 1) { err("ATOM tipo", op); return; }
        const unsigned ar = op.f(8, 8);
        const bool e = op.b(48);
        const uint64_t base = (e && ar != 255) ? ((uint64_t{R(v, ar + 1)} << 32) | R(v, ar)) : uint64_t{R(v, ar)};
        const uint64_t addr = base + static_cast<uint64_t>(static_cast<int64_t>(sx(op.f(28, 20), 20)));
        const unsigned vr = red ? dst : op.f(20, 8);
        const uint32_t x = R(v, vr);
        uint32_t* p = mem_.global_word(e ? addr : (addr & 0xffffffffull));
        const uint32_t old = p ? *p : 0;
        const bool s = ty == 1;
        if (p) {
            switch (ao) {
                case 0: *p = old + x; break;
                case 1: *p = s ? static_cast<uint32_t>(std::min(static_cast<int32_t>(old), static_cast<int32_t>(x))) : std::min(old, x); break;
                case 2: *p = s ? static_cast<uint32_t>(std::max(static_cast<int32_t>(old), static_cast<int32_t>(x))) : std::max(old, x); break;
                case 3: *p = old >= x ? 0 : old + 1; break;
                case 4: *p = (old == 0 || old > x) ? x : old - 1; break;
                case 5: *p = old & x; break;
                case 6: *p = old | x; break;
                case 7: *p = old ^ x; break;
                case 8: *p = x; break;
                case 15: if (old == x) *p = R(v, vr == 255 ? 255 : vr + 1); break;
                default: err("ATOM op", op); return;
            }
        }
        if (!red) W(v, dst, old);
        return;
    }
    if (n == "bar") {
        if ((op.f(32, 8) & 0x9b) != 0x80) { err("BAR no SYNC", op); return; }
        v.state = Inv::Barrier;
        return;
    }
    if (n == "membar" || n == "depbar" || n == "nop" || n == "cctl" || n == "cctll" || n == "cctlt") return;
    err("instrucción fuera de P4.1", op);
}

} // namespace

uint32_t Memory::cbuf32(unsigned bank, uint32_t off) const {
    if (bank >= cbufs.size() || off + 4 > cbufs[bank].size()) return 0;
    uint32_t v;
    std::memcpy(&v, &cbufs[bank][off], 4);
    return v;
}

uint32_t* Memory::global_word(uint64_t addr) {
    for (auto& g : globals) {
        if (addr >= g.base && addr + 4 <= g.base + g.data->size())
            return reinterpret_cast<uint32_t*>(g.data->data() + ((addr - g.base) & ~3ull));
    }
    return nullptr;
}

std::string run(std::span<const uint64_t> code, const Dispatch& d, Memory& mem, uint64_t max_steps) {
    Machine m(code, d, mem);
    m.run_all(max_steps);
    return m.error;
}

} // namespace lg_test::mref
