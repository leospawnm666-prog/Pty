// P3.2: the process memory manager in isolation (no CPU engine).
//  V1 ArenaAllocator: granules, first fit, non-contiguous runs, all-or-nothing, free checks
//  V2 initial map (seeded from a real NRO layout) and QueryMemory: blocks, fake block outside
//  V3 each SVC's validation and Result codes (Horizon / mesosphere rules)
//  V4 SetHeapSize: grow/shrink, zero on regrow, RAM scrubbed, LimitReached, heap head boundary
//  V5 MapMemory/UnmapMemory: aliasing, the source inaccessible, page-group check
//  V6 permissions/attributes: RELRO sequence of libnx's dynamic.c; PermissionLocked
//  V7 the Mmu is DERIVED: translate() matches the blocks after every kind of operation
//  V8 dispatcher: QueryMemory output pointer, GetInfo memory ids, synthetic images fail closed
//  D1 differential: 10^5 random operations against an independent page-granular model
//     (result codes, merged blocks, Mmu translation); run under ASan/UBSan and TSan
#include "lg_check.h"
#include "../cpu/guest_clock.h"
#include "../loader/nro_loader.h"
#include "../system/arena_allocator.h"
#include "../system/process_layout.h"
#include "../system/svc_dispatcher.h"
#include "../system/vm_manager.h"
#include "data/nro/nro_fixtures.h"
#include "vm_test_process.h"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <map>
#include <random>
#include <string>
#include <vector>

namespace {
using namespace lg::system;
namespace km = lg::system::kmem;
namespace kr = lg::system::kmem::result;
using lg::system::ProcessLayout;
constexpr uint64_t MiB = 1ull << 20;
constexpr uint64_t P = km::PageSize;

using vm_test::Process;

void v1_allocator() {
    std::printf("[V1] arena allocator\n");
    ArenaAllocator a;
    a.reset(0x10008000, 0x100000 + 0x7000);                     // rounded inwards: 0x10010000 .. 0x10100000 (15 granules)
    LG_CHECK(a.base() == 0x10010000 && a.capacity() == 15 * ArenaAllocator::kGranule && a.used() == 0);
    auto r1 = a.allocate(1);
    LG_CHECK(r1 && r1->size() == 1 && (*r1)[0] == (PhysicalRun{0x10010000, 0x10000}));
    auto r2 = a.allocate(0x30000);
    LG_CHECK(r2 && r2->size() == 1 && (*r2)[0] == (PhysicalRun{0x10020000, 0x30000}));
    LG_CHECK(a.free(0x10020000 + 0x10000, 0x10000));            // a hole in the middle
    auto r3 = a.allocate(0x30000);                               // first fit: the hole, then the tail
    LG_CHECK(r3 && r3->size() == 2 && (*r3)[0] == (PhysicalRun{0x10030000, 0x10000}) &&
             (*r3)[1] == (PhysicalRun{0x10050000, 0x20000}));
    LG_CHECK(a.used() == 6 * ArenaAllocator::kGranule);
    LG_CHECK(!a.allocate(10 * ArenaAllocator::kGranule) && a.used() == 6 * ArenaAllocator::kGranule);   // all or nothing
    LG_CHECK(a.allocate(9 * ArenaAllocator::kGranule) && a.used() == a.capacity());
    LG_CHECK(!a.allocate(1));
    LG_CHECK(!a.free(0x10010000 + 0x1000, 0x10000) && !a.free(0x10010000, 0x1000) && !a.free(0x0FFF0000, 0x10000));
    LG_CHECK(a.free(0x10010000, 0x10000) && !a.free(0x10010000, 0x10000));   // double free refused
    LG_CHECK(!a.free(0x10000000 + 0x100000, 0x10000));          // outside
    LG_CHECK(a.is_allocated(0x10020000) && !a.is_allocated(0x10010000));
    auto empty = a.allocate(0);
    LG_CHECK(empty && empty->empty());
}

void expect_block(const VmManager& vm, uint64_t addr, uint64_t base, uint64_t size, uint32_t state, uint32_t perm,
                  uint32_t attr = 0) {
    const auto i = vm.query(addr);
    if (!(i.base_address == base && i.size == size && i.state == state && i.permission == perm && i.attribute == attr))
        std::printf("  query 0x%llx -> [0x%llx +0x%llx] state %u perm %u attr %u\n", (unsigned long long)addr,
                    (unsigned long long)i.base_address, (unsigned long long)i.size, i.state, i.permission, i.attribute);
    LG_CHECK(i.base_address == base && i.size == size && i.state == state && i.permission == perm && i.attribute == attr);
    LG_CHECK(i.ipc_count == 0 && i.device_count == 0 && i.padding == 0);
}

void v2_initial_map() {
    std::printf("[V2] initial map and QueryMemory\n");
    Process p;
    const auto& vm = p.vm;
    const uint64_t code = ProcessLayout::kCodeBase;
    expect_block(vm, code, code, 0x1000, 0x08, km::PermRX);               // .text AliasCode
    expect_block(vm, code + 0x1000, code + 0x1000, 0x1000, 0x08, km::PermR);
    expect_block(vm, code + 0x2000, code + 0x2000, 0x3000, 0x09, km::PermRW);   // .data + .bss AliasCodeData
    expect_block(vm, code + 0x5000, code + 0x5000, ProcessLayout::kStackRegion + ProcessLayout::kGuardSize - code - 0x5000, 0, 0);
    expect_block(vm, p.l.stack_bottom_va + 0x800, p.l.stack_bottom_va, ProcessLayout::kMainStackSize, 0x0B, km::PermRW);
    expect_block(vm, p.l.tls_va, p.l.tls_va, P, 0x0C, km::PermRW);
    expect_block(vm, p.l.exit_stub_va, p.l.exit_stub_va, P, 0x03, km::PermRX);
    expect_block(vm, p.l.config_va, p.l.config_va, P, 0x04, km::PermRW);
    expect_block(vm, ProcessLayout::kHeapRegion, p.l.config_va + P, ProcessLayout::kAslrEnd - p.l.config_va - P, 0, 0);
    // Outside the space: Horizon's fake block [end, 2^64), also below the space.
    for (uint64_t a : {uint64_t{0}, uint64_t{0x7FFFFFF}, uint64_t{ProcessLayout::kAslrEnd}, ~uint64_t{0}})
        expect_block(vm, a, ProcessLayout::kAslrEnd, 0 - ProcessLayout::kAslrEnd, 0x10, 0);
    // A walk from the start of the space covers it exactly, with no gaps or overlaps.
    uint64_t at = ProcessLayout::kAslrBase, n = 0;
    while (at < ProcessLayout::kAslrEnd) { const auto i = vm.query(at); LG_CHECK(i.base_address == at && i.size > 0); at += i.size; ++n; }
    LG_CHECK(at == ProcessLayout::kAslrEnd && n == vm.block_count() && n == 12);
    LG_CHECK(vm.used_memory() == p.l.arena_used && vm.total_memory() == 64 * MiB && vm.heap_size() == 0);
    // Seeding refuses overlaps, unmapped ranges and bad arguments.
    VmManager& w = p.vm;
    LG_CHECK(!w.seed(code, P, km::Code, km::PermRX));                      // not Free
    LG_CHECK(!w.seed(ProcessLayout::kHeapRegion, P, km::Normal, km::PermRW));   // not in the Mmu
    LG_CHECK(!w.seed(code + 0x5000, 0x800, km::Code, km::PermR) && !w.seed(0x1000, P, km::Code, km::PermR));
}

void v3_validation() {
    std::printf("[V3] validation and Result codes\n");
    Process p;
    auto& vm = p.vm;
    const uint64_t heap = ProcessLayout::kHeapRegion, data = ProcessLayout::kCodeBase + 0x2000, text = ProcessLayout::kCodeBase;
    const uint64_t stack_dst = ProcessLayout::kStackRegion + 0x0200'0000;
    uint64_t out = 1;
    // SetHeapSize
    LG_CHECK(vm.set_heap_size(0x100000, out) == kr::InvalidSize && out == 0);
    LG_CHECK(vm.set_heap_size(8ull << 30, out) == kr::InvalidSize);
    LG_CHECK(vm.set_heap_size(ProcessLayout::kHeapRegionSize + 0x200000, out) == kr::OutOfMemory);
    LG_CHECK(vm.set_heap_size(128 * MiB, out) == kr::LimitReached && vm.heap_size() == 0);   // more than the arena
    LG_CHECK(vm.set_heap_size(4 * MiB, out) == 0 && out == heap);
    // SetMemoryPermission
    LG_CHECK(vm.set_memory_permission(data + 1, P, km::PermR) == kr::InvalidAddress);
    LG_CHECK(vm.set_memory_permission(data, 0, km::PermR) == kr::InvalidSize);
    LG_CHECK(vm.set_memory_permission(data, 0x800, km::PermR) == kr::InvalidSize);
    LG_CHECK(vm.set_memory_permission(~0ull & ~(P - 1), 2 * P, km::PermR) == kr::InvalidCurrentMemory);   // overflow
    for (uint32_t bad : {km::PermW, km::PermX, km::PermRX, 7u, 8u})
        LG_CHECK(vm.set_memory_permission(data, P, bad) == kr::InvalidNewMemoryPermission);
    LG_CHECK(vm.set_memory_permission(0x1000, P, km::PermR) == kr::InvalidCurrentMemory);           // outside the space
    LG_CHECK(vm.set_memory_permission(text, P, km::PermR) == kr::InvalidCurrentMemory);             // code: no CanReprotect
    LG_CHECK(vm.set_memory_permission(p.l.stack_bottom_va, P, km::PermR) == kr::InvalidCurrentMemory);   // stack: no CanReprotect
    LG_CHECK(vm.set_memory_permission(heap + 3 * MiB, 2 * MiB, km::PermR) == kr::InvalidCurrentMemory);   // heap + Free
    LG_CHECK(vm.set_memory_permission(data - P, 2 * P, km::PermR) == kr::InvalidCurrentMemory);      // two states
    LG_CHECK(vm.set_memory_permission(heap, P, km::PermRW) == 0);                                    // same perm: ok
    // SetMemoryAttribute
    LG_CHECK(vm.set_memory_attribute(data, P, 0, km::AttrUncached) == kr::InvalidCombination);      // attr outside mask
    LG_CHECK(vm.set_memory_attribute(data, P, km::AttrLocked, 0) == kr::InvalidCombination);        // unsupported bit
    LG_CHECK(vm.set_memory_attribute(data, P, km::AttrPermissionLocked, 0) == kr::InvalidCombination);   // PL only set
    LG_CHECK(vm.set_memory_attribute(heap, P, km::AttrPermissionLocked, km::AttrPermissionLocked) == kr::InvalidCurrentMemory);   // Normal: no CanPermissionLock
    LG_CHECK(vm.set_memory_attribute(text, P, km::AttrUncached, km::AttrUncached) == kr::InvalidCurrentMemory);   // code: no CanChangeAttribute
    LG_CHECK(vm.set_memory_attribute(heap, P, km::AttrUncached, km::AttrUncached) == 0);             // heap: Uncached ok
    expect_block(vm, heap, heap, P, 0x05, km::PermRW, km::AttrUncached);
    LG_CHECK(vm.set_memory_attribute(heap, P, km::AttrUncached, 0) == 0);
    expect_block(vm, heap, heap, 4 * MiB, 0x05, km::PermRW);                                          // merged back
    // MapMemory / UnmapMemory
    LG_CHECK(vm.map_memory(stack_dst + 1, heap, P) == kr::InvalidAddress && vm.map_memory(stack_dst, heap + 1, P) == kr::InvalidAddress);
    LG_CHECK(vm.map_memory(stack_dst, heap, 0) == kr::InvalidSize && vm.map_memory(stack_dst, heap, 0x800) == kr::InvalidSize);
    LG_CHECK(vm.map_memory(stack_dst, ~0ull & ~(P - 1), 2 * P) == kr::InvalidCurrentMemory);
    LG_CHECK(vm.map_memory(stack_dst, 0x1000, P) == kr::InvalidCurrentMemory);                       // src outside
    LG_CHECK(vm.map_memory(heap + 8 * MiB, heap, P) == kr::InvalidMemoryRegion);                    // dst in the heap
    LG_CHECK(vm.map_memory(ProcessLayout::kAliasRegion, heap, P) == kr::InvalidMemoryRegion);       // dst in alias
    LG_CHECK(vm.map_memory(ProcessLayout::kCodeBase + 0x100000, heap, P) == kr::InvalidMemoryRegion);   // not the stack region
    LG_CHECK(vm.map_memory(ProcessLayout::kStackRegion + ProcessLayout::kStackRegionSize - P, heap, 2 * P) == kr::InvalidMemoryRegion);
    LG_CHECK(vm.map_memory(stack_dst, text, P) == kr::InvalidCurrentMemory);                          // code cannot alias
    LG_CHECK(vm.map_memory(stack_dst, heap + 4 * MiB, P) == kr::InvalidCurrentMemory);               // Free cannot alias
    LG_CHECK(vm.map_memory(p.l.stack_bottom_va, heap, P) == kr::InvalidCurrentMemory);               // dst not Free
    LG_CHECK(vm.unmap_memory(stack_dst, heap, P) == kr::InvalidCurrentMemory);                       // src not locked
    LG_CHECK(vm.map_memory(stack_dst, heap, 2 * P) == 0);
    LG_CHECK(vm.map_memory(stack_dst + 0x100000, heap, P) == kr::InvalidCurrentMemory);              // src already locked
    LG_CHECK(vm.unmap_memory(stack_dst, heap + P, P) == kr::InvalidMemoryRegion);                     // other pages
    LG_CHECK(vm.unmap_memory(stack_dst + 0x100000, heap, P) == kr::InvalidCurrentMemory);             // dst not Stack
    LG_CHECK(vm.set_heap_size(0, out) == kr::InvalidCurrentMemory && vm.heap_size() == 4 * MiB);      // locked pages in the tail
    LG_CHECK(vm.set_memory_permission(heap, P, km::PermR) == kr::InvalidCurrentMemory);               // locked source
    LG_CHECK(vm.unmap_memory(stack_dst, heap, 2 * P) == 0);
    LG_CHECK(vm.set_heap_size(0, out) == 0 && vm.heap_size() == 0 && out == heap);
    LG_CHECK(!vm.broken());
}

void v4_heap() {
    std::printf("[V4] heap\n");
    Process p;
    auto& vm = p.vm;
    const uint64_t heap = ProcessLayout::kHeapRegion;
    uint64_t out = 0;
    LG_CHECK(vm.set_heap_size(16 * MiB, out) == 0 && vm.heap_size() == 16 * MiB);
    LG_CHECK(vm.used_memory() == p.l.arena_used + 16 * MiB);
    expect_block(vm, heap + 5 * MiB, heap, 16 * MiB, 0x05, km::PermRW);
    LG_CHECK(p.readable(heap) && p.writable(heap + 16 * MiB - 8) && !p.readable(heap + 16 * MiB));
    for (uint64_t off = 0; off < 16 * MiB; off += 64 * 1024) LG_CHECK(p.read64(heap + off) == 0u);   // zero heap
    LG_CHECK(p.write64(heap, 0x1111) && p.write64(heap + 16 * MiB - 8, 0x2222) && p.write64(heap + 6 * MiB, 0x3333));
    // Shrink: the tail is unmapped, its RAM scrubbed; the head keeps its data.
    LG_CHECK(vm.set_heap_size(4 * MiB, out) == 0 && vm.heap_size() == 4 * MiB && vm.scrubbed_bytes() == 12 * MiB);
    LG_CHECK(!p.readable(heap + 6 * MiB) && p.read64(heap) == 0x1111u);
    LG_CHECK(vm.used_memory() == p.l.arena_used + 4 * MiB);
    // Grow again: the regrown part reads as zero (Horizon's heap fill value 0).
    LG_CHECK(vm.set_heap_size(16 * MiB, out) == 0);
    LG_CHECK(p.read64(heap + 6 * MiB) == 0u && p.read64(heap + 16 * MiB - 8) == 0u && p.read64(heap) == 0x1111u);
    LG_CHECK(vm.set_heap_size(16 * MiB, out) == 0 && out == heap);                                   // same size
    // The heap head is a merge boundary; a whole-heap shrink to 0 frees everything.
    LG_CHECK(vm.set_heap_size(0, out) == 0 && vm.used_memory() == p.l.arena_used && vm.allocator().used() == 0);
    expect_block(vm, heap, p.l.config_va + P, ProcessLayout::kAslrEnd - p.l.config_va - P, 0, 0);
    // The whole arena can become heap, and not a byte more.
    const uint64_t cap = vm.allocator().capacity() & ~(km::HeapSizeAlignment - 1);
    LG_CHECK(vm.set_heap_size(cap, out) == 0 && vm.set_heap_size(cap + km::HeapSizeAlignment, out) == kr::LimitReached);
    LG_CHECK(vm.heap_size() == cap && !vm.broken());
}

void v5_alias() {
    std::printf("[V5] MapMemory / UnmapMemory\n");
    Process p;
    auto& vm = p.vm;
    const uint64_t heap = ProcessLayout::kHeapRegion, dst = ProcessLayout::kStackRegion + 0x0300'0000;
    uint64_t out = 0;
    LG_CHECK(vm.set_heap_size(2 * MiB, out) == 0);
    LG_CHECK(p.write64(heap + 0x10000, 0xAB));
    LG_CHECK(vm.map_memory(dst, heap + 0x10000, 0x20000) == 0);                 // a 128 KiB thread stack
    expect_block(vm, dst, dst, 0x20000, 0x0B, km::PermRW);
    expect_block(vm, heap + 0x10000, heap + 0x10000, 0x20000, 0x05, km::PermNone, km::AttrLocked);
    expect_block(vm, heap, heap, 0x10000, 0x05, km::PermRW);
    expect_block(vm, heap + 0x30000, heap + 0x30000, 2 * MiB - 0x30000, 0x05, km::PermRW);
    LG_CHECK(!p.readable(heap + 0x10000) && p.read64(dst) == 0xABu);          // the source is gone, the mirror sees it
    LG_CHECK(vm.physical(dst) == vm.physical(heap + 0x10000));
    LG_CHECK(p.write64(dst + 8, 0xCD));
    // Two adjacent mirrors stay two blocks (each destination is a merge boundary).
    LG_CHECK(vm.map_memory(dst + 0x20000, heap + 0x40000, 0x10000) == 0);
    expect_block(vm, dst + 0x20000, dst + 0x20000, 0x10000, 0x0B, km::PermRW);
    LG_CHECK(vm.unmap_memory(dst, heap + 0x10000, 0x20000) == 0);
    LG_CHECK(vm.query(dst).state == 0 && vm.query(dst).permission == 0);        // the destination is Free again
    LG_CHECK(p.read64(heap + 0x10008) == 0xCDu && !p.readable(dst));           // back in the heap
    LG_CHECK(vm.unmap_memory(dst + 0x20000, heap + 0x40000, 0x10000) == 0);
    expect_block(vm, heap, heap, 2 * MiB, 0x05, km::PermRW);                   // one heap block again
    LG_CHECK(vm.map_memory(dst, heap, 2 * MiB) == 0 && vm.map_memory(dst + 4 * MiB, ProcessLayout::kCodeBase + 0x2000, 0x3000) == 0);
    LG_CHECK(!p.readable(ProcessLayout::kCodeBase + 0x2000) && p.readable(dst + 4 * MiB));   // .data can alias too (CanAlias)
    LG_CHECK(vm.unmap_memory(dst + 4 * MiB, ProcessLayout::kCodeBase + 0x2000, 0x3000) == 0);
    LG_CHECK(vm.unmap_memory(dst, heap, 2 * MiB) == 0 && !vm.broken());
}

void v6_relro() {
    std::printf("[V6] libnx RELRO: SetMemoryPermission(R) + SetMemoryAttribute(PermissionLocked)\n");
    Process p;
    auto& vm = p.vm;
    const uint64_t relro = ProcessLayout::kCodeBase + 0x2000;
    LG_CHECK(vm.set_memory_permission(relro, P, km::PermR) == 0);
    LG_CHECK(p.readable(relro) && !p.writable(relro) && p.writable(relro + P));
    expect_block(vm, relro, relro, P, 0x09, km::PermR);
    expect_block(vm, relro + P, relro + P, 0x2000, 0x09, km::PermRW);
    LG_CHECK(vm.set_memory_attribute(relro, P, km::AttrPermissionLocked, km::AttrPermissionLocked) == 0);
    expect_block(vm, relro, relro, P, 0x09, km::PermR, km::AttrPermissionLocked);
    LG_CHECK(vm.set_memory_permission(relro, P, km::PermRW) == kr::InvalidCurrentMemory);   // locked for good
    LG_CHECK(vm.set_memory_permission(relro + P, P, km::PermNone) == 0 && !p.readable(relro + P));
    LG_CHECK(vm.physical(relro + P).has_value());                             // None keeps the backing
    LG_CHECK(vm.set_memory_permission(relro + P, P, km::PermRW) == 0 && p.writable(relro + P));
    expect_block(vm, relro + P, relro + P, 0x2000, 0x09, km::PermRW);          // merged back
    LG_CHECK(!vm.broken());
}

void v7_mmu_derived(const Process& p) {
    // Every page of every block: translate() agrees with the block's permission.
    for (const auto& b : p.vm.blocks()) {
        const uint64_t step = b.size > 64 * P ? b.size / 64 : P;
        for (uint64_t off = 0; off < b.size; off += step) {
            const uint64_t va = (b.va + off) & ~(P - 1);
            const auto rd = p.mmu.translate(va, false, false), wr = p.mmu.translate(va, true, false),
                       ex = p.mmu.translate(va, false, true);
            LG_CHECK(rd.ok() == ((b.perm & km::PermR) != 0));
            LG_CHECK(wr.ok() == ((b.perm & km::PermW) != 0) && ex.ok() == ((b.perm & km::PermX) != 0));
            if (rd.ok()) LG_CHECK(p.vm.physical(va) == rd.value().physical);
        }
    }
}

void v8_dispatcher() {
    std::printf("[V8] dispatcher: QueryMemory, GetInfo, synthetic images\n");
    Process p;
    lg::cpu::GuestClock clock;
    SvcDispatcher d(p.as, p.mmu);
    d.begin_session({7, 0, 0, &clock, {}, &p.vm});
    auto call = [&](lg::cpu::CpuState& s, uint32_t id) {
        s.exception = {}; s.exception.kind = lg::cpu::ExceptionKind::Svc; s.exception.address = 0x8000100; s.exception.syndrome = id;
        return d.handle(1, s);
    };
    const uint64_t buf = ProcessLayout::kCodeBase + 0x3000;                     // .bss
    lg::cpu::CpuState s{};
    s.x[0] = buf; s.x[2] = p.l.stack_bottom_va + 0x100;
    LG_CHECK(call(s, 0x06).kind == SvcOutcome::Kind::Continue && s.x[0] == 0 && s.x[1] == 0);
    km::MemoryInfo mi{};
    LG_CHECK(d.guest_memory().read(buf, &mi, sizeof mi));
    LG_CHECK(mi.base_address == p.l.stack_bottom_va && mi.size == ProcessLayout::kMainStackSize && mi.state == 0x0B && mi.permission == 3);
    for (uint64_t bad : {uint64_t{0x10}, uint64_t{ProcessLayout::kCodeBase}, uint64_t{ProcessLayout::kCodeBase + 0x5000 - 8}}) {   // unmapped, read-only, straddling
        s = {}; s.x[0] = bad; s.x[2] = 0;
        LG_CHECK(call(s, 0x06).kind == SvcOutcome::Kind::Continue && static_cast<uint32_t>(s.x[0]) == kr::InvalidPointer);
    }
    s = {}; s.x[1] = 4 * MiB;
    LG_CHECK(call(s, 0x01).kind == SvcOutcome::Kind::Continue && s.x[0] == 0 && s.x[1] == ProcessLayout::kHeapRegion);
    s = {}; s.x[1] = 3;                                                        // bad size: x1 = 0
    LG_CHECK(call(s, 0x01).kind == SvcOutcome::Kind::Continue && s.x[0] == kr::InvalidSize && s.x[1] == 0);
    auto info = [&](uint32_t id0, uint32_t handle, uint64_t id1, uint64_t& v) {
        lg::cpu::CpuState g{}; g.x[1] = id0; g.x[2] = handle; g.x[3] = id1;
        LG_CHECK(call(g, 0x29).kind == SvcOutcome::Kind::Continue);
        v = g.x[1];
        return static_cast<uint32_t>(g.x[0]);
    };
    const uint32_t cur = HandleTable::kCurrentProcess;
    const std::pair<uint32_t, uint64_t> expect[] = {
        {2, ProcessLayout::kAliasRegion}, {3, ProcessLayout::kAliasRegionSize}, {4, ProcessLayout::kHeapRegion},
        {5, ProcessLayout::kHeapRegionSize}, {6, 64 * MiB}, {7, p.l.arena_used + 4 * MiB}, {12, 0x0800'0000},
        {13, 0x10'0000'0000ull - 0x0800'0000}, {14, 0x4000'0000}, {15, 0x4000'0000}, {16, 0}, {17, 0},
        {21, 64 * MiB}, {22, p.l.arena_used + 4 * MiB}};
    uint64_t v = 0;
    for (const auto& [id, value] : expect) {
        const uint32_t rc = info(id, cur, 0, v);
        if (rc != 0 || v != value) std::printf("  GetInfo(%u) -> 0x%x 0x%llx\n", id, rc, (unsigned long long)v);
        LG_CHECK(rc == 0 && v == value);
        LG_CHECK(info(id, cur, 1, v) == kresult::InvalidCombination && info(id, 0, 0, v) == kresult::InvalidHandle);
    }
    // D-P3.2-3 answered InvalidEnumValue for 20/23/28; P6.0 emulates the newest kernel (D-P6.0-9):
    // 23 IsApplication and 28 AliasRegionExtraSize answer; 20 needs the kernel threads (absent here).
    LG_CHECK(info(20, cur, 0, v) == kresult::InvalidEnumValue);
    LG_CHECK(info(23, cur, 0, v) == 0 && v == 0 && info(28, cur, 0, v) == 0 && v == 0);
    // Caches.
    s = {}; LG_CHECK(call(s, 0x2A).kind == SvcOutcome::Kind::Continue && s.x[0] == 0);
    s = {}; s.x[0] = ProcessLayout::kHeapRegion; s.x[1] = 4 * MiB;
    LG_CHECK(call(s, 0x2B).kind == SvcOutcome::Kind::Continue && s.x[0] == 0);
    s = {}; s.x[0] = ProcessLayout::kHeapRegion; s.x[1] = 4 * MiB + 1;
    LG_CHECK(call(s, 0x2B).kind == SvcOutcome::Kind::Continue && s.x[0] == kr::InvalidCurrentMemory);
    s = {}; s.x[0] = 0x10; s.x[1] = 0;
    LG_CHECK(call(s, 0x2B).kind == SvcOutcome::Kind::Continue && s.x[0] == 0);
    // Synthetic image (no process map): memory SVCs fail closed, GetInfo memory ids are unknown.
    SvcDispatcher syn(p.as, p.mmu);
    syn.begin_session({7, 0, 0, &clock, {}});
    for (uint32_t id = 0x01; id <= 0x06; ++id) {
        lg::cpu::CpuState z{};
        z.exception.kind = lg::cpu::ExceptionKind::Svc; z.exception.syndrome = id;
        const auto o = syn.handle(1, z);
        LG_CHECK(o.kind == SvcOutcome::Kind::Fatal && o.message.find("memoria del proceso no disponible") != std::string::npos);
    }
    v7_mmu_derived(p);
}

void v9_big_heap() {
    std::printf("[V9] cost of a 1 GiB heap (R7)\n");
    Process p(1280 * MiB);
    uint64_t out = 0;
    const auto t0 = std::chrono::steady_clock::now();
    LG_CHECK(p.vm.set_heap_size(1024 * MiB, out) == 0);
    const auto t1 = std::chrono::steady_clock::now();
    LG_CHECK(p.write64(ProcessLayout::kHeapRegion + 1024 * MiB - 8, 1) && p.read64(ProcessLayout::kHeapRegion + 512 * MiB) == 0u);
    LG_CHECK(p.vm.set_heap_size(0, out) == 0);
    const auto t2 = std::chrono::steady_clock::now();
    const double grow = std::chrono::duration<double, std::milli>(t1 - t0).count();
    const double shrink = std::chrono::duration<double, std::milli>(t2 - t1).count();
    std::printf("  SetHeapSize(1 GiB) %.2f ms, back to 0 %.2f ms; Mmu regions %zu\n", grow, shrink, p.mmu.region_count());
#if !defined(__SANITIZE_ADDRESS__) && !defined(__SANITIZE_THREAD__)
    LG_CHECK(grow < 200.0 && shrink < 1000.0);
#endif
}

// ---------------------------------------------------------------------------------------
// D1: an independent, page-granular model of the same rules.
struct Model {
    struct Page { uint32_t state{}, perm{}, attr{}; uint8_t head{}; uint64_t pa{}; bool backed{}; };
    std::map<uint64_t, Page> pages;             // every non-Free page
    uint64_t begin{}, end{}, heap{}, heap_size{}, stack{}, stack_size{}, alias{}, alias_size{};
    uint64_t heap_used{}, capacity{};           // granules of the arena left for the heap

    Page get(uint64_t pg) const { auto it = pages.find(pg); return it == pages.end() ? Page{} : it->second; }
    void put(uint64_t pg, Page p) {
        if (p.state == km::Free && !p.backed && p.head == 0) pages.erase(pg); else pages[pg] = p;
    }
    /** Horizon's Update, page by page: pages that already have the properties are untouched;
     *  `set` only on the range's first page; `clear` on every updated page. */
    void upd(uint64_t a, uint64_t b, uint32_t state, uint32_t perm, uint32_t attr, uint8_t set, uint8_t clear) {
        for (uint64_t pg = a; pg < b; pg += P) {
            Page x = get(pg);
            if (x.state == state && x.perm == perm && x.attr == attr) continue;
            x.state = state; x.perm = perm; x.attr = attr;
            if (pg == a) x.head |= set;
            x.head &= static_cast<uint8_t>(~clear);
            put(pg, x);
        }
    }
    bool contains(uint64_t a, uint64_t s) const { return s && a >= begin && a + s > a && a + s <= end; }
    bool stack_ok(uint64_t a, uint64_t s) const {
        if (!s || a + s <= a) return false;
        if (a < stack || a + s - 1 > stack + stack_size - 1) return false;
        return !(a < heap + heap_size && heap < a + s) && !(a < alias + alias_size && alias < a + s);
    }
    uint32_t check(uint64_t a, uint64_t b, uint32_t sm, uint32_t s, uint32_t pm, uint32_t pp, uint32_t am, uint32_t at,
                   uint32_t ig = km::AttrIpcLocked | km::AttrDeviceShared, Page* first = nullptr) const {
        const Page f = get(a);
        for (uint64_t pg = a; pg < b; pg += P) {
            const Page x = get(pg);
            if (x.state != f.state || x.perm != f.perm || (x.attr | ig) != (f.attr | ig)) return kr::InvalidCurrentMemory;
            if ((x.state & sm) != s || (x.perm & pm) != pp || (x.attr & am) != at) return kr::InvalidCurrentMemory;
        }
        if (first) *first = f;
        return 0;
    }
    static bool mergeable(const Page& l, const Page& r) {
        return l.state == r.state && l.perm == r.perm && l.attr == r.attr && r.head == 0;
    }
    km::MemoryInfo query(uint64_t a) const {
        if (!contains(a, 1)) return {end, 0 - end, 0x10, 0, 0, 0, 0, 0};
        const uint64_t pg = a & ~(P - 1);
        const Page x = get(pg);
        if (x.state == km::Free) {
            auto hi = pages.upper_bound(pg);
            while (hi != pages.end() && hi->second.state == km::Free) ++hi;
            uint64_t lo = begin;
            for (auto it = pages.lower_bound(pg); it != pages.begin();) {
                --it;
                if (it->second.state != km::Free) { lo = it->first + P; break; }
            }
            const uint64_t h = hi == pages.end() ? end : hi->first;
            return {lo, h - lo, 0, 0, 0, 0, 0, 0};
        }
        uint64_t lo = pg, hi = pg + P;
        while (lo > begin && mergeable(get(lo - P), get(lo))) lo -= P;
        while (hi < end && mergeable(get(hi - P), get(hi))) hi += P;
        return {lo, hi - lo, x.state & 0xFF, x.attr, x.perm, 0, 0, 0};
    }
    uint32_t set_heap(uint64_t size, const VmManager& real) {
        if (size % km::HeapSizeAlignment || size >= km::MainMemorySizeMax) return kr::InvalidSize;
        if (size > heap_size) return kr::OutOfMemory;
        if (size < heap_used) {
            if (auto rc = check(heap + size, heap + heap_used, km::All, km::Normal, km::All, km::PermRW, km::All, 0)) return rc;
            for (uint64_t pg = heap + size; pg < heap + heap_used; pg += P) { Page x = get(pg); x.backed = false; x.pa = 0; pages[pg] = x; }
            upd(heap + size, heap + heap_used, km::Free, 0, 0, 0, size == 0 ? vm_merge::Normal : 0);
            heap_used = size;
            return 0;
        }
        if (size == heap_used) return 0;
        if (auto rc = check(heap + heap_used, heap + size, km::All, km::Free, 0, 0, 0, 0)) return rc;
        if ((size - heap_used) / ArenaAllocator::kGranule > capacity - heap_used / ArenaAllocator::kGranule)
            return kr::LimitReached;
        (void)real;
        for (uint64_t pg = heap + heap_used; pg < heap + size; pg += P) { Page x = get(pg); x.backed = true; pages[pg] = x; }
        upd(heap + heap_used, heap + size, km::Normal, km::PermRW, 0, heap_used == 0 ? vm_merge::Normal : 0, 0);
        heap_used = size;
        return kr::Success;   // the PAs are read from the real manager afterwards (placement is not modelled)
    }
    uint32_t set_perm(uint64_t a, uint64_t s, uint32_t perm) {
        if (a % P) return kr::InvalidAddress;
        if (s % P || s == 0) return kr::InvalidSize;
        if (a + s <= a) return kr::InvalidCurrentMemory;
        if (perm != 0 && perm != 1 && perm != 3) return kr::InvalidNewMemoryPermission;
        if (!contains(a, s)) return kr::InvalidCurrentMemory;
        Page f;
        if (auto rc = check(a, a + s, km::FlagCanReprotect, km::FlagCanReprotect, 0, 0, km::All, 0,
                            km::AttrIpcLocked | km::AttrDeviceShared, &f)) return rc;
        if (f.perm == perm) return 0;
        upd(a, a + s, f.state, perm, 0, 0, 0);
        return 0;
    }
    uint32_t set_attr(uint64_t a, uint64_t s, uint32_t mask, uint32_t attr) {
        if (a % P) return kr::InvalidAddress;
        if (s % P || s == 0) return kr::InvalidSize;
        if (a + s <= a) return kr::InvalidCurrentMemory;
        if ((mask | attr) != mask || (mask | attr | km::AttrSetMask) != km::AttrSetMask ||
            (mask & km::AttrPermissionLocked) != (attr & km::AttrPermissionLocked)) return kr::InvalidCombination;
        if (!contains(a, s)) return kr::InvalidCurrentMemory;
        const uint32_t st = ((mask & km::AttrUncached) ? km::FlagCanChangeAttribute : 0) |
                            ((mask & km::AttrPermissionLocked) ? km::FlagCanPermissionLock : 0);
        const uint32_t test = ~(km::AttrSetMask | km::AttrDeviceShared);
        if (auto rc = check(a, a + s, st, st, 0, 0, test, 0, ~test)) return rc;
        for (uint64_t pg = a; pg < a + s; pg += P) { Page x = get(pg); x.attr = (x.attr & ~mask) | attr; put(pg, x); }
        return 0;
    }
    uint32_t common_args(uint64_t d, uint64_t s, uint64_t n) const {
        if (d % P || s % P) return kr::InvalidAddress;
        if (n == 0 || n % P) return kr::InvalidSize;
        if (s + n <= s || d + n <= d) return kr::InvalidCurrentMemory;
        if (!contains(s, n)) return kr::InvalidCurrentMemory;
        if (!stack_ok(d, n)) return kr::InvalidMemoryRegion;
        return 0;
    }
    uint32_t map(uint64_t d, uint64_t s, uint64_t n) {
        if (auto rc = common_args(d, s, n)) return rc;
        Page f;
        if (auto rc = check(s, s + n, km::FlagCanAlias, km::FlagCanAlias, km::All, km::PermRW, km::All, 0,
                            km::AttrIpcLocked | km::AttrDeviceShared, &f)) return rc;
        if (auto rc = check(d, d + n, km::All, km::Free, 0, 0, 0, 0)) return rc;
        for (uint64_t off = 0; off < n; off += P) {
            const Page src = get(s + off);
            Page dst = get(d + off); dst.pa = src.pa; dst.backed = src.backed; pages[d + off] = dst;
        }
        upd(s, s + n, f.state, 0, km::AttrLocked, vm_merge::Locked, 0);
        upd(d, d + n, km::Stack, km::PermRW, 0, vm_merge::Normal, 0);
        return 0;
    }
    uint32_t unmap(uint64_t d, uint64_t s, uint64_t n) {
        if (auto rc = common_args(d, s, n)) return rc;
        Page f;
        if (auto rc = check(s, s + n, km::FlagCanAlias, km::FlagCanAlias, km::All, 0, km::All, km::AttrLocked,
                            km::AttrIpcLocked | km::AttrDeviceShared, &f)) return rc;
        if (auto rc = check(d, d + n, km::All, km::Stack, 0, 0, km::All, 0)) return rc;
        for (uint64_t off = 0; off < n; off += P) {
            const Page dp = get(d + off), sp = get(s + off);
            if (!dp.backed || !sp.backed || dp.pa != sp.pa) return kr::InvalidMemoryRegion;
        }
        for (uint64_t off = 0; off < n; off += P) { Page x = get(d + off); x.backed = false; x.pa = 0; pages[d + off] = x; }
        upd(s, s + n, f.state, km::PermRW, 0, 0, vm_merge::Locked);
        upd(d, d + n, km::Free, 0, 0, 0, vm_merge::Normal);
        return 0;
    }
};

void d1_differential() {
    std::printf("[D1] differential: 10^5 random operations against a page-granular model\n");
    Process p(96 * MiB);
    auto& vm = p.vm;
    Model m;
    const auto& c = vm.config();
    m.begin = c.space_begin; m.end = c.space_end; m.heap = c.heap_base; m.heap_size = c.heap_size;
    m.stack = c.stack_base; m.stack_size = c.stack_size; m.alias = c.alias_base; m.alias_size = c.alias_size;
    m.capacity = vm.allocator().capacity() / ArenaAllocator::kGranule;
    for (const auto& b : vm.blocks()) {                          // the seeded state
        if (b.state == km::Free) continue;
        for (uint64_t off = 0; off < b.size; off += P)
            m.pages[b.va + off] = Model::Page{b.state, b.perm, b.attr, off == 0 ? b.head_flags : uint8_t{0}, *vm.physical(b.va + off), true};
    }
    std::mt19937_64 rng(0xD1FF);
    auto pick = [&](uint64_t n) { return rng() % n; };
    const uint64_t kHeapMax = 16 * MiB, kStackWin = ProcessLayout::kStackRegion + 0x0400'0000;
    std::vector<std::tuple<uint64_t, uint64_t, uint64_t>> maps;   // successful MapMemory
    auto addr_in = [&](uint64_t base, uint64_t span) { return base + (pick(span / P) * P); };
    auto random_addr = [&]() -> uint64_t {
        switch (pick(8)) {
            case 0: return addr_in(ProcessLayout::kCodeBase, 0x8000);
            case 1: case 2: return addr_in(ProcessLayout::kHeapRegion, kHeapMax + 4 * MiB);
            case 3: case 4: return addr_in(kStackWin, 8 * MiB);
            case 5: return addr_in(ProcessLayout::kStackRegion, 0x200000);
            case 6: return pick(2) ? rng() : rng() & ~(P - 1);
            default: return addr_in(ProcessLayout::kAliasRegion - 2 * MiB, 4 * MiB);
        }
    };
    auto random_size = [&]() -> uint64_t {
        switch (pick(6)) {
            case 0: return 0;
            case 1: return 1 + pick(P);
            case 2: return pick(2) ? ~0ull & ~(P - 1) : (1ull << 40);
            default: return (1 + pick(64)) * P;
        }
    };
    uint64_t counts[7] = {}, ok[7] = {}, mismatches = 0;
    auto compare_all = [&]() {
        // Every real block equals the model's merged block at its start; together they tile the space.
        uint64_t at = c.space_begin;
        for (const auto& b : vm.blocks()) {
            LG_CHECK(b.va == at);
            const auto q = m.query(b.va);
            const bool same = q.base_address == b.va && q.size == b.size && q.state == (b.state & 0xFF) && q.permission == b.perm &&
                              q.attribute == b.attr;
            if (!same && ++mismatches < 5)
                std::printf("  block 0x%llx+0x%llx s%x p%u a%u | model 0x%llx+0x%llx s%x p%u a%u\n", (unsigned long long)b.va,
                            (unsigned long long)b.size, b.state & 0xFF, b.perm, b.attr, (unsigned long long)q.base_address,
                            (unsigned long long)q.size, q.state, q.permission, q.attribute);
            LG_CHECK(same);
            at += b.size;
        }
        LG_CHECK(at == c.space_end);
    };
    auto compare_pages = [&](uint64_t n) {
        for (uint64_t i = 0; i < n; ++i) {
            const uint64_t va = random_addr() & ~(P - 1);
            if (!m.contains(va, 1)) continue;
            const auto x = m.get(va);
            const auto rd = p.mmu.translate(va, false, false), wr = p.mmu.translate(va, true, false);
            LG_CHECK(rd.ok() == (x.backed && (x.perm & km::PermR)) && wr.ok() == (x.backed && (x.perm & km::PermW)));
            if (rd.ok()) LG_CHECK(rd.value().physical == x.pa);
            const auto q = vm.query(va), mq = m.query(va);
            LG_CHECK(q.base_address == mq.base_address && q.size == mq.size && q.state == mq.state);
        }
    };
    for (int i = 0; i < 100000; ++i) {
        const int op = static_cast<int>(pick(100));
        uint32_t got = 0, want = 0;
        int kind;
        if (op < 10) {
            kind = 0;
            uint64_t size;
            switch (pick(8)) {
                case 0: size = pick(2) ? 0x100000 : ~0ull & ~(km::HeapSizeAlignment - 1); break;
                case 1: size = 0; break;
                default: size = pick(kHeapMax / km::HeapSizeAlignment + 1) * km::HeapSizeAlignment;
            }
            const uint64_t before = m.heap_used;
            // Dirty the part that a shrink frees (the regrowth must read zero).
            if (size < before && size % km::HeapSizeAlignment == 0)
                for (uint64_t pg = m.heap + size; pg < m.heap + before; pg += 16 * P) (void)p.write64(pg, 0xDEAD);
            uint64_t out = 0;
            want = m.set_heap(size, vm);
            got = vm.set_heap_size(size, out);
            if (want == 0 && got == 0 && size > before) {
                for (uint64_t pg = m.heap + before; pg < m.heap + size; pg += P) {
                    m.pages[pg].pa = *vm.physical(pg);
                    if (((pg - m.heap) / P) % 61 == 0) LG_CHECK(p.read64(pg) == 0u);   // zero on (re)growth
                }
            }
            if (want == 0 && got == 0) LG_CHECK(out == m.heap && vm.heap_size() == size);
        } else if (op < 30) {
            kind = 1;
            const uint64_t a = random_addr(), s = random_size();
            const uint32_t perms[] = {0, 1, 3, 2, 5, 7};
            const uint32_t perm = perms[pick(6)];
            want = m.set_perm(a, s, perm);
            got = vm.set_memory_permission(a, s, perm);
        } else if (op < 40) {
            kind = 2;
            const uint64_t a = random_addr(), s = random_size();
            const uint32_t vals[] = {0, 8, 16, 24, 1, 2};
            const uint32_t mask = vals[pick(6)], attr = pick(3) ? mask & vals[pick(6)] : vals[pick(6)];
            want = m.set_attr(a, s, mask, attr);
            got = vm.set_memory_attribute(a, s, mask, attr);
        } else if (op < 60) {
            kind = 3;
            const uint64_t d = pick(4) ? addr_in(kStackWin, 8 * MiB) : random_addr();
            const uint64_t s = pick(4) ? addr_in(ProcessLayout::kHeapRegion, kHeapMax) : random_addr();
            const uint64_t n = pick(5) ? (1 + pick(32)) * P : random_size();
            want = m.map(d, s, n);
            got = vm.map_memory(d, s, n);
            if (want == 0 && got == 0) maps.emplace_back(d, s, n);
        } else if (op < 75) {
            kind = 4;
            uint64_t d, s, n;
            if (!maps.empty() && pick(4)) {
                const size_t k = pick(maps.size());
                std::tie(d, s, n) = maps[k];
                if (pick(8) == 0) n += P;                                    // wrong size
                else if (pick(8) == 0) s += P;                               // wrong pages
                else maps.erase(maps.begin() + static_cast<std::ptrdiff_t>(k));
            } else {
                d = addr_in(kStackWin, 8 * MiB); s = random_addr(); n = random_size();
            }
            want = m.unmap(d, s, n);
            got = vm.unmap_memory(d, s, n);
        } else {
            kind = 5;
            const uint64_t a = random_addr();
            const auto q = vm.query(a), mq = m.query(a);
            const bool same = q.base_address == mq.base_address && q.size == mq.size && q.state == mq.state &&
                              q.permission == mq.permission && q.attribute == mq.attribute;
            if (!same && ++mismatches < 5)
                std::printf("  query 0x%llx: 0x%llx+0x%llx s%x | model 0x%llx+0x%llx s%x\n", (unsigned long long)a,
                            (unsigned long long)q.base_address, (unsigned long long)q.size, q.state,
                            (unsigned long long)mq.base_address, (unsigned long long)mq.size, mq.state);
            if (!same) {   // diagnostics: both views around the mismatch
                for (uint64_t pg = (a & ~(P - 1)) - 8 * P; pg < (a & ~(P - 1)) + 12 * P; pg += P) {
                    const auto x = m.get(pg);
                    std::printf("   m %llx s%x p%u a%u head%u pa%llx\n", (unsigned long long)pg, x.state & 0xFF, x.perm, x.attr, x.head, (unsigned long long)x.pa);
                }
                for (const auto& b : vm.blocks()) if (b.va + b.size > (a & ~(P-1)) - 8 * P && b.va < a + 12 * P)
                    std::printf("   r %llx+%llx s%x p%u a%u head%u\n", (unsigned long long)b.va, (unsigned long long)b.size, b.state & 0xFF, b.perm, b.attr, b.head_flags);
            }
            LG_CHECK(same);
        }
        ++counts[kind];
        if (got != want) {
            if (++mismatches < 5) std::printf("  op %d kind %d: real 0x%x model 0x%x\n", i, kind, got, want);
            LG_CHECK(got == want);
        }
        if (kind < 5 && got == 0) ++ok[kind];
        if (i % 500 == 0) { compare_all(); compare_pages(32); }
    }
    compare_all();
    compare_pages(2000);
    v7_mmu_derived(p);
    LG_CHECK(!vm.broken());
    std::printf("  heap %llu (ok %llu), perm %llu (ok %llu), attr %llu (ok %llu), map %llu (ok %llu), unmap %llu (ok %llu), query %llu; blocks %zu\n",
                (unsigned long long)counts[0], (unsigned long long)ok[0], (unsigned long long)counts[1], (unsigned long long)ok[1],
                (unsigned long long)counts[2], (unsigned long long)ok[2], (unsigned long long)counts[3], (unsigned long long)ok[3],
                (unsigned long long)counts[4], (unsigned long long)ok[4], (unsigned long long)counts[5], vm.block_count());
    for (int k = 0; k < 5; ++k) LG_CHECK(ok[k] > 100);   // every operation succeeded often enough to matter
}
// P6.0: a heap page mapped elsewhere (MapProcessCodeMemory + MapProcessMemory) outlives the
// heap: Horizon counts page references; Lobo keeps the granule until no mapping uses it.
void v10_shared_granules() {
    std::printf("[V10] heap pages still mapped elsewhere survive a heap shrink (P6.0)\n");
    Process p;
    uint64_t heap = 0;
    LG_CHECK(p.vm.set_heap_size(2 * MiB, heap) == 0);
    const uint64_t code = ProcessLayout::kAslrBase + 0x4000'0000ull, shared = code + 4 * MiB;
    LG_CHECK(p.vm.map_process_code_memory(code, heap, 0x10000) == 0);
    LG_CHECK(p.vm.map_process_memory(shared, code, 0x10000) == 0);
    const uint32_t pattern = 0xC0DEF00D;
    LG_CHECK(p.vm.write_linear(shared + 0x40, &pattern, 4));
    LG_CHECK(p.vm.unmap_process_code_memory(code, heap, 0x10000) == 0);
    const uint64_t used = p.vm.used_memory();
    LG_CHECK(p.vm.set_heap_size(0, heap) == 0);
    LG_CHECK(p.vm.used_memory() < used);              // the rest of the heap went back
    LG_CHECK(p.vm.set_heap_size(2 * MiB, heap) == 0);   // a new heap never gets the kept granule
    uint32_t v = 0, z = 1;
    LG_CHECK(p.vm.read_linear(shared + 0x40, &v, 4) && v == pattern);
    LG_CHECK(p.vm.read_linear(heap + 0x40, &z, 4) && z == 0);
    LG_CHECK(p.vm.unmap_process_memory(shared, code, 0x10000) == km::result::InvalidCurrentMemory);   // code is gone
}
} // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);   // keep the log if an LG_CHECK aborts
    v1_allocator();
    v2_initial_map();
    v3_validation();
    v4_heap();
    v5_alias();
    v6_relro();
    v8_dispatcher();
    v9_big_heap();
    v10_shared_granules();
    d1_differential();
    std::puts("vm manager ok");
    return 0;
}
