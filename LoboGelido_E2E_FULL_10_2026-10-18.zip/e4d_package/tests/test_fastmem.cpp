#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <cstdint>
#include "../memory/address_space.h"
#include "../memory/mmu.h"
int main() {
    lg::memory::AddressSpace mem;
    constexpr uint64_t base = 0x10000000;
    LG_CHECK(mem.enable_fastmem(16 * 1024 * 1024, base));
    LG_CHECK(mem.map(base, 8192));
    auto* p = mem.host_ptr(base + 16);
    LG_CHECK(p != nullptr);
    *p = 0x5A;
    LG_CHECK(mem.read8(base + 16).value() == 0x5A);
    LG_CHECK(mem.fastmem_contains(base + 16, 32));
    LG_CHECK(mem.fastmem_base()[16] == 0x5A);
    mem.write32(base + 4094, 0x11223344);
    LG_CHECK(mem.read32(base + 4094).value() == 0x11223344);
    lg::memory::Mmu mmu;
    LG_CHECK(mmu.map(base, base, 8192, lg::memory::Read | lg::memory::Write | lg::memory::Execute));
    auto tr = mmu.translate(base + 16, false, false);
    LG_CHECK(tr.ok());
    LG_CHECK(tr.value().physical == base + 16);
    return 0;
}
