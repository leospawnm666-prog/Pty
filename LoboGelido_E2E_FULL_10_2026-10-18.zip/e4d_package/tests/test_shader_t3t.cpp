// P4.3 T3-T (P4_3_DISENO.md §5.1): the differential texture and image corpus.
// tests/data/shader/tcorpus: compute shaders (tests/shader/t3t_fixtures.h, path R not run: the
// reference interpreter has no texture unit) and graphics pipelines (t3tg_fixtures.h, with every
// single-stage mix), textures and storage images described in their comments (tex_spec.h). The
// translated path must equal glslang's on the same textures, samplers and images.
// Oracle: lavapipe. SwiftShader is not used for textures: it corrupts its own heap destroying
// compute pipelines with texel offsets (a glslang shader suffices: texelFetchOffset +
// textureLodOffset), and ignores non-constant gather offsets and ConstOffsets.
// Usage: test_shader_t3t <libvulkan.so> [name-filter]   (VK_ICD_FILENAMES: the lavapipe ICD)
//
// P4.4: the same runner serves T3-X (tests/test_shader_t3x.cpp defines the LG_T3T_* macros before
// including this file).
#include "lg_check.h"
#ifndef LG_T3T_CNS
#define LG_T3T_CNS t3tfx
#define LG_T3T_GNS t3tgfx
#define LG_T3T_CHEADER "shader/t3t_fixtures.h"
#define LG_T3T_GHEADER "shader/t3tg_fixtures.h"
#define LG_T3T_LABEL "T3-T"
#define LG_T3T_WHAT "texturas e imágenes"
#endif
#include LG_T3T_CHEADER
#include LG_T3T_GHEADER
#include "shader/t3g_runner.h"
#include "shader/t3_runner.h"

#include <cstdio>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    if (argc < 2) { std::fprintf(stderr, "uso: %s <libvulkan.so> [filtro]\n", argv[0]); return 2; }
    const std::string filter = argc > 2 ? argv[2] : "";
    uint32_t ok = 0, total = 0;
    {
        lg_test::vk::ComputeRunner runner(argv[1]);
        if (!runner.ok()) { std::fprintf(stderr, "oráculo no disponible: %s\n", runner.error().c_str()); return 1; }
        std::printf("oráculo: %s\n", runner.device_name().c_str());
        for (const auto& s : lg_test::LG_T3T_CNS::kShaders) {
            if (!filter.empty() && std::string(s.name).find(filter) == std::string::npos) continue;
            ++total;
            std::vector<uint8_t> dksh(s.dksh, s.dksh + s.dksh_size);
            std::vector<uint32_t> spv(s.spirv_size / 4);
            std::memcpy(spv.data(), s.spirv, spv.size() * 4);
            const auto o = lg_test::t3::run(runner, s.glsl, dksh, spv);
            ok += o.ok;
            std::printf("%-22s %s  %3u instr.  %s\n", s.name, o.ok ? "OK   " : "FALLO", o.tr.instructions, o.message.c_str());
            for (const auto& w : o.tr.warnings) std::printf("      aviso: %s\n", w.c_str());
        }
    }
    {
        lg_test::vk::GraphicsRunner runner(argv[1]);
        if (!runner.ok()) { std::fprintf(stderr, "oráculo no disponible: %s\n", runner.error().c_str()); return 1; }
        const bool llvmpipe = runner.device_name().find("llvmpipe") != std::string::npos;
        for (const auto& p : lg_test::LG_T3T_GNS::kPipelines) {
            if (!filter.empty() && std::string(p.name).find(filter) == std::string::npos) continue;
            // known oracle bug (P4.4): lavapipe gives the center value to interpolateAtOffset of an
            // input also read at the center (tests/data/shader/oracle_bugs/lvp_interp_at_offset_mixed.frag);
            // SwiftShader checks the case
            if (llvmpipe && std::string(p.name) == "f04_ipaoff_mix") {
                std::printf("%-22s OMITIDO  fallo conocido de llvmpipe: interpolateAtOffset junto a la lectura del centro\n", p.name);
                continue;
            }
            ++total;
            lg_test::t3g::StageSrc st[lg_test::t3g::kStages];
            for (int s = 0; s < lg_test::t3g::kStages; ++s) {
                const auto& f = p.stages[s];
                if (!f.glsl) continue;
                st[s].present = true;
                st[s].glsl = f.glsl;
                st[s].dksh.assign(f.dksh, f.dksh + f.dksh_size);
                st[s].spirv.resize(f.spirv_size / 4);
                std::memcpy(st[s].spirv.data(), f.spirv, st[s].spirv.size() * 4);
            }
            const auto o = lg_test::t3g::run(runner, st);
            const bool pass = o.ok && !o.skipped;
            ok += pass;
            std::printf("%-22s %s  %s\n", p.name, pass ? "OK   " : "FALLO", o.message.c_str());
            for (const auto& w : o.warnings) std::printf("      aviso: %s\n", w.c_str());
        }
    }
    std::printf(LG_T3T_LABEL ": %u/%u casos iguales (recompilado = glslang, " LG_T3T_WHAT ")\n", ok, total);
    LG_CHECK(ok == total);
    return 0;
}
