#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <iostream>
#include "../system/capability_manager.h"
int main() {
    lg::system::CapabilityManager cm;
    LG_CHECK(cm.grant(7, "fsp-srv"));
    LG_CHECK(cm.has(7, "fsp-srv"));
    LG_CHECK(cm.count(7) == 1);
    LG_CHECK(!cm.grant(7, "fsp-srv"));
    LG_CHECK(!cm.grant(0, "x"));
    LG_CHECK(cm.revoke(7, "fsp-srv"));
    LG_CHECK(!cm.has(7, "fsp-srv"));
    cm.grant(7, "svc:a");
    cm.grant(7, "svc:b");
    cm.clear(7);
    LG_CHECK(cm.count(7) == 0);
    std::cout << "capability manager ok\n";
}
