# P3.0 test hygiene: tests must not use assert() (compiled out by NDEBUG in Release builds).
# Usage: cmake -DDIR=<tests dir> -P lint_no_assert.cmake   (fails listing every occurrence)
if(NOT DIR)
  message(FATAL_ERROR "DIR not set")
endif()
file(GLOB_RECURSE sources "${DIR}/*.cpp" "${DIR}/*.h" "${DIR}/*.cpp.txt")
set(bad "")
foreach(f IN LISTS sources)
  if(f MATCHES "/reference/")          # verbatim copies of old product code, not tests
    continue()
  endif()
  if(f MATCHES "/data/nro/h4/shim/")   # P3.4: C headers for the freestanding guest build of h4.nro
    continue()
  endif()
  if(f MATCHES "/data/nro/h5pre/shim/")   # P3.5: same, for the H5-pre fixture
    continue()
  endif()
  if(f MATCHES "/lint_probe/" AND NOT PROBE)   # the probe only counts when testing the lint
    continue()
  endif()
  # Split into lines keeping ';' (a CMake list separator) out of the way, so line numbers
  # are exact; ignore // comments.
  file(READ "${f}" text)
  string(REPLACE ";" "<semicolon>" text "${text}")
  string(REPLACE "\n" ";" lines "${text}")
  set(n 0)
  foreach(l IN LISTS lines)
    math(EXPR n "${n}+1")
    string(REGEX REPLACE "//.*$" "" code "${l}")
    if(" ${code}" MATCHES "[^_A-Za-z0-9]assert[ \t]*\\(")
      list(APPEND bad "${f}:${n}")
    endif()
  endforeach()
endforeach()
if(bad)
  string(REPLACE ";" "\n  " bad "${bad}")
  message(FATAL_ERROR "assert() used in tests (use LG_CHECK from tests/lg_check.h):\n  ${bad}")
endif()
message(STATUS "no assert() in tests")
