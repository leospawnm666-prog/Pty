// P2 phase E.1: value-based exclusive monitor (interpreter + Dynarmic JIT).
//  [1] AddressSpace::compare_exchange / atomic_load: sizes, failures, epoch, code watch,
//      misaligned host addresses (unaligned arena base)
//  [2] interpreter LDXR/STXR semantics
//  [3] concurrency: 4 interpreter threads increment one counter with LDXR/ADD/STXR loops
//  [4] JIT (when linked): LDXR no longer aborts; JIT + 2 interpreter threads on one counter
//  [5] JIT: a reservation does not survive a switch to another guest context
//  [6] JIT: STXR fails when another agent changed the value in between
//  [7] Block backend: a failed STXR does not kill the guest thread
#include "../memory/address_space.h"
#include "../memory/mmu.h"
#include "../cpu/interpreter.h"
#include "../cpu/block_backend.h"
#if defined(LOBOGELIDO_HAS_DYNARMIC)
#include "../cpu/dynarmic_provider.h"
#endif

#include <array>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <vector>

namespace {
int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("  FAIL %s:%d %s\n", __FILE__, __LINE__, #c); std::fflush(stdout); if (++g_fail > 20) std::exit(1); } } while (0)

using lg::memory::AddressSpace;
using lg::cpu::CpuState;
constexpr uint64_t P = 4096;

// clang --target=aarch64 encodings (see the P2 E.1 report):
//   loop: ldxr w0,[x1]; add w0,w0,#1; stxr w2,w0,[x1]; cbnz w2,loop; sub x3,x3,#1; cbnz x3,loop
//   done: b done
constexpr uint32_t kIncrementLoop[] = {0x885F7C20u, 0x11000400u, 0x88027C20u, 0x35FFFFA2u,
                                       0xD1000463u, 0xB5FFFF63u, 0x14000000u};
constexpr uint32_t kLdxrX0 = 0xC85F7C20u, kStxrW2X0 = 0xC8027C20u, kLdxrW0 = 0x885F7C20u,
                   kStxrW2W0 = 0x88027C20u, kBSelf = 0x14000000u;

void compare_exchange_api() {
    std::printf("[1] compare_exchange / atomic_load\n");
    for (uint64_t base : {0x40000000ull, 0x40000800ull}) {         // aligned / misaligned host
        AddressSpace as;
        CHECK(as.enable_fastmem(16 * P, base));
        const uint64_t a = (base & ~(P - 1)) + 2 * P;               // page inside the arena
        CHECK(as.map(a, 2 * P));
        for (unsigned size : {1u, 2u, 4u, 8u, 16u}) {
            uint8_t cur[16] = {}, want[16], wrong[16];
            for (unsigned i = 0; i < size; ++i) { want[i] = uint8_t(0x10 + i); wrong[i] = uint8_t(0xEE); }
            const uint64_t e0 = as.write_epoch();
            CHECK(!as.compare_exchange(a, size, wrong, want));         // memory is zero
            CHECK(as.write_epoch() == e0);
            CHECK(as.compare_exchange(a, size, cur, want));
            CHECK(as.write_epoch() != e0);
            uint8_t back[16] = {};
            for (unsigned i = 0; i < size; ++i) back[i] = as.read8(a + i).value_or(0xFF);
            CHECK(std::memcmp(back, want, size) == 0);
            if (size <= 8) { uint8_t l[8] = {}; CHECK(as.atomic_load(a, size, l)); CHECK(std::memcmp(l, want, size) == 0); }
            CHECK(as.compare_exchange(a, size, want, cur));            // restore zeros
        }
        uint64_t z = 0, one = 1;
        CHECK(!as.compare_exchange(a, 3, &z, &one));                   // bad size
        CHECK(!as.compare_exchange(a + P - 4, 8, &z, &one));           // crosses a page
        CHECK(!as.compare_exchange(0x7000000000ull, 8, &z, &one));     // unmapped
        CHECK(as.compare_exchange(a + 1, 4, &z, &one));                // misaligned guest: locked path
        uint32_t l = 0; CHECK(as.atomic_load(a + 1, 4, &l)); CHECK(l == 1u);
        // A successful CAS on a watched code page is logged; a failed one is not.
        uint64_t cursor = as.code_epoch();
        as.watch_code_page(a + P);
        uint64_t two = 2;
        CHECK(!as.compare_exchange(a + P, 8, &one, &two));
        CHECK(as.code_epoch() == cursor);
        CHECK(as.compare_exchange(a + P, 8, &z, &two));
        std::vector<uint64_t> pages;
        CHECK(as.code_changes_since(cursor, [&](uint64_t p) { pages.push_back(p); }));
        CHECK(pages.size() == 1 && pages[0] == a + P);
        // Ordinary stores do not move write_epoch() any more.
        const uint64_t e = as.write_epoch();
        for (int i = 0; i < 100; ++i) as.write64(a + 8 * i, uint64_t(i));
        CHECK(as.write_epoch() == e);
    }
}

void interpreter_semantics() {
    std::printf("[2] interpreter LDXR/STXR\n");
    AddressSpace as;
    const uint64_t code = 0x100000, data = 0x200000;
    CHECK(as.map(code, P)); CHECK(as.map(data, P));
    as.write32(code + 0, kLdxrX0); as.write32(code + 4, kStxrW2X0);
    as.write32(code + 8, kLdxrW0); as.write32(code + 12, kStxrW2W0);
    lg::cpu::Interpreter cpu(as);
    auto pair = [&](uint64_t pc, uint64_t addr, auto between) {
        CpuState s{}; s.pc = pc; s.x[1] = addr;
        CHECK(cpu.step(s));                                        // LDXR
        s.x[0] += 1;                                               // new value
        between(s);
        CHECK(cpu.step(s));                                        // STXR
        return s;
    };
    as.write64(data, 41);
    auto s = pair(code, data, [](CpuState&) {});
    CHECK(s.x[2] == 0 && as.read64(data) == 42u);                  // success
    CHECK(!s.reservation_valid);
    s = pair(code, data, [&](CpuState&) { as.write64(data, 7); });  // other agent changed it
    CHECK(s.x[2] == 1 && as.read64(data) == 7u);
    s = pair(code, data, [&](CpuState&) { as.write64(data, 7); });  // same value written: ABA
    CHECK(s.x[2] == 0 && as.read64(data) == 8u);                   // value-based: succeeds
    s = pair(code, data, [](CpuState& st) { st.x[1] += 8; });       // different address
    CHECK(s.x[2] == 1);
    { CpuState t{}; t.pc = code + 4; t.x[1] = data; CHECK(cpu.step(t)); CHECK(t.x[2] == 1); }   // no LDXR
    // No live reservation although memory holds exactly the value a stale one remembers:
    // a value-only check would wrongly succeed. The reservation itself must be required.
    {
        as.write64(data, 0);
        CpuState t{}; t.pc = code + 4; t.x[1] = data; t.x[0] = 99;   // reservation_value == 0 == memory
        CHECK(cpu.step(t)); CHECK(t.x[2] == 1); CHECK(as.read64(data) == 0u);
        auto u = pair(code, data, [](CpuState&) {});                  // a completed pair...
        CHECK(u.x[2] == 0);
        u.pc = code + 4;                                               // ...then STXR again
        CHECK(cpu.step(u)); CHECK(u.x[2] == 1);                        // reservation was consumed
    }
    as.write32(data + 16, 0xFFFFFFFFu);                            // 32-bit pair, wraps
    s = pair(code + 8, data + 16, [](CpuState&) {});
    CHECK(s.x[2] == 0 && as.read32(data + 16) == 0u);
}

// Steps `cpu` until the increment loop reaches `done` (x3 == 0).
bool run_loop(lg::cpu::Interpreter& cpu, CpuState& s, uint64_t done) {
    for (uint64_t guard = 0; guard < 100'000'000ull; ++guard) {
        if (s.pc == done) return true;
        if (!cpu.step(s)) return false;
    }
    return false;
}

void interpreter_concurrency() {
    std::printf("[3] 4 interpreter threads, one counter\n");
    AddressSpace as;
    const uint64_t code = 0x100000, counter = 0x300000;
    CHECK(as.map(code, P)); CHECK(as.map(counter, P));
    for (unsigned i = 0; i < 7; ++i) as.write32(code + 4 * i, kIncrementLoop[i]);
    constexpr uint64_t kPerThread = 20000;
    std::atomic<int> ok{0};
    std::vector<std::thread> t;
    for (int k = 0; k < 4; ++k) t.emplace_back([&] {
        lg::cpu::Interpreter cpu(as);
        CpuState s{}; s.pc = code; s.x[1] = counter; s.x[3] = kPerThread;
        if (run_loop(cpu, s, code + 24)) ok.fetch_add(1);
    });
    for (auto& th : t) th.join();
    CHECK(ok.load() == 4);
    CHECK(as.read32(counter) == uint32_t(4 * kPerThread));
    std::printf("  counter = %u (expected %llu)\n", as.read32(counter).value_or(0), 4ull * kPerThread);
}

void block_backend_survives_failed_stxr() {
    std::printf("[7] Block backend: a failed STXR is not a guest fault\n");
    // Before E.1 a failed STXR left ExceptionKind::ExclusiveFail in the state and the
    // Block backend (the default CPU backend) reported it as a guest fault, killing the
    // thread on ordinary lock contention. A failed STXR only returns status 1.
    AddressSpace as;
    lg::memory::Mmu mmu;
    const uint64_t code = 0x100000, data = 0x300000;
    CHECK(as.map(code, P)); CHECK(as.map(data, P));
    CHECK(mmu.map(code, code, P, lg::memory::Read | lg::memory::Execute));
    CHECK(mmu.map(data, data, P, lg::memory::Read | lg::memory::Write));
    as.write32(code, kStxrW2W0);                                   // no LDXR: must fail
    as.write32(code + 4, kBSelf);
    lg::cpu::BlockBackend block(as, mmu, 8);
    CHECK(block.initialize().ok());
    CpuState s{}; s.pc = code; s.x[1] = data; s.x[0] = 1;
    const auto r = block.execute_state(s, 8);
    CHECK(r.ok());
    CHECK(s.x[2] == 1);
    CHECK(s.exception.kind == lg::cpu::ExceptionKind::None);
    CHECK(as.read32(data) == 0u);
}

#if defined(LOBOGELIDO_HAS_DYNARMIC)
constexpr uint32_t RWX = lg::memory::Read | lg::memory::Write | lg::memory::Execute;

void jit_concurrency() {
    std::printf("[4] JIT: LDXR/STXR run; JIT + 2 interpreter threads on one counter\n");
    AddressSpace as;
    lg::memory::Mmu mmu;
    const uint64_t code = 0x100000, counter = 0x300000;
    CHECK(as.map(code, P)); CHECK(as.map(counter, P));
    CHECK(mmu.map(code, code, P, RWX)); CHECK(mmu.map(counter, counter, P, RWX));
    for (unsigned i = 0; i < 7; ++i) as.write32(code + 4 * i, kIncrementLoop[i]);
    lg::cpu::Interpreter fallback(as, mmu);
    lg::cpu::DynarmicProvider jit(as, mmu, fallback);
    CHECK(jit.initialize().ok());
    constexpr uint64_t kPerAgent = 20000;
    std::atomic<int> ok{0};
    std::vector<std::thread> t;
    for (int k = 0; k < 2; ++k) t.emplace_back([&] {               // interpreters: no MMU
        lg::cpu::Interpreter cpu(as);
        CpuState s{}; s.pc = code; s.x[1] = counter; s.x[3] = kPerAgent;
        if (run_loop(cpu, s, code + 24)) ok.fetch_add(1);
    });
    {
        CpuState s{}; s.pc = code; s.x[1] = counter; s.x[3] = kPerAgent;
        int quanta = 0;
        while (s.pc != code + 24 && quanta < 1'000'000) { CHECK(jit.execute(s, 64).ok()); ++quanta; }
        CHECK(s.pc == code + 24);                                   // no abort, finished
    }
    for (auto& th : t) th.join();
    CHECK(ok.load() == 2);
    CHECK(as.read32(counter) == uint32_t(3 * kPerAgent));
    std::printf("  counter = %u (expected %llu)\n", as.read32(counter).value_or(0), 3ull * kPerAgent);
}

void jit_context_switch_clears_reservation() {
    std::printf("[5] JIT: reservation cleared on guest context switch\n");
    AddressSpace as;
    lg::memory::Mmu mmu;
    const uint64_t code = 0x100000, data = 0x300000;
    CHECK(as.map(code, P)); CHECK(as.map(data, P));
    CHECK(mmu.map(code, code, P, RWX)); CHECK(mmu.map(data, data, P, RWX));
    as.write32(code + 0, kLdxrW0); as.write32(code + 4, kBSelf);        // thread A: LDXR; B .
    as.write32(code + 8, kStxrW2W0); as.write32(code + 12, kBSelf);    // thread B: STXR; B .
    lg::cpu::Interpreter fallback(as, mmu);
    lg::cpu::DynarmicProvider jit(as, mmu, fallback);
    CHECK(jit.initialize().ok());
    CpuState a{}; a.pc = code; a.x[1] = data;
    CHECK(jit.execute(a, 16).ok());                                  // A holds a reservation
    CpuState b{}; b.pc = code + 8; b.x[1] = data; b.x[0] = 5;
    CHECK(jit.execute(b, 16).ok());                                  // B never did LDXR
    CHECK(b.x[2] == 1);                                              // ...so its STXR fails
    CHECK(as.read32(data) == 0u);
}
void jit_stxr_compares() {
    std::printf("[6] JIT: STXR fails when another agent changed the value\n");
    AddressSpace as;
    lg::memory::Mmu mmu;
    const uint64_t code = 0x100000, data = 0x300000;
    CHECK(as.map(code, P)); CHECK(as.map(data, P));
    CHECK(mmu.map(code, code, P, RWX)); CHECK(mmu.map(data, data, P, RWX));
    // ldxr w0,[x1] ; b 1f ; 1: add w0,w0,#1 ; stxr w2,w0,[x1] ; b .
    const uint32_t prog[] = {0x885F7C20u, 0x14000001u, 0x11000400u, 0x88027C20u, 0x14000000u};
    for (unsigned i = 0; i < 5; ++i) as.write32(code + 4 * i, prog[i]);
    lg::cpu::Interpreter fallback(as, mmu);
    lg::cpu::DynarmicProvider jit(as, mmu, fallback);
    CHECK(jit.initialize().ok());
    as.write32(data, 10);
    CpuState s{}; s.pc = code; s.x[1] = data;
    CHECK(jit.execute(s, 2).ok());                                   // LDXR + B: quantum ends
    CHECK(s.pc == code + 8);
    as.write32(data, 500);                                           // other agent, plain store
    CHECK(jit.execute(s, 2).ok());                                   // ADD + STXR
    CHECK(s.x[2] == 1);                                              // must fail...
    CHECK(as.read32(data) == 500u);                                  // ...and not overwrite
}
#endif
} // namespace

int main() {
    compare_exchange_api();
    interpreter_semantics();
    interpreter_concurrency();
    block_backend_survives_failed_stxr();
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    jit_concurrency();
    jit_context_switch_clears_reservation();
    jit_stxr_compares();
#endif
    if (g_fail) { std::printf("exclusive monitor: %d FAILED\n", g_fail); return 1; }
    std::puts("exclusive monitor ok");
    return 0;
}
