#include "lg_check.h"   // fusion: LG_CHECK instead of assert (P3.0 test hygiene)
#include "../loader/content_loader.h"
#include "../crypto/sha256.h"
#include <cstring>
#include <filesystem>
#include <fstream>
#include <vector>

static void p32(std::vector<uint8_t>& b, size_t o, uint32_t v) { for (int i=0;i<4;++i) b[o+i]=uint8_t(v>>(8*i)); }
static void p64(std::vector<uint8_t>& b, size_t o, uint64_t v) { for (int i=0;i<8;++i) b[o+i]=uint8_t(v>>(8*i)); }

static std::vector<uint8_t> make_hfs0(const std::string& name, const std::vector<uint8_t>& payload,
                                      uint32_t hashed_size, std::array<uint8_t,32>* out_hash = nullptr) {
    const uint32_t strings = static_cast<uint32_t>(name.size()+1);
    const uint64_t data_base = 0x10 + 0x40 + strings;
    std::vector<uint8_t> h(static_cast<size_t>(data_base + payload.size()), 0);
    std::memcpy(h.data(), "HFS0", 4); p32(h, 4, 1); p32(h, 8, strings);
    p64(h, 0x10, 0); p64(h, 0x18, payload.size()); p32(h, 0x20, 0); p32(h, 0x24, hashed_size);
    std::memcpy(h.data()+0x50, name.c_str(), name.size());
    const auto payload_hash = lg::crypto::Sha256::digest(payload.data(), payload.size());
    std::copy(payload_hash.begin(), payload_hash.end(), h.begin()+0x30);
    std::copy(payload.begin(), payload.end(), h.begin()+data_base);
    if (out_hash) *out_hash = lg::crypto::Sha256::digest(h.data(), hashed_size);
    return h;
}

int main() {
    namespace fs = std::filesystem;
    const fs::path path = fs::temp_directory_path() / "lobo_xci_container_test.xci";

    const std::vector<uint8_t> nca_bytes = {'N','C','A','3'};
    std::array<uint8_t,32> nca_hash{};
    const auto secure = make_hfs0("main.nca", nca_bytes, static_cast<uint32_t>(nca_bytes.size()), &nca_hash);

    const uint64_t root_offset = 0x10000;
    const std::string secure_name = "secure";
    const uint32_t root_strings = static_cast<uint32_t>(secure_name.size()+1);
    const uint64_t root_data_base = 0x10 + 0x40 + root_strings;
    std::vector<uint8_t> root(static_cast<size_t>(root_data_base + secure.size()), 0);
    std::memcpy(root.data(), "HFS0", 4); p32(root, 4, 1); p32(root, 8, root_strings);
    p64(root, 0x10, 0); p64(root, 0x18, secure.size()); p32(root, 0x20, 0);
    p32(root, 0x24, static_cast<uint32_t>(secure.size()));
    std::memcpy(root.data()+0x50, secure_name.c_str(), secure_name.size());
    std::copy(secure.begin(), secure.end(), root.begin()+root_data_base);
    const auto secure_hash = lg::crypto::Sha256::digest(secure);
    std::copy(secure_hash.begin(), secure_hash.end(), root.begin()+0x30);

    std::vector<uint8_t> image(static_cast<size_t>(root_offset + root.size()), 0);
    std::memcpy(image.data()+0x100, "HEAD", 4);
    p64(image, 0x130, root_offset);
    p64(image, 0x138, root.size());
    const auto root_hash = lg::crypto::Sha256::digest(root);
    std::copy(root_hash.begin(), root_hash.end(), image.begin()+0x140);
    std::copy(root.begin(), root.end(), image.begin()+root_offset);

    std::ofstream(path, std::ios::binary).write(reinterpret_cast<const char*>(image.data()), image.size());
    const auto info = lg::loader::ContentLoader::inspect(path.string());
    LG_CHECK(info.valid && info.format == lg::loader::Format::Xci);
    LG_CHECK(info.entries.size() == 1 && info.entries.front().name == "main.nca");
    LG_CHECK(info.entries.front().has_hash && info.entries.front().hashed_size == nca_bytes.size());

    fs::remove(path);
    return 0;
}
