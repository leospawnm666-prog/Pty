// P3.3: threads and synchronization end to end, with real NROs (tests/data/nro).
//  H3 h3.nro: 4 threads incrementing a counter under libnx's mutex protocol (LDAXR/STLXR +
//     ArbitrateLock/Unlock), producer/consumer on a condition variable (with a timed wait),
//     events with WaitSynchronization (timeout, woken by another thread, ResetSignal),
//     SleepThread, the address arbiter, thread handles, CloseHandle. Same results on Block,
//     Block 16 KiB, JIT, JIT+fastmem, JIT+fastmem 16 KiB and on the plain interpreter driven by
//     hand through the dispatcher and the kernel with a manual clock
//  D1 diagnostics of the guest kernel (guest_threads=, cores=, waits=, timers=)
//  D2 idle_deadline_ns() is 0 while a thread can run, even with a timeout pending
//  W1 the worker waits instead of spinning while every guest thread sleeps (R5: 2 s of guest
//     sleep cost well under 10 % of one host CPU), and stop() interrupts a long wait at once
//  X1 a fault in any thread ends the process (Error, with the thread and the fault)
#include "lg_check.h"
#include "vm_test_process.h"
#include "../cpu/guest_clock.h"
#include "../cpu/interpreter.h"
#include "../runtime/runtime_coordinator.h"
#include "../runtime/runtime_worker.h"
#include "../system/guest_thread_context.h"
#include "../system/kthread.h"
#include "../system/scheduler.h"
#include "../system/svc_dispatcher.h"
#include "../system/thread_manager.h"
#include "data/nro/nro_fixtures.h"

#include <sys/resource.h>

#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

namespace {
namespace fs = std::filesystem;
using namespace std::chrono_literals;
using lg::cpu::ExceptionKind;
using lg::runtime::RuntimeCoordinator;
using lg::runtime::State;
using lg::system::ProcessLayout;
constexpr uint64_t MiB = 1ull << 20;
constexpr uint64_t kN = 2000;   // h3.S: increments per worker

template <size_t N> std::vector<uint8_t> bytes(const unsigned char (&a)[N]) { return {a, a + N}; }
std::string write_nro(const std::string& name, const std::vector<uint8_t>& b) {
    const auto p = fs::temp_directory_path() / ("lobo_p33_" + name + ".nro");
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(b.data()), long(b.size()));
    return p.string();
}
struct Engine { const char* name; bool force_interpreter; bool fastmem; size_t host_page; };
std::vector<Engine> engines() {
    std::vector<Engine> e = {{"Block", true, false, 0}, {"Block, 16 KiB host pages", true, false, 16384}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    e.push_back({"JIT", false, false, 0});
    e.push_back({"JIT + fastmem", false, true, 0});
    e.push_back({"JIT + fastmem, 16 KiB host pages", false, true, 16384});
#endif
    return e;
}
std::string run_to_end(RuntimeCoordinator& rt) {
    for (int i = 0; i < 20'000'000 && rt.state() == State::Running; ++i) {
        const auto r = rt.run_frame(rt.entry_point());
        if (!r.ok()) return r.error();
    }
    return {};
}
std::vector<uint64_t> words(const std::string& blob) {
    std::vector<uint64_t> w(blob.size() / 8);
    std::memcpy(w.data(), blob.data(), w.size() * 8);
    return w;
}

void check_h3(const std::vector<uint64_t>& r, uint64_t main_id, const char* engine) {
    LG_CHECK(r.size() == 34);
    if (r.size() != 34) { std::printf("  [%s] %zu words\n", engine, r.size()); return; }
    const uint64_t expect[34] = {
        0, 44, 0,                       // priority, main core
        4 * kN,                          // counter
        0, 0, 0, 0,                      // joins
        0, 1, 2, 0,                      // worker cores
        5050, 0, 0xEA01, 1,              // producer / consumer
        0xEA01, 0xFFFFFFFFu, 0, 0, 0, 0xFA01, 0,   // events
        1,                               // sleep
        0xEA01, 0, 1, 0,                 // arbiter
        0, main_id,                      // GetThreadId
        7, 0, 0x4833,
        0x00C00000};                     // FPCR inherited by a new thread (CloneFpuStatus)
    for (int i = 0; i < 34; ++i) {
        if (r[static_cast<size_t>(i)] != expect[i])
            std::printf("  [%s] results[%d] = 0x%llx, want 0x%llx\n", engine, i, (unsigned long long)r[static_cast<size_t>(i)],
                        (unsigned long long)expect[i]);
        LG_CHECK(r[static_cast<size_t>(i)] == expect[i]);
    }
}

void h3_engines() {
    std::printf("[H3] threads and synchronization in a real NRO, on every engine\n");
    const std::string path = write_nro("h3", bytes(nro_fixtures::h3));
    for (const auto& e : engines()) {
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            LG_CHECK(rt.kthreads_for_testing().active() && rt.kthreads_for_testing().live_count() == 1);
            const auto t0 = std::chrono::steady_clock::now();
            const auto err = run_to_end(rt);
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
            if (!err.empty() || rt.state() != State::Stopped) std::printf("  %s | %s\n", err.c_str(), rt.diagnostics().c_str());
            LG_CHECK(err.empty() && rt.state() == State::Stopped && rt.guest_exit().has_code && rt.guest_exit().code == 0);
            check_h3(words(rt.guest_log()), 1, e.name);
            const uint64_t locks = rt.svc_calls(0x1A), unlocks = rt.svc_calls(0x1B);
            std::printf("  %-34s %7.1f ms  ArbitrateLock=%llu ArbitrateUnlock=%llu condvar waits=%llu idle frames=%llu\n", e.name, ms,
                        (unsigned long long)locks, (unsigned long long)unlocks, (unsigned long long)rt.svc_calls(0x1C),
                        (unsigned long long)rt.idle_waits());
            LG_CHECK(locks > 0 && unlocks > 0);                 // the mutex really was contended
            LG_CHECK(rt.svc_calls(0x08) == 7 && rt.svc_calls(0x09) == 7 && rt.svc_calls(0x0A) == 7);
            LG_CHECK(rt.svc_calls(0x45) == 1 && rt.svc_calls(0x11) == 1 && rt.svc_calls(0x17) == 2 && rt.svc_calls(0x34) == 2 &&
                     rt.svc_calls(0x35) == 1 && rt.svc_calls(0x16) == 7);
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

/** The plain interpreter, the dispatcher and the kernel driven by hand (manual clock). */
void h3_plain_interpreter() {
    std::printf("[H3] plain interpreter + dispatcher + KernelThreads, manual clock\n");
    vm_test::Process p(64 * MiB, bytes(nro_fixtures::h3));
    lg::cpu::GuestClock clock;
    clock.set_manual(true);
    lg::cpu::Interpreter cpu(p.as, p.mmu);
    cpu.set_guest_clock(&clock);
    lg::system::Scheduler sched;
    lg::system::ThreadManager tm(sched);
    lg::system::GuestThreadContextManager ctxs;
    lg::system::SvcDispatcher d(p.as, p.mmu);
    lg::system::KernelThreads k;
    lg::system::KernelThreadsConfig c{};
    c.process_id = 1;
    c.priority_mask = lg::system::SvcDispatcher::kPriorityMask;
    c.tls_region_base = ProcessLayout::kConfigVa + 0x20000;
    c.tls_region_end = ProcessLayout::kStackRegion + ProcessLayout::kStackRegionSize;
    c.clock = &clock;
    c.handles = &d.handles();
    c.memory = &d.guest_memory();
    c.vm = &p.vm;
    c.threads = &tm;
    c.contexts = &ctxs;
    c.host.spawn = [&](uint64_t pc, uint64_t sp) -> uint64_t {
        const auto id = tm.create("guest", 1, [](uint64_t) {});
        return id && ctxs.create(id, pc, sp) ? id : 0;
    };
    LG_CHECK(k.begin(c));
    d.begin_session({1, 0, p.l.exit_stub_va, &clock, {}, &p.vm, &k});
    const uint64_t main = tm.create("main", 1, [](uint64_t) {});
    auto* m = ctxs.create(main, p.l.code_va, p.l.stack_top_va);
    const uint32_t mh = *d.handles().add({lg::system::KObjectType::Thread, main});
    LG_CHECK(k.register_main_thread(main, mh, 44, p.l.tls_va));
    // hbloader's ConfigEntry list: MainThreadHandle, EndOfList
    const uint64_t cfg[6] = {1, mh, 0, 0, 0, 0};
    LG_CHECK(d.guest_memory().write(p.l.config_va, cfg, sizeof cfg));
    m->x[0] = p.l.config_va;
    m->x[1] = ~0ull;
    m->x[30] = p.l.exit_stub_va;
    m->tpidrro_el0 = p.l.tls_va;
    bool exited = false;
    uint64_t turns = 0, idle = 0;
    while (!exited && turns < 50'000'000) {
        k.update(clock.ticks());
        bool ran = false;
        for (int core = 0; core < lg::system::kNumVirtualCores && !exited; ++core) {
            lg::system::KThread* t = k.top(core);
            if (!t) continue;
            ran = true;
            const uint64_t tid = t->id;
            auto& s = *ctxs.get(tid);
            k.begin_turn(core, t, clock.ticks());
            for (int i = 0; i < 97; ++i) {                  // an odd quantum: other interleavings than the engines
                if (cpu.step(s)) continue;
                if (s.exception.kind != ExceptionKind::Svc) {
                    std::printf("  fault kind %d at 0x%llx (thread %llu)\n", int(s.exception.kind),
                                (unsigned long long)s.exception.address, (unsigned long long)tid);
                    LG_CHECK(false);
                }
                const auto o = d.handle(tid, s);
                LG_CHECK(o.kind != lg::system::SvcOutcome::Kind::Fatal);
                exited = o.kind == lg::system::SvcOutcome::Kind::ExitProcess;
                break;                                        // an SVC ends the turn
            }
            k.end_turn(clock.ticks());
            k.update(clock.ticks());
            ++turns;
            clock.advance(3);                                 // time passes while threads run
        }
        if (!ran) {
            LG_CHECK(k.next_deadline() != 0);                 // otherwise a deadlock
            clock.advance(k.next_deadline() - clock.ticks());
            ++idle;
        }
        if (turns % 4096 == 0) {
            const std::string inv = k.check_invariants();
            if (!inv.empty()) std::printf("  invariant: %s\n", inv.c_str());
            LG_CHECK(inv.empty());
        }
    }
    std::printf("  %llu turns, %llu idle jumps\n", (unsigned long long)turns, (unsigned long long)idle);
    LG_CHECK(exited && d.exit().has_code && d.exit().code == 0);
    check_h3(words(d.log().contents()), main, "plain interpreter");
    LG_CHECK(d.calls(0x1A) > 0);
    // every other thread exited and its handle was closed: only the main thread's object is
    // left (the handles left: the main thread's and the event pair h3 never closes)
    LG_CHECK(k.object_count() == 1 && d.handles().size() == 3);
}

void d1_diagnostics() {
    std::printf("[D1] guest kernel diagnostics\n");
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(true);
    LG_CHECK(rt.prepare(write_nro("nap_d1", bytes(nro_fixtures::nap))).ok() && rt.start().ok());
    rt.set_manual_guest_clock_for_testing(true);
    const std::string d0 = rt.diagnostics();
    LG_CHECK(d0.find(" guest_threads=1/1 cores=[c0:1,c1:-,c2:-] waits=0 timers=0 idle_waits=0 ") != std::string::npos);
    for (int i = 0; i < 100 && rt.kthreads_for_testing().waiting_count() == 0; ++i) LG_CHECK(rt.run_frame(rt.entry_point()).ok());
    LG_CHECK(rt.kthreads_for_testing().waiting_count() == 1);
    LG_CHECK(rt.run_frame(rt.entry_point()).ok() && rt.idle_waits() >= 1);
    const std::string d1 = rt.diagnostics();
    if (d1.find(" cores=[c0:-,c1:-,c2:-] waits=1 timers=1 ") == std::string::npos) std::printf("  %s\n", d1.c_str());
    LG_CHECK(d1.find(" cores=[c0:-,c1:-,c2:-] waits=1 timers=1 ") != std::string::npos);
    const uint64_t ns = rt.idle_deadline_ns();
    LG_CHECK(ns > 1'990'000'000ull && ns <= 2'000'000'200ull);   // the 2 s sleep, measured on the manual clock
    // advancing the manual clock wakes the guest, which then finishes
    rt.advance_guest_clock_for_testing(lg::cpu::GuestClock::ns_to_ticks(ns) + 1);
    LG_CHECK(run_to_end(rt).empty() && rt.state() == State::Stopped && rt.guest_log() == "nap");
    LG_CHECK(rt.idle_deadline_ns() == 0);
}

void d2_idle_only_when_nothing_runs() {
    std::printf("[D2] a pending timeout does not idle the worker while a thread can run\n");
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(true);
    LG_CHECK(rt.prepare(write_nro("nap_busy", bytes(nro_fixtures::nap_busy))).ok() && rt.start().ok());
    rt.set_manual_guest_clock_for_testing(true);
    const auto& k = rt.kthreads_for_testing();
    int frames = 0;
    for (; frames < 100000 && !(k.timer_count() == 1 && k.top(1) != nullptr); ++frames)
        LG_CHECK(rt.run_frame(rt.entry_point()).ok());
    LG_CHECK(k.timer_count() == 1 && k.top(1) != nullptr && k.top(0) == nullptr);   // main sleeps, the child computes
    LG_CHECK(rt.idle_deadline_ns() == 0);
    for (int i = 0; i < 1000; ++i) LG_CHECK(rt.run_frame(rt.entry_point()).ok());
    LG_CHECK(rt.idle_deadline_ns() == 0 && rt.idle_waits() == 0);
    rt.advance_guest_clock_for_testing(lg::cpu::GuestClock::ns_to_ticks(2'000'000'000ull) + 10);
    LG_CHECK(run_to_end(rt).empty() && rt.state() == State::Stopped && rt.guest_log() == "busy");
}

double cpu_seconds() {
    rusage u{};
    getrusage(RUSAGE_SELF, &u);
    return double(u.ru_utime.tv_sec + u.ru_stime.tv_sec) + double(u.ru_utime.tv_usec + u.ru_stime.tv_usec) / 1e6;
}

void w1_worker_idle() {
    std::printf("[W1] the worker sleeps while the guest sleeps\n");
    const std::string path = write_nro("nap", bytes(nro_fixtures::nap));
    using WS = lg::runtime::RuntimeWorker::State;
    {
        RuntimeCoordinator rt;
        rt.set_guest_memory_budget(64 * MiB);
        rt.set_force_interpreter(true);
        LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
        lg::runtime::RuntimeWorker worker(rt);
        const double c0 = cpu_seconds();
        const auto t0 = std::chrono::steady_clock::now();
        LG_CHECK(worker.start());
        LG_CHECK(worker.wait_until_state(WS::Stopped, 20000ms));
        const double wall = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        const double cpu = cpu_seconds() - c0;
        std::printf("  2 s guest sleep: wall %.3f s, host CPU %.3f s (%.1f %%), idle frames %llu\n", wall, cpu,
                    100.0 * cpu / wall, (unsigned long long)rt.idle_waits());
        LG_CHECK(rt.guest_log() == "nap" && rt.guest_exit().exited && rt.guest_exit().code == 0);
        LG_CHECK(wall >= 1.99 && wall < 10.0);
        LG_CHECK(cpu < 0.1 * wall);                            // R5: waiting, not spinning
        LG_CHECK(rt.idle_waits() < 2000);                      // ~ 2 s / 5 ms = 400 bounded waits
    }
    {
        // stop() during the 2 s sleep returns at once, pause()/resume() work in the middle
        RuntimeCoordinator rt;
        rt.set_guest_memory_budget(64 * MiB);
        rt.set_force_interpreter(true);
        LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
        lg::runtime::RuntimeWorker worker(rt);
        LG_CHECK(worker.start());
        std::this_thread::sleep_for(50ms);
        LG_CHECK(worker.pause() && worker.wait_until_state(WS::Paused, 2000ms));
        LG_CHECK(rt.pause().ok());
        std::this_thread::sleep_for(20ms);
        LG_CHECK(rt.resume().ok() && worker.resume());
        std::this_thread::sleep_for(50ms);
        const auto t0 = std::chrono::steady_clock::now();
        LG_CHECK(worker.stop());
        const double stop_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        std::printf("  stop() during the sleep: %.2f ms\n", stop_ms);
        LG_CHECK(stop_ms < 200.0);
        LG_CHECK(!rt.guest_exit().exited);
        LG_CHECK(rt.stop().ok());
    }
}

void x1_fault_in_thread() {
    std::printf("[X1] a fault in a second thread ends the process\n");
    const std::string path = write_nro("thread_fault", bytes(nro_fixtures::thread_fault));
    for (const auto& e : engines()) {
        RuntimeCoordinator rt;
        rt.set_guest_memory_budget(64 * MiB);
        rt.set_force_interpreter(e.force_interpreter);
        rt.set_jit_fastmem(e.fastmem);
        LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
        const auto err = run_to_end(rt);
        const auto f = rt.last_guest_fault();
        const bool ok = rt.state() == State::Error && err.find("guest fault: data_abort_0x") != std::string::npos &&
                        err.find("@0x8 thread=2") != std::string::npos && f.kind == ExceptionKind::DataAbort && f.address == 8 &&
                        f.thread == 2;
        if (!ok) std::printf("  [%s] %s\n", e.name, err.c_str());
        LG_CHECK(ok);
        const auto marker = rt.debug_read_guest64(rt.process_layout()->code_va + nro_fixtures::thread_fault_after_fault_offset);
        LG_CHECK(marker.has_value() && *marker == 0);                 // the main thread never went on
    }
}
} // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    h3_engines();
    h3_plain_interpreter();
    d1_diagnostics();
    d2_idle_only_when_nothing_runs();
    w1_worker_idle();
    x1_fault_in_thread();
    std::puts("thread process ok");
    return 0;
}
