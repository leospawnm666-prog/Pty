// P3.0-A: NsoLoader::parse (.bss fix, LZ4 bomb limit) and NsoLoader::layout.
//  TA2 real NSOs from switch-tools/elf2nso (LZ4, flags 0x3f) and uncompressed rebuilds; exact
//      extents for unaligned .bss sizes around page boundaries
//  TA3 one corruption per rule (parse and layout), the 32-bit wrap and the LZ4 "bomb"
//  TA4 differential against a verbatim copy of the pre-fix parse(): every input it accepts
//      without a .bss must give an identical image; then fuzzing of parse + layout
#include "../loader/nso_loader.h"
#include "data/nro/nro_fixtures.h"
#include "reference/nso_loader_ref.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

namespace {
int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("  FAIL %s:%d %s\n", __FILE__, __LINE__, #c); std::fflush(stdout); if (++g_fail > 30) std::exit(1); } } while (0)

using lg::loader::NsoImage;
using lg::loader::NsoLayout;
using lg::loader::NsoLoader;

template <size_t N> std::vector<uint8_t> bytes(const unsigned char (&a)[N]) { return {a, a + N}; }
void put32(std::vector<uint8_t>& b, size_t o, uint32_t v) { for (int i = 0; i < 4; ++i) b[o + i] = uint8_t(v >> (8 * i)); }
uint32_t get32(const std::vector<uint8_t>& b, size_t o) { return uint32_t(b[o]) | uint32_t(b[o + 1]) << 8 | uint32_t(b[o + 2]) << 16 | uint32_t(b[o + 3]) << 24; }
constexpr uint64_t page(uint64_t v) { return (v + 0xFFF) & ~uint64_t(0xFFF); }

// Rebuilds an NSO WITHOUT compression from a parsed image (flags 0): same segments, .bss.
std::vector<uint8_t> uncompressed(const NsoImage& img, uint32_t bss) {
    std::vector<uint8_t> f(0x100, 0);
    std::memcpy(f.data(), "NSO0", 4);
    for (size_t i = 0; i < img.segments.size(); ++i) {
        const auto& s = img.segments[i];
        const size_t h = 0x10 + 0x10 * i;
        put32(f, h, uint32_t(f.size()));
        put32(f, h + 4, uint32_t(s.memory_offset));
        put32(f, h + 8, uint32_t(s.bytes.size()));
        put32(f, 0x60 + 4 * i, uint32_t(s.bytes.size()));
        f.insert(f.end(), s.bytes.begin(), s.bytes.end());
    }
    put32(f, 0x3C, bss);
    return f;
}

bool same_image(const NsoImage& a, const NsoImage& b) {
    if (a.flags != b.flags || a.module_id != b.module_id || a.image_base != b.image_base ||
        a.image_size != b.image_size || a.entry_point != b.entry_point || a.segments.size() != b.segments.size())
        return false;
    for (size_t i = 0; i < a.segments.size(); ++i) {
        const auto& x = a.segments[i];
        const auto& y = b.segments[i];
        if (x.name != y.name || x.memory_offset != y.memory_offset || x.memory_size != y.memory_size ||
            x.permissions != y.permissions || x.bytes != y.bytes)
            return false;
    }
    return true;
}

void real_nsos() {
    std::printf("[TA2] real NSOs from elf2nso\n");
    const auto hello = NsoLoader::parse(bytes(nro_fixtures::hello_nso));
    CHECK(hello.ok());
    if (!hello.ok()) { std::printf("  %s\n", hello.error().c_str()); return; }
    const auto& h = hello.value();
    CHECK(h.flags == 0x3F);                                   // LZ4 + hash flags on all three
    CHECK(h.segments.size() == 3);
    CHECK(h.segments[0].memory_offset == 0 && h.segments[0].bytes.size() == 0x13C);
    CHECK(h.segments[1].memory_offset == 0x1000 && h.segments[1].bytes.size() == 0x1E);
    CHECK(h.segments[2].memory_offset == 0x2000 && h.segments[2].bytes.size() == 0x68);
    CHECK(h.segments[2].memory_size == 0x68 + 0x2F98);        // .data + .bss
    CHECK(h.image_size == 0x5000 && h.entry_point == 0);
    // The file holds .data only: its bytes are exactly the NRO's .data bytes.
    const auto nro = bytes(nro_fixtures::hello);
    CHECK(std::memcmp(h.segments[2].bytes.data(), nro.data() + 0x2000, 0x68) == 0);
    CHECK(std::memcmp(h.segments[0].bytes.data() + 0x80, nro.data() + 0x80, 0x13C - 0x80) == 0);
    const auto l = NsoLoader::layout(h);
    CHECK(l.ok());
    if (l.ok()) {
        CHECK(l.value().text.begin == 0 && l.value().text.end == 0x1000);
        CHECK(l.value().ro.begin == 0x1000 && l.value().ro.end == 0x2000);
        CHECK(l.value().rw.begin == 0x2000 && l.value().rw.end == 0x5000);
        CHECK(l.value().data_end == 0x2068 && l.value().bss_end == 0x5000 && l.value().extent == 0x5000);
    }
    const auto big = NsoLoader::parse(bytes(nro_fixtures::bigbss_nso));
    CHECK(big.ok() && big.value().segments[2].memory_size == 8 + 0x4000FF8);
    CHECK(big.ok() && NsoLoader::layout(big.value()).ok() && NsoLoader::layout(big.value()).value().extent == 0x4003000);
    // Near LZ4's maximum ratio (64 KiB of initialised zeros, ~245:1): the anti-"bomb" limit
    // (D-A-2) must accept every legitimate LZ4 stream.
    {
        const auto z = NsoLoader::parse(bytes(nro_fixtures::zeros_nso));
        CHECK(z.ok());
        if (z.ok()) {
            const auto& d = z.value().segments[2];
            CHECK(d.bytes.size() == 0x10000 && d.memory_size == 0x10000);
            CHECK(std::all_of(d.bytes.begin(), d.bytes.end(), [](uint8_t v) { return v == 0; }));
            CHECK(get32(bytes(nro_fixtures::zeros_nso), 0x38) > get32(bytes(nro_fixtures::zeros_nso), 0x68) * 200u);
        }
    }
    for (const auto& f : {bytes(nro_fixtures::guard_nso), bytes(nro_fixtures::write_text_nso)})
        CHECK(NsoLoader::parse(f).ok() && NsoLoader::layout(NsoLoader::parse(f).value()).ok());
    // Uncompressed rebuild: identical content, same extents.
    const auto u = NsoLoader::parse(uncompressed(h, 0x2F98));
    CHECK(u.ok() && u.value().flags == 0);
    for (size_t i = 0; u.ok() && i < 3; ++i) CHECK(u.value().segments[i].bytes == h.segments[i].bytes);
    CHECK(u.ok() && u.value().image_size == 0x5000);
    // .bss sizes around page boundaries: .data ends at 0x2068.
    for (uint32_t bss : {0u, 1u, 0xF97u, 0xF98u, 0xF99u, 0x2F98u, 0x2F99u, 0x10000u}) {
        const auto p = NsoLoader::parse(uncompressed(h, bss));
        CHECK(p.ok());
        if (!p.ok()) continue;
        const auto lay = NsoLoader::layout(p.value());
        CHECK(lay.ok());
        if (!lay.ok()) continue;
        const uint64_t expect = page(0x2068 + uint64_t(bss));
        if (lay.value().rw.end != expect)
            std::printf("  FAIL bss=0x%x rw.end=0x%llx expected 0x%llx\n", bss, (unsigned long long)lay.value().rw.end,
                        (unsigned long long)expect), ++g_fail;
        CHECK(lay.value().bss_end == 0x2068 + uint64_t(bss));
    }
}

void expect_error(const std::vector<uint8_t>& f, const char* needle, bool via_layout, int line) {
    const auto r = NsoLoader::parse(f);
    std::string got;
    if (!r.ok()) got = r.error();
    else if (via_layout) { const auto l = NsoLoader::layout(r.value()); got = l.ok() ? "success" : l.error(); }
    else got = "success";
    if (got.find(needle) == std::string::npos) {
        std::printf("  FAIL line %d: expected \"%s\", got \"%s\"\n", line, needle, got.c_str());
        ++g_fail;
    }
}
#define PARSE_ERROR(f, n) expect_error(f, n, false, __LINE__)
#define LAYOUT_ERROR(f, n) expect_error(f, n, true, __LINE__)

void corruptions() {
    std::printf("[TA3] corruptions, 32-bit wrap, LZ4 bomb\n");
    const auto lz4 = bytes(nro_fixtures::hello_nso);
    const auto base = NsoLoader::parse(lz4).value();
    const auto plain = uncompressed(base, 0x2F98);
    auto m = [](std::vector<uint8_t> f, auto edit) { edit(f); return f; };
    PARSE_ERROR(std::vector<uint8_t>(lz4.begin(), lz4.begin() + 0xFF), "invalid NSO header");
    PARSE_ERROR(m(lz4, [](auto& f) { f[0] = 'X'; }), "invalid NSO header");
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 4, 1); }), "unsupported NSO version");
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 0x24, 0x1800); }), "not page aligned");
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 0x60, 0xFFFF); }), "file range is invalid");
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 0x18, get32(f, 0x18) + 1); }), "LZ4");
    PARSE_ERROR(m(plain, [](auto& f) { put32(f, 0x38, get32(f, 0x38) + 1); }), "uncompressed size mismatch");
    // D-A-2: the "bomb" is refused before any allocation (ASan would flag a 4 GiB request).
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 0x18, 0xFFFFFFFFu); }), "implausible for LZ4");
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 0x38, get32(f, 0x68) * 255u + 17u); }), "implausible for LZ4");
    PARSE_ERROR(m(lz4, [](auto& f) { put32(f, 0x18, 0x40000001u); put32(f, 0x60, 0x400000u); }), "implausible for LZ4");
    // 32-bit wrap: .data 0x68 + .bss 0xFFFFFFA0 used to wrap to 0x8 in 32 bits.
    {
        const auto w = NsoLoader::parse(uncompressed(base, 0xFFFFFFA0u));
        CHECK(w.ok() && w.value().segments[2].memory_size == 0x68ull + 0xFFFFFFA0ull);
        CHECK(w.ok() && w.value().image_size == 0x2000ull + 0x68 + 0xFFFFFFA0ull);
        LAYOUT_ERROR(uncompressed(base, 0xFFFFFFA0u), "1 GiB sanity limit");
    }
    // layout() rules (the strict path only)
    LAYOUT_ERROR(m(plain, [](auto& f) { put32(f, 0x0C, 0x40); }), "unknown header flags");
    LAYOUT_ERROR(m(plain, [](auto& f) { put32(f, 0x14, 0x1000); put32(f, 0x24, 0x3000); put32(f, 0x34, 0x4000); }),
                 ".text does not start");
    LAYOUT_ERROR(m(plain, [](auto& f) { put32(f, 0x24, 0); }), ".rodata overlaps .text");
    LAYOUT_ERROR(m(plain, [](auto& f) { put32(f, 0x34, 0x1000); }), ".data overlaps .rodata");
    LAYOUT_ERROR(m(plain, [](auto& f) { put32(f, 0x3C, 0x40000000u); }), "1 GiB sanity limit");
    {   // no .rodata segment at all
        auto f = plain;
        put32(f, 0x28, 0); put32(f, 0x64, 0);
        LAYOUT_ERROR(f, "expected .text, .rodata and .data");
    }
    {   // empty .text (only .bss-like data)
        auto f = plain;
        put32(f, 0x18, 0); put32(f, 0x60, 0);
        LAYOUT_ERROR(f, "expected .text, .rodata and .data");
    }
}

// Mutates an NSO: header fields, bss, compressed payload bytes, truncation.
std::vector<uint8_t> mutate(std::vector<uint8_t> f, std::mt19937_64& rng, bool zero_bss) {
    const int edits = 1 + int(rng() % 4);
    for (int e = 0; e < edits; ++e) {
        switch (rng() % 6) {
            case 0: f[0x10 + rng() % 0x30] ^= uint8_t(1u << (rng() % 8)); break;
            case 1: put32(f, 0x10 + 4 * (rng() % 12), uint32_t(rng() % 0x3000)); break;
            case 2: put32(f, 0x60 + 4 * (rng() % 3), uint32_t(rng() % 0x200)); break;
            case 3: if (f.size() > 0x100) f[0x100 + rng() % (f.size() - 0x100)] ^= uint8_t(rng()); break;   // payload
            case 4: put32(f, 0x0C, uint32_t(rng() % 0x80)); break;
            case 5: f.resize(0x100 + rng() % (f.size() - 0xFF)); break;
        }
    }
    if (zero_bss) put32(f, 0x3C, 0);
    else if (rng() % 2) put32(f, 0x3C, uint32_t(rng()));
    return f;
}

void differential_and_fuzz(uint64_t iterations, uint64_t seed) {
    std::printf("[TA4] differential vs the pre-fix parse() + fuzzing (%llu, seed %llu)\n",
                (unsigned long long)iterations, (unsigned long long)seed);
    std::mt19937_64 rng(seed);
    const auto h = NsoLoader::parse(bytes(nro_fixtures::hello_nso)).value();
    std::vector<std::vector<uint8_t>> seeds = {bytes(nro_fixtures::hello_nso), bytes(nro_fixtures::guard_nso),
                                               bytes(nro_fixtures::bigbss_nso), bytes(nro_fixtures::zeros_nso),
                                               uncompressed(h, 0), uncompressed(h, 0x2F98)};
    // Seeds without a .bss, so that the old parser accepts them at all.
    for (auto s : std::vector<std::vector<uint8_t>>(seeds)) { put32(s, 0x3C, 0); seeds.push_back(s); }
    uint64_t compared = 0, old_accepted_with_bss = 0, accepted = 0, laid_out = 0, skipped_old = 0;
    for (uint64_t it = 0; it < iterations; ++it) {
        const bool zero_bss = rng() % 2;
        const auto f = mutate(seeds[rng() % seeds.size()], rng, zero_bss);
        const auto neu = NsoLoader::parse(f);
        // The pre-fix parser is itself vulnerable to the LZ4 "bomb" (it reserves the header's
        // size, up to 4 GiB, before checking anything): only feed it inputs whose declared
        // output sizes are small. Every .bss-free input of the differential qualifies.
        const uint64_t old_sizes = uint64_t(get32(f, 0x18)) + get32(f, 0x28) + uint32_t(get32(f, 0x38) + get32(f, 0x3C));
        const bool skip_old = old_sizes > (16u << 20);
        if (skip_old) ++skipped_old;
        const auto old = skip_old ? lg::core::Result<NsoImage>::Error("skipped") : lg::loader::ref::parse(f);
        if (old.ok()) {
            if (get32(f, 0x3C) == 0) {
                ++compared;
                if (!neu.ok() || !same_image(old.value(), neu.value())) {
                    ++g_fail;
                    std::printf("  FAIL differential at iteration %llu: %s\n", (unsigned long long)it,
                                neu.ok() ? "different image" : neu.error().c_str());
                    if (g_fail > 30) std::exit(1);
                }
            } else {
                ++old_accepted_with_bss;   // only when the old sum happened to match: the bug itself
            }
        }
        if (!neu.ok()) continue;
        ++accepted;
        const auto& img = neu.value();
        for (const auto& s : img.segments) {
            CHECK(s.bytes.size() <= s.memory_size);
            CHECK(s.bytes.size() <= NsoLoader::kMaxSegmentSize);
            CHECK(s.memory_offset % 0x1000 == 0);
        }
        const auto l = NsoLoader::layout(img);
        if (!l.ok()) continue;
        ++laid_out;
        const auto& v = l.value();
        CHECK(v.text.begin == 0 && v.text.end <= v.ro.begin && v.ro.end <= v.rw.begin && v.rw.end == v.extent);
        CHECK(v.extent % 0x1000 == 0 && v.extent <= NsoLoader::kMaxImageSize && v.bss_end <= v.extent);
        CHECK(v.bss_end == img.segments[2].memory_offset + img.segments[2].memory_size);
    }
    std::printf("  identical on %llu inputs the old parser accepted without .bss; "
                "%llu old acceptances with .bss (the bug); new accepted %llu, laid out %llu; "
                "old parser skipped %llu times (would reserve > 16 MiB)\n",
                (unsigned long long)compared, (unsigned long long)old_accepted_with_bss,
                (unsigned long long)accepted, (unsigned long long)laid_out, (unsigned long long)skipped_old);
    CHECK(compared > 1000);
}
} // namespace

int main(int argc, char** argv) {
    const uint64_t iterations = argc > 1 ? std::strtoull(argv[1], nullptr, 10) : 100000;
    const uint64_t seed = argc > 2 ? std::strtoull(argv[2], nullptr, 10) : 20260925ull;
    real_nsos();
    corruptions();
    differential_and_fuzz(iterations, seed);
    if (g_fail) { std::printf("nso loader: %d FAILED\n", g_fail); return 1; }
    std::puts("nso loader ok");
    return 0;
}
