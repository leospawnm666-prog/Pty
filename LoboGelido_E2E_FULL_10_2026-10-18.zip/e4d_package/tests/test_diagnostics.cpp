#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include "performance/diagnostics.h"
#include <cassert>
#include <string>
using namespace lg::performance;
int main(){ DiagnosticsCore d; d.set_runtime(false,true,100,false); for(int i=0;i<10;i++) d.record(3.0,12.0,1.0); auto s=d.snapshot(); LG_CHECK(s.samples==10); LG_CHECK(s.bottleneck==Bottleneck::Gpu); LG_CHECK(s.gpu_util>70); auto t=d.summary(); LG_CHECK(t.find("GPU")!=std::string::npos); d.record(2,2,1,3); LG_CHECK(d.snapshot().bottleneck==Bottleneck::Thermal); return 0; }
