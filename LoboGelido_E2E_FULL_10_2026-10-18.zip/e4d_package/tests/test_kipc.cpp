// P3.4: the guest kernel's IPC (ports, sessions, domains) and the HLE services, without a CPU:
// messages are built in the thread's TLS exactly as libnx's hipc.h / cmif.h build them.
//  K1  ConnectToNamedPort: name rules (12 bytes, NUL, InvalidPointer/OutOfRange/NotFound), the
//      session limit (OutOfSessions at once) and its release on CloseHandle
//  K2  SendSyncRequest at the client/server boundary: handles (InvalidHandle, pseudo-handles),
//      move handles refused, copy handles translated, message size, pointer buffer (OutOfResource),
//      A/B/W state and permission (.text, TLS, free memory, stack), mode 2; the TLS keeps the
//      request when the kernel refuses it
//  K3  control commands: QueryPointerBufferSize, Convert (twice), Clone/CloneEx sharing the object
//      or domain, CopyFromCurrentDomain, domain object close and reuse, TargetNotFound,
//      OutOfDomainEntries
//  K4  Close (type 2): SessionClosed now and later, the handle still to be closed
//  K5  sm: RegisterClient/PID, InvalidClient, service-name rules, GetServiceHandle, deferral of a
//      missing service (the thread waits, named in describe_waits) and its retry on
//      register_service; a deferred request whose handle is closed
//  K6  time: GetCurrentTime from the wall clock + GuestClock (manual clock), calendar in UTC
//      (epoch, leap days, year ends, negative time, 2100)
//  K7  fsp-srv: SetCurrentProcess needs the PID, OpenSdCardFileSystem -> SdCardNotPresent
//  K8  the kernel writes the real PID; buffers A/X in and B/C out through a test service
//  K9  unimplemented command / message type -> fatal with the message dump (D3)
//  K10 10^4 open/convert/clone/close cycles in random order: no session or handle left
//  F1  10^5 hostile messages on live sessions (plain, domain): kernel error, reply or fatal,
//      never a host fault; invariants of both kernels after each one
#include "lg_check.h"
#include "vm_test_process.h"
#include "../cpu/guest_clock.h"
#include "../system/cmif.h"
#include "../system/guest_memory.h"
#include "../system/guest_thread_context.h"
#include "../system/handle_table.h"
#include "../system/hipc.h"
#include "../system/hle/hle_services.h"
#include "../system/kipc.h"
#include "../system/kthread.h"
#include "../system/scheduler.h"
#include "../system/svc_dispatcher.h"
#include "../system/thread_manager.h"

#include <array>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <vector>

namespace {
using namespace lg::system;
namespace kr = kresult_ipc;
using lg::cpu::GuestClock;

struct Req {
    uint32_t type{cmif::type::Request};
    bool pid{};
    uint64_t pid_value{0x1234};
    std::vector<uint32_t> copy, move;
    std::vector<hipc::StaticDescriptor> x;
    std::vector<hipc::BufferDescriptor> a, b, w;
    uint32_t recv_mode{};
    std::vector<hipc::ReceiveEntry> c;
    bool domain{};
    uint8_t dtype{cmif::domain_type::SendMessage};
    uint32_t object{};
    bool cmif{true};
    uint32_t magic{cmif::kInMagic};
    uint32_t cmd{};
    std::vector<uint8_t> raw;
    /** hipcMakeRequest + cmifMakeRequest (libnx) layout. */
    hipc::Message build() const {
        hipc::Message m{};
        const bool special = pid || !copy.empty() || !move.empty();
        uint32_t i = 2;
        if (special) {
            m[i++] = (pid ? 1u : 0u) | (static_cast<uint32_t>(copy.size()) << 1) | (static_cast<uint32_t>(move.size()) << 5);
            if (pid) { m[i++] = static_cast<uint32_t>(pid_value); m[i++] = static_cast<uint32_t>(pid_value >> 32); }
            for (auto h : copy) m[i++] = h;
            for (auto h : move) m[i++] = h;
        }
        for (const auto& d : x) { hipc::pack_static(d, &m[i]); i += 2; }
        for (const auto* l : {&a, &b, &w}) for (const auto& d : *l) { hipc::pack_buffer(d, &m[i]); i += 3; }
        const uint32_t data = i;
        uint32_t words = 0;
        if (cmif) {
            const size_t bytes = 16 + (domain ? 16 : 0) + 16 + raw.size();
            words = static_cast<uint32_t>((bytes + 3) / 4);
            uint32_t p = cmif::payload_offset(data);
            auto* b8 = reinterpret_cast<uint8_t*>(m.data());
            if (domain) {
                const uint32_t ds = static_cast<uint32_t>(dtype == cmif::domain_type::Close ? 0 : 16 + raw.size());
                b8[p] = dtype; b8[p + 1] = 0; b8[p + 2] = static_cast<uint8_t>(ds); b8[p + 3] = static_cast<uint8_t>(ds >> 8);
                std::memcpy(b8 + p + 4, &object, 4);
                p += 16;
            }
            if (!(domain && dtype == cmif::domain_type::Close)) {
                const uint32_t h[4] = {magic, 0, cmd, 0};
                std::memcpy(b8 + p, h, 16);
                if (!raw.empty()) std::memcpy(b8 + p + 16, raw.data(), raw.size());
            }
        }
        const uint32_t list = data + words;
        for (size_t k = 0; k < c.size(); ++k) hipc::pack_receive(c[k], &m[list + 2 * k]);
        m[0] = (type & 0xFFFF) | (static_cast<uint32_t>(x.size()) << 16) | (static_cast<uint32_t>(a.size()) << 20) |
               (static_cast<uint32_t>(b.size()) << 24) | (static_cast<uint32_t>(w.size()) << 28);
        m[1] = words | (recv_mode << 10) | (special ? 1u << 31 : 0u);
        return m;
    }
};
template <class T> std::vector<uint8_t> bytes_of(const T& v) {
    std::vector<uint8_t> b(sizeof(T));
    std::memcpy(b.data(), &v, sizeof(T));
    return b;
}

struct Rep {
    uint32_t kernel{};            // w0 of SendSyncRequest
    bool blocked{};
    std::string fatal;
    uint32_t result{~0u};         // CMIF result
    std::vector<uint32_t> copy, move, ids;
    std::vector<uint8_t> raw;     // the out raw data (out_raw bytes)
};

/** A test service: echoes the PID; buffers in (0) and out (1). */
class Probe final : public hle::HleService {
public:
    Probe() : HleService("lobo:probe") {
        add(0, "Pid", [](hle::HleRequest& r) { r.push<uint64_t>(r.has_pid() ? r.pid() : 0); });
        add(1, "ReadIn0", [](hle::HleRequest& r) {
            const auto b = r.read_buffer(0);
            uint64_t sum = 0;
            if (b) for (uint8_t v : *b) sum = sum * 31 + v;
            r.push<uint64_t>(b ? b->size() : ~0ull);
            r.push<uint64_t>(sum);
        });
        add(2, "WriteOut0", [](hle::HleRequest& r) {
            const auto n = r.pop<uint32_t>();
            std::vector<uint8_t> v(n ? std::min<uint32_t>(*n, 0x1000) : 0);   // a guest size is never trusted
            for (size_t i = 0; i < v.size(); ++i) v[i] = static_cast<uint8_t>(0xA0 + i);
            r.push<uint32_t>(r.write_buffer(0, v.data(), v.size()) ? 1u : 0u);
        });
        add(3, "Object", [](hle::HleRequest& r) { r.push_object(std::make_shared<Probe>()); });
        add(4, "ObjectButFail", [](hle::HleRequest& r) {   // an error reply carries no objects
            r.push_object(std::make_shared<Probe>());
            r.push<uint64_t>(1);
            r.set_result(0x1234);
        });
    }
};

/** P6.0: a service that receives a copy handle and answers with a copy and a move handle. */
class EventProbe final : public hle::HleService {
public:
    explicit EventProbe(KernelIpc& ipc) : HleService("lobo:ev"), ipc_(ipc) {
        add(0, "Handles", [this](hle::HleRequest& r) {
            const auto in = r.copy_handle(0);
            r.push<uint32_t>(in ? static_cast<uint32_t>(in->type) : 0xFFu);
            r.push<uint32_t>(static_cast<uint32_t>(r.copy_handle_count()));
            if (!kept_.id) kept_ = ipc_.create_service_event();
            ipc_.signal_service_event(kept_);
            r.push_copy_handle(kept_);
            r.push_move_handle(ipc_.create_service_event());   // its reference goes to the client
        });
    }
    ~EventProbe() override = default;
    KObjectRef kept_{};
private:
    KernelIpc& ipc_;
};

struct Rig {
    vm_test::Process p;
    Scheduler sched;
    ThreadManager tm{sched};
    GuestThreadContextManager ctxs;
    HandleTable handles;
    GuestMemory mem{p.as, p.mmu};
    GuestClock clock;
    KernelThreads k;
    KernelIpc ipc;
    uint64_t main{};
    uint32_t main_handle{};
    int64_t wall0{1700000000};

    explicit Rig(bool services = true) {
        clock.set_manual(true);
        clock.advance(1000);
        KernelThreadsConfig c{};
        c.process_id = 7;
        c.priority_mask = SvcDispatcher::kPriorityMask;
        c.tls_region_base = ProcessLayout::kConfigVa + 0x20000;
        c.tls_region_end = ProcessLayout::kStackRegion + ProcessLayout::kStackRegionSize;
        c.clock = &clock;
        c.handles = &handles;
        c.memory = &mem;
        c.vm = &p.vm;
        c.threads = &tm;
        c.contexts = &ctxs;
        c.host.spawn = [this](uint64_t pc, uint64_t sp) -> uint64_t {
            const auto id = tm.create("guest", 1, [](uint64_t) {});
            return id && ctxs.create(id, pc, sp) ? id : 0;
        };
        LG_CHECK(k.begin(c));
        main = tm.create("main", 1, [](uint64_t) {});
        LG_CHECK(ctxs.create(main, p.l.code_va, p.l.stack_top_va) != nullptr);
        main_handle = *handles.add({KObjectType::Thread, main});
        LG_CHECK(k.register_main_thread(main, main_handle, 44, p.l.tls_va));
        k.update(clock.ticks());
        KernelIpcConfig ic{};
        ic.process_id = 7;
        ic.clock = &clock;
        ic.handles = &handles;
        ic.memory = &mem;
        ic.vm = &p.vm;
        ic.kthreads = &k;
        ic.wall_clock_base = wall0;
        // P6.0: the references a message's handles take (as the coordinator wires them)
        ic.retain = [this](const KObjectRef& o) { return k.add_handle_ref(o) || ipc.add_handle_ref(o) || o.type == KObjectType::Process; };
        ic.release = [this](const KObjectRef& o) { k.on_handle_closed(o); ipc.on_handle_closed(o); };
        LG_CHECK(ipc.begin(ic));
        if (services) LG_CHECK(hle::register_boot_services(ipc));
    }
    KThread& self() { return *k.find(main); }
    uint64_t scratch(int i = 0) const { return p.l.stack_bottom_va + 0x1000 + 0x100ull * static_cast<uint64_t>(i); }
    void check() {
        const std::string a = ipc.check_invariants(), b = k.check_invariants();
        if (!a.empty() || !b.empty()) std::printf("  invariants: ipc '%s' threads '%s'\n", a.c_str(), b.c_str());
        LG_CHECK(a.empty() && b.empty());
    }
    uint32_t connect(const char* name, uint32_t* rc = nullptr) {
        char buf[16] = {};
        std::memcpy(buf, name, std::min<size_t>(std::strlen(name) + 1, sizeof buf));
        LG_CHECK(mem.write(scratch(), buf, sizeof buf));
        uint32_t h = 0;
        const uint32_t r = ipc.connect_to_named_port(scratch(), h);
        if (rc) *rc = r;
        else LG_CHECK(r == 0 && h != 0);
        return h;
    }
    Rep call(uint32_t session, const Req& q, size_t out_raw = 0, bool domain_reply = false) {
        const hipc::Message m = q.build();
        LG_CHECK(mem.write(p.l.tls_va, m.data(), sizeof m));
        k.begin_turn(0, &self(), clock.ticks());
        const auto r = ipc.send_sync_request(self(), session);
        k.end_turn(clock.ticks());
        k.update(clock.ticks());
        check();
        Rep out;
        out.kernel = r.result;
        out.blocked = r.blocked;
        out.fatal = r.fatal;
        if (r.result || r.blocked || !r.fatal.empty()) {
            hipc::Message now{};
            LG_CHECK(mem.read(p.l.tls_va, now.data(), sizeof now));
            if (!r.blocked) LG_CHECK(now == m);                     // nothing written back
            return out;
        }
        parse_reply(out, out_raw, domain_reply);
        return out;
    }
    void parse_reply(Rep& out, size_t out_raw, bool domain_reply) {
        hipc::Message m{};
        LG_CHECK(mem.read(p.l.tls_va, m.data(), sizeof m));
        hipc::Request h;
        LG_CHECK(hipc::parse(m, h) == 0 && h.type == 0);
        out.copy = h.copy_handles;
        out.move = h.move_handles;
        uint32_t pos = cmif::payload_offset(h.data_offset);
        const auto* b = reinterpret_cast<const uint8_t*>(m.data());
        uint32_t nids = 0;
        if (domain_reply) { std::memcpy(&nids, b + pos, 4); pos += 16; }
        uint32_t magic = 0;
        std::memcpy(&magic, b + pos, 4);
        if (magic != cmif::kOutMagic) {
            std::printf("  reply without SFCO (domain=%d):", domain_reply ? 1 : 0);
            for (int i = 0; i < 16; ++i) std::printf(" %08x", m[static_cast<size_t>(i)]);
            std::printf("\n");
        }
        LG_CHECK(magic == cmif::kOutMagic);
        std::memcpy(&out.result, b + pos + 8, 4);
        pos += 16;
        if (out.result == 0) {
            out.raw.assign(b + pos, b + pos + out_raw);
            pos += static_cast<uint32_t>(out_raw);
            for (uint32_t k2 = 0; k2 < nids; ++k2) { uint32_t id; std::memcpy(&id, b + pos + 4 * k2, 4); out.ids.push_back(id); }
        }
    }
    template <class T> T as(const Rep& r, size_t off = 0) {
        T v{};
        LG_CHECK(r.raw.size() >= off + sizeof(T));
        std::memcpy(&v, r.raw.data() + off, sizeof(T));
        return v;
    }
    void close(uint32_t h) {
        const KObjectRef* o = handles.get(h);
        LG_CHECK(o != nullptr);
        const KObjectRef obj = *o;
        LG_CHECK(handles.close(h));
        ipc.on_handle_closed(obj);
        check();
    }
    /** sm: RegisterClient + GetServiceHandle(name) -> session handle. */
    uint32_t service(const char* name) {
        const uint32_t sm = connect("sm:");
        Req reg;
        reg.cmd = 0; reg.pid = true; reg.raw = bytes_of(uint64_t{0});
        LG_CHECK(call(sm, reg).result == 0);
        Req get;
        get.cmd = 1;
        char n[8] = {};
        std::memcpy(n, name, std::strlen(name));
        get.raw.assign(n, n + 8);
        const Rep r = call(sm, get);
        LG_CHECK(r.result == 0 && r.move.size() == 1);
        close(sm);
        return r.move[0];
    }
};

Req control(uint32_t cmd, std::vector<uint8_t> raw = {}) {
    Req q;
    q.type = cmif::type::Control;
    q.cmd = cmd;
    q.raw = std::move(raw);
    return q;
}

// ---------------------------------------------------------------------------------------
void k1_ports() {
    std::printf("[K1] named ports\n");
    Rig r;
    uint32_t rc = 0;
    LG_CHECK(r.connect("nope:", &rc) == 0 && rc == kr::NotFound);
    LG_CHECK(r.connect("abcdefghijk", &rc) == 0 && rc == kr::NotFound);   // 11 chars + NUL: a valid name
    LG_CHECK(r.mem.write(r.scratch(), "abcdefghijkl", 12));              // no NUL in 12 bytes
    uint32_t h = 0;
    LG_CHECK(r.ipc.connect_to_named_port(r.scratch(), h) == kr::OutOfRange && h == 0);
    LG_CHECK(r.ipc.connect_to_named_port(0x10, h) == kr::InvalidPointer);
    LG_CHECK(r.mem.write(r.p.l.stack_top_va - 2, "ab", 2));
    LG_CHECK(r.ipc.connect_to_named_port(r.p.l.stack_top_va - 2, h) == kr::InvalidPointer);      // runs into the guard
    std::vector<uint32_t> hs;
    for (int i = 0; i < KernelIpc::kPortMaxSessions; ++i) hs.push_back(r.connect("sm:"));
    LG_CHECK(r.connect("sm:", &rc) == 0 && rc == kr::OutOfSessions);
    r.close(hs.back());
    hs.pop_back();
    hs.push_back(r.connect("sm:"));
    for (uint32_t x : hs) r.close(x);
    LG_CHECK(r.ipc.session_count() == 0);
    auto f = [] { return std::make_shared<Probe>(); };
    LG_CHECK(!r.ipc.create_named_port("sm:", 1, f) && !r.ipc.create_named_port("", 1, f) &&
             !r.ipc.create_named_port("abcdefghijkl", 1, f) && !r.ipc.create_named_port("x", 0, f));
    LG_CHECK(r.ipc.create_named_port("abcdefghijk", 2, f));
    const uint32_t a = r.connect("abcdefghijk"), b = r.connect("abcdefghijk");
    LG_CHECK(r.connect("abcdefghijk", &rc) == 0 && rc == kr::OutOfSessions);
    r.close(a);
    r.close(b);
}

void k2_boundary() {
    std::printf("[K2] the client/server boundary\n");
    Rig r;
    LG_CHECK(r.ipc.create_named_port("probe", 8, [] { return std::make_shared<Probe>(); }));
    const uint32_t s = r.connect("probe");
    Req pid;
    pid.cmd = 0;
    LG_CHECK(r.call(0x1234, pid).kernel == kr::InvalidHandle);
    LG_CHECK(r.call(HandleTable::kCurrentThread, pid).kernel == kr::InvalidHandle);
    LG_CHECK(r.call(r.main_handle, pid).kernel == kr::InvalidHandle);            // a thread, not a session
    Req mv = pid;
    mv.move = {r.main_handle};
    LG_CHECK(r.call(s, mv).kernel == kr::InvalidCombination);                    // no move handles from a client
    Req cp = pid;
    cp.copy = {r.main_handle, 0, HandleTable::kCurrentThread, HandleTable::kCurrentProcess};
    LG_CHECK(r.call(s, cp, 8).result == 0);                                     // translated (0 and pseudo allowed)
    cp.copy = {r.main_handle, 0x777};
    LG_CHECK(r.call(s, cp).kernel == kr::InvalidHandle);                         // the whole IPC fails
    Req big = pid;
    big.raw.assign(0xE0, 0);                                                    // CMIF + raw beyond 0x100
    LG_CHECK(r.call(s, big).kernel == kr::InvalidCombination);
    // Pointer buffer: 0x8000 bytes of X in total (each 16-aligned), data must be readable.
    const uint64_t text = r.p.l.code_va, stack = r.p.l.stack_bottom_va;
    Req x = pid;
    x.x = {{0, stack, 0x4000}, {1, stack + 0x4000, 0x3FF1}};                      // 0x4000 + align16(0x3FF1) = 0x8000
    LG_CHECK(r.call(s, x, 8).result == 0);
    x.x.push_back({2, stack, 1});
    LG_CHECK(r.call(s, x).kernel == kr::OutOfResource);
    x.x = {{0, 0x10, 0x10}};
    LG_CHECK(r.call(s, x).kernel == kr::InvalidCurrentMemory);
    x.x = {{0, 0x10, 0}};                                                        // size 0: nothing to copy
    LG_CHECK(r.call(s, x, 8).result == 0);
    // Map-alias buffers (SetupForIpcClient): state flag + permission per descriptor kind.
    Req a = pid;
    a.a = {{text, 0x100, 0}};
    LG_CHECK(r.call(s, a, 8).result == 0);                                      // .text is IPC-able and readable
    a.a = {{r.p.l.tls_va, 0x10, 0}};
    LG_CHECK(r.call(s, a).kernel == kr::InvalidCurrentMemory);                   // ThreadLocal: no CanUseIpc
    a.a = {{0x10, 0x10, 0}};
    LG_CHECK(r.call(s, a).kernel == kr::InvalidCurrentMemory);                   // free
    a.a = {{stack, 0x10, 2}};
    LG_CHECK(r.call(s, a).kernel == kr::InvalidCombination);                     // mode 2
    a.a = {{stack, 0x10, 1}};
    LG_CHECK(r.call(s, a, 8).result == 0);                                      // NonSecure
    Req b = pid;
    b.b = {{text, 0x100, 0}};
    LG_CHECK(r.call(s, b).kernel == kr::InvalidCurrentMemory);                   // not writable
    b.b = {{stack + 0x10, 0x2000, 0}};
    LG_CHECK(r.call(s, b, 8).result == 0);
    b.b = {{stack + ProcessLayout::kMainStackSize - 0x10, 0x20, 0}};             // runs past the stack
    LG_CHECK(r.call(s, b).kernel == kr::InvalidCurrentMemory);
    Req w = pid;
    w.w = {{stack, 0, 3}};                                                      // size 0 always passes
    LG_CHECK(r.call(s, w, 8).result == 0);
    r.close(s);
}

void k3_control() {
    std::printf("[K3] control commands and domains\n");
    Rig r;
    const uint32_t t = r.service("time:u");
    Rep q = r.call(t, control(3), 2);
    LG_CHECK(q.result == 0 && r.as<uint16_t>(q) == 0x8000);
    LG_CHECK(!r.call(t, control(9)).fatal.empty());
    // Clone: a second session on the same object
    q = r.call(t, control(2));
    LG_CHECK(q.result == 0 && q.move.size() == 1);
    const uint32_t clone = q.move[0];
    Req get_clock;
    get_clock.cmd = 0;
    q = r.call(clone, get_clock);
    LG_CHECK(q.result == 0 && q.move.size() == 1);                              // non-domain: a session
    r.close(q.move[0]);
    q = r.call(t, control(4, bytes_of(uint32_t{7})));
    LG_CHECK(q.result == 0 && q.move.size() == 1);
    r.close(q.move[0]);
    // Convert: object id 1; again -> NotSupported
    q = r.call(t, control(0), 4);
    LG_CHECK(q.result == 0 && r.as<uint32_t>(q) == 1 && r.ipc.domain_count() == 1);
    LG_CHECK(r.call(t, control(0)).result == cmif::result::NotSupported);
    Req dom;
    dom.domain = true;
    dom.object = 1;
    dom.cmd = 0;
    q = r.call(t, dom, 0, true);
    LG_CHECK(q.result == 0 && q.ids == std::vector<uint32_t>{2} && q.move.empty());   // a domain object
    // A clone of a domain session shares the domain
    q = r.call(t, control(2));
    const uint32_t dclone = q.move.at(0);
    dom.object = 2;                                                             // the clock, via the clone
    Req now = dom;
    now.cmd = 0;
    q = r.call(dclone, now, 8, true);
    LG_CHECK(q.result == 0 && r.as<int64_t>(q) == r.wall0);
    // CopyFromCurrentDomain(2): a plain session to the clock
    q = r.call(t, control(1, bytes_of(uint32_t{2})));
    LG_CHECK(q.result == 0 && q.move.size() == 1);
    Req plain_now;
    plain_now.cmd = 0;
    q = r.call(q.move[0], plain_now, 8);
    LG_CHECK(q.result == 0 && r.as<int64_t>(q) == r.wall0);
    LG_CHECK(r.call(t, control(1, bytes_of(uint32_t{9}))).result == cmif::result::TargetNotFound);
    // Close object 2, then it is gone and its id is reused
    Req close2 = dom;
    close2.dtype = cmif::domain_type::Close;
    LG_CHECK(r.call(t, close2, 0, true).result == 0);
    LG_CHECK(r.call(t, now, 0, true).result == cmif::result::TargetNotFound);
    Req open = dom;
    open.object = 1;
    open.cmd = 3;                                                               // GetTimeZoneService
    q = r.call(t, open, 0, true);
    LG_CHECK(q.result == 0 && q.ids == std::vector<uint32_t>{2});
    // Fill the domain: 64 objects at most
    open.cmd = 0;
    for (uint32_t id = 3; id <= KernelIpc::kDomainMaxObjects; ++id) {
        q = r.call(t, open, 0, true);
        LG_CHECK(q.result == 0 && q.ids == std::vector<uint32_t>{id});
    }
    LG_CHECK(r.call(t, open, 0, true).result == cmif::result::OutOfDomainEntries);
    Req bad = dom;
    bad.dtype = 3;
    LG_CHECK(r.call(t, bad, 0, true).result == cmif::result::InvalidInHeader);
    Req magic = dom;
    magic.magic = 0x42424242;
    LG_CHECK(r.call(t, magic, 0, true).result == cmif::result::InvalidInHeader);
    r.close(dclone);
    r.close(t);
    r.close(clone);
    LG_CHECK(r.ipc.domain_count() == 0);
}

void k4_close() {
    std::printf("[K4] Close\n");
    Rig r;
    const uint32_t s = r.connect("sm:");
    Req c;
    c.type = cmif::type::Close;
    c.cmif = false;
    Rep q = r.call(s, c);
    LG_CHECK(q.kernel == kr::SessionClosed);
    Req reg;
    reg.pid = true;
    reg.raw = bytes_of(uint64_t{0});
    LG_CHECK(r.call(s, reg).kernel == kr::SessionClosed);                      // and every later request
    LG_CHECK(r.ipc.session_count() == 1);                                      // until CloseHandle
    r.close(s);
    LG_CHECK(r.ipc.session_count() == 0);
}

void k5_sm() {
    std::printf("[K5] sm: and deferral\n");
    Rig r;
    const uint32_t sm = r.connect("sm:");
    auto get = [&](const char (&name)[9]) {
        Req q;
        q.cmd = 1;
        q.raw.assign(name, name + 8);
        return r.call(sm, q);
    };
    LG_CHECK(get("time:u\0\0").result == hle::result::SmInvalidClient);        // before RegisterClient
    Req reg;
    reg.cmd = 0;
    reg.raw = bytes_of(uint64_t{0});
    LG_CHECK(r.call(sm, reg).result == cmif::result::InvalidHeaderSize);       // no PID
    reg.pid = true;
    LG_CHECK(r.call(sm, reg).result == 0);
    LG_CHECK(get("\0\0\0\0\0\0\0\0").result == hle::result::SmInvalidServiceName);
    LG_CHECK(get("ab\0c\0\0\0\0").result == hle::result::SmInvalidServiceName);
    Rep q = get("fsp-srv\0");
    LG_CHECK(q.result == 0 && q.move.size() == 1);
    r.close(q.move[0]);
    // On a domain sm session (libnx never converts it) the service still comes as a session.
    {
        const uint32_t sm2 = r.connect("sm:");
        LG_CHECK(r.call(sm2, reg).result == 0);
        LG_CHECK(r.call(sm2, control(0), 4).result == 0);
        Req dget;
        dget.domain = true;
        dget.object = 1;
        dget.cmd = 1;
        const char n[8] = {'f', 's', 'p', '-', 's', 'r', 'v', 0};
        dget.raw.assign(n, n + 8);
        const Rep dq = r.call(sm2, dget, 0, true);
        LG_CHECK(dq.result == 0 && dq.ids.empty() && dq.move.size() == 1);
        r.close(dq.move[0]);
        r.close(sm2);
    }
    // Deferral: the thread waits until the service exists.
    q = get("lobo:x\0\0");
    LG_CHECK(q.blocked && r.self().state == KThreadState::Waiting && r.self().wait == KWaitKind::Ipc);
    LG_CHECK(r.k.describe_waits().find(":ipc@sm::GetServiceHandle(\"lobo:x\")") != std::string::npos);
    LG_CHECK(r.ipc.deferred_count() == 1);
    LG_CHECK(r.ipc.register_service("lobo:x", [] { return std::make_shared<Probe>(); }));
    r.k.update(r.clock.ticks());
    r.check();
    LG_CHECK(r.self().state == KThreadState::Runnable && r.ctxs.get(r.main)->x[0] == 0 && r.ipc.deferred_count() == 0);
    Rep woke;
    r.parse_reply(woke, 0, false);
    LG_CHECK(woke.result == 0 && woke.move.size() == 1);
    Req pid;
    pid.cmd = 0;
    pid.pid = true;
    LG_CHECK(r.as<uint64_t>(r.call(woke.move[0], pid, 8)) == 7);
    r.close(woke.move[0]);
    // A deferred request whose session handle is closed wakes with SessionClosed.
    q = get("lobo:y\0\0");
    LG_CHECK(q.blocked);
    r.close(sm);
    LG_CHECK(r.ipc.register_service("lobo:y", [] { return std::make_shared<Probe>(); }));
    r.k.update(r.clock.ticks());
    LG_CHECK(r.self().state == KThreadState::Runnable && r.ctxs.get(r.main)->x[0] == kr::SessionClosed);
    LG_CHECK(!r.ipc.register_service("lobo:y", [] { return std::make_shared<Probe>(); }));   // taken
    LG_CHECK(!r.ipc.register_service("toolongname", [] { return std::make_shared<Probe>(); }));
}

void k6_time() {
    std::printf("[K6] time\n");
    Rig r;
    const uint32_t t = r.service("time:u");
    Req get;
    get.cmd = 0;
    Rep q = r.call(t, get);
    const uint32_t clock = q.move.at(0);
    Req now;
    now.cmd = 0;
    LG_CHECK(r.as<int64_t>(r.call(clock, now, 8)) == r.wall0);
    r.clock.advance(GuestClock::kFrequency * 5 + 7);
    LG_CHECK(r.as<int64_t>(r.call(clock, now, 8)) == r.wall0 + 5);
    get.cmd = 3;
    const uint32_t tz = r.call(t, get).move.at(0);
    struct Case { int64_t t; uint16_t y; uint8_t mo, d, h, mi, s; uint32_t wday, yday; };
    const Case cases[] = {
        {0, 1970, 1, 1, 0, 0, 0, 4, 0},
        {951782400, 2000, 2, 29, 0, 0, 0, 2, 59},
        {1709251199, 2024, 2, 29, 23, 59, 59, 4, 59},
        {1735689599, 2024, 12, 31, 23, 59, 59, 2, 365},
        {-1, 1969, 12, 31, 23, 59, 59, 3, 364},
        {4102444800, 2100, 1, 1, 0, 0, 0, 5, 0},
    };
    for (const auto& c : cases) {
        Req cal;
        cal.cmd = 101;
        cal.raw = bytes_of(c.t);
        q = r.call(tz, cal, 0x20);
        LG_CHECK(q.result == 0);
        LG_CHECK(r.as<uint16_t>(q, 0) == c.y && q.raw[2] == c.mo && q.raw[3] == c.d && q.raw[4] == c.h && q.raw[5] == c.mi &&
                 q.raw[6] == c.s && q.raw[7] == 0);
        LG_CHECK(r.as<uint32_t>(q, 8) == c.wday && r.as<uint32_t>(q, 12) == c.yday);
        LG_CHECK(std::memcmp(q.raw.data() + 16, "UTC\0\0\0\0\0", 8) == 0 && r.as<uint32_t>(q, 24) == 0 && r.as<int32_t>(q, 28) == 0);
    }
    // (A request without its u64 reads libnx's alignment padding, zeros, as HOS does: 1970.)
    Req shortcal;
    shortcal.cmd = 101;
    q = r.call(tz, shortcal, 0x20);
    LG_CHECK(q.result == 0 && r.as<uint16_t>(q, 0) == 1970);
    Req unknown;
    unknown.cmd = 5;
    const Rep f = r.call(clock, unknown);
    LG_CHECK(f.fatal.find("IPC no implementada: ISystemClock(user) cmd 5") == 0);
    r.close(tz);
    r.close(clock);
    r.close(t);
}

void k7_fsp() {
    std::printf("[K7] fsp-srv\n");
    Rig r;
    const uint32_t f = r.service("fsp-srv");
    Req set;
    set.cmd = 1;
    set.raw = bytes_of(uint64_t{0});
    LG_CHECK(r.call(f, set).result == cmif::result::InvalidHeaderSize);        // SetCurrentProcess needs the PID
    set.pid = true;
    LG_CHECK(r.call(f, set).result == 0);
    Req sd;
    sd.cmd = 18;
    LG_CHECK(r.call(f, sd).result == hle::result::FsSdCardNotPresent);
    r.close(f);
}

void k8_pid_buffers() {
    std::printf("[K8] PID and buffers\n");
    Rig r;
    LG_CHECK(r.ipc.create_named_port("probe", 8, [] { return std::make_shared<Probe>(); }));
    const uint32_t s = r.connect("probe");
    Req pid;
    pid.cmd = 0;
    pid.pid = true;
    pid.pid_value = 0xDEADBEEF;
    LG_CHECK(r.as<uint64_t>(r.call(s, pid, 8)) == 7);                           // the kernel's value, not the guest's
    pid.pid = false;
    LG_CHECK(r.as<uint64_t>(r.call(s, pid, 8)) == 0);
    Req fail;
    fail.cmd = 4;
    const size_t sessions = r.ipc.session_count(), handles = r.handles.size();
    const Rep fr = r.call(s, fail);
    LG_CHECK(fr.result == 0x1234 && fr.move.empty() && fr.copy.empty() && r.ipc.session_count() == sessions && r.handles.size() == handles);
    const uint64_t buf = r.scratch(4);
    std::vector<uint8_t> data(0x40);
    uint64_t sum = 0;
    for (size_t i = 0; i < data.size(); ++i) { data[i] = static_cast<uint8_t>(i * 7); sum = sum * 31 + data[i]; }
    LG_CHECK(r.mem.write(buf, data.data(), data.size()));
    Req in;
    in.cmd = 1;
    in.a = {{buf, 0x40, 0}};
    Rep q = r.call(s, in, 16);
    LG_CHECK(r.as<uint64_t>(q, 0) == 0x40 && r.as<uint64_t>(q, 8) == sum);       // A
    in.a = {{0, 0, 0}};
    in.x = {{0, buf, 0x40}};
    q = r.call(s, in, 16);
    LG_CHECK(r.as<uint64_t>(q, 0) == 0x40 && r.as<uint64_t>(q, 8) == sum);       // X (A empty)
    in.a = {{buf, 0x40, 0}};                                                    // both: A wins (Eden's rule)
    in.x = {{0, buf + 1, 0x20}};
    q = r.call(s, in, 16);
    LG_CHECK(r.as<uint64_t>(q, 0) == 0x40 && r.as<uint64_t>(q, 8) == sum);
    in.a.clear();
    in.x.clear();
    q = r.call(s, in, 16);
    LG_CHECK(r.as<uint64_t>(q, 0) == ~0ull);                                    // no buffer 0
    Req out;
    out.cmd = 2;
    out.raw = bytes_of(uint32_t{0x20});
    out.b = {{buf + 0x80, 0x20, 0}};
    q = r.call(s, out, 4);
    LG_CHECK(r.as<uint32_t>(q) == 1);
    std::vector<uint8_t> got(0x20);
    LG_CHECK(r.mem.read(buf + 0x80, got.data(), got.size()) && got[0] == 0xA0 && got[0x1F] == 0xBF);
    out.b = {{buf + 0x80, 0x10, 0}};
    LG_CHECK(r.as<uint32_t>(r.call(s, out, 4)) == 0);                           // too small
    out.b.clear();
    out.recv_mode = 3;                                                          // one indexed C entry
    out.c = {{buf + 0xC0, 0x20}};
    q = r.call(s, out, 4);
    LG_CHECK(r.as<uint32_t>(q) == 1);
    LG_CHECK(r.mem.read(buf + 0xC0, got.data(), got.size()) && got[0] == 0xA0 && got[0x1F] == 0xBF);
    Rep full;
    r.parse_reply(full, 4, false);
    hipc::Message m{};
    LG_CHECK(r.mem.read(r.p.l.tls_va, m.data(), sizeof m));
    hipc::Request h;
    LG_CHECK(hipc::parse(m, h) == 0 && h.x.size() == 1 && h.x[0].address == buf + 0xC0 && h.x[0].size == 0x20);   // reply X
    r.close(s);
}

void k9_fatal() {
    std::printf("[K9] unimplemented -> fatal with a dump\n");
    Rig r;
    const uint32_t s = r.connect("sm:");
    Req q;
    q.cmd = 2;                                                                  // RegisterService: not in P3.4
    const Rep f = r.call(s, q);
    LG_CHECK(f.fatal.find("IPC no implementada: sm: cmd 2 [00000004 00000008") == 0);
    for (uint32_t type : {0u, 1u, 3u, 16u, 0x1234u}) {
        Req t;
        t.type = type;
        LG_CHECK(r.call(s, t).fatal.find("IPC: tipo de mensaje") == 0);
    }
    r.close(s);
}

void k10_cycles() {
    std::printf("[K10] 10^4 session cycles\n");
    Rig r;
    std::mt19937_64 rng(10);
    const size_t handles0 = r.handles.size();
    std::vector<uint32_t> open;
    for (int i = 0; i < 10000; ++i) {
        const int op = static_cast<int>(rng() % 6);
        if (op == 0 && open.size() < 40) open.push_back(r.service(rng() % 2 ? "time:u" : "fsp-srv"));
        else if (op == 1 && !open.empty()) (void)r.call(open[rng() % open.size()], control(0), 4);
        else if (op == 2 && !open.empty() && open.size() < 40) {
            const Rep q = r.call(open[rng() % open.size()], control(2));
            if (q.result == 0 && q.kernel == 0 && q.move.size() == 1) open.push_back(q.move[0]);
        } else if (op == 3 && !open.empty()) {
            const size_t k = rng() % open.size();
            r.close(open[k]);
            open.erase(open.begin() + static_cast<std::ptrdiff_t>(k));
        } else if (op == 4 && !open.empty()) {
            Req c;
            c.type = cmif::type::Close;
            c.cmif = false;
            (void)r.call(open[rng() % open.size()], c);
        } else if (op == 5 && !open.empty()) {
            (void)r.call(open[rng() % open.size()], control(3), 2);
        }
    }
    for (uint32_t h : open) r.close(h);
    LG_CHECK(r.ipc.session_count() == 0 && r.handles.size() == handles0 && r.ipc.domain_count() == 0);
}

void f1_fuzz() {
    std::printf("[F1] 10^5 hostile messages\n");
    Rig r;
    LG_CHECK(r.ipc.create_named_port("probe", 8, [] { return std::make_shared<Probe>(); }));
    const uint32_t plain = r.service("time:u");
    const uint32_t domain = r.service("fsp-srv");
    LG_CHECK(r.call(domain, control(0), 4).result == 0);
    const uint32_t probe = r.connect("probe");
    std::mt19937_64 rng(0xF1);
    const uint64_t stack = r.p.l.stack_bottom_va;
    const uint64_t addrs[] = {0, 0x10, stack, stack + 0x8000, r.p.l.code_va, r.p.l.tls_va, ~0ull - 0x100, 1ull << 38};
    uint64_t kernel_err = 0, replies = 0, fatals = 0;
    const int iterations = std::getenv("LG_KIPC_FUZZ") ? std::atoi(std::getenv("LG_KIPC_FUZZ")) : 100000;
    for (int i = 0; i < iterations; ++i) {
        Req q;
        q.type = rng() % 8 ? (rng() % 2 ? cmif::type::Request : cmif::type::Control) : static_cast<uint32_t>(rng() % 20);
        q.cmd = static_cast<uint32_t>(rng() % 8 ? rng() % 5 : rng());
        q.pid = rng() & 1;
        const uint32_t target = std::array<uint32_t, 3>{plain, domain, probe}[rng() % 3];
        q.domain = target == domain && rng() % 4;
        q.object = static_cast<uint32_t>(rng() % 4);
        q.dtype = static_cast<uint8_t>(rng() % 3);
        q.raw.resize(rng() % 24);
        for (auto& b : q.raw) b = static_cast<uint8_t>(rng());
        if (rng() % 4 == 0) q.copy.push_back(static_cast<uint32_t>(rng() % 3 ? r.main_handle : rng()));
        if (rng() % 16 == 0) q.move.push_back(r.main_handle);
        if (rng() % 4 == 0) q.x.push_back({static_cast<uint32_t>(rng() % 3), addrs[rng() % 8], rng() % 0x3000});
        if (rng() % 4 == 0) q.a.push_back({addrs[rng() % 8], rng() % 0x3000, static_cast<uint32_t>(rng() % 4)});
        if (rng() % 4 == 0) q.b.push_back({addrs[rng() % 8], rng() % 0x3000, static_cast<uint32_t>(rng() % 4)});
        if (rng() % 8 == 0) { q.recv_mode = static_cast<uint32_t>(rng() % 6); q.c.assign(q.recv_mode > 2 ? q.recv_mode - 2 : q.recv_mode == 2, {addrs[rng() % 8], rng() % 0x100}); }
        if (q.type == cmif::type::Close) continue;                             // would close the live sessions
        if ((q.type == cmif::type::Control || q.type == cmif::type::ControlWithContext) && q.cmd == 0) continue;   // keep plain sessions plain
        if (rng() % 10 == 0) q.magic = static_cast<uint32_t>(rng());
        const bool domain_reply = target == domain && (q.type == cmif::type::Request || q.type == cmif::type::RequestWithContext);
        const Rep rep = r.call(target, q, 0, domain_reply);
        if (!rep.fatal.empty()) ++fatals;
        else if (rep.kernel) ++kernel_err;
        else ++replies;
        // new handles from replies are closed so the table never fills
        hipc::Message m{};
        if (rep.kernel == 0 && rep.fatal.empty() && !rep.blocked) {
            LG_CHECK(r.mem.read(r.p.l.tls_va, m.data(), sizeof m));
            hipc::Request h;
            if (hipc::parse(m, h) == 0) for (uint32_t mh : h.move_handles) r.close(mh);
        }
        if (r.self().state != KThreadState::Runnable) {                        // a deferred sm request: wake it
            LG_CHECK(false);
        }
    }
    std::printf("  kernel errors %llu, replies %llu, fatal %llu; sessions %zu\n", (unsigned long long)kernel_err,
                (unsigned long long)replies, (unsigned long long)fatals, r.ipc.session_count());
    LG_CHECK(kernel_err > 1000 && replies > 1000 && fatals > 1000);
    LG_CHECK(r.ipc.session_count() == 3);
}
} // namespace

// P6.0 (P6_DISENO.md §3.1): copy handles in a request, copy and move handles in a reply.
void k11_handles() {
    std::printf("[K11] copy/move handles of HLE services (P6.0)\n");
    Rig r;
    std::shared_ptr<EventProbe> probe;
    LG_CHECK(r.ipc.create_named_port("ev", 4, [&] { probe = std::make_shared<EventProbe>(r.ipc); return probe; }));
    const uint32_t s = r.connect("ev");
    const size_t events0 = r.k.event_count();
    Req q;
    q.cmd = 0;
    q.copy = {HandleTable::kCurrentThread};
    const Rep a = r.call(s, q, 8);
    LG_CHECK(a.kernel == 0 && a.result == 0 && a.copy.size() == 1 && a.move.size() == 1);
    LG_CHECK(r.as<uint32_t>(a, 0) == static_cast<uint32_t>(KObjectType::Thread) && r.as<uint32_t>(a, 4) == 1);
    LG_CHECK(r.k.event_count() == events0 + 2);
    // the copied event is signaled (WaitSynchronization returns at once), the moved one is not
    for (int i = 0; i < 2; ++i) {
        const uint32_t h = i == 0 ? a.copy[0] : a.move[0];
        LG_CHECK(r.mem.write(r.scratch(1), &h, 4));
        int32_t idx = -1;
        bool blocked = false;
        r.k.begin_turn(0, &r.self(), r.clock.ticks());
        const uint32_t rc = r.k.wait_synchronization(r.self(), r.scratch(1), 1, 0, idx, blocked);
        r.k.end_turn(r.clock.ticks());
        LG_CHECK(i == 0 ? (rc == 0 && idx == 0) : rc == 0xEA01);
    }
    // a second call: the kept event gets a second handle (one more reference)
    const Rep b = r.call(s, q, 8);
    LG_CHECK(b.copy.size() == 1 && b.copy[0] != a.copy[0] && r.k.event_count() == events0 + 3);
    auto close_event = [&](uint32_t h) {   // as SvcHandlers::close_handle: every owner hears of it
        const KObjectRef o = *r.handles.get(h);
        LG_CHECK(r.handles.close(h));
        r.k.on_handle_closed(o);
        r.ipc.on_handle_closed(o);
    };
    for (uint32_t h : {a.copy[0], a.move[0], b.copy[0], b.move[0]}) close_event(h);
    LG_CHECK(r.k.event_count() == events0 + 1);   // the service still holds its event
    r.ipc.release_service_event(probe->kept_);
    LG_CHECK(r.k.event_count() == events0);
    r.close(s);
    r.check();
}

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    k11_handles();
    k1_ports();
    k2_boundary();
    k3_control();
    k4_close();
    k5_sm();
    k6_time();
    k7_fsp();
    k8_pid_buffers();
    k9_fatal();
    k10_cycles();
    f1_fuzz();
    std::puts("kipc ok");
    return 0;
}
