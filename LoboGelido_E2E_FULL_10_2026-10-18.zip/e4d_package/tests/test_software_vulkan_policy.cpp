// Host unit test: software Vulkan policy (no Vulkan headers required).
#include "lg_check.h"
#include "../gpu/software_vulkan_backend.h"
#include "../gpu/vulkan_driver_policy.h"

#include <cstdio>
#include <string>
#include <optional>

int main() {
    using namespace lg::gpu;

    // --- classify ---
    {
        const auto ss = classify_software_driver("/data/app/libvk_swiftshader.so");
        LG_CHECK(ss.kind == SoftwareVulkanKind::SwiftShader);
        LG_CHECK(is_software_vulkan_path("libvk_swiftshader.so"));

        const auto lp = classify_software_driver("/usr/lib/libvulkan_lvp.so");
        LG_CHECK(lp.kind == SoftwareVulkanKind::Lavapipe);

        LG_CHECK(classify_software_driver("libvulkan_freedreno.so").kind == SoftwareVulkanKind::None);
        LG_CHECK(!is_software_vulkan_path("libvulkan.so"));
    }

    // --- parse ---
    {
        LG_CHECK(parse_software_kind("swiftshader") == SoftwareVulkanKind::SwiftShader);
        LG_CHECK(parse_software_kind("LAVAPIPE") == SoftwareVulkanKind::Lavapipe);
        LG_CHECK(parse_software_kind("llvmpipe") == SoftwareVulkanKind::Lavapipe);
        LG_CHECK(parse_software_kind("nope") == SoftwareVulkanKind::None);
    }

    // --- score ---
    {
        const int ss = score_software_device(SoftwareVulkanKind::SwiftShader, 0x1AE0, "SwiftShader Device");
        const int bad = score_software_device(SoftwareVulkanKind::SwiftShader, 0x5143, "Adreno (TM) 740");
        LG_CHECK(ss > bad);
        LG_CHECK(ss >= 100);

        const int lvp = score_software_device(SoftwareVulkanKind::Lavapipe, 0x10005, "llvmpipe (LLVM 15)");
        const int lvp_bad = score_software_device(SoftwareVulkanKind::Lavapipe, 0x13B5, "Mali-G710");
        LG_CHECK(lvp > lvp_bad);
    }

    // --- looks_like_software_gpu ---
    {
        LG_CHECK(looks_like_software_gpu(0x1AE0, "x"));
        LG_CHECK(looks_like_software_gpu(0, "SwiftShader"));
        LG_CHECK(!looks_like_software_gpu(0x5143, "Adreno (TM) 650"));
    }

    // --- driver path policy ---
    {
        auto soft = evaluate_driver_path("/opt/libvk_swiftshader.so", std::optional<uint32_t>{0x13B5}, false);
        LG_CHECK(soft.allowed);
        LG_CHECK(soft.reason.find("software") != std::string::npos);

        // Non-software on Mali host must be rejected by Adreno gate
        auto adreno_on_mali = evaluate_driver_path("/opt/libvulkan_freedreno.so", std::optional<uint32_t>{0x13B5}, false);
        LG_CHECK(!adreno_on_mali.allowed);

        // Non-software on Qualcomm allowed
        auto adreno_on_qcom = evaluate_driver_path("/opt/libvulkan_freedreno.so", std::optional<uint32_t>{0x5143}, false);
        LG_CHECK(adreno_on_qcom.allowed);
    }

    // --- kind names ---
    {
        LG_CHECK(std::string(software_kind_name(SoftwareVulkanKind::SwiftShader)) == "swiftshader");
        LG_CHECK(std::string(software_kind_name(SoftwareVulkanKind::Lavapipe)) == "lavapipe");
    }

    
    // --- write ICD json ---
    {
        const char* tmp = std::getenv("TMPDIR");
        std::string dir = tmp && *tmp ? tmp : "/tmp";
        dir += "/lobo_sw_vk_test";
        auto written = write_software_icd_json("/opt/libvk_swiftshader.so",
                                              SoftwareVulkanKind::SwiftShader, dir);
        LG_CHECK(written.ok());
        LG_CHECK(!written.value().path.empty());
        std::FILE* f = std::fopen(written.value().path.c_str(), "r");
        LG_CHECK(f != nullptr);
        if (f) std::fclose(f);
    }

        {
        auto rep = resolve_software_library_report(SoftwareVulkanKind::None);
        LG_CHECK(std::string(rep.source) == "none");
        LG_CHECK(rep.path.empty());
    }

    std::printf("test_software_vulkan_policy: OK\n");
    return 0;
}
