// P2 phase E.2a: Dynarmic page table (inline fast path for arena pages).
//  [1] loads/stores to RW arena pages stop going through the callbacks
//  [2] read-only and sparse pages stay on the callbacks; a write to RO memory still faults
//  [3] the guest writes code through the table, runs it, rewrites it (now watched) and
//      runs the new version
//  [4] SMC through a VA alias whose table entry was filled before the page became code
//  [5] MMU remap of a data page: the JIT reads the new physical page
//  [6] an access crossing into a page mapped to an unrelated physical page is split right
//  [7] a new alias of a page that is already code never enters the table
#include "../cpu/dynarmic_provider.h"
#include "../cpu/interpreter.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"

#include <cstdio>
#include <cstdlib>

#if !defined(LOBOGELIDO_HAS_DYNARMIC)
int main() { std::puts("dynarmic page table: skipped (Dynarmic not linked)"); return 0; }
#else

namespace {
int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("  FAIL %s:%d %s\n", __FILE__, __LINE__, #c); if (++g_fail > 20) std::exit(1); } } while (0)

using lg::cpu::CpuState;
using lg::cpu::DynarmicProvider;
using lg::memory::AddressSpace;
using lg::memory::Mmu;
constexpr uint64_t P = 4096;
constexpr uint32_t R = lg::memory::Read, W = lg::memory::Write, X = lg::memory::Execute;
constexpr uint64_t kBase = 0x10000000;                      // arena, identity-mapped
constexpr uint32_t b_rel(int32_t n) { return 0x14000000u | (static_cast<uint32_t>(n) & 0x03FFFFFFu); }
constexpr uint32_t movz_x0(uint32_t imm) { return 0xD2800000u | (imm << 5); }
constexpr uint32_t kStrX0X1 = 0xF9000020u;                  // str x0, [x1]
constexpr uint32_t kLdrX3X1 = 0xF9400023u;                  // ldr x3, [x1]
constexpr uint32_t kStrW2X1 = 0xB9000022u;                  // str w2, [x1]
constexpr uint32_t kAddX0 = 0x91000400u;                    // add x0, x0, #1
constexpr uint32_t kBrX4 = 0xD61F0080u;                     // br x4

struct Rig {
    AddressSpace as;
    Mmu mmu;
    lg::cpu::Interpreter fallback{as, mmu};
    DynarmicProvider jit{as, mmu, fallback};
    Rig() {
        CHECK(as.enable_fastmem(64 * P, kBase));
        CHECK(as.map(kBase, 64 * P));
        CHECK(jit.initialize().ok());
    }
    void code(uint64_t va, std::initializer_list<uint32_t> words) { for (uint32_t w : words) { as.write32(va, w); va += 4; } }
    bool run(CpuState& s, uint64_t q = 64) { return jit.execute(s, q).ok(); }
};

void fast_path_used() {
    std::printf("[1] RW arena data goes through the page table\n");
    Rig r;
    CHECK(r.mmu.map(kBase, kBase, P, R | X));
    CHECK(r.mmu.map(kBase + 8 * P, kBase + 8 * P, P, R | W));
    r.code(kBase, {kStrX0X1, kAddX0, kLdrX3X1, b_rel(-3)});
    CpuState s{}; s.pc = kBase; s.x[1] = kBase + 8 * P;
    CHECK(r.run(s));
    CHECK(r.run(s));
    const auto warm = r.jit.code_stats();
    CHECK(warm.page_table_fills >= 1);
    for (int i = 0; i < 100; ++i) CHECK(r.run(s));
    const auto st = r.jit.code_stats();
    CHECK(st.callback_accesses == warm.callback_accesses);   // no callback in 100 quanta
    CHECK(r.as.read64(kBase + 8 * P) == s.x[3]);
    CHECK(s.x[3] + 1 == s.x[0]);
}

void readonly_and_sparse_stay_on_callbacks() {
    std::printf("[2] read-only / sparse pages use the callbacks; RO writes still fault\n");
    Rig r;
    // Everything mapped up front: an MMU change empties the table, which would hide a
    // read-only page wrongly placed in it.
    CHECK(r.mmu.map(kBase, kBase, P, R | X));
    CHECK(r.mmu.map(kBase + 4 * P, kBase + 4 * P, P, R | X));
    CHECK(r.mmu.map(kBase + 8 * P, kBase + 8 * P, P, R));   // read-only data
    CHECK(r.as.map(0x40000000, P));                           // sparse (outside the arena)
    CHECK(r.mmu.map(0x40000000, 0x40000000, P, R | W));
    r.as.write64(kBase + 8 * P, 77);
    r.code(kBase, {kLdrX3X1, b_rel(0)});
    CpuState s{}; s.pc = kBase; s.x[1] = kBase + 8 * P;
    CHECK(r.run(s)); CHECK(s.x[3] == 77);
    const auto a = r.jit.code_stats();
    CHECK(r.run(s));
    CpuState t{}; t.pc = kBase; t.x[1] = 0x40000000;             // sparse RW page
    r.as.write64(0x40000000, 5);
    CHECK(r.run(t)); CHECK(t.x[3] == 5);
    CHECK(r.jit.code_stats().page_table_fills == a.page_table_fills);   // neither was filled
    // A store to the read-only page must fault (permission), as with the interpreter.
    r.code(kBase + 4 * P, {kStrX0X1, b_rel(0)});
    CpuState u{}; u.pc = kBase + 4 * P; u.x[1] = kBase + 8 * P; u.x[0] = 1;
    CHECK(!r.run(u));
    CHECK(u.exception.kind == lg::cpu::ExceptionKind::DataAbort);
    CHECK(r.as.read64(kBase + 8 * P) == 77u);
}

void code_written_through_table() {
    std::printf("[3] guest writes code via the table, runs it, rewrites it, runs the new code\n");
    Rig r;
    CHECK(r.mmu.map(kBase, kBase, P, R | X));
    CHECK(r.mmu.map(kBase + 8 * P, kBase + 8 * P, P, R | W | X));   // RWX: data AND code
    const uint64_t target = kBase + 8 * P;
    // writer: str w2,[x1] ; br x4   (x1 = x4 = target)
    r.code(kBase, {kStrW2X1, kBrX4});
    // First make the page a TABLE page with plain data traffic.
    CpuState s{}; s.pc = kBase; s.x[1] = target; s.x[4] = target;
    r.as.write32(target + 4, b_rel(0));                             // B . after the patched word
    s.x[2] = movz_x0(11);
    CHECK(r.run(s, 16));                                            // writes MOVZ X0,#11 and runs it
    CHECK(s.x[0] == 11);
    const auto fills = r.jit.code_stats().page_table_fills;
    CHECK(fills >= 1);
    CHECK(r.as.is_code_page(target));                               // now watched
    // Rewrite it: the entry was removed when the page became code, so the store reaches
    // the callbacks and invalidates.
    s.pc = kBase; s.x[2] = movz_x0(22);
    CHECK(r.run(s, 16));
    CHECK(s.x[0] == 22);
    CHECK(r.jit.code_stats().page_table_clears >= 1);
}

void alias_filled_before_code() {
    std::printf("[4] SMC through a VA alias filled before the page became code\n");
    Rig r;
    const uint64_t code = kBase + 16 * P, alias = 0x50000000, writer = kBase;
    CHECK(r.mmu.map(writer, writer, P, R | X));
    CHECK(r.mmu.map(code, code, P, R | X));
    CHECK(r.mmu.map(alias, code, P, R | W));                        // RW alias of the code page
    r.code(writer, {kStrW2X1, b_rel(0)});
    // 1) data traffic through the alias fills its table entry
    CpuState w{}; w.pc = writer; w.x[1] = alias + 0x100; w.x[2] = 1;
    CHECK(r.run(w, 8));
    CHECK(r.jit.code_stats().page_table_fills >= 1);
    // 2) the page becomes code
    r.code(code, {movz_x0(1), b_rel(-1)});
    CpuState c{}; c.pc = code;
    CHECK(r.run(c)); CHECK(c.x[0] == 1);
    // 3) the alias rewrites it: its entry must be gone, so the store is seen
    w.pc = writer; w.x[1] = alias; w.x[2] = movz_x0(9);
    CHECK(r.run(w, 8));
    CHECK(r.run(c)); CHECK(c.x[0] == 9);
}

void mmu_remap_data() {
    std::printf("[5] MMU remap of a data page\n");
    Rig r;
    CHECK(r.mmu.map(kBase, kBase, P, R | X));
    CHECK(r.mmu.map(0x60000000, kBase + 20 * P, P, R | W));
    r.as.write64(kBase + 20 * P, 111);
    r.as.write64(kBase + 21 * P, 222);
    r.code(kBase, {kLdrX3X1, b_rel(0)});
    CpuState s{}; s.pc = kBase; s.x[1] = 0x60000000;
    CHECK(r.run(s)); CHECK(s.x[3] == 111);
    CHECK(r.mmu.unmap(0x60000000, P));
    CHECK(r.mmu.map(0x60000000, kBase + 21 * P, P, R | W));
    s.pc = kBase;
    CHECK(r.run(s)); CHECK(s.x[3] == 222);
}

void page_crossing() {
    std::printf("[6] access crossing into an unrelated physical page\n");
    Rig r;
    CHECK(r.mmu.map(kBase, kBase, P, R | X));
    // VA pages 0x70000000 and +P map to NON-adjacent physical pages.
    CHECK(r.mmu.map(0x70000000, kBase + 30 * P, P, R | W));
    CHECK(r.mmu.map(0x70000000 + P, kBase + 40 * P, P, R | W));
    r.code(kBase, {kStrX0X1, kLdrX3X1, b_rel(0)});
    CpuState s{}; s.pc = kBase; s.x[1] = 0x70000000 + P - 4; s.x[0] = 0x1122334455667788ull;
    CHECK(r.run(s, 4)); CHECK(r.run(s, 4));                         // twice: table filled by now
    CHECK(s.x[3] == 0x1122334455667788ull);
    CHECK(r.as.read32(kBase + 30 * P + P - 4) == 0x55667788u);       // low half, first page
    CHECK(r.as.read32(kBase + 40 * P) == 0x11223344u);               // high half, OTHER page
    CHECK(r.as.read32(kBase + 31 * P) == 0u);                        // not the adjacent one
}
void new_alias_after_code() {
    std::printf("[7] a NEW alias of a page that is already code never enters the table\n");
    Rig r;
    const uint64_t code = kBase + 16 * P, alias = 0x58000000, writer = kBase;
    CHECK(r.mmu.map(writer, writer, P, R | X));
    CHECK(r.mmu.map(code, code, P, R | X));
    CHECK(r.mmu.map(alias, code, P, R | W));
    r.code(code, {movz_x0(1), b_rel(-1)});
    CpuState c{}; c.pc = code;
    CHECK(r.run(c)); CHECK(c.x[0] == 1);                            // page is code now
    // First-ever access through the alias: a read (slow path), then writes.
    r.code(writer, {kLdrX3X1, kStrW2X1, b_rel(0)});
    CpuState w{}; w.pc = writer; w.x[1] = alias; w.x[2] = movz_x0(4);
    CHECK(r.run(w, 8));
    CHECK(r.run(c)); CHECK(c.x[0] == 4);
    w.pc = writer; w.x[2] = movz_x0(6);                              // and again
    CHECK(r.run(w, 8));
    CHECK(r.run(c)); CHECK(c.x[0] == 6);
}
} // namespace

int main() {
    fast_path_used();
    readonly_and_sparse_stay_on_callbacks();
    code_written_through_table();
    alias_filled_before_code();
    mmu_remap_data();
    page_crossing();
    new_alias_after_code();
    if (g_fail) { std::printf("dynarmic page table: %d FAILED\n", g_fail); return 1; }
    std::puts("dynarmic page table ok");
    return 0;
}
#endif
