// P3.5: guest_report (instruction families, the 4-line summary, UTF-8 truncation) and the JIT
// smoke test.
//  F1 a64_instruction_family / a64_is_simd_or_fp on one word of every top-level group
//  F2 undefined_instruction_note on the interpreter and on the JIT
//  U1 utf8_truncate never splits a sequence
//  U2 utf8_sanitize_bmp (what JNI's NewStringUTF accepts)
//  G1 format_guest_summary: every phase, last non-empty line, control characters, long error
//  J1 the smoke NRO parses; on the interpreter it stops at its first FP word (it really needs
//     FP/AdvSIMD); run_jit_smoke is ok on the JIT (skipped without one); a failing image is
//     "failed" with the exit code; a marker of the same build means "crashed_before" and is
//     kept, one of another build is replaced
#include "lg_check.h"
#include "../loader/nro_loader.h"
#include "../runtime/guest_report.h"
#include "../runtime/jit_smoke.h"
#include "../runtime/runtime_coordinator.h"

#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>

namespace {
namespace fs = std::filesystem;
using namespace lg::runtime;

void f1_families() {
    std::printf("[F1] instruction families\n");
    struct Case { uint32_t w; const char* family; bool simd; };
    const Case cases[] = {
        {0x6F00E400, "AdvSIMD/FP", true},                          // movi v0.2d, #0
        {0x4EE08400, "AdvSIMD/FP", true},                          // add v0.2d, v0.2d, v0.2d
        {0x1E602000, "AdvSIMD/FP", true},                          // fcmp d0, d0
        {0x9E670120, "AdvSIMD/FP", true},                          // fmov d0, x9
        {0x3CC18660, "AdvSIMD/FP (carga/almacenamiento)", true},   // ldr q0, [x19], #0x18
        {0xAD7F07E0, "AdvSIMD/FP (carga/almacenamiento)", true},   // ldp q0, q1, [sp, #-32]
        {0x04A00000, "SVE", true},
        {0x00000000, "reservada (UDF)", false},                    // udf #0
        {0x02000000, "no asignada", false},
        {0x06000000, "no asignada", false},
        {0x91000000, "procesamiento de datos (inmediato)", false}, // add x0, x0, #0
        {0xD2800549, "procesamiento de datos (inmediato)", false}, // mov x9, #42
        {0x8B000000, "procesamiento de datos (registro)", false},  // add x0, x0, x0
        {0x9AC00C00, "procesamiento de datos (registro)", false},  // sdiv x0, x0, x0
        {0xF9400000, "carga/almacenamiento", false},               // ldr x0, [x0]
        {0xC85F7C00, "carga/almacenamiento", false},               // ldxr x0, [x0]
        {0xD53BD040, "sistema (MSR/MRS/SYS)", false},              // mrs x0, tpidr_el0
        {0xD503201F, "sistema (MSR/MRS/SYS)", false},              // nop
        {0xD4000001, "salto/excepción", false},                    // svc #0
        {0x14000000, "salto/excepción", false},                    // b .
        {0xD65F03C0, "salto/excepción", false},                    // ret
    };
    for (const auto& c : cases) {
        const std::string got = a64_instruction_family(c.w);
        if (got != c.family || a64_is_simd_or_fp(c.w) != c.simd)
            std::printf("  0x%08x: '%s' simd=%d, want '%s' simd=%d\n", c.w, got.c_str(), a64_is_simd_or_fp(c.w), c.family, c.simd);
        LG_CHECK(got == c.family && a64_is_simd_or_fp(c.w) == c.simd);
    }
}

void f2_note() {
    std::printf("[F2] undefined-instruction note\n");
    LG_CHECK(undefined_instruction_note(0x6F00E400, true) == " [AdvSIMD/FP: no soportada por el intérprete; usa la JIT]");
    LG_CHECK(undefined_instruction_note(0x6F00E400, false) == " [AdvSIMD/FP]");
    LG_CHECK(undefined_instruction_note(0x04A00000, true) == " [SVE: no soportada por el intérprete; usa la JIT]");
    LG_CHECK(undefined_instruction_note(0x00000000, true) == " [reservada (UDF)]");
    LG_CHECK(undefined_instruction_note(0xD53BD040, true) == " [sistema (MSR/MRS/SYS)]");
}

void u1_truncate() {
    std::printf("[U1] UTF-8 truncation\n");
    LG_CHECK(utf8_truncate("abc", 3) == "abc");
    LG_CHECK(utf8_truncate("abcdef", 5) == "ab\xE2\x80\xA6");
    const std::string s = "a\xC3\xB1\xC3\xB1\xC3\xB1";   // "añññ" (2-byte ñ)
    for (size_t max = 0; max <= s.size() + 1; ++max) {
        const std::string t = utf8_truncate(s, max);
        LG_CHECK(t.size() <= std::max<size_t>(max, 3));
        // never ends inside a sequence: every lead byte has its continuation bytes
        size_t i = 0;
        bool ok = true;
        while (i < t.size()) {
            const unsigned char c = static_cast<unsigned char>(t[i]);
            const size_t n = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : 4;
            if (i + n > t.size()) { ok = false; break; }
            for (size_t k = 1; k < n; ++k) ok = ok && (static_cast<unsigned char>(t[i + k]) & 0xC0) == 0x80;
            i += n;
        }
        LG_CHECK(ok);
    }
}

void u2_sanitize() {
    std::printf("[U2] UTF-8 for JNI (BMP only)\n");
    LG_CHECK(utf8_sanitize_bmp("hola \xC3\xB1 \xE2\x80\xA6") == "hola \xC3\xB1 \xE2\x80\xA6");
    LG_CHECK(utf8_sanitize_bmp(std::string("a\0b", 3)) == "ab");
    LG_CHECK(utf8_sanitize_bmp("\xF0\x9F\x98\x80!") == "?!");        // U+1F600: 4 bytes -> one '?'
    LG_CHECK(utf8_sanitize_bmp("\xFF\xC3") == "??");                    // invalid, truncated
    LG_CHECK(utf8_sanitize_bmp("\xC0\xAF") == "?");                     // overlong "/": one sequence, one ?
    LG_CHECK(utf8_sanitize_bmp("\xED\xA0\x80") == "?");                // surrogate U+D800
    LG_CHECK(utf8_sanitize_bmp("\xE2\x28\xA1") == "?(?");
}

void g1_summary() {
    std::printf("[G1] guest summary\n");
    using P = GuestSummaryInput::Phase;
    GuestSummaryInput in;
    LG_CHECK(format_guest_summary(in) == "Estado: sin sesión\nÚltimo log: (ninguno)\nHilos: 0/0 · IPC: 0 · SVC: 0");
    in.phase = P::Running;
    in.log = "uno\ndos\n\n  \n";
    in.live_threads = 2; in.total_threads = 3; in.ipc_requests = 17; in.svc_calls = 99;
    LG_CHECK(format_guest_summary(in) == "Estado: ejecutando\nÚltimo log: dos\nHilos: 2/3 · IPC: 17 · SVC: 99");
    in.log = "sin salto de línea\x01" "final";
    LG_CHECK(format_guest_summary(in).find("\nÚltimo log: sin salto de línea final\n") != std::string::npos);
    in.log = "emoji \xF0\x9F\x98\x80\n";
    LG_CHECK(format_guest_summary(in).find("\nÚltimo log: emoji ?\n") != std::string::npos);
    in.phase = P::Stopped; in.exited = true; in.has_code = true; in.code = -3;
    LG_CHECK(format_guest_summary(in).rfind("Estado: terminado (código -3)\n", 0) == 0);
    in.has_code = false;
    LG_CHECK(format_guest_summary(in).rfind("Estado: terminado\n", 0) == 0);
    in.phase = P::Paused;
    LG_CHECK(format_guest_summary(in).rfind("Estado: en pausa\n", 0) == 0);
    in.phase = P::Ready;
    LG_CHECK(format_guest_summary(in).rfind("Estado: preparado\n", 0) == 0);
    in.phase = P::Error;
    in.error = std::string(300, 'x');
    const std::string s = format_guest_summary(in);
    const auto e = s.find("\nError: ");
    LG_CHECK(e != std::string::npos);
    const auto eol = s.find('\n', e + 1);
    LG_CHECK(eol - (e + 8) == 200 && s.substr(eol - 3, 3) == "\xE2\x80\xA6");
    in.log = std::string(500, 'y');
    const std::string s2 = format_guest_summary(in);
    const auto l = s2.find("\nÚltimo log: ");
    LG_CHECK(s2.find('\n', l + 1) - (l + std::string("\nÚltimo log: ").size()) == 120);
    // exactly 4 lines with an error, 3 without
    size_t lines = 1;
    for (char c : s2) lines += c == '\n';
    LG_CHECK(lines == 4);
}

void j1_smoke() {
    std::printf("[J1] JIT smoke test\n");
    const auto image = jit_smoke_nro();
    const auto parsed = lg::loader::NroLoader::parse(image);
    LG_CHECK(parsed.ok());
    const fs::path dir = fs::temp_directory_path() / "lobo_p35_jit_smoke";
    fs::remove_all(dir);
    // The image needs FP/AdvSIMD: the interpreter stops at its second instruction.
    {
        const fs::path p = fs::temp_directory_path() / "lobo_p35_jit_smoke_block.nro";
        std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(image.data()), long(image.size()));
        RuntimeCoordinator rt;
        rt.set_guest_memory_budget(16ull << 20);
        rt.set_force_interpreter(true);
        LG_CHECK(rt.prepare(p.string()).ok() && rt.start().ok());
        std::string err;
        for (int i = 0; i < 1000 && rt.state() == State::Running; ++i) {
            const auto r = rt.run_frame(rt.entry_point());
            if (!r.ok()) { err = r.error(); break; }
        }
        LG_CHECK(err.find("undefined_0x9e670120@0x") != std::string::npos &&
                 err.find(" [AdvSIMD/FP: no soportada por el intérprete; usa la JIT]") != std::string::npos);
        LG_CHECK(rt.last_guest_fault().pc == rt.process_layout()->code_va + 0x84);
        std::printf("  interpreter: %s\n", err.c_str());
    }
    const auto r = run_jit_smoke(dir.string(), "build-A");
    std::printf("  run_jit_smoke: %s %s\n", jit_smoke_status_name(r.status), r.detail.c_str());
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    LG_CHECK(r.status == JitSmokeResult::Status::Ok && r.detail.empty());
    LG_CHECK(!fs::exists(dir / "jit_smoke.inprogress") && !fs::exists(dir / "jit_smoke.nro"));
    // a program that returns something else
    auto bad = image;
    bad[0x80] = 0xE9;   // mov x9, #42 -> mov x9, #47: fmov/add give 94
    const auto f = run_jit_smoke_image(dir.string(), "build-A", bad);
    LG_CHECK(f.status == JitSmokeResult::Status::Failed && f.detail == "exit code 94");
    // a marker of this build: the previous run died; it stays
    std::ofstream(dir / "jit_smoke.inprogress") << "build-A";
    const auto c = run_jit_smoke(dir.string(), "build-A");
    LG_CHECK(c.status == JitSmokeResult::Status::CrashedBefore && fs::exists(dir / "jit_smoke.inprogress"));
    // another build tries again
    const auto n = run_jit_smoke(dir.string(), "build-B");
    LG_CHECK(n.status == JitSmokeResult::Status::Ok && !fs::exists(dir / "jit_smoke.inprogress"));
#else
    LG_CHECK(r.status == JitSmokeResult::Status::Skipped && r.detail == "built without the JIT");
#endif
    LG_CHECK(run_jit_smoke("", "x").status == JitSmokeResult::Status::Skipped);   // no scratch directory
    LG_CHECK(std::string(jit_smoke_status_name(JitSmokeResult::Status::CrashedBefore)) == "crashed_before");
    fs::remove_all(dir);
}
} // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    f1_families();
    f2_note();
    u1_truncate();
    u2_sanitize();
    g1_summary();
    j1_smoke();
    std::puts("guest report ok");
    return 0;
}
