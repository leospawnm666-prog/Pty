// End-to-end test of dynamic Vulkan dispatch, vendor gating and custom->system fallback,
// driven by real dlopen()ed fake drivers (fake_icd.cpp). Headless (no surface).
//
// Build/run: tests/vulkan_dispatch/run.sh <vulkan-headers-include-dir>
#include "gpu/adreno_driver_loader.h"
#include "gpu/android_vulkan_context.h"
#include "gpu/vk_dispatch.h"
#include "gpu/vulkan_driver_policy.h"

#include <dlfcn.h>

#include <cstdio>
#include <cstdlib>
#include <string>

namespace {

int g_failures = 0;
#define CHECK(cond) do { if (!(cond)) { std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++g_failures; } } while (0)

// Holds a reference to a fake driver so its counters survive the context's dlclose.
struct Probe {
    void* h{};
    int (*calls)(const char*){};
    int (*live_instances)(){};
    int (*live_devices)(){};
    const char* (*events)(){};
    void (*reset)(){};
    explicit Probe(const std::string& path) {
        h = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
        if (!h) { std::printf("cannot open %s: %s\n", path.c_str(), dlerror()); std::exit(2); }
        calls = reinterpret_cast<int (*)(const char*)>(dlsym(h, "fake_calls"));
        live_instances = reinterpret_cast<int (*)()>(dlsym(h, "fake_live_instances"));
        live_devices = reinterpret_cast<int (*)()>(dlsym(h, "fake_live_devices"));
        events = reinterpret_cast<const char* (*)()>(dlsym(h, "fake_events"));
        reset = reinterpret_cast<void (*)()>(dlsym(h, "fake_reset"));
    }
    ~Probe() { if (h) dlclose(h); }
    int n(const char* f) const { return calls(f); }
};

bool contains(const std::string& hay, const std::string& needle) { return hay.find(needle) != std::string::npos; }

void table_is_clear() {
    using namespace lg::gpu::vkfn;
    CHECK(vkGetInstanceProcAddr == nullptr);
    CHECK(vkCreateInstance == nullptr);
    CHECK(vkCreateDevice == nullptr);
    CHECK(vkQueueSubmit == nullptr);
    CHECK(vkDestroyInstance == nullptr);
}

} // namespace

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s <dir-with-fake-drivers>\n", argv[0]); return 2; }
    const std::string dir = argv[1];
    const std::string sys_mali = dir + "/fake_sys_mali.so";
    const std::string sys_adreno = dir + "/fake_sys_adreno.so";
    const std::string turnip = dir + "/fake_turnip.so";
    const std::string turnip_bad = dir + "/fake_turnip_baddevice.so";
    const std::string turnip_icd = dir + "/fake_turnip_icdonly.so";
    const std::string wrong_vendor = dir + "/fake_custom_wrongvendor.so";
    const std::string kgsl_present = dir + "/fake_kgsl_node";   // file created by run.sh
    const std::string kgsl_absent = dir + "/no_such_node";

    Probe mali(sys_mali), sadreno(sys_adreno), tu(turnip), tubad(turnip_bad), tuicd(turnip_icd), wv(wrong_vendor);

    // 1. No custom driver -> system driver, no fallback, everything served by it.
    {
        std::printf("[1] system driver only (Mali host)\n");
        lg::gpu::AndroidVulkanContext ctx({sys_mali, kgsl_absent});
        auto r = ctx.initialize(nullptr, {});
        CHECK(r.ok());
        CHECK(std::string(ctx.driver_kind()) == "system");
        CHECK(ctx.vendor_id() == lg::gpu::kVendorArm);
        CHECK(ctx.fallback_reason().empty());
        CHECK(mali.n("vkCreateDevice") == 1);
        const int before = mali.n("vkQueueSubmit");
        lg::gpu::vkfn::vkQueueSubmit(static_cast<VkQueue>(ctx.graphics_queue_handle()), 0, nullptr, VK_NULL_HANDLE);
        CHECK(mali.n("vkQueueSubmit") == before + 1);
        ctx.shutdown();
        CHECK(mali.live_devices() == 0 && mali.live_instances() == 0);
        table_is_clear();
    }

    // 2. MediaTek-style host (Mali) + Turnip selected -> REJECTED before any Turnip code runs.
    {
        std::printf("[2] Mali host + Turnip -> vendor gate, system fallback, Turnip never executed\n");
        mali.reset();
        lg::gpu::AndroidVulkanContext ctx({sys_mali, kgsl_absent});
        auto r = ctx.initialize(nullptr, turnip);
        CHECK(r.ok());
        CHECK(std::string(ctx.driver_kind()) == "system");
        CHECK(contains(ctx.fallback_reason(), "not Qualcomm"));
        CHECK(contains(ctx.fallback_reason(), "0x13B5"));
        CHECK(tu.n("vkCreateInstance") == 0);         // the Adreno driver was never entered
        CHECK(tu.n("vkEnumeratePhysicalDevices") == 0);
        CHECK(contains(ctx.diagnostics(), "fallback=custom driver rejected"));
        ctx.shutdown();
        table_is_clear();
    }

    // 3. Adreno host + Turnip -> custom driver used; EVERY call after instance creation
    //    is served by Turnip, the system driver only saw the vendor probe.
    {
        std::printf("[3] Adreno host + Turnip -> all calls routed to Turnip\n");
        sadreno.reset(); tu.reset();
        lg::gpu::AndroidVulkanContext ctx({sys_adreno, kgsl_absent});
        auto r = ctx.initialize(nullptr, turnip);
        CHECK(r.ok());
        CHECK(ctx.using_custom_driver());
        CHECK(std::string(ctx.driver_kind()) == "custom");
        CHECK(ctx.fallback_reason().empty());
        CHECK(ctx.gpu_name() == "Turnip Adreno (TM) 740");
        // Turnip served the whole bring-up (the bug: these used to hit the system loader).
        CHECK(tu.n("vkCreateInstance") == 1);
        CHECK(tu.n("vkEnumeratePhysicalDevices") >= 1);
        CHECK(tu.n("vkCreateDevice") == 1);
        CHECK(tu.n("vkGetDeviceQueue") == 1);
        CHECK(tu.n("vkGetDeviceProcAddr") > 60);       // device table loaded from Turnip
        // The system driver only answered the vendor probe: no device, no queue.
        CHECK(sadreno.n("vkCreateInstance") == 1);
        CHECK(sadreno.n("vkCreateDevice") == 0);
        CHECK(sadreno.n("vkGetDeviceQueue") == 0);
        CHECK(sadreno.live_instances() == 0);          // probe instance already destroyed
        // A renderer-style call through the global table lands in Turnip, not the system.
        lg::gpu::vkfn::vkQueueSubmit(static_cast<VkQueue>(ctx.graphics_queue_handle()), 0, nullptr, VK_NULL_HANDLE);
        CHECK(tu.n("vkQueueSubmit") == 1);
        CHECK(sadreno.n("vkQueueSubmit") == 0);
        ctx.shutdown();
        // Teardown order: device before instance, nothing leaked.
        const std::string ev = tu.events();
        CHECK(ev.find("destroyDevice") != std::string::npos);
        CHECK(ev.find("destroyDevice") < ev.find("destroyInstance"));
        CHECK(tu.live_devices() == 0 && tu.live_instances() == 0);
        table_is_clear();
    }

    // 4. Turnip that fails vkCreateDevice -> transactional teardown + system fallback.
    {
        std::printf("[4] Turnip fails vkCreateDevice -> clean fallback to system\n");
        sadreno.reset(); tubad.reset();
        lg::gpu::AndroidVulkanContext ctx({sys_adreno, kgsl_absent});
        auto r = ctx.initialize(nullptr, turnip_bad);
        CHECK(r.ok());
        CHECK(std::string(ctx.driver_kind()) == "system");
        CHECK(contains(ctx.fallback_reason(), "vkCreateDevice"));
        CHECK(tubad.n("vkCreateDevice") == 1);
        CHECK(tubad.live_instances() == 0);            // failed attempt fully destroyed
        CHECK(sadreno.n("vkCreateDevice") == 1);       // system took over
        ctx.shutdown();
        CHECK(sadreno.live_devices() == 0 && sadreno.live_instances() == 0);
        table_is_clear();
    }

    // 5. ICD exporting only vk_icdGetInstanceProcAddr is accepted.
    {
        std::printf("[5] ICD-only export (vk_icdGetInstanceProcAddr)\n");
        lg::gpu::AndroidVulkanContext ctx({sys_adreno, kgsl_absent});
        auto r = ctx.initialize(nullptr, turnip_icd);
        CHECK(r.ok());
        CHECK(ctx.using_custom_driver());
        CHECK(tuicd.n("vkCreateDevice") == 1);
        ctx.shutdown();
        table_is_clear();
    }

    // 6. Custom driver exposing a non-Qualcomm GPU -> rejected after enumeration, fallback.
    {
        std::printf("[6] custom driver reports wrong vendor -> post-enumeration reject\n");
        lg::gpu::AndroidVulkanContext ctx({sys_adreno, kgsl_absent});
        auto r = ctx.initialize(nullptr, wrong_vendor);
        CHECK(r.ok());
        CHECK(std::string(ctx.driver_kind()) == "system");
        CHECK(contains(ctx.fallback_reason(), "0x13B5"));
        CHECK(wv.n("vkCreateDevice") == 0);
        CHECK(wv.live_instances() == 0);
        ctx.shutdown();
    }

    // 7. No system Vulkan + no Adreno kernel node -> custom rejected, clear error.
    {
        std::printf("[7] no system Vulkan, no KGSL node -> error with both reasons\n");
        lg::gpu::AndroidVulkanContext ctx({dir + "/missing_libvulkan.so", kgsl_absent});
        auto r = ctx.initialize(nullptr, turnip);
        CHECK(!r.ok());
        CHECK(contains(r.error(), "vendor unknown"));
        CHECK(contains(r.error(), "system driver"));
        CHECK(!ctx.ready());
        table_is_clear();
    }

    // 8. No system Vulkan but KGSL node present -> Turnip rescues the device.
    {
        std::printf("[8] no system Vulkan, KGSL node present -> Turnip allowed\n");
        lg::gpu::AndroidVulkanContext ctx({dir + "/missing_libvulkan.so", kgsl_present});
        auto r = ctx.initialize(nullptr, turnip);
        CHECK(r.ok());
        CHECK(ctx.using_custom_driver());
        ctx.shutdown();
    }

    // 9. Nonexistent / non-.so custom path -> fallback with a precise reason.
    {
        std::printf("[9] bad custom path -> fallback\n");
        lg::gpu::AndroidVulkanContext ctx({sys_adreno, kgsl_absent});
        auto r = ctx.initialize(nullptr, dir + "/nope.so");
        CHECK(r.ok());
        CHECK(contains(ctx.fallback_reason(), "not a regular file"));
        ctx.shutdown();
    }

    // 10. Exclusive table: a second live session cannot hijack the dispatch table.
    {
        std::printf("[10] dispatch table exclusivity\n");
        lg::gpu::AndroidVulkanContext a({sys_mali, kgsl_absent});
        lg::gpu::AndroidVulkanContext b({sys_mali, kgsl_absent});
        CHECK(a.initialize(nullptr, {}).ok());
        auto rb = b.initialize(nullptr, {});
        CHECK(!rb.ok());
        CHECK(contains(rb.error(), "another Vulkan driver session"));
        CHECK(a.ready());
        CHECK(lg::gpu::vkfn::vkCreateDevice != nullptr);   // A's table untouched
        a.shutdown();
        CHECK(b.initialize(nullptr, {}).ok());               // free again
        b.shutdown();
        table_is_clear();
    }

    // 11. Re-initialize without explicit shutdown (surface recreated) is leak-free.
    {
        std::printf("[11] re-initialize in place\n");
        sadreno.reset(); tu.reset();
        lg::gpu::AndroidVulkanContext ctx({sys_adreno, kgsl_absent});
        for (int i = 0; i < 5; ++i) CHECK(ctx.initialize(nullptr, turnip).ok());
        CHECK(tu.live_instances() == 1 && tu.live_devices() == 1);
        ctx.shutdown();
        CHECK(tu.live_instances() == 0 && tu.live_devices() == 0);
        CHECK(sadreno.n("vkCreateInstance") == 0);   // vendor probe cached from scenario 3
    }

    // 12. Pure policy table.
    {
        std::printf("[12] policy\n");
        using lg::gpu::evaluate_custom_driver;
        CHECK(evaluate_custom_driver(lg::gpu::kVendorQualcomm, false).allowed);
        CHECK(!evaluate_custom_driver(lg::gpu::kVendorArm, true).allowed);          // node irrelevant if vendor known
        CHECK(!evaluate_custom_driver(lg::gpu::kVendorImagination, false).allowed);
        CHECK(evaluate_custom_driver(std::nullopt, true).allowed);
        CHECK(!evaluate_custom_driver(std::nullopt, false).allowed);
        CHECK(lg::gpu::format_vendor(0x13B5) == "0x13B5 (ARM Mali)");
    }

    // 13. Retained AdrenoDriverLoader API (Regla de Oro): original contract, standalone,
    //     never touches the dispatch table owned by an active session.
    {
        std::printf("[13] AdrenoDriverLoader retained API\n");
        lg::gpu::AndroidVulkanContext ctx({sys_mali, kgsl_absent});
        CHECK(ctx.initialize(nullptr, {}).ok());
        auto* const table_before = lg::gpu::vkfn::vkCreateDevice;
        {
            lg::gpu::AdrenoDriverLoader loader;
            CHECK(!loader.loaded());
            CHECK(loader.open(turnip));
            CHECK(loader.loaded() && loader.custom());
            CHECK(loader.resolved_path() == turnip);
            CHECK(loader.instance_proc_addr(nullptr, "vkCreateInstance") != nullptr);
            CHECK(loader.instance_proc_addr(nullptr, nullptr) == nullptr);
            CHECK(lg::gpu::vkfn::vkCreateDevice == table_before);   // session table untouched
            CHECK(!loader.open(dir + "/nope.so"));                   // failed open -> closed
            CHECK(!loader.loaded() && !loader.error().empty());
            CHECK(loader.open(turnip));
            loader.close();
            CHECK(!loader.loaded() && !loader.custom() && loader.resolved_path().empty());
        }
        CHECK(ctx.ready() && lg::gpu::vkfn::vkCreateDevice == table_before);
        ctx.shutdown();
    }

    if (g_failures == 0) std::printf("ALL VULKAN DISPATCH TESTS PASSED\n");
    else std::printf("%d CHECK(S) FAILED\n", g_failures);
    return g_failures == 0 ? 0 : 1;
}
