// Fake Vulkan driver used by test_vulkan_dispatch. Built several times with different
// macros to emulate: a system loader on a Mali or Adreno phone, a Turnip ICD, a Turnip
// that fails vkCreateDevice, an ICD exporting only vk_icdGetInstanceProcAddr, and a
// custom driver that reports the wrong vendor.
//
// Every entry point records its name so the test can prove WHICH library served each
// call, and the order of destruction. State is queried through extern "C" hooks.
//
//   FAKE_VENDOR         VkPhysicalDeviceProperties::vendorID
//   FAKE_NAME           deviceName
//   FAKE_FAIL_DEVICE    vkCreateDevice returns VK_ERROR_INITIALIZATION_FAILED
//   FAKE_ICD_ONLY       export only vk_icdGetInstanceProcAddr
#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.h>

#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#ifndef FAKE_VENDOR
#define FAKE_VENDOR 0x5143
#endif
#ifndef FAKE_NAME
#define FAKE_NAME "Fake GPU"
#endif

namespace {
std::mutex g_mu;
std::map<std::string, int> g_calls;
std::vector<std::string> g_events;   // create/destroy order
int g_live_instances = 0, g_live_devices = 0;

void hit(const char* n) { std::lock_guard l(g_mu); ++g_calls[n]; }
void event(const std::string& e) { std::lock_guard l(g_mu); g_events.push_back(e); }

struct Obj { uint64_t loader_magic = 0x01CDC0DE; int kind; };   // dispatchable-looking handle
Obj g_phys{0x01CDC0DE, 2};
Obj g_queue{0x01CDC0DE, 4};

VKAPI_ATTR VkResult VKAPI_CALL CreateInstance(const VkInstanceCreateInfo*, const VkAllocationCallbacks*, VkInstance* out) {
    hit("vkCreateInstance"); event("createInstance");
    *out = reinterpret_cast<VkInstance>(new Obj{0x01CDC0DE, 1});
    std::lock_guard l(g_mu); ++g_live_instances;
    return VK_SUCCESS;
}
VKAPI_ATTR void VKAPI_CALL DestroyInstance(VkInstance i, const VkAllocationCallbacks*) {
    hit("vkDestroyInstance"); event("destroyInstance");
    delete reinterpret_cast<Obj*>(i);
    std::lock_guard l(g_mu); --g_live_instances;
}
VKAPI_ATTR VkResult VKAPI_CALL EnumerateInstanceExtensionProperties(const char*, uint32_t* n, VkExtensionProperties*) {
    hit("vkEnumerateInstanceExtensionProperties"); *n = 0; return VK_SUCCESS;
}
VKAPI_ATTR VkResult VKAPI_CALL EnumerateInstanceVersion(uint32_t* v) {
    hit("vkEnumerateInstanceVersion"); *v = VK_API_VERSION_1_3; return VK_SUCCESS;
}
VKAPI_ATTR VkResult VKAPI_CALL EnumeratePhysicalDevices(VkInstance, uint32_t* n, VkPhysicalDevice* out) {
    hit("vkEnumeratePhysicalDevices");
    if (!out) { *n = 1; return VK_SUCCESS; }
    if (*n < 1) return VK_INCOMPLETE;
    out[0] = reinterpret_cast<VkPhysicalDevice>(&g_phys); *n = 1; return VK_SUCCESS;
}
VKAPI_ATTR void VKAPI_CALL GetPhysicalDeviceProperties(VkPhysicalDevice, VkPhysicalDeviceProperties* p) {
    hit("vkGetPhysicalDeviceProperties");
    std::memset(p, 0, sizeof(*p));
    p->apiVersion = VK_API_VERSION_1_3; p->vendorID = FAKE_VENDOR; p->deviceID = 0x43050A01;
    std::strncpy(p->deviceName, FAKE_NAME, sizeof(p->deviceName) - 1);
}
VKAPI_ATTR void VKAPI_CALL GetPhysicalDeviceQueueFamilyProperties(VkPhysicalDevice, uint32_t* n, VkQueueFamilyProperties* q) {
    hit("vkGetPhysicalDeviceQueueFamilyProperties");
    if (!q) { *n = 1; return; }
    std::memset(q, 0, sizeof(*q));
    q[0].queueFlags = VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT | VK_QUEUE_TRANSFER_BIT; q[0].queueCount = 1; *n = 1;
}
VKAPI_ATTR VkResult VKAPI_CALL CreateDevice(VkPhysicalDevice, const VkDeviceCreateInfo*, const VkAllocationCallbacks*, VkDevice* out) {
    hit("vkCreateDevice");
#ifdef FAKE_FAIL_DEVICE
    (void)out; return VK_ERROR_INITIALIZATION_FAILED;
#else
    event("createDevice");
    *out = reinterpret_cast<VkDevice>(new Obj{0x01CDC0DE, 3});
    std::lock_guard l(g_mu); ++g_live_devices;
    return VK_SUCCESS;
#endif
}
VKAPI_ATTR void VKAPI_CALL DestroyDevice(VkDevice d, const VkAllocationCallbacks*) {
    hit("vkDestroyDevice"); event("destroyDevice");
    delete reinterpret_cast<Obj*>(d);
    std::lock_guard l(g_mu); --g_live_devices;
}
VKAPI_ATTR VkResult VKAPI_CALL DeviceWaitIdle(VkDevice) { hit("vkDeviceWaitIdle"); return VK_SUCCESS; }
VKAPI_ATTR void VKAPI_CALL GetDeviceQueue(VkDevice, uint32_t, uint32_t, VkQueue* q) {
    hit("vkGetDeviceQueue"); *q = reinterpret_cast<VkQueue>(&g_queue);
}
VKAPI_ATTR VkResult VKAPI_CALL QueueSubmit(VkQueue, uint32_t, const VkSubmitInfo*, VkFence) {
    hit("vkQueueSubmit"); return VK_SUCCESS;
}
// Any other entry point: valid, non-null, never called by the tests.
VKAPI_ATTR void VKAPI_CALL Unimplemented() { hit("<unimplemented>"); }

PFN_vkVoidFunction lookup(const char* name);

VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL GetDeviceProcAddr(VkDevice, const char* name) {
    hit("vkGetDeviceProcAddr"); return lookup(name);
}

PFN_vkVoidFunction lookup(const char* name) {
    if (!name || std::strncmp(name, "vk", 2) != 0) return nullptr;
#define F(n, fn) if (std::strcmp(name, n) == 0) return reinterpret_cast<PFN_vkVoidFunction>(fn);
    F("vkCreateInstance", CreateInstance)
    F("vkDestroyInstance", DestroyInstance)
    F("vkEnumerateInstanceExtensionProperties", EnumerateInstanceExtensionProperties)
    F("vkEnumerateInstanceVersion", EnumerateInstanceVersion)
    F("vkEnumeratePhysicalDevices", EnumeratePhysicalDevices)
    F("vkGetPhysicalDeviceProperties", GetPhysicalDeviceProperties)
    F("vkGetPhysicalDeviceQueueFamilyProperties", GetPhysicalDeviceQueueFamilyProperties)
    F("vkCreateDevice", CreateDevice)
    F("vkDestroyDevice", DestroyDevice)
    F("vkDeviceWaitIdle", DeviceWaitIdle)
    F("vkGetDeviceQueue", GetDeviceQueue)
    F("vkQueueSubmit", QueueSubmit)
    F("vkGetDeviceProcAddr", GetDeviceProcAddr)
#undef F
    return reinterpret_cast<PFN_vkVoidFunction>(Unimplemented);
}

VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL GetInstanceProcAddr(VkInstance, const char* name) {
    return lookup(name);
}
} // namespace

extern "C" {
#ifdef FAKE_ICD_ONLY
__attribute__((visibility("default"))) PFN_vkVoidFunction vk_icdGetInstanceProcAddr(VkInstance i, const char* n) { return GetInstanceProcAddr(i, n); }
#else
__attribute__((visibility("default"))) PFN_vkVoidFunction vkGetInstanceProcAddr(VkInstance i, const char* n) { return GetInstanceProcAddr(i, n); }
#endif
__attribute__((visibility("default"))) int fake_calls(const char* n) { std::lock_guard l(g_mu); auto it = g_calls.find(n); return it == g_calls.end() ? 0 : it->second; }
__attribute__((visibility("default"))) int fake_live_instances() { std::lock_guard l(g_mu); return g_live_instances; }
__attribute__((visibility("default"))) int fake_live_devices() { std::lock_guard l(g_mu); return g_live_devices; }
__attribute__((visibility("default"))) const char* fake_events() {
    static std::string s; std::lock_guard l(g_mu); s.clear();
    for (auto& e : g_events) { s += e; s += ','; }
    return s.c_str();
}
__attribute__((visibility("default"))) void fake_reset() { std::lock_guard l(g_mu); g_calls.clear(); g_events.clear(); }
}
