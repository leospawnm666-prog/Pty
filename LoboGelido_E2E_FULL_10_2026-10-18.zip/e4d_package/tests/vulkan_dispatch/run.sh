#!/usr/bin/env bash
# Builds the fake Vulkan drivers and runs test_vulkan_dispatch on a Linux host.
# Needs only a C++20 compiler and the Khronos Vulkan headers (no GPU, no loader).
#
#   tests/vulkan_dispatch/run.sh /path/to/Vulkan-Headers/include [--sanitize]
set -euo pipefail

VK_INCLUDE="${1:?usage: run.sh <vulkan-headers-include-dir> [--sanitize]}"
SAN=""
[ "${2:-}" = "--sanitize" ] && SAN="-fsanitize=address,undefined -fno-omit-frame-pointer -fno-sanitize-recover=undefined"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT="${OUT_DIR:-$(mktemp -d)}"
CXX="${CXX:-g++}"
mkdir -p "$OUT"

fake() {  # name, extra flags
  "$CXX" -std=c++20 -O1 -fPIC -shared -fvisibility=hidden -I"$VK_INCLUDE" "${@:2}" \
      "$ROOT/tests/vulkan_dispatch/fake_icd.cpp" -o "$OUT/$1"
}
fake fake_sys_mali.so            -DFAKE_VENDOR=0x13B5 '-DFAKE_NAME="Mali-G715"'
fake fake_sys_adreno.so          -DFAKE_VENDOR=0x5143 '-DFAKE_NAME="Adreno (TM) 740"'
fake fake_turnip.so              -DFAKE_VENDOR=0x5143 '-DFAKE_NAME="Turnip Adreno (TM) 740"'
fake fake_turnip_baddevice.so    -DFAKE_VENDOR=0x5143 '-DFAKE_NAME="Turnip broken"' -DFAKE_FAIL_DEVICE
fake fake_turnip_icdonly.so      -DFAKE_VENDOR=0x5143 '-DFAKE_NAME="Turnip ICD"' -DFAKE_ICD_ONLY
fake fake_custom_wrongvendor.so  -DFAKE_VENDOR=0x13B5 '-DFAKE_NAME="Not an Adreno"'
: > "$OUT/fake_kgsl_node"

"$CXX" -std=c++20 -g -O1 -Wall -Wextra -Wpedantic -DLG_VULKAN_HOST_TESTS $SAN \
    -I"$ROOT" -I"$VK_INCLUDE" \
    "$ROOT/tests/vulkan_dispatch/test_vulkan_dispatch.cpp" \
    "$ROOT/gpu/android_vulkan_context.cpp" "$ROOT/gpu/vk_dispatch.cpp" \
    "$ROOT/gpu/vulkan_library.cpp" "$ROOT/gpu/vulkan_driver_policy.cpp" \
    "$ROOT/gpu/adreno_driver_loader.cpp" \
    -ldl -o "$OUT/test_vulkan_dispatch"

"$OUT/test_vulkan_dispatch" "$OUT"
