// P3.0: NroLoader::parse.
//  T2 real NROs produced by clang + ld.lld + switch-tools/elf2nro are accepted with the
//     exact layout nx-hbloader would map
//  T3 one hand-made corruption per validation rule, then 100 000 random mutations: never
//     a host fault (ASan/UBSan), and every accepted image satisfies the layout invariants
#include "../loader/nro_loader.h"
#include "data/nro/nro_fixtures.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <string>
#include <vector>

namespace {
int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("  FAIL %s:%d %s\n", __FILE__, __LINE__, #c); if (++g_fail > 30) std::exit(1); } } while (0)

using lg::loader::NroImage;
using lg::loader::NroLoader;

template <size_t N> std::vector<uint8_t> bytes(const unsigned char (&a)[N]) { return {a, a + N}; }
void put32(std::vector<uint8_t>& b, size_t o, uint32_t v) { for (int i = 0; i < 4; ++i) b[o + i] = uint8_t(v >> (8 * i)); }

bool invariants(const NroImage& m) {
    constexpr uint64_t P = NroLoader::kPage;
    return m.text.offset == 0 && m.text.size > 0 &&
           m.ro.offset >= m.text.size && m.data.offset >= m.ro.offset + m.ro.size &&
           m.data.offset + m.data.size == m.image_size &&
           m.text.size % P == 0 && m.ro.size % P == 0 && m.data.size % P == 0 && m.bss_size % P == 0 &&
           m.mapped_size == ((m.image_size + m.bss_size + P - 1) & ~(P - 1)) &&
           m.rw_size == ((m.data.size + m.bss_size + P - 1) & ~(P - 1)) &&
           m.mapped_size <= NroLoader::kMaxMappedSize;
}

void real_nros() {
    std::printf("[T2] real NROs from elf2nro\n");
    const auto hello = NroLoader::parse(bytes(nro_fixtures::hello));
    CHECK(hello.ok());
    if (hello.ok()) {
        const auto& m = hello.value();
        CHECK(m.text.offset == 0 && m.text.size == 0x1000);
        CHECK(m.ro.offset == 0x1000 && m.ro.size == 0x1000);
        CHECK(m.data.offset == 0x2000 && m.data.size == 0x1000);
        CHECK(m.image_size == 0x3000);
        CHECK(m.bss_size == 0x2000);
        CHECK(m.mapped_size == 0x5000);
        CHECK(m.rw_size == 0x3000);
        CHECK(m.mod0_valid);
        CHECK(!m.has_assets);
        CHECK(invariants(m));
    }
    for (const auto& f : {bytes(nro_fixtures::guard), bytes(nro_fixtures::write_text)}) {
        const auto r = NroLoader::parse(f);
        CHECK(r.ok() && invariants(r.value()) && r.value().mod0_valid);
    }
    const auto big = NroLoader::parse(bytes(nro_fixtures::bigbss));
    CHECK(big.ok() && big.value().bss_size == 0x4000000 && invariants(big.value()));
    // The first word is the branch over the header (as in libnx's crt0), not a magic.
    CHECK(NroLoader::looks_like(nro_fixtures::hello, sizeof nro_fixtures::hello));
    CHECK(std::memcmp(nro_fixtures::hello, "NRO0", 4) != 0);
    // Assets after the image are recognised (and not treated as part of it).
    auto with_assets = bytes(nro_fixtures::hello);
    for (char c : std::string("ASET")) with_assets.push_back(uint8_t(c));
    with_assets.resize(with_assets.size() + 0x38, 0);
    const auto a = NroLoader::parse(with_assets);
    CHECK(a.ok() && a.value().has_assets && a.value().image_size == 0x3000);
}

void expect_error(const std::vector<uint8_t>& f, const char* needle, int line) {
    const auto r = NroLoader::parse(f);
    if (r.ok() || r.error().find(needle) == std::string::npos) {
        std::printf("  FAIL line %d: expected error containing \"%s\", got %s\n", line, needle,
                    r.ok() ? "success" : r.error().c_str());
        ++g_fail;
    }
}
#define EXPECT_ERROR(f, needle) expect_error(f, needle, __LINE__)

void corruptions() {
    std::printf("[T3a] one corruption per validation rule\n");
    const auto good = bytes(nro_fixtures::hello);
    auto m = [&](auto edit) { auto f = good; edit(f); return f; };
    EXPECT_ERROR(std::vector<uint8_t>(good.begin(), good.begin() + 0x7F), "smaller than the 0x80-byte header");
    EXPECT_ERROR(std::vector<uint8_t>(), "smaller than the 0x80-byte header");
    EXPECT_ERROR(m([](auto& f) { f[0x10] = 'X'; }), "missing NRO0 magic");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x18, 0x7F); }), "smaller than the header");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x18, 0x4000); }), "exceeds the file");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x18, 0xFFFFFFFF); }), "exceeds the file");
    EXPECT_ERROR(std::vector<uint8_t>(good.begin(), good.begin() + 0x2FFF), "exceeds the file");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x20, 0x3000); }), "text segment lies outside");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x24, 0x4000); }), "text segment lies outside");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x28, 0x2000); put32(f, 0x2C, 0x2000); }), "rodata segment lies outside");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x30, 0xFFFFF000); }), "data segment lies outside");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x30, 0x2000); put32(f, 0x34, 0xFFFFF000); }), "data segment lies outside");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x24, 0x800); }), "text segment is not 4 KiB aligned");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x28, 0x1800); }), "rodata segment is not 4 KiB aligned");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x34, 0xF00); }), "data segment is not 4 KiB aligned");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x20, 0x1000); put32(f, 0x24, 0x1000); put32(f, 0x28, 0x1000); }),
                 "text segment does not start at the image base");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x24, 0); }), "text segment is empty");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x24, 0x2000); }), "rodata overlaps text");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x2C, 0x2000); }), "data overlaps rodata");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x34, 0); }), "does not end at the declared size");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x38, 0x123); }), "bss size is not 4 KiB aligned");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x38, 0x40000000); }), "1 GiB sanity limit");
    EXPECT_ERROR(m([](auto& f) { put32(f, 0x38, 0xFFFFF000); }), "1 GiB sanity limit");
    // MOD0 problems are diagnostics, never a rejection (hbloader does not check them).
    auto bad_mod0 = m([](auto& f) { put32(f, 0x04, 0xFFFFFFF0); });
    CHECK(NroLoader::parse(bad_mod0).ok() && !NroLoader::parse(bad_mod0).value().mod0_valid);
    auto zero_mod0 = m([](auto& f) { put32(f, 0x04, 0); });
    CHECK(NroLoader::parse(zero_mod0).ok() && !NroLoader::parse(zero_mod0).value().mod0_valid);
}

void fuzz(uint64_t iterations, uint64_t seed) {
    std::printf("[T3b] %llu random mutations (seed %llu)\n", (unsigned long long)iterations, (unsigned long long)seed);
    std::mt19937_64 rng(seed);
    const std::vector<std::vector<uint8_t>> seeds = {bytes(nro_fixtures::hello), bytes(nro_fixtures::guard),
                                                     bytes(nro_fixtures::bigbss)};
    uint64_t accepted = 0;
    for (uint64_t it = 0; it < iterations; ++it) {
        auto f = seeds[rng() % seeds.size()];
        const int edits = 1 + int(rng() % 6);
        for (int e = 0; e < edits; ++e) {
            switch (rng() % 5) {
                case 0: f[rng() % 0x80] ^= uint8_t(1u << (rng() % 8)); break;           // bit flip in header
                case 1: put32(f, 0x18 + 4 * (rng() % 9), uint32_t(rng())); break;       // random header field
                case 2: put32(f, 0x18 + 4 * (rng() % 9), uint32_t(rng() % 0x8000) & ~0xFFFu); break;  // plausible field
                case 3: f.resize(rng() % (f.size() + 1)); if (f.size() < 0x80) f.resize(0x80, 0); break;
                case 4: if (f.size() >= 0x14) std::memcpy(f.data() + 0x10, "NRO0", 4); break;
            }
        }
        const auto r = NroLoader::parse(f);
        if (r.ok()) {
            ++accepted;
            if (!invariants(r.value()) || r.value().image_size > f.size()) {
                ++g_fail;
                std::printf("  FAIL accepted image breaks invariants at iteration %llu\n", (unsigned long long)it);
                if (g_fail > 30) std::exit(1);
            }
        } else {
            CHECK(r.error().rfind("NRO: ", 0) == 0);
        }
    }
    std::printf("  accepted %llu (all satisfy the invariants)\n", (unsigned long long)accepted);
}
} // namespace

int main(int argc, char** argv) {
    const uint64_t iterations = argc > 1 ? std::strtoull(argv[1], nullptr, 10) : 100000;
    const uint64_t seed = argc > 2 ? std::strtoull(argv[2], nullptr, 10) : 20260925ull;
    real_nros();
    corruptions();
    fuzz(iterations, seed);
    if (g_fail) { std::printf("nro loader: %d FAILED\n", g_fail); return 1; }
    std::puts("nro loader ok");
    return 0;
}
