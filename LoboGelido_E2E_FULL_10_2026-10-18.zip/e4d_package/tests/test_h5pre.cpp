// P3.5 H5-pre: libnx's own startup (switch_crt0.s, dynamic.c, init.c, env.c, virtmem.c,
// random.c, argv.c, hosversion.c + the IPC clients; libnx 146c3d1, unmodified; newlib shimmed)
// from _start to main() and back to the loader through exit -> __libnx_exit -> __appExit ->
// __nx_exit.
//  S1 h5pre_gpr (-mgeneral-regs-only) on every engine: the guest log is exactly the expected
//     lines, the session ends in exit=guest code=0, every IPC session was closed, and relro was
//     reprotected by dynamic.c (SetMemoryPermission)
//  S2 h5pre_neon (default code generation, as devkitPro builds it): same result on the JIT; on
//     the interpreter it stops at the first AdvSIMD instruction and the error names the family
//  S3 guest_summary() before, during and after a session; argv[0] from set_content_display_name
#include "lg_check.h"
#include "../memory/address_space.h"
#include "../runtime/runtime_coordinator.h"
#include "data/nro/h5pre/h5pre_fixture.h"

#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace {
namespace fs = std::filesystem;
using lg::runtime::RuntimeCoordinator;
using lg::runtime::State;
constexpr uint64_t MiB = 1ull << 20;

template <size_t N> std::vector<uint8_t> bytes(const unsigned char (&a)[N]) { return {a, a + N}; }
std::string write_nro(const std::string& name, const std::vector<uint8_t>& b) {
    const auto p = fs::temp_directory_path() / (name + ".nro");
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(b.data()), long(b.size()));
    return p.string();
}
struct Engine { const char* name; bool force_interpreter; bool fastmem; size_t host_page; };
std::vector<Engine> engines() {
    std::vector<Engine> e = {{"Block", true, false, 0}, {"Block, 16 KiB host pages", true, false, 16384}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    e.push_back({"JIT", false, false, 0});
    e.push_back({"JIT + fastmem", false, true, 0});
    e.push_back({"JIT + fastmem, 16 KiB host pages", false, true, 16384});
#endif
    return e;
}
std::string run_to_end(RuntimeCoordinator& rt, int max_frames = 5'000'000) {
    for (int i = 0; i < max_frames && rt.state() == State::Running; ++i) {
        const auto r = rt.run_frame(rt.entry_point());
        if (!r.ok()) return r.error();
    }
    return {};
}
int64_t wall_now() {
    return std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}
std::vector<std::string> lines(const std::string& s) {
    std::vector<std::string> out;
    size_t b = 0;
    for (size_t e; (e = s.find('\n', b)) != std::string::npos; b = e + 1) out.push_back(s.substr(b, e - b));
    if (b < s.size()) out.push_back(s.substr(b));
    return out;
}

/** Checks the log of a complete run; prints what differs. */
bool check_log(const std::string& log, const std::string& argv0, int64_t t0, int64_t t1, const char* engine) {
    const auto l = lines(log);
    bool ok = l.size() == 7;
    const auto want = [&](size_t i, const std::string& w) {
        if (i < l.size() && l[i] == w) return;
        std::printf("  [%s] line %zu: '%s', want '%s'\n", engine, i, i < l.size() ? l[i].c_str() : "(none)", w.c_str());
        ok = false;
    };
    want(0, "Hola desde libnx: argc=1 HOS=5.1.0");   // argvSetup + hosversion from the ConfigEntry list
    want(1, "argv0=" + argv0);
    if (l.size() > 2) {   // time=<posix> tz=0: __libnx_init_time's two time:u calls
        long long t = -1, tz = -1;
        const bool parsed = std::sscanf(l[2].c_str(), "time=%lld tz=%lld", &t, &tz) == 2;
        if (!parsed || t < t0 || t > t1 || tz != 0) {
            std::printf("  [%s] line 2: '%s' (want time in [%lld, %lld], tz=0)\n", engine, l[2].c_str(), (long long)t0, (long long)t1);
            ok = false;
        }
    }
    want(3, "sdmc=0xfa202");        // fsdevMountSdmc -> fsOpenSdCardFileSystem: no SD (D-P3.4-6)
    if (l.size() > 4 && l[4].rfind("heap=0x", 0) != 0) { std::printf("  [%s] line 4: '%s'\n", engine, l[4].c_str()); ok = false; }
    want(5, "thread=ok applet=-2");  // __libnx_init_thread; AppletType_None from the ConfigEntry list
    want(6, "adios");
    if (!ok) std::printf("  [%s] log:\n%s\n", engine, log.c_str());
    return ok;
}

void s1_gpr_everywhere() {
    std::printf("[S1] libnx startup (general registers only) on every engine\n");
    const std::string path = write_nro("lobo_p35_h5pre_gpr", bytes(nro_fixtures::h5pre_gpr));
    const auto engines_list = engines();
    for (const auto& e : engines_list) {
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            const int64_t t0 = wall_now();
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            const auto start = std::chrono::steady_clock::now();
            const auto err = run_to_end(rt);
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            if (!err.empty() || rt.state() != State::Stopped)
                std::printf("  %s | pc=0x%llx lr=0x%llx | %s\n", err.c_str(), (unsigned long long)rt.last_guest_fault().pc,
                            (unsigned long long)rt.last_guest_fault().lr, rt.diagnostics().c_str());
            LG_CHECK(err.empty() && rt.state() == State::Stopped && rt.guest_exit().has_code && rt.guest_exit().code == 0);
            LG_CHECK(check_log(rt.guest_log(), "lobo_p35_h5pre_gpr.nro", t0, wall_now() + 1, e.name));
            LG_CHECK(rt.ipc_for_testing().session_count() == 0);
            if (&e == &engines_list.front())
                for (const auto& line : lines(rt.guest_log())) std::printf("    | %s\n", line.c_str());
            std::printf("  %-34s %6.1f ms  SVC: SetHeapSize=%llu SetMemoryPermission=%llu QueryMemory=%llu "
                        "SendSyncRequest=%llu CloseHandle=%llu\n",
                        e.name, ms, (unsigned long long)rt.svc_calls(0x01), (unsigned long long)rt.svc_calls(0x02),
                        (unsigned long long)rt.svc_calls(0x06), (unsigned long long)rt.svc_calls(0x21),
                        (unsigned long long)rt.svc_calls(0x16));
            LG_CHECK(rt.svc_calls(0x02) >= 1);   // dynamic.c reprotects relro (LNY1)
            LG_CHECK(rt.svc_calls(0x06) >= 1);   // __libnx_init_thread / argvSetup
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

void s2_neon() {
    std::printf("[S2] libnx startup with AdvSIMD/FP (default code generation)\n");
    const std::string path = write_nro("lobo_p35_h5pre_neon", bytes(nro_fixtures::h5pre_neon));
    for (const auto& e : engines()) {
        lg::memory::AddressSpace::set_host_page_size_for_testing(e.host_page);
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(64 * MiB);
            rt.set_force_interpreter(e.force_interpreter);
            rt.set_jit_fastmem(e.fastmem);
            const int64_t t0 = wall_now();
            LG_CHECK(rt.prepare(path).ok() && rt.start().ok());
            const auto err = run_to_end(rt);
            const auto f = rt.last_guest_fault();
            if (!e.force_interpreter) {   // the JIT runs it like the GPR build
                if (!err.empty()) std::printf("  [%s] %s\n", e.name, err.c_str());
                LG_CHECK(err.empty() && rt.state() == State::Stopped && rt.guest_exit().has_code && rt.guest_exit().code == 0);
                LG_CHECK(check_log(rt.guest_log(), "lobo_p35_h5pre_neon.nro", t0, wall_now() + 1, e.name));
                std::printf("  %-34s runs to exit=guest code=0\n", e.name);
            } else {                      // the interpreter stops at the first AdvSIMD/FP word and says so
                const bool ok = rt.state() == State::Error && f.kind == lg::cpu::ExceptionKind::UndefinedInstruction &&
                                f.insn_valid && f.on_interpreter && f.pc == f.address &&
                                err.find("guest fault: undefined_0x") == 0 &&
                                err.find(" [AdvSIMD/FP") != std::string::npos &&
                                err.find(": no soportada por el intérprete; usa la JIT]") != std::string::npos;
                if (!ok) std::printf("  [%s] %s\n", e.name, err.c_str());
                LG_CHECK(ok);
                const std::string summary = rt.guest_summary();
                LG_CHECK(summary.rfind("Estado: error\nÚltimo log: (ninguno)\nError: guest fault: undefined_0x", 0) == 0);
                std::printf("  %-34s %s\n", e.name, err.c_str());
            }
        }
        lg::memory::AddressSpace::set_host_page_size_for_testing(0);
    }
}

void s3_summary_and_name() {
    std::printf("[S3] guest summary and argv[0] from the display name\n");
    const std::string path = write_nro("lobo_p35_h5pre_gpr", bytes(nro_fixtures::h5pre_gpr));
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64 * MiB);
    rt.set_force_interpreter(true);
    LG_CHECK(rt.guest_summary() == "Estado: sin sesión\nÚltimo log: (ninguno)\nHilos: 0/0 · IPC: 0 · SVC: 0");
    rt.set_content_display_name("/storage/emulated/0/Switch/Mi \"Juego\".nro");   // a descriptor's user-visible name
    LG_CHECK(rt.content_display_name() == "Mi \"Juego\".nro");
    const int64_t t0 = wall_now();
    LG_CHECK(rt.prepare(path).ok());
    LG_CHECK(rt.guest_summary().rfind("Estado: preparado\n", 0) == 0);
    LG_CHECK(rt.start().ok());
    const auto err = run_to_end(rt);
    LG_CHECK(err.empty() && rt.state() == State::Stopped);
    // setup_entry_abi drops the quotes and quotes the name (it has a blank); libnx's argvSetup
    // removes them again: argv[0] is the name without its quotes.
    LG_CHECK(check_log(rt.guest_log(), "Mi Juego.nro", t0, wall_now() + 1, "display name"));
    const std::string s = rt.guest_summary();
    std::printf("%s\n", s.c_str());
    // the counts of the ended session stay: 28 requests (one per SendSyncRequest), every SVC
    const std::string counts = "Hilos: 0/1 · IPC: " + std::to_string(rt.svc_calls(0x21)) + " · SVC: ";
    LG_CHECK(rt.svc_calls(0x21) == 28);
    LG_CHECK(s.rfind("Estado: terminado (código 0)\nÚltimo log: adios\n" + counts, 0) == 0);
    LG_CHECK(s.find("\nError:") == std::string::npos);
    // the next prepare starts from zero (a synthetic image has no guest kernel to count)
    LG_CHECK(rt.prepare().ok());
    LG_CHECK(rt.guest_summary() == "Estado: preparado\nÚltimo log: (ninguno)\nHilos: 0/0 · IPC: 0 · SVC: 0");
    rt.set_content_display_name("");
    LG_CHECK(rt.content_display_name().empty());
}
} // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    s1_gpr_everywhere();
    s2_neon();
    s3_summary_and_name();
    std::puts("h5pre ok");
    return 0;
}
