#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "../runtime/runtime_coordinator.h"

static void put32(std::vector<uint8_t>& b, size_t o, uint32_t v) {
    b[o] = static_cast<uint8_t>(v); b[o+1] = static_cast<uint8_t>(v >> 8);
    b[o+2] = static_cast<uint8_t>(v >> 16); b[o+3] = static_cast<uint8_t>(v >> 24);
}
static void put64(std::vector<uint8_t>& b, size_t o, uint64_t v) {
    put32(b, o, static_cast<uint32_t>(v)); put32(b, o+4, static_cast<uint32_t>(v >> 32));
}

int main() {
    namespace fs = std::filesystem;
    const fs::path path = fs::temp_directory_path() / "lobo_gelido_synthetic_e2e.nro";
    constexpr size_t kTextSize = 2048;
    std::vector<uint8_t> nro(0x80 + kTextSize, 0);
    nro[0]='N'; nro[1]='R'; nro[2]='O'; nro[3]='0';
    put64(nro, 0x10, 0x80); put64(nro, 0x18, kTextSize);
    for (size_t off=0x80; off<nro.size(); off+=4) put32(nro, off, 0xD503201F); // ARM64 NOP
    // P2 B.2: end the NOP sled with "B <entry>" so the program is well defined for every
    // backend. A JIT translates and runs whole blocks (Dynarmic checks its tick budget
    // between blocks), so without it the JIT ran past the last NOP into the zero-filled
    // rest of the page (UDF) and killed the guest thread. The interpreter/Block backends
    // never reach this instruction in 4 frames, so their behaviour is unchanged.
    constexpr uint32_t kNops = kTextSize / 4;
    put32(nro, 0x80 + kTextSize - 4, 0x14000000u | (static_cast<uint32_t>(-static_cast<int32_t>(kNops - 1)) & 0x03FFFFFFu));
    { std::ofstream out(path, std::ios::binary|std::ios::trunc); LG_CHECK(out); out.write(reinterpret_cast<const char*>(nro.data()), nro.size()); LG_CHECK(out.good()); }

    lg::runtime::RuntimeCoordinator rt;
    LG_CHECK(rt.state() == lg::runtime::State::Cold);

    // Open -> inspect -> load -> process creation -> real runtime preparation.
    auto prep = rt.prepare(path.string());
    LG_CHECK(prep.ok());
    LG_CHECK(rt.state() == lg::runtime::State::Ready);
    LG_CHECK(rt.entry_point() == 0x100000ull);
    LG_CHECK(rt.process() == nullptr); // created, but not running/current yet

    // Start must actually transition the created guest process to running/current.
    LG_CHECK(rt.start().ok());
    LG_CHECK(rt.state() == lg::runtime::State::Running);
    LG_CHECK(rt.process() != nullptr);
    LG_CHECK(rt.process()->running);
    LG_CHECK(rt.process()->initialized);
    LG_CHECK(rt.process()->entry_point == 0x100000ull);
    LG_CHECK(rt.process()->segment_count == 1);

    // Execute enough real ARM64 NOPs to exercise persistent guest PC + CPU/MMU/scheduler.
    for (int i=0; i<3; ++i) { auto r = rt.run_frame(rt.entry_point()); if (!r.ok()) { std::cerr << "frame " << i << " failed: " << r.error() << "\n" << rt.diagnostics() << "\n"; return 2; } }
    LG_CHECK(rt.metrics().frames == 3);
    // P2 E.3: with the JIT selected the count is the provider's tick-based ESTIMATE
    // (published as instr_est=); before E.3 it stayed 0 under the JIT.
    LG_CHECK(rt.metrics().instructions > 0);
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    LG_CHECK(rt.diagnostics().find("instr_est=") != std::string::npos);
#endif
    LG_CHECK(rt.metrics().scheduler_ticks > 0);
    LG_CHECK(rt.metrics().guest_dispatches > 0);
    LG_CHECK(rt.metrics().thread_context_switches > 0);
    LG_CHECK(rt.metrics().faults == 0);
    const std::string d = rt.diagnostics();
    LG_CHECK(d.find("MMU=ready") != std::string::npos);
    LG_CHECK(d.find("frames=3") != std::string::npos);

    // Pause/resume and another frame, then full shutdown/reset.
    LG_CHECK(rt.pause().ok()); LG_CHECK(rt.resume().ok()); LG_CHECK(rt.run_frame(rt.entry_point()).ok());
    LG_CHECK(rt.metrics().frames == 4);
    LG_CHECK(rt.stop().ok());
    LG_CHECK(rt.state() == lg::runtime::State::Stopped);
    LG_CHECK(rt.process() == nullptr);

    std::error_code ec; fs::remove(path, ec);
    std::cout << "runtime synthetic e2e ok: open -> load -> process -> start -> CPU/MMU -> scheduler -> 4 frames -> diagnostics -> stop\n";
}
