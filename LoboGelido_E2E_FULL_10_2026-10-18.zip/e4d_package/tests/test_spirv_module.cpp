#include "lg_check.h"
#include <cassert>
#include "../gpu/spirv_module.h"
int main() {
    using namespace lg::gpu;
    auto bad_magic = validate_spirv({1, 2, 3, 4, 5});
    LG_CHECK(!bad_magic.ok());

    auto valid_header = validate_spirv({0x07230203u, 0x00010000u, 0, 1, 0});
    LG_CHECK(valid_header.ok());
    LG_CHECK(valid_header.value().bound == 1);

    auto zero_bound = validate_spirv({0x07230203u, 0x00010000u, 0, 0, 0});
    LG_CHECK(!zero_bound.ok());
    auto invalid_schema = validate_spirv({0x07230203u, 0x00010000u, 0, 1, 1});
    LG_CHECK(!invalid_schema.ok());
    auto malformed = validate_spirv({0x07230203u, 0x00010000u, 0, 1, 0, 0});
    LG_CHECK(!malformed.ok());

    // Header-only fails full validation
    auto full_header = validate_spirv_full({0x07230203u, 0x00010000u, 0, 1, 0}, false);
    LG_CHECK(!full_header.ok());

    // External tool optional: must not hard-fail when spirv-val absent
    auto ext = validate_spirv_external({0x07230203u, 0x00010000u, 0, 1, 0}, false);
    LG_CHECK(ext.ok());

    return 0;
}
