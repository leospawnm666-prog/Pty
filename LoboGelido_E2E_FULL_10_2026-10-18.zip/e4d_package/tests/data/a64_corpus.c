typedef unsigned long u64; typedef long i64; typedef unsigned int u32; typedef unsigned char u8;
u64 sum_array(const u64* a, u64 n) { u64 s = 0; for (u64 i = 0; i < n; ++i) s += a[i]; return s; }
i64 fib(i64 n) { i64 a = 0, b = 1; while (n-- > 0) { i64 t = a + b; a = b; b = t; } return a; }
u64 collatz(u64 n) { u64 steps = 0; while (n != 1) { n = (n & 1) ? 3 * n + 1 : n >> 1; ++steps; } return steps; }
void copy_bytes(u8* d, const u8* s, u64 n) { for (u64 i = 0; i < n; ++i) d[i] = s[i] ^ (u8)i; }
u32 crc32ish(const u8* p, u64 n) { u32 c = 0xFFFFFFFFu; for (u64 i = 0; i < n; ++i) { c ^= p[i]; for (int k = 0; k < 8; ++k) c = (c >> 1) ^ (0xEDB88320u & -(c & 1)); } return ~c; }
i64 clamp_sum(const i64* a, u64 n, i64 lo, i64 hi) { i64 s = 0; for (u64 i = 0; i < n; ++i) { i64 v = a[i]; v = v < lo ? lo : v > hi ? hi : v; s += v; } return s; }
static u64 helper(u64 x) { return x * 2654435761u + (x >> 7); }
u64 call_chain(u64 x) { for (int i = 0; i < 10; ++i) x = helper(x) ^ (u64)i; return x; }
u64 divs(u64 a, u64 b) { return a / b + a % b + (u64)((i64)a / (i64)(b | 1)); }
int sort3(i64* v) { for (int i = 0; i < 3; ++i) for (int j = i + 1; j < 3; ++j) if (v[j] < v[i]) { i64 t = v[i]; v[i] = v[j]; v[j] = t; } return (int)v[0]; }
u64 bitops(u64 x) { return __builtin_popcountll(x) + __builtin_clzll(x | 1) + __builtin_ctzll(x | 0x8000) + (x << 13 | x >> 51); }
u64 sw(u64 k) { switch (k & 7) { case 0: return 11; case 1: return 22; case 2: return k * 3; case 3: return k ^ 0x55; case 4: return k - 9; default: return k + 100; } }
