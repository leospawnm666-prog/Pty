// P3.4 H4: libnx's own IPC clients (sm.c, time.c, fs.c, sessionmgr.c, mutex.c, condvar.c,
// svc.s, hosversion.c, diag.c of libnx 146c3d1, unmodified) against Lobo's kernel.
#include <stdint.h>
#include "switch/types.h"
#include "switch/result.h"
#include "switch/arm/tls.h"
#include "switch/kernel/svc.h"
#include "switch/kernel/thread.h"
#include "switch/runtime/hosversion.h"
#include "switch/services/sm.h"
#include "switch/services/time.h"
#include "switch/services/fs.h"

typedef struct { u32 magic; Handle handle; void* thread_info; void* reent; void* tls_tp; } H4ThreadVars;
static u64 results[16];
static u8 tls_block[0x100] __attribute__((aligned(16)));
void hosversionSet(u32 version);

u64 h4_main(const u32* config) {
    // What __libnx_init / envSetup / __libnx_init_thread do: main thread handle into ThreadVars,
    // the HOS version, and a TLS block for __thread variables (fs.c's g_fsPriority).
    Handle main_handle = 0;
    for (const u32* e = config; e[0] != 0; e += 6) if (e[0] == 1) main_handle = e[2];
    H4ThreadVars* tv = (H4ThreadVars*)((u8*)armGetTls() + 0x200 - sizeof(H4ThreadVars));
    tv->magic = 0x21545624;
    tv->handle = main_handle;
    tv->tls_tp = tls_block;
    __asm__ volatile("msr tpidr_el0, %0" :: "r"(tls_block));
    hosversionSet(MAKEHOSVERSION(5, 1, 0));

    results[0] = smInitialize();
    results[1] = timeInitialize();
    u64 now = 0;
    results[2] = timeGetCurrentTime(TimeType_UserSystemClock, &now);
    results[3] = now;
    TimeCalendarTime ct = {0};
    TimeCalendarAdditionalInfo ai = {0};
    results[4] = timeToCalendarTimeWithMyRule(now, &ct, &ai);
    results[5] = (u64)ct.year | ((u64)ct.month << 16) | ((u64)ct.day << 24) | ((u64)ct.hour << 32) |
                 ((u64)ct.minute << 40) | ((u64)ct.second << 48);
    results[6] = (u64)ai.wday | ((u64)ai.yday << 32);
    u64 tz = 0;
    for (int i = 0; i < 8; ++i) tz |= (u64)(u8)ai.timezoneName[i] << (8 * i);
    results[7] = tz;
    results[8] = (u64)(u32)ai.offset | ((u64)ai.DST << 32);
    results[9] = fsInitialize();
    FsFileSystem sd;
    results[10] = fsOpenSdCardFileSystem(&sd);
    fsExit();
    timeExit();
    smExit();
    results[11] = 0x4834;   // "H4": the run got to the end
    svcOutputDebugString((const char*)results, 12 * 8);
    return 0;
}
