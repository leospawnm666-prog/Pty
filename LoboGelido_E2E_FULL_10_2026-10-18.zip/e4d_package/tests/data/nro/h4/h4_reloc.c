#include <stdint.h>
typedef struct { int64_t tag; uint64_t val; } Dyn;
typedef struct { uint64_t offset; uint64_t info; int64_t addend; } Rela;
void h4_relocate(uint8_t* base, const Dyn* dyn) {
    const Rela* rela = 0;
    uint64_t relasz = 0;
    for (; dyn->tag != 0; ++dyn) {
        if (dyn->tag == 7) rela = (const Rela*)(base + dyn->val);   // DT_RELA
        if (dyn->tag == 8) relasz = dyn->val;                       // DT_RELASZ
    }
    for (uint64_t i = 0; rela && i < relasz / sizeof(Rela); ++i)
        if ((uint32_t)rela[i].info == 1027)                         // R_AARCH64_RELATIVE
            *(uint64_t*)(base + rela[i].offset) = (uint64_t)(base + rela[i].addend);
}
