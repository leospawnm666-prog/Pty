// Minimal C runtime pieces the libnx modules need (freestanding build of the H4 fixture).
#include <stddef.h>
#include <stdint.h>
void* memcpy(void* d, const void* s, size_t n) { unsigned char* a = d; const unsigned char* b = s; while (n--) *a++ = *b++; return d; }
void* memmove(void* d, const void* s, size_t n) {
    unsigned char* a = d; const unsigned char* b = s;
    if (a < b) while (n--) *a++ = *b++; else { a += n; b += n; while (n--) *--a = *--b; }
    return d;
}
void* memset(void* d, int c, size_t n) { unsigned char* a = d; while (n--) *a++ = (unsigned char)c; return d; }
int memcmp(const void* x, const void* y, size_t n) {
    const unsigned char* a = x; const unsigned char* b = y;
    for (; n; --n, ++a, ++b) if (*a != *b) return *a - *b;
    return 0;
}
size_t strlen(const char* s) { size_t n = 0; while (s[n]) ++n; return n; }
char* strncpy(char* d, const char* s, size_t n) { size_t i = 0; for (; i < n && s[i]; ++i) d[i] = s[i]; for (; i < n; ++i) d[i] = 0; return d; }
// time.c references these on paths HOS 5.1.0 never takes (shared memory: 6.0.0+); only
// shmemClose runs (timeExit on an unmapped block, a no-op in libnx too).
__attribute__((noreturn)) static void never(void) { __builtin_trap(); }
int eventLoadRemote(void* e, uint32_t h, int a) { (void)e; (void)h; (void)a; never(); }
int shmemLoadRemote(void* s, uint32_t h, size_t z, uint32_t p) { (void)s; (void)h; (void)z; (void)p; never(); }
int shmemMap(void* s) { (void)s; never(); }
int shmemClose(void* s) { (void)s; return 0; }   // timeExit closes the (never mapped) shared memory
