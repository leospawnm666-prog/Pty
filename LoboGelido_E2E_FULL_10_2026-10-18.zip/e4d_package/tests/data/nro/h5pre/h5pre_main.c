// P3.5 H5-pre: main() of an NRO whose startup is libnx's own (switch_crt0.s, dynamic.c, init.c,
// env.c, virtmem.c, random.c, argv.c, hosversion.c, exception.s + the IPC clients of H4, libnx
// 146c3d1, unmodified). It reaches main() the way a devkitPro homebrew does and prints the same
// first line as tools/homebrew/hola_libnx, one svcOutputDebugString per line.
#include <stddef.h>
#include <stdint.h>
#include <switch.h>
#include "internal.h"

extern char* fake_heap_start;
extern char* fake_heap_end;
extern u64 h5pre_boottime;
extern s32 h5pre_tz_offset;
extern Result h5pre_sdmc_result;
extern u32 __nx_applet_type;

typedef struct { char b[160]; size_t n; } Line;
static void put_s(Line* l, const char* s) { while (*s && l->n + 1 < sizeof l->b) l->b[l->n++] = *s++; }
static void put_u(Line* l, u64 v, unsigned base) {
    char t[24]; int i = 0;
    do { t[i++] = "0123456789abcdef"[v % base]; v /= base; } while (v);
    if (base == 16) put_s(l, "0x");
    while (i) { char c[2] = {t[--i], 0}; put_s(l, c); }
}
static void put_i(Line* l, s64 v) { if (v < 0) { put_s(l, "-"); put_u(l, (u64)-v, 10); } else put_u(l, (u64)v, 10); }
static void emit(Line* l) { put_s(l, "\n"); svcOutputDebugString(l->b, l->n); l->n = 0; }

int main(int argc, char** argv) {
    Line l = {{0}, 0};
    const u32 hos = hosversionGet();
    put_s(&l, "Hola desde libnx: argc="); put_i(&l, argc);
    put_s(&l, " HOS="); put_u(&l, HOSVER_MAJOR(hos), 10); put_s(&l, ".");
    put_u(&l, HOSVER_MINOR(hos), 10); put_s(&l, "."); put_u(&l, HOSVER_MICRO(hos), 10);
    emit(&l);
    put_s(&l, "argv0="); put_s(&l, argc > 0 && argv[0] ? argv[0] : "(none)"); emit(&l);
    put_s(&l, "time="); put_u(&l, h5pre_boottime, 10); put_s(&l, " tz="); put_i(&l, h5pre_tz_offset); emit(&l);
    put_s(&l, "sdmc="); put_u(&l, h5pre_sdmc_result, 16); emit(&l);
    put_s(&l, "heap="); put_u(&l, (u64)(fake_heap_end - fake_heap_start), 16); emit(&l);
    const ThreadVars* tv = getThreadVars();
    put_s(&l, "thread="); put_s(&l, tv->magic == THREADVARS_MAGIC && tv->thread_ptr && tv->handle ? "ok" : "bad");
    put_s(&l, " applet="); put_i(&l, (s32)__nx_applet_type); emit(&l);
    put_s(&l, "adios"); emit(&l);
    return 0;   // crt0 set LR = exit: exit -> __libnx_exit -> __appExit -> __nx_exit -> loader
}
