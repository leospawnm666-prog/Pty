#pragma once
static inline int isspace(int c){return c==32||(c>=9&&c<=13);}
