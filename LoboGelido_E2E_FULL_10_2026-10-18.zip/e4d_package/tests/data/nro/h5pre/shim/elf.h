#pragma once
/* The subset of <elf.h> libnx's runtime/dynamic.c uses (ELF64, AArch64). */
#include <stdint.h>
typedef uint64_t Elf64_Addr;
typedef uint64_t Elf64_Xword;
typedef int64_t Elf64_Sxword;
typedef struct { Elf64_Sxword d_tag; union { Elf64_Xword d_val; Elf64_Addr d_ptr; } d_un; } Elf64_Dyn;
typedef struct { Elf64_Addr r_offset; Elf64_Xword r_info; Elf64_Sxword r_addend; } Elf64_Rela;
typedef Elf64_Xword Elf64_Relr;
#define ELF64_R_TYPE(i) ((uint32_t)((i) & 0xffffffffu))
#define ELF64_R_SYM(i) ((uint32_t)((i) >> 32))
#define DT_NULL 0
#define DT_RELA 7
#define DT_RELASZ 8
#define DT_RELAENT 9
#define DT_RELACOUNT 0x6ffffff9
#define DT_RELRSZ 35
#define DT_RELR 36
#define DT_RELRENT 37
#define R_AARCH64_NONE 0
#define R_AARCH64_RELATIVE 1027
