// P3.5 H5-pre: the newlib half of libnx's runtime, which cannot be built here (no newlib, R8).
// Everything else in the startup is libnx's own unmodified code. Each function below says which
// libnx function it stands for and what it keeps of it; nothing here changes what the emulator
// sees except where noted.
#include <stddef.h>
#include <stdint.h>
#include <switch.h>
#include "internal.h"

// --- memory/string (newlib) -------------------------------------------------------------------
void* memcpy(void* d, const void* s, size_t n) { unsigned char* a = d; const unsigned char* b = s; while (n--) *a++ = *b++; return d; }
void* memmove(void* d, const void* s, size_t n) {
    unsigned char* a = d; const unsigned char* b = s;
    if (a < b) while (n--) *a++ = *b++; else { a += n; b += n; while (n--) *--a = *--b; }
    return d;
}
void* memset(void* d, int c, size_t n) { unsigned char* a = d; while (n--) *a++ = (unsigned char)c; return d; }
int memcmp(const void* x, const void* y, size_t n) {
    const unsigned char* a = x; const unsigned char* b = y;
    for (; n; --n, ++a, ++b) if (*a != *b) return *a - *b;
    return 0;
}
size_t strlen(const char* s) { size_t n = 0; while (s[n]) ++n; return n; }
char* strncpy(char* d, const char* s, size_t n) { size_t i = 0; for (; i < n && s[i]; ++i) d[i] = s[i]; for (; i < n; ++i) d[i] = 0; return d; }
int strcmp(const char* a, const char* b) { while (*a && *a == *b) { ++a; ++b; } return (unsigned char)*a - (unsigned char)*b; }
int strncmp(const char* a, const char* b, size_t n) {
    for (; n; --n, ++a, ++b) { if (*a != *b) return (unsigned char)*a - (unsigned char)*b; if (!*a) return 0; }
    return 0;
}
char* strcpy(char* d, const char* s) { char* r = d; while ((*d++ = *s++)) {} return r; }

// --- heap (newlib's sbrk over fake_heap_start/end, which libnx's __libnx_initheap fills) ---------
char* fake_heap_start;
char* fake_heap_end;
static char* g_brk;
void* aligned_alloc(size_t alignment, size_t size) {
    if (!g_brk) g_brk = fake_heap_start;
    uintptr_t p = ((uintptr_t)g_brk + alignment - 1) & ~(uintptr_t)(alignment - 1);
    if (!fake_heap_start || p + size > (uintptr_t)fake_heap_end) return NULL;
    g_brk = (char*)(p + size);
    return (void*)p;
}
void* malloc(size_t size) { return aligned_alloc(16, size); }
void* calloc(size_t n, size_t size) { void* p = malloc(n * size); if (p) memset(p, 0, n * size); return p; }
void free(void* p) { (void)p; }
void abort(void) { diagAbortWithResult(MAKERESULT(Module_Libnx, LibnxError_NotFound)); }

// --- newlibSetup (runtime/newlib.c): the main thread's ThreadVars, without newlib's _reent -------
void newlibSetup(void) {
    ThreadVars* tv = getThreadVars();
    tv->magic = THREADVARS_MAGIC;
    tv->thread_ptr = NULL;
    tv->reent = NULL;
    tv->tls_tp = __tls_start - getTlsStartOffset();
    tv->handle = envGetMainThreadHandle();
    // devkitA64's GCC reads the thread pointer through __aarch64_read_tp (runtime/readtp.s:
    // TPIDRRO_EL0 -> ThreadVars.tls_tp); clang has no such mode and reads TPIDR_EL0, so the same
    // value goes there too.
    __asm__ volatile("msr tpidr_el0, %0" :: "r"(tv->tls_tp));
    const size_t tls_size = (size_t)(__tdata_lma_end - __tdata_lma);
    if (tls_size) memcpy(__tls_start, __tdata_lma, tls_size);
}
void __libc_init_array(void) {}   // no constructors in this fixture

// --- __libnx_init_thread (kernel/thread.c): same steps, the Thread list kept local -----------------
static Thread g_main_thread;
void __libnx_init_thread(void) {
    g_main_thread.handle = envGetMainThreadHandle();
    MemoryInfo mem_info = {0};
    u32 page_info;
    svcQueryMemory(&mem_info, &page_info, (u64)(&mem_info));
    g_main_thread.owns_stack_mem = false;
    g_main_thread.stack_mem = NULL;
    g_main_thread.stack_mirror = (void*)mem_info.addr;
    g_main_thread.stack_sz = mem_info.size;
    g_main_thread.tls_array = (void**)((u8*)armGetTls() + 0x180);   // USER_TLS_BEGIN
    getThreadVars()->thread_ptr = &g_main_thread;
}

// --- __libnx_init_time (runtime/newlib.c): same service calls; the TZ string is not built -------
u64 h5pre_boottime = UINT64_MAX;
s32 h5pre_tz_offset = -1;
void __libnx_init_time(void) {
    Result rc = timeGetCurrentTime(TimeType_Default, &h5pre_boottime);
    if (R_FAILED(rc)) { h5pre_boottime = UINT64_MAX; return; }
    TimeCalendarAdditionalInfo info;
    rc = timeToCalendarTimeWithMyRule(h5pre_boottime, NULL, &info);
    if (R_SUCCEEDED(rc)) h5pre_tz_offset = info.offset;
}
void __libnx_init_cwd(void) {}   // argv[0] is not an "sdmc:/" path here, so libnx sets nothing

// --- runtime/devices/fs_dev.c: the one IPC call fsdevMountSdmc makes before any devoptab work ----
Result h5pre_sdmc_result = 1;
Result fsdevMountSdmc(void) {
    FsFileSystem fs;
    h5pre_sdmc_result = fsOpenSdCardFileSystem(&fs);
    if (R_SUCCEEDED(h5pre_sdmc_result)) fsFsClose(&fs);
    return h5pre_sdmc_result;
}
Result fsdevUnmountAll(void) { return 0; }
void nxlinkSetup(void) {}   // runtime/nxlink.c: only acts on an "_NXLINK_" argument

// --- services not used with AppletType_None (init.c skips them; __appExit calls their Exit) -------
__attribute__((noreturn)) static void never(void) { __builtin_trap(); }
u32 __nx_applet_type = AppletType_Default;   // services/applet.c; envSetup overwrites it
Result appletInitialize(void) { if (__nx_applet_type != AppletType_None) never(); return 0; }
void appletExit(void) {}
Result hidInitialize(void) { never(); }
void hidExit(void) {}
Result setsysInitialize(void) { never(); }   // HOS version comes from the loader's ConfigEntry
Result setsysGetFirmwareVersion(SetSysFirmwareVersion* out) { (void)out; never(); }
void setsysExit(void) {}
// time.c shared memory (6.0.0+ only; HOS is 5.1.0)
void eventLoadRemote(Event* e, Handle h, bool a) { (void)e; (void)h; (void)a; never(); }
void shmemLoadRemote(SharedMemory* s, Handle h, size_t z, Permission p) { (void)s; (void)h; (void)z; (void)p; never(); }
Result shmemMap(SharedMemory* s) { (void)s; never(); }
Result shmemClose(SharedMemory* s) { (void)s; return 0; }

// --- exit (newlib's exit -> __syscall_exit -> __libnx_exit) -------------------------------------
void NX_NORETURN __libnx_exit(int rc);
__attribute__((noreturn)) void exit(int rc) { __libnx_exit(rc); }
