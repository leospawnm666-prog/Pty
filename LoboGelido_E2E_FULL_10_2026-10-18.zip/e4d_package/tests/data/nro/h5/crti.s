// Stand-in for GCC's crti.o/crtn.o (devkitA64 startfile): empty .init/.fini functions.
	.section .init,"ax",%progbits
	.global _init
	.type _init,%function
	.align 2
_init:	ret
	.section .fini,"ax",%progbits
	.global _fini
	.type _fini,%function
	.align 2
_fini:	ret
