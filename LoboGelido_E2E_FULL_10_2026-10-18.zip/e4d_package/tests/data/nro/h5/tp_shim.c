// Toolchain shim (clang only): devkitA64's GCC reads the thread pointer through
// __aarch64_read_tp (TPIDRRO_EL0 -> ThreadVars.tls_tp); clang reads TPIDR_EL0. After libnx's
// real newlibSetup fills ThreadVars, the same value is copied to TPIDR_EL0 (ld --wrap).
void __real_newlibSetup(void);
void __wrap_newlibSetup(void) {
    __real_newlibSetup();
    void* tpidrro;
    __asm__ volatile("mrs %0, tpidrro_el0" : "=r"(tpidrro));
    void* tls_tp = *(void**)((char*)tpidrro + 0x1F8);
    __asm__ volatile("msr tpidr_el0, %0" :: "r"(tls_tp));
}
