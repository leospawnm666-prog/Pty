#pragma once
/* newlib's <stdatomic.h> as GCC sees it: generic builtins on plain objects. */
#define memory_order_relaxed __ATOMIC_RELAXED
#define memory_order_acquire __ATOMIC_ACQUIRE
#define memory_order_release __ATOMIC_RELEASE
#define memory_order_seq_cst __ATOMIC_SEQ_CST
#define atomic_load(p) ({ __typeof__(*(p)) _lg_v; __atomic_load((p), &_lg_v, __ATOMIC_SEQ_CST); _lg_v; })
#define atomic_store(p, v) ({ __typeof__(*(p)) _lg_v = (v); __atomic_store((p), &_lg_v, __ATOMIC_SEQ_CST); })
#define atomic_load_explicit(p, o) ({ __typeof__(*(p)) _lg_v; __atomic_load((p), &_lg_v, (o)); _lg_v; })
#define atomic_store_explicit(p, v, o) ({ __typeof__(*(p)) _lg_v = (v); __atomic_store((p), &_lg_v, (o)); })
#define atomic_fetch_add(p, v) __atomic_fetch_add((p), (v), __ATOMIC_SEQ_CST)
#define atomic_fetch_sub(p, v) __atomic_fetch_sub((p), (v), __ATOMIC_SEQ_CST)
#define atomic_exchange(p, v) __atomic_exchange_n((p), (v), __ATOMIC_SEQ_CST)
#define atomic_thread_fence(o) __atomic_thread_fence(o)
#define memory_order_consume __ATOMIC_CONSUME
#define memory_order_acq_rel __ATOMIC_ACQ_REL
#define atomic_fetch_or(p, v) __atomic_fetch_or((p), (v), __ATOMIC_SEQ_CST)
#define atomic_fetch_and(p, v) __atomic_fetch_and((p), (v), __ATOMIC_SEQ_CST)
#define atomic_compare_exchange_strong(p, e, d) __atomic_compare_exchange_n((p), (e), (d), 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
#define atomic_compare_exchange_weak(p, e, d) __atomic_compare_exchange_n((p), (e), (d), 1, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
#define atomic_load_explicit_n(p,o) __atomic_load_n((p),(o))
