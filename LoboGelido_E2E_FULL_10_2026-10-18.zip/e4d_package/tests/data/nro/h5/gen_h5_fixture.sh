#!/usr/bin/env bash
# P3.5-H1 (hito H5): builds hola_libnx.nro from tools/homebrew/hola_libnx/source/main.c
# (unmodified) with the full devkitPro runtime built from source with clang/lld:
#   - devkitPro newlib (github.com/devkitPro/newlib, branch devkitPro, 57bd8e1): libc, libm,
#     libsysbase (devoptab, stdio -> svcOutputDebugString through consoleDebugInit);
#   - libnx 146c3d1: every source that clang compiles (all but nvchannel.c and
#     buffer_producer.c, GPU code that uses a GCC-only VLA-in-struct and that hola does not use);
#   - compiler-rt builtins (llvmorg-18.1.8) in place of libgcc (long double for printf).
# Toolchain stand-ins (documented, none changes libnx or newlib code):
#   - crti.s: empty _init/_fini, like GCC's crti.o/crtn.o with nothing between them;
#   - tp_shim.c: clang reads the thread pointer from TPIDR_EL0, devkitA64's GCC through
#     __aarch64_read_tp (TPIDRRO_EL0 + 0x1F8); newlibSetup is wrapped (ld --wrap) to copy it;
#   - stdatomic_clang.h: GCC's generic atomics on plain objects for hid*.c, irs.c, btdrv.c;
#   - exception.s without ".weak __libnx_exception_entry" (clang's assembler), switch.ld with a
#     PT_TLS header (lld), as in ../h5pre/gen_h5pre_fixture.sh.
# Writes h5_fixture.h. Licences of the embedded code: licenses/.
# Usage: gen_h5_fixture.sh <elf2nro> <libnx checkout> <newlib checkout> <llvm-project checkout
#        (at least compiler-rt/lib/builtins)>     Needs: clang-18, ld.lld-18, llvm-ar-18, make.
set -euo pipefail
cd "$(dirname "$0")"
here=$(pwd)
ELF2NRO=$(realpath "${1:?elf2nro}"); NX=$(realpath "${2:?libnx}")/nx; NLSRC=$(realpath "${3:?newlib}"); RT=$(realpath "${4:?llvm-project}")/compiler-rt/lib/builtins
CC=${CC:-clang-18}; LD=${LD:-ld.lld-18}; AR=${AR:-llvm-ar-18}; READELF=${READELF:-llvm-readelf-18}
tmp=${KEEP:-$(mktemp -d)}; [ -n "${KEEP:-}" ] || trap 'rm -rf "$tmp"' EXIT; mkdir -p "$tmp"
TGT="--target=aarch64-none-elf"
ARCH="$TGT -march=armv8-a+crc+crypto -mtune=cortex-a57"

# 1. newlib + libsysbase (devkitA64's configure flags)
mkdir -p "$tmp/nlb"
( cd "$tmp/nlb"
  export CC_FOR_TARGET="$CC $TGT" AS_FOR_TARGET="$CC $TGT" AR_FOR_TARGET=$AR RANLIB_FOR_TARGET=llvm-ranlib-18 \
         LD_FOR_TARGET=$LD NM_FOR_TARGET=llvm-nm-18 OBJDUMP_FOR_TARGET=llvm-objdump-18 READELF_FOR_TARGET=$READELF \
         STRIP_FOR_TARGET=llvm-strip-18 \
         CFLAGS_FOR_TARGET="-O2 -ffunction-sections -fdata-sections -march=armv8-a+crc+crypto -mtune=cortex-a57 -fPIE -mno-outline-atomics -D__SWITCH__ -Wno-implicit-function-declaration -Wno-int-conversion -Wno-incompatible-pointer-types"
  "$NLSRC/configure" --target=aarch64-none-elf --prefix="$tmp/nl" --disable-newlib-supplied-syscalls \
      --enable-newlib-mb --disable-newlib-wide-orient --disable-nls > cfg.log 2>&1
  make -j"$(nproc)" MAKEINFO=true all-target-newlib all-target-libgloss > build.log 2>&1
  make MAKEINFO=true install-target-newlib install-target-libgloss > install.log 2>&1 )
NL="$tmp/nl/aarch64-none-elf"

# 2. compiler-rt builtins
mkdir -p "$tmp/rt"
for f in "$RT"/*.c; do
  $CC $ARCH -O2 -fPIC -ffreestanding -ffunction-sections -fdata-sections -mno-outline-atomics -isystem "$NL/include" -w \
      -c "$f" -o "$tmp/rt/$(basename "$f" .c).o" 2>/dev/null || true   # x86/ARM32/other-target files do not build: skipped
done
$AR rcs "$tmp/librt.a" "$tmp"/rt/*.o

# 3. libnx
mkdir -p "$tmp/nx" "$tmp/atomic"
cp stdatomic_clang.h "$tmp/atomic/stdatomic.h"
NXFLAGS="$ARCH -fPIC -O2 -ffunction-sections -fdata-sections -mno-outline-atomics -std=gnu11 -D__SWITCH__ -DLIBNX_NO_DEPRECATION -isystem $NL/include -I$NX/include -I$NX/include/switch -I$NX/external/bsd/include -I$NX/source -I$tmp/gen -w"
mkdir -p "$tmp/gen"
printf 'extern const unsigned char default_font_bin[];\nextern const unsigned char default_font_bin_end[];\nextern const unsigned int default_font_bin_size;\n' > "$tmp/gen/default_font_bin.h"
printf '.section .rodata.default_font_bin,"a"\n.balign 4\n.global default_font_bin\n.global default_font_bin_end\n.global default_font_bin_size\ndefault_font_bin:\n.incbin "%s"\ndefault_font_bin_end:\n.balign 4\ndefault_font_bin_size: .int %d\n' \
  "$NX/data/default_font.bin" "$(stat -c %s "$NX/data/default_font.bin")" > "$tmp/gen/default_font.s"
$CC $ARCH -c "$tmp/gen/default_font.s" -o "$tmp/nx/data_default_font.o"
for d in arm kernel sf services crypto nvidia nvidia/ioctl display audio applets runtime runtime/devices runtime/util runtime/util/utf; do
  for f in "$NX/source/$d"/*.c; do
    [ -f "$f" ] || continue
    b=$(basename "$f" .c); o="$tmp/nx/$(echo "$d" | tr / _)_$b.o"
    case "$b" in nvchannel|buffer_producer) continue ;; esac   # GCC-only VLA in a struct; GPU, unused
    case "$b" in hid|hidbus|irs|btdrv) $CC $NXFLAGS -I"$tmp/atomic" -c "$f" -o "$o" ;; *) $CC $NXFLAGS -c "$f" -o "$o" ;; esac
  done
  for f in "$NX/source/$d"/*.s; do
    [ -f "$f" ] || continue
    in=$f; o="$tmp/nx/$(echo "$d" | tr / _)_$(basename "$f" .s)_s.o"
    if [ "$(basename "$f")" = exception.s ]; then grep -v '^\.weak __libnx_exception_entry$' "$f" > "$tmp/exception.s"; in="$tmp/exception.s"; fi
    $CC $ARCH -c -x assembler-with-cpp -I"$NX/include" "$in" -o "$o"
  done
done
$AR rcs "$tmp/libnx.a" "$tmp"/nx/*.o

# 4. hola_libnx
python3 - "$NX/switch.ld" "$tmp/switch.ld" <<'PY'
import sys
s = open(sys.argv[1]).read()
s = s.replace("dyn    PT_DYNAMIC;", "dyn    PT_DYNAMIC;\n\ttls    PT_TLS;", 1)
for sec in (".tdata :", ".tbss :"):
    i = s.index("\t" + sec); j = s.index("} :data", i)
    s = s[:j] + "} :data :tls" + s[j + len("} :data"):]
assert s.count(":tls") == 2
open(sys.argv[2], "w").write(s)
PY
$CC $ARCH -fPIE -O2 -ffunction-sections -fdata-sections -D__SWITCH__ -isystem "$NL/include" -I"$NX/include" -Wall \
    -c "$here/../../../../tools/homebrew/hola_libnx/source/main.c" -o "$tmp/main.o"
$CC $ARCH -fPIE -O2 -c tp_shim.c -o "$tmp/tp_shim.o"
$CC $TGT -c crti.s -o "$tmp/crti.o"
$LD -pie --no-dynamic-linker --gc-sections -z text -z now -z pack-relative-relocs --build-id=sha1 --wrap=newlibSetup \
    -T "$tmp/switch.ld" -o "$tmp/hola.elf" "$tmp/crti.o" "$tmp/main.o" "$tmp/tp_shim.o" "$tmp/nx/runtime_switch_crt0_s.o" \
    --start-group "$tmp/libnx.a" "$NL/lib/libsysbase.a" "$NL/lib/libc.a" "$NL/lib/libm.a" --end-group "$tmp/librt.a"
if $READELF -r "$tmp/hola.elf" | grep -E 'R_AARCH64_' | grep -qv 'R_AARCH64_RELATIVE'; then
  echo "hola.elf: relocations other than RELATIVE" >&2; exit 1
fi
"$ELF2NRO" "$tmp/hola.elf" "$tmp/hola_libnx.nro" > /dev/null
{
  echo "// Generated by gen_h5_fixture.sh: tools/homebrew/hola_libnx + libnx 146c3d1 + devkitPro newlib"
  echo "// 57bd8e1 + compiler-rt 18.1.8, built with clang/lld. Do not edit. Licences: licenses/."
  echo "#pragma once"
  echo "namespace nro_fixtures {"
  echo "constexpr unsigned char h5_hola_libnx[] = {"
  python3 -c 'import sys; b=open(sys.argv[1],"rb").read(); print(",\n".join(", ".join("0x%02x"%x for x in b[i:i+16]) for i in range(0,len(b),16)))' "$tmp/hola_libnx.nro"
  echo "};"
  echo "} // namespace nro_fixtures"
} > h5_fixture.h
echo "hola_libnx.nro: $(stat -c %s "$tmp/hola_libnx.nro") bytes"
