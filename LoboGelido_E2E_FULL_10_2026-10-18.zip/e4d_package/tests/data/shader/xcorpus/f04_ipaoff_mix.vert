#version 460
// P4.4: IPA.OFFSET and IPA of the same inputs (interpolateAtOffset and the center), with a w that
// varies per vertex (the perspective correction at the offset matters)
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
// cb1: frag 0 1.0
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_a;
layout(location=1) noperspective out vec2 o_b;
void main() {
    float w = 1.0 + 0.75 * (pos.x * 0.5 + 0.5) + 0.5 * (pos.y * 0.5 + 0.5);
    gl_Position = vec4(pos.xy * w, 0.5 * w, w);
    o_a = vec4(pos.xy * 4.0 + 8.0, pos.x * pos.x * 16.0, 1.0);
    o_b = pos.yx * 8.0 + 8.0;
}
