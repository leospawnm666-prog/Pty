#version 460
layout(location=0) in vec4 a;
layout(location=1) noperspective in vec2 b;
layout(location=0) out vec4 c0;
void main() {
    vec4 p = interpolateAtOffset(a, vec2(0.25, -0.375));
    vec2 q = interpolateAtOffset(b, vec2(-0.5, 0.4375));
    c0 = vec4(p.x - a.x, p.y + q.x, p.z, q.y - b.y);
}
