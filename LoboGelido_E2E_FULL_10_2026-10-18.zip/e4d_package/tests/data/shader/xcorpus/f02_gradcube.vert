#version 460
// P4.4: textureGrad on a cube and a 3D texture: nouveau emulates them with quad operations between
// SAM and RAM (QUADON/QUADPOP). The cube has one level: the emulation's level of detail (implicit
// derivatives of the face coordinates) is the compiler's approximation of the native one, not
// something the translation decides.
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
// rt: 1 f
// tol: 64
// atol: 0.002
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_uv;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_uv = vec4(pos.xy, pos.x * 0.7 + 0.2, pos.y * 0.9); }
