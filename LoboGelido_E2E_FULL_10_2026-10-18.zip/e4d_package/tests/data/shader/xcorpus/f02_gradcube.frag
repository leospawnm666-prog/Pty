#version 460
// tex: 16 cube f 8 8 6 1 linear
// tex: 17 3d f 8 8 8 3 linear miplinear
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(binding=16) uniform samplerCube tc;
layout(binding=17) uniform sampler3D t3;
void main() {
    vec3 d = vec3(uv.x * 0.5, uv.y * 0.5, 1.0);   // inside the +Z face, also for the neighbours' coordinates
    c0 = textureGrad(tc, d, vec3(uv.z * 0.1, 0.02, 0.0), vec3(0.01, uv.w * 0.05, 0.0));
    c1 = textureGrad(t3, vec3(uv.xy * 0.5 + 0.5, uv.z), vec3(0.05, 0.0, 0.01), vec3(0.0, 0.08, 0.02));
}
