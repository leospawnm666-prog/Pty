#version 460
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
void main() { c0 = vec4(float(gl_SampleID) + uv.x, float(gl_SampleMaskIn[0]), uv.y, 1.0); }
