#version 460
// P4.4: PIXLD (gl_SampleID: MY_INDEX, gl_SampleMaskIn: COVMASK) on a single-sample target
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_uv;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_uv = vec4(pos.xy * 0.5 + 0.5, 0.0, 1.0); }
