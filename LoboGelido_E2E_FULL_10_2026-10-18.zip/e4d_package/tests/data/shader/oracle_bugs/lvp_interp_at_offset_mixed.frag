#version 460
// Known oracle bug (P4.4, lavapipe Mesa 24.3.4 / LLVM 18): when a fragment input is read at the
// pixel center and also through interpolateAtOffset on the whole variable, the interpolated value
// equals the center one (c0 is 0 everywhere; SwiftShader gives the differences). Without the
// center reads (tests/data/shader/xcorpus/f03_ipaoff.frag) lavapipe is right. Vertex shader:
// tests/data/shader/xcorpus/f04_ipaoff_mix.vert. glslangValidator -V -S frag this file.
layout(location=0) in vec4 a;
layout(location=1) noperspective in vec2 b;
layout(location=0) out vec4 c0;
void main() {
    vec4 p = interpolateAtOffset(a, vec2(0.25, -0.375));
    vec2 q = interpolateAtOffset(b, vec2(-0.5, 0.4375));
    c0 = vec4(p.x - a.x, p.y - a.y, q.x - b.x, q.y - b.y);
}
