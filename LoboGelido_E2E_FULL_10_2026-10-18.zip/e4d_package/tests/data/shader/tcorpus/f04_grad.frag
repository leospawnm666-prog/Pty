#version 460
// tex: 16 2d f 32 32 1 6 linear miplinear
// tex: 20 2da f 16 16 4 4 linear miplinear
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(location=2) out vec4 c2;
layout(binding=16) uniform sampler2D t0;
layout(binding=20) uniform sampler2DArray ta;
void main() {
    c0 = textureGrad(t0, uv.xy, vec2(uv.z * 0.1, 0.02), vec2(0.01, uv.w * 0.05)) + textureGradOffset(t0, uv.yx, vec2(0.05), vec2(0.03), ivec2(1, 2));
    vec2 q = textureQueryLod(t0, uv.xy * 4.0);
    // magnification (computed LOD < 0, accessed level 0) and minification past the last level
    c2 = vec4(textureQueryLod(t0, uv.xy * 0.05), textureQueryLod(t0, uv.xy * 4000.0));
    c1 = vec4(q, vec2(textureSize(ta, 1).xz)) + textureGrad(ta, vec3(uv.xy, 2.0), vec2(0.1, 0.0), vec2(0.0, 0.1)) + vec4(textureQueryLevels(t0));
}
