#version 460
// tex: 16 2d f 32 32 1 6 linear miplinear repeat
// tex: 17 2d f 16 16 1 5
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(binding=16) uniform sampler2D t0;
layout(binding=17) uniform sampler2D t1;
void main() {
    c0 = texture(t0, uv.xy * 3.0) + texture(t0, uv.zw, 0.75) * 0.5;
    c1 = textureOffset(t1, uv.xy, ivec2(-2, 3)) + textureLodOffset(t1, uv.yx, 1.0, ivec2(1, -1));
}
