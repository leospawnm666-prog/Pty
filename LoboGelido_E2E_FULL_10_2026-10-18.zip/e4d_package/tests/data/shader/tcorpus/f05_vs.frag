#version 460
layout(location=0) in vec4 c;
layout(location=0) out vec4 c0;
void main() { c0 = c; }
