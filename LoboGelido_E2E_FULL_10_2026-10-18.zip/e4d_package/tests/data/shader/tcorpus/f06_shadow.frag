#version 460
// tex: 24 cube d 8 8 6 1 linear cmp:3
// tex: 25 1da d 16 3 1 1 cmp:1
// tex: 26 cubea d 8 8 12 1 cmp:1
// tex: 16 2d f 32 32 1 6 linear miplinear repeat
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(binding=24) uniform samplerCubeShadow tcs;
layout(binding=25) uniform sampler1DArrayShadow t1as;
layout(binding=26) uniform samplerCubeArrayShadow tcas;
layout(binding=16) uniform sampler2D t0;
void main() {
    vec3 d = normalize(vec3(uv.x - 0.5, uv.w - 0.2, uv.z));
    c0 = vec4(texture(tcs, vec4(d, uv.y)), texture(t1as, vec3(uv.x, 1.0, uv.y)), texture(tcas, vec4(d.yzx, 1.0), uv.x), 1.0);
    c1 = textureProj(t0, vec3(uv.xy * 2.0, 2.0)) + textureProj(t0, vec4(uv.yx, 0.0, 1.5), 0.5);
}
