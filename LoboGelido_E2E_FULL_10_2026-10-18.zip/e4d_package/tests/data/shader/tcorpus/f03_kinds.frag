#version 460
// tex: 19 cube f 8 8 6 3 linear
// tex: 20 2da f 16 16 4 2 linear
// tex: 21 3d f 8 8 8 2 linear
// tex: 22 2da d 16 16 3 1 cmp:1
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(binding=19) uniform samplerCube tc;
layout(binding=20) uniform sampler2DArray ta;
layout(binding=21) uniform sampler3D t3;
layout(binding=22) uniform sampler2DArrayShadow tas;
void main() {
    vec3 d = normalize(vec3(uv.x - 0.5, uv.y - 0.5, uv.z));
    c0 = texture(tc, d) + textureLod(tc, d.zxy, 1.0) + texture(ta, vec3(uv.xy, floor(uv.w * 2.0 + 1.0)));
    c1 = texture(t3, vec3(uv.xy, uv.z * 0.3 + 0.5)) + textureLod(t3, uv.yxz, 0.5) * 0.5 + vec4(texture(tas, vec4(uv.xy, 1.0, 0.5)));
}
