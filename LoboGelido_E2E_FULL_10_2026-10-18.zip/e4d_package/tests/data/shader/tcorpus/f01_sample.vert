#version 460
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
// rt: 1 f
// tol: 64
// atol: 0.002
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_uv;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_uv = vec4(pos.xy * 0.5 + 0.5, pos.x * 1.7 - 0.3, pos.y * 2.3); }
