#version 460
// tex: 16 2d f 16 16 1 1
// tex: 18 2d d 16 16 1 1 cmp:3
layout(location=0) in vec4 uv;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(binding=16) uniform sampler2D t0;
layout(binding=18) uniform sampler2DShadow t2;
void main() {
    c0 = textureGather(t0, uv.xy, 1) + textureGatherOffset(t0, uv.yx, ivec2(2, -3), 3) * 2.0;
    c1 = textureGather(t2, uv.xy, 0.5) + vec4(texture(t2, vec3(uv.yx, 0.4)), textureOffset(t2, vec3(uv.xy, 0.6), ivec2(1, 1)), 0.0, 1.0);
}
