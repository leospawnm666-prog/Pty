#version 460
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
// tol: 64
// tex: 16 2d f 16 16 1 4 linear miplinear
// tex: 23 2d i 8 8 1 1
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_c;
layout(binding=16) uniform sampler2D t0;
layout(binding=23) uniform isampler2D ti;
#ifdef VULKAN
#define VID gl_VertexIndex
#else
#define VID gl_VertexID
#endif
void main() {
    gl_Position = vec4(pos.xy, 0.5, 1.0);
    o_c = textureLod(t0, pos.xy * 0.5 + 0.5, float(VID % 4)) + vec4(texelFetch(ti, ivec2(VID, VID * 3) % 8, 0)) * 0.001 + texture(t0, pos.yx);
}
