#version 460
layout(location=0) in vec4 r;
layout(location=1) flat in int k;
layout(location=0) out vec4 c0;
layout(location=1) out ivec4 c1;
void main() { c0 = r; c1 = ivec4(k, gl_PrimitiveID, gl_FrontFacing ? 1 : 0, 9); }
