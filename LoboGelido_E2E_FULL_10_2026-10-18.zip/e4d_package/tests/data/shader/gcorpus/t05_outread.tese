#version 460
layout(triangles, equal_spacing, ccw) in;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];

layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    vec3 t = gl_TessCoord;
    gl_Position = t.x * gl_in[0].gl_Position + t.y * gl_in[1].gl_Position + t.z * gl_in[2].gl_Position;
    o_r = t.x * r[0] + t.y * r[1] + t.z * r[2];
    o_k = k[0] + k[1] * 10 + k[2] * 100 + gl_PrimitiveID * 1000;
}
