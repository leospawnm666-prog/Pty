#version 460
// draw: triangles 6 1
// attr: 0 f pos
// attr: 1 i rand
// attr: 2 u rand
// rt: 0 f
// rt: 1 u
// rt: 2 i
// rt: 3 f
// varying: 0 i
// varying: 1 u
layout(location=0) in vec4 pos;
layout(location=1) in ivec4 ia;
layout(location=2) in uvec4 ua;
layout(location=0) flat out ivec4 o_i;
layout(location=1) flat out uvec4 o_u;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_i = ia * 3 - 1; o_u = ua ^ uvec4(0xff); }
