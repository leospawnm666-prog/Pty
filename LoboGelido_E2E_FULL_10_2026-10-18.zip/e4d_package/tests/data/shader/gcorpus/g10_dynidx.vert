#version 460
// draw: triangles 6 1
// attr: 0 f pos
// attr: 1 i rand
// attr: 2 f rand
// rt: 0 f
// varying: 4 i
// tol: 64
layout(location=0) in vec4 pos;
layout(location=1) in ivec4 sel;
layout(location=2) in vec4 r;
layout(location=0) out vec4 o_v[4];
layout(location=4) flat out int o_k;
void main() {
    gl_Position = vec4(pos.xy, 0.5, 1.0);
    for (int i = 0; i < 4; ++i) o_v[i] = r * float(i + 1);
    int k = abs(sel.x) % 4; o_v[k] = vec4(-1.0); o_k = abs(sel.y) % 4;
}
