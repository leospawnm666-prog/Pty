#version 460
layout(location=0) in vec4 v[4];
layout(location=4) flat in int k;
layout(location=0) out vec4 c0;
void main() { c0 = v[k] + v[(k + 1) & 3] * 0.5; }
