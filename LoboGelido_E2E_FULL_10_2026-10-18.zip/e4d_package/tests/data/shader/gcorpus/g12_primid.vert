#version 460
// draw: triangles 12 1
// attr: 0 f pos
// rt: 0 i
// needs: geometry
layout(location=0) in vec4 pos;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); }
