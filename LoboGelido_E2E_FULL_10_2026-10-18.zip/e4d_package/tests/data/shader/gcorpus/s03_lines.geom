#version 460
layout(lines) in;
layout(line_strip, max_vertices = 3) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    gl_Position = gl_in[0].gl_Position; o_r = r[0]; o_k = k[0]; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex();
    gl_Position = mix(gl_in[0].gl_Position, gl_in[1].gl_Position, 0.5) + vec4(0.0, 0.2, 0.0, 0.0); o_r = r[1]; o_k = k[1]; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex();
    gl_Position = gl_in[1].gl_Position; o_r = r[1] * r[0]; o_k = k[0] + k[1]; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex();
}
