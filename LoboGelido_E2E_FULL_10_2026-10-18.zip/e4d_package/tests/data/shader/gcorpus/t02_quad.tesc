#version 460
layout(vertices = 4) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r[];
layout(location=1) flat out int o_k[];
void main() {
    gl_out[gl_InvocationID].gl_Position = gl_in[gl_InvocationID].gl_Position;
    o_r[gl_InvocationID] = r[gl_InvocationID] * float(gl_InvocationID + 1);
    barrier();
    o_k[gl_InvocationID] = floatBitsToInt(o_r[(gl_InvocationID + 1) % 4].x) & 0xffff;
    if (gl_InvocationID == 1) {
        gl_TessLevelOuter[0] = 2.5; gl_TessLevelOuter[1] = 3.0; gl_TessLevelOuter[2] = 1.7; gl_TessLevelOuter[3] = 4.0;
        gl_TessLevelInner[0] = 3.3; gl_TessLevelInner[1] = 2.0;
    }
}
