#version 460
layout(location=0) in vec4 c;
layout(location=0) out vec4 c0;
layout(std140, binding=1) uniform V { vec4 tint; } v;
layout(std430, binding=3) buffer Cnt { uint n; uint m; } cnt;
void main() { c0 = c * v.tint; atomicAdd(cnt.n, 1u); atomicMax(cnt.m, uint(gl_FragCoord.x)); }
