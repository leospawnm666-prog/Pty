#version 460
layout(location=0) out ivec4 c0;
void main() { c0 = ivec4(gl_PrimitiveID, gl_PrimitiveID * 2, 3, 4); }
