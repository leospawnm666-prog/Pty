#version 460
layout(triangles) in;
layout(triangle_strip, max_vertices = 6) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    for (int i = 0; i < 3; ++i) { gl_Position = gl_in[i].gl_Position; o_r = r[i] * 2.0; o_k = k[i] + gl_PrimitiveIDIn * 100; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex(); }
    EndPrimitive();
    for (int i = 0; i < 3; ++i) { gl_Position = gl_in[i].gl_Position * vec4(-1.0, 1.0, 1.0, 1.0); o_r = r[(i + 1) % 3]; o_k = -k[i]; gl_PrimitiveID = 7; EmitVertex(); }
}
