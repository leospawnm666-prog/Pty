#version 460
// draw: triangles 6 4 3
// attr: 0 f pos
// rt: 0 i
// varying: 0 i
// buffer: 1 z 64
// needs: draw_parameters
#ifdef VULKAN
#define VID gl_VertexIndex
#define IID (gl_InstanceIndex - gl_BaseInstance)
#extension GL_ARB_shader_draw_parameters : enable
#else
#define VID gl_VertexID
#define IID gl_InstanceID
#endif
layout(location=0) in vec4 pos;
layout(location=0) flat out ivec2 o_i;
layout(std430, binding=1) buffer S { int v[]; } sb;
void main() { gl_Position = vec4(pos.xy * 0.5 + vec2(IID % 2, IID / 2) * 0.5 - 0.25, 0.5, 1.0); o_i = ivec2(VID, IID); sb.v[IID * 6 + VID] = VID * 100 + IID; }
