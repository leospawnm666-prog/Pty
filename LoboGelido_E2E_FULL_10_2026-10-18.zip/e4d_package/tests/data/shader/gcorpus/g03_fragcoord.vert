#version 460
// draw: triangles 12 1
// attr: 0 f posw
// rt: 0 f
// rt: 1 i
// tol: 64
layout(location=0) in vec4 pos;
void main() { gl_Position = pos; }
