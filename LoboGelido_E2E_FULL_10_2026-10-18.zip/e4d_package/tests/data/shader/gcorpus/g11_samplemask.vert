#version 460
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
// rt: 1 f
// depth
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_p;
void main() { gl_Position = vec4(pos.xy, pos.z, 1.0); o_p = pos; }
