#version 460
layout(location=0) out vec4 c0;
layout(location=1) out ivec4 c1;
void main() {
    if (int(gl_FragCoord.x) % 5 == 2) discard;
    c0 = vec4(gl_FragCoord.xy, gl_FragCoord.z, gl_FragCoord.w);
    c1 = ivec4(gl_FrontFacing ? 11 : -11, int(gl_FragCoord.x) * 64 + int(gl_FragCoord.y), 0, 1);
}
