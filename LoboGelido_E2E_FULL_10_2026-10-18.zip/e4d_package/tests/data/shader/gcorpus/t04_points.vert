#version 460
// draw: patches 6 1
// attr: 0 f pos
// attr: 1 f rand
// rt: 0 f
// rt: 1 i
// varying: 1 i
// patch: 3
// tess: tri even ccw point
// tol: 256
// atol: 0.00001
layout(location=0) in vec4 pos;
layout(location=1) in vec4 r;
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
#ifdef VULKAN
#define VID gl_VertexIndex
#else
#define VID gl_VertexID
#endif
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_r = r; o_k = VID; }
