#version 460
// draw: triangles 6 1
// attr: 0 f pos
// attr: 1 f rand
// rt: 0 f
// tol: 256
// atol: 0.00001
layout(location=0) in vec4 pos;
layout(location=1) in vec4 r;
layout(location=0) out vec4 o_r;
void main() { vec4 a = r; for (int i = 0; i < 5; ++i) { if (a.x > 1.0) a = a.yzwx * 0.5; else a += vec4(0.25, -0.5, 0.125, 1.0); }
              gl_Position = vec4(pos.xy, 0.5, 1.0); o_r = a; }
