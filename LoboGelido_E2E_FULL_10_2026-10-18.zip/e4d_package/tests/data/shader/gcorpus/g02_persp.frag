#version 460
layout(location=0) in vec4 a;
layout(location=1) noperspective in vec3 b;
layout(location=2) in float s;
layout(location=3) flat in uvec2 u;
layout(location=4) flat in float f;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
layout(location=2) out uvec4 c2;
void main() { c0 = a; c1 = vec4(b, s + f); c2 = uvec4(u, uint(gl_FragCoord.x), uint(gl_FragCoord.y)); gl_FragDepth = clamp(a.y * 0.25 + 0.5, 0.0, 1.0); }
