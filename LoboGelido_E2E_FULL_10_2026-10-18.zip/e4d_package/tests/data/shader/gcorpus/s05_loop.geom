#version 460
layout(triangles) in;
layout(triangle_strip, max_vertices = 12) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    int n = 1 + (k[0] / 3) % 4;
    for (int j = 0; j < n; ++j) {
        if (r[0].x > 1.5 && j == 2) continue;
        for (int i = 0; i < 3; ++i) { gl_Position = gl_in[i].gl_Position * vec4(1.0 - 0.2 * float(j), 1.0 - 0.2 * float(j), 1.0, 1.0); o_r = r[i] * float(j + 1); o_k = j * 10 + i; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex(); }
        EndPrimitive();
    }
}
