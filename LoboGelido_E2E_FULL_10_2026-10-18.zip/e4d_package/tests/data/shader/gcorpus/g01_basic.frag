#version 460
layout(location=0) in vec4 col;
layout(location=1) flat in int id;
layout(location=0) out vec4 c;
layout(location=1) out ivec4 c2;
void main() { c = col; c2 = ivec4(id, gl_FrontFacing ? 1 : 0, 5, 7); }
