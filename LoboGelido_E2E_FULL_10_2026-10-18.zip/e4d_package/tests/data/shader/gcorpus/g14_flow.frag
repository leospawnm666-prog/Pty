#version 460
layout(location=0) in vec4 r;
layout(location=0) out vec4 c0;
void main() { vec4 a = r; float s = 0.0; for (int i = 0; i < int(gl_FragCoord.x) % 7; ++i) s += sin(a[i & 3]) * float(i); if (s > 1.0) discard; c0 = vec4(s, exp2(a.x), sqrt(abs(a.y)), a.z / (abs(a.w) + 1.0)); }
