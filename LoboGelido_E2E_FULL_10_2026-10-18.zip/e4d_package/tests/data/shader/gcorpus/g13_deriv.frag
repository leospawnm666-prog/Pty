#version 460
layout(location=0) in vec4 r;
layout(location=0) out vec4 c0;
void main() { c0 = vec4(dFdx(r.x), dFdy(r.y), fwidth(r.z), r.w); }
