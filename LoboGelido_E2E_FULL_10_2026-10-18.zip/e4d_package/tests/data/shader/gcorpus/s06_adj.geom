#version 460
layout(triangles_adjacency) in;
layout(triangle_strip, max_vertices = 3) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() { for (int i = 0; i < 3; ++i) { gl_Position = gl_in[i * 2].gl_Position; o_r = r[i * 2 + 1]; o_k = k[i * 2] * 1000 + k[i * 2 + 1]; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex(); } }
