#version 460
// draw: triangles 9 1
// attr: 0 f posw
// attr: 1 f rand
// attr: 2 f rand
// rt: 0 f
// rt: 1 f
// rt: 2 u
// varying: 3 u
// depth
// tol: 64
layout(location=0) in vec4 pos;
layout(location=1) in vec4 a;
layout(location=2) in vec4 b;
layout(location=0) out vec4 o_a;
layout(location=1) noperspective out vec3 o_b;
layout(location=2) out float o_s;
layout(location=3) flat out uvec2 o_u;
layout(location=4) flat out float o_f;
void main() { gl_Position = pos; o_a = a; o_b = b.xyz * 2.0; o_s = b.w; o_u = uvec2(floatBitsToUint(a.x), 77u); o_f = b.y * 3.0; }
