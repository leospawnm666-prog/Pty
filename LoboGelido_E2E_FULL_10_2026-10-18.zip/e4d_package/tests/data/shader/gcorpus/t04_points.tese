#version 460
layout(triangles, fractional_even_spacing, ccw, point_mode) in;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    vec3 t = gl_TessCoord;
    gl_Position = t.x * gl_in[0].gl_Position + t.y * gl_in[1].gl_Position + t.z * gl_in[2].gl_Position;
    gl_PointSize = 2.0;
    o_r = vec4(t, 1.0);
    o_k = k[0];
}
