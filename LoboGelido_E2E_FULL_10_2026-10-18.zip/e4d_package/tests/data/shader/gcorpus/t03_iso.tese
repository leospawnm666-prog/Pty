#version 460
layout(isolines, equal_spacing, ccw) in;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    vec2 t = gl_TessCoord.xy;
    gl_Position = mix(gl_in[0].gl_Position, gl_in[1].gl_Position, t.x) + vec4(0.0, t.y * 0.3, 0.0, 0.0);
    o_r = mix(r[0], r[1], t.x);
    o_k = int(t.y * 100.0) + k[0];
}
