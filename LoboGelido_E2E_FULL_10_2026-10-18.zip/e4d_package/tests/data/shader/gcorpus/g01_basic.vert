#version 460
// draw: triangles 6 1
// attr: 0 f pos
// attr: 1 f rand
// rt: 0 f
// rt: 1 i
// varying: 1 i
#ifdef VULKAN
#define VID gl_VertexIndex
#else
#define VID gl_VertexID
#endif
layout(location=0) in vec4 pos;
layout(location=1) in vec4 col;
layout(location=0) out vec4 o_col;
layout(location=1) flat out int o_id;
void main() { gl_Position = pos; o_col = col; o_id = VID * 3 + 1; }
