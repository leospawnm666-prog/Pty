#version 460
// draw: triangles 6 1
// attr: 0 f pos
// attr: 1 f rand
// rt: 0 f
// tol: 256
// cb1: frag 0 1.0
layout(location=0) in vec4 pos;
layout(location=1) in vec4 r;
layout(location=0) out vec4 o_r;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_r = r; }
