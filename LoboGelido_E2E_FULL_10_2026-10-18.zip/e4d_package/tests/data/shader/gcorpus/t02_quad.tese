#version 460
layout(quads, fractional_odd_spacing, cw) in;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    vec2 t = gl_TessCoord.xy;
    vec4 a = mix(gl_in[0].gl_Position, gl_in[1].gl_Position, t.x), b = mix(gl_in[3].gl_Position, gl_in[2].gl_Position, t.x);
    gl_Position = mix(a, b, t.y);
    o_r = mix(mix(r[0], r[1], t.x), mix(r[3], r[2], t.x), t.y);
    o_k = k[0] ^ (k[1] * 3) ^ (k[2] * 5) ^ (k[3] * 7);
}
