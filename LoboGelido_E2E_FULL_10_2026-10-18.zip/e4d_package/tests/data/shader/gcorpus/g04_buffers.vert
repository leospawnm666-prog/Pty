#version 460
// draw: triangles 6 1
// attr: 0 f pos
// rt: 0 f
// ubo: 0 f 64
// ubo: 1 f 16
// buffer: 2 w 64
// buffer: 3 z 4
// tol: 64
#ifdef VULKAN
#define VID gl_VertexIndex
#else
#define VID gl_VertexID
#endif
layout(location=0) in vec4 pos;
layout(location=0) out vec4 o_c;
layout(std140, binding=0) uniform U { mat4 m; vec4 k[3]; } u;
layout(std430, binding=2) buffer S { uint v[]; } sb;
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_c = u.m * pos + u.k[VID % 3]; sb.v[VID] = floatBitsToUint(o_c.x); }
