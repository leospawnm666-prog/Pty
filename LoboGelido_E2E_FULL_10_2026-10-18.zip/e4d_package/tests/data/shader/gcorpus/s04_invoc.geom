#version 460
layout(triangles, invocations = 3) in;
layout(triangle_strip, max_vertices = 3) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
layout(std430, binding=2) buffer S { int v[]; } sb;
void main() {
    sb.v[gl_PrimitiveIDIn * 3 + gl_InvocationID] = gl_InvocationID * 10 + gl_PrimitiveIDIn + 1;
    vec2 off = vec2(gl_InvocationID - 1, 0) * 0.6;
    for (int i = 0; i < 3; ++i) { gl_Position = vec4(gl_in[i].gl_Position.xy * 0.4 + off, 0.5, 1.0); o_r = r[i] + float(gl_InvocationID); o_k = gl_InvocationID; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex(); }
}
