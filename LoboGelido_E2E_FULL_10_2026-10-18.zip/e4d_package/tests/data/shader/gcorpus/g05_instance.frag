#version 460
layout(location=0) flat in ivec2 i;
layout(location=0) out ivec4 c0;
void main() { c0 = ivec4(i, i.x + i.y * 8, -1); }
