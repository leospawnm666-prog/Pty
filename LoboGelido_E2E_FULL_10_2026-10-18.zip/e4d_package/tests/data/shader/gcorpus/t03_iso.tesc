#version 460
layout(vertices = 2) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r[];
layout(location=1) flat out int o_k[];
void main() {
    gl_out[gl_InvocationID].gl_Position = gl_in[gl_InvocationID].gl_Position;
    o_r[gl_InvocationID] = r[gl_InvocationID];
    o_k[gl_InvocationID] = k[gl_InvocationID];
    gl_TessLevelOuter[0] = 3.0; gl_TessLevelOuter[1] = 5.0;
}
