#version 460
layout(location=0) flat in ivec4 i;
layout(location=1) flat in uvec4 u;
layout(location=0) out vec4 c0;
layout(location=1) out uvec4 c1;
layout(location=2) out ivec4 c2;
layout(location=3) out vec4 c3;
void main() { c0 = vec4(i); c1 = u + uvec4(1, 2, 3, 4); c2 = i.wzyx; c3 = vec4(u.xy, -1.5, 2.5); }
