#version 460
layout(points) in;
layout(triangle_strip, max_vertices = 4) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r;
layout(location=1) flat out int o_k;
void main() {
    const vec2 c[4] = vec2[](vec2(-1, -1), vec2(1, -1), vec2(-1, 1), vec2(1, 1));
    float s = 0.03 + abs(r[0].x) * 0.05;
    for (int i = 0; i < 4; ++i) { gl_Position = gl_in[0].gl_Position + vec4(c[i] * s, 0.0, 0.0); o_r = vec4(c[i], r[0].zw); o_k = k[0] * 4 + i; gl_PrimitiveID = gl_PrimitiveIDIn; EmitVertex(); }
}
