#version 460
// invocation 0 reads the other invocations' outputs inside a branch (the common tess-level pattern)
layout(vertices = 3) out;
layout(location=0) in vec4 r[];
layout(location=1) flat in int k[];
layout(location=0) out vec4 o_r[];
layout(location=1) flat out int o_k[];
void main() {
    gl_out[gl_InvocationID].gl_Position = gl_in[gl_InvocationID].gl_Position;
    o_r[gl_InvocationID] = r[gl_InvocationID] * float(gl_InvocationID + 2);
    o_k[gl_InvocationID] = k[gl_InvocationID] + 1000 * gl_InvocationID;
    barrier();
    if (gl_InvocationID == 0) {
        float s = abs(o_r[1].x) + abs(o_r[2].y);
        gl_TessLevelOuter[0] = 1.0 + floor(s);
        gl_TessLevelOuter[1] = 2.0 + float(o_k[2] & 1);
        gl_TessLevelOuter[2] = 3.0;
        gl_TessLevelInner[0] = 2.0 + floor(abs(o_r[2].z));
    }
}
