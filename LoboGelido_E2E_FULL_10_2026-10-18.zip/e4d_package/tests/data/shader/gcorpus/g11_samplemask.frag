#version 460
layout(location=0) in vec4 p;
layout(location=0) out vec4 c0;
layout(location=1) out vec4 c1;
void main() { c0 = p; c1 = p.yxwz; gl_SampleMask[0] = (int(gl_FragCoord.x) & 1) == 0 ? 1 : 0; gl_FragDepth = 0.25; }
