#version 460
// draw: triangles 9 1
// attr: 0 f pos
// attr: 1 f rand
// rt: 0 f
// tol: 64
layout(location=0) in vec4 pos;
layout(location=1) in vec4 r;
layout(location=0) out vec4 o_r;
out float gl_ClipDistance[2];
void main() { gl_Position = vec4(pos.xy, 0.5, 1.0); o_r = r; gl_ClipDistance[0] = pos.x + 0.3; gl_ClipDistance[1] = r.y; }
