#include "lg_check.h"   // strict checks: never compiled out (P3.0 test hygiene)
#include <cassert>
#include "../gpu/vulkan_presenter.h"
int main(){ lg::gpu::VulkanPresenter p; LG_CHECK(!p.ready()); LG_CHECK(!p.draw_frame().ok()); LG_CHECK(p.diagnostics().find("presenter=OFF")!=std::string::npos); return 0; }
