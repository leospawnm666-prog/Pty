#include "vk_dispatch.h"

#if LG_HAS_VULKAN

#include <atomic>

namespace lg::gpu::vkfn {
#define LG_VK_DEFINE(name) LG_VK_HIDDEN PFN_##name name = nullptr;
LG_VK_DEFINE(vkGetInstanceProcAddr)
LG_VK_GLOBAL_REQUIRED(LG_VK_DEFINE)
LG_VK_GLOBAL_OPTIONAL(LG_VK_DEFINE)
LG_VK_INSTANCE_REQUIRED(LG_VK_DEFINE)
LG_VK_INSTANCE_SURFACE(LG_VK_DEFINE)
LG_VK_INSTANCE_ANDROID_SURFACE(LG_VK_DEFINE)
LG_VK_DEVICE_REQUIRED(LG_VK_DEFINE)
LG_VK_DEVICE_SWAPCHAIN(LG_VK_DEFINE)
#undef LG_VK_DEFINE
} // namespace lg::gpu::vkfn

namespace lg::gpu {
namespace {

std::atomic<bool> g_table_owned{false};

// Appends `name` to the comma-separated `missing` list.
void note_missing(std::string& missing, const char* name) {
    if (!missing.empty()) missing += ", ";
    missing += name;
}

core::Result<void> finish(const char* level, const std::string& missing) {
    if (missing.empty()) return core::Result<void>::Ok();
    return core::Result<void>::Error(std::string("driver lacks required ") + level +
                                     " entry points: " + missing);
}

} // namespace

const char* driver_kind_name(VkDriverKind kind) noexcept {
    switch (kind) {
        case VkDriverKind::System: return "system";
        case VkDriverKind::Custom: return "custom";
        case VkDriverKind::None: break;
    }
    return "none";
}

core::Result<void> VulkanDispatch::load_global(PFN_vkGetInstanceProcAddr gipa) {
    if (!gipa) return core::Result<void>::Error("null vkGetInstanceProcAddr");
    vkfn::vkGetInstanceProcAddr = gipa;
    std::string missing;
#define LG_VK_LOAD_REQUIRED(name)                                                        \
    vkfn::name = reinterpret_cast<PFN_##name>(gipa(VK_NULL_HANDLE, #name));              \
    if (!vkfn::name) note_missing(missing, #name);
#define LG_VK_LOAD_OPTIONAL(name) \
    vkfn::name = reinterpret_cast<PFN_##name>(gipa(VK_NULL_HANDLE, #name));
    LG_VK_GLOBAL_REQUIRED(LG_VK_LOAD_REQUIRED)
    LG_VK_GLOBAL_OPTIONAL(LG_VK_LOAD_OPTIONAL)
#undef LG_VK_LOAD_REQUIRED
#undef LG_VK_LOAD_OPTIONAL
    return finish("global", missing);
}

core::Result<void> VulkanDispatch::load_instance(VkInstance instance, bool with_surface) {
    if (!instance || !vkfn::vkGetInstanceProcAddr)
        return core::Result<void>::Error("load_instance before load_global / null instance");
    const auto gipa = vkfn::vkGetInstanceProcAddr;
    std::string missing;
#define LG_VK_LOAD(name)                                                                 \
    vkfn::name = reinterpret_cast<PFN_##name>(gipa(instance, #name));                   \
    if (!vkfn::name) note_missing(missing, #name);
    // vkDestroyInstance is first in the list so it resolves even if later ones fail,
    // letting the owning InstanceHandle clean up.
    LG_VK_INSTANCE_REQUIRED(LG_VK_LOAD)
    if (with_surface) {
        LG_VK_INSTANCE_SURFACE(LG_VK_LOAD)
        LG_VK_INSTANCE_ANDROID_SURFACE(LG_VK_LOAD)
    }
#undef LG_VK_LOAD
    return finish("instance", missing);
}

core::Result<void> VulkanDispatch::load_device(VkDevice device, bool with_swapchain) {
    if (!device || !vkfn::vkGetDeviceProcAddr)
        return core::Result<void>::Error("load_device before load_instance / null device");
    const auto gdpa = vkfn::vkGetDeviceProcAddr;
    std::string missing;
#define LG_VK_LOAD(name)                                                                 \
    vkfn::name = reinterpret_cast<PFN_##name>(gdpa(device, #name));                     \
    if (!vkfn::name) note_missing(missing, #name);
    LG_VK_DEVICE_REQUIRED(LG_VK_LOAD)
    if (with_swapchain) {
        LG_VK_DEVICE_SWAPCHAIN(LG_VK_LOAD)
    }
#undef LG_VK_LOAD
    return finish("device", missing);
}

void VulkanDispatch::reset() noexcept {
#define LG_VK_CLEAR(name) vkfn::name = nullptr;
    LG_VK_CLEAR(vkGetInstanceProcAddr)
    LG_VK_GLOBAL_REQUIRED(LG_VK_CLEAR)
    LG_VK_GLOBAL_OPTIONAL(LG_VK_CLEAR)
    LG_VK_INSTANCE_REQUIRED(LG_VK_CLEAR)
    LG_VK_INSTANCE_SURFACE(LG_VK_CLEAR)
    LG_VK_INSTANCE_ANDROID_SURFACE(LG_VK_CLEAR)
    LG_VK_DEVICE_REQUIRED(LG_VK_CLEAR)
    LG_VK_DEVICE_SWAPCHAIN(LG_VK_CLEAR)
#undef LG_VK_CLEAR
}

DispatchScope& DispatchScope::operator=(DispatchScope&& other) noexcept {
    if (this != &other) {
        release();
        active_ = other.active_;
        other.active_ = false;
    }
    return *this;
}

core::Result<void> DispatchScope::acquire() {
    if (active_) return core::Result<void>::Ok();
    bool expected = false;
    if (!g_table_owned.compare_exchange_strong(expected, true, std::memory_order_acq_rel))
        return core::Result<void>::Error("another Vulkan driver session owns the dispatch table");
    VulkanDispatch::reset();
    active_ = true;
    return core::Result<void>::Ok();
}

void DispatchScope::release() noexcept {
    if (!active_) return;
    VulkanDispatch::reset();
    active_ = false;
    g_table_owned.store(false, std::memory_order_release);
}

} // namespace lg::gpu

#endif // LG_HAS_VULKAN
