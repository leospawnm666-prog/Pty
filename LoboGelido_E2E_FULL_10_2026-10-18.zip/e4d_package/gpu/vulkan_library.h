#pragma once
#include "vk_dispatch.h"

#if LG_HAS_VULKAN

#include <string>

namespace lg::gpu {

// RAII owner of one dynamically loaded Vulkan driver library.
//
//  * System path: the platform loader (libvulkan.so on Android). The app does not link
//    it; it is dlopen'ed like any other driver so every call goes through the table.
//  * Custom path: an ICD such as Mesa Turnip copied into app-private storage
//    (libvulkan_freedreno.so, vulkan.adreno.so, ...). A directory is accepted for
//    backward compatibility and resolved to <dir>/libvulkan.so.
//
// The entry point is `vkGetInstanceProcAddr`; ICD-only builds that export just
// `vk_icdGetInstanceProcAddr` are accepted as a fallback.
//
// Move-only. The library stays loaded until close()/destruction, which must happen
// AFTER every Vulkan object created through it is destroyed (AndroidVulkanContext
// guarantees this through member declaration order).
class VulkanLibrary {
public:
    VulkanLibrary() = default;
    ~VulkanLibrary() { close(); }
    VulkanLibrary(const VulkanLibrary&) = delete;
    VulkanLibrary& operator=(const VulkanLibrary&) = delete;
    VulkanLibrary(VulkanLibrary&& other) noexcept;
    VulkanLibrary& operator=(VulkanLibrary&& other) noexcept;

    // `soname_or_path` is handed to dlopen as-is (library search path applies).
    core::Result<void> open_system(const std::string& soname_or_path);
    // `path` must name a regular .so file (or a directory holding libvulkan.so).
    core::Result<void> open_custom(const std::string& path);
    void close() noexcept;

    bool loaded() const noexcept { return handle_ != nullptr; }
    VkDriverKind kind() const noexcept { return kind_; }
    const std::string& path() const noexcept { return path_; }
    PFN_vkGetInstanceProcAddr get_instance_proc_addr() const noexcept { return gipa_; }

private:
    core::Result<void> load(const std::string& target, VkDriverKind kind);

    void* handle_{nullptr};
    PFN_vkGetInstanceProcAddr gipa_{nullptr};
    VkDriverKind kind_{VkDriverKind::None};
    std::string path_;
};

} // namespace lg::gpu

#endif // LG_HAS_VULKAN
