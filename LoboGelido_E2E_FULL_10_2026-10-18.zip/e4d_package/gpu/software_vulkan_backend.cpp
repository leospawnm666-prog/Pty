#include "software_vulkan_backend.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>

namespace lg::gpu {
namespace {

std::string lower(std::string_view s) {
    std::string o(s);
    std::transform(o.begin(), o.end(), o.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return o;
}

std::string_view basename_view(std::string_view path) {
    const auto pos = path.find_last_of("/\\");
    return pos == std::string_view::npos ? path : path.substr(pos + 1);
}

bool contains_ci(std::string_view hay, std::string_view needle) {
    return lower(hay).find(lower(needle)) != std::string::npos;
}

} // namespace

const char* software_kind_name(SoftwareVulkanKind kind) noexcept {
    switch (kind) {
        case SoftwareVulkanKind::SwiftShader: return "swiftshader";
        case SoftwareVulkanKind::Lavapipe: return "lavapipe";
        case SoftwareVulkanKind::None: return "none";
    }
    return "none";
}

SoftwareVulkanIdentity classify_software_driver(std::string_view path_or_name) noexcept {
    const std::string n = lower(basename_view(path_or_name));
    const std::string full = lower(path_or_name);

    if (n.find("swiftshader") != std::string::npos ||
        n.find("vk_swiftshader") != std::string::npos ||
        full.find("swiftshader") != std::string::npos) {
        return {SoftwareVulkanKind::SwiftShader, "swiftshader", "Google SwiftShader", 0x1AE0};
    }

    if (n.find("lavapipe") != std::string::npos ||
        n.find("vulkan_lvp") != std::string::npos ||
        (n.find("lvp") != std::string::npos && n.find("vulkan") != std::string::npos) ||
        full.find("lavapipe") != std::string::npos ||
        full.find("/lvp/") != std::string::npos) {
        return {SoftwareVulkanKind::Lavapipe, "lavapipe", "Mesa Lavapipe", 0x10005};
    }

    return {};
}

bool is_software_vulkan_path(std::string_view path_or_name) noexcept {
    return classify_software_driver(path_or_name).kind != SoftwareVulkanKind::None;
}

bool looks_like_software_gpu(uint32_t vendor_id, std::string_view device_name) noexcept {
    if (vendor_id == 0x1AE0 || vendor_id == 0x10005 || vendor_id == 0x10002) return true;
    const std::string n = lower(device_name);
    return n.find("swiftshader") != std::string::npos ||
           n.find("lavapipe") != std::string::npos ||
           n.find("llvmpipe") != std::string::npos ||
           n.find("softpipe") != std::string::npos ||
           n.find("cpu") != std::string::npos;
}

int score_software_device(SoftwareVulkanKind want, uint32_t vendor_id, std::string_view device_name) noexcept {
    int score = 0;
    const std::string n = lower(device_name);
    if (want == SoftwareVulkanKind::SwiftShader) {
        if (vendor_id == 0x1AE0) score += 100;
        if (n.find("swiftshader") != std::string::npos) score += 80;
    } else if (want == SoftwareVulkanKind::Lavapipe) {
        if (vendor_id == 0x10005 || vendor_id == 0x10002) score += 100;
        if (n.find("lavapipe") != std::string::npos || n.find("llvmpipe") != std::string::npos) score += 80;
        if (n.find("softpipe") != std::string::npos) score += 40;
    } else {
        if (looks_like_software_gpu(vendor_id, device_name)) score += 50;
    }
    // Prefer known software names over random devices in multi-ICD processes
    if (looks_like_software_gpu(vendor_id, device_name)) score += 10;
    return score;
}

std::vector<std::string> software_library_hints(SoftwareVulkanKind kind) {
    switch (kind) {
        case SoftwareVulkanKind::SwiftShader:
            return {
                "libvk_swiftshader.so",
                "libswiftshader_libvulkan.so",
                "vk_swiftshader.dll",
                "libvk_swiftshader.dylib",
            };
        case SoftwareVulkanKind::Lavapipe:
            return {
                "libvulkan_lvp.so",
                "vulkan_lvp.dll",
            };
        case SoftwareVulkanKind::None:
            break;
    }
    return {};
}

std::string find_software_library(std::string_view root_dir, SoftwareVulkanKind kind) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const fs::path root{std::string(root_dir)};
    if (!fs::exists(root, ec) || !fs::is_directory(root, ec)) return {};

    const auto hints = software_library_hints(kind);
    for (const auto& hint : hints) {
        const fs::path candidate = root / hint;
        if (fs::is_regular_file(candidate, ec)) return candidate.string();
    }
    for (fs::directory_iterator it(root, ec); !ec && it != fs::directory_iterator(); it.increment(ec)) {
        if (!it->is_regular_file(ec)) continue;
        const auto p = it->path().string();
        if (classify_software_driver(p).kind == kind) return p;
    }
    return {};
}

std::string library_from_icd_env() noexcept {
    const char* env = std::getenv("VK_ICD_FILENAMES");
    if (!env || !*env) env = std::getenv("VK_DRIVER_FILES");
    if (!env || !*env) return {};

    // May be a colon/semicolon-separated list of JSON paths
    std::string list(env);
    const char sep =
#if defined(_WIN32)
        ';';
#else
        ':';
#endif
    std::stringstream ss(list);
    std::string json_path;
    while (std::getline(ss, json_path, sep)) {
        if (json_path.empty()) continue;
        std::ifstream in(json_path);
        if (!in) continue;
        std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        // Minimal parse: "library_path": "...."
        const auto key = content.find("\"library_path\"");
        if (key == std::string::npos) continue;
        const auto colon = content.find(':', key);
        const auto q1 = content.find('"', colon + 1);
        const auto q2 = content.find('"', q1 + 1);
        if (q1 == std::string::npos || q2 == std::string::npos) continue;
        std::string lib = content.substr(q1 + 1, q2 - q1 - 1);
        if (!lib.empty()) return lib;
    }
    return {};
}

core::Result<WrittenIcdJson> write_software_icd_json(std::string_view library_path,
                                                     SoftwareVulkanKind kind,
                                                     std::string_view output_dir) {
    if (kind == SoftwareVulkanKind::None)
        return core::Result<WrittenIcdJson>::Error("software kind is none");
    if (library_path.empty())
        return core::Result<WrittenIcdJson>::Error("library path empty");

    namespace fs = std::filesystem;
    std::error_code ec;
    fs::path out_dir{std::string(output_dir)};
    if (out_dir.empty()) out_dir = fs::path{std::string(library_path)}.parent_path();
    fs::create_directories(out_dir, ec);

    const char* file_name = kind == SoftwareVulkanKind::SwiftShader ? "vk_swiftshader_icd.json"
                                                                     : "vk_lavapipe_icd.json";
    const fs::path json_path = out_dir / file_name;

    std::ofstream out(json_path, std::ios::binary | std::ios::trunc);
    if (!out)
        return core::Result<WrittenIcdJson>::Error("cannot write ICD json");
    out << "{\n"
        << "    \"file_format_version\": \"1.0.0\",\n"
        << "    \"ICD\": {\n"
        << "        \"library_path\": \"" << library_path << "\",\n"
        << "        \"api_version\": \"1.1.0\"\n"
        << "    }\n"
        << "}\n";
    out.close();
    if (!out)
        return core::Result<WrittenIcdJson>::Error("ICD json write failed");
    return core::Result<WrittenIcdJson>::Ok(WrittenIcdJson{json_path.string()});
}


SoftwareVulkanKind parse_software_kind(std::string_view name) noexcept {
    const std::string n = lower(name);
    if (n == "swiftshader" || n == "swift" || n == "ss") return SoftwareVulkanKind::SwiftShader;
    if (n == "lavapipe" || n == "lvp" || n == "mesa" || n == "llvmpipe") return SoftwareVulkanKind::Lavapipe;
    return SoftwareVulkanKind::None;
}

SoftwareResolveReport resolve_software_library_report(SoftwareVulkanKind kind) noexcept {
    SoftwareResolveReport r;
    r.kind = kind;
    if (kind == SoftwareVulkanKind::None) {
        r.source = "none";
        r.detail = "kind is none";
        return r;
    }

    if (const char* forced = std::getenv("LOBO_SOFTWARE_VULKAN_LIB"); forced && *forced) {
        const auto id = classify_software_driver(forced);
        if (id.kind == kind || id.kind == SoftwareVulkanKind::None) {
            r.path = forced;
            r.source = "forced_lib";
            r.detail = "LOBO_SOFTWARE_VULKAN_LIB";
            return r;
        }
        r.detail = "LOBO_SOFTWARE_VULKAN_LIB kind mismatch";
    }

    if (std::string from_env = library_from_icd_env(); !from_env.empty()) {
        const auto id = classify_software_driver(from_env);
        if (id.kind == kind || id.kind == SoftwareVulkanKind::None) {
            r.path = std::move(from_env);
            r.source = "icd_env";
            r.detail = "VK_ICD_FILENAMES";
            return r;
        }
    }

    std::vector<std::string> roots;
    if (const char* root_env = std::getenv("LOBO_SOFTWARE_VULKAN_ROOT"); root_env && *root_env)
        roots.emplace_back(root_env);
    for (const char* d : {".", "./build", "./third_party/swiftshader", "./third_party/mesa",
                          "/usr/lib", "/usr/lib/x86_64-linux-gnu"}) {
        roots.emplace_back(d);
    }

    for (const auto& root : roots) {
        if (std::string found = find_software_library(root, kind); !found.empty()) {
            r.path = std::move(found);
            r.source = "search_root";
            r.detail = "filesystem search";
            return r;
        }
    }
    r.source = "none";
    if (!r.detail || !*r.detail)
        r.detail = "no ICD found in env or search roots";
    return r;
}

std::string resolve_software_library(SoftwareVulkanKind kind) noexcept {
    return resolve_software_library_report(kind).path;
}

} // namespace lg::gpu
