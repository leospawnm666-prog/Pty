#include "adreno_driver_loader.h"

// Retained public API (Regla de Oro). Since P1 the library handling lives in
// VulkanLibrary (gpu/vulkan_library.h), which AndroidVulkanContext uses directly; this
// class keeps its original contract as a thin, standalone adapter over it. It never
// touches the process-wide dispatch table, so it cannot interfere with the active
// Vulkan session.

#include "vk_dispatch.h"

#include <memory>

#if LG_HAS_VULKAN
#include "vulkan_library.h"
#endif

namespace lg::gpu {

AdrenoDriverLoader::~AdrenoDriverLoader() { close(); }

bool AdrenoDriverLoader::open(const std::string& driver_path) {
    close();
#if !LG_HAS_VULKAN
    (void)driver_path;
    error_ = "custom Vulkan driver loading is Android-only";
    return false;
#else
    auto lib = std::make_unique<VulkanLibrary>();
    auto opened = lib->open_custom(driver_path);
    if (!opened.ok()) {
        error_ = opened.error();
        return false;
    }
    instance_proc_addr_ = reinterpret_cast<void*>(lib->get_instance_proc_addr());
    resolved_path_ = lib->path();
    custom_ = true;
    library_ = lib.release();   // owned; released in close()
    return true;
#endif
}

void AdrenoDriverLoader::close() noexcept {
#if LG_HAS_VULKAN
    delete static_cast<VulkanLibrary*>(library_);   // RAII dlclose
#endif
    library_ = nullptr;
    instance_proc_addr_ = nullptr;
    custom_ = false;
    resolved_path_.clear();
}

void* AdrenoDriverLoader::instance_proc_addr(void* instance, const char* name) const noexcept {
#if LG_HAS_VULKAN
    if (!instance_proc_addr_ || !name) return nullptr;
    auto get = reinterpret_cast<PFN_vkGetInstanceProcAddr>(instance_proc_addr_);
    return reinterpret_cast<void*>(get(reinterpret_cast<VkInstance>(instance), name));
#else
    (void)instance;
    (void)name;
    return nullptr;
#endif
}

} // namespace lg::gpu
