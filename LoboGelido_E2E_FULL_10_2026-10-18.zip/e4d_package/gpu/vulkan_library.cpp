#include "vulkan_library.h"

#if LG_HAS_VULKAN

#include <dlfcn.h>
#include <sys/stat.h>

#include <utility>

namespace lg::gpu {
namespace {

bool is_directory(const std::string& p) {
    struct stat st{};
    return ::stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool is_regular_file(const std::string& p) {
    struct stat st{};
    return ::stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode);
}

bool ends_with(const std::string& s, const char* suffix) {
    const std::string suf(suffix);
    return s.size() >= suf.size() && s.compare(s.size() - suf.size(), suf.size(), suf) == 0;
}

} // namespace

VulkanLibrary::VulkanLibrary(VulkanLibrary&& other) noexcept
    : handle_(std::exchange(other.handle_, nullptr)),
      gipa_(std::exchange(other.gipa_, nullptr)),
      kind_(std::exchange(other.kind_, VkDriverKind::None)),
      path_(std::move(other.path_)) {}

VulkanLibrary& VulkanLibrary::operator=(VulkanLibrary&& other) noexcept {
    if (this != &other) {
        close();
        handle_ = std::exchange(other.handle_, nullptr);
        gipa_ = std::exchange(other.gipa_, nullptr);
        kind_ = std::exchange(other.kind_, VkDriverKind::None);
        path_ = std::move(other.path_);
    }
    return *this;
}

core::Result<void> VulkanLibrary::open_system(const std::string& soname_or_path) {
    if (soname_or_path.empty()) return core::Result<void>::Error("empty system Vulkan library name");
    return load(soname_or_path, VkDriverKind::System);
}

core::Result<void> VulkanLibrary::open_custom(const std::string& path) {
    if (path.empty()) return core::Result<void>::Error("empty custom Vulkan driver path");
    std::string target = path;
    if (is_directory(target)) target += "/libvulkan.so";
    if (!is_regular_file(target))
        return core::Result<void>::Error("custom Vulkan driver is not a regular file: " + target);
    if (!ends_with(target, ".so"))
        return core::Result<void>::Error("custom Vulkan driver must be a .so: " + target);
    return load(target, VkDriverKind::Custom);
}

core::Result<void> VulkanLibrary::load(const std::string& target, VkDriverKind kind) {
    close();
    dlerror(); // clear stale state
    void* handle = ::dlopen(target.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!handle) {
        const char* e = dlerror();
        return core::Result<void>::Error(std::string("dlopen(") + target + ") failed: " +
                                         (e ? e : "unknown error"));
    }

    // Resolve the bootstrap entry point. Prefer the public name; accept the ICD name.
    void* sym = ::dlsym(handle, "vkGetInstanceProcAddr");
    if (!sym) sym = ::dlsym(handle, "vk_icdGetInstanceProcAddr");
    if (!sym) {
        ::dlclose(handle);
        return core::Result<void>::Error(target +
            " exports neither vkGetInstanceProcAddr nor vk_icdGetInstanceProcAddr");
    }

    handle_ = handle;
    gipa_ = reinterpret_cast<PFN_vkGetInstanceProcAddr>(sym);
    kind_ = kind;
    path_ = target;
    return core::Result<void>::Ok();
}

void VulkanLibrary::close() noexcept {
    if (handle_) ::dlclose(handle_);
    handle_ = nullptr;
    gipa_ = nullptr;
    kind_ = VkDriverKind::None;
    path_.clear();
}

} // namespace lg::gpu

#endif // LG_HAS_VULKAN
