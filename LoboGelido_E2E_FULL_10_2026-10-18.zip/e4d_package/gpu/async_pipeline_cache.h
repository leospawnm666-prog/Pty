#pragma once
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace lg::gpu {

enum class PipelineStatus : uint8_t { Missing, Compiling, Ready, Failed };
using PipelineHandle = uint64_t;

/**
 * Asynchronous pipeline compilation with disk-backed semantic key cache.
 * Vulkan handles are never serialized — only keys — so cache survives process
 * restarts and recompiles on the active device without blocking the frame path.
 */
class AsyncPipelineCache {
public:
    using CompileFn = std::function<bool(uint64_t key, PipelineHandle& out_handle)>;
    using WorkerInit = std::function<void()>;

    explicit AsyncPipelineCache(CompileFn compiler, unsigned workers = 4, WorkerInit on_worker_start = {});
    ~AsyncPipelineCache();
    AsyncPipelineCache(const AsyncPipelineCache&) = delete;
    AsyncPipelineCache& operator=(const AsyncPipelineCache&) = delete;

    PipelineStatus get(uint64_t key, PipelineHandle& out_handle);
    /** High priority: jump the queue (first-time critical shaders). */
    PipelineStatus get_priority(uint64_t key, PipelineHandle& out_handle);
    void wait_idle();
    void invalidate_runtime_handles();

    // Persist semantic keys only (main-line format: u32 count + u64 keys). load() also accepts the
    // "LPK1" files written by the CLEAN branch. Restored keys are Missing and compile on demand.
    std::vector<uint8_t> serialize() const;
    size_t load(const std::vector<uint8_t>& blob);

    /** Persist/load under <root>/<title_id>.pkeys */
    bool save_to_disk(const std::string& root, const std::string& title_id) const;
    size_t load_from_disk(const std::string& root, const std::string& title_id);

    bool has_known_key(uint64_t key) const;
    size_t ready_count() const;
    size_t pending_count() const;
    uint64_t compiled() const { return compiled_.load(); }
    uint64_t cache_hits() const { return hits_.load(); }
    uint64_t failures() const { return failures_.load(); }
    std::string diagnostics() const;

private:
    struct Entry { PipelineStatus status{PipelineStatus::Missing}; PipelineHandle handle{0}; };
    void worker_loop();
    void queue_locked(uint64_t key, Entry& entry, bool priority);

    CompileFn compiler_;
    WorkerInit on_worker_start_;
    mutable std::mutex mutex_;
    std::condition_variable queue_cv_;
    std::condition_variable idle_cv_;
    std::unordered_map<uint64_t, Entry> entries_;
    std::deque<uint64_t> queue_;
    std::vector<std::thread> workers_;
    int in_flight_{0};
    bool stop_{false};
    std::atomic<uint64_t> compiled_{0};
    std::atomic<uint64_t> hits_{0};
    std::atomic<uint64_t> failures_{0};
};

} // namespace lg::gpu
