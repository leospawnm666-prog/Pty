#include "vulkan_driver_policy.h"
#include "software_vulkan_backend.h"

#include <cstdio>

namespace lg::gpu {

const char* gpu_vendor_name(uint32_t vendor_id) noexcept {
    switch (vendor_id) {
        case kVendorQualcomm:    return "Qualcomm Adreno";
        case kVendorArm:         return "ARM Mali";
        case kVendorImagination: return "Imagination PowerVR";
        case kVendorSamsung:     return "Samsung Xclipse";
        case kVendorAmd:         return "AMD";
        case kVendorNvidia:      return "NVIDIA";
        case kVendorGoogle:      return "Google SwiftShader";
        case kVendorMesa:        return "Mesa Lavapipe";
        case kVendorIntel:       return "Intel";
        default:                 return "unknown";
    }
}

std::string format_vendor(uint32_t vendor_id) {
    char buf[64];
    std::snprintf(buf, sizeof(buf), "0x%04X (%s)", vendor_id, gpu_vendor_name(vendor_id));
    return buf;
}

CustomDriverDecision evaluate_custom_driver(std::optional<uint32_t> host_vendor,
                                            bool adreno_kernel_node_present) {
    if (host_vendor) {
        if (*host_vendor == kVendorQualcomm)
            return {true, "host GPU " + format_vendor(*host_vendor)};
        return {false, "custom driver rejected: host GPU " + format_vendor(*host_vendor) +
                       " is not Qualcomm Adreno"};
    }
    if (adreno_kernel_node_present)
        return {true, "system Vulkan unavailable; Adreno kernel node present"};
    return {false, "custom driver rejected: host GPU vendor unknown and no Adreno kernel node"};
}

CustomDriverDecision evaluate_driver_path(const std::string& custom_path,
                                          std::optional<uint32_t> host_vendor,
                                          bool adreno_kernel_node_present) {
    if (custom_path.empty())
        return {false, "custom driver path empty"};
    if (is_software_vulkan_path(custom_path)) {
        const auto id = classify_software_driver(custom_path);
        return {true, std::string("software Vulkan allowed: ") + id.label + " (" + id.vendor_hint + ")"};
    }
    return evaluate_custom_driver(host_vendor, adreno_kernel_node_present);
}

} // namespace lg::gpu
