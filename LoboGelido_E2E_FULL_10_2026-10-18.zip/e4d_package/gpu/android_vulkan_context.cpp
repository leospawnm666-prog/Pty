#include "android_vulkan_context.h"

#include "vk_dispatch.h"
#include "vulkan_driver_policy.h"
#include "software_vulkan_backend.h"

#include <utility>

#if LG_HAS_VULKAN

#include "vulkan_library.h"

#if defined(__ANDROID__)
#include <android/native_window.h>
#endif
#include <unistd.h>

#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <map>
#include <mutex>
#include <optional>
#include <sstream>
#include <utility>
#include <vector>

namespace lg::gpu {
namespace {

constexpr uint32_t kMaxApiVersion = VK_API_VERSION_1_1;
const std::string kEmpty;

const char* result_name(VkResult r) noexcept {
    switch (r) {
        case VK_SUCCESS: return "VK_SUCCESS";
        case VK_INCOMPLETE: return "VK_INCOMPLETE";
        case VK_ERROR_OUT_OF_HOST_MEMORY: return "VK_ERROR_OUT_OF_HOST_MEMORY";
        case VK_ERROR_OUT_OF_DEVICE_MEMORY: return "VK_ERROR_OUT_OF_DEVICE_MEMORY";
        case VK_ERROR_INITIALIZATION_FAILED: return "VK_ERROR_INITIALIZATION_FAILED";
        case VK_ERROR_DEVICE_LOST: return "VK_ERROR_DEVICE_LOST";
        case VK_ERROR_LAYER_NOT_PRESENT: return "VK_ERROR_LAYER_NOT_PRESENT";
        case VK_ERROR_EXTENSION_NOT_PRESENT: return "VK_ERROR_EXTENSION_NOT_PRESENT";
        case VK_ERROR_FEATURE_NOT_PRESENT: return "VK_ERROR_FEATURE_NOT_PRESENT";
        case VK_ERROR_INCOMPATIBLE_DRIVER: return "VK_ERROR_INCOMPATIBLE_DRIVER";
        case VK_ERROR_SURFACE_LOST_KHR: return "VK_ERROR_SURFACE_LOST_KHR";
        case VK_ERROR_NATIVE_WINDOW_IN_USE_KHR: return "VK_ERROR_NATIVE_WINDOW_IN_USE_KHR";
        default: return "VkResult(other)";
    }
}

core::Result<void> vk_fail(const char* call, VkResult r) {
    return core::Result<void>::Error(std::string(call) + " -> " + result_name(r));
}

void append(std::string& list, const std::string& item) {
    if (!list.empty()) list += ", ";
    list += item;
}

// ---- RAII owners (non-movable: they live inside a heap-allocated Session) ---------
// Each destroys through the ACTIVE dispatch table, which the owning Session keeps
// loaded until these members are gone (see Session member order).

class InstanceHandle {
public:
    InstanceHandle() = default;
    ~InstanceHandle() { reset(); }
    InstanceHandle(const InstanceHandle&) = delete;
    InstanceHandle& operator=(const InstanceHandle&) = delete;
    void adopt(VkInstance h) noexcept { reset(); h_ = h; }
    void reset() noexcept {
        if (h_ && vkDestroyInstance) vkDestroyInstance(h_, nullptr);
        h_ = VK_NULL_HANDLE;
    }
    VkInstance get() const noexcept { return h_; }
private:
    VkInstance h_{VK_NULL_HANDLE};
};

class SurfaceHandle {
public:
    SurfaceHandle() = default;
    ~SurfaceHandle() { reset(); }
    SurfaceHandle(const SurfaceHandle&) = delete;
    SurfaceHandle& operator=(const SurfaceHandle&) = delete;
    void adopt(VkInstance owner, VkSurfaceKHR h) noexcept { reset(); owner_ = owner; h_ = h; }
    void reset() noexcept {
        if (h_ && owner_ && vkDestroySurfaceKHR) vkDestroySurfaceKHR(owner_, h_, nullptr);
        h_ = VK_NULL_HANDLE;
        owner_ = VK_NULL_HANDLE;
    }
    VkSurfaceKHR get() const noexcept { return h_; }
private:
    VkInstance owner_{VK_NULL_HANDLE};
    VkSurfaceKHR h_{VK_NULL_HANDLE};
};

class DeviceHandle {
public:
    DeviceHandle() = default;
    ~DeviceHandle() { reset(); }
    DeviceHandle(const DeviceHandle&) = delete;
    DeviceHandle& operator=(const DeviceHandle&) = delete;
    void adopt(VkDevice h) noexcept { reset(); h_ = h; }
    void reset() noexcept {
        if (h_) {
            if (vkDeviceWaitIdle) vkDeviceWaitIdle(h_);
            if (vkDestroyDevice) vkDestroyDevice(h_, nullptr);
        }
        h_ = VK_NULL_HANDLE;
    }
    VkDevice get() const noexcept { return h_; }
private:
    VkDevice h_{VK_NULL_HANDLE};
};

} // namespace

// Declaration order IS the teardown contract: members are destroyed in reverse, so the
// device goes first, then the surface (frees the ANativeWindow), the instance, the
// dispatch table (pointers nulled) and finally the driver library (dlclose).
struct AndroidVulkanContext::Session {
    VulkanLibrary library;
    DispatchScope dispatch;
    InstanceHandle instance;
    SurfaceHandle surface;
    DeviceHandle device;

    VkPhysicalDevice physical_device{VK_NULL_HANDLE};
    VkQueue queue{VK_NULL_HANDLE};
    uint32_t queue_family{UINT32_MAX};
    uint32_t api_version{0};
    uint32_t vendor_id{0};
    uint32_t device_id{0};
    std::string gpu_name;
};

namespace {

using Session = AndroidVulkanContext::Session;

struct BringUpRequest {
    VkDriverKind kind{VkDriverKind::System};
    std::string library;          // soname (system) or file path (custom)
    void* android_surface{nullptr};
    bool require_qualcomm{false};
    SoftwareVulkanKind prefer_software{SoftwareVulkanKind::None};
    bool require_software_device{false};
};

core::Result<void> open_driver(Session& s, const BringUpRequest& req) {
    auto opened = req.kind == VkDriverKind::Custom ? s.library.open_custom(req.library)
                                                   : s.library.open_system(req.library);
    if (!opened.ok()) return opened;
    if (auto owned = s.dispatch.acquire(); !owned.ok()) return owned;
    return VulkanDispatch::load_global(s.library.get_instance_proc_addr());
}

core::Result<void> create_instance(Session& s, bool with_surface) {
    std::vector<const char*> extensions;
    if (with_surface) {
#if defined(__ANDROID__)
        uint32_t n = 0;
        VkResult r = vkEnumerateInstanceExtensionProperties(nullptr, &n, nullptr);
        if (r != VK_SUCCESS) return vk_fail("vkEnumerateInstanceExtensionProperties", r);
        std::vector<VkExtensionProperties> props(n);
        r = vkEnumerateInstanceExtensionProperties(nullptr, &n, props.data());
        if (r != VK_SUCCESS && r != VK_INCOMPLETE) return vk_fail("vkEnumerateInstanceExtensionProperties", r);
        props.resize(n);
        for (const char* wanted : {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME}) {
            const bool found = std::any_of(props.begin(), props.end(), [wanted](const VkExtensionProperties& e) {
                return std::strcmp(e.extensionName, wanted) == 0;
            });
            if (!found) return core::Result<void>::Error(std::string("instance extension missing: ") + wanted);
            extensions.push_back(wanted);
        }
#else
        return core::Result<void>::Error("presentation surface requested on a non-Android build");
#endif
    }

    // Never request more than the driver supports: 1.0 drivers reject apiVersion 1.1.
    uint32_t api = VK_API_VERSION_1_0;
    if (vkEnumerateInstanceVersion) {
        uint32_t supported = 0;
        if (vkEnumerateInstanceVersion(&supported) == VK_SUCCESS) api = std::min(supported, kMaxApiVersion);
    }

    VkApplicationInfo app{};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.pApplicationName = "Lobo Gelido";
    app.applicationVersion = VK_MAKE_API_VERSION(0, 40, 0, 0);
    app.pEngineName = "Lobo Gelido Runtime";
    app.engineVersion = VK_MAKE_API_VERSION(0, 40, 0, 0);
    app.apiVersion = api;

    VkInstanceCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &app;
    ci.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    ci.ppEnabledExtensionNames = extensions.empty() ? nullptr : extensions.data();

    VkInstance instance = VK_NULL_HANDLE;
    const VkResult r = vkCreateInstance(&ci, nullptr, &instance);
    if (r != VK_SUCCESS || !instance) return vk_fail("vkCreateInstance", r);
    s.instance.adopt(instance);
    s.api_version = api;
    return VulkanDispatch::load_instance(instance, with_surface);
}

core::Result<void> create_surface(Session& s, void* android_surface) {
#if defined(__ANDROID__)
    VkAndroidSurfaceCreateInfoKHR si{};
    si.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR;
    si.window = static_cast<ANativeWindow*>(android_surface);
    VkSurfaceKHR surface = VK_NULL_HANDLE;
    const VkResult r = vkCreateAndroidSurfaceKHR(s.instance.get(), &si, nullptr, &surface);
    if (r != VK_SUCCESS || !surface) return vk_fail("vkCreateAndroidSurfaceKHR", r);
    s.surface.adopt(s.instance.get(), surface);
    return core::Result<void>::Ok();
#else
    (void)s;
    (void)android_surface;
    return core::Result<void>::Error("presentation surface requested on a non-Android build");
#endif
}

bool device_has_extension(VkPhysicalDevice pd, const char* name) {
    uint32_t n = 0;
    if (vkEnumerateDeviceExtensionProperties(pd, nullptr, &n, nullptr) != VK_SUCCESS) return false;
    std::vector<VkExtensionProperties> props(n);
    const VkResult r = vkEnumerateDeviceExtensionProperties(pd, nullptr, &n, props.data());
    if (r != VK_SUCCESS && r != VK_INCOMPLETE) return false;
    props.resize(n);
    return std::any_of(props.begin(), props.end(), [name](const VkExtensionProperties& e) {
        return std::strcmp(e.extensionName, name) == 0;
    });
}

core::Result<std::vector<VkPhysicalDevice>> enumerate_devices(VkInstance instance) {
    uint32_t count = 0;
    VkResult r = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (r != VK_SUCCESS)
        return core::Result<std::vector<VkPhysicalDevice>>::Error(std::string("vkEnumeratePhysicalDevices -> ") + result_name(r));
    std::vector<VkPhysicalDevice> devices(count);
    if (count) {
        r = vkEnumeratePhysicalDevices(instance, &count, devices.data());
        if (r != VK_SUCCESS && r != VK_INCOMPLETE)
            return core::Result<std::vector<VkPhysicalDevice>>::Error(std::string("vkEnumeratePhysicalDevices -> ") + result_name(r));
        devices.resize(count);
    }
    return core::Result<std::vector<VkPhysicalDevice>>::Ok(std::move(devices));
}

// Picks the first device (and queue family) that satisfies every requirement. With a
// surface, the family must also be able to present to it - checked here rather than
// after device creation, so a device whose first graphics family cannot present is
// not selected by mistake.
core::Result<void> select_physical_device(Session& s, bool with_surface, bool require_qualcomm,
                                          SoftwareVulkanKind prefer_software, bool require_software_device) {
    auto listed = enumerate_devices(s.instance.get());
    if (!listed.ok()) return core::Result<void>::Error(listed.error());
    const auto& devices = listed.value();
    if (devices.empty()) return core::Result<void>::Error("driver exposes no Vulkan physical device");

    struct Candidate {
        VkPhysicalDevice pd{};
        uint32_t queue_family{UINT32_MAX};
        uint32_t vendor_id{0};
        uint32_t device_id{0};
        uint32_t api_version{0};
        std::string name;
        int score{0};
    };
    std::vector<Candidate> ok;
    std::string rejected;

    for (VkPhysicalDevice pd : devices) {
        VkPhysicalDeviceProperties props{};
        vkGetPhysicalDeviceProperties(pd, &props);
        const std::string name = props.deviceName;
        if (require_qualcomm && props.vendorID != kVendorQualcomm) {
            append(rejected, name + " is " + format_vendor(props.vendorID));
            continue;
        }
        if (require_software_device && !looks_like_software_gpu(props.vendorID, name)) {
            append(rejected, name + " is not a software GPU");
            continue;
        }
        if (with_surface && !device_has_extension(pd, VK_KHR_SWAPCHAIN_EXTENSION_NAME)) {
            append(rejected, name + " lacks VK_KHR_swapchain");
            continue;
        }
        uint32_t qcount = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qcount, nullptr);
        std::vector<VkQueueFamilyProperties> families(qcount);
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qcount, families.data());
        bool found_queue = false;
        for (uint32_t i = 0; i < qcount; ++i) {
            const VkQueueFlags need = VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT;
            if ((families[i].queueFlags & need) != need || families[i].queueCount == 0) continue;
            if (with_surface) {
                VkBool32 present = VK_FALSE;
                if (vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, s.surface.get(), &present) != VK_SUCCESS || !present)
                    continue;
            }
            Candidate c;
            c.pd = pd;
            c.queue_family = i;
            c.vendor_id = props.vendorID;
            c.device_id = props.deviceID;
            c.api_version = props.apiVersion;
            c.name = name;
            c.score = score_software_device(prefer_software, props.vendorID, name);
            ok.push_back(c);
            found_queue = true;
            break;  // one queue family per device is enough
        }
        if (!found_queue)
            append(rejected, name + " has no graphics+compute" + std::string(with_surface ? "+present" : "") + " queue");
    }

    if (ok.empty())
        return core::Result<void>::Error("no suitable Vulkan device (" + rejected + ")");

    // Prefer highest software score when a software backend was requested.
    std::stable_sort(ok.begin(), ok.end(), [](const Candidate& a, const Candidate& b) {
        return a.score > b.score;
    });
    const Candidate& best = ok.front();
    s.physical_device = best.pd;
    s.queue_family = best.queue_family;
    s.vendor_id = best.vendor_id;
    s.device_id = best.device_id;
    s.gpu_name = best.name;
    s.api_version = std::min(s.api_version, best.api_version);
    return core::Result<void>::Ok();
}

core::Result<void> create_device(Session& s, bool with_surface) {
    const float priority = 1.0f;
    VkDeviceQueueCreateInfo qi{};
    qi.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    qi.queueFamilyIndex = s.queue_family;
    qi.queueCount = 1;
    qi.pQueuePriorities = &priority;

    std::vector<const char*> extensions;
    if (with_surface) extensions.push_back(VK_KHR_SWAPCHAIN_EXTENSION_NAME);
    VkPhysicalDeviceFeatures features{};

    VkDeviceCreateInfo di{};
    di.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    di.queueCreateInfoCount = 1;
    di.pQueueCreateInfos = &qi;
    di.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    di.ppEnabledExtensionNames = extensions.empty() ? nullptr : extensions.data();
    di.pEnabledFeatures = &features;

    VkDevice device = VK_NULL_HANDLE;
    const VkResult r = vkCreateDevice(s.physical_device, &di, nullptr, &device);
    if (r != VK_SUCCESS || !device) return vk_fail("vkCreateDevice", r);
    s.device.adopt(device);

    // Device-level entry points come from THIS driver's vkGetDeviceProcAddr.
    if (auto loaded = VulkanDispatch::load_device(device, with_surface); !loaded.ok()) return loaded;

    vkGetDeviceQueue(device, s.queue_family, 0, &s.queue);
    if (!s.queue) return core::Result<void>::Error("vkGetDeviceQueue returned a null queue");
    return core::Result<void>::Ok();
}

// Full, transactional bring-up. On error the caller destroys the Session, which undoes
// every completed step in reverse order.
core::Result<void> bring_up(Session& s, const BringUpRequest& req) {
    const bool with_surface = req.android_surface != nullptr;
    if (auto r = open_driver(s, req); !r.ok()) return r;
    if (auto r = create_instance(s, with_surface); !r.ok()) return r;
    if (with_surface) {
        if (auto r = create_surface(s, req.android_surface); !r.ok()) return r;
    }
    if (auto r = select_physical_device(s, with_surface, req.require_qualcomm,
                                       req.prefer_software, req.require_software_device); !r.ok()) return r;
    return create_device(s, with_surface);
}

// Asks the SYSTEM driver which GPU vendor this device has. Only conclusive results are
// cached (per library name); a probe blocked by another active session is retried later.
std::optional<uint32_t> probe_host_vendor(const std::string& system_library) {
    static std::mutex mutex;
    static std::map<std::string, std::optional<uint32_t>> cache;
    std::lock_guard lock(mutex);
    if (const auto it = cache.find(system_library); it != cache.end()) return it->second;

    std::optional<uint32_t> vendor;
    bool conclusive = false;
    {
        Session probe;
        if (probe.library.open_system(system_library).ok()) {
            conclusive = true;   // the system library itself answered (even if with "no GPU")
            if (probe.dispatch.acquire().ok()) {
                if (VulkanDispatch::load_global(probe.library.get_instance_proc_addr()).ok() &&
                    create_instance(probe, false).ok()) {
                    if (auto listed = enumerate_devices(probe.instance.get()); listed.ok()) {
                        for (VkPhysicalDevice pd : listed.value()) {
                            VkPhysicalDeviceProperties props{};
                            vkGetPhysicalDeviceProperties(pd, &props);
                            if (props.vendorID == kVendorQualcomm) { vendor = props.vendorID; break; }
                            if (!vendor) vendor = props.vendorID;
                        }
                    }
                }
            } else {
                conclusive = false;  // table busy: do not poison the cache
            }
        }
    }   // probe session fully torn down here
    if (conclusive) cache.emplace(system_library, vendor);
    return vendor;
}

bool path_exists(const std::string& path) {
    return !path.empty() && ::access(path.c_str(), F_OK) == 0;
}

std::string sanitize_field(std::string s) {
    std::replace(s.begin(), s.end(), ';', ',');
    std::replace(s.begin(), s.end(), '=', ':');
    return s;
}

} // namespace

AndroidVulkanContext::AndroidVulkanContext() : AndroidVulkanContext(Config{}) {}
AndroidVulkanContext::AndroidVulkanContext(Config config) : config_(std::move(config)) {}
AndroidVulkanContext::~AndroidVulkanContext() { shutdown(); }

core::Result<void> AndroidVulkanContext::initialize(void* android_surface, const std::string& custom_driver_path) {
    shutdown();

    // Host/debug: LOBO_FORCE_SOFTWARE=swiftshader|lavapipe resolves an ICD when path is empty.
    // Headless is supported when android_surface == nullptr (no swapchain / no Android surface).
    std::string path = custom_driver_path;
    if (path.empty()) {
        if (const char* force = std::getenv("LOBO_FORCE_SOFTWARE"); force && *force) {
            const auto kind = parse_software_kind(force);
            if (kind != SoftwareVulkanKind::None) {
                path = resolve_software_library(kind);
                if (path.empty()) {
                    return core::Result<void>::Error(
                        std::string("LOBO_FORCE_SOFTWARE=") + force +
                        " but no ICD library found (set LOBO_SOFTWARE_VULKAN_LIB or VK_ICD_FILENAMES)");
                }
            }
        }
    }

    std::string custom_failure;
    if (!path.empty()) {
        // Software ICDs (SwiftShader / Lavapipe) bypass the Adreno-only gate so
        // host tests and debug installs can force a CPU Vulkan device.
        const auto decision = evaluate_driver_path(path,
                                                   probe_host_vendor(config_.system_library),
                                                   path_exists(config_.adreno_kernel_node));
        if (!decision.allowed) {
            custom_failure = decision.reason;
        } else {
            auto attempt = std::make_unique<Session>();
            BringUpRequest req{VkDriverKind::Custom, path, android_surface, false};
            if (is_software_vulkan_path(path)) {
                const auto id = classify_software_driver(path);
                req.prefer_software = id.kind;
                req.require_software_device = true;  // refuse a discrete GPU if the ICD enumerates both
                req.require_qualcomm = false;
            } else {
                req.require_qualcomm = true;  // Adreno custom drivers stay gated
            }
            auto r = bring_up(*attempt, req);
            if (r.ok()) {
                // Soft validation: warn via fallback_reason if vendor does not match expectation.
                if (req.prefer_software != SoftwareVulkanKind::None &&
                    !looks_like_software_gpu(attempt->vendor_id, attempt->gpu_name)) {
                    fallback_reason_ = std::string("software path loaded but device looks discrete: ") +
                                       attempt->gpu_name;
                }
                session_ = std::move(attempt);
                return core::Result<void>::Ok();
            }
            custom_failure = "custom driver failed: " + r.error();
            if (is_software_vulkan_path(path)) {
                const auto id = classify_software_driver(path);
                custom_failure += std::string(" [software=") + id.label + "]";
            }
        }   // a failed attempt is destroyed HERE - surface released before the retry
    }

    auto attempt = std::make_unique<Session>();
    auto r = bring_up(*attempt, {VkDriverKind::System, config_.system_library, android_surface, false});
    if (!r.ok()) {
        if (custom_failure.empty()) return core::Result<void>::Error("system driver: " + r.error());
        return core::Result<void>::Error(custom_failure + " | system driver: " + r.error());
    }
    session_ = std::move(attempt);
    fallback_reason_ = std::move(custom_failure);   // empty when no custom driver was requested
    return core::Result<void>::Ok();
}

void AndroidVulkanContext::shutdown() noexcept {
    session_.reset();   // RAII: device -> surface -> instance -> dispatch -> dlclose
    fallback_reason_.clear();
}

void AndroidVulkanContext::note_fallback(std::string reason) {
    if (reason.empty()) return;
    if (fallback_reason_.empty()) fallback_reason_ = std::move(reason);
    else fallback_reason_ = std::move(reason) + " | " + fallback_reason_;
}

bool AndroidVulkanContext::ready() const noexcept { return session_ != nullptr; }
bool AndroidVulkanContext::surface_ready() const noexcept { return session_ && session_->surface.get(); }
bool AndroidVulkanContext::using_custom_driver() const noexcept {
    return session_ && session_->library.kind() == VkDriverKind::Custom;
}
const char* AndroidVulkanContext::driver_kind() const noexcept {
    return driver_kind_name(session_ ? session_->library.kind() : VkDriverKind::None);
}
const std::string& AndroidVulkanContext::driver_path() const noexcept { return session_ ? session_->library.path() : kEmpty; }
uint32_t AndroidVulkanContext::vendor_id() const noexcept { return session_ ? session_->vendor_id : 0; }
uint32_t AndroidVulkanContext::device_id() const noexcept { return session_ ? session_->device_id : 0; }
const std::string& AndroidVulkanContext::gpu_name() const noexcept { return session_ ? session_->gpu_name : kEmpty; }
const std::string& AndroidVulkanContext::fallback_reason() const noexcept { return fallback_reason_; }
uint32_t AndroidVulkanContext::api_version() const noexcept { return session_ ? session_->api_version : 0; }
uint32_t AndroidVulkanContext::graphics_queue_family() const noexcept { return session_ ? session_->queue_family : UINT32_MAX; }
void* AndroidVulkanContext::instance_handle() const noexcept { return session_ ? reinterpret_cast<void*>(session_->instance.get()) : nullptr; }
void* AndroidVulkanContext::physical_device_handle() const noexcept { return session_ ? reinterpret_cast<void*>(session_->physical_device) : nullptr; }
void* AndroidVulkanContext::device_handle() const noexcept { return session_ ? reinterpret_cast<void*>(session_->device.get()) : nullptr; }
void* AndroidVulkanContext::surface_handle() const noexcept { return session_ ? reinterpret_cast<void*>(session_->surface.get()) : nullptr; }
void* AndroidVulkanContext::graphics_queue_handle() const noexcept { return session_ ? reinterpret_cast<void*>(session_->queue) : nullptr; }

std::string AndroidVulkanContext::diagnostics() const {
    std::ostringstream s;
    s << "Vulkan=" << (ready() ? "READY" : "OFF")
      << ";surface=" << (surface_ready() ? "READY" : "OFF")
      << ";gpu=" << (gpu_name().empty() ? "none" : sanitize_field(gpu_name()))
      << ";vendor=" << (session_ ? format_vendor(session_->vendor_id) : std::string("none"))
      << ";driver=" << driver_kind()
      << ";driverPath=" << (driver_path().empty() ? "none" : sanitize_field(driver_path()));
    if (session_) {
        s << ";api=" << VK_API_VERSION_MAJOR(session_->api_version) << '.'
          << VK_API_VERSION_MINOR(session_->api_version) << '.'
          << VK_API_VERSION_PATCH(session_->api_version)
          << ";queue=" << session_->queue_family;
    } else {
        s << ";api=none;queue=none";
    }
    s << ";fallback=" << (fallback_reason_.empty() ? "none" : sanitize_field(fallback_reason_));
    if (!driver_path().empty() && is_software_vulkan_path(driver_path())) {
        const auto id = classify_software_driver(driver_path());
        s << ";software=" << id.label;
    } else {
        s << ";software=none";
    }
    return s.str();
}

} // namespace lg::gpu

#else  // !LG_HAS_VULKAN - host build without Vulkan headers

namespace lg::gpu {
namespace { const std::string kEmpty; }

struct AndroidVulkanContext::Session {};

AndroidVulkanContext::AndroidVulkanContext() : AndroidVulkanContext(Config{}) {}
AndroidVulkanContext::AndroidVulkanContext(Config config) : config_(std::move(config)) {}
AndroidVulkanContext::~AndroidVulkanContext() = default;
core::Result<void> AndroidVulkanContext::initialize(void*, const std::string&) {
    return core::Result<void>::Error("Android Vulkan backend unavailable on host");
}
void AndroidVulkanContext::shutdown() noexcept { session_.reset(); fallback_reason_.clear(); }
void AndroidVulkanContext::note_fallback(std::string reason) { fallback_reason_ = std::move(reason); }
bool AndroidVulkanContext::ready() const noexcept { return false; }
bool AndroidVulkanContext::surface_ready() const noexcept { return false; }
bool AndroidVulkanContext::using_custom_driver() const noexcept { return false; }
const char* AndroidVulkanContext::driver_kind() const noexcept { return "none"; }
const std::string& AndroidVulkanContext::driver_path() const noexcept { return kEmpty; }
uint32_t AndroidVulkanContext::vendor_id() const noexcept { return 0; }
uint32_t AndroidVulkanContext::device_id() const noexcept { return 0; }
const std::string& AndroidVulkanContext::gpu_name() const noexcept { return kEmpty; }
const std::string& AndroidVulkanContext::fallback_reason() const noexcept { return fallback_reason_; }
uint32_t AndroidVulkanContext::api_version() const noexcept { return 0; }
uint32_t AndroidVulkanContext::graphics_queue_family() const noexcept { return UINT32_MAX; }
void* AndroidVulkanContext::instance_handle() const noexcept { return nullptr; }
void* AndroidVulkanContext::physical_device_handle() const noexcept { return nullptr; }
void* AndroidVulkanContext::device_handle() const noexcept { return nullptr; }
void* AndroidVulkanContext::surface_handle() const noexcept { return nullptr; }
void* AndroidVulkanContext::graphics_queue_handle() const noexcept { return nullptr; }
std::string AndroidVulkanContext::diagnostics() const {
    return "Vulkan=OFF;surface=OFF;gpu=none;vendor=none;driver=none;driverPath=none;api=none;queue=none;fallback=none";
}
} // namespace lg::gpu

#endif // LG_HAS_VULKAN
