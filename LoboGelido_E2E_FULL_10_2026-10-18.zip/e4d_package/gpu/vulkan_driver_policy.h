#pragma once
#include <cstdint>
#include <optional>
#include <string>

// Pure decision logic for custom Vulkan drivers. No Vulkan headers, host-testable.
namespace lg::gpu {

// PCI / Khronos vendor IDs as reported in VkPhysicalDeviceProperties::vendorID.
inline constexpr uint32_t kVendorQualcomm    = 0x5143;  // Adreno (and Mesa Turnip)
inline constexpr uint32_t kVendorArm         = 0x13B5;  // Mali / Immortalis (MediaTek, Exynos, Tensor)
inline constexpr uint32_t kVendorImagination = 0x1010;  // PowerVR (some MediaTek / Unisoc)
inline constexpr uint32_t kVendorSamsung     = 0x144D;  // Xclipse
inline constexpr uint32_t kVendorAmd         = 0x1002;
inline constexpr uint32_t kVendorNvidia      = 0x10DE;
inline constexpr uint32_t kVendorGoogle     = 0x1AE0;  // SwiftShader
constexpr uint32_t kVendorMesa       = 0x10005; // Mesa / Lavapipe
constexpr uint32_t kVendorIntel       = 0x8086;

const char* gpu_vendor_name(uint32_t vendor_id) noexcept;
std::string format_vendor(uint32_t vendor_id);   // "0x13B5 (ARM Mali)"

struct CustomDriverDecision {
    bool allowed{false};
    std::string reason;
};

// Custom drivers in this project are Adreno-only (Turnip needs the KGSL kernel driver).
//  * host vendor known   -> allowed only for Qualcomm;
//  * host vendor unknown -> (system Vulkan missing/broken) allowed only if the Adreno
//                           kernel node (/dev/kgsl-3d0) exists, the one case where a
//                           custom driver can rescue a device with no working system driver.
CustomDriverDecision evaluate_custom_driver(std::optional<uint32_t> host_vendor,
                                            bool adreno_kernel_node_present);

/** Custom path allowed when it is a known software ICD (any host GPU). */
CustomDriverDecision evaluate_driver_path(const std::string& custom_path,
                                          std::optional<uint32_t> host_vendor,
                                          bool adreno_kernel_node_present);

} // namespace lg::gpu
