#pragma once
// Dynamic Vulkan dispatch for Lobo Gélido (volk-style, process-wide).
//
// Problem this solves
// -------------------
// A custom ICD (Mesa Turnip) returns raw ICD handles from its own vkCreateInstance.
// Passing those handles to the entry points exported by the system loader
// (libvulkan.so) is undefined behaviour: loader trampolines read their dispatch table
// from the first word of every dispatchable handle, and an ICD handle does not carry
// the loader's table. The old code resolved only vkCreateInstance and
// vkCreateAndroidSurfaceKHR through the custom driver and sent every other call
// (vkEnumeratePhysicalDevices, vkCreateDevice, queues, swapchain, command buffers...)
// to the system loader with that mixed instance.
//
// Design
// ------
// * Every Vulkan entry point used by the renderer is a function POINTER resolved at
//   runtime from the ACTIVE driver: vkGetInstanceProcAddr for global/instance level,
//   vkGetDeviceProcAddr for device level (which also bypasses loader trampolines on
//   the system path).
// * The pointers keep the Vulkan spellings and are visible inside namespace lg::gpu,
//   so existing call sites (`vkCreateDevice(...)`) compile unchanged.
// * They live in namespace lg::gpu::vkfn (mangled, hidden) - NOT at global scope - so
//   they can never be interposed by / collide with the functions exported by the
//   system libvulkan.so that the Android framework already has loaded (HWUI).
// * The app no longer links libvulkan statically; VK_NO_PROTOTYPES is mandatory.
//
// Invariants (enforced by DispatchScope)
// --------------------------------------
// * exactly one driver owns the table per process;
// * the table only changes while no Vulkan object created through it is alive;
// * reset() nulls every pointer, so a stale call faults immediately instead of
//   silently entering a different driver.

#if defined(__ANDROID__) || defined(LG_VULKAN_HOST_TESTS)
#  define LG_HAS_VULKAN 1
#else
#  define LG_HAS_VULKAN 0
#endif

#if LG_HAS_VULKAN

#ifndef VK_NO_PROTOTYPES
#  define VK_NO_PROTOTYPES
#endif
#if defined(__ANDROID__) && !defined(VK_USE_PLATFORM_ANDROID_KHR)
#  define VK_USE_PLATFORM_ANDROID_KHR
#endif
#include <vulkan/vulkan.h>

#include <cstdint>
#include <string>

#include "../core/result.h"

#if defined(__GNUC__) || defined(__clang__)
#  define LG_VK_HIDDEN __attribute__((visibility("hidden")))
#else
#  define LG_VK_HIDDEN
#endif

// ---- Entry-point tables (single source of truth; add new functions here) ----------

// Resolved with vkGetInstanceProcAddr(VK_NULL_HANDLE, ...).
#define LG_VK_GLOBAL_REQUIRED(X) \
    X(vkCreateInstance)          \
    X(vkEnumerateInstanceExtensionProperties)
#define LG_VK_GLOBAL_OPTIONAL(X) \
    X(vkEnumerateInstanceVersion)            /* absent on Vulkan 1.0 drivers */

// Resolved with vkGetInstanceProcAddr(instance, ...).
#define LG_VK_INSTANCE_REQUIRED(X)                  \
    X(vkDestroyInstance)                            \
    X(vkEnumeratePhysicalDevices)                   \
    X(vkGetPhysicalDeviceProperties)                \
    X(vkGetPhysicalDeviceQueueFamilyProperties)     \
    X(vkGetPhysicalDeviceMemoryProperties)          \
    X(vkEnumerateDeviceExtensionProperties)         \
    X(vkCreateDevice)                               \
    X(vkGetDeviceProcAddr)
// VK_KHR_surface (only required when the instance enables it).
#define LG_VK_INSTANCE_SURFACE(X)                   \
    X(vkDestroySurfaceKHR)                          \
    X(vkGetPhysicalDeviceSurfaceSupportKHR)         \
    X(vkGetPhysicalDeviceSurfaceCapabilitiesKHR)    \
    X(vkGetPhysicalDeviceSurfaceFormatsKHR)         \
    X(vkGetPhysicalDeviceSurfacePresentModesKHR)
#if defined(VK_USE_PLATFORM_ANDROID_KHR)
#  define LG_VK_INSTANCE_ANDROID_SURFACE(X) X(vkCreateAndroidSurfaceKHR)
#else
#  define LG_VK_INSTANCE_ANDROID_SURFACE(X)
#endif

// Resolved with vkGetDeviceProcAddr(device, ...).
#define LG_VK_DEVICE_REQUIRED(X)          \
    X(vkDestroyDevice)                    \
    X(vkDeviceWaitIdle)                   \
    X(vkGetDeviceQueue)                   \
    X(vkQueueSubmit)                      \
    X(vkAllocateMemory)                   \
    X(vkFreeMemory)                       \
    X(vkMapMemory)                        \
    X(vkUnmapMemory)                      \
    X(vkBindBufferMemory)                 \
    X(vkBindImageMemory)                  \
    X(vkGetBufferMemoryRequirements)      \
    X(vkGetImageMemoryRequirements)       \
    X(vkCreateBuffer)                     \
    X(vkDestroyBuffer)                    \
    X(vkCreateImage)                      \
    X(vkDestroyImage)                     \
    X(vkCreateImageView)                  \
    X(vkDestroyImageView)                 \
    X(vkCreateFence)                      \
    X(vkDestroyFence)                     \
    X(vkResetFences)                      \
    X(vkWaitForFences)                    \
    X(vkCreateSemaphore)                  \
    X(vkDestroySemaphore)                 \
    X(vkCreateQueryPool)                  \
    X(vkDestroyQueryPool)                 \
    X(vkGetQueryPoolResults)              \
    X(vkCreateShaderModule)               \
    X(vkDestroyShaderModule)              \
    X(vkCreatePipelineCache)              \
    X(vkDestroyPipelineCache)             \
    X(vkCreateGraphicsPipelines)          \
    X(vkDestroyPipeline)                  \
    X(vkCreatePipelineLayout)             \
    X(vkDestroyPipelineLayout)            \
    X(vkCreateDescriptorSetLayout)        \
    X(vkDestroyDescriptorSetLayout)       \
    X(vkCreateDescriptorPool)             \
    X(vkDestroyDescriptorPool)            \
    X(vkAllocateDescriptorSets)           \
    X(vkFreeDescriptorSets)               \
    X(vkUpdateDescriptorSets)             \
    X(vkCreateFramebuffer)                \
    X(vkDestroyFramebuffer)               \
    X(vkCreateRenderPass)                 \
    X(vkDestroyRenderPass)                \
    X(vkCreateCommandPool)                \
    X(vkDestroyCommandPool)               \
    X(vkAllocateCommandBuffers)           \
    X(vkBeginCommandBuffer)               \
    X(vkEndCommandBuffer)                 \
    X(vkResetCommandBuffer)               \
    X(vkCmdBindPipeline)                  \
    X(vkCmdSetViewport)                   \
    X(vkCmdSetScissor)                    \
    X(vkCmdBindDescriptorSets)            \
    X(vkCmdBindVertexBuffers)             \
    X(vkCmdDraw)                          \
    X(vkCmdClearAttachments)              \
    X(vkCmdPipelineBarrier)               \
    X(vkCmdResetQueryPool)                \
    X(vkCmdWriteTimestamp)                \
    X(vkCmdBeginRenderPass)               \
    X(vkCmdEndRenderPass)
// VK_KHR_swapchain (only required when the device enables it).
#define LG_VK_DEVICE_SWAPCHAIN(X)         \
    X(vkCreateSwapchainKHR)               \
    X(vkDestroySwapchainKHR)              \
    X(vkGetSwapchainImagesKHR)            \
    X(vkAcquireNextImageKHR)              \
    X(vkQueuePresentKHR)

namespace lg::gpu::vkfn {
#define LG_VK_DECLARE(name) extern LG_VK_HIDDEN PFN_##name name;
LG_VK_DECLARE(vkGetInstanceProcAddr)
LG_VK_GLOBAL_REQUIRED(LG_VK_DECLARE)
LG_VK_GLOBAL_OPTIONAL(LG_VK_DECLARE)
LG_VK_INSTANCE_REQUIRED(LG_VK_DECLARE)
LG_VK_INSTANCE_SURFACE(LG_VK_DECLARE)
LG_VK_INSTANCE_ANDROID_SURFACE(LG_VK_DECLARE)
LG_VK_DEVICE_REQUIRED(LG_VK_DECLARE)
LG_VK_DEVICE_SWAPCHAIN(LG_VK_DECLARE)
#undef LG_VK_DECLARE
} // namespace lg::gpu::vkfn

namespace lg::gpu {

// Existing renderer code calls vkXxx(...) unqualified from inside lg::gpu.
using namespace vkfn;

enum class VkDriverKind : uint8_t { None, System, Custom };
const char* driver_kind_name(VkDriverKind kind) noexcept;

// Loads the process-wide table. Every loader sets whatever it can resolve and returns
// an error naming the REQUIRED entry points that are missing, so callers can abort the
// session while destroy functions that did resolve remain usable for cleanup.
class VulkanDispatch {
public:
    static core::Result<void> load_global(PFN_vkGetInstanceProcAddr get_instance_proc_addr);
    static core::Result<void> load_instance(VkInstance instance, bool with_surface);
    static core::Result<void> load_device(VkDevice device, bool with_swapchain);
    static void reset() noexcept;
};

// Exclusive, move-only ownership of the process-wide table for one driver session.
// Destroying (or releasing) the scope resets every pointer.
class DispatchScope {
public:
    DispatchScope() = default;
    ~DispatchScope() { release(); }
    DispatchScope(const DispatchScope&) = delete;
    DispatchScope& operator=(const DispatchScope&) = delete;
    DispatchScope(DispatchScope&& other) noexcept : active_(other.active_) { other.active_ = false; }
    DispatchScope& operator=(DispatchScope&& other) noexcept;

    core::Result<void> acquire();   // fails if another scope currently owns the table
    void release() noexcept;
    bool active() const noexcept { return active_; }

private:
    bool active_{false};
};

} // namespace lg::gpu

#endif // LG_HAS_VULKAN
