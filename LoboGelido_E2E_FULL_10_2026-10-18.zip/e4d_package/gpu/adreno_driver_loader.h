#pragma once

#include <string>

namespace lg::gpu {

class AdrenoDriverLoader final {
public:
    AdrenoDriverLoader() = default;
    ~AdrenoDriverLoader();

    AdrenoDriverLoader(const AdrenoDriverLoader&) = delete;
    AdrenoDriverLoader& operator=(const AdrenoDriverLoader&) = delete;

    bool open(const std::string& driver_path);
    void close() noexcept;
    bool loaded() const noexcept { return library_ != nullptr; }
    bool custom() const noexcept { return custom_; }
    const std::string& resolved_path() const noexcept { return resolved_path_; }
    const std::string& error() const noexcept { return error_; }

    void* instance_proc_addr(void* instance, const char* name) const noexcept;

private:
    void* library_{nullptr};
    void* instance_proc_addr_{nullptr};
    bool custom_{false};
    std::string resolved_path_;
    std::string error_;
};

} // namespace lg::gpu
