// Fusion (2026-10-16): main-line core (exception-safe workers, in-flight accounting, idle CV,
// serialize format checked by test_async_pipeline_cache) + CLEAN-branch additions
// (priority queueing, per-title disk persistence, diagnostics, worker cap).
#include "async_pipeline_cache.h"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <sstream>
#include <utility>

namespace lg::gpu {
namespace fs = std::filesystem;

AsyncPipelineCache::AsyncPipelineCache(CompileFn compiler, unsigned workers, WorkerInit on_worker_start)
    : compiler_(std::move(compiler)), on_worker_start_(std::move(on_worker_start)) {
    workers = std::max(1u, std::min(workers, 8u));
    workers_.reserve(workers);
    for (unsigned i = 0; i < workers; ++i)
        workers_.emplace_back([this] { worker_loop(); });
}

AsyncPipelineCache::~AsyncPipelineCache() {
    {
        std::lock_guard lock(mutex_);
        stop_ = true;
    }
    queue_cv_.notify_all();
    for (auto& t : workers_) if (t.joinable()) t.join();
}

void AsyncPipelineCache::queue_locked(uint64_t key, Entry& entry, bool priority) {
    entry.status = PipelineStatus::Compiling;
    entry.handle = 0;
    if (priority) queue_.push_front(key);
    else queue_.push_back(key);
    queue_cv_.notify_one();
}

PipelineStatus AsyncPipelineCache::get(uint64_t key, PipelineHandle& out_handle) {
    std::lock_guard lock(mutex_);
    auto [it, inserted] = entries_.try_emplace(key);
    Entry& entry = it->second;
    if (!inserted) {
        if (entry.status == PipelineStatus::Ready) {
            out_handle = entry.handle;
            hits_.fetch_add(1, std::memory_order_relaxed);
            return PipelineStatus::Ready;
        }
        if (entry.status == PipelineStatus::Compiling) return PipelineStatus::Compiling;
        if (entry.status == PipelineStatus::Failed) return PipelineStatus::Failed;
    }
    queue_locked(key, entry, false);
    return PipelineStatus::Compiling;
}

PipelineStatus AsyncPipelineCache::get_priority(uint64_t key, PipelineHandle& out_handle) {
    std::lock_guard lock(mutex_);
    auto [it, inserted] = entries_.try_emplace(key);
    Entry& entry = it->second;
    if (!inserted) {
        if (entry.status == PipelineStatus::Ready) {
            out_handle = entry.handle;
            hits_.fetch_add(1, std::memory_order_relaxed);
            return PipelineStatus::Ready;
        }
        if (entry.status == PipelineStatus::Compiling) {
            // Already queued: move it to the front if a worker has not taken it yet.
            auto q = std::find(queue_.begin(), queue_.end(), key);
            if (q != queue_.end() && q != queue_.begin()) { queue_.erase(q); queue_.push_front(key); }
            return PipelineStatus::Compiling;
        }
        if (entry.status == PipelineStatus::Failed) return PipelineStatus::Failed;
    }
    queue_locked(key, entry, true);
    return PipelineStatus::Compiling;
}

void AsyncPipelineCache::worker_loop() {
    if (on_worker_start_) on_worker_start_();
    for (;;) {
        uint64_t key = 0;
        {
            std::unique_lock lock(mutex_);
            queue_cv_.wait(lock, [&] { return stop_ || !queue_.empty(); });
            if (stop_ && queue_.empty()) return;
            key = queue_.front();
            queue_.pop_front();
            ++in_flight_;
        }

        PipelineHandle handle = 0;
        bool ok = false;
        try { if (compiler_) ok = compiler_(key, handle); } catch (...) { ok = false; }

        {
            std::lock_guard lock(mutex_);
            auto it = entries_.find(key);
            if (it != entries_.end()) {
                it->second.status = ok ? PipelineStatus::Ready : PipelineStatus::Failed;
                it->second.handle = ok ? handle : 0;
            }
            if (ok) compiled_.fetch_add(1, std::memory_order_relaxed);
            else failures_.fetch_add(1, std::memory_order_relaxed);
            --in_flight_;
            if (queue_.empty() && in_flight_ == 0) idle_cv_.notify_all();
        }
    }
}

void AsyncPipelineCache::wait_idle() {
    std::unique_lock lock(mutex_);
    idle_cv_.wait(lock, [&] { return queue_.empty() && in_flight_ == 0; });
}

void AsyncPipelineCache::invalidate_runtime_handles() {
    std::lock_guard lock(mutex_);
    for (auto& [_, entry] : entries_) {
        entry.status = PipelineStatus::Missing;
        entry.handle = 0;
    }
}

static void put_u64(std::vector<uint8_t>& p, uint64_t v) {
    for (int i = 0; i < 8; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
static uint64_t rd_u64(const std::vector<uint8_t>& p, size_t o) {
    uint64_t v = 0;
    for (int i = 0; i < 8; ++i) v |= static_cast<uint64_t>(p[o + i]) << (8 * i);
    return v;
}
static uint32_t rd_u32(const std::vector<uint8_t>& p, size_t o) {
    uint32_t v = 0;
    for (int i = 0; i < 4; ++i) v |= static_cast<uint32_t>(p[o + i]) << (8 * i);
    return v;
}

std::vector<uint8_t> AsyncPipelineCache::serialize() const {
    std::lock_guard lock(mutex_);
    std::vector<uint64_t> keys;
    keys.reserve(entries_.size());
    for (const auto& [key, entry] : entries_)
        if (entry.status == PipelineStatus::Ready || entry.status == PipelineStatus::Compiling)
            keys.push_back(key);
    std::vector<uint8_t> blob;
    const uint32_t count = static_cast<uint32_t>(keys.size());
    blob.reserve(4 + keys.size() * 8);
    for (int i = 0; i < 4; ++i) blob.push_back(static_cast<uint8_t>((count >> (8 * i)) & 0xFF));
    for (const auto key : keys) put_u64(blob, key);
    return blob;
}

size_t AsyncPipelineCache::load(const std::vector<uint8_t>& blob) {
    if (blob.size() < 4) return 0;
    constexpr uint32_t kLpk1 = 0x4C504B31u;   // CLEAN-branch files: "LPK1", u32 count, u64 keys
    size_t base = 4;
    uint32_t count = rd_u32(blob, 0);
    if (count == kLpk1 && blob.size() >= 8) {  // a main-line count this large cannot fit in the blob
        count = rd_u32(blob, 4);
        base = 8;
    }
    if (count > (blob.size() - base) / 8) count = static_cast<uint32_t>((blob.size() - base) / 8);
    size_t loaded = 0;
    std::lock_guard lock(mutex_);
    for (uint32_t i = 0; i < count; ++i) {
        const uint64_t key = rd_u64(blob, base + static_cast<size_t>(i) * 8);
        auto [it, inserted] = entries_.try_emplace(key, Entry{});
        if (inserted) ++loaded;
        if (it->second.status != PipelineStatus::Ready && it->second.status != PipelineStatus::Compiling)
            it->second.status = PipelineStatus::Missing;
    }
    return loaded;
}

bool AsyncPipelineCache::save_to_disk(const std::string& root, const std::string& title_id) const {
    if (root.empty() || title_id.empty()) return false;
    std::error_code ec;
    fs::create_directories(root, ec);
    const auto path = fs::path(root) / (title_id + ".pkeys");
    const auto tmp = fs::path(path.string() + ".tmp");
    const auto blob = serialize();
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return false;
        out.write(reinterpret_cast<const char*>(blob.data()), static_cast<std::streamsize>(blob.size()));
        if (!out) { out.close(); fs::remove(tmp, ec); return false; }
    }
    fs::rename(tmp, path, ec);   // never leaves a half-written key file behind
    if (ec) { fs::remove(tmp, ec); return false; }
    return true;
}

size_t AsyncPipelineCache::load_from_disk(const std::string& root, const std::string& title_id) {
    if (root.empty() || title_id.empty()) return 0;
    const auto path = fs::path(root) / (title_id + ".pkeys");
    std::ifstream in(path, std::ios::binary);
    if (!in) return 0;
    std::vector<uint8_t> blob((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    return load(blob);
}

bool AsyncPipelineCache::has_known_key(uint64_t key) const {
    std::lock_guard lock(mutex_);
    return entries_.find(key) != entries_.end();
}

size_t AsyncPipelineCache::ready_count() const { std::lock_guard lock(mutex_); size_t n=0; for(const auto&[_,e]:entries_) if(e.status==PipelineStatus::Ready) ++n; return n; }
size_t AsyncPipelineCache::pending_count() const { std::lock_guard lock(mutex_); return queue_.size()+static_cast<size_t>(in_flight_); }

std::string AsyncPipelineCache::diagnostics() const {
    size_t ready = 0, known = 0, pending = 0;
    {
        std::lock_guard lock(mutex_);
        known = entries_.size();
        for (const auto& [_, e] : entries_) if (e.status == PipelineStatus::Ready) ++ready;
        pending = queue_.size() + static_cast<size_t>(in_flight_);
    }
    const uint64_t h = cache_hits(), c = compiled(), f = failures();
    const uint64_t denom = h + c + f;
    std::ostringstream s;
    s << "pipeCache=async;ready=" << ready << ";pending=" << pending << ";compiled=" << c
      << ";hits=" << h << ";fail=" << f << ";known=" << known << ";hit_rate=";
    if (denom == 0) s << "n/a";
    else s << (100.0 * double(h) / double(denom)) << "%";
    return s.str();
}

} // namespace lg::gpu
