#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "../core/result.h"

namespace lg::gpu {

struct SpirvModule {
    std::vector<uint32_t> words;
    uint32_t bound{0};
    bool valid() const noexcept { return words.size() >= 5 && words[0] == 0x07230203u && bound != 0; }
};

/** Structural validation (header, instruction lengths, required logical layout markers). */
core::Result<SpirvModule> validate_spirv(const std::vector<uint32_t>& words);

/**
 * Optional external spirv-val (Khronos). Looks at:
 *   LOBOGELIDO_SPIRV_VAL, SPIRV_VAL, or "spirv-val" on PATH.
 * Returns Ok if tool missing (skip) unless require_tool=true.
 * Writes words to a temp file for the tool.
 */
core::Result<void> validate_spirv_external(const std::vector<uint32_t>& words,
                                           bool require_tool = false);

/** One-shot: structural + external when available. */
core::Result<SpirvModule> validate_spirv_full(const std::vector<uint32_t>& words,
                                              bool require_external = false);

} // namespace lg::gpu
