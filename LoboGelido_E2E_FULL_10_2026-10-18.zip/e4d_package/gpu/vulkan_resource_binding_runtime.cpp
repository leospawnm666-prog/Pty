#include "vulkan_resource_binding_runtime.h"
#include <sstream>
#include <filesystem>
#include <fstream>
#include <functional>

namespace lg::gpu {
namespace {
uint64_t async_key(uint32_t pipeline_id, uint32_t program_id) {
    uint64_t x = (static_cast<uint64_t>(pipeline_id) << 32) | program_id;
    x ^= 0x9e3779b97f4a7c15ull;
    x *= 0xbf58476d1ce4e5b9ull;
    x ^= x >> 29;
    return x;
}
}
core::Result<void> VulkanResourceBindingRuntime::initialize(ShaderProgramManager* programs,
                                                             VulkanDescriptorBackend* descriptors,
                                                             VulkanResourceBackend* resources,
                                                             VulkanPipeline* pipelines) {
    reset();
    if (!programs || !descriptors || !resources || !pipelines)
        return core::Result<void>::Error("invalid GPU resource binding runtime dependencies");
    if (!descriptors->ready() || !resources->ready() || !pipelines->ready())
        return core::Result<void>::Error("GPU resource binding runtime dependencies are not ready");
    std::lock_guard lock(mutex_);
    programs_ = programs; descriptors_ = descriptors; resources_ = resources; pipelines_ = pipelines;
    return core::Result<void>::Ok();
}

core::Result<void> VulkanResourceBindingRuntime::prepare_program(uint32_t program_id,
                                                                  uint32_t first_layout_id,
                                                                  uint32_t first_set_id) {
    if (!programs_ || !descriptors_ || !resources_ || !pipelines_)
        return core::Result<void>::Error("GPU resource binding runtime not initialized");
    if (!programs_->program(program_id)) return core::Result<void>::Error("unknown shader program");
    auto grouped = programs_->descriptor_bindings_by_set(program_id);
    if (!grouped.ok()) return core::Result<void>::Error(grouped.error());
    auto layouts = descriptors_->create_layouts_for_program(*programs_, program_id, first_layout_id);
    if (!layouts.ok()) return core::Result<void>::Error(layouts.error());
    for (size_t i = 0; i < layouts.value().size(); ++i) {
        const uint32_t sid = first_set_id + static_cast<uint32_t>(i);
        if (descriptors_->set_layout_id(sid) == 0) {
            auto ar = descriptors_->allocate_set(sid, layouts.value()[i]);
            if (!ar.ok()) return core::Result<void>::Error(ar.error());
        } else if (descriptors_->set_layout_id(sid) != layouts.value()[i]) {
            return core::Result<void>::Error("descriptor set id is already associated with another layout");
        }
    }
    programs_map_[program_id] = ProgramBinding{first_layout_id, first_set_id, static_cast<uint32_t>(layouts.value().size())};
    return core::Result<void>::Ok();
}

core::Result<void> VulkanResourceBindingRuntime::prepare_pipeline(uint32_t pipeline_id, void* render_pass, uint32_t program_id) {
    if (!programs_ || !descriptors_ || !resources_ || !pipelines_)
        return core::Result<void>::Error("GPU resource binding runtime not initialized");
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) {
        auto r = prepare_program(program_id);
        if (!r.ok()) return r;
        it = programs_map_.find(program_id);
    }
    if (pipelines_->has_pipeline_variant_for_program(pipeline_id, program_id)) return core::Result<void>::Ok();

    // Descriptor layouts are created synchronously because they are small state objects;
    // the expensive vkCreateGraphicsPipelines call is dispatched to the dedicated pool.
    std::vector<void*> handles;
    handles.reserve(it->second.set_count);
    for (uint32_t i = 0; i < it->second.set_count; ++i) {
        void* handle = descriptors_->layout_handle(it->second.first_layout_id + i);
        if (!handle) return core::Result<void>::Error("generated descriptor layout handle is unavailable");
        handles.push_back(handle);
    }

    const uint64_t key = async_key(pipeline_id, program_id);
    if (!async_cache_) {
        // If the cache has not been configured by the presenter yet, retain the exact
        // synchronous behavior. Production Android configures it during initialization.
        return pipelines_->create_graphics_pipeline_variant_from_program(
            pipeline_id, render_pass, *programs_, program_id, handles);
    }

    {
        std::lock_guard lock(mutex_);
        async_requests_[key] = AsyncRequest{pipeline_id, program_id, render_pass, std::move(handles)};
    }
    PipelineHandle ignored = 0;
    // First sighting of a pipeline key jumps the queue (reduces first-frame stalls).
    const auto status = async_cache_->get_priority(key, ignored);
    if (status == PipelineStatus::Failed)
        return core::Result<void>::Error("asynchronous graphics pipeline compilation failed");
    // Compiling is deliberately non-blocking. The command executor will defer draws for
    // this variant until the worker has produced a live Vulkan pipeline.
    return core::Result<void>::Error("asynchronous graphics pipeline compilation queued");
}

bool VulkanResourceBindingRuntime::pipeline_compilation_pending(uint32_t pipeline_id, uint32_t program_id) const noexcept {
    if (pipelines_ && pipelines_->has_pipeline_variant_for_program(pipeline_id, program_id)) return false;
    const uint64_t key = async_key(pipeline_id, program_id);
    if (!async_cache_) return false;
    return async_cache_->pending_count() != 0 && async_cache_->has_known_key(key);
}

bool VulkanResourceBindingRuntime::configure_async_cache(const std::string& directory, const std::string& game_id) {
    if (!pipelines_ || !programs_ || !descriptors_) return false;
    try {
        namespace fs = std::filesystem;
        fs::create_directories(directory);
        async_game_id_ = game_id.empty() ? "unknown" : game_id;
        async_cache_path_ = (fs::path(directory) / (async_game_id_ + ".pipeline.keys")).string();
        // 3 workers: enough for mobile without starving the render thread.
        async_cache_ = std::make_unique<AsyncPipelineCache>(
            [this](uint64_t key, PipelineHandle& out) -> bool {
                AsyncRequest req;
                {
                    std::lock_guard lock(mutex_);
                    auto it = async_requests_.find(key);
                    if (it == async_requests_.end()) return false;
                    req = it->second;
                }
                const auto r = pipelines_->create_graphics_pipeline_variant_from_program(
                    req.pipeline_id, req.render_pass, *programs_, req.program_id, req.descriptor_layouts);
                if (!r.ok()) return false;
                out = static_cast<PipelineHandle>(req.pipeline_id);
                return true;
            }, 3);
        // Load main-line blob and optional CLEAN .pkeys sidecar.
        std::ifstream in(async_cache_path_, std::ios::binary);
        if (in) {
            std::vector<uint8_t> blob((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
            async_cache_->load(blob);
        }
        (void)async_cache_->load_from_disk(directory, async_game_id_);
        return true;
    } catch (...) {
        async_cache_.reset();
        async_cache_path_.clear();
        return false;
    }
}

void VulkanResourceBindingRuntime::invalidate_pipeline_handles() noexcept {
    if (async_cache_) async_cache_->invalidate_runtime_handles();
}

void VulkanResourceBindingRuntime::wait_async_idle() noexcept {
    if (!async_cache_) return;
    async_cache_->wait_idle();
    try {
        if (!async_cache_path_.empty()) {
            const auto blob = async_cache_->serialize();
            const auto tmp = async_cache_path_ + ".tmp";
            std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
            if (out) {
                out.write(reinterpret_cast<const char*>(blob.data()), static_cast<std::streamsize>(blob.size()));
                out.flush();
                out.close();
                std::error_code ec;
                std::filesystem::rename(tmp, async_cache_path_, ec);
                if (ec) std::filesystem::remove(tmp, ec);
            }
        }
    } catch (...) {}
}
core::Result<void> VulkanResourceBindingRuntime::bind_buffer(uint32_t program_id, uint32_t set, uint32_t binding,
                                                             uint32_t resource_id, uint64_t offset, uint64_t range) {
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) { auto r = prepare_program(program_id); if (!r.ok()) return r; it = programs_map_.find(program_id); }
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    return descriptors_->bind_buffer(it->second.first_set_id + set, binding, resource_id, offset, range);
}

core::Result<void> VulkanResourceBindingRuntime::bind_sampled_image(uint32_t program_id, uint32_t set, uint32_t binding,
                                                                    uint32_t resource_id) {
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) { auto r = prepare_program(program_id); if (!r.ok()) return r; it = programs_map_.find(program_id); }
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    return descriptors_->bind_sampled_image(it->second.first_set_id + set, binding, resource_id);
}

core::Result<void> VulkanResourceBindingRuntime::update(uint32_t program_id, uint32_t set) {
    auto it = programs_map_.find(program_id); if (it == programs_map_.end()) return core::Result<void>::Error("shader program has not been prepared");
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    const uint32_t sid = it->second.first_set_id + set;
    auto v = descriptors_->validate_set_against_program(sid, *programs_, program_id, set); if (!v.ok()) return v;
    return descriptors_->update(sid);
}

core::Result<void> VulkanResourceBindingRuntime::validate(uint32_t program_id, uint32_t set) const {
    auto it = programs_map_.find(program_id); if (it == programs_map_.end()) return core::Result<void>::Error("shader program has not been prepared");
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    return descriptors_->validate_set_against_program(it->second.first_set_id + set, *programs_, program_id, set);
}

core::Result<void> VulkanResourceBindingRuntime::bind(void* command_buffer, uint32_t pipeline_id, uint32_t program_id, uint32_t set) {
    if (!command_buffer) return core::Result<void>::Error("command buffer is null");
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) { auto r = prepare_program(program_id); if (!r.ok()) return r; it = programs_map_.find(program_id); }
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    if (!pipelines_->has_pipeline_variant_for_program(pipeline_id, program_id)) return core::Result<void>::Error("pipeline variant for shader program is not ready");
    const uint32_t sid = it->second.first_set_id + set;
    auto v = descriptors_->validate_set_against_program(sid, *programs_, program_id, set); if (!v.ok()) return v;
    auto u = descriptors_->update(sid); if (!u.ok()) return u;
    void* layout = pipelines_->pipeline_layout_handle(pipeline_id); if (!layout) return core::Result<void>::Error("pipeline layout for resource binding is unavailable");
    descriptors_->bind_set(command_buffer, layout, sid, set);
    return core::Result<void>::Ok();
}

uint32_t VulkanResourceBindingRuntime::descriptor_set_id(uint32_t program_id, uint32_t set) const noexcept {
    std::lock_guard lock(mutex_);
    auto it=programs_map_.find(program_id); if(it==programs_map_.end()||set>=it->second.set_count)return 0; return it->second.first_set_id+set;
}
uint32_t VulkanResourceBindingRuntime::descriptor_layout_id(uint32_t program_id, uint32_t set) const noexcept {
    std::lock_guard lock(mutex_);
    auto it=programs_map_.find(program_id); if(it==programs_map_.end()||set>=it->second.set_count)return 0; return it->second.first_layout_id+set;
}
size_t VulkanResourceBindingRuntime::prepared_program_count() const noexcept { std::lock_guard lock(mutex_); return programs_map_.size(); }
size_t VulkanResourceBindingRuntime::prepared_set_count() const noexcept { std::lock_guard lock(mutex_); size_t n=0; for(const auto& [_,p]:programs_map_) n+=p.set_count; return n; }
void VulkanResourceBindingRuntime::reset() noexcept {
    wait_async_idle();
    async_cache_.reset();
    std::lock_guard lock(mutex_);
    async_requests_.clear(); async_cache_path_.clear(); async_game_id_.clear();
    programs_map_.clear(); programs_=nullptr; descriptors_=nullptr; resources_=nullptr; pipelines_=nullptr;
}
std::string VulkanResourceBindingRuntime::diagnostics() const {
    std::ostringstream s; s<<"vkBindingRuntime="<<(programs_?"READY":"OFF")<<";programs="<<prepared_program_count()<<";sets="<<prepared_set_count();
    if(async_cache_) s<<";"<<async_cache_->diagnostics();
    return s.str();
}
}
