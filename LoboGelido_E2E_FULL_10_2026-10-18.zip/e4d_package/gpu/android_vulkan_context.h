#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include "../core/result.h"

namespace lg::gpu {

// Owns the Vulkan driver session: library -> dispatch table -> instance -> surface ->
// device -> queue. Header stays Vulkan-free (opaque handles) so host builds without
// Vulkan headers can still include it.
//
// Driver selection (initialize):
//   1. If a custom driver path is given, the HOST GPU vendor is probed once through the
//      system driver and the custom driver is only attempted on Qualcomm Adreno hosts
//      (see vulkan_driver_policy.h). The custom session must also expose a Qualcomm
//      physical device.
//   2. Any failure of the custom attempt tears it down COMPLETELY (surface included, so
//      the ANativeWindow is free again) and the system driver is used instead; the
//      reason is kept in fallback_reason().
//   3. If the system driver fails too, initialize() reports both errors.
class AndroidVulkanContext {
public:
    struct Config {
        std::string system_library{"libvulkan.so"};   // dlopen'ed platform loader
        std::string adreno_kernel_node{"/dev/kgsl-3d0"};
    };

    AndroidVulkanContext();
    explicit AndroidVulkanContext(Config config);
    ~AndroidVulkanContext();
    AndroidVulkanContext(const AndroidVulkanContext&) = delete;
    AndroidVulkanContext& operator=(const AndroidVulkanContext&) = delete;

    core::Result<void> initialize(void* android_surface, const std::string& custom_driver_path = {});
    void shutdown() noexcept;
    bool ready() const noexcept;
    bool surface_ready() const noexcept;
    std::string diagnostics() const;

    // Driver provenance.
    bool using_custom_driver() const noexcept;
    const char* driver_kind() const noexcept;          // "custom" | "system" | "none"
    const std::string& driver_path() const noexcept;
    uint32_t vendor_id() const noexcept;
    uint32_t device_id() const noexcept;
    const std::string& gpu_name() const noexcept;
    const std::string& fallback_reason() const noexcept;  // empty when no fallback happened
    // Records a fallback decided by a higher layer (e.g. presenter failed on the custom
    // driver and the host re-initialized on the system driver).
    void note_fallback(std::string reason);

    uint32_t api_version() const noexcept;
    uint32_t graphics_queue_family() const noexcept;
    void* instance_handle() const noexcept;
    void* physical_device_handle() const noexcept;
    void* device_handle() const noexcept;
    void* surface_handle() const noexcept;
    void* graphics_queue_handle() const noexcept;

    struct Session;   // defined in the .cpp (RAII-ordered Vulkan objects)

private:
    Config config_;
    std::unique_ptr<Session> session_;
    std::string fallback_reason_;
};

} // namespace lg::gpu
