#include "spirv_module.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>

namespace lg::gpu {
namespace {

constexpr uint32_t kMagic = 0x07230203u;
constexpr uint16_t OpCapability = 17;
constexpr uint16_t OpMemoryModel = 14;
constexpr uint16_t OpEntryPoint = 15;
constexpr uint16_t OpFunction = 54;
constexpr uint16_t OpFunctionEnd = 56;

const char* find_spirv_val() {
    if (const char* e = std::getenv("LOBOGELIDO_SPIRV_VAL")) if (e[0]) return e;
    if (const char* e = std::getenv("SPIRV_VAL")) if (e[0]) return e;
    return "spirv-val";
}

} // namespace

core::Result<SpirvModule> validate_spirv(const std::vector<uint32_t>& words) {
    if (words.size() < 5)
        return core::Result<SpirvModule>::Error("SPIR-V module too small");
    if (words[0] != kMagic)
        return core::Result<SpirvModule>::Error("invalid SPIR-V magic");
    if (words[3] == 0)
        return core::Result<SpirvModule>::Error("invalid SPIR-V bound");
    if (words[4] != 0)
        return core::Result<SpirvModule>::Error("invalid SPIR-V schema");

    size_t i = 5;
    while (i < words.size()) {
        const uint32_t first = words[i];
        const uint16_t wc = static_cast<uint16_t>(first >> 16);
        if (wc == 0 || i + wc > words.size())
            return core::Result<SpirvModule>::Error("malformed SPIR-V instruction");
        i += wc;
    }

    SpirvModule m;
    m.words = words;
    m.bound = words[3];
    return core::Result<SpirvModule>::Ok(std::move(m));
}

static core::Result<void> validate_spirv_layout(const std::vector<uint32_t>& words) {
    bool saw_capability = false, saw_memory_model = false, saw_entry = false, saw_function = false;
    int function_depth = 0;
    size_t i = 5;
    while (i < words.size()) {
        const uint32_t first = words[i];
        const uint16_t wc = static_cast<uint16_t>(first >> 16);
        const uint16_t opcode = static_cast<uint16_t>(first & 0xffffu);
        if (wc == 0 || i + wc > words.size())
            return core::Result<void>::Error("malformed SPIR-V instruction");
        switch (opcode) {
            case OpCapability: saw_capability = true; break;
            case OpMemoryModel: saw_memory_model = true; break;
            case OpEntryPoint: saw_entry = true; break;
            case OpFunction: saw_function = true; ++function_depth; break;
            case OpFunctionEnd:
                if (function_depth == 0)
                    return core::Result<void>::Error("OpFunctionEnd without OpFunction");
                --function_depth;
                break;
            default: break;
        }
        i += wc;
    }
    if (function_depth != 0)
        return core::Result<void>::Error("unbalanced OpFunction/OpFunctionEnd");
    // Header-only modules: structural OK but not "full"
    if (words.size() == 5)
        return core::Result<void>::Error("SPIR-V header only; missing program layout");
    if (!saw_capability) return core::Result<void>::Error("SPIR-V missing OpCapability");
    if (!saw_memory_model) return core::Result<void>::Error("SPIR-V missing OpMemoryModel");
    if (!saw_entry) return core::Result<void>::Error("SPIR-V missing OpEntryPoint");
    if (!saw_function) return core::Result<void>::Error("SPIR-V missing OpFunction");
    return core::Result<void>::Ok();
}

core::Result<void> validate_spirv_external(const std::vector<uint32_t>& words, bool require_tool) {
    const char* tool = find_spirv_val();
    std::string probe = std::string("command -v \"") + tool + "\" >/dev/null 2>&1";
    if (std::system(probe.c_str()) != 0) {
        if (require_tool)
            return core::Result<void>::Error("spirv-val not found (set LOBOGELIDO_SPIRV_VAL)");
        return core::Result<void>::Ok();
    }

    char path2[96];
    const auto stamp = std::chrono::steady_clock::now().time_since_epoch().count();
    std::snprintf(path2, sizeof path2, "/tmp/lobo_spirv_%lld.spv", static_cast<long long>(stamp));
    {
        std::ofstream out(path2, std::ios::binary);
        if (!out) return core::Result<void>::Error("cannot write temp SPIR-V for spirv-val");
        out.write(reinterpret_cast<const char*>(words.data()),
                  static_cast<std::streamsize>(words.size() * sizeof(uint32_t)));
    }
    std::string cmd = std::string("\"") + tool + "\" \"" + path2 + "\" 2>/dev/null";
    const int rc = std::system(cmd.c_str());
    std::remove(path2);
    if (rc != 0) return core::Result<void>::Error("spirv-val rejected module");
    return core::Result<void>::Ok();
}

core::Result<SpirvModule> validate_spirv_full(const std::vector<uint32_t>& words,
                                              bool require_external) {
    auto s = validate_spirv(words);
    if (!s.ok()) return s;
    auto layout = validate_spirv_layout(words);
    if (!layout.ok())
        return core::Result<SpirvModule>::Error(layout.error().c_str());
    auto e = validate_spirv_external(words, require_external);
    if (!e.ok())
        return core::Result<SpirvModule>::Error(e.error().c_str());
    return s;
}

} // namespace lg::gpu
