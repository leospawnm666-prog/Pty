#pragma once
// Software Vulkan backends: SwiftShader (Google) and Lavapipe (Mesa LVP).
// Selection policy allows these libraries on any host (bypass Adreno-only gate).
// Blobs are NOT shipped in the APK.

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

#include "../core/result.h"

namespace lg::gpu {

enum class SoftwareVulkanKind : uint8_t {
    None = 0,
    SwiftShader,
    Lavapipe,
};

struct SoftwareVulkanIdentity {
    SoftwareVulkanKind kind{SoftwareVulkanKind::None};
    const char* label{"none"};
    const char* vendor_hint{"unknown"};
    uint32_t expected_vendor_id{0};  // 0 = do not enforce strictly
};

SoftwareVulkanIdentity classify_software_driver(std::string_view path_or_name) noexcept;
bool is_software_vulkan_path(std::string_view path_or_name) noexcept;
std::vector<std::string> software_library_hints(SoftwareVulkanKind kind);
std::string find_software_library(std::string_view root_dir, SoftwareVulkanKind kind);

/** Resolve a software ICD: VK_ICD_FILENAMES → LOBO_SOFTWARE_VULKAN_ROOT → common roots. */
std::string resolve_software_library(SoftwareVulkanKind kind) noexcept;

/** Layered resolve with explicit source (for logs / UI). */
struct SoftwareResolveReport {
    std::string path;           // empty if unresolved
    const char* source{"none"}; // forced_lib|icd_env|search_root|none
    const char* detail{""};     // human hint
    SoftwareVulkanKind kind{SoftwareVulkanKind::None};
};
SoftwareResolveReport resolve_software_library_report(SoftwareVulkanKind kind) noexcept;

/** Parse "swiftshader" / "lavapipe" / "none" (case-insensitive). */
SoftwareVulkanKind parse_software_kind(std::string_view name) noexcept;

/** Score a VkPhysicalDeviceProperties-like name/vendor for software preference (higher = better). */
int score_software_device(SoftwareVulkanKind want, uint32_t vendor_id, std::string_view device_name) noexcept;

/** Read first library_path from VK_ICD_FILENAMES / VK_DRIVER_FILES JSON files (host). */
std::string library_from_icd_env() noexcept;

struct WrittenIcdJson {
    std::string path;
};

core::Result<WrittenIcdJson> write_software_icd_json(std::string_view library_path,
                                                     SoftwareVulkanKind kind,
                                                     std::string_view output_dir);

const char* software_kind_name(SoftwareVulkanKind kind) noexcept;

/** True if vendor/name looks like a CPU software GPU (any kind). */
bool looks_like_software_gpu(uint32_t vendor_id, std::string_view device_name) noexcept;

} // namespace lg::gpu
