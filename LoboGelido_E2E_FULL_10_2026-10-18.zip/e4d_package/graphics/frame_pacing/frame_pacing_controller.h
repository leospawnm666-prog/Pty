#pragma once

#include "cadence_calculator.h"
#include <chrono>
#include <cstdint>

namespace lg::graphics::frame_pacing {

struct RefreshMetrics {
    double refresh_rate_hz{60.0};
    bool valid{false};
};

struct SynchronizationMetrics {
    std::chrono::nanoseconds cpu_frame_time{0};
    std::chrono::nanoseconds gpu_frame_time{0};
    std::chrono::nanoseconds present_wait_time{0};
    bool gpu_completed{false};
};

struct FramePacingConfig {
    double target_fps{60.0};
    std::chrono::nanoseconds max_catch_up{std::chrono::milliseconds(250)};
};

struct FramePacingDecision {
    bool valid{false};
    std::uint64_t frame_index{0};
    std::chrono::steady_clock::time_point deadline{};
    std::chrono::nanoseconds recommended_wait{0};
    std::chrono::nanoseconds frame_budget{0};
    std::chrono::nanoseconds estimated_slack{0};
    CadenceResult cadence{};
};

class FramePacingController {
public:
    explicit FramePacingController(FramePacingConfig config = {}) noexcept;

    void set_target_fps(double target_fps) noexcept;
    double target_fps() const noexcept { return config_.target_fps; }

    void update_refresh_metrics(RefreshMetrics metrics) noexcept;
    void update_synchronization_metrics(SynchronizationMetrics metrics) noexcept;

    void reset(std::chrono::steady_clock::time_point now =
                   std::chrono::steady_clock::now()) noexcept;

    FramePacingDecision begin_frame(
        std::chrono::steady_clock::time_point now =
            std::chrono::steady_clock::now()) noexcept;

    void end_frame(std::chrono::steady_clock::time_point now =
                       std::chrono::steady_clock::now()) noexcept;

    const RefreshMetrics& refresh_metrics() const noexcept { return refresh_; }
    const SynchronizationMetrics& synchronization_metrics() const noexcept { return sync_; }
    const CadenceResult& cadence() const noexcept { return cadence_; }
    std::uint64_t frame_index() const noexcept { return frame_index_; }

private:
    void recalculate_cadence() noexcept;

    FramePacingConfig config_{};
    RefreshMetrics refresh_{};
    SynchronizationMetrics sync_{};
    CadenceResult cadence_{};
    std::chrono::steady_clock::time_point next_deadline_{};
    bool started_{false};
    std::uint64_t frame_index_{0};
};

} // namespace lg::graphics::frame_pacing
