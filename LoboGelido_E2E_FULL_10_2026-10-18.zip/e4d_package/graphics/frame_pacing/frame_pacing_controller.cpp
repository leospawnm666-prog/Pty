#include "frame_pacing_controller.h"

#include <algorithm>
#include <cmath>

namespace lg::graphics::frame_pacing {
namespace {

double sanitize_fps(double value, double fallback) noexcept {
    return std::isfinite(value) && value >= 1.0 && value <= 1000.0 ? value : fallback;
}

} // namespace

FramePacingController::FramePacingController(FramePacingConfig config) noexcept
    : config_(config) {
    config_.target_fps = sanitize_fps(config_.target_fps, 60.0);
    recalculate_cadence();
}

void FramePacingController::set_target_fps(double target_fps) noexcept {
    config_.target_fps = sanitize_fps(target_fps, config_.target_fps);
    recalculate_cadence();
}

void FramePacingController::update_refresh_metrics(RefreshMetrics metrics) noexcept {
    if (metrics.valid && std::isfinite(metrics.refresh_rate_hz) &&
        metrics.refresh_rate_hz >= 1.0 && metrics.refresh_rate_hz <= 1000.0) {
        refresh_ = metrics;
        recalculate_cadence();
    }
}

void FramePacingController::update_synchronization_metrics(
    SynchronizationMetrics metrics) noexcept {
    sync_ = metrics;
}

void FramePacingController::reset(std::chrono::steady_clock::time_point now) noexcept {
    started_ = false;
    frame_index_ = 0;
    next_deadline_ = now;
}

FramePacingDecision FramePacingController::begin_frame(
    std::chrono::steady_clock::time_point now) noexcept {
    FramePacingDecision decision{};
    decision.frame_index = frame_index_;
    decision.cadence = cadence_;
    decision.frame_budget = cadence_.frame_interval;

    if (!cadence_.valid) {
        return decision;
    }

    if (!started_) {
        next_deadline_ = now;
        started_ = true;
    }

    const auto deadline = next_deadline_;
    const auto delta = deadline - now;
    const auto max_catch_up = std::max(config_.max_catch_up, std::chrono::nanoseconds{0});

    if (delta < -max_catch_up) {
        next_deadline_ = now;
    }

    decision.deadline = next_deadline_;
    decision.recommended_wait = std::max(next_deadline_ - now,
                                         std::chrono::nanoseconds{0});
    decision.estimated_slack = std::max(cadence_.frame_interval - sync_.gpu_frame_time,
                                        std::chrono::nanoseconds{0});
    decision.valid = true;
    return decision;
}

void FramePacingController::end_frame(std::chrono::steady_clock::time_point now) noexcept {
    if (!started_ || !cadence_.valid) {
        return;
    }

    ++frame_index_;
    next_deadline_ += cadence_.frame_interval;

    // Never accumulate an unbounded backlog after a slow frame. This keeps the
    // controller deterministic without forcing a sleep or touching the runtime.
    const auto max_deadline = now + config_.max_catch_up;
    if (next_deadline_ < now - config_.max_catch_up) {
        next_deadline_ = now;
    } else if (next_deadline_ > max_deadline + cadence_.frame_interval * 2) {
        next_deadline_ = now + cadence_.frame_interval;
    }
}

void FramePacingController::recalculate_cadence() noexcept {
    const double refresh_hz = refresh_.valid ? refresh_.refresh_rate_hz : config_.target_fps;
    cadence_ = CadenceCalculator::calculate({refresh_hz, config_.target_fps});
}

} // namespace lg::graphics::frame_pacing
