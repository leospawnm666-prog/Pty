#include "cadence_calculator.h"

#include <cmath>
#include <limits>

namespace lg::graphics::frame_pacing {
namespace {
constexpr double kMinRate = 1.0;
constexpr double kMaxRate = 1000.0;

bool finite_positive(double value) noexcept {
    return std::isfinite(value) && value >= kMinRate && value <= kMaxRate;
}
}

CadenceResult CadenceCalculator::calculate(CadenceConfig config) noexcept {
    CadenceResult result{};
    if (!finite_positive(config.refresh_rate_hz) || !finite_positive(config.target_fps)) {
        return result;
    }

    result.refresh_rate_hz = config.refresh_rate_hz;
    result.target_fps = config.target_fps;
    result.refresh_period_ns = 1'000'000'000.0 / config.refresh_rate_hz;
    result.frame_period_ns = 1'000'000'000.0 / config.target_fps;
    result.refreshes_per_frame = config.refresh_rate_hz / config.target_fps;
    result.base_refreshes = static_cast<std::uint32_t>(std::floor(result.refreshes_per_frame));
    result.fractional_refreshes = result.refreshes_per_frame - static_cast<double>(result.base_refreshes);
    result.frame_interval = std::chrono::nanoseconds(
        static_cast<std::int64_t>(std::llround(result.frame_period_ns)));
    result.valid = result.frame_interval.count() > 0;
    return result;
}

std::chrono::nanoseconds CadenceCalculator::presentation_offset(
    const CadenceResult& cadence, std::uint64_t frame_index) noexcept {
    if (!cadence.valid) {
        return std::chrono::nanoseconds{0};
    }

    const long double offset = static_cast<long double>(frame_index) *
                               static_cast<long double>(cadence.frame_period_ns);
    if (offset >= static_cast<long double>(std::numeric_limits<std::int64_t>::max())) {
        return std::chrono::nanoseconds{std::numeric_limits<std::int64_t>::max()};
    }
    return std::chrono::nanoseconds{static_cast<std::int64_t>(std::llround(offset))};
}

} // namespace lg::graphics::frame_pacing
