#pragma once

#include <cstdint>
#include <chrono>

namespace lg::graphics::frame_pacing {

struct CadenceConfig {
    double refresh_rate_hz{60.0};
    double target_fps{60.0};
};

struct CadenceResult {
    bool valid{false};
    double refresh_rate_hz{0.0};
    double target_fps{0.0};
    double refresh_period_ns{0.0};
    double frame_period_ns{0.0};
    double refreshes_per_frame{0.0};
    std::uint32_t base_refreshes{0};
    double fractional_refreshes{0.0};
    std::chrono::nanoseconds frame_interval{0};
};

class CadenceCalculator {
public:
    static CadenceResult calculate(CadenceConfig config) noexcept;

    // Returns the ideal presentation offset for a zero-based frame index.
    // This is purely mathematical: it never sleeps, waits, touches Vulkan,
    // Android, or the runtime.
    static std::chrono::nanoseconds presentation_offset(
        const CadenceResult& cadence, std::uint64_t frame_index) noexcept;
};

} // namespace lg::graphics::frame_pacing
