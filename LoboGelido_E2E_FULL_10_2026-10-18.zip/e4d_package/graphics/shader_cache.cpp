#include "shader_cache.h"
#include <fstream>
#include <iomanip>
#include <sstream>
#include <list>
#include <unordered_map>

namespace lg::graphics {
namespace {
constexpr size_t kMaxEntries = 4096;
constexpr size_t kMaxBlobBytes = 8u * 1024u * 1024u;
}

// --- Persistent API (main line, unchanged logic) ---
std::filesystem::path ShaderCache::file(const ShaderCacheKey& k) const {
    std::ostringstream s;
    s << std::hex << k.program << '_' << k.device << '_' << k.format << ".bin";
    return root_ / s.str();
}

bool ShaderCache::put(const ShaderCacheKey& k, const std::vector<uint8_t>& d) {
    if (root_.empty()) return false;
    std::error_code ec;
    std::filesystem::create_directories(root_, ec);
    const auto path = file(k);
    const auto tmp = path.string() + ".tmp";
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(reinterpret_cast<const char*>(d.data()), static_cast<std::streamsize>(d.size()));
    f.close();
    if (!f) return false;
    std::filesystem::rename(tmp, path, ec);
    if (ec) {
        std::filesystem::remove(path, ec);
        ec.clear();
        std::filesystem::rename(tmp, path, ec);
    }
    return !ec;
}

bool ShaderCache::get(const ShaderCacheKey& k, std::vector<uint8_t>& d) const {
    if (root_.empty()) return false;
    std::ifstream f(file(k), std::ios::binary | std::ios::ate);
    if (!f) return false;
    const auto n = f.tellg();
    if (n < 0) return false;
    d.resize(static_cast<size_t>(n));
    f.seekg(0);
    return bool(f.read(reinterpret_cast<char*>(d.data()), n));
}

// --- In-memory API (CLEAN branch) ---
bool ShaderCache::put(uint64_t key, const std::vector<uint8_t>& blob) {
    if (blob.empty() || blob.size() > kMaxBlobBytes) return false;
    std::lock_guard lock(mutex_);
    auto it = entries_.find(key);
    if (it != entries_.end()) {
        it->second = blob;
        return true;
    }
    if (entries_.size() >= kMaxEntries) {
        // Drop an arbitrary entry (unordered_map has no order; remove first).
        entries_.erase(entries_.begin());
        ++evictions_;
    }
    entries_.emplace(key, blob);
    return true;
}

bool ShaderCache::get(uint64_t key, std::vector<uint8_t>& out) const {
    std::lock_guard lock(mutex_);
    auto it = entries_.find(key);
    if (it == entries_.end()) {
        ++misses_;
        return false;
    }
    out = it->second;
    ++hits_;
    return true;
}

size_t ShaderCache::size() const {
    std::lock_guard lock(mutex_);
    return entries_.size();
}

void ShaderCache::clear() {
    std::lock_guard lock(mutex_);
    entries_.clear();
    hits_ = misses_ = evictions_ = 0;
    if (!root_.empty()) {   // main-line behaviour: clear() also drops the persistent files
        std::error_code ec;
        std::filesystem::remove_all(root_, ec);
    }
}

bool ShaderCache::save(const std::string& path) const {
    std::lock_guard lock(mutex_);
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    const uint32_t magic = 0x53484331u; // SHC1
    const uint32_t count = static_cast<uint32_t>(entries_.size());
    out.write(reinterpret_cast<const char*>(&magic), 4);
    out.write(reinterpret_cast<const char*>(&count), 4);
    for (const auto& [k, blob] : entries_) {
        out.write(reinterpret_cast<const char*>(&k), 8);
        const uint32_t sz = static_cast<uint32_t>(blob.size());
        out.write(reinterpret_cast<const char*>(&sz), 4);
        if (!blob.empty()) out.write(reinterpret_cast<const char*>(blob.data()), blob.size());
    }
    return static_cast<bool>(out);
}

size_t ShaderCache::load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return 0;
    uint32_t magic = 0, count = 0;
    in.read(reinterpret_cast<char*>(&magic), 4);
    in.read(reinterpret_cast<char*>(&count), 4);
    if (magic != 0x53484331u || count > kMaxEntries) return 0;
    std::lock_guard lock(mutex_);
    size_t loaded = 0;
    for (uint32_t i = 0; i < count; ++i) {
        uint64_t key = 0;
        uint32_t sz = 0;
        in.read(reinterpret_cast<char*>(&key), 8);
        in.read(reinterpret_cast<char*>(&sz), 4);
        if (!in || sz > kMaxBlobBytes) break;
        std::vector<uint8_t> blob(sz);
        if (sz) in.read(reinterpret_cast<char*>(blob.data()), sz);
        if (!in) break;
        entries_[key] = std::move(blob);
        ++loaded;
    }
    return loaded;
}

std::string ShaderCache::diagnostics() const {
    std::lock_guard lock(mutex_);
    std::ostringstream o;
    o << "shader_cache entries=" << entries_.size()
      << " hits=" << hits_
      << " misses=" << misses_
      << " evictions=" << evictions_
      << " hit_rate=";
    const uint64_t total = hits_ + misses_;
    if (total == 0) o << "n/a";
    else o << (100.0 * double(hits_) / double(total)) << "%";
    return o.str();
}

} // namespace lg::graphics
