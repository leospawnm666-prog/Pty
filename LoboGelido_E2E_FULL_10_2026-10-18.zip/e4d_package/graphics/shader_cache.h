#pragma once
#include <cstdint>
#include <filesystem>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace lg::graphics {

// Fusion (2026-10-16): restored from the main line (Regla de Oro). Persistent per-key files under a
// root directory; used by RuntimeCoordinator and test_gpu. Coexists with the in-memory u64 cache.
struct ShaderCacheKey {
    uint64_t program{};
    uint64_t device{};
    uint32_t format{1};
    bool operator==(const ShaderCacheKey&) const = default;
};

/**
 * Host-side shader binary cache (SPIR-V / driver blobs keyed by hash).
 * Complements gpu::AsyncPipelineCache (pipeline state) with shader module reuse.
 */
class ShaderCache {
public:
    ShaderCache() = default;
    explicit ShaderCache(std::filesystem::path root): root_(std::move(root)) {}
    // Persistent API (main line): one file per key under root().
    bool put(const ShaderCacheKey& key, const std::vector<uint8_t>& data);
    bool get(const ShaderCacheKey& key, std::vector<uint8_t>& data) const;
    const std::filesystem::path& root() const noexcept { return root_; }
    // In-memory API (CLEAN branch).
    bool put(uint64_t key, const std::vector<uint8_t>& blob);
    bool get(uint64_t key, std::vector<uint8_t>& out) const;
    size_t size() const;
    void clear();
    bool save(const std::string& path) const;
    size_t load(const std::string& path);
    std::string diagnostics() const;

private:
    std::filesystem::path file(const ShaderCacheKey&) const;
    std::filesystem::path root_;
    mutable std::mutex mutex_;
    std::unordered_map<uint64_t, std::vector<uint8_t>> entries_;
    mutable uint64_t hits_{0};
    mutable uint64_t misses_{0};
    mutable uint64_t evictions_{0};
};

} // namespace lg::graphics
