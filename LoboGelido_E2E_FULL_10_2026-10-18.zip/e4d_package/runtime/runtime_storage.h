#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "../core/result.h"

namespace lg::runtime {

/** Runtime-owned Android sandbox paths and validated key material metadata. */
struct RuntimeStorageConfig {
    std::string keys_root;
    std::string nand_root;
};

struct KeyRecord {
    std::string name;
    std::vector<uint8_t> bytes;
};

class RuntimeStorage final {
public:
    core::Result<void> configure(RuntimeStorageConfig config);
    core::Result<void> validate_for_secure_content() const;
    core::Result<void> load_key_material();
    core::Result<void> refresh_firmware_state();

    const RuntimeStorageConfig& config() const noexcept { return config_; }
    bool configured() const noexcept { return configured_; }
    bool keys_ready() const noexcept { return keys_ready_; }
    bool firmware_ready() const noexcept { return firmware_ready_; }
    bool has_key(const std::string& normalized_name) const noexcept;
    const KeyRecord* find_key(const std::string& normalized_name) const noexcept;

    std::string diagnostics() const;

private:
    static std::string normalize_key_name(std::string name);

    RuntimeStorageConfig config_{};
    std::unordered_map<std::string, KeyRecord> keys_;
    bool configured_{false};
    bool keys_ready_{false};
    bool firmware_ready_{false};
};

} // namespace lg::runtime
