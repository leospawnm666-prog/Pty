#include "guest_report.h"

#include <cinttypes>
#include <cstdio>

namespace lg::runtime {

const char* a64_instruction_family(uint32_t w) noexcept {
    const uint32_t op0 = (w >> 25) & 0xF;   // bits 28:25
    if (op0 == 0x0) return "reservada (UDF)";
    if (op0 == 0x1 || op0 == 0x3) return "no asignada";
    if (op0 == 0x2) return "SVE";
    if (op0 == 0x8 || op0 == 0x9) return "procesamiento de datos (inmediato)";
    if (op0 == 0xA || op0 == 0xB) return (w & 0xFFC00000u) == 0xD5000000u ? "sistema (MSR/MRS/SYS)" : "salto/excepción";
    if ((op0 & 0x5) == 0x4) return (w & (1u << 26)) ? "AdvSIMD/FP (carga/almacenamiento)" : "carga/almacenamiento";
    if ((op0 & 0x7) == 0x5) return "procesamiento de datos (registro)";
    return "AdvSIMD/FP";   // x111
}

bool a64_is_simd_or_fp(uint32_t w) noexcept {
    const uint32_t op0 = (w >> 25) & 0xF;
    return op0 == 0x2 || (op0 & 0x7) == 0x7 || ((op0 & 0x5) == 0x4 && (w & (1u << 26)));
}

std::string undefined_instruction_note(uint32_t word, bool on_interpreter) {
    std::string s = " [";
    s += a64_instruction_family(word);
    if (on_interpreter && a64_is_simd_or_fp(word)) s += ": no soportada por el intérprete; usa la JIT";
    s += ']';
    return s;
}

std::string utf8_truncate(const std::string& s, size_t max_bytes) {
    if (s.size() <= max_bytes) return s;
    static const char kEllipsis[] = "\xE2\x80\xA6";   // …
    size_t cut = max_bytes >= 3 ? max_bytes - 3 : 0;
    while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) --cut;   // not inside a sequence
    return s.substr(0, cut) + kEllipsis;
}

std::string utf8_sanitize_bmp(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (size_t i = 0; i < s.size();) {
        const auto c = static_cast<unsigned char>(s[i]);
        if (c == 0) { ++i; continue; }
        if (c < 0x80) { out += static_cast<char>(c); ++i; continue; }
        size_t n = 0;
        uint32_t cp = 0, min = 0;
        if ((c >> 5) == 0x6) { n = 2; cp = c & 0x1F; min = 0x80; }
        else if ((c >> 4) == 0xE) { n = 3; cp = c & 0x0F; min = 0x800; }
        else if ((c >> 3) == 0x1E) { n = 4; cp = c & 0x07; min = 0x10000; }
        bool ok = n != 0 && i + n <= s.size();
        for (size_t k = 1; ok && k < n; ++k) {
            const auto cc = static_cast<unsigned char>(s[i + k]);
            ok = (cc & 0xC0) == 0x80;
            cp = (cp << 6) | (cc & 0x3F);
        }
        ok = ok && cp >= min && cp <= 0xFFFF && (cp < 0xD800 || cp > 0xDFFF);
        if (ok) { out.append(s, i, n); i += n; }
        else {
            out += '?';
            // skip the whole (well-formed) sequence of a supplementary character, else one byte
            bool seq = n != 0 && i + n <= s.size();
            for (size_t k = 1; seq && k < n; ++k) seq = (static_cast<unsigned char>(s[i + k]) & 0xC0) == 0x80;
            i += seq ? n : 1;
        }
    }
    return out;
}

namespace {
std::string last_line(const std::string& log) {
    size_t end = log.size();
    while (end > 0) {
        while (end > 0 && (log[end - 1] == '\n' || log[end - 1] == '\r')) --end;
        if (end == 0) break;
        size_t begin = log.rfind('\n', end - 1);
        begin = begin == std::string::npos ? 0 : begin + 1;
        std::string line = log.substr(begin, end - begin);
        for (char& c : line)
            if (static_cast<unsigned char>(c) < 0x20 && c != '\t') c = ' ';   // no control characters on screen
        if (line.find_first_not_of(" \t") != std::string::npos) return line;
        end = begin;
    }
    return {};
}
} // namespace

std::string format_guest_summary(const GuestSummaryInput& in) {
    using P = GuestSummaryInput::Phase;
    std::string out = "Estado: ";
    switch (in.phase) {
        case P::None: out += "sin sesión"; break;
        case P::Ready: out += "preparado"; break;
        case P::Running: out += "ejecutando"; break;
        case P::Paused: out += "en pausa"; break;
        case P::Stopped:
            if (in.exited && in.has_code) out += "terminado (código " + std::to_string(in.code) + ")";
            else out += "terminado";
            break;
        case P::Error: out += "error"; break;
    }
    const std::string line = utf8_sanitize_bmp(last_line(in.log));
    out += "\nÚltimo log: " + (line.empty() ? std::string("(ninguno)") : utf8_truncate(line, 120));
    if (!in.error.empty()) out += "\nError: " + utf8_truncate(utf8_sanitize_bmp(in.error), 200);
    char tail[128];
    std::snprintf(tail, sizeof tail, "\nHilos: %" PRIu64 "/%" PRIu64 " \xC2\xB7 IPC: %" PRIu64 " \xC2\xB7 SVC: %" PRIu64,
                  in.live_threads, in.total_threads, in.ipc_requests, in.svc_calls);
    out += tail;
    return out;
}

} // namespace lg::runtime
