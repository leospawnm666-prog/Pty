#pragma once
// P3.5 (P3_5_DISENO.md §2.3, §2.4): short, user-facing descriptions of a guest session. Pure
// functions (no coordinator state), so they are unit tested on their own.
#include <cstdint>
#include <string>

namespace lg::runtime {

/** Family of an A64 instruction word by its top-level encoding (Arm ARM, "A64 instruction set
 *  encoding"): "AdvSIMD/FP", "AdvSIMD/FP (carga/almacenamiento)", "SVE", "sistema (MSR/MRS/SYS)",
 *  "salto/excepción", "procesamiento de datos (inmediato)", "procesamiento de datos
 *  (registro)", "carga/almacenamiento", "reservada (UDF)" or "no asignada". */
const char* a64_instruction_family(uint32_t word) noexcept;
/** True for the AdvSIMD/FP and SVE families: the interpreter engines do not implement them. */
bool a64_is_simd_or_fp(uint32_t word) noexcept;
/** " [<family>]" for an undefined-instruction fault; on the interpreter, SIMD/FP/SVE adds
 *  ": no soportada por el intérprete; usa la JIT". */
std::string undefined_instruction_note(uint32_t word, bool on_interpreter);

struct GuestSummaryInput {
    enum class Phase { None, Ready, Running, Paused, Stopped, Error } phase{Phase::None};
    bool exited{};                 // GuestExit
    bool has_code{};
    int32_t code{};
    std::string log;               // the guest log (svcOutputDebugString)
    std::string error;             // last error ("" if none)
    uint64_t live_threads{}, total_threads{};
    uint64_t ipc_requests{};
    uint64_t svc_calls{};
};
/** Up to 4 lines for the screen (UTF-8, '\n' separated, no trailing newline):
 *    Estado: ejecutando | preparado | en pausa | terminado (código N) | terminado | error | sin sesión
 *    Último log: <last non-empty line of the guest log, <= 120 bytes> | (ninguno)
 *  (guest text goes through utf8_sanitize_bmp)
 *    Error: <cause, <= 200 bytes>              (only when there is one)
 *    Hilos: vivos/total · IPC: N · SVC: N */
std::string format_guest_summary(const GuestSummaryInput& in);
/** `s` cut to at most `max_bytes` without splitting a UTF-8 sequence ("…" appended if cut). */
std::string utf8_truncate(const std::string& s, size_t max_bytes);
/** Valid UTF-8 limited to the BMP, as JNI's NewStringUTF accepts it: invalid bytes, overlong
 *  forms, surrogates and code points above U+FFFF become '?', NUL is dropped. */
std::string utf8_sanitize_bmp(const std::string& s);

} // namespace lg::runtime
