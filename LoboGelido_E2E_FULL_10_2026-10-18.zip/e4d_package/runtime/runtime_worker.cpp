#include "runtime_worker.h"

#include "runtime_coordinator.h"

#include <algorithm>
#include <exception>

namespace lg::runtime {
namespace {
constexpr uint64_t kMaxIdleWaitNs = 5'000'000;   // D-P3.3-8: 5 ms
} // namespace

RuntimeWorker::RuntimeWorker(RuntimeCoordinator& runtime)
    : runtime_(runtime) {
}

RuntimeWorker::~RuntimeWorker() noexcept {
    (void)stop();
}

bool RuntimeWorker::start() {
    std::unique_lock lock(control_mutex_);

    if (state_ != State::Stopped) return false;
    if (worker_thread_.joinable()) {
        // The worker may have ended by itself. Claim exclusive join ownership while
        // holding control_mutex_ so stop() cannot join the same std::thread concurrently.
        control_cv_.wait(lock, [this] { return !join_in_progress_; });
        if (state_ != State::Stopped || !worker_thread_.joinable()) return false;
        join_in_progress_ = true;
        lock.unlock();
        const bool joined = join_worker();
        lock.lock();
        join_in_progress_ = false;
        control_cv_.notify_all();
        if (!joined || state_ != State::Stopped || worker_thread_.joinable()) return false;
    }
    if (runtime_.state() != lg::runtime::State::Running) return false;

    stop_requested_.store(false, std::memory_order_release);
    execution_requested_ = true;
    state_ = State::Starting;

    try {
        worker_thread_ = std::thread(&RuntimeWorker::worker_main, this);
    } catch (const std::exception&) {
        execution_requested_ = false;
        stop_requested_.store(true, std::memory_order_release);
        state_ = State::Stopped;
        return false;
    } catch (...) {
        execution_requested_ = false;
        stop_requested_.store(true, std::memory_order_release);
        state_ = State::Stopped;
        return false;
    }

    return true;
}

bool RuntimeWorker::pause() {
    {
        std::lock_guard lock(control_mutex_);
        if (state_ != State::Running && state_ != State::Starting) return false;
        if (stop_requested_.load(std::memory_order_acquire)) return false;
        execution_requested_ = false;
    }
    notify_worker();
    return true;
}

bool RuntimeWorker::resume() {
    {
        std::lock_guard lock(control_mutex_);
        if (state_ != State::Paused) return false;
        if (stop_requested_.load(std::memory_order_acquire)) return false;
        execution_requested_ = true;
        state_ = State::Running;
    }
    notify_worker();
    return true;
}

bool RuntimeWorker::wait_until_state(State target, std::chrono::milliseconds timeout) {
    std::unique_lock lock(control_mutex_);
    return control_cv_.wait_for(lock, timeout, [this, target] {
        return state_ == target
            || state_ == State::Error
            || state_ == State::Stopped;
    }) && state_ == target;
}

bool RuntimeWorker::stop() {
    bool self_worker = false;
    {
        std::unique_lock lock(control_mutex_);
        if (state_ == State::Stopped && !worker_thread_.joinable()) return true;

        request_stop_locked();
        state_ = State::Stopping;
        self_worker = is_worker_thread_locked();
        if (!self_worker) {
            // std::thread::join() is not safe when called concurrently on the
            // same thread object. Serialize join ownership without holding the
            // mutex needed by worker_main().
            control_cv_.wait(lock, [this] { return !join_in_progress_; });
            if (!worker_thread_.joinable()) {
                execution_requested_ = false;
                state_ = State::Stopped;
                return true;
            }
            join_in_progress_ = true;
        }
    }

    notify_worker();
    // A worker may request its own stop, but must never join itself. The
    // external owner retains the joinable thread and completes cleanup later.
    if (self_worker) return true;

    const bool joined = join_worker();
    {
        std::lock_guard lock(control_mutex_);
        join_in_progress_ = false;
        if (joined) {
            execution_requested_ = false;
            state_ = State::Stopped;
        }
    }
    notify_worker();
    return joined;
}

RuntimeWorker::State RuntimeWorker::state() const noexcept {
    std::lock_guard lock(control_mutex_);
    return state_;
}

bool RuntimeWorker::is_running() const noexcept {
    return state() == State::Running;
}

bool RuntimeWorker::is_stopped() const noexcept {
    return state() == State::Stopped;
}

void RuntimeWorker::worker_main() noexcept {
    try {
        {
            std::lock_guard lock(control_mutex_);
            if (stop_requested_.load(std::memory_order_acquire)) {
                state_ = State::Stopping;
            } else if (execution_requested_) {
                state_ = State::Running;
            } else {
                state_ = State::Paused;
            }
        }
        notify_worker();

        for (;;) {
            if (!wait_for_execution_or_stop()) break;
            if (should_stop()) break;

            // One coordinator quantum is the worker's unit of execution.
            // The worker never owns or reimplements the scheduler/CPU loop.
            const auto result = runtime_.run_frame(runtime_.entry_point());
            if (result.ok() && runtime_.state() == lg::runtime::State::Stopped) {
                // P3.1 (audit A3): the guest ended its process and the coordinator closed the
                // session cleanly. That is a normal end of execution, not an Error.
                std::lock_guard lock(control_mutex_);
                execution_requested_ = false;
                if (!stop_requested_.load(std::memory_order_acquire)) state_ = State::Stopped;
                else state_ = State::Stopping;
                control_cv_.notify_all();
                break;
            }
            if (!result.ok()) {
                std::lock_guard lock(control_mutex_);
                if (!stop_requested_.load(std::memory_order_acquire)) {
                    execution_requested_ = false;
                    state_ = State::Error;
                }
                notify_worker();
                break;
            }

            // P3.3 (D-P3.3-8): every guest thread waits for a timeout -> sleep until it, at
            // most 5 ms, instead of spinning. pause()/stop() wake the wait at once.
            const uint64_t idle_ns = runtime_.idle_deadline_ns();

            std::unique_lock lock(control_mutex_);
            if (idle_ns > 0 && can_execute_locked()) {
                const auto wait = std::chrono::nanoseconds(std::min<uint64_t>(idle_ns, kMaxIdleWaitNs));
                control_cv_.wait_for(lock, wait, [this] {
                    return stop_requested_.load(std::memory_order_acquire) || !execution_requested_;
                });
            }
            if (stop_requested_.load(std::memory_order_acquire)) {
                state_ = State::Stopping;
                break;
            }
            if (!execution_requested_) {
                const bool changed = state_ != State::Paused;
                state_ = State::Paused;
                if (changed) control_cv_.notify_all();   // P3.3: wait_until_state(Paused) sees it at once
            } else {
                state_ = State::Running;
            }
        }
    } catch (...) {
        // The thread entry point is noexcept by contract. No exception may
        // escape into std::thread and trigger std::terminate().
        std::lock_guard lock(control_mutex_);
        execution_requested_ = false;
        if (stop_requested_.load(std::memory_order_acquire)) {
            state_ = State::Stopping;
        } else {
            state_ = State::Error;
            stop_requested_.store(true, std::memory_order_release);
        }
        control_cv_.notify_all();
    }
}

bool RuntimeWorker::can_execute_locked() const noexcept {
    return execution_requested_ && !stop_requested_.load(std::memory_order_acquire)
        && (state_ == State::Starting || state_ == State::Running);
}

bool RuntimeWorker::should_stop() const noexcept {
    return stop_requested_.load(std::memory_order_acquire);
}

void RuntimeWorker::request_stop_locked() noexcept {
    stop_requested_.store(true, std::memory_order_release);
    execution_requested_ = false;
}

void RuntimeWorker::transition_to_locked(State next) noexcept {
    state_ = next;
}

void RuntimeWorker::notify_worker() noexcept {
    control_cv_.notify_all();
}

bool RuntimeWorker::join_worker() noexcept {
    if (!worker_thread_.joinable() || is_worker_thread_locked()) return false;
    try {
        worker_thread_.join();
        return true;
    } catch (...) {
        return false;
    }
}

bool RuntimeWorker::is_worker_thread_locked() const noexcept {
    return worker_thread_.joinable()
        && worker_thread_.get_id() == std::this_thread::get_id();
}

bool RuntimeWorker::wait_for_execution_or_stop() {
    std::unique_lock lock(control_mutex_);
    control_cv_.wait(lock, [this] {
        return stop_requested_.load(std::memory_order_acquire)
            || can_execute_locked()
            || state_ == State::Error;
    });

    if (stop_requested_.load(std::memory_order_acquire) || state_ == State::Error) {
        return false;
    }
    return can_execute_locked();
}

} // namespace lg::runtime
