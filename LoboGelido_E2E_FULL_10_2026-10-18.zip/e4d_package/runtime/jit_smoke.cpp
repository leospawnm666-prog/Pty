#include "jit_smoke.h"

#include "runtime_coordinator.h"

#include <cstring>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <system_error>

namespace lg::runtime {
namespace {
namespace fs = std::filesystem;
[[maybe_unused]] constexpr const char* kMarkerName = "jit_smoke.inprogress";
[[maybe_unused]] constexpr const char* kImageName = "jit_smoke.nro";

void put32(std::vector<uint8_t>& b, size_t at, uint32_t v) {
    for (int i = 0; i < 4; ++i) b[at + size_t(i)] = static_cast<uint8_t>(v >> (8 * i));
}
[[maybe_unused]] bool write_file(const fs::path& p, const void* data, size_t size) {
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    f.write(static_cast<const char*>(data), static_cast<std::streamsize>(size));
    return static_cast<bool>(f);
}
[[maybe_unused]] std::string read_file(const fs::path& p) {
    std::ifstream f(p, std::ios::binary);
    return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}
} // namespace

const char* jit_smoke_status_name(JitSmokeResult::Status s) noexcept {
    switch (s) {
        case JitSmokeResult::Status::Ok: return "ok";
        case JitSmokeResult::Status::Failed: return "failed";
        case JitSmokeResult::Status::Skipped: return "skipped";
        case JitSmokeResult::Status::CrashedBefore: return "crashed_before";
    }
    return "skipped";
}

std::vector<uint8_t> jit_smoke_nro() {
    constexpr size_t kPage = 0x1000;
    std::vector<uint8_t> b(3 * kPage, 0);
    put32(b, 0x00, 0x14000020);   // b 0x80 (over the header, like crt0)
    std::memcpy(&b[0x10], "NRO0", 4);
    put32(b, 0x18, 3 * kPage);    // size
    put32(b, 0x20, 0);            // text
    put32(b, 0x24, kPage);
    put32(b, 0x28, kPage);        // rodata
    put32(b, 0x2C, kPage);
    put32(b, 0x30, 2 * kPage);    // data
    put32(b, 0x34, kPage);
    // Entered with x0 = ConfigEntry list, x1 = -1, x30 = Lobo's exit stub; returns 84.
    static constexpr uint32_t kCode[] = {
        0xD2800549,   // mov  x9, #42
        0x9E670120,   // fmov d0, x9              (FP)
        0x4EE08400,   // add  v0.2d, v0.2d, v0.2d (AdvSIMD)
        0x3C9F0FE0,   // str  q0, [sp, #-16]!     (SIMD store)
        0x3CC107E1,   // ldr  q1, [sp], #16       (SIMD load)
        0x9E660020,   // fmov x0, d1              -> 84
        0xD65F03C0,   // ret                      -> exit stub, code = x0
    };
    for (size_t i = 0; i < std::size(kCode); ++i) put32(b, 0x80 + 4 * i, kCode[i]);
    return b;
}

JitSmokeResult run_jit_smoke(const std::string& scratch_dir, const std::string& build_tag) {
    return run_jit_smoke_image(scratch_dir, build_tag, jit_smoke_nro());
}

JitSmokeResult run_jit_smoke_image(const std::string& scratch_dir, const std::string& build_tag,
                                   const std::vector<uint8_t>& image) {
    using S = JitSmokeResult::Status;
#if !defined(LOBOGELIDO_HAS_DYNARMIC)
    (void)scratch_dir; (void)build_tag; (void)image;
    return {S::Skipped, "built without the JIT"};
#else
    try {
        std::error_code ec;
        const fs::path dir(scratch_dir);
        if (scratch_dir.empty()) return {S::Skipped, "no scratch directory"};
        fs::create_directories(dir, ec);
        if (!fs::is_directory(dir, ec)) return {S::Skipped, "no scratch directory"};
        const fs::path marker = dir / kMarkerName;
        if (fs::exists(marker, ec)) {
            if (read_file(marker) == build_tag) return {S::CrashedBefore, "the previous smoke run of this build did not finish"};
            fs::remove(marker, ec);   // another build's marker: try again
        }
        const fs::path nro = dir / kImageName;
        if (!write_file(nro, image.data(), image.size())) return {S::Skipped, "cannot write the smoke image"};
        if (!write_file(marker, build_tag.data(), build_tag.size())) return {S::Skipped, "cannot write the smoke marker"};

        JitSmokeResult out{S::Failed, {}};
        {
            RuntimeCoordinator rt;
            rt.set_guest_memory_budget(16ull << 20);
            rt.set_force_interpreter(false);
            rt.set_jit_fastmem(false);
            auto r = rt.prepare(nro.string());
            if (!r.ok()) out.detail = std::string("prepare: ") + r.error();
            else if (std::strcmp(rt.cpu_backend_name(), "Block") == 0 || std::strcmp(rt.cpu_backend_name(), "Interpreter") == 0)
                out = {S::Skipped, "JIT unavailable"};
            else if (r = rt.start(); !r.ok()) out.detail = std::string("start: ") + r.error();
            else {
                for (int i = 0; i < 10000 && rt.state() == State::Running; ++i) {
                    r = rt.run_frame(rt.entry_point());
                    if (!r.ok()) { out.detail = r.error(); break; }
                }
                const auto ex = rt.guest_exit();
                if (out.detail.empty()) {
                    if (rt.state() == State::Stopped && ex.has_code && ex.code == kJitSmokeExitCode) out = {S::Ok, {}};
                    else if (rt.state() == State::Running) out.detail = "did not finish";
                    else out.detail = "exit code " + std::to_string(ex.has_code ? ex.code : -1);
                }
            }
            if (out.status == S::Failed && out.detail.empty()) out.detail = "unknown";
            (void)rt.stop();
        }
        fs::remove(marker, ec);
        fs::remove(nro, ec);
        return out;
    } catch (const std::exception& e) {
        return {S::Failed, std::string("exception: ") + e.what()};
    } catch (...) {
        return {S::Failed, "exception"};
    }
#endif
}

} // namespace lg::runtime
