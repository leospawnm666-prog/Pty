#pragma once

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <chrono>

namespace lg::runtime {

class RuntimeCoordinator;

// Host-side execution orchestrator for a RuntimeCoordinator.
//
// RuntimeWorker owns no guest/runtime resources. It owns only the host thread
// and its execution control state. RuntimeCoordinator remains the lifecycle
// and execution authority for the emulated system.
class RuntimeWorker final {
public:
    enum class State {
        Stopped,
        Starting,
        Running,
        Paused,
        Stopping,
        Error,
    };

    explicit RuntimeWorker(RuntimeCoordinator& runtime);
    ~RuntimeWorker() noexcept;

    RuntimeWorker(const RuntimeWorker&) = delete;
    RuntimeWorker& operator=(const RuntimeWorker&) = delete;
    RuntimeWorker(RuntimeWorker&&) = delete;
    RuntimeWorker& operator=(RuntimeWorker&&) = delete;

    bool start();
    bool pause();
    bool resume();
    bool stop();
    bool wait_until_state(State target, std::chrono::milliseconds timeout);

    State state() const noexcept;
    bool is_running() const noexcept;
    bool is_stopped() const noexcept;

private:
    void worker_main() noexcept;
    bool can_execute_locked() const noexcept;
    bool should_stop() const noexcept;
    void request_stop_locked() noexcept;
    void transition_to_locked(State next) noexcept;
    void notify_worker() noexcept;
    bool join_worker() noexcept;
    bool is_worker_thread_locked() const noexcept;
    bool wait_for_execution_or_stop();

    RuntimeCoordinator& runtime_;
    std::thread worker_thread_;
    mutable std::mutex control_mutex_;
    std::condition_variable control_cv_;
    State state_{State::Stopped};
    std::atomic<bool> stop_requested_{false};
    bool execution_requested_{false};
    bool join_in_progress_{false};
};

} // namespace lg::runtime
