#pragma once
#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>

#include "runtime_metrics.h"
#include "../core/result.h"
#include "../core/session.h"
#include "../cpu/backend.h"
#include "../cpu/backend_manager.h"
#include "../cpu/interpreter.h"
#include "../cpu/block_backend.h"
#include "../cpu/jit_backend.h"
#include "../cpu/guest_clock.h"
#include "../system/process_layout.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"
#include "../system/kernel.h"
#include "../system/kipc.h"
#include "../system/kobjects.h"
#include "../system/kthread.h"
#include "../system/svc_dispatcher.h"
#include "../system/vm_manager.h"
#include "../gpu/gpu_device.h"
#include "../gpu/maxwell_shader_pipeline.h"
#include "../gpu/guest_gpu_translator.h"
#include "../gpu/gpu_command_processor.h"
#include "../gpu/maxwell_pushbuffer.h"
#include "../graphics/shader_cache.h"
#include "../recovery/watchdog.h"
#include "runtime_storage.h"

namespace lg::runtime {

enum class State { Cold, Preparing, Ready, Running, Paused, Recovering, Stopped, Error };

class InterpreterBackend final : public cpu::Backend {
public:
    InterpreterBackend(memory::AddressSpace& memory, memory::Mmu& mmu) : cpu_(memory, mmu) {}
    core::Result<void> initialize() override { return core::Result<void>::Ok(); }
    core::Result<void> execute(uint64_t guest_pc) override;
    const char* name() const noexcept override { return "Interpreter"; }
    cpu::BackendKind kind() const noexcept override { return cpu::BackendKind::Interpreter; }
    cpu::Interpreter& interpreter() noexcept { return cpu_; }
    uint64_t instruction_count() const noexcept { return state_.instructions; }
private:
    cpu::Interpreter cpu_;
    cpu::CpuState state_{};
};

class RuntimeCoordinator final {
public:
    RuntimeCoordinator();
    ~RuntimeCoordinator() = default;

    RuntimeCoordinator(const RuntimeCoordinator&) = delete;
    RuntimeCoordinator& operator=(const RuntimeCoordinator&) = delete;

    core::Result<void> prepare();
    core::Result<void> prepare(const std::string& content_path);
    core::Result<void> configure_storage(RuntimeStorageConfig config);
    core::Result<void> start();
    core::Result<void> pause();
    core::Result<void> resume();
    core::Result<void> stop();
    core::Result<void> run_frame(uint64_t guest_pc);
    /** Lock-free frontend button snapshot, applied to HLE HID on the runtime worker at frame boundaries. */
    void set_frontend_input_mask(uint32_t mask) noexcept;
    /** Maxwell VS+FS → SPIR-V program id (production shader path). */
    core::Result<uint32_t> compile_maxwell_graphics(const uint64_t* vertex_code, size_t vertex_words,
                                                    const uint64_t* fragment_code, size_t fragment_words,
                                                    const char* name = nullptr);
    /** Intermediate guest GPU packets → GpuCommandProcessor (BindPipeline uses program ids). */
    core::Result<void> submit_guest_gpu_packets(const std::vector<gpu::GuestGpuPacket>& packets);
    const gpu::MaxwellShaderPipeline& maxwell_shaders() const noexcept { return maxwell_shaders_; }
    const gpu::GpuCommandProcessor& gpu_commands() const noexcept { return gpu_cmds_; }
    /** Ingest clean-room Maxwell method stream and submit through translator/processor. */
    core::Result<void> process_maxwell_pushbuffer(const uint32_t* words, size_t count);
    const gpu::MaxwellPushbufferEngine& pushbuffer() const noexcept { return pushbuffer_; }
    void set_frontend_analog(int32_t lx, int32_t ly, int32_t rx, int32_t ry) noexcept;
    core::Result<void> create_guest_thread(const char* name, uint8_t priority, uint64_t pc, uint64_t sp = 0);
    core::Result<void> dispatch_guest_thread(uint64_t quantum = 64);
    core::Result<void> recover(const char* reason);

    State state() const noexcept;
    RuntimeMetrics metrics() const;
    uint64_t entry_point() const noexcept;
    std::string title_id() const;
    const system::ProcessManager::Process* process() const noexcept;
    const char* cpu_backend_name() const noexcept;
    std::string diagnostics() const;
    std::string storage_diagnostics() const;
    /** Guest memory (P2 phase D). 0 = automatic budget from physical RAM (the default);
     *  otherwise the arena size in bytes (rounded down to 4 KiB, clamped to [16 MiB,
     *  4 GiB]). Takes effect at the next prepare(). */
    void set_guest_memory_budget(uint64_t bytes) noexcept;
    /** Arena size chosen by the last successful prepare() (0 before the first one). */
    uint64_t guest_memory_size() const noexcept;
    /** P2 phase E.2b: let the JIT use fastmem (the arena becomes a memfd, mapped a second
     *  time into the JIT's fastmem window). OFF by default until validated on devices:
     *  it relies on a SIGSEGV handler coexisting with ART, and memfd memory is not
     *  commit-accounted. Takes effect at the next prepare(). */
    void set_jit_fastmem(bool enabled) noexcept;
    bool jit_fastmem() const noexcept;
    /** P2 phase E.3: developer kill-switch ("Forzar intérprete CPU"). When set, the JIT
     *  is neither initialized nor selected: the interpreter-based Block backend runs.
     *  Takes effect at the next prepare(). */
    void set_force_interpreter(bool enabled) noexcept;
    bool force_interpreter() const noexcept;

    // ---- P3.0 ------------------------------------------------------------------------
    /** Layout of the current process when it was built from a real executable (a native
     *  NRO); empty for the synthetic formats and the NCA path (identity mapped as before). */
    std::optional<system::ProcessLayout> process_layout() const;
    /** Last exception that terminated a guest thread (kind None if none). */
    struct GuestFault { cpu::ExceptionKind kind{cpu::ExceptionKind::None}; uint64_t address{}; uint32_t syndrome{}; uint64_t thread{};
                        uint64_t x0{}, x1{};      // x0/x1: the SVC's first arguments
                        uint64_t pc{}, lr{};      // P3.5: where it happened (diagnostics)
                        uint32_t insn{}; bool insn_valid{};   // P3.5: the word at pc (undefined instruction)
                        bool on_interpreter{}; };             // P3.5: which engine met it
    GuestFault last_guest_fault() const;
    /** Guest clock of the current session (nullptr before prepare()). Tests/diagnostics. */
    const cpu::GuestClock* guest_clock() const noexcept;
    /** Diagnostics/tests: reads guest VIRTUAL memory through the Mmu (user read permission). */
    std::optional<uint64_t> debug_read_guest64(uint64_t va) const;
    /** Frames in which no thread was runnable and time jumped to the next event. */
    uint64_t idle_skips() const noexcept;
    /** Tests/diagnostics only: the guest kernel. Not synchronised; use while the session is
     *  not running on the worker thread. */
    system::Kernel& kernel_for_testing() noexcept { return kernel_; }

    // ---- P3.1 ------------------------------------------------------------------------
    /** Guest debug output of the current/last session (svcOutputDebugString, last 64 KiB).
     *  Kept after the guest exits, until the next prepare(). */
    std::string guest_log() const;
    /** Optional mirror of every guest debug string (Android: logcat tag "LoboGuest"). Called
     *  on the guest-execution thread with the coordinator locked: it must not call back into
     *  the coordinator. Survives prepare()/stop(). */
    void set_guest_log_sink(std::function<void(const std::string&)> sink);
    /** How the guest ended its process (exited == false while it runs or after a fault). */
    system::GuestExit guest_exit() const;
    /** SVC statistics of the current/last session. */
    uint64_t svc_calls(uint32_t id) const;
    system::SvcRecord last_svc() const;
    /** Handle of the main thread given to the guest (x1 of an NSO, MainThreadHandle of an NRO). */
    uint32_t main_thread_handle() const;

    // ---- P3.2 ------------------------------------------------------------------------
    /** Tests/diagnostics only: the process memory manager (inactive for synthetic images).
     *  Not synchronised; use while the session is not running on the worker thread. */
    const system::VmManager& vm_for_testing() const noexcept { return vm_; }

    // ---- P3.5 ------------------------------------------------------------------------
    /** Up to 4 short lines for the screen (state, last guest log line, error, threads/IPC/SVC);
     *  see guest_report.h. */
    std::string guest_summary() const;
    /** Name the guest sees as argv[0] of a native NRO (the user's file name when the content
     *  comes from a descriptor, whose path is "/proc/self/fd/N"). Directories are dropped;
     *  "" (the default) keeps the name of the content path. Takes effect at the next prepare(). */
    void set_content_display_name(std::string name);
    std::string content_display_name() const;

    // ---- P3.6 ------------------------------------------------------------------------
    /** Base quantum of the guest threads of the current native process (8192 with the JIT,
     *  2048 on the interpreter engines); 64 otherwise. Diagnostics/tests. */
    uint64_t native_quantum() const noexcept;
    /** SVCs serviced inside a turn without ending it (P3_6_DISENO.md §2.2), this session. */
    uint64_t svc_continuations() const noexcept;

    // ---- P3.3 ------------------------------------------------------------------------
    /** Nanoseconds until the next guest timeout when no guest thread can run right now (the
     *  worker sleeps that long, at most 5 ms, D-P3.3-8); 0 when a thread is runnable, when
     *  nothing is pending, or for synthetic images. */
    uint64_t idle_deadline_ns() const;
    /** Frames in which every virtual core was idle while a timeout was pending (current or
     *  last session; reset by prepare()). */
    uint64_t idle_waits() const noexcept;
    /** Tests only (D-P3.3-2): switch the session's GuestClock to manual time / advance it. */
    void set_manual_guest_clock_for_testing(bool manual);
    void advance_guest_clock_for_testing(uint64_t ticks);
    /** Tests/diagnostics only: the guest kernel threads (inactive for synthetic images). Not
     *  synchronised; use while the session is not running on the worker thread. */
    const system::KernelThreads& kthreads_for_testing() const noexcept { return kthreads_; }

    // ---- P3.4 ------------------------------------------------------------------------
    /** Tests/diagnostics only: the guest kernel's IPC (inactive for synthetic images). Not
     *  synchronised; use while the session is not running on the worker thread. */
    system::KernelIpc& ipc_for_testing() noexcept { return kipc_; }

private:
    core::Result<void> prepare_memory();
    core::Result<void> load_content(const std::string& content_path);
    core::Result<void> initialize_services();
    core::Result<void> initialize_backends();
    core::Result<void> create_main_thread();
    core::Result<void> load_native_nro(const std::string& content_path, uint64_t image_size);   // P3.0
    core::Result<void> load_native_nso(const std::string& content_path);                        // P3.0-A
    core::Result<void> register_native_process(const std::string& content_path);                // P3.0-A
    void install_guest_clock(const cpu::GuestClock* clock) noexcept;                            // P3.0
    void record_guest_fault(uint64_t thread, const cpu::CpuState& ctx) noexcept;                // P3.0
    const char* image_kind_name() const noexcept;                                               // P3.0
    // P3.6: one stretch of a turn, up to the end of the slice, an SVC or a fault.
    enum class SegmentOutcome { End, SvcContinue };
    SegmentOutcome run_guest_segment(uint64_t tid, cpu::CpuState& ctx, uint64_t slice, uint64_t& segment);
    /** P3.1; P3.6: returns true when the SVC let the thread go on (outcome Continue). */
    bool handle_svc(uint64_t thread, cpu::CpuState& ctx, uint64_t instructions_before, bool report_ticks); // P3.1
    core::Result<void> setup_entry_abi(cpu::CpuState& ctx, const std::string& content_path);          // P3.1
    void finish_guest_exit() noexcept;                                                                 // P3.1
    core::Result<void> setup_process_memory();                                                         // P3.2
    uint64_t spawn_guest_thread(const char* name, uint8_t priority, uint64_t pc, uint64_t sp);         // P3.3
    void run_guest_turn(uint64_t tid);                                                                 // P3.3
    core::Result<void> run_virtual_cores(bool& idle);                                                  // P3.3
    core::Result<void> setup_kernel_threads();                                                         // P3.3
    std::string fault_text() const;                                                             // P3.0
    core::Result<void> fail(const char* message);
    void reset_runtime_state() noexcept;
    bool transition(State expected, State next) noexcept;

    mutable std::mutex mutex_;
    std::atomic<uint32_t> frontend_input_mask_{0};
    std::atomic<int32_t> frontend_lx_{0}, frontend_ly_{0}, frontend_rx_{0}, frontend_ry_{0};
    core::Session session_;
    memory::AddressSpace memory_;
    memory::Mmu mmu_;
    // P3.0: declared before the backends so it outlives every engine that points to it.
    std::unique_ptr<cpu::GuestClock> guest_clock_;
    system::Kernel kernel_;
    gpu::GpuDevice gpu_;
    gpu::MaxwellShaderPipeline maxwell_shaders_;
    gpu::GuestGpuTranslator guest_gpu_;
    gpu::GpuCommandProcessor gpu_cmds_;
    gpu::MaxwellPushbufferEngine pushbuffer_;
    graphics::ShaderCache shader_cache_;
    RuntimeStorage storage_;
    recovery::Watchdog watchdog_;
    cpu::BackendManager backends_;
    InterpreterBackend* interpreter_backend_{};
    cpu::BlockBackend* block_backend_{};
    cpu::JitBackend* jit_backend_{};
    cpu::Backend* backend_{};
    uint64_t main_thread_{};
    system::ProcessManager::ProcessId main_process_{};
    RuntimeMetrics metrics_{};
    State state_{State::Cold};
    std::chrono::steady_clock::time_point last_progress_{};
    uint64_t entry_point_{};
    std::string title_id_;
    uint64_t guest_memory_override_{};   // P2 phase D: 0 = automatic
    uint64_t guest_memory_size_{};
    bool jit_fastmem_{false};           // P2 phase E.2b
    bool force_interpreter_{false};     // P2 phase E.3
    // P3.0
    enum class ImageKind : uint8_t { None, SyntheticNro, SyntheticNso, NativeNro, Nca, NativeNso };
    ImageKind image_kind_{ImageKind::None};
    std::optional<system::ProcessLayout> layout_;
    GuestFault last_fault_{};
    uint64_t idle_skips_{};
    std::string last_error_;
    // P3.1: declared after memory_/mmu_ (it keeps references to both).
    system::SvcDispatcher svc_;
    uint64_t program_id_{};            // NCA title id (D-P3.1-1: 0 for NRO/plain NSO)
    uint32_t main_thread_handle_{};
    std::string content_path_;         // argv of a homebrew NRO
    std::string content_display_name_; // P3.5: argv[0] override (set_content_display_name)
    struct EndedCounts { uint64_t live_threads{}, total_threads{}, ipc_requests{}; };
    EndedCounts ended_counts_{};       // P3.5: last session's counts for guest_summary()
    uint64_t native_quantum_{64};      // P3.6: base quantum of native guest threads
    uint64_t svc_continuations_{};     // P3.6: SVCs that did not end the turn
    bool guest_exit_pending_{};        // ExitProcess serviced during the current dispatch
    std::string svc_fatal_;            // fatal SVC outcome of the current dispatch
    // P3.2: declared after memory_/mmu_ (it keeps references to both).
    system::VmManager vm_;
    // P3.3: declared last (it keeps pointers to svc_, vm_ and the kernel's threads/contexts).
    system::KernelThreads kthreads_;
    uint64_t idle_waits_{};
    // P3.4: declared after kthreads_ (it keeps a pointer to it).
    system::KernelIpc kipc_;
    // P6.0: memory objects and the resource limit (pointers to svc_, vm_, kthreads_, kipc_).
    system::KernelObjects kobjects_;
};

} // namespace lg::runtime
