#include "runtime_storage.h"

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace lg::runtime {
namespace fs = std::filesystem;
namespace {
constexpr std::size_t kMaxKeyFileBytes = 16u * 1024u * 1024u;

core::Result<std::vector<uint8_t>> read_file(const fs::path& path) {
    std::error_code ec;
    const auto size = fs::file_size(path, ec);
    if (ec) return core::Result<std::vector<uint8_t>>::Error("cannot stat key file");
    if (size > kMaxKeyFileBytes) return core::Result<std::vector<uint8_t>>::Error("key file exceeds runtime limit");
    std::ifstream in(path, std::ios::binary);
    if (!in) return core::Result<std::vector<uint8_t>>::Error("cannot open key file");
    std::vector<uint8_t> bytes(static_cast<std::size_t>(size));
    if (!bytes.empty() && !in.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size())))
        return core::Result<std::vector<uint8_t>>::Error("cannot read key file");
    return core::Result<std::vector<uint8_t>>::Ok(std::move(bytes));
}

bool is_hex(std::string_view value) {
    if (value.size() < 8 || (value.size() % 2) != 0) return false;
    return std::all_of(value.begin(), value.end(), [](char c) {
        return std::isxdigit(static_cast<unsigned char>(c)) != 0;
    });
}

bool parse_key_line(std::string_view line, std::string& name) {
    while (!line.empty() && std::isspace(static_cast<unsigned char>(line.front()))) line.remove_prefix(1);
    while (!line.empty() && std::isspace(static_cast<unsigned char>(line.back()))) line.remove_suffix(1);
    if (line.empty() || line.front() == '#') return false;
    const auto eq = line.find('=');
    if (eq == std::string_view::npos) return false;
    auto lhs = line.substr(0, eq);
    auto rhs = line.substr(eq + 1);
    while (!lhs.empty() && std::isspace(static_cast<unsigned char>(lhs.back()))) lhs.remove_suffix(1);
    while (!rhs.empty() && std::isspace(static_cast<unsigned char>(rhs.front()))) rhs.remove_prefix(1);
    while (!rhs.empty() && std::isspace(static_cast<unsigned char>(rhs.back()))) rhs.remove_suffix(1);
    if (lhs.empty() || !is_hex(rhs)) return false;
    name.assign(lhs.begin(), lhs.end());
    return true;
}
} // namespace

core::Result<void> RuntimeStorage::configure(RuntimeStorageConfig config) {
    if (config.keys_root.empty() || config.nand_root.empty())
        return core::Result<void>::Error("runtime storage paths are empty");

    // Configuration itself must not require that the user has already imported
    // keys/firmware. The Android importer owns those directories and may create
    // them asynchronously. We create the roots here so launch can proceed to
    // the real validation stage, where missing material is reported precisely.
    std::error_code ec;
    fs::create_directories(config.keys_root, ec);
    if (ec || !fs::is_directory(config.keys_root, ec))
        return core::Result<void>::Error("cannot create/access runtime keys directory");

    ec.clear();
    fs::create_directories(config.nand_root, ec);
    if (ec || !fs::is_directory(config.nand_root, ec))
        return core::Result<void>::Error("cannot create/access runtime nand directory");

    config_ = std::move(config);
    configured_ = true;
    keys_.clear();
    keys_ready_ = false;
    firmware_ready_ = false;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeStorage::load_key_material() {
    if (!configured_) return core::Result<void>::Error("runtime storage is not configured");
    keys_.clear();
    const fs::path root(config_.keys_root);
    std::error_code ec;
    if (!fs::is_directory(root, ec)) return core::Result<void>::Error("keys directory is missing");

    bool found_valid_line = false;
    bool found_prod_file = false;
    for (const auto& entry : fs::directory_iterator(root, ec)) {
        if (ec) return core::Result<void>::Error("failed to enumerate keys directory");
        if (!entry.is_regular_file(ec)) continue;
        // Case-insensitive match: Android app files are case-sensitive, but user ZIPs
        // often ship Prod.KEYS / Title.Keys. Normalize so launch does not false-fail.
        const auto fname = entry.path().filename().string();
        std::string lower_name = fname;
        std::transform(lower_name.begin(), lower_name.end(), lower_name.begin(),
                       [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (lower_name.size() < 5 || lower_name.compare(lower_name.size() - 5, 5, ".keys") != 0) continue;
        if (lower_name == "prod.keys") found_prod_file = true;
        auto bytes = read_file(entry.path());
        if (!bytes.ok()) return core::Result<void>::Error(bytes.error().c_str());
        std::string text(reinterpret_cast<const char*>(bytes.value().data()), bytes.value().size());
        std::size_t begin = 0;
        while (begin <= text.size()) {
            const auto end = text.find('\n', begin);
            const auto line = std::string_view(text).substr(begin, end == std::string::npos ? text.size() - begin : end - begin);
            std::string name;
            if (parse_key_line(line, name)) {
                const auto normalized = normalize_key_name(name);
                if (!keys_.contains(normalized)) {
                    // The runtime keeps the decoded value only in native memory.
                    const auto eq = line.find('=');
                    auto hex = line.substr(eq + 1);
                    while (!hex.empty() && std::isspace(static_cast<unsigned char>(hex.front()))) hex.remove_prefix(1);
                    while (!hex.empty() && std::isspace(static_cast<unsigned char>(hex.back()))) hex.remove_suffix(1);
                    std::vector<uint8_t> value;
                    value.reserve(hex.size() / 2);
                    for (std::size_t i = 0; i < hex.size(); i += 2) {
                        const auto digit = [](char c) -> uint8_t {
                            if (c >= '0' && c <= '9') return static_cast<uint8_t>(c - '0');
                            if (c >= 'a' && c <= 'f') return static_cast<uint8_t>(c - 'a' + 10);
                            return static_cast<uint8_t>(c - 'A' + 10);
                        };
                        value.push_back(static_cast<uint8_t>((digit(hex[i]) << 4) | digit(hex[i + 1])));
                    }
                    keys_.emplace(normalized, KeyRecord{name, std::move(value)});
                    found_valid_line = true;
                }
            }
            if (end == std::string::npos) break;
            begin = end + 1;
        }
    }
    keys_ready_ = found_valid_line && found_prod_file;
    if (!keys_ready_) return core::Result<void>::Error("prod.keys is missing or contains no valid key entries");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeStorage::refresh_firmware_state() {
    if (!configured_) return core::Result<void>::Error("runtime storage is not configured");
    std::error_code ec;
    const fs::path root = fs::path(config_.nand_root) / "system";
    firmware_ready_ = fs::is_directory(root, ec) && !ec;
    return firmware_ready_ ? core::Result<void>::Ok() : core::Result<void>::Error("nand/system directory is missing");
}

core::Result<void> RuntimeStorage::validate_for_secure_content() const {
    if (!configured_) return core::Result<void>::Error("runtime storage is not configured");
    if (!keys_ready_) return core::Result<void>::Error("runtime keys are not loaded");
    const fs::path system(config_.nand_root);
    std::error_code ec;
    if (!fs::is_directory(system, ec)) return core::Result<void>::Error("nand directory is missing");
    const fs::path system_root = system / "system";
    if (!fs::is_directory(system_root, ec)) return core::Result<void>::Error("nand/system directory is missing");
    return core::Result<void>::Ok();
}

bool RuntimeStorage::has_key(const std::string& normalized_name) const noexcept {
    return keys_.find(normalize_key_name(normalized_name)) != keys_.end();
}

const KeyRecord* RuntimeStorage::find_key(const std::string& normalized_name) const noexcept {
    const auto it = keys_.find(normalize_key_name(normalized_name));
    return it == keys_.end() ? nullptr : &it->second;
}

std::string RuntimeStorage::normalize_key_name(std::string name) {
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return name;
}

std::string RuntimeStorage::diagnostics() const {
    std::ostringstream out;
    out << "storage=" << (configured_ ? "configured" : "unconfigured")
        << ";keys=" << (keys_ready_ ? "ready" : "missing")
        << ";keyCount=" << keys_.size()
        << ";firmware=" << (firmware_ready_ ? "ready" : "missing")
        << ";keysRoot=" << (configured_ ? config_.keys_root : "")
        << ";nandRoot=" << (configured_ ? config_.nand_root : "");
    return out.str();
}

} // namespace lg::runtime
