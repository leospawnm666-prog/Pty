#include "runtime_coordinator.h"

#include "../cpu/dynarmic_provider.h"
#include "../loader/content_loader.h"
#include "../loader/nca_loader.h"
#include "../loader/nso_loader.h"
#include "../loader/nro_loader.h"
#include "../system/filesystem_service.h"
#include "../system/info_services.h"
#include "../system/lm_service.h"
#include "../system/hid_service.h"
#include "../system/audout_service.h"
#include "../system/pl_service.h"
#include "../system/psm_service.h"
#include "../system/vi_service.h"
#include "../system/nvdrv_service.h"
#include "../system/hl_services.h"
#include "../system/hle/hle_services.h"
#include "../system/hle/hle_content.h"
#include "../system/hle/hle_hid_shm.h"
#include "../loader/romfs.h"
#include "guest_report.h"
#include "../memory/guest_memory_budget.h"

#include <limits>
#include <algorithm>
#include <cctype>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <filesystem>
#include <vector>
#include <span>

namespace lg::runtime {
namespace {
constexpr uint64_t kGuestBase = 0x10000000ull;
// Size of the guest arena before P2 phase D. Now the floor of the RAM-based budget
// (memory/guest_memory_budget.h) and the last-resort size if commits are refused.
constexpr uint64_t kGuestSize = 16ull * 1024 * 1024;
constexpr uint64_t kDefaultQuantum = 64;
// P3.6 (P3_6_DISENO.md §2.1, D-P3.6-1): base quantum of a native process's guest threads.
// The guest clock is host time, so a longer turn does not change guest time; it only sets how
// often the single host thread alternates between virtual cores (~10 us JIT, ~75 us Block).
constexpr uint64_t kNativeQuantumJit = 8192;
constexpr uint64_t kNativeQuantumInterpreter = 2048;
constexpr uint8_t kMainPriority = 64;

core::Result<void> execute_guest_state(cpu::Interpreter& cpu, cpu::CpuState& state) {
    if (!cpu.step(state)) return core::Result<void>::Error("guest thread fault");
    return core::Result<void>::Ok();
}

const char* state_name(State state) noexcept {
    switch (state) {
        case State::Cold: return "COLD";
        case State::Preparing: return "PREPARING";
        case State::Ready: return "READY";
        case State::Running: return "RUNNING";
        case State::Paused: return "PAUSED";
        case State::Recovering: return "RECOVERING";
        case State::Stopped: return "STOPPED";
        case State::Error: return "ERROR";
    }
    return "UNKNOWN";
}
} // namespace

core::Result<void> InterpreterBackend::execute(uint64_t guest_pc) {
    state_.pc = guest_pc;
    if (!cpu_.step(state_)) return core::Result<void>::Error("interpreter fault");
    return core::Result<void>::Ok();
}

RuntimeCoordinator::RuntimeCoordinator()
    : shader_cache_("shader_cache"), watchdog_(std::chrono::milliseconds(500)), svc_(memory_, mmu_), vm_(memory_, mmu_) {
    auto interpreter = std::make_unique<InterpreterBackend>(memory_, mmu_);
    interpreter_backend_ = interpreter.get();
    backends_.add(std::move(interpreter));

    auto block = std::make_unique<cpu::BlockBackend>(memory_, mmu_, kDefaultQuantum);
    block_backend_ = block.get();
    backends_.add(std::move(block));

    auto provider = cpu::make_dynarmic_provider(memory_, mmu_, interpreter_backend_->interpreter());
    if (provider) {
        auto jit = std::make_unique<cpu::JitBackend>(std::move(provider));
        jit_backend_ = jit.get();
        backends_.add(std::move(jit));
    }
}

State RuntimeCoordinator::state() const noexcept {
    std::lock_guard lock(mutex_);
    return state_;
}

core::Result<void> RuntimeCoordinator::configure_storage(RuntimeStorageConfig config) {
    std::lock_guard lock(mutex_);
    return storage_.configure(std::move(config));
}

RuntimeMetrics RuntimeCoordinator::metrics() const {
    std::lock_guard lock(mutex_);
    return metrics_;
}

uint64_t RuntimeCoordinator::entry_point() const noexcept {
    std::lock_guard lock(mutex_);
    return entry_point_;
}

std::string RuntimeCoordinator::title_id() const {
    std::lock_guard lock(mutex_);
    return title_id_;
}

const system::ProcessManager::Process* RuntimeCoordinator::process() const noexcept {
    std::lock_guard lock(mutex_);
    return kernel_.processes().current();
}

const char* RuntimeCoordinator::cpu_backend_name() const noexcept {
    std::lock_guard lock(mutex_);
    return backend_ ? backend_->name() : "none";
}

bool RuntimeCoordinator::transition(State expected, State next) noexcept {
    if (state_ != expected) return false;
    state_ = next;
    return true;
}

core::Result<void> RuntimeCoordinator::fail(const char* message) {
    last_error_ = (message && *message) ? message : "unknown runtime error";
    state_ = State::Error;
    return core::Result<void>::Error(last_error_.c_str());
}

void RuntimeCoordinator::reset_runtime_state() noexcept {
    // P3.3: the guest kernel's threads go first (they point at the handles, the memory and
    // the kernel's ThreadManager/contexts, all cleared below).
    // P3.5: guest_summary() keeps the counts of the session that ends, like the guest log.
    if (kthreads_.active()) {
        // ExitProcess ends every thread of the process, even those the kernel still lists.
        ended_counts_.live_threads = svc_.exit().exited ? 0 : kthreads_.live_count();
        ended_counts_.total_threads = kthreads_.object_count();
    }
    if (kipc_.active()) ended_counts_.ipc_requests = kipc_.request_count();
    kobjects_.reset();   // P6.0: before what it points at
    kipc_.reset();   // P3.4: before the kernel threads it points at
    kthreads_.reset();
    gpu_.shutdown();
    if (jit_backend_) jit_backend_->invalidate_all();
    if (interpreter_backend_) interpreter_backend_->interpreter().clear_decode_cache();
    if (block_backend_) block_backend_->clear();
    mmu_.clear();
    memory_.clear();
    if (main_process_) kernel_.processes().stop(main_process_);
    kernel_.reset();
    main_thread_ = 0;
    main_process_ = 0;
    entry_point_ = 0;
    title_id_.clear();
    backend_ = nullptr;
    // P3.0: engines stop pointing at the clock before it is destroyed.
    install_guest_clock(nullptr);
    guest_clock_.reset();
    image_kind_ = ImageKind::None;
    layout_.reset();
    last_fault_ = {};
    idle_skips_ = 0;
    native_quantum_ = kDefaultQuantum;   // P3.6
    // P3.1: the handles die with the kernel objects; the guest log, the SVC counters and the
    // exit record stay readable until the next prepare().
    svc_.end_session();
    vm_.reset();   // P3.2 (the Mmu itself is cleared above)
    program_id_ = 0;
    main_thread_handle_ = 0;
    guest_exit_pending_ = false;
    svc_fatal_.clear();
}

void RuntimeCoordinator::install_guest_clock(const cpu::GuestClock* clock) noexcept {
    if (interpreter_backend_) interpreter_backend_->interpreter().set_guest_clock(clock);   // also the JIT's fallback
    if (block_backend_) block_backend_->interpreter().set_guest_clock(clock);
    if (jit_backend_) jit_backend_->set_guest_clock(clock);
}

void RuntimeCoordinator::record_guest_fault(uint64_t thread, const cpu::CpuState& ctx) noexcept {
    last_fault_ = {ctx.exception.kind, ctx.exception.address, ctx.exception.syndrome, thread, ctx.x[0], ctx.x[1], ctx.pc, ctx.x[30]};
    // P3.5: the engine and, for an undefined instruction, its word (the JIT does not report it).
    last_fault_.on_interpreter = !(jit_backend_ && backend_ == jit_backend_);
    if (ctx.exception.kind == cpu::ExceptionKind::UndefinedInstruction) {
        const auto t = mmu_.translate(ctx.exception.address, false, false);
        const auto w = t.ok() ? memory_.read32(t.value().physical) : std::nullopt;
        if (w) { last_fault_.insn = *w; last_fault_.insn_valid = true; }
    }
}

core::Result<void> RuntimeCoordinator::prepare() {
    return prepare(std::string{});
}

core::Result<void> RuntimeCoordinator::prepare(const std::string& content_path) {
    std::lock_guard lock(mutex_);
    if (state_ != State::Cold && state_ != State::Stopped)
        return core::Result<void>::Error("runtime is not Cold/Stopped");

    reset_runtime_state();
    state_ = State::Preparing;
    metrics_ = {};
    last_error_.clear();
    // P3.0 (D1): one host-time guest clock per session, shared by every engine.
    guest_clock_ = std::make_unique<cpu::GuestClock>();
    install_guest_clock(guest_clock_.get());
    svc_.begin_session({});   // P3.1: a new session starts with an empty guest log / counters
    ended_counts_ = {};       // P3.5
    svc_continuations_ = 0;   // P3.6: like the SVC counters, readable after the guest exits
    idle_waits_ = 0;          // P3.3: like the SVC counters, readable after the guest exits
    content_path_ = content_path;
    system::hle::process_content().clear();
    system::hle::clear_active_hid_shared_id();
    maxwell_shaders_.clear();
    guest_gpu_.reset();
    gpu_cmds_.reset();

    auto session_result = session_.prepare();
    if (!session_result.ok()) return fail(session_result.error().c_str());

    if (auto r = prepare_memory(); !r.ok()) return fail(r.error().c_str());
    if (!content_path.empty()) {
        const auto info = loader::ContentLoader::inspect(content_path);
        if (info.secure_container) {
            if (auto r = storage_.load_key_material(); !r.ok()) return fail(r.error().c_str());
            if (auto r = storage_.refresh_firmware_state(); !r.ok()) return fail(r.error().c_str());
            if (auto r = storage_.validate_for_secure_content(); !r.ok()) return fail(r.error().c_str());
        }
    }
    if (auto r = load_content(content_path); !r.ok()) return fail(r.error().c_str());
    if (auto r = initialize_services(); !r.ok()) return fail(r.error().c_str());
    if (auto r = initialize_backends(); !r.ok()) return fail(r.error().c_str());
    if (auto r = setup_process_memory(); !r.ok()) return fail(r.error().c_str());   // P3.2
    if (auto r = setup_kernel_threads(); !r.ok()) return fail(r.error().c_str());   // P3.3
    // P3.1: what the SVCs answer in this session.
    svc_.begin_session({main_process_, program_id_,
                        layout_ && image_kind_ == ImageKind::NativeNro ? layout_->exit_stub_va : 0,
                        guest_clock_.get(), system::SvcDispatcher::fresh_entropy(),
                        vm_.active() ? &vm_ : nullptr,
                        kthreads_.active() ? &kthreads_ : nullptr,
                        kipc_.active() ? &kipc_ : nullptr,
                        kobjects_.active() ? &kobjects_ : nullptr,
                        // P6.0 (D-P6.0-6): an NCA/NSO is the application; a homebrew NRO runs
                        // as hbloader's process (application_type 2 in hbl.json)
                        image_kind_ == ImageKind::Nca || image_kind_ == ImageKind::NativeNso});
    if (auto r = create_main_thread(); !r.ok()) return fail(r.error().c_str());

    last_progress_ = std::chrono::steady_clock::now();
    state_ = State::Ready;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::prepare_memory() {
    // P2 phase D: the arena is sized from the device's RAM (or the override), reserved
    // without commit, and committed by map(). If the kernel refuses the commit, retry at
    // half the size down to the pre-phase-D 16 MiB instead of failing the session.
    uint64_t size = guest_memory_override_ ? guest_memory_override_
                                           : memory::guest_memory_budget(memory::physical_ram_bytes());
    size = std::clamp<uint64_t>(size & ~(memory::Mmu::PageSize - 1), kGuestSize, memory::kGuestMemoryMax);
    // P2 phase E.2b: a memfd-backed (Shared) arena when the JIT may use fastmem; falls
    // back to the phase D Private arena if the Shared one cannot be created.
    const bool shared = jit_fastmem_ && jit_backend_ != nullptr && !force_interpreter_;
    for (;;) {
        bool ok = shared && memory_.enable_fastmem(size, kGuestBase, memory::AddressSpace::ArenaBacking::Shared);
        if (!ok) ok = memory_.enable_fastmem(size, kGuestBase);
        if (!ok) return core::Result<void>::Error("failed to create fastmem guest arena");
        if (memory_.map(kGuestBase, size)) break;
        if (size <= kGuestSize) return core::Result<void>::Error("failed to create guest memory");
        size = std::max<uint64_t>(size / 2 & ~(memory::Mmu::PageSize - 1), kGuestSize);
    }
    if (!mmu_.map(kGuestBase, kGuestBase, size,
                  memory::Read | memory::Write | memory::Execute | memory::User))
        return core::Result<void>::Error("failed to map guest memory");
    guest_memory_size_ = size;
    return core::Result<void>::Ok();
}

void RuntimeCoordinator::set_jit_fastmem(bool enabled) noexcept {
    std::lock_guard lock(mutex_);
    jit_fastmem_ = enabled;
}

bool RuntimeCoordinator::jit_fastmem() const noexcept {
    std::lock_guard lock(mutex_);
    return jit_fastmem_;
}

void RuntimeCoordinator::set_force_interpreter(bool enabled) noexcept {
    std::lock_guard lock(mutex_);
    force_interpreter_ = enabled;
}

bool RuntimeCoordinator::force_interpreter() const noexcept {
    std::lock_guard lock(mutex_);
    return force_interpreter_;
}

void RuntimeCoordinator::set_guest_memory_budget(uint64_t bytes) noexcept {
    std::lock_guard lock(mutex_);
    guest_memory_override_ = bytes;
}

uint64_t RuntimeCoordinator::guest_memory_size() const noexcept {
    std::lock_guard lock(mutex_);
    return guest_memory_size_;
}

core::Result<void> RuntimeCoordinator::load_content(const std::string& content_path) {
    entry_point_ = 0;
    if (content_path.empty()) return core::Result<void>::Ok();

    const auto info = loader::ContentLoader::inspect(content_path);
    if (!info.valid) return core::Result<void>::Error("game content is invalid or unreadable");
    if (info.format == loader::Format::Nsp || info.format == loader::Format::Xci || info.format == loader::Format::Nca) {
        std::vector<loader::NcaSource> candidates;
        if (info.format == loader::Format::Nca) {
            candidates.push_back({content_path, 0, info.size});
        } else {
            for (const auto& entry : info.entries) {
                if (entry.name.size() < 4) continue;
                auto ext = entry.name.substr(entry.name.size() - 4);
                std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                if (ext == ".nca") candidates.push_back({content_path, entry.offset, entry.size});
            }
        }
        if (candidates.empty()) return core::Result<void>::Error("NSP/XCI no contiene ninguna entrada NCA válida");

        core::Result<loader::NcaImage> program = core::Result<loader::NcaImage>::Error("no Program NCA found");
        std::string last_error;
        for (const auto& candidate : candidates) {
            auto attempt = loader::NcaLoader::load_program(candidate, storage_);
            if (attempt.ok()) { program = std::move(attempt); break; }
            last_error = attempt.error();
        }
        if (!program.ok()) return core::Result<void>::Error((std::string("no se pudo cargar el Program NCA: ") + last_error).c_str());

        if (program.value().program_id != 0 && program.value().program_id != ~uint64_t{0}) {
            std::ostringstream tid;
            tid << std::hex << std::setfill('0') << std::setw(16) << program.value().program_id;
            title_id_ = tid.str();
            program_id_ = program.value().program_id;   // P3.1: GetInfo(ProgramId)
        }

        // HLE fsp-srv: mount RomFS section(s) so OpenDataStorage / OpenFileSystem can serve data.
        system::hle::process_content().clear();
        for (const auto& candidate : candidates) {
            auto insp = loader::NcaLoader::inspect(candidate, storage_);
            if (!insp.ok()) continue;
            const auto& nca = insp.value();
            for (uint8_t si = 0; si < nca.section_count && si < 4; ++si) {
                if (nca.sections[si].fs_type != 0) continue;  // 0 = RomFS
                if (nca.sections[si].size == 0) continue;
                auto sec = loader::NcaLoader::load_section(candidate, si, storage_);
                if (!sec.ok() || sec.value().data.size() < 0x28) continue;
                auto parsed = loader::RomFsImage::parse(sec.value().data);
                if (!parsed.ok()) continue;
                auto img = std::make_shared<loader::RomFsImage>(std::move(parsed.value()));
                system::hle::process_content().set_romfs(std::move(img), std::move(sec.value().data));
                break;
            }
            if (system::hle::process_content().has_romfs()) break;
        }

        // P3.0 (D-A-1): the decrypted main NSO is placed exactly like a plaintext one, in the
        // 36-bit layout of P3.0 (system::build_nso_process). Before, it was mapped at a fixed
        // identity address with NsoLoader::map_into_memory(), which called
        // AddressSpace::map() on an arena prepare_memory() had already mapped: every NCA
        // failed with "failed to map NSO segment" (and the .bss was zeroed byte by byte).
        mmu_.clear();
        auto built = system::build_nso_process(program.value().main_nso, memory_, mmu_,
                                               memory_.fastmem_guest_base(), memory_.fastmem_size());
        if (!built.ok()) return core::Result<void>::Error(built.error().c_str());
        layout_ = built.value();
        image_kind_ = ImageKind::Nca;
        return register_native_process(content_path);
    }
    if (info.format != loader::Format::Nro && info.format != loader::Format::Nso)
        return core::Result<void>::Error("formato de contenido no soportado por el loader");
    if (info.native_nro) {
        if (!info.valid || info.segments.size() != 3)
            return core::Result<void>::Error("NRO real con cabecera inválida");
        const auto& data = info.segments.back();
        return load_native_nro(content_path, data.file_offset + data.file_size);
    }
    if (info.native_nso) {
        if (!info.valid) return core::Result<void>::Error("NSO real con cabecera inválida");
        return load_native_nso(content_path);
    }
    image_kind_ = info.format == loader::Format::Nro ? ImageKind::SyntheticNro : ImageKind::SyntheticNso;

    loader::LoadResult loaded{};
    if (!loader::ContentLoader::load_plaintext(info, memory_, loaded))
        return core::Result<void>::Error("failed to load plaintext game image");

    mmu_.clear();
    constexpr uint64_t page = memory::Mmu::PageSize;
    for (const auto& segment : info.segments) {
        const uint64_t base = segment.load_address & ~memory::Mmu::PageMask;
        const uint64_t end_unaligned = segment.load_address + segment.file_size;
        if (end_unaligned < segment.load_address)
            return core::Result<void>::Error("content segment address overflow");
        if (end_unaligned > std::numeric_limits<uint64_t>::max() - (page - 1))
            return core::Result<void>::Error("content segment alignment overflow");
        const uint64_t end = (end_unaligned + page - 1) & ~memory::Mmu::PageMask;
        if (end <= base || !mmu_.map(base, base, end - base, segment.permissions))
            return core::Result<void>::Error("failed to map executable segment into MMU");
    }

    const uint64_t stack_page =
        (memory_.fastmem_guest_base() + memory_.fastmem_size() - page) & ~memory::Mmu::PageMask;
    if (!mmu_.map(stack_page, stack_page, page, memory::Read | memory::Write | memory::User))
        return core::Result<void>::Error("failed to map guest stack");

    entry_point_ = loaded.entry_point;
    const auto process_id = kernel_.processes().create("main", content_path, loaded.entry_point,
                                                        loaded.image_base, loaded.image_size,
                                                        loaded.segment_count);
    if (!process_id) return core::Result<void>::Error("failed to create guest process");
    main_process_ = process_id;

    if (!kernel_.capabilities().grant(process_id, "svc:system") ||
        !kernel_.capabilities().grant(process_id, "svc:filesystem"))
        return core::Result<void>::Error("failed to initialize process capabilities");
    if (!kernel_.processes().mark_initialized(process_id))
        return core::Result<void>::Error("failed to initialize guest process");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::load_native_nro(const std::string& content_path, uint64_t image_size) {
    // P3.0: a real homebrew NRO, placed like nx-hbloader does (system/process_layout.h).
    if (image_size < loader::NroLoader::kHeaderEnd || image_size > loader::NroLoader::kMaxMappedSize)
        return core::Result<void>::Error("NRO real: tamaño de imagen inválido");
    std::vector<uint8_t> image(static_cast<size_t>(image_size));
    {
        std::ifstream f(content_path, std::ios::binary);
        if (!f || !f.read(reinterpret_cast<char*>(image.data()), static_cast<std::streamsize>(image.size())))
            return core::Result<void>::Error("NRO real: no se pudo leer la imagen");
    }
    const auto parsed = loader::NroLoader::parse(image);   // re-validated: the file may have changed
    if (!parsed.ok()) return core::Result<void>::Error(parsed.error().c_str());
    mmu_.clear();
    auto built = system::build_nro_process(parsed.value(), image, memory_, mmu_,
                                           memory_.fastmem_guest_base(), memory_.fastmem_size());
    if (!built.ok()) return core::Result<void>::Error(built.error().c_str());
    layout_ = built.value();
    image_kind_ = ImageKind::NativeNro;
    return register_native_process(content_path);
}

core::Result<void> RuntimeCoordinator::register_native_process(const std::string& content_path) {
    // P3.0 / P3.0-A: shared tail of the native NRO and NSO paths (layout_ already built).
    entry_point_ = layout_->code_va;
    const auto process_id = kernel_.processes().create("main", content_path, entry_point_, layout_->code_va,
                                                       layout_->mapped_size, 3);
    if (!process_id) return core::Result<void>::Error("failed to create guest process");
    main_process_ = process_id;
    if (!kernel_.capabilities().grant(process_id, "svc:system") ||
        !kernel_.capabilities().grant(process_id, "svc:filesystem"))
        return core::Result<void>::Error("failed to initialize process capabilities");
    if (!kernel_.processes().mark_initialized(process_id)) return core::Result<void>::Error("failed to initialize guest process");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::load_native_nso(const std::string& content_path) {
    // P3.0-A: a real plaintext NSO, in the same 36-bit layout as a native NRO. Entry at the
    // image base with the NSO convention (x0 = 0, x1 = main thread handle; 0 until P3.1).
    std::vector<uint8_t> file;
    if (!loader::ContentLoader::read_file(content_path, file) || file.size() > loader::NsoLoader::kMaxImageSize)
        return core::Result<void>::Error("NSO real: no se pudo leer el archivo");
    const auto parsed = loader::NsoLoader::parse(file);   // re-validated: the file may have changed
    if (!parsed.ok()) return core::Result<void>::Error(parsed.error().c_str());
    mmu_.clear();
    auto built = system::build_nso_process(parsed.value(), memory_, mmu_, memory_.fastmem_guest_base(), memory_.fastmem_size());
    if (!built.ok()) return core::Result<void>::Error(built.error().c_str());
    layout_ = built.value();
    image_kind_ = ImageKind::NativeNso;
    return register_native_process(content_path);
}

core::Result<void> RuntimeCoordinator::initialize_services() {
    if (!kernel_.services().register_service(
            "sm:", system::make_system_service(kernel_.scheduler()), "svc:system"))
        return core::Result<void>::Error("failed to register system service");
    if (!kernel_.services().register_service(
            "fsp-srv:", system::make_filesystem_service(), "svc:filesystem"))
        return core::Result<void>::Error("failed to register filesystem service");

    // PR1 HLE services. This block is deliberately limited to service registration;
    // it does not alter content loading, secure NCA/NSO execution, Vulkan presentation,
    // or frame pacing.
    if (!kernel_.services().register_service("set:sys", system::make_set_sys_service(), "svc:system"))
        return core::Result<void>::Error("failed to register set:sys service");
    if (!kernel_.services().register_service("set", system::make_set_service(), "svc:system"))
        return core::Result<void>::Error("failed to register set service");
    if (!kernel_.services().register_service("apm", system::make_apm_service(), "svc:system"))
        return core::Result<void>::Error("failed to register apm service");
    if (!kernel_.services().register_service("time", system::make_time_service(), "svc:system"))
        return core::Result<void>::Error("failed to register time service");
    if (!kernel_.services().register_service("lm", system::make_lm_service(), "svc:system"))
        return core::Result<void>::Error("failed to register lm service");
    if (!kernel_.services().register_service("hid", system::make_hid_service(), "svc:system"))
        return core::Result<void>::Error("failed to register hid service");
    if (!kernel_.services().register_service("audout:u", system::make_audout_service(), "svc:audio"))
        return core::Result<void>::Error("failed to register audout:u service");
    if (!kernel_.services().register_service("audout:a", system::make_audout_service(), "svc:audio"))
        return core::Result<void>::Error("failed to register audout:a service");
    if (!kernel_.services().register_service("pl:u", system::make_pl_service(), "svc:system"))
        return core::Result<void>::Error("failed to register pl:u service");
    if (!kernel_.services().register_service("psm", system::make_psm_service(), "svc:system"))
        return core::Result<void>::Error("failed to register psm service");

    // Shared display state: VI and dispdrv must observe the same DisplayServer.
    auto display_server = system::make_display_server();
    if (!kernel_.services().register_service("vi:u", system::make_vi_service(display_server), "svc:system"))
        return core::Result<void>::Error("failed to register vi service");
    if (!kernel_.services().register_service("dispdrv", system::make_dispdrv_service(display_server), "svc:system"))
        return core::Result<void>::Error("failed to register dispdrv service");
    if (!kernel_.services().register_service("nvdrv", system::make_nvdrv_service(), "svc:system"))
        return core::Result<void>::Error("failed to register nvdrv service");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::initialize_backends() {
    auto gpu_result = gpu_.initialize();
    if (!gpu_result.ok()) gpu_.shutdown(); // GPU remains optional until Android surface attachment.

    if (auto r = interpreter_backend_->initialize(); !r.ok()) return r;
    if (auto r = block_backend_->initialize(); !r.ok()) return r;
    bool jit_available = false;
    if (jit_backend_ && !force_interpreter_) {
        const auto jit_result = jit_backend_->initialize();
        jit_available = jit_result.ok() && jit_backend_->available();
    }
    backend_ = backends_.select_best(jit_available);
    if (!backend_) return core::Result<void>::Error("no CPU backend");

    metrics_.mmu_ready = true;
    metrics_.gpu_ready = gpu_.ready();
    metrics_.shader_cache_ready = true;
    metrics_.cpu_backend = backend_->name();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::create_main_thread() {
    if (!entry_point_ && main_process_)
        return core::Result<void>::Error("game image has no entry point");

    if (layout_) {
        // P3.0 layout; P3.1 entry ABI (setup_entry_abi): nx-hbloader's for an NRO, Horizon's
        // for an NSO/NCA.
        auto r = create_guest_thread("main", system::hz_to_lobo_priority(system::ProcessLayout::kMainThreadPriorityHz),
                                     layout_->code_va, layout_->stack_top_va);
        if (!r.ok()) return r;
        auto* ctx = kernel_.contexts().get(main_thread_);
        if (!ctx) return core::Result<void>::Error("failed to create guest CPU context");
        ctx->tpidrro_el0 = layout_->tls_va;
        const auto handle = svc_.handles().add({system::KObjectType::Thread, main_thread_});
        if (!handle) return core::Result<void>::Error("failed to create the main thread handle");
        main_thread_handle_ = *handle;
        // P3.3: the main thread enters the guest kernel (Horizon priority, core 0, its TLS).
        if (kthreads_.active() &&
            !kthreads_.register_main_thread(main_thread_, main_thread_handle_,
                                            system::ProcessLayout::kMainThreadPriorityHz, layout_->tls_va))
            return core::Result<void>::Error("failed to register the main thread in the guest kernel");
        return setup_entry_abi(*ctx, content_path_);
    }
    const uint64_t pc = entry_point_ ? entry_point_ : kGuestBase;
    const uint64_t sp = memory_.fastmem_guest_base() + memory_.fastmem_size() - 16;
    auto r = create_guest_thread("main", kMainPriority, pc, sp);
    if (!r.ok()) return r;
    // P3.1: the synthetic formats keep their registers; the handle exists for the SVCs.
    if (const auto handle = svc_.handles().add({system::KObjectType::Thread, main_thread_})) main_thread_handle_ = *handle;
    return r;
}

core::Result<void> RuntimeCoordinator::setup_process_memory() {
    // P3.2 (P3_2_DISENO.md §2.1): the memory manager takes over the P3.0 map. Synthetic
    // images keep their identity map and no manager (their memory SVCs are fatal).
    vm_.reset();
    if (!layout_) return core::Result<void>::Ok();
    using system::ProcessLayout;
    namespace km = system::kmem;
    const uint64_t arena_base = memory_.fastmem_guest_base(), arena_size = memory_.fastmem_size();
    system::VmConfig c{};
    c.space_begin = ProcessLayout::kAslrBase;
    c.space_end = ProcessLayout::kAslrEnd;
    c.heap_base = ProcessLayout::kHeapRegion;
    c.heap_size = ProcessLayout::kHeapRegionSize;
    c.alias_base = ProcessLayout::kAliasRegion;
    c.alias_size = ProcessLayout::kAliasRegionSize;
    c.stack_base = ProcessLayout::kStackRegion;
    c.stack_size = ProcessLayout::kStackRegionSize;
    c.arena_free_base = arena_base + layout_->arena_used;
    c.arena_free_size = arena_size > layout_->arena_used ? arena_size - layout_->arena_used : 0;
    c.total_memory = arena_size;                               // D-P3.2-1
    c.static_used = layout_->arena_used;
    if (!vm_.begin(c)) return core::Result<void>::Error("process memory: invalid configuration");
    // D-P3.2-2: a homebrew NRO is mapped like hbloader maps it (AliasCode*), an NSO/NCA like
    // Horizon's loader (Code*).
    const bool nro = image_kind_ == ImageKind::NativeNro;
    constexpr uint64_t page = km::PageSize;
    for (const auto& region : layout_->image_regions) {
        if (region.size == 0) continue;
        const bool writable = region.perms & memory::Write;
        const uint32_t state = writable ? (nro ? km::AliasCodeData : km::CodeData) : (nro ? km::AliasCode : km::Code);
        const uint32_t perm = writable ? km::PermRW : ((region.perms & memory::Execute) ? km::PermRX : km::PermR);
        const uint64_t size = (region.size + page - 1) & ~(page - 1);
        if (!vm_.seed(layout_->code_va + region.offset, size, state, perm))
            return core::Result<void>::Error("process memory: failed to register an image segment");
    }
    const struct { uint64_t va, size; uint32_t state, perm; } fixed[] = {
        {layout_->stack_bottom_va, ProcessLayout::kMainStackSize, km::Stack, km::PermRW},
        {layout_->tls_va, ProcessLayout::kTlsPageSize, km::ThreadLocal, km::PermRW},
        {layout_->exit_stub_va, ProcessLayout::kSmallPageSize, km::Code, km::PermRX},
        {layout_->config_va, ProcessLayout::kSmallPageSize, km::CodeData, km::PermRW},
    };
    for (const auto& f : fixed)
        if (!vm_.seed(f.va, f.size, f.state, f.perm))
            return core::Result<void>::Error("process memory: failed to register the process pages");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::setup_kernel_threads() {
    // P3.3 (P3_3_DISENO.md §2): threads and synchronization for the processes with a real
    // memory map (native NRO/NSO and NCA). Synthetic images keep the P3.0 dispatch.
    kthreads_.reset();
    if (!vm_.active() || !layout_) return core::Result<void>::Ok();
    system::KernelThreadsConfig c{};
    c.process_id = main_process_;
    c.core_mask = system::SvcDispatcher::kCoreMask;
    c.priority_mask = system::SvcDispatcher::kPriorityMask;
    c.ideal_core = 0;                                                   // hbl.json default_cpu_id
    // New TLS pages go to the stack region after the process pages (config page + 64 KiB).
    c.tls_region_base = system::ProcessLayout::kConfigVa + 0x20000;
    c.tls_region_end = system::ProcessLayout::kStackRegion + system::ProcessLayout::kStackRegionSize;
    c.clock = guest_clock_.get();
    c.handles = &svc_.handles();
    c.memory = &svc_.guest_memory();
    c.vm = &vm_;
    c.threads = &kernel_.threads();
    c.contexts = &kernel_.contexts();
    c.host.spawn = [this](uint64_t pc, uint64_t sp) -> uint64_t {
        // The kernel then fills the context (x0, TLS, FPCR/FPSR) and keeps it Blocked.
        return spawn_guest_thread("guest", system::hz_to_lobo_priority(system::ProcessLayout::kMainThreadPriorityHz), pc, sp);
    };
    if (!kthreads_.begin(c)) return core::Result<void>::Error("guest kernel: invalid thread configuration");
    // P3.6: longer turns for native processes (the ThreadManager keeps its old limits for the
    // synthetic images; reset_runtime_state() -> kernel_.reset() restores them).
    native_quantum_ = (jit_backend_ && backend_ == jit_backend_) ? kNativeQuantumJit : kNativeQuantumInterpreter;
    kernel_.threads().set_quantum_limits(system::ThreadManager::kDefaultQuantumMin, 2 * native_quantum_);
    // P3.4 (P3_4_DISENO.md): IPC and the boot services (sm:, time:u, fsp-srv).
    system::KernelIpcConfig ic{};
    ic.process_id = main_process_;
    ic.clock = guest_clock_.get();
    ic.handles = &svc_.handles();
    ic.memory = &svc_.guest_memory();
    ic.vm = &vm_;
    ic.kthreads = &kthreads_;
    ic.wall_clock_base = std::chrono::duration_cast<std::chrono::seconds>(
                             std::chrono::system_clock::now().time_since_epoch()).count();   // D-P3.4-5
    // P6.0 (guest IPC): a message's copy handles take references in their owners
    ic.retain = [this](const system::KObjectRef& o) {
        return kthreads_.add_handle_ref(o) || kipc_.add_handle_ref(o) || (kobjects_.active() && kobjects_.add_ref(o)) ||
               o.type == system::KObjectType::Process;
    };
    ic.release = [this](const system::KObjectRef& o) {
        kthreads_.on_handle_closed(o);
        kipc_.on_handle_closed(o);
        if (kobjects_.active()) kobjects_.on_handle_closed(o);
    };
    ic.reserve_session = [this] { return !kobjects_.active() || kobjects_.process_limit_free(system::LimitableResource::SessionCountMax) > 0; };
    ic.reserve_event = [this] { return !kobjects_.active() || kobjects_.process_limit_free(system::LimitableResource::EventCountMax) > 0; };
    ic.create_host_shared = [this](uint64_t size) -> uint64_t {
        if (!kobjects_.active()) return 0;
        return kobjects_.create_host_shared_memory(size, system::KernelObjects::PermRW);
    };
    kipc_.reset();
    if (!kipc_.begin(ic) || !system::hle::register_boot_services(kipc_))
        return core::Result<void>::Error("guest kernel: IPC setup failed");
    kthreads_.set_sync_provider({[this](uint32_t h) { return kipc_.sync_object_of(h); },
                                 [this](uint64_t id) { return kipc_.sync_signaled(id); },
                                 [this](uint64_t tid) { kipc_.on_wait_ended(tid); }});
    // P6.0 (P6_DISENO.md §3.1): memory objects and the process's resource limit (D-P6.0-4: its
    // limits are the emulator's capacities: arena, kernel threads, handles, sessions).
    system::KernelObjectsConfig oc{};
    oc.process_id = main_process_;
    oc.handles = &svc_.handles();
    oc.vm = &vm_;
    oc.memory = &memory_;
    oc.limits = {static_cast<int64_t>(vm_.total_memory()), static_cast<int64_t>(system::kMaxThreads),
                 static_cast<int64_t>(system::HandleTable::kCapacity), 128,
                 static_cast<int64_t>(system::HandleTable::kCapacity)};
    oc.current_count = [this](system::LimitableResource r) -> int64_t {
        switch (r) {
            case system::LimitableResource::PhysicalMemoryMax: return static_cast<int64_t>(vm_.used_memory());
            case system::LimitableResource::ThreadCountMax: return static_cast<int64_t>(kthreads_.live_count());
            case system::LimitableResource::EventCountMax: return static_cast<int64_t>(kthreads_.event_count());
            case system::LimitableResource::SessionCountMax: return static_cast<int64_t>(kipc_.session_count());
            default: return 0;
        }
    };
    kobjects_.reset();
    if (!kobjects_.begin(oc)) return core::Result<void>::Error("guest kernel: kernel objects setup failed");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::setup_entry_abi(cpu::CpuState& ctx, const std::string& content_path) {
    // P3.1 (P3_1_DISENO.md §2.6).
    if (image_kind_ != ImageKind::NativeNro) {
        // Horizon's convention for an NSO (plain or from an NCA): x0 = 0, x1 = main thread handle.
        ctx.x[0] = 0;
        ctx.x[1] = main_thread_handle_;
        return core::Result<void>::Ok();
    }
    // nx-hbloader's convention: x0 = ConfigEntry list, x1 = -1, x30 = loader return address
    // (Lobo's exit stub: returning from main lands on "svc #0x07" with x0 = exit code).
    // ConfigEntry = {u32 Key; u32 Flags; u64 Value[2]} (libnx env.h). No entry is mandatory.
    constexpr uint64_t kLoaderInfoOffset = 0x300, kArgvOffset = 0x400, kArgvMax = 0x400;
    static const char kLoaderInfo[] = "Lobo Gelido P3.1";
    std::string argv = std::filesystem::path(content_path).filename().string();
    if (!content_display_name_.empty()) argv = content_display_name_;   // P3.5: the user's file name
    if (argv.empty()) argv = "main.nro";
    if (argv.find_first_of(" \t\"") != std::string::npos) {   // libnx splits argv on blanks; quotes group
        argv.erase(std::remove(argv.begin(), argv.end(), '"'), argv.end());
        argv = "\"" + argv + "\"";
    }
    if (argv.size() > kArgvMax - 1) argv.resize(kArgvMax - 1);
    const uint64_t page = layout_->config_va;
    struct Entry { uint32_t key; uint64_t v0, v1; };
    const Entry entries[] = {
        {1, main_thread_handle_, 0},                                     // MainThreadHandle
        {7, static_cast<uint64_t>(int64_t{-2}), 0},                       // AppletType = AppletType_None
        {16, 0x00050100u, 0},                                            // HosVersion 5.1.0 (D2)
        {6, system::syscall_hint_word(0), system::syscall_hint_word(1)},   // SyscallAvailableHint
        {17, system::syscall_hint_word(2), 0},                           // SyscallAvailableHint2
        {5, 0, page + kArgvOffset},                                      // Argv
        {0, page + kLoaderInfoOffset, sizeof kLoaderInfo - 1},           // EndOfList (+ loader info)
    };
    std::vector<uint8_t> blob(kArgvOffset + argv.size() + 1, 0);
    auto put32 = [&](size_t o, uint32_t v) { for (int i = 0; i < 4; ++i) blob[o + i] = static_cast<uint8_t>(v >> (8 * i)); };
    auto put64 = [&](size_t o, uint64_t v) { put32(o, static_cast<uint32_t>(v)); put32(o + 4, static_cast<uint32_t>(v >> 32)); };
    size_t at = 0;
    for (const auto& e : entries) { put32(at, e.key); put32(at + 4, 0); put64(at + 8, e.v0); put64(at + 16, e.v1); at += 24; }
    std::copy(kLoaderInfo, kLoaderInfo + sizeof kLoaderInfo, blob.begin() + kLoaderInfoOffset);
    std::copy(argv.begin(), argv.end(), blob.begin() + kArgvOffset);
    if (!svc_.guest_memory().write(page, blob.data(), blob.size()))
        return core::Result<void>::Error("failed to write the homebrew configuration page");
    ctx.x[0] = page;
    ctx.x[1] = ~uint64_t{0};
    ctx.x[30] = layout_->exit_stub_va;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::start() {
    std::lock_guard lock(mutex_);
    if (!transition(State::Ready, State::Running))
        return core::Result<void>::Error("runtime is not Ready");

    auto result = session_.start();
    if (!result.ok()) { state_ = State::Error; return result; }
    if (main_process_ && !kernel_.processes().start(main_process_))
        return fail("failed to start guest process");

    last_progress_ = std::chrono::steady_clock::now();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::pause() {
    std::lock_guard lock(mutex_);
    if (!transition(State::Running, State::Paused))
        return core::Result<void>::Error("runtime is not Running");
    auto result = session_.pause();
    if (!result.ok()) { state_ = State::Running; return result; }
    if (guest_clock_) guest_clock_->pause();   // P3.0: guest time does not advance while paused
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::resume() {
    std::lock_guard lock(mutex_);
    if (!transition(State::Paused, State::Running))
        return core::Result<void>::Error("runtime is not Paused");
    auto result = session_.resume();
    if (!result.ok()) { state_ = State::Paused; return result; }
    if (guest_clock_) guest_clock_->resume();
    last_progress_ = std::chrono::steady_clock::now();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::stop() {
    std::lock_guard lock(mutex_);
    if (state_ == State::Cold || state_ == State::Stopped) {
        if (state_ == State::Cold) session_.stop();
        state_ = State::Stopped;
        return core::Result<void>::Ok();
    }

    const auto result = session_.stop();
    reset_runtime_state();
    metrics_.mmu_ready = false;
    metrics_.gpu_ready = false;
    metrics_.shader_cache_ready = false;
    state_ = State::Stopped;
    return result;
}


core::Result<uint32_t> RuntimeCoordinator::compile_maxwell_graphics(
    const uint64_t* vertex_code, size_t vertex_words,
    const uint64_t* fragment_code, size_t fragment_words,
    const char* name) {
    std::lock_guard lock(mutex_);
    if (!vertex_code || !fragment_code || vertex_words == 0 || fragment_words == 0)
        return core::Result<uint32_t>::Error("maxwell graphics code is empty");
    std::span<const uint64_t> vs(vertex_code, vertex_words);
    std::span<const uint64_t> fs(fragment_code, fragment_words);
    auto r = maxwell_shaders_.compile_graphics(vs, fs, name ? name : "guest", true);
    if (r.ok()) metrics_.shader_cache_ready = true;
    return r;
}


core::Result<void> RuntimeCoordinator::process_maxwell_pushbuffer(const uint32_t* words, size_t count) {
    std::lock_guard lock(mutex_);
    if (!words || count == 0) return core::Result<void>::Ok();
    pushbuffer_.set_pipeline(&maxwell_shaders_);
    pushbuffer_.reset();
    auto ing = pushbuffer_.ingest_flat(std::span<const uint32_t>(words, count));
    if (!ing.ok()) return core::Result<void>::Error(ing.error().c_str());
    auto ex = pushbuffer_.execute(guest_gpu_, gpu_cmds_);
    if (ex.ok()) metrics_.shader_cache_ready = true;
    return ex;
}

core::Result<void> RuntimeCoordinator::submit_guest_gpu_packets(
    const std::vector<gpu::GuestGpuPacket>& packets) {
    std::lock_guard lock(mutex_);
    if (packets.empty()) return core::Result<void>::Ok();
    auto cmds = guest_gpu_.translate(packets);
    if (!cmds.ok()) return core::Result<void>::Error(cmds.error().c_str());
    return gpu_cmds_.submit(cmds.value());
}

void RuntimeCoordinator::set_frontend_input_mask(uint32_t mask) noexcept {
    frontend_input_mask_.store(mask, std::memory_order_release);
}

void RuntimeCoordinator::set_frontend_analog(int32_t lx, int32_t ly, int32_t rx, int32_t ry) noexcept {
    frontend_lx_.store(lx, std::memory_order_release);
    frontend_ly_.store(ly, std::memory_order_release);
    frontend_rx_.store(rx, std::memory_order_release);
    frontend_ry_.store(ry, std::memory_order_release);
}

core::Result<void> RuntimeCoordinator::run_frame(uint64_t guest_pc) {
    std::lock_guard lock(mutex_);
    if (state_ != State::Running) return core::Result<void>::Error("runtime is not Running");
    if (!backend_) return core::Result<void>::Error("CPU backend unavailable");

    // Input is sampled on the runtime worker, not by the Android UI thread. This
    // avoids taking the coordinator lock from JNI and gives HID a coherent frame snapshot.
    {
        const uint32_t mask = frontend_input_mask_.load(std::memory_order_acquire);
        const int32_t lx = frontend_lx_.load(std::memory_order_acquire);
        const int32_t ly = frontend_ly_.load(std::memory_order_acquire);
        const int32_t rx = frontend_rx_.load(std::memory_order_acquire);
        const int32_t ry = frontend_ry_.load(std::memory_order_acquire);

        // Legacy IpcEndpoint HID (tests / older path)
        if (auto* endpoint = kernel_.services().find("hid")) {
            if (auto* hid = dynamic_cast<system::HidService*>(endpoint)) {
                hid->set_analog(lx, ly, rx, ry);
                // SwitchTouchOverlay action IDs → nn::hid::NpadButton indices.
                constexpr uint32_t action_to_hid[] = {13, 15, 12, 14, 0, 1, 2, 3, 6, 7, 10, 11, 0xFFFFFFFFu, 8, 9};
                for (uint32_t action = 0; action < sizeof(action_to_hid) / sizeof(action_to_hid[0]); ++action) {
                    const uint32_t button = action_to_hid[action];
                    if (button == 0xFFFFFFFFu) continue;
                    hid->set_button(button, (mask & (uint32_t(1) << action)) != 0);
                }
            }
        }

        // CMIF HID shared memory (IAppletResource::GetSharedMemoryHandle)
        system::hle::HidFrontendState st{};
        st.lx = lx; st.ly = ly; st.rx = rx; st.ry = ry;
        constexpr uint32_t action_to_hid[] = {13, 15, 12, 14, 0, 1, 2, 3, 6, 7, 10, 11, 0xFFFFFFFFu, 8, 9};
        for (uint32_t action = 0; action < sizeof(action_to_hid) / sizeof(action_to_hid[0]); ++action) {
            const uint32_t button = action_to_hid[action];
            if (button == 0xFFFFFFFFu || button >= 64) continue;
            if (mask & (uint32_t(1) << action)) st.buttons |= (uint64_t{1} << button);
        }
        const uint64_t hid_id = system::hle::active_hid_shared_id();
        if (hid_id != 0 && kobjects_.active())
            (void)system::hle::write_hid_shared_memory(kobjects_, hid_id, st);
    }

    const auto begin = std::chrono::steady_clock::now();
    if (watchdog_.expired(last_progress_)) {
        state_ = State::Recovering;
        ++metrics_.recoveries;
        if (interpreter_backend_) interpreter_backend_->interpreter().clear_decode_cache();
        if (block_backend_) block_backend_->clear();
        if (jit_backend_) jit_backend_->invalidate_all();
        mmu_.invalidate_all();
        last_progress_ = std::chrono::steady_clock::now();
        state_ = State::Running;
    }

    const bool kernel_cores = main_thread_ && kthreads_.active();   // P3.3: native processes
    if (kernel_cores) {
        bool idle = false;
        if (auto r = run_virtual_cores(idle); !r.ok()) {
            ++metrics_.faults;
            return fail(r.error().c_str());
        }
        if (!svc_fatal_.empty()) {
            ++metrics_.faults;
            const std::string msg = std::move(svc_fatal_);
            svc_fatal_.clear();
            return fail(msg.c_str());
        }
        if (guest_exit_pending_) {
            ++metrics_.frames;
            finish_guest_exit();
            return core::Result<void>::Ok();
        }
        if (idle) {
            // Every core idle until a timeout: nothing to run (the worker sleeps until it).
            ++idle_waits_;
            last_progress_ = std::chrono::steady_clock::now();
            return core::Result<void>::Ok();
        }
    }
    if (!kernel_cores && main_thread_ && kernel_.threads().runnable_count() == 0 && kernel_.threads().live_count() > 0) {
        // P3.0: nobody is runnable but threads are alive (sleeping/blocked). That is not a
        // fault: jump guest time to the next scheduled event. Without events it is a guest
        // deadlock, reported with every thread's state.
        if (kernel_.scheduler().pending() == 0) {
            ++metrics_.faults;
            const std::string msg = "guest deadlock: no runnable thread and no pending event [" +
                                    kernel_.threads().describe() + "]";
            return fail(msg.c_str());
        }
        kernel_.scheduler().run_until(kernel_.scheduler().next_deadline());
        kernel_.timers().pump(kernel_.scheduler().now());
        metrics_.scheduler_ticks = kernel_.scheduler().now();
        ++idle_skips_;
        last_progress_ = std::chrono::steady_clock::now();
        if (kernel_.threads().runnable_count() == 0) return core::Result<void>::Ok();
    }
    if (kernel_cores) {
        // P3.3: already dispatched by run_virtual_cores().
    } else if (main_thread_) {
        const auto quantum = kernel_.threads().recommended_quantum(main_thread_, kDefaultQuantum);
        if (auto r = dispatch_guest_thread(quantum); !r.ok()) {
            ++metrics_.faults;
            return fail(r.error().c_str());
        }
        // P3.1: outcomes of an SVC serviced in this dispatch.
        if (!svc_fatal_.empty()) {
            ++metrics_.faults;
            const std::string msg = std::move(svc_fatal_);
            svc_fatal_.clear();
            return fail(msg.c_str());
        }
        if (guest_exit_pending_) {
            ++metrics_.frames;
            finish_guest_exit();
            return core::Result<void>::Ok();
        }
    } else if (auto r = backend_->execute(guest_pc); !r.ok()) {
        ++metrics_.faults;
        return fail(r.error().c_str());
    }

    const auto guest_ticks = main_thread_ ? kernel_.threads().last_dispatch_ticks() : kDefaultQuantum;
    const auto now = kernel_.scheduler().now();
    const auto target = now > std::numeric_limits<uint64_t>::max() - guest_ticks
        ? std::numeric_limits<uint64_t>::max() : now + guest_ticks;
    const auto scheduler_run = kernel_.scheduler().run_until(target);
    metrics_.scheduler_ticks = kernel_.scheduler().now();
    metrics_.scheduler_executed += scheduler_run.executed;
    metrics_.scheduler_cancelled += scheduler_run.cancelled;
    metrics_.scheduler_deferred += scheduler_run.budget_exhausted ? 1 : 0;
    metrics_.scheduler_queue_peak = kernel_.scheduler().stats().queue_peak;
    metrics_.scheduler_decisions = kernel_.threads().scheduler_decisions();
    metrics_.scheduler_fairness_rotations = kernel_.threads().fairness_rotations();
    metrics_.scheduler_guest_cpu_ticks = kernel_.threads().total_cpu_ticks();
    kernel_.timers().pump(kernel_.scheduler().now());

    ++metrics_.frames;
    if (jit_backend_ && backend_ == jit_backend_ && jit_backend_->available()) {
        // JIT providers own instruction accounting; P2 E.3 publishes their estimate.
        metrics_.instructions = jit_backend_->instructions();
    } else if (block_backend_) {
        metrics_.instructions = block_backend_->instructions();
    } else if (interpreter_backend_) {
        metrics_.instructions = interpreter_backend_->instruction_count();
    }

    const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - begin).count();
    metrics_.cpu_ns += static_cast<uint64_t>(elapsed);
    metrics_.frame_time_ms = elapsed / 1e6;
    // RuntimeCoordinator measures guest execution time only. Presentation FPS belongs to the presenter.
    metrics_.fps = elapsed ? 1e9 / static_cast<double>(elapsed) : 0.0;
    last_progress_ = std::chrono::steady_clock::now();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::create_guest_thread(
    const char* name, uint8_t priority, uint64_t pc, uint64_t sp) {
    if (!interpreter_backend_) return core::Result<void>::Error("CPU backend unavailable");
    const auto id = spawn_guest_thread(name, priority, pc, sp);
    if (!id) return core::Result<void>::Error("failed to create guest thread");
    if (!main_thread_) main_thread_ = id;
    return core::Result<void>::Ok();
}

uint64_t RuntimeCoordinator::spawn_guest_thread(const char* name, uint8_t priority, uint64_t pc, uint64_t sp) {
    // P3.3: create_guest_thread() without the main-thread bookkeeping; returns the id (0 on
    // failure). Also the host side of svcCreateThread (KernelThreadsConfig::host.spawn).
    if (!interpreter_backend_) return 0;
    const auto id = kernel_.threads().create(name ? name : "guest", priority,
                                             [this](system::ThreadManager::ThreadId tid) { run_guest_turn(tid); });
    if (!id) return 0;
    if (!kernel_.contexts().create(id, pc, sp)) {
        kernel_.threads().terminate(id);
        return 0;
    }
    return id;
}

namespace {
// P3.6 (P3_6_DISENO.md §2.2): SVCs that always end the turn even when they return Continue:
// they create, start or reconfigure threads (priority, cores, activity) or yield.
bool svc_ends_turn(uint32_t id) noexcept {
    switch (id) {
        case 0x08: /* CreateThread */ case 0x09: /* StartThread */ case 0x0B: /* SleepThread (yields) */
        case 0x0D: /* SetThreadPriority */ case 0x0F: /* SetThreadCoreMask */ case 0x32: /* SetThreadActivity */
            return true;
        default:
            return false;
    }
}
constexpr uint64_t kMaxSvcContinuationsPerTurn = 64;   // D-P3.6-2
} // namespace

void RuntimeCoordinator::run_guest_turn(uint64_t tid) {
    // One quantum of guest thread `tid` (the ThreadManager entry of every guest thread).
    // P3.6: for a native process, an SVC that lets the thread go on (and changes nothing in
    // the scheduler) no longer ends the turn: the thread continues with what is left of its
    // quantum, at most kMaxSvcContinuationsPerTurn times.
    auto* ctx = kernel_.contexts().get(tid);
    if (!ctx) return;
    const uint64_t budget = kernel_.threads().active_quantum();
    uint64_t used = 0;
    uint64_t continuations = 0;
    for (;;) {
        const uint64_t slice = budget > used ? budget - used : 1;
        uint64_t segment = 0;
        const auto outcome = run_guest_segment(tid, *ctx, slice, segment);
        used += segment;
        if (outcome != SegmentOutcome::SvcContinue) break;
        if (used >= budget || continuations >= kMaxSvcContinuationsPerTurn) break;
        ++continuations;
        ++svc_continuations_;
    }
    // Without a continuation the ticks were reported exactly as before P3.6. With one, the
    // whole turn is charged: every segment, including the last.
    if (continuations) kernel_.threads().report_current_consumed_ticks(std::max<uint64_t>(1, used));
}

RuntimeCoordinator::SegmentOutcome RuntimeCoordinator::run_guest_segment(uint64_t tid, cpu::CpuState& ctx_ref,
                                                                         uint64_t slice, uint64_t& segment) {
    auto* ctx = &ctx_ref;
    segment = 0;
    core::Result<void> result = core::Result<void>::Ok();
    const uint64_t instructions_before = ctx->instructions;   // P3.1: ticks of an SVC turn
    const bool counts_instructions = !(jit_backend_ && backend_ == jit_backend_);
    if (jit_backend_ && backend_ == jit_backend_) {
        auto r = jit_backend_->execute_state(*ctx, slice);
        if (!r.ok()) { result = core::Result<void>::Error(r.error().c_str()); segment = jit_backend_->last_run_ticks(); }
        else { kernel_.threads().report_current_consumed_ticks(r.value()); segment = r.value(); }
    } else if (block_backend_) {
        auto r = block_backend_->execute_state(*ctx, slice);
        if (!r.ok()) { result = core::Result<void>::Error(r.error().c_str()); segment = ctx->instructions - instructions_before + 1; }
        else { kernel_.threads().report_current_consumed_ticks(r.value()); segment = r.value(); }
    } else {
        result = execute_guest_state(interpreter_backend_->interpreter(), *ctx);
        if (result.ok()) kernel_.threads().report_current_consumed_ticks(1);
        segment = 1;
    }
    segment = std::max<uint64_t>(1, segment);

    if (!result.ok() && ctx->exception.kind == cpu::ExceptionKind::Svc) {
        // P3.6: only a native process (guest kernel), a plain Continue, no change in the
        // scheduler's queues during the SVC and an SVC that does not reconfigure threads.
        const uint64_t sched_before = kthreads_.active() ? kthreads_.scheduled_count() : 0;
        const uint32_t svc_id = ctx->exception.syndrome;
        const bool go_on = handle_svc(tid, *ctx, instructions_before, counts_instructions);   // P3.1
        const bool unchanged = kthreads_.active() && kthreads_.scheduled_count() == sched_before;
        return go_on && unchanged && !svc_ends_turn(svc_id) && !ctx->halted && svc_fatal_.empty() && !guest_exit_pending_
                   ? SegmentOutcome::SvcContinue
                   : SegmentOutcome::End;
    }
    if (!result.ok()) {
        record_guest_fault(tid, *ctx);   // P3.0: diagnostics (last_fault=)
        ctx->halted = true;
        kernel_.threads().terminate(tid);
        // P3.3: an unhandled exception ends a process with guest kernel threads (Horizon
        // terminates it); its other threads must not go on with a half-dead one.
        if (kthreads_.active() && svc_fatal_.empty())
            svc_fatal_ = "guest fault: " + fault_text() + " thread=" + std::to_string(tid);
        return SegmentOutcome::End;
    }
    if (ctx->halted) {
        kernel_.threads().terminate(tid);
        if (kthreads_.active() && svc_fatal_.empty())
            svc_fatal_ = "guest thread halted: thread=" + std::to_string(tid);
    }
    return SegmentOutcome::End;
}

core::Result<void> RuntimeCoordinator::run_virtual_cores(bool& idle) {
    // P3.3 (D-P3.3-1, P3_3_DISENO.md §2.2): one quantum for the chosen thread of each virtual
    // core, 0 -> 1 -> 2, on this single host thread. Timers and the priority-59 rotation are
    // processed before each turn, so a thread woken on one core runs in the same frame.
    idle = false;
    kthreads_.update(guest_clock_->ticks());
    bool ran = false;
    for (int core = 0; core < system::kNumVirtualCores; ++core) {
        system::KThread* t = kthreads_.top(core);
        if (!t) continue;
        const uint64_t id = t->id;
        const auto quantum = kernel_.threads().recommended_quantum(id, native_quantum_);   // P3.6
        const auto before = kernel_.threads().context_switches();
        kthreads_.begin_turn(core, t, guest_clock_->ticks());
        const bool dispatched = kernel_.threads().dispatch(id, quantum);
        kthreads_.end_turn(guest_clock_->ticks());
        if (!dispatched) {
            const std::string msg = "guest kernel: thread " + std::to_string(id) + " of core " + std::to_string(core) +
                                    " is not dispatchable [" + kernel_.threads().describe() + "]";
            return core::Result<void>::Error(msg.c_str());
        }
        const auto after = kernel_.threads().context_switches();
        metrics_.thread_context_switches = after;
        if (after != before) ++metrics_.guest_dispatches;
        ran = true;
        if (!svc_fatal_.empty() || guest_exit_pending_) return core::Result<void>::Ok();
        kthreads_.update(guest_clock_->ticks());
    }
    if (ran) return core::Result<void>::Ok();
    if (kthreads_.next_deadline() != 0) { idle = true; return core::Result<void>::Ok(); }
    // Nobody can run and no timeout can wake anybody (P3_3_DISENO.md §2.6).
    const std::string msg = "guest deadlock: no runnable thread and no pending timeout [" + kthreads_.describe_waits() + "]";
    return core::Result<void>::Error(msg.c_str());
}

bool RuntimeCoordinator::handle_svc(uint64_t thread, cpu::CpuState& ctx, uint64_t instructions_before,
                                    bool report_ticks) {
    // P3.1: the single interception point (audit A1). Runs inside the thread's turn, with the
    // coordinator locked (run_frame -> dispatch_next -> entry).
    const auto out = svc_.handle(thread, ctx);
    using Kind = system::SvcOutcome::Kind;
    switch (out.kind) {
        case Kind::Continue:
            // The SVC ends the thread's turn. The interpreter engines retire a known number of
            // instructions (+1 for the SVC); the JIT's turn is charged the whole quantum, as a
            // fault was before P3.1 (its tick count is not reported on a stop).
            if (report_ticks)
                kernel_.threads().report_current_consumed_ticks(
                    std::max<uint64_t>(1, ctx.instructions - instructions_before + 1));
            return true;
        case Kind::ExitProcess:
            ctx.halted = true;
            kernel_.threads().terminate(thread);
            guest_exit_pending_ = true;   // run_frame closes the session after this dispatch
            return false;
        case Kind::Block:
            // P3.3: the guest kernel already moved the thread to Waiting (ThreadManager
            // Blocked); the SVC ended its turn like a Continue.
            if (kthreads_.active()) {
                if (report_ticks)
                    kernel_.threads().report_current_consumed_ticks(
                        std::max<uint64_t>(1, ctx.instructions - instructions_before + 1));
                return false;
            }
            break;
        case Kind::ExitThread:
            // P3.3: the thread ended (the kernel terminated it); the others go on.
            if (kthreads_.active()) {
                ctx.halted = true;
                return false;
            }
            break;
        case Kind::Fatal:
            break;
    }
    // Fatal, or a P3.3 outcome without the guest kernel (synthetic images; fail closed).
    record_guest_fault(thread, ctx);   // last_fault=svc_0x..@pc
    ctx.halted = true;
    kernel_.threads().terminate(thread);
    svc_fatal_ = out.kind == Kind::Fatal ? out.message : "SVC outcome not supported in P3.1";
    return false;
}

void RuntimeCoordinator::finish_guest_exit() noexcept {
    // P3.1 (D5): the guest ended its process. Same teardown as stop(), then Stopped: a clean
    // end, not an error. guest_exit()/guest_log() keep the result until the next prepare().
    (void)session_.stop();
    reset_runtime_state();
    metrics_.mmu_ready = false;
    metrics_.gpu_ready = false;
    metrics_.shader_cache_ready = false;
    state_ = State::Stopped;
}

core::Result<void> RuntimeCoordinator::dispatch_guest_thread(uint64_t quantum) {
    if (state_ != State::Running) return core::Result<void>::Error("runtime is not Running");
    const auto before = kernel_.threads().context_switches();
    if (!kernel_.threads().dispatch_next(quantum))
        return core::Result<void>::Error("no runnable guest thread");
    const auto after = kernel_.threads().context_switches();
    metrics_.thread_context_switches = after;
    if (after != before) ++metrics_.guest_dispatches;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::recover(const char* reason) {
    std::lock_guard lock(mutex_);
    (void)reason;
    if (state_ != State::Running && state_ != State::Paused)
        return core::Result<void>::Error("runtime is not recoverable in current state");
    const State previous = state_;
    state_ = State::Recovering;
    ++metrics_.recoveries;
    if (interpreter_backend_) interpreter_backend_->interpreter().clear_decode_cache();
    if (block_backend_) block_backend_->clear();
    if (jit_backend_) jit_backend_->invalidate_all();
    mmu_.invalidate_all();
    last_progress_ = std::chrono::steady_clock::now();
    state_ = previous;
    return core::Result<void>::Ok();
}

std::string RuntimeCoordinator::diagnostics() const {
    std::lock_guard lock(mutex_);
    std::ostringstream out;
    out << "Runtime=" << state_name(state_)
        << " CPU=" << (backend_ ? backend_->name() : "none")
        << " JIT=" << (jit_backend_ && jit_backend_->available() ? "provider" : "unavailable")
        << " MMU=" << (metrics_.mmu_ready ? "ready" : "off")
        << " GPU=" << (metrics_.gpu_ready ? "ready" : "off")
        << " shaders=" << (metrics_.shader_cache_ready ? "ready" : "off")
        << " frames=" << metrics_.frames
        << " faults=" << metrics_.faults
        << " recoveries=" << metrics_.recoveries
        << " threads=" << kernel_.threads().size()
        << " switches=" << kernel_.threads().context_switches()
        << " guest_dispatches=" << metrics_.guest_dispatches
        << " blocks=" << (block_backend_ ? block_backend_->block_count() : 0)
        << " block_hits=" << (block_backend_ ? block_backend_->hot_hits() : 0)
        << " title_id=" << (title_id_.empty() ? "none" : title_id_)
        << " entry=0x" << std::hex << entry_point_ << std::dec
        << " guest_mem=" << (guest_memory_size_ >> 20) << "MiB"
        << " arena=" << (memory_.arena_backing() == memory::AddressSpace::ArenaBacking::Shared ? "shared" : "private")
        << " force_interp=" << (force_interpreter_ ? 1 : 0)
        << " instr" << (jit_backend_ && backend_ == jit_backend_ ? "_est=" : "=") << metrics_.instructions
        << " image=" << image_kind_name()
        << " code_va=0x" << std::hex << (layout_ ? layout_->code_va : 0)
        << " tls=0x" << (layout_ ? layout_->tls_va : 0) << std::dec
        << " idle_skips=" << idle_skips_
        << " guest_tick=" << (guest_clock_ ? guest_clock_->ticks() : 0)
        << " last_fault=" << fault_text();
    // P3.1
    const auto& ls = svc_.last();
    out << " svc_calls=" << svc_.total_calls()
        << " last_svc=";
    if (ls.valid) out << "0x" << std::hex << ls.id << "@0x" << ls.pc << std::dec; else out << "none";
    const auto& ex = svc_.exit();
    out << " exit=";
    if (!ex.exited) out << "none";
    else if (ex.has_code) out << "guest code=" << ex.code;
    else out << "guest code=none";
    // P3.3
    if (kthreads_.active()) {
        out << " guest_threads=" << kthreads_.live_count() << '/' << kthreads_.object_count()
            << " cores=[";
        for (int core = 0; core < system::kNumVirtualCores; ++core) {
            if (core) out << ',';
            const system::KThread* t = kthreads_.top(core);
            out << 'c' << core << ':';
            if (t) out << t->id; else out << '-';
        }
        out << "] waits=" << kthreads_.waiting_count() << " timers=" << kthreads_.timer_count()
            << " idle_waits=" << idle_waits_;
    }
    // P3.4
    if (kipc_.active()) {
        out << " ipc=" << kipc_.request_count() << " sessions=" << kipc_.session_count()
            << " domains=" << kipc_.domain_count() << " last_ipc=" << (kipc_.last_request().empty() ? "none" : kipc_.last_request());
    }
    // P3.2
    out << " heap=" << (vm_.heap_size() >> 20) << "MiB"
        << " mem_used=" << (vm_.active() ? vm_.used_memory() >> 20 : 0) << "MiB"
        << " vm_blocks=" << vm_.block_count();
    out << " guest_log=\"" << svc_.log().last_line() << "\""
        << " guest_log_bytes=" << svc_.log().total_bytes()
        << " error=" << (last_error_.empty() ? "none" : last_error_);
    // Production GPU / Maxwell / HLE content / HID SHM
    out << " " << maxwell_shaders_.diagnostics()
        << " " << guest_gpu_.diagnostics()
        << " " << gpu_cmds_.diagnostics()
        << " " << pushbuffer_.diagnostics()
        << " " << system::hle::process_content().diagnostics()
        << " hid_shm=" << system::hle::active_hid_shared_id()
        << " " << system::hle::coverage_summary();
    return out.str();
}

const char* RuntimeCoordinator::image_kind_name() const noexcept {
    switch (image_kind_) {
        case ImageKind::None: return "none";
        case ImageKind::SyntheticNro: return "nro-synthetic";
        case ImageKind::SyntheticNso: return "nso-synthetic";
        case ImageKind::NativeNro: return "nro";
        case ImageKind::Nca: return "nca";
        case ImageKind::NativeNso: return "nso";
    }
    return "unknown";
}

std::string RuntimeCoordinator::fault_text() const {
    using cpu::ExceptionKind;
    const char* kind = "none";
    switch (last_fault_.kind) {
        case ExceptionKind::None: return "none";
        case ExceptionKind::InstructionAbort: kind = "instruction_abort"; break;
        case ExceptionKind::DataAbort: kind = "data_abort"; break;
        case ExceptionKind::UndefinedInstruction: kind = "undefined"; break;
        case ExceptionKind::Alignment: kind = "alignment"; break;
        case ExceptionKind::Svc: kind = "svc"; break;
        case ExceptionKind::Breakpoint: kind = "brk"; break;
        case ExceptionKind::SystemRegister: kind = "sysreg"; break;
        case ExceptionKind::ExclusiveFail: kind = "exclusive"; break;
    }
    std::ostringstream o;
    o << kind << "_0x" << std::hex << last_fault_.syndrome << "@0x" << last_fault_.address;
    if (last_fault_.kind == ExceptionKind::UndefinedInstruction && last_fault_.insn_valid)   // P3.5 (§2.3)
        o << undefined_instruction_note(last_fault_.insn, last_fault_.on_interpreter);
    return o.str();
}

std::optional<system::ProcessLayout> RuntimeCoordinator::process_layout() const {
    std::lock_guard lock(mutex_);
    return layout_;
}

RuntimeCoordinator::GuestFault RuntimeCoordinator::last_guest_fault() const {
    std::lock_guard lock(mutex_);
    return last_fault_;
}

const cpu::GuestClock* RuntimeCoordinator::guest_clock() const noexcept { return guest_clock_.get(); }

uint64_t RuntimeCoordinator::idle_skips() const noexcept {
    std::lock_guard lock(mutex_);
    return idle_skips_;
}

std::optional<uint64_t> RuntimeCoordinator::debug_read_guest64(uint64_t va) const {
    std::lock_guard lock(mutex_);
    const auto t = mmu_.translate(va, false, false);
    if (!t.ok()) return std::nullopt;
    return memory_.read64(t.value().physical);
}

// ---- P3.5 ----------------------------------------------------------------------------
std::string RuntimeCoordinator::guest_summary() const {
    std::lock_guard lock(mutex_);
    GuestSummaryInput in;
    using P = GuestSummaryInput::Phase;
    switch (state_) {
        case State::Cold: case State::Preparing: in.phase = P::None; break;
        case State::Ready: in.phase = P::Ready; break;
        case State::Running: case State::Recovering: in.phase = P::Running; break;
        case State::Paused: in.phase = P::Paused; break;
        case State::Stopped: in.phase = P::Stopped; break;
        case State::Error: in.phase = P::Error; break;
    }
    const auto& ex = svc_.exit();
    in.exited = ex.exited;
    in.has_code = ex.has_code;
    in.code = ex.code;
    in.log = svc_.log().contents();
    in.error = last_error_;
    in.live_threads = ended_counts_.live_threads;
    in.total_threads = ended_counts_.total_threads;
    in.ipc_requests = ended_counts_.ipc_requests;
    if (kthreads_.active()) { in.live_threads = kthreads_.live_count(); in.total_threads = kthreads_.object_count(); }
    if (kipc_.active()) in.ipc_requests = kipc_.request_count();
    in.svc_calls = svc_.total_calls();
    return format_guest_summary(in);
}

void RuntimeCoordinator::set_content_display_name(std::string name) {
    std::lock_guard lock(mutex_);
    // Only the last path component, without control characters, at most 255 bytes.
    const auto slash = name.find_last_of("/\\");
    if (slash != std::string::npos) name.erase(0, slash + 1);
    name.erase(std::remove_if(name.begin(), name.end(), [](char c) { return static_cast<unsigned char>(c) < 0x20; }), name.end());
    content_display_name_ = utf8_truncate(name, 255);
}

uint64_t RuntimeCoordinator::native_quantum() const noexcept {
    std::lock_guard lock(mutex_);
    return native_quantum_;
}

uint64_t RuntimeCoordinator::svc_continuations() const noexcept {
    std::lock_guard lock(mutex_);
    return svc_continuations_;
}

std::string RuntimeCoordinator::content_display_name() const {
    std::lock_guard lock(mutex_);
    return content_display_name_;
}

std::string RuntimeCoordinator::guest_log() const {
    std::lock_guard lock(mutex_);
    return svc_.log().contents();
}

void RuntimeCoordinator::set_guest_log_sink(std::function<void(const std::string&)> sink) {
    std::lock_guard lock(mutex_);
    svc_.set_log_sink(std::move(sink));
}

system::GuestExit RuntimeCoordinator::guest_exit() const {
    std::lock_guard lock(mutex_);
    return svc_.exit();
}

uint64_t RuntimeCoordinator::svc_calls(uint32_t id) const {
    std::lock_guard lock(mutex_);
    return svc_.calls(id);
}

system::SvcRecord RuntimeCoordinator::last_svc() const {
    std::lock_guard lock(mutex_);
    return svc_.last();
}

uint32_t RuntimeCoordinator::main_thread_handle() const {
    std::lock_guard lock(mutex_);
    return main_thread_handle_;
}

uint64_t RuntimeCoordinator::idle_deadline_ns() const {
    std::lock_guard lock(mutex_);
    if (state_ != State::Running || !kthreads_.active() || !guest_clock_) return 0;
    for (int core = 0; core < system::kNumVirtualCores; ++core)
        if (kthreads_.top(core)) return 0;                             // something can run
    const uint64_t deadline = kthreads_.next_deadline();
    if (deadline == 0) return 0;
    const uint64_t now = guest_clock_->ticks();
    if (deadline <= now) return 0;
    return std::max<uint64_t>(1, cpu::GuestClock::ticks_to_ns(deadline - now));
}

uint64_t RuntimeCoordinator::idle_waits() const noexcept {
    std::lock_guard lock(mutex_);
    return idle_waits_;
}

void RuntimeCoordinator::set_manual_guest_clock_for_testing(bool manual) {
    std::lock_guard lock(mutex_);
    if (guest_clock_) guest_clock_->set_manual(manual);
}

void RuntimeCoordinator::advance_guest_clock_for_testing(uint64_t ticks) {
    std::lock_guard lock(mutex_);
    if (guest_clock_) guest_clock_->advance(ticks);
}

std::string RuntimeCoordinator::storage_diagnostics() const {
    std::lock_guard lock(mutex_);
    return storage_.diagnostics();
}

} // namespace lg::runtime
