#pragma once
// P3.5 (P3_5_DISENO.md §2.5, R1): JIT smoke test. Before the first session, a tiny NRO built
// here (no binary blob: the instruction words are listed in jit_smoke.cpp) runs on the JIT in
// its own RuntimeCoordinator. It uses FP, AdvSIMD and SIMD loads/stores - what the interpreter
// lacks - and returns 84 to the loader. The host uses the result to decide whether sessions
// may use the JIT.
//
// A crash of the JIT (a signal, not a guest fault) would take the process down with it. To
// avoid a crash loop, a marker file holding `build_tag` is written before the run and removed
// after it: if the marker of this same build is still there at the next start, the previous
// run died, and the JIT is not tried again until the build changes.
#include <cstdint>
#include <string>
#include <vector>

namespace lg::runtime {

struct JitSmokeResult {
    enum class Status { Ok, Failed, Skipped, CrashedBefore } status{Status::Skipped};
    std::string detail;   // one line: why (empty for Ok)
};
const char* jit_smoke_status_name(JitSmokeResult::Status s) noexcept;   // ok|failed|skipped|crashed_before

/** The smoke NRO (3 pages: text with the program, empty rodata and data). */
std::vector<uint8_t> jit_smoke_nro();
/** Exit code the smoke program returns when FP/AdvSIMD worked (2 * 42). */
constexpr int32_t kJitSmokeExitCode = 84;

/** Runs the smoke NRO on the JIT. `scratch_dir` must be writable (the NRO and the marker go
 *  there); `build_tag` identifies this build (see above). Skipped when this build has no JIT.
 *  Never throws. */
JitSmokeResult run_jit_smoke(const std::string& scratch_dir, const std::string& build_tag);
/** Same with another image (tests: a program that fails). */
JitSmokeResult run_jit_smoke_image(const std::string& scratch_dir, const std::string& build_tag,
                                   const std::vector<uint8_t>& image);

} // namespace lg::runtime
