// Host utility: print Maxwell translator dispatch-surface coverage.
// Build: linked from top-level CMake target print_shader_coverage.
#include "../shader/translate.h"

#include <cstdio>

int main() {
    const auto r = lg::shader::coverage_report();
    std::printf("LoboGelido shader coverage (dispatch surface, not semantics)\n");
    std::printf("  isa_encodings          = %u\n", r.isa_encodings);
    std::printf("  isa_unique_mnemonics   = %u\n", r.isa_unique_mnemonics);
    std::printf("  translator_body_mnems  = %u\n", r.translator_body_mnemonics);
    std::printf("  summary                = %s\n", r.summary.c_str());
    return 0;
}
