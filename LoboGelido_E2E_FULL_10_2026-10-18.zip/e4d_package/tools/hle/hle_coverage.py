#!/usr/bin/env python3
"""P6.0 (P6_DISENO.md §1, §3.1): M-SRV and M-CMD measured from the code. Reads the libnx
inventory (libnx_inventory.py --json) and the catalog the HLE services declare (the
"CATALOG {...}" line test_hle_catalog prints). A libnx command (file, interface, id) counts
when the catalogued class for (file, interface) implements the id. A family (libnx file) is
"started" with one command and "complete" with all of them.
Usage: hle_coverage.py inv.json <output of test_hle_catalog>"""
import json, sys

inv = json.load(open(sys.argv[1]))['files']
cat = None
for line in open(sys.argv[2]):
    if line.startswith('CATALOG '):
        cat = json.loads(line[len('CATALOG '):])
if cat is None:
    sys.exit('no CATALOG line')
total = covered = started = complete = 0
rows = []
for f, v in sorted(inv.items()):
    cmds = [tuple(c) for c in v['commands']]
    n = sum(1 for iface, cid in cmds if cid in cat.get(f + '|' + iface, []))
    total += len(cmds)
    covered += n
    if n:
        started += 1
        rows.append((f, n, len(cmds)))
    if cmds and n == len(cmds):
        complete += 1
print('M-CMD %d/%d (%.1f %%)' % (covered, total, 100.0 * covered / total))
print('M-SRV familias empezadas %d/%d, completas %d/%d' % (started, len(inv), complete, len(inv)))
for f, n, t in rows:
    print('  %-32s %d/%d' % (f, n, t))
