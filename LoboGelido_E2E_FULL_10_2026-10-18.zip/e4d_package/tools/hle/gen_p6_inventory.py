#!/usr/bin/env python3
"""P6 (P6_DISENO.md §2): the inventory table of the HLE plan, from libnx_inventory.py's JSON.
Each libnx IPC file (a service family) gets its phase and its policy class.
Usage: gen_p6_inventory.py <inventory.json>  (prints markdown)"""
import json, sys

d = json.load(open(sys.argv[1]))
# families whose names libnx builds at run time (not visible to the static scan)
DYN = {'bsd.c': 'bsd:u bsd:s', 'ssl.c': 'ssl', 'pm.c': 'pm:shell pm:dmnt pm:info pm:bm', 'ldr.c': 'ldr:pm ldr:shel ldr:dmnt',
       'news.c': 'news:a news:c news:m news:p news:v', 'htcs.c': 'htcs', 'sfdnsres.c': 'sfdnsres', 'lp2p.c': 'lp2p:app lp2p:sys',
       'bpc.c': 'bpc bpc:r', 'sm.c': 'sm:', 'async.c': '(IAsync*)', 'binder.c': '(IHOSBinderDriver)'}
PHASE = {}
def put(ph, names):
    for n in names.split():
        PHASE[n] = ph
put('P6.1', 'sm.c smm.c set.c apm.c applet.c acc.c time.c fs.c hid.c pl.c psm.c nifm.c pctl.c friends.c csrng.c mii.c miiimg.c '
            'pdm.c ectx.c notif.c async.c spsm.c psc.c idlesys.c omm.c ovln.c tc.c ts.c lbl.c fan.c')
put('P6.2', 'vi.c binder.c nv.c')
put('P6.3', 'audren.c audout.c audin.c auddev.c aud.c audctl.c audrec.c hwopus.c')
put('P6.4', 'ns.c avm.c nim.c pgl.c capsa.c capsc.c capsdc.c capssc.c capssu.c capsu.c capmtp.c grc.c bsd.c ssl.c sfdnsres.c '
            'htcs.c news.c ldn.c lp2p.c nfc.c irs.c hidbus.c hidsys.c hiddbg.c bt.c btdrv.c btm.c btmsys.c btmu.c wlaninf.c '
            'usbds.c usbhs.c uart.c gpio.c i2c.c pcv.c clkrst.c bpc.c pm.c ins.c mm.c ro.c lr.c')
# D-P6-3: the content and security boundary (never keys, decryption or signature checks)
put('P6.5', 'spl.c fsldr.c fspr.c ncm.c ldr.c')
POLICY = {'spl.c': 'frontera DRM: sin claves (solo GetConfig/aleatorios)', 'fsldr.c': 'frontera DRM: sin NCA',
          'fspr.c': 'frontera DRM', 'ncm.c': 'frontera DRM: sin content_metadata', 'ldr.c': 'frontera DRM: sin NPDM firmado',
          'lr.c': 'rutas de contenido local, sin NCA', 'ro.c': 'NRO/NRR sin verificación de firma'}
rows = []
for f, v in sorted(d['files'].items()):
    base = f.split('/')[-1]
    names = ' '.join(v['services']) or DYN.get(base, '')
    rows.append((PHASE.get(base, 'P6.4'), f, names, len(v['commands']), POLICY.get(base, '')))
rows.sort(key=lambda r: (r[0], -r[3]))
tot = {}
print('| Fase | Archivo de libnx | Servicios | Comandos | Política |')
print('|---|---|---|---|---|')
for r in rows:
    tot[r[0]] = tot.get(r[0], 0) + r[3]
    print('| %s | `%s` | %s | %d | %s |' % (r[0], r[1], ' '.join('`%s`' % n for n in r[2].split()), r[3], r[4]))
print()
print('| Fase | Familias | Comandos |')
print('|---|---|---|')
for ph in sorted(tot):
    print('| %s | %d | %d |' % (ph, sum(1 for r in rows if r[0] == ph), tot[ph]))
print('| **Total** | **%d** | **%d** |' % (len(rows), sum(tot.values())))
