#!/usr/bin/env python3
"""P6 (P6_DISENO.md §2): the denominator of the HLE metric. Scans libnx's client code (ISC license)
for every IPC command it can send: per source file, the named services it opens (smGetService*)
and the literal command ids passed to serviceDispatch* or to the file's own static helpers that
take a Service* first or are named *Cmd* (the id is their last integer literal argument).
Usage: libnx_inventory.py <libnx>/nx/source [--json out.json]"""
import json, os, re, sys

root = sys.argv[1]
SVC = re.compile(r'smGetService[A-Za-z]*\(\s*&?[\w.\->\[\]]+\s*,\s*"([^"]+)"')
SVC2 = re.compile(r'"([a-z][a-z0-9_-]*:[a-z0-9_:-]*|[a-z][a-z0-9_-]+)"')
files = {}
for dp, _, fns in os.walk(root):
    for fn in fns:
        if not fn.endswith('.c'):
            continue
        p = os.path.join(dp, fn)
        src = open(p, errors='ignore').read()
        names = sorted(set(SVC.findall(src)))
        cmds = set()   # (interface expression, command id): an interface is the Service the call targets
        # the file's own static helpers that take a Service* first (they wrap serviceDispatch)
        helpers = set(re.findall(r'static\s+(?:inline\s+)?Result\s+(_\w+)\s*\(\s*(?:const\s+)?Service\s*\*', src))
        helpers |= set(n for n in re.findall(r'static\s+(?:inline\s+)?Result\s+(_\w+)\s*\(', src) if re.search(r'[Cc]md', n))
        call = re.compile(r'\b(serviceDispatch[A-Za-z]*%s)\s*\(' % ''.join('|' + re.escape(h) for h in sorted(helpers)))
        for m in call.finditer(src):
            name = m.group(1)
            if src[max(0, m.start() - 40):m.start()].rstrip().endswith('Result'):
                continue   # the helper's own definition
            # balanced argument list
            i, depth = m.end(), 1
            while i < len(src) and depth:
                depth += {'(': 1, ')': -1}.get(src[i], 0)
                i += 1
            argtext = src[m.end():i - 1]
            args, d, cur = [], 0, ''
            for ch in argtext:
                if ch in '({[':
                    d += 1
                elif ch in ')}]':
                    d -= 1
                if ch == ',' and d == 0:
                    args.append(cur.strip()); cur = ''
                else:
                    cur += ch
            args.append(cur.strip())
            iface = re.sub(r'\s+', '', args[0]) if args else ''
            if name.startswith('serviceDispatch'):
                if len(args) >= 2 and re.fullmatch(r'\d+', args[1]):
                    cmds.add((iface, int(args[1])))
            else:
                ints = [a for a in args if re.fullmatch(r'\d+', a)]
                if ints:
                    cmds.add((iface, int(ints[-1])))
        if names or cmds:
            files[os.path.relpath(p, root)] = {'services': names, 'commands': sorted([list(c) for c in cmds])}
tot_cmd = sum(len(v['commands']) for v in files.values())
svcs = sorted({s for v in files.values() for s in v['services']} | {'sm:'})
print('archivos con IPC: %d, servicios con nombre: %d, comandos (archivo, interfaz, id): %d' % (len(files), len(svcs), tot_cmd))
if '--json' in sys.argv:
    json.dump({'files': files, 'services': svcs}, open(sys.argv[sys.argv.index('--json') + 1], 'w'), indent=1, sort_keys=True)
