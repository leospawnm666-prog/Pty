# Cobertura de shaders + Vulkan por software

## Cobertura (dispatch surface)

```bash
cmake -S . -B build
cmake --build build --target print_shader_coverage
./tools/shader_coverage.sh
# o
./build/print_shader_coverage
```

Imprime `isa_encodings`, mnemónicos únicos y superficie de despacho de `emit_body`.
**No** es porcentaje de semántica SPIR-V correcta (ver `REVISION_TECNICA_GPU_HLE`).

También expuesto en `ShaderProgramManager::diagnostics()` como `dispatchSurface≈…`.

## Vulkan software (SwiftShader / Lavapipe)

```bash
source <(./tools/setup_software_vulkan.sh swiftshader /path/to/libvk_swiftshader.so)
source <(./tools/setup_software_vulkan.sh lavapipe   /path/to/libvulkan_lvp.so)
```

Variables: `VK_ICD_FILENAMES`, `LOBO_FORCE_SOFTWARE`, `LOBO_SOFTWARE_VULKAN_LIB`.

Unit test: `ctest -R software_vulkan_policy` o `./build/test_software_vulkan_policy`.
