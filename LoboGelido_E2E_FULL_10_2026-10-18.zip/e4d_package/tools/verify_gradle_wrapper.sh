#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
check_wrapper() {
  dir="$1"
  test -f "$dir/gradlew" || { echo "MISSING: $dir/gradlew"; return 1; }
  test -f "$dir/gradle/wrapper/gradle-wrapper.properties" || { echo "MISSING: $dir/gradle/wrapper/gradle-wrapper.properties"; return 1; }
  test -f "$dir/gradle/wrapper/gradle-wrapper.jar" || { echo "MISSING: $dir/gradle/wrapper/gradle-wrapper.jar (required; obtain from official Gradle 8.13 distribution/source)"; return 1; }
  echo "Wrapper files present: $dir"
}
check_wrapper "$ROOT"
check_wrapper "$ROOT/android"
echo "Wrapper file presence verified. This does not certify Gradle/Android compilation."
