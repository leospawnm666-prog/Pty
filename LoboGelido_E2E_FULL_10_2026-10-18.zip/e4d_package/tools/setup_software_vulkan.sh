#!/usr/bin/env bash
# Prepare VK_ICD_FILENAMES + LOBO_* for host software Vulkan (SwiftShader / Lavapipe).
#
# Usage:
#   source <(./tools/setup_software_vulkan.sh swiftshader /path/to/libvk_swiftshader.so)
#   source <(./tools/setup_software_vulkan.sh lavapipe   /path/to/libvulkan_lvp.so)
#   ./tools/setup_software_vulkan.sh swiftshader /path/to/lib.so   # prints exports only
set -euo pipefail
KIND="${1:-}"
LIB="${2:-}"
OUT="${3:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ -z "$OUT" ]]; then
  OUT="${ROOT}/build/software_icd"
fi
if [[ -z "$KIND" || -z "$LIB" ]]; then
  cat >&2 << USAGE
usage: $0 <swiftshader|lavapipe> <library.so> [output_dir]

Exports (use with source):
  VK_ICD_FILENAMES / VK_DRIVER_FILES
  LOBO_FORCE_SOFTWARE
  LOBO_SOFTWARE_VULKAN_LIB

Headless runtime: initialize(nullptr, \"\") resolves via LOBO_FORCE_SOFTWARE.
USAGE
  exit 2
fi
mkdir -p "$OUT"
case "$KIND" in
  swiftshader|swift|ss) KIND=swiftshader; JSON="$OUT/vk_swiftshader_icd.json" ;;
  lavapipe|lvp|mesa|llvmpipe) KIND=lavapipe; JSON="$OUT/vk_lavapipe_icd.json" ;;
  *) echo "unknown kind: $KIND (use swiftshader|lavapipe)" >&2; exit 2 ;;
esac
if [[ ! -f "$LIB" ]]; then
  echo "library not found: $LIB" >&2
  exit 1
fi
ABS="$(cd "$(dirname "$LIB")" && pwd)/$(basename "$LIB")"
cat > "$JSON" << JSON
{
    "file_format_version": "1.0.0",
    "ICD": {
        "library_path": "$ABS",
        "api_version": "1.1.0"
    }
}
JSON
# When sourced, export into current shell; when executed, print export lines.
EXPORT_BLOCK=$(cat << EXP
export VK_ICD_FILENAMES="$JSON"
export VK_DRIVER_FILES="$JSON"
export LOBO_FORCE_SOFTWARE="$KIND"
export LOBO_SOFTWARE_VULKAN_LIB="$ABS"
EXP
)
echo "$EXPORT_BLOCK"
if [[ "${BASH_SOURCE[0]:-}" != "${0:-}" ]]; then
  eval "$EXPORT_BLOCK"
  echo "# software Vulkan ready: kind=$KIND lib=$ABS" >&2
else
  echo "# Tip: source <($0 $KIND $LIB) to export into your shell" >&2
fi
