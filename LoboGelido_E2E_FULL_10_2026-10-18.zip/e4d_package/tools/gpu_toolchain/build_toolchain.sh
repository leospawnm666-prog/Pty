#!/usr/bin/env bash
# P4.1 (P4_DISENO.md §3): rebuilds the GPU verification toolchain with pinned versions.
# None of this is linked into Lobo Gélido: these tools only generate test fixtures (envyas,
# envydis, uam, glslang) or act as the test oracle (SwiftShader + Vulkan loader, spirv-val).
#
#   envytools      f102b82381f3f11cee113d16374c87091db039d9  envyas/envydis (MIT)          fixtures T1/T2
#   uam            5a5afc2bae8b55409ab36ba45be63fcb73f68993  GLSL -> Maxwell (deko3d)       fixtures T3
#   glslang        vulkan-sdk-1.3.290.0                      GLSL -> SPIR-V                 fixtures T3
#   SPIRV-Tools    vulkan-sdk-1.3.290.0 (+ SPIRV-Headers)    spirv-val                      M4
#   Vulkan-Headers b379292b2ab6df5771ba9870d53cf8b2c9295daf  headers                        T2/T3
#   Vulkan-Loader  40b8e6eeead809a62c708cb48fdd9f8f2eab3f15  libvulkan.so.1                 T2/T3
#   SwiftShader    cddb5c91b23ff70a1f607ea31610aa0d7f4b5ad5  Vulkan ICD on the CPU          T2/T3 oracle
#   Mesa lavapipe  mesa-24.3.4 + system LLVM 18 (build_lavapipe.sh)  every stage          P4.2 graphics oracle
#   flex 2.6.4, meson eaefe294..., mako 14889bc0..., markupsafe 4e111271... (uam's build)
#
# Usage: bash build_toolchain.sh <prefix>      (needs git, cmake, ninja, a C/C++ compiler, bison,
#                                               python3; ~1 h on 2 cores, SwiftShader dominates)
# Then configure Lobo with:
#   -DLOBOGELIDO_SHADER_ORACLE=<prefix>/lib/libvulkan.so.1
#   -DLOBOGELIDO_SHADER_ORACLE_ICD=<prefix>/src/swiftshader/build/Linux/vk_swiftshader_icd.json
#   -DLOBOGELIDO_VULKAN_INCLUDE=<prefix>/include -DLOBOGELIDO_SPIRV_VAL=<prefix>/bin/spirv-val
#   -DLOBOGELIDO_SHADER_ORACLE_GFX_ICD=<prefix>/lvp/share/vulkan/icd.d/lvp_icd.x86_64.json   (P4.2)
# and regenerate the fixtures (only needed after changing the corpus or the cases):
#   python3 tools/gpu_toolchain/gen_maxwell_isa.py <prefix>/src/envytools shader/maxwell/isa_table.inc
#   python3 tools/gpu_toolchain/gen_shader_t1.py <prefix>/bin/envydis shader/maxwell/isa_table.inc tests/shader/t1_golden.h
#   python3 tools/gpu_toolchain/gen_shader_t2.py <prefix>/bin/envyas tests/shader/t2_fixtures.h
#   python3 tools/gpu_toolchain/gen_random_shaders.py tests/data/shader/corpus 24
#   python3 tools/gpu_toolchain/gen_shader_corpus.py <prefix>/bin/uam <prefix>/bin/glslangValidator \
#           tests/data/shader/corpus tests/shader/t3_fixtures.h
#   python3 tools/gpu_toolchain/gen_shader_t2g.py <prefix>/bin/envyas <prefix>/bin/glslangValidator tests/shader/t2g_fixtures.h
#   python3 tools/gpu_toolchain/gen_shader_gcorpus.py <prefix>/bin/uam <prefix>/bin/glslangValidator \
#           tests/data/shader/gcorpus tests/shader/t3g_fixtures.h
#   python3 tools/gpu_toolchain/gen_shader_t2t.py <prefix>/bin/envyas tests/shader/t2t_fixtures.h          (P4.3)
#   python3 tools/gpu_toolchain/gen_shader_corpus.py <prefix>/bin/uam <prefix>/bin/glslangValidator \
#           tests/data/shader/tcorpus tests/shader/t3t_fixtures.h t3tfx
#   python3 tools/gpu_toolchain/gen_shader_gcorpus.py <prefix>/bin/uam <prefix>/bin/glslangValidator \
#           tests/data/shader/tcorpus tests/shader/t3tg_fixtures.h t3tgfx
set -euo pipefail
P=$(realpath -m "${1:?prefix}")
S=$P/src
mkdir -p "$S" "$P/bin"
export PATH=$P/bin:$PATH
fetch() {   # fetch <url> <dir> <commit-or-tag>
    if [ ! -d "$S/$2/.git" ]; then git clone -q "$1" "$S/$2"; fi
    git -C "$S/$2" fetch -q --tags origin "$3" 2>/dev/null || true
    git -C "$S/$2" checkout -q "$3"
}

# ---- flex (envytools and Mesa's GLSL front end in uam need it)
if ! command -v flex >/dev/null; then
    curl -sSL -o "$S/flex.tar.gz" https://github.com/westes/flex/releases/download/v2.6.4/flex-2.6.4.tar.gz
    tar -C "$S" -xzf "$S/flex.tar.gz"
    (cd "$S/flex-2.6.4" && ./configure -q --prefix="$P" && make -s -j"$(nproc)" install)
fi

# ---- envytools: only envydis and envyas, built by hand (its CMake wants libxml2 and more)
fetch https://github.com/envytools/envytools.git envytools f102b82381f3f11cee113d16374c87091db039d9
E=$S/envytools
mkdir -p "$E/mb"
flex -o "$E/mb/easm_lex.c" --header-file="$E/mb/easm_lex.h" "$E/easm/easm_lex.l"
bison -o "$E/mb/easm_parse.c" --defines="$E/mb/easm_parse.h" "$E/easm/easm_parse.y"
INC="-I$E/include -I$E/mb -I$E/easm"
UTIL="$E/util/aprintf.c $E/util/astr.c $E/util/colors.c $E/util/hash.c $E/util/mask.c $E/util/path.c \
      $E/util/symtab.c $E/util/vardata.c $E/util/varinfo.c $E/util/varselect.c $E/util/yy.c"
EASM="$E/easm/easm.c $E/easm/easm_print.c $E/easm/easm_xfrm.c $E/mb/easm_lex.c $E/mb/easm_parse.c"
ISAS=$(ls "$E"/envydis/*.c | grep -v -e "/envydis\.c$" -e "/envyas\.c$")
cc -O2 -w $INC -o "$P/bin/envydis" "$E/envydis/envydis.c" $ISAS $EASM $UTIL
cc -O2 -w $INC -o "$P/bin/envyas" "$E/envydis/envyas.c" $ISAS $EASM $UTIL

# ---- SPIRV-Headers / SPIRV-Tools / glslang
fetch https://github.com/KhronosGroup/SPIRV-Headers.git spirv-headers vulkan-sdk-1.3.290.0
fetch https://github.com/KhronosGroup/SPIRV-Tools.git spirv-tools vulkan-sdk-1.3.290.0
ln -sfn ../../spirv-headers "$S/spirv-tools/external/spirv-headers"
cmake -S "$S/spirv-tools" -B "$S/spirv-tools/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DSPIRV_SKIP_TESTS=ON \
      -DCMAKE_INSTALL_PREFIX="$P" >/dev/null
ninja -C "$S/spirv-tools/build" install >/dev/null
fetch https://github.com/KhronosGroup/glslang.git glslang vulkan-sdk-1.3.290.0
cmake -S "$S/glslang" -B "$S/glslang/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DENABLE_OPT=OFF -DGLSLANG_TESTS=OFF \
      -DCMAKE_INSTALL_PREFIX="$P" >/dev/null
ninja -C "$S/glslang/build" install >/dev/null

# ---- uam (devkitPro's deko3d shader compiler: Mesa's GLSL front end + nouveau codegen)
fetch https://github.com/mesonbuild/meson.git meson eaefe29463a61a311a6b1de6cd539f39500399ff
fetch https://github.com/sqlalchemy/mako.git mako 14889bc0feacd12102ee61f0769677be2fddbc1b
fetch https://github.com/pallets/markupsafe.git markupsafe 4e111271b1494995708a9e878a10829b5e10c7ba
printf '#!/bin/sh\nexec python3 %s/meson/meson.py "$@"\n' "$S" > "$P/bin/meson"
chmod +x "$P/bin/meson"
export PYTHONPATH=$S/mako:$S/markupsafe/src
fetch https://github.com/devkitPro/uam.git uam 5a5afc2bae8b55409ab36ba45be63fcb73f68993
(cd "$S/uam" && meson setup build >/dev/null && ninja -C build >/dev/null)
cp "$S/uam/build/uam" "$P/bin/uam"

# ---- Vulkan headers, loader and SwiftShader (the oracle)
fetch https://github.com/KhronosGroup/Vulkan-Headers.git vkheaders b379292b2ab6df5771ba9870d53cf8b2c9295daf
cmake -S "$S/vkheaders" -B "$S/vkheaders/build" -DCMAKE_INSTALL_PREFIX="$P" >/dev/null
cmake --install "$S/vkheaders/build" >/dev/null
fetch https://github.com/KhronosGroup/Vulkan-Loader.git vkloader 40b8e6eeead809a62c708cb48fdd9f8f2eab3f15
cmake -S "$S/vkloader" -B "$S/vkloader/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DVULKAN_HEADERS_INSTALL_DIR="$P" \
      -DBUILD_WSI_XCB_SUPPORT=OFF -DBUILD_WSI_XLIB_SUPPORT=OFF -DBUILD_WSI_WAYLAND_SUPPORT=OFF \
      -DCMAKE_INSTALL_PREFIX="$P" >/dev/null
ninja -C "$S/vkloader/build" install >/dev/null
fetch https://github.com/google/swiftshader.git swiftshader cddb5c91b23ff70a1f607ea31610aa0d7f4b5ad5
cmake -S "$S/swiftshader" -B "$S/swiftshader/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DSWIFTSHADER_BUILD_TESTS=OFF \
      -DSWIFTSHADER_BUILD_BENCHMARKS=OFF -DSWIFTSHADER_BUILD_PVR=OFF -DSWIFTSHADER_WARNINGS_AS_ERRORS=OFF \
      -DREACTOR_BACKEND=Subzero -DSWIFTSHADER_BUILD_WSI_XCB=OFF -DSWIFTSHADER_BUILD_WSI_XLIB=OFF \
      -DSWIFTSHADER_BUILD_WSI_WAYLAND=OFF -DSWIFTSHADER_BUILD_WSI_DIRECTFB=OFF -DSWIFTSHADER_BUILD_WSI_D2D=OFF >/dev/null
ninja -C "$S/swiftshader/build" vk_swiftshader >/dev/null
# ---- P4.2: lavapipe, the graphics oracle (every stage)
bash "$(dirname "$(realpath "$0")")/build_lavapipe.sh" "$P"
echo "toolchain listo en $P"
