#!/usr/bin/env python3
# P4.4 T2-X (P4_4_DISENO.md §5.1): one test per form of the instructions P4.4 adds.
#
# The scaffold is T2-T's (tools/gpu_toolchain/gen_shader_t2t.py): a compute program of 64
# invocations, sources loaded from c2 (R8..R11 = words 0..3, R20..R23 = words 4..7), the
# instruction under test, R0..R7 stored to a storage buffer. The forms envyas (envytools, MIT) does
# not write are raw words built from the field layout of the envydis tables (and, for the
# conversions, of the nouveau GM107 emitter). Every expected value is computed HERE, independently
# of the recompiler: IEEE binary64/binary16 with numpy, the rest from the public semantics cited
# per section (PTX ISA, Mesa/NAK).
#
# Case flags (read by tests/test_shader_t2t.cpp built as test_shader_t2x):
#   f64    needs shaderFloat64        lossy  ShaderInfo::fp64 = Lossy32
#   nan64  a NaN double (word pair R0:R1, R2:R3...) matches any NaN double
#   nan32  a NaN float word matches any NaN float
#
# Usage: gen_shader_t2x.py <envyas> <out .h>
import math
import os
import random
import re
import struct
import subprocess
import sys
import tempfile

import numpy as np

ENVYAS, OUT = sys.argv[1:3]
SCHED = 0x001f8000fc0007e0
TMP = tempfile.mkdtemp()
PT = 7 << 16
N = 64
rng = random.Random(0x4404)


def f2u(f):
    return struct.unpack('<I', struct.pack('<f', f))[0]


def u32(x):
    return x & 0xffffffff


def d2w(d):
    """a double -> (lo, hi) words"""
    q = struct.unpack('<Q', struct.pack('<d', float(d)))[0]
    return q & 0xffffffff, q >> 32


def w2d(lo, hi):
    return struct.unpack('<d', struct.pack('<Q', (hi << 32) | lo))[0]


# ---------------------------------------------------------------- assembly (as gen_shader_t2t.py)
def assemble(lines):
    raw = {}
    text = []
    for k, ln in enumerate(lines):
        if ln.startswith('raw '):
            raw[k] = int(ln.split()[1], 0)
            text.append('mov $r0 $r0 0xf')
        else:
            text.append(ln)
    src = os.path.join(TMP, 'p.s')
    open(src, 'w').write('\n'.join(text) + '\n')
    out = src + '.bin'
    r = subprocess.run([ENVYAS, '-m', 'gm107', '-w', src, '-o', out], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit('envyas failed on:\n%s\n%s' % ('\n'.join(text), r.stderr))
    w = [int(x, 16) for x in re.findall(r'0x[0-9a-f]+', open(out).read())]
    words = [raw[k] if k in raw else w[2 * k] | (w[2 * k + 1] << 32) for k in range(len(lines))]
    code = []
    for x in words:
        if len(code) % 4 == 0:
            code.append(SCHED)
        code.append(x)
    while len(code) % 4:
        code.append(0x50b0000000070f00 if len(code) % 4 else SCHED)
    return code


PROLOGUE = [
    'mov $r40 $tidx',
    'shl $r41 $r40 0x5',
    'ld b32 $r8 c2[$r41]', 'ld b32 $r9 c2[$r41+0x4]', 'ld b32 $r10 c2[$r41+0x8]', 'ld b32 $r11 c2[$r41+0xc]',
    'ld b32 $r20 c2[$r41+0x10]', 'ld b32 $r21 c2[$r41+0x14]', 'ld b32 $r22 c2[$r41+0x18]', 'ld b32 $r23 c2[$r41+0x1c]',
] + ['mov32i $r%d 0x0 0xf' % r for r in range(8)]
EPILOGUE = [
    'iadd cc $r43 $r41 c0[0x140]',
    'iadd x $r44 $r255 c0[0x144]',
] + ['stg e b32 ncg[$r43+0x%x] $r%d' % (4 * r, r) for r in range(8)] + ['exit']

cases = []


def case(name, body, inputs, expect, flags='', texs=(), images=None, prologue=None, epilogue=None, alt=None):
    """inputs/expect: per invocation 8 words (R8..R11, R20..R23 / R0..R7); alt: another accepted
    result per word (e.g. FMA computed unfused by the oracle)."""
    assert len(inputs) == N and len(expect) == N, name
    code = assemble(resolve((PROLOGUE if prologue is None else prologue) + body + (EPILOGUE if epilogue is None else epilogue)))
    cases.append(dict(name=name, code=code, texs=list(texs), inputs=inputs, expect=expect, images=images or {},
                      body=' | '.join(body_text(x) for x in body), flags=flags, alt=alt))


def body_text(x):
    if isinstance(x, tuple):
        return '%s:' % x[1]
    return x if isinstance(x, str) else '<palabra calculada>'


def insn_addr(k):
    """byte address of the k-th instruction (a scheduling word opens every group of three)"""
    return ((k // 3) * 4 + k % 3 + 1) * 8


def resolve(lines):
    """('label', name) marks the next instruction; a callable(addr, labels) gives a raw word."""
    labels, out, k = {}, [], 0
    for ln in lines:
        if isinstance(ln, tuple) and ln[0] == 'label':
            labels[ln[1]] = insn_addr(k)
        else:
            out.append(ln)
            k += 1
    return [('raw 0x%016x' % ln(insn_addr(i), labels)) if callable(ln) else ln for i, ln in enumerate(out)]


def pad8(ws):
    ws = [u32(x) for x in ws]
    return ws + [0] * (8 - len(ws))


# =====================================================================================
# FP64 (D-P4.4-2): DADD DMUL DFMA DMNMX DSETP DSET, IEEE binary64 (numpy float64 = the hardware's
# arithmetic for these operations, round to nearest even)
# =====================================================================================
DEDGE = [0.0, -0.0, 1.0, -1.0, 0.5, -2.5, 3.0, 1e308, -1e308, math.inf, -math.inf, math.nan, 5e-324, -5e-324,
         2.2250738585072014e-308, 1.0 / 3.0, math.pi, -math.e, 2.0 ** 53 + 2, 1e-300, 123456789.125, -7.75e-5,
         1.7976931348623157e308, 4.9e-310, 65504.0, 2.0 ** -1022 * 1.5]


def drand():
    k = rng.randrange(4)
    if k == 0:
        return rng.choice(DEDGE)
    if k == 1:
        return rng.uniform(-1e6, 1e6)
    if k == 2:
        return math.ldexp(rng.uniform(0.5, 1.0), rng.randrange(-1074, 1024)) * rng.choice((1, -1))
    return float(rng.randrange(-1000, 1000)) / 8.0


def dops(n):
    """64 tuples of n doubles: the edge values against each other first, then random ones."""
    out = []
    for t in range(N):
        if t < len(DEDGE) and n >= 2:
            v = [DEDGE[t], DEDGE[(t * 7 + 3) % len(DEDGE)]] + [drand() for _ in range(n - 2)]
        else:
            v = [drand() for _ in range(n)]
        out.append(v)
    return out


def dres(x):
    return list(d2w(np.float64(x)))


def fma64(a, b, c):
    """binary64 fused multiply-add, one rounding (exact rational arithmetic; Python 3.11 has no math.fma)"""
    from fractions import Fraction
    a, b, c = float(a), float(b), float(c)
    if not all(math.isfinite(x) for x in (a, b, c)):
        return a * b + c   # the special cases (inf/NaN) are the same with or without fusion
    exact = Fraction(a) * Fraction(b) + Fraction(c)
    if exact == 0:
        # the sign of an exact zero: +0 unless both the product and c are -0 / negative zero sums
        p = a * b
        return p + c
    try:
        return float(exact)   # correctly rounded
    except OverflowError:
        return math.inf if exact > 0 else -math.inf


with np.errstate(all='ignore'):
    # register forms: a = R8:R9, b = R20:R21, c = R10:R11
    def d_case(name, body, fn, n=2, flags='f64 nan64', mod=None, no_zero_pairs=False, alt_fn=None):
        ins, exp, alt = [], [], []
        for v in dops(n):
            a = v[0]
            b = v[1]
            if no_zero_pairs and a == 0.0 and b == 0.0:
                b = 0.25
            c = v[2] if n > 2 else 0.0
            ins.append(pad8(list(d2w(a)) + list(d2w(c)) + list(d2w(b))))
            exp.append(pad8(fn(np.float64(a), np.float64(b), np.float64(c))))
            if alt_fn:
                alt.append(pad8(alt_fn(np.float64(a), np.float64(b), np.float64(c))))
        case(name, body, ins, exp, flags, alt=alt if alt_fn else None)

    d_case('dadd', ['dadd $r0 $r8 $r20'], lambda a, b, c: dres(a + b))
    d_case('dadd_neg_abs', ['dadd $r0 neg $r8 abs $r20'], lambda a, b, c: dres(-a + abs(b)))
    d_case('dadd_abs_neg', ['raw 0x%016x' % (0x5c70000000000000 | (1 << 46) | (1 << 45) | (20 << 20) | PT | (8 << 8))],
           lambda a, b, c: dres(abs(a) - b))
    d_case('dmul', ['dmul $r0 $r8 $r20'], lambda a, b, c: dres(a * b))
    d_case('dmul_neg', ['dmul $r0 $r8 neg $r20'], lambda a, b, c: dres(a * -b))
    d_case('dfma', ['dfma $r0 $r8 $r20 $r10'], lambda a, b, c: dres(fma64(a, b, c)), n=3,
           alt_fn=lambda a, b, c: dres(a * b + c))
    d_case('dfma_neg', ['dfma $r0 $r8 neg $r20 neg $r10'], lambda a, b, c: dres(fma64(a, -b, -c)), n=3,
           alt_fn=lambda a, b, c: dres(a * -b - c))

    def nminmax(a, b, is_min):
        # IEEE 754-2008 minNum/maxNum: the non-NaN operand (Maxwell's FMNMX/DMNMX; P4.1 model)
        if math.isnan(a):
            return b
        if math.isnan(b):
            return a
        if a == b == 0.0:
            # min(-0, +0): either is a valid minNum; both sides of the test agree on the operand order
            return a if (math.copysign(1, a) < 0) == is_min else b
        return min(a, b) if is_min else max(a, b)

    for pnot, mname in ((False, 'min'), (True, 'max')):
        # P = $p0 (true): min; !$p0: max
        d_case('dmnmx_%s' % mname, ['dmnmx $r0 $r8 $r20 %s0x1' % ('not ' if pnot else '')],
               lambda a, b, c, m=(not pnot): dres(nminmax(float(a), float(b), m)), flags='f64', no_zero_pairs=True)
    d_case('dmnmx_abs', ['dmnmx $r0 abs $r8 neg $r20 0x1'], lambda a, b, c: dres(nminmax(abs(float(a)), -float(b), True)),
           flags='f64', no_zero_pairs=True)

    FCMP = {'lt': lambda a, b: a < b, 'eq': lambda a, b: a == b, 'le': lambda a, b: a <= b, 'gt': lambda a, b: a > b,
            'ne': lambda a, b: a != b and not (math.isnan(a) or math.isnan(b)), 'ge': lambda a, b: a >= b,
            'num': lambda a, b: not (math.isnan(a) or math.isnan(b)), 'nan': lambda a, b: math.isnan(a) or math.isnan(b),
            'ltu': lambda a, b: not a >= b, 'equ': lambda a, b: not (a < b or a > b), 'leu': lambda a, b: not a > b,
            'gtu': lambda a, b: not a <= b, 'neu': lambda a, b: a != b, 'geu': lambda a, b: not a < b}
    for cond, fn in FCMP.items():
        # DSETP: P1 = cond AND P0(true), P2 = !cond AND P0; outputs: R0 = P1, R1 = P2 (via sel)
        body = ['dsetp %s and $p1 $p2 $r8 $r20 0x1' % cond, 'sel $r0 $r255 0x1 not $p1', 'sel $r1 $r255 0x1 not $p2']
        d_case('dsetp_%s' % cond, body, lambda a, b, c, f=fn: [int(f(float(a), float(b))), int(not f(float(a), float(b)))],
               flags='f64')
    d_case('dsetp_or_not', ['dsetp lt or $p1 $p2 neg $r8 abs $r20 not 0x1', 'sel $r0 $r255 0x1 not $p1',
                            'sel $r1 $r255 0x1 not $p2'],
           lambda a, b, c: [int(-float(a) < abs(float(b))), int(not (-float(a) < abs(float(b))))], flags='f64')
    d_case('dset_lt', ['dset lt and $r0 $r8 $r20 0x1'], lambda a, b, c: [0xffffffff if float(a) < float(b) else 0], flags='f64')
    d_case('dset_bf_geu', ['dset bf geu and $r0 $r8 $r20 0x1'],
           lambda a, b, c: [f2u(1.0) if not float(a) < float(b) else 0], flags='f64')

    # cbuf and immediate forms: b = c3[0x10] (the test puts 2.75 there: see run_case's c3? no -> c2 only)
    # (the scaffold only fills c0 and c2: the cbuf operand reads c2 words 0/1 of invocation 0 = R8:R9 of t=0)

    # the 20-bit immediate: the top of the high word (0x40060 -> 0x40060000_00000000 = 2.75 + ...)
    def imm_d(raw20):
        return w2d(0, (raw20 & 0xfffff) << 12)

    for raw20 in (0x3ff00, 0xc0080, 0x40060):
        w = 0x3870000000000000 | ((raw20 & 0x7ffff) << 20) | ((raw20 >> 19) << 56) | PT | (8 << 8)
        d_case('dadd_imm_%05x' % raw20, ['raw 0x%016x' % w], lambda a, b, c, k=raw20: dres(a + np.float64(imm_d(k))))
    w = 0x3880000000000000 | ((0x40000 & 0x7ffff) << 20) | PT | (8 << 8)
    d_case('dmul_imm', ['raw 0x%016x' % w], lambda a, b, c: dres(a * np.float64(imm_d(0x40000))))

    # cbuf form: c2[0x8] is word 2 of invocation 0's inputs (= R10:R11 of t = 0, its c operand)
    ins0 = None

    def d_cbuf_case():
        ins, exp = [], []
        vals = dops(3)
        c0d = vals[0][2]
        for v in vals:
            a, b, c = v
            ins.append(pad8(list(d2w(a)) + list(d2w(c)) + list(d2w(b))))
        cb = np.float64(c0d)
        for v in vals:
            exp.append(pad8(dres(np.float64(v[0]) * cb)))
        case('dmul_cbuf', ['dmul $r0 $r8 c2[0x8]'], ins, exp, 'f64 nan64')
        exp = [pad8(dres(fma64(v[0], c0d, v[2]))) for v in vals]
        alt = [pad8(dres(np.float64(v[0]) * cb + np.float64(v[2]))) for v in vals]
        case('dfma_cbuf_b', ['dfma $r0 $r8 c2[0x8] $r10'], ins, exp, 'f64 nan64', alt=alt)
        exp = [pad8(dres(fma64(v[0], v[2], c0d))) for v in vals]
        alt = [pad8(dres(np.float64(v[0]) * np.float64(v[2]) + cb)) for v in vals]
        case('dfma_cbuf_c', ['dfma $r0 $r8 $r10 c2[0x8]'], ins, exp, 'f64 nan64', alt=alt)

    d_cbuf_case()

    # CC: DADD.CC then a CSET-free check: predicate from P2R? keep to flags via ISET? -> BRA CC is
    # P4.1's; here the result of the add on R0:R1 and R2 = (result == 0) through DSETP
    d_case('dadd_eq0', ['dadd $r0 $r8 $r20', 'dsetp eq and $p1 $p2 $r0 $r255 0x1', 'sel $r2 $r255 0x1 not $p1'],
           lambda a, b, c: dres(a + b) + [int(float(a + b) == 0.0)])

    # Lossy32 (D-P4.4-2): operands exactly representable in f32, results computed in f32
    def lossy_vals():
        out = []
        for t in range(N):
            a = float(np.float32(rng.uniform(-1e3, 1e3)))
            b = float(np.float32(rng.choice([rng.uniform(-1e3, 1e3), 0.0, -0.0, 1.0, 3e30, 1e-30])))
            c = float(np.float32(rng.uniform(-10, 10)))
            out.append((a, b, c))
        return out

    lv = lossy_vals()
    ins = [pad8(list(d2w(a)) + list(d2w(c)) + list(d2w(b))) for a, b, c in lv]
    case('dadd_lossy', ['dadd $r0 $r8 $r20'], ins,
         [pad8(dres(np.float64(np.float32(a) + np.float32(b)))) for a, b, c in lv], 'lossy')
    case('dmul_lossy', ['dmul $r0 $r8 $r20'], ins,
         [pad8(dres(np.float64(np.float32(a) * np.float32(b)))) for a, b, c in lv], 'lossy')
    case('dsetp_lossy', ['dsetp lt and $p1 $p2 $r8 $r20 0x1', 'sel $r0 $r255 0x1 not $p1'], ins,
         [pad8([int(a < b)]) for a, b, c in lv], 'lossy')

# =====================================================================================
# Conversions with a 64-bit operand (nouveau GM107 emitter: destination type bits 8-9, source
# type bits 10-11; F2I/I2F integer size and sign at bits 8-9 / 12 and 10-11 / 13)
# =====================================================================================
def f2f_word(dt, st, mode=0, rint=False, neg=False, ab=False, sat=False, src=8):
    return (0x5ca8000000000000 | (dt << 8) | (st << 10) | (mode << 39) | (int(rint) << 42) | (int(neg) << 45) |
            (int(ab) << 49) | (int(sat) << 50) | (src << 20) | PT)


def f2i_word(isz, sgn, st, mode=0, src=8):
    return 0x5cb0000000000000 | (isz << 8) | (st << 10) | (int(sgn) << 12) | (mode << 39) | (src << 20) | PT


def i2f_word(dt, isz, sgn, neg=False, ab=False, src=8):
    return 0x5cb8000000000000 | (dt << 8) | (isz << 10) | (int(sgn) << 13) | (int(neg) << 45) | (int(ab) << 49) | (src << 20) | PT


def f32_bits(x):
    return f2u(float(np.float32(x)))


def f16_bits(x):
    h = np.float16(x)
    if math.isnan(float(x)):
        return 0x7fff
    return int(h.view(np.uint16))


with np.errstate(all='ignore'):
    # F2F f64 -> f32 (correctly rounded), f64 -> f16 (correctly rounded: numpy rounds f64 -> f16 directly)
    vals = dops(1)
    ins = [pad8([0] * 4 + list(d2w(v[0]))) for v in vals]   # source in R20:R21
    case('f2f_f32_f64', ['raw 0x%016x' % f2f_word(2, 3, src=20)], ins,
         [pad8([f32_bits(np.float64(v[0]))]) for v in vals], 'f64 nan32')
    # f16 results: values in the half range and around its rounding ties
    hv = []
    for t in range(N):
        if t < 16:
            base = float(np.float16(rng.uniform(-60000, 60000)))
            ulp = abs(float(np.spacing(np.float16(base))))
            hv.append(base + ulp / 2 + (2.0 ** -40 if t % 2 else -(2.0 ** -40)))   # just off a tie: double rounding trap
        else:
            hv.append(rng.choice([rng.uniform(-70000, 70000), rng.uniform(-1, 1) * 1e-6, 0.0, -0.0, math.inf, 1e10]))
    ins = [pad8([0] * 4 + list(d2w(v))) for v in hv]
    case('f2f_f16_f64', ['raw 0x%016x' % f2f_word(1, 3, src=20)], ins, [pad8([f16_bits(np.float64(v))]) for v in hv], 'f64')
    # f32 -> f16 just off the ties (P4.1's path, which the f64 -> f16 path ends in)
    tv = []
    for t in range(N):
        base = float(np.float16(rng.uniform(-60000, 60000)))
        mid = np.float32(base + abs(float(np.spacing(np.float16(base)))) / 2)
        tv.append(float(np.nextafter(mid, np.float32(np.inf if t % 2 else -np.inf))) if t % 4 < 2 else float(mid))
    ins = [pad8([0] * 4 + [f2u(v)]) for v in tv]
    case('f2f_f16_f32_ties', ['raw 0x%016x' % f2f_word(1, 2, src=20)], ins, [pad8([f16_bits(np.float32(v))]) for v in tv], '')
    # f32 -> f64 (exact), f64 -> f64 with rounding to integer, neg/abs, saturation
    fv = [float(np.float32(rng.uniform(-1e5, 1e5))) for _ in range(N - 6)] + [0.0, -0.0, math.inf, -math.inf, 1e-40, 3.0e38]
    ins = [pad8([0] * 4 + [f2u(v)]) for v in fv]
    case('f2f_f64_f32', ['raw 0x%016x' % f2f_word(3, 2, src=20)], ins, [pad8(dres(np.float64(np.float32(v)))) for v in fv],
         'f64')
    vals = dops(1)
    ins = [pad8([0] * 4 + list(d2w(v[0]))) for v in vals]
    for mode, mname, fn in ((0, 'rn', lambda x: np.rint(x)), (1, 'floor', np.floor), (2, 'ceil', np.ceil), (3, 'trunc', np.trunc)):
        case('f2f_f64_f64_%s' % mname, ['raw 0x%016x' % f2f_word(3, 3, mode=mode, rint=True, src=20)], ins,
             [pad8(dres(fn(np.float64(v[0])))) for v in vals], 'f64 nan64')
    case('f2f_f64_f64_negabs', ['raw 0x%016x' % f2f_word(3, 3, neg=True, ab=True, src=20)], ins,
         [pad8(dres(-abs(np.float64(v[0])))) for v in vals], 'f64 nan64')

    def sat01(x):
        x = float(x)
        return 0.0 if math.isnan(x) or x <= 0.0 else (1.0 if x >= 1.0 else x)
    case('f2f_f32_f64_sat', ['raw 0x%016x' % f2f_word(2, 3, sat=True, src=20)], ins,
         [pad8([f32_bits(sat01(v[0]))]) for v in vals], 'f64')

    # F2I from f64 to 32/64-bit integers (saturating, NaN -> 0)
    def f2int(x, width, sgn, mode):
        x = float(x)
        if math.isnan(x):
            return 0
        x = [lambda y: float(np.rint(y)), math.floor, math.ceil, math.trunc][mode](x) if not math.isinf(x) else x
        lo = -(1 << (width - 1)) if sgn else 0
        hi = (1 << (width - 1)) - 1 if sgn else (1 << width) - 1
        if x <= lo:
            return lo
        if x >= hi:
            return hi
        return int(x)

    ivals = [[v] for v in [0.0, -0.0, 1.5, -1.5, 2.5, -2.5, 2147483647.5, 2147483648.0, -2147483649.0, 4294967296.0,
                           9.3e18, -9.3e18, 1.9e19, 9223372036854775807.0, -9223372036854775808.0, math.inf, -math.inf,
                           math.nan, 0.49999999999999994, 1e-310, 4503599627370497.0, -4503599627370497.5]]
    ivals += [[rng.choice([rng.uniform(-3e9, 3e9), rng.uniform(-2e19, 2e19), rng.uniform(-100, 100)])] for _ in range(N - len(ivals))]
    ins = [pad8([0] * 4 + list(d2w(v[0]))) for v in ivals]
    for isz, sgn, mode, nm in ((2, True, 0, 's32'), (2, False, 3, 'u32_trunc'), (3, True, 3, 's64_trunc'),
                               (3, False, 1, 'u64_floor'), (3, True, 0, 's64')):
        width = 32 if isz == 2 else 64

        def exp_words(x, width=width, sgn=sgn, mode=mode):
            v = f2int(x, width, sgn, mode) & ((1 << width) - 1)
            return [v & 0xffffffff, v >> 32] if width == 64 else [v]
        case('f2i_%s_f64' % nm, ['raw 0x%016x' % f2i_word(isz, sgn, 3, mode, src=20)], ins,
             [pad8(exp_words(v[0])) for v in ivals], 'f64')
    # F2I f32 -> s64 / u64
    fvals = [float(np.float32(rng.choice([rng.uniform(-1e19, 1e19), rng.uniform(-1e10, 1e10), rng.uniform(-5, 5)]))) for _ in range(N - 6)]
    fvals += [math.inf, -math.inf, math.nan, 9.3e18, -9.3e18, 1.9e19]
    ins = [pad8([0] * 4 + [f2u(v)]) for v in fvals]
    for sgn, nm in ((True, 's64'), (False, 'u64')):
        case('f2i_%s_f32' % nm, ['raw 0x%016x' % f2i_word(3, sgn, 2, 3, src=20)], ins,
             [pad8([f2int(np.float32(v), 64, sgn, 3) & 0xffffffff, (f2int(np.float32(v), 64, sgn, 3) & ((1 << 64) - 1)) >> 32])
              for v in fvals], 'f64')

    # I2F from 64-bit integers (R20:R21) to f64 / f32 / f16, and from 32-bit to f64
    def i64vals():
        out = [0, 1, -1, (1 << 63) - 1, -(1 << 63), (1 << 53) + 1, (1 << 53) + 3, -((1 << 53) + 1), (1 << 62) + (1 << 10) + 1,
               0x123456789abcdef, (1 << 24) + 1, (1 << 40) + (1 << 16) + (1 << 15), (1 << 40) + (1 << 16) + (1 << 15) + 1,
               # f32 ties that binary64 cannot hold the rest of (double rounding traps)
               (1 << 62) + (1 << 38) + 1, (1 << 62) + (1 << 38) - 1, (1 << 62) + 3 * (1 << 38) + 1, (1 << 62) + 3 * (1 << 38) - 1,
               -((1 << 62) + (1 << 38) + 1), -((1 << 62) + 3 * (1 << 38) - 1), (1 << 61) + (1 << 37) + 5, -(1 << 61) - 3 * (1 << 37) + 7,
               # f16 ties through the round-to-odd intermediate (I2F.F16)
               (1 << 55) + (1 << 44) + 1, (1 << 55) + 3 * (1 << 44) - 1]
        while len(out) < N:
            out.append(rng.choice([rng.randrange(-(1 << 63), 1 << 63), rng.randrange(-(1 << 30), 1 << 30),
                                   rng.randrange(1 << 54, 1 << 63) | 1]))
        return out

    iv = i64vals()
    ins = [pad8([0] * 4 + [v & 0xffffffff, (v >> 32) & 0xffffffff]) for v in iv]
    case('i2f_f64_s64', ['raw 0x%016x' % i2f_word(3, 3, True, src=20)], ins, [pad8(dres(float(v))) for v in iv], 'f64')
    case('i2f_f64_u64', ['raw 0x%016x' % i2f_word(3, 3, False, src=20)], ins,
         [pad8(dres(float(v & ((1 << 64) - 1)))) for v in iv], 'f64')
    # to f32 / f16 with one correct rounding from the exact integer (Python's int -> float is exact
    # to binary64; numpy's float32(int) rounds once from the integer as well)
    def int_to_f32_bits(v):
        # correctly rounded via the exact rational
        from fractions import Fraction
        f = np.float32(float(v))   # candidate (may double round); fix it with exact comparisons
        cands = [np.nextafter(f, np.float32(-np.inf)), f, np.nextafter(f, np.float32(np.inf))]
        best = min(cands, key=lambda c: (abs(Fraction(int(c)) - v) if not np.isinf(c) else Fraction(1 << 200),
                                         int(np.float32(c).view(np.uint32)) & 1))
        return int(np.float32(best).view(np.uint32))

    case('i2f_f32_s64', ['raw 0x%016x' % i2f_word(2, 3, True, src=20)], ins, [pad8([int_to_f32_bits(v)]) for v in iv], 'f64')
    case('i2f_f32_u64', ['raw 0x%016x' % i2f_word(2, 3, False, src=20)], ins,
         [pad8([int_to_f32_bits(v & ((1 << 64) - 1))]) for v in iv], 'f64')
    def int_to_f16_bits(v):
        from fractions import Fraction
        f = np.float16(float(v))
        cands = [np.nextafter(f, np.float16(-np.inf)), f, np.nextafter(f, np.float16(np.inf))]
        best = min(cands, key=lambda c: (abs(Fraction(int(c)) - v) if not np.isinf(c) else Fraction(1 << 200),
                                         int(np.float16(c).view(np.uint16)) & 1))
        # beyond the largest half (65504 + half an ulp): infinity
        if abs(v) >= 65520:
            return 0x7c00 if v > 0 else 0xfc00
        return int(np.float16(best).view(np.uint16))
    hv64 = [rng.randrange(-70000, 70000) for _ in range(N - 6)] + [65519, 65520, -65520, 2049, 2051, (1 << 62) + 1]
    ins16 = [pad8([0] * 4 + [v & 0xffffffff, (v >> 32) & 0xffffffff]) for v in hv64]
    case('i2f_f16_s64', ['raw 0x%016x' % i2f_word(1, 3, True, src=20)], ins16, [pad8([int_to_f16_bits(v)]) for v in hv64], 'f64')
    case('i2f_f64_s64_neg', ['raw 0x%016x' % i2f_word(3, 3, True, neg=True, src=20)], ins,
         [pad8(dres(float(-v if v != -(1 << 63) else -(1 << 63)))) for v in iv], 'f64')
    case('i2f_f64_s64_abs', ['raw 0x%016x' % i2f_word(3, 3, True, ab=True, src=20)], ins,
         [pad8(dres(float(abs(v) if v != -(1 << 63) else -(1 << 63)))) for v in iv], 'f64')
    i32v = [0, 1, -1, 0x7fffffff, -0x80000000, 123456789] + [rng.randrange(-(1 << 31), 1 << 31) for _ in range(N - 6)]
    ins = [pad8([0] * 4 + [v & 0xffffffff]) for v in i32v]
    case('i2f_f64_s32', ['raw 0x%016x' % i2f_word(3, 2, True, src=20)], ins, [pad8(dres(float(v))) for v in i32v], 'f64')
    case('i2f_f64_u32', ['raw 0x%016x' % i2f_word(3, 2, False, src=20)], ins,
         [pad8(dres(float(v & 0xffffffff))) for v in i32v], 'f64')


# =====================================================================================
# FP16x2 (D-P4.4-3): HADD2 HMUL2 HFMA2 HSET2 HSETP2 (+ _32I). Expected values: the exact result
# (rational arithmetic) rounded ONCE to binary16, ties to even; FTZ/FMZ/SAT as P4_4_DISENO.md says.
# =====================================================================================
from fractions import Fraction

HMAX = Fraction(65504)


def h2f(h):
    return float(np.array([h], dtype=np.uint16).view(np.float16)[0])


def f2h_exact(x):
    """binary16 bits of x (a float special or a Fraction), one rounding, ties to even"""
    if isinstance(x, float):
        if math.isnan(x):
            return 0x7e00
        if math.isinf(x):
            return 0x7c00 if x > 0 else 0xfc00
        x = Fraction(x)
    neg = x < 0
    a = -x if neg else x
    if a == 0:
        return 0x8000 if neg else 0
    # 2^-24 units below 2^-14 (denormals), else 11 significant bits
    e = 0
    t = a
    while t >= 2:
        t /= 2
        e += 1
    while t < 1:
        t *= 2
        e -= 1
    e = max(e, -14)
    q = a / Fraction(2) ** (e - 10)          # in units of the last place
    n = q.numerator // q.denominator
    rem = q - n
    if rem > Fraction(1, 2) or (rem == Fraction(1, 2) and n % 2 == 1):
        n += 1
    v = Fraction(n) * Fraction(2) ** (e - 10)
    if v > HMAX:   # rounds past the largest half: infinity (65520 and above)
        return 0xfc00 if neg else 0x7c00
    h = int(np.float16(float(v)).view(np.uint16))
    return h | (0x8000 if neg else 0)


def hval(h):
    """(float special or Fraction, sign) of a half"""
    f = h2f(h)
    if math.isnan(f) or math.isinf(f):
        return f
    return Fraction(f) if f != 0 else (-0.0 if h & 0x8000 else 0.0)


def is_neg_zero(v):
    return isinstance(v, float) and v == 0 and math.copysign(1, v) < 0


def to_float(v):
    return float(v)


def h_op(op, a, b, c=None):
    """IEEE semantics of one half operation on hval()s; returns float special or Fraction or signed 0.0"""
    fa, fb = float(a), float(b)
    if op == 'add':
        if any(isinstance(v, float) and (math.isnan(v) or math.isinf(v)) for v in (a, b)):
            return fa + fb
        sa, sb = Fraction(a) if not isinstance(a, float) else Fraction(0), Fraction(b) if not isinstance(b, float) else Fraction(0)
        r = sa + sb
        if r == 0:
            return -0.0 if is_neg_zero(a) and is_neg_zero(b) else 0.0
        return r
    if op == 'mul':
        if any(isinstance(v, float) and (math.isnan(v) or math.isinf(v)) for v in (a, b)):
            return fa * fb
        r = (Fraction(a) if not isinstance(a, float) else Fraction(0)) * (Fraction(b) if not isinstance(b, float) else Fraction(0))
        if r == 0:
            return -0.0 if (math.copysign(1, fa) < 0) != (math.copysign(1, fb) < 0) else 0.0
        return r
    # fma
    fc = float(c)
    if any(isinstance(v, float) and (math.isnan(v) or math.isinf(v)) for v in (a, b, c)):
        return fa * fb + fc
    p = (Fraction(a) if not isinstance(a, float) else Fraction(0)) * (Fraction(b) if not isinstance(b, float) else Fraction(0))
    r = p + (Fraction(c) if not isinstance(c, float) else Fraction(0))
    if r == 0:
        pneg = (math.copysign(1, fa) < 0) != (math.copysign(1, fb) < 0)
        if p == 0 and (c == 0):
            return -0.0 if pneg and is_neg_zero(c) else 0.0
        return 0.0
    return r


def h_ftz_val(v):
    if isinstance(v, Fraction) and abs(v) < Fraction(1, 1 << 14):
        return -0.0 if v < 0 else 0.0
    return v


def h_sat(v):
    if isinstance(v, float):
        if math.isnan(v) or v <= 0:
            return 0.0
        return 1.0 if v >= 1 else v
    return Fraction(0) if v <= 0 else (Fraction(1) if v >= 1 else v)


def h_negabs(v, neg, ab):
    if ab:
        v = abs(v) if not isinstance(v, float) else abs(v)
    if neg:
        v = -v
    return v


def h_lanes(word, swz):
    lo, hi = word & 0xffff, word >> 16
    if swz == 1:   # F32 model: the f32 rounded to f16, both halves
        f = struct.unpack('<f', struct.pack('<I', word))[0]
        h = f2h_exact(f if (math.isnan(f) or math.isinf(f)) else Fraction(f))
        return [h, h]
    return [lo if swz != 3 else hi, hi if swz != 2 else lo]


def h_out_bits(v, ftz):
    h = f2h_exact(v if not (isinstance(v, float) and v == 0) else Fraction(0)) if not (isinstance(v, float) and v == 0) else (0x8000 if math.copysign(1, v) < 0 else 0)
    if ftz and (h & 0x7c00) == 0 and (h & 0x3ff) != 0:
        h &= 0x8000
    return h


HEDGE = [0x0000, 0x8000, 0x3c00, 0xbc00, 0x3800, 0x7bff, 0xfbff, 0x7c00, 0xfc00, 0x7e00, 0x0001, 0x8001, 0x03ff, 0x0400,
         0x3555, 0x4248, 0xc900, 0x5640, 0x6800, 0x6801, 0x1400, 0x0200, 0x3bff, 0x3c01]


def hrand():
    k = rng.randrange(3)
    if k == 0:
        return rng.choice(HEDGE)
    if k == 1:
        return rng.getrandbits(16) & 0xfbff   # random, no NaN-heavy
    return f2h_exact(Fraction(rng.randrange(-4096, 4096), 64))


def hword():
    return hrand() | hrand() << 16


def h_word(top, **fl):
    w = top << 48 | PT
    for pos, v in fl.items():
        w |= v << int(pos[1:])
    return w


def hcase(name, op, form, ftz=0, sat=False, out=0, na=False, aa=False, sa=0, nb=False, ab=False, sb=0, nc=False, sc=0,
          bimm=None, flags='nan16', junk=False):
    """op: add/mul/fma; form: reg/cbuf/imm/imm32. A = R8, B = R20 (reg), C = R10."""
    ins, exp = [], []
    for t in range(N):
        A, Bw, Cw = hword(), hword(), hword()
        ins.append(pad8([A, 0, Cw, 0, Bw]))
    cb_word = ins[0][4]
    for t in range(N):
        A, Cw, Bw = ins[t][0], ins[t][2], ins[t][4]
        if form == 'cbuf':
            Bw = cb_word
        elif form in ('imm', 'imm32'):
            Bw = bimm
        if form == 'imm32' and op == 'fma':
            Cw = 0x12345678 if not junk else Cw
        av = [hval(h) for h in h_lanes(A, sa)]
        bv = [hval(h) for h in h_lanes(Bw, sb)]
        cv = [hval(h) for h in h_lanes(Cw, sc)]
        res = []
        for k in range(2):
            a_, b_, c_ = av[k], bv[k], cv[k]
            if ftz:
                a_, b_, c_ = h_ftz_val(a_), h_ftz_val(b_), h_ftz_val(c_)
            a_ = h_negabs(a_, na, aa)
            b_ = h_negabs(b_, nb, ab)
            c_ = h_negabs(c_, nc, False)
            if op == 'mul' and ftz == 2 and (float(a_) == 0 or float(b_) == 0):
                r = 0.0
            elif op == 'fma' and ftz == 2 and (float(a_) == 0 or float(b_) == 0):
                r = h_op('add', 0.0, c_)
            else:
                r = h_op(op, a_, b_, c_)
            if sat:
                r = h_sat(r)
            res.append(h_out_bits(r, ftz != 0))
        old = 0xdeadbeef if junk else 0
        if out == 0:
            word = res[0] | res[1] << 16
        elif out == 1:
            word = f2u(h2f(res[0]))
        elif out == 2:
            word = (old & 0xffff0000) | res[0]
        else:
            word = (old & 0x0000ffff) | res[1] << 16
        exp.append(pad8([word]))
    # the instruction word
    if op in ('add', 'mul') and form != 'imm32':
        if form == 'reg':
            top = 0x5d10 if op == 'add' else 0x5d08
            fl = dict(b32=int(sat), b31=int(nb), b30=int(ab), b28=sb, b20=20)
        elif form == 'cbuf':
            top = 0x7a80 if op == 'add' else 0x7880
            fl = dict(b52=int(sat), b56=int(nb) if op == 'add' else 0, b54=int(ab), b34=2, b20=0x10 // 4)
        else:
            top = 0x7a00 if op == 'add' else 0x7800
            lo, hi = bimm & 0xffff, bimm >> 16
            fl = dict(b52=int(sat), b20=(lo >> 6) & 0x1ff, b29=lo >> 15, b30=(hi >> 6) & 0x1ff, b56=hi >> 15)
        fl.update(dict(b39=ftz, b49=out, b43=int(na), b44=int(aa), b47=sa, b8=8))
        w = h_word(top, **fl)
    elif op == 'fma' and form != 'imm32':
        if form == 'reg':
            fl = dict(b37=ftz, b32=int(sat), b49=out, b47=sa, b31=int(nb), b28=sb, b20=20, b30=int(nc), b35=sc, b39=10, b8=8)
            w = h_word(0x5d00, **fl)
        elif form == 'cbuf':   # B = c2[0x10], C = R10 swizzled
            fl = dict(b57=ftz, b52=int(sat), b49=out, b47=sa, b56=int(nb), b34=2, b20=0x10 // 4, b51=int(nc), b53=sc, b39=10, b8=8)
            w = h_word(0x7080, **fl)
        else:
            lo, hi = bimm & 0xffff, bimm >> 16
            fl = dict(b57=ftz, b52=int(sat), b49=out, b47=sa, b20=(lo >> 6) & 0x1ff, b29=lo >> 15, b30=(hi >> 6) & 0x1ff,
                      b56=hi >> 15, b51=int(nc), b53=sc, b39=10, b8=8)
            w = h_word(0x7000, **fl)
    else:   # _32I
        lo, hi = bimm & 0xffff, bimm >> 16
        if op == 'add':
            w = h_word(0x2c00, b55=int(ftz != 0), b52=int(sat), b56=int(na), b53=sa, b36=hi, b20=lo, b8=8)
        elif op == 'mul':
            w = h_word(0x2a00, b55=ftz, b52=int(sat), b53=sa, b36=hi, b20=lo, b8=8)
        else:
            w = h_word(0x2800, b55=ftz, b52=int(nc), b53=sa, b36=hi, b20=lo, b8=8)
    body = []
    if junk or (form == 'imm32' and op == 'fma'):
        body.append('mov32i $r0 0x%x 0xf' % (0xdeadbeef if junk else 0x12345678))
    body.append('raw 0x%016x' % w)
    case(name, body, ins, exp, flags)


def imm9_word(hi, lo):
    """a B word an immediate form can hold: the low 6 bits of each half are 0"""
    return (lo & 0xffc0) | (hi & 0xffc0) << 16


hcase('hadd2', 'add', 'reg')
hcase('hadd2_ftz_sat', 'add', 'reg', ftz=1, sat=True)
hcase('hadd2_negabs_swz', 'add', 'reg', na=True, aa=True, sa=2, nb=True, sb=3)
hcase('hadd2_absb_h1h1', 'add', 'reg', ab=True, sa=3, sb=2)
hcase('hadd2_mrg_h0', 'add', 'reg', out=2, junk=True)
hcase('hadd2_mrg_h1', 'add', 'reg', out=3, junk=True)
hcase('hadd2_f32out', 'add', 'reg', out=1, flags='nan32')
hcase('hadd2_f32src', 'add', 'reg', sa=1)
hcase('hadd2_cbuf', 'add', 'cbuf', nb=True, ab=True)
hcase('hadd2_imm', 'add', 'imm', bimm=imm9_word(0xbc00, 0x3e40))
hcase('hadd2_32i', 'add', 'imm32', bimm=0x3c00b555, na=True, sa=2)
hcase('hadd2_32i_ftz_sat', 'add', 'imm32', bimm=0x0001c900, ftz=1, sat=True)
hcase('hmul2', 'mul', 'reg')
hcase('hmul2_ftz', 'mul', 'reg', ftz=1, aa=True, nb=True, sb=2)
hcase('hmul2_fmz_sat', 'mul', 'reg', ftz=2, sat=True)
hcase('hmul2_cbuf', 'mul', 'cbuf', na=True, ab=True)
hcase('hmul2_imm', 'mul', 'imm', bimm=imm9_word(0x4100, 0xb800), sa=3)
hcase('hmul2_32i', 'mul', 'imm32', bimm=0x4248bc00, ftz=2)
hcase('hfma2', 'fma', 'reg')
hcase('hfma2_neg_swz', 'fma', 'reg', nb=True, sb=3, nc=True, sc=2, sa=2)
hcase('hfma2_ftz_sat', 'fma', 'reg', ftz=1, sat=True)
hcase('hfma2_fmz', 'fma', 'reg', ftz=2)
hcase('hfma2_mrg_h1', 'fma', 'reg', out=3, junk=True)
hcase('hfma2_cbuf', 'fma', 'cbuf', nb=True, nc=True, sc=3)
hcase('hfma2_imm', 'fma', 'imm', bimm=imm9_word(0x3c40, 0xc200), nc=True)
hcase('hfma2_32i', 'fma', 'imm32', bimm=0x3800c000, nc=True)


# FMA ties: a*b exactly halfway between two halves only after a tiny c (double rounding traps)
def hfma_ties():
    ins, exp = [], []
    for t in range(N):
        while True:
            a = f2h_exact(Fraction(rng.randrange(1025, 2047), 1024))
            b = f2h_exact(Fraction(rng.randrange(1025, 2047), 1024))
            p = hval(a) * hval(b)
            c = rng.choice([0x0001, 0x8001, 0x0002, 0x8002, 0x0010, 0x8010])   # tiny denormals
            if True:
                break
        A = a | a << 16
        Bw = b | b << 16
        Cw = c | (c ^ 0x8000) << 16
        ins.append(pad8([A, 0, Cw, 0, Bw]))
        res = [f2h_exact(h_op('fma', hval(a), hval(b), hval(cc))) for cc in (c, c ^ 0x8000)]
        exp.append(pad8([res[0] | res[1] << 16]))
    w = h_word(0x5d00, b20=20, b39=10, b8=8)
    case('hfma2_ties', ['raw 0x%016x' % w], ins, exp, 'nan16')


hfma_ties()

HCMP = ['f', 'lt', 'eq', 'le', 'gt', 'ne', 'ge', 'num', 'nan', 'ltu', 'equ', 'leu', 'gtu', 'neu', 'geu', 't']


def hcmp(cond, a, b):
    a, b = float(a), float(b)
    if cond == 15:
        return True
    if cond == 0:
        return False
    return FCMP[HCMP[cond]](a, b)


def hset_case(name, setp, form, cond, bop=0, bf=False, h_and=False, ftz=False, na=False, aa=False, sa=0, nb=False,
              ab=False, sb=0, bimm=None, pnot=False):
    ins, exp = [], []
    for t in range(N):
        ins.append(pad8([hword(), 0, 0, 0, hword()]))
    cb_word = ins[0][4]
    for t in range(N):
        A, Bw = ins[t][0], ins[t][4]
        if form == 'cbuf':
            Bw = cb_word
        elif form == 'imm':
            Bw = bimm
        av = [hval(h) for h in h_lanes(A, sa)]
        bv = [hval(h) for h in h_lanes(Bw, sb)]
        ts = []
        for k in range(2):
            a_, b_ = av[k], bv[k]
            if ftz:
                a_, b_ = h_ftz_val(a_), h_ftz_val(b_)
            ts.append(hcmp(cond, h_negabs(a_, na, aa), h_negabs(b_, nb, ab)))
        p = not pnot   # PT, or !PT
        def bo(x):
            return [x and p, x or p, x != p][bop]
        if setp:
            if h_and:
                q = ts[0] and ts[1]
                exp.append(pad8([int(bo(q)), int(bo(not q))]))
            else:
                exp.append(pad8([int(bo(ts[0])), int(bo(ts[1]))]))
        else:
            one = 0x3c00 if bf else 0xffff
            exp.append(pad8([(one if bo(ts[0]) else 0) | (one if bo(ts[1]) else 0) << 16]))
    if setp:
        top = {'reg': 0x5d20, 'cbuf': 0x7e80, 'imm': 0x7e00}[form]
        fl = dict(b45=bop, b6=int(ftz), b43=int(na), b44=int(aa), b47=sa, b39=7, b42=int(pnot), b3=1, b0=2, b8=8)
        if form == 'reg':
            fl.update(b35=cond, b49=int(h_and), b31=int(nb), b30=int(ab), b28=sb, b20=20)
        else:
            fl.update(b49=cond, b53=int(h_and))
            if form == 'cbuf':
                fl.update(b56=int(nb), b54=int(ab), b34=2, b20=0x10 // 4)
    else:
        top = {'reg': 0x5d18, 'cbuf': 0x7c80, 'imm': 0x7c00}[form]
        fl = dict(b45=bop, b43=int(na), b44=int(aa), b47=sa, b39=7, b42=int(pnot), b8=8)
        if form == 'reg':
            fl.update(b35=cond, b49=int(bf), b50=int(ftz), b31=int(nb), b30=int(ab), b28=sb, b20=20)
        else:
            fl.update(b49=cond, b53=int(bf), b54=int(ftz))
            if form == 'cbuf':
                fl.update(b56=int(nb), b34=2, b20=0x10 // 4)
    if form == 'imm':
        lo, hi = bimm & 0xffff, bimm >> 16
        fl.update(b20=(lo >> 6) & 0x1ff, b29=lo >> 15, b30=(hi >> 6) & 0x1ff, b56=hi >> 15)
    w = h_word(top, **fl)
    body = ['raw 0x%016x' % w]
    if setp:
        body += ['sel $r0 $r255 0x1 not $p1', 'sel $r1 $r255 0x1 not $p2']
    case(name, body, ins, exp, '')


for cond in range(16):
    hset_case('hsetp2_%s' % HCMP[cond], True, 'reg', cond)
hset_case('hsetp2_hand', True, 'reg', 1, h_and=True)
hset_case('hsetp2_hand_or_not', True, 'reg', 9, h_and=True, bop=1, pnot=True)
hset_case('hsetp2_xor_mods', True, 'reg', 3, bop=2, na=True, ab=True, sa=3, sb=2, ftz=True)
hset_case('hsetp2_cbuf', True, 'cbuf', 4, nb=True, ab=True)
hset_case('hsetp2_imm', True, 'imm', 2, bimm=imm9_word(0x3c00, 0xc000))
hset_case('hset2_lt', False, 'reg', 1)
hset_case('hset2_bf_geu', False, 'reg', 14, bf=True)
hset_case('hset2_or_not_mods', False, 'reg', 5, bop=1, pnot=True, na=True, sb=3, ftz=True)
hset_case('hset2_cbuf', False, 'cbuf', 6, nb=True)
hset_case('hset2_imm_bf', False, 'imm', 1, bf=True, bimm=imm9_word(0x4000, 0x0000))


# =====================================================================================
# Flow (D-P4.4-4): targets read from a constant buffer, PEXIT/EXIT, PLONGJMP/LONGJMP, BPT, RTT.
# The targets live in c2 at 0x7f0.. (words 4..7 of invocation 63, its R20..R23 inputs).
# =====================================================================================
FLOW_TAB = 0x7f0
OPC = {'bra': 0xe240, 'brx': 0xe250, 'jmp': 0xe210, 'jmx': 0xe200, 'cal': 0xe260, 'jcal': 0xe220, 'ssy': 0xe290,
       'pbk': 0xe2a0, 'pcnt': 0xe2b0, 'pret': 0xe270, 'plongjmp': 0xe280, 'pexit': 0xe230}
PRED_CC = {'bra', 'brx', 'jmp', 'jmx'}            # T(pred) + T(f0f8_0): PT, CC.T
PRED_ONLY = {'jcal', 'pexit'}


def fw(op, cbuf=None, target=None, absolute=False):
    """a flow word: immediate target label, or cbuf=(bank, byte offset) (BRX/JMX: + R8)"""
    def make(addr, labels):
        w = OPC[op] << 48
        if op in PRED_CC:
            w |= PT | 0xf
        elif op in PRED_ONLY:
            w |= PT
        if cbuf is not None:
            bank, off = cbuf
            w |= 0x20 | bank << 36 | (off & 0xffff) << 20
            if op in ('brx', 'jmx'):
                w |= 8 << 8
            return w
        t = labels[target]
        if absolute:
            return w | t << 20
        return w | ((t - (addr + 8)) & 0xffffff) << 20
    return make


def simple(op):
    return lambda addr, labels: {'sync': 0xf0f8, 'brk': 0xe340, 'cont': 0xe350, 'ret': 0xe320, 'exit': 0xe300,
                                 'longjmp': 0xe310}[op] << 48 | PT | 0xf


def flow_case(name, body, targets, expect_fn, flags=''):
    """targets(labels) -> the 4 words at c2[0x7f0..0x7fc]; expect_fn(t, ins) -> R0..R7"""
    # resolve once to know the labels (the same layout as case() builds)
    full = PROLOGUE + body + EPILOGUE
    labels, k = {}, 0
    for ln in full:
        if isinstance(ln, tuple) and ln[0] == 'label':
            labels[ln[1]] = insn_addr(k)
        else:
            k += 1
    tab = targets(labels)
    ins = []
    for t in range(N):
        row = [rng.getrandbits(32) for _ in range(4)] + [0, 0, 0, 0]
        if t == 63:
            row[4:8] = [u32(x) for x in tab]
        ins.append(row)
    exp = [pad8(expect_fn(t, ins[t], labels)) for t in range(N)]
    case(name, body, ins, exp, flags)


def body_jump(op, form, **kw):
    """R0 = 1; jump (op) to L; R0 = 0xbad (skipped); L: R1 = 2"""
    return ['mov32i $r0 0x1 0xf', fw(op, **form), 'mov32i $r0 0xbad 0xf', ('label', 'L'), 'mov32i $r1 0x2 0xf']


for op in ('bra', 'jmp'):   # relative: L - (address of the jump + 8); absolute: L
    absolute = op == 'jmp'

    def mk(op=op, absolute=absolute):
        body = ['mov32i $r0 0x1 0xf', ('label', 'J'), fw(op, cbuf=(2, FLOW_TAB)), 'mov32i $r0 0xbad 0xf', ('label', 'L'),
                'mov32i $r1 0x2 0xf']
        flow_case('%s_cbuf' % op, body,
                  lambda lb: [lb['L'] if absolute else lb['L'] - (lb['J'] + 8), 0, 0, 0],
                  lambda t, i, lb: [1, 2])
    mk()

# BRX/JMX: c2[R8 + 0x7f0]: R8 = 0 or 4 per invocation -> two different targets
for op in ('brx', 'jmx'):
    absolute = op == 'jmx'
    def mk(op=op, absolute=absolute):
        body = ['lop32i and $r8 $r40 0x4', 'mov32i $r0 0x1 0xf', ('label', 'J'), fw(op, cbuf=(2, FLOW_TAB)),
                'mov32i $r0 0xbad 0xf', ('label', 'L1'), 'mov32i $r1 0x2 0xf', fw('bra', target='E'), ('label', 'L2'),
                'mov32i $r1 0x3 0xf', ('label', 'E')]
        def tab(lb):
            base = 0 if absolute else lb['J'] + 8
            return [lb['L1'] - base, lb['L2'] - base, 0, 0]
        flow_case('%s_cbuf' % op, body, tab, lambda t, i, lb: [1, 2 if (t & 4) == 0 else 3])
    mk()

# CRS pushes with a cbuf target and their pops
for push, pop in (('ssy', 'sync'), ('pbk', 'brk'), ('pcnt', 'cont'), ('pret', 'ret')):
    def mk(push=push, pop=pop):
        body = [('label', 'P'), fw(push, cbuf=(2, FLOW_TAB)), 'mov32i $r0 0x1 0xf', simple(pop), 'mov32i $r0 0xbad 0xf',
                ('label', 'L'), 'mov32i $r1 0x2 0xf']
        flow_case('%s_cbuf' % push, body, lambda lb: [lb['L'] - (lb['P'] + 8), 0, 0, 0], lambda t, i, lb: [1, 2])
    mk()

# CAL / JCAL with a cbuf target: the subroutine sets R1 and returns after the call
for op in ('cal', 'jcal'):
    absolute = op == 'jcal'
    def mk(op=op, absolute=absolute):
        body = ['mov32i $r0 0x1 0xf', ('label', 'C'), fw(op, cbuf=(2, FLOW_TAB)), 'iadd32i $r0 $r0 0x10', fw('bra', target='E'),
                ('label', 'S'), 'mov32i $r1 0x5 0xf', simple('ret'), ('label', 'E')]
        flow_case('%s_cbuf' % op, body, lambda lb: [lb['S'] if absolute else lb['S'] - (lb['C'] + 8), 0, 0, 0],
                  lambda t, i, lb: [0x11, 5])
    mk()

# PEXIT / EXIT and PLONGJMP / LONGJMP (models, by symmetry with PRET/RET and PBK/BRK)
flow_case('pexit_exit', [fw('pexit', target='L'), 'mov32i $r0 0x1 0xf', simple('exit'), 'mov32i $r0 0xbad 0xf',
                         ('label', 'L'), 'mov32i $r1 0x7 0xf'], lambda lb: [0] * 4, lambda t, i, lb: [1, 7])
flow_case('plongjmp_longjmp', [fw('plongjmp', target='L'), fw('ssy', target='L'), 'mov32i $r0 0x1 0xf', simple('longjmp'),
                               'mov32i $r0 0xbad 0xf', ('label', 'L'), 'mov32i $r1 0x9 0xf'],
          lambda lb: [0] * 4, lambda t, i, lb: [1, 9])
flow_case('plongjmp_cbuf', [('label', 'P'), fw('plongjmp', cbuf=(2, FLOW_TAB)), 'mov32i $r0 0x1 0xf', simple('longjmp'),
                            'mov32i $r0 0xbad 0xf', ('label', 'L'), 'mov32i $r1 0x9 0xf'],
          lambda lb: [lb['L'] - (lb['P'] + 8), 0, 0, 0], lambda t, i, lb: [1, 9])

# BPT: PAUSE does nothing; TRAP ends the invocation (odd invocations jump around it: they store)
flow_case('bpt_pause', ['mov32i $r0 0x1 0xf', 'bpt pause 0x0', 'mov32i $r1 0x2 0xf'], lambda lb: [0] * 4,
          lambda t, i, lb: [1, 2])
flow_case('bpt_trap', ['lop32i and $r9 $r40 0x1', 'isetp ne and $p1 0x1 $r9 0x0 0x1', 'mov32i $r0 0x1 0xf',
                       lambda a, lb: (0xe240 << 48) | (1 << 16) | 0xf | (((lb['K'] - (a + 8)) & 0xffffff) << 20),
                       'bpt trap 0x0', ('label', 'K'), 'mov32i $r1 0x2 0xf'],
          lambda lb: [0] * 4, lambda t, i, lb: [1, 2] if t & 1 else [0, 0])
flow_case('rtt', ['lop32i and $r9 $r40 0x1', 'isetp ne and $p1 0x1 $r9 0x0 0x1', 'mov32i $r0 0x1 0xf',
                  lambda a, lb: (0xe240 << 48) | (1 << 16) | 0xf | (((lb['K'] - (a + 8)) & 0xffffff) << 20),
                  'rtt', ('label', 'K'), 'mov32i $r1 0x2 0xf'],
          lambda lb: [0] * 4, lambda t, i, lb: [1, 2] if t & 1 else [0, 0])

# =====================================================================================
# CSET / CSETP after IADD.CC (integer flags: Z, S, C = carry out, O = signed overflow) and FADD.CC
# (Z, S of the float, O = NaN)
# =====================================================================================
CSET_C = ['f', 'lt', 'eq', 'le', 'gt', 'ne', 'ge', 'num', 'nan', 'ltu', 'equ', 'leu', 'gtu', 'neu', 'geu', 't',
          'off', 'lo', 'sff', 'ls', 'hi', 'sft', 'hs', 'oft']


def cc_eval(cond, z, sgn, c, o):
    lt = sgn != o
    tbl = [False, lt and not z, z, lt or z, not lt and not z, not z, not lt or z, not o, o,
           (lt and not z) or o, z or o, lt or z or o, (not lt and not z) or o, (not z) or o, (not lt or z) or o, True,
           not o, not c, not sgn, (not c) or z, c and not z, sgn, c, o]
    return tbl[cond]


def iadd_flags(a, b):
    r = (a + b) & 0xffffffff
    c = (a + b) >> 32 != 0
    sa, sb, sr = a >> 31, b >> 31, r >> 31
    o = sa == sb and sr != sa
    return r == 0, sr == 1, c, o


IEDGE = [0, 1, 0xffffffff, 0x7fffffff, 0x80000000, 0x80000001, 5, 0xfffffffb]


def iops():
    out = []
    for t in range(N):
        if t < 32:
            out.append((IEDGE[t % 8], IEDGE[(t // 8 + t) % 8]))
        else:
            out.append((rng.getrandbits(32), rng.choice([rng.getrandbits(32), 0, 1, 0xffffffff])))
    return out


def cset_word(cond, setp=False, bop=0, bf=False, pnot=False):
    if setp:
        return (0x50a0 << 48) | cond << 8 | bop << 45 | 7 << 39 | int(pnot) << 42 | 1 << 3 | 2 | PT
    return (0x5098 << 48) | cond << 8 | bop << 45 | int(bf) << 44 | 7 << 39 | int(pnot) << 42 | PT


iv2 = iops()
for cond in range(24):
    cn = CSET_C[cond]
    ins = [pad8([a, 0, 0, 0, b]) for a, b in iv2]
    exp = []
    for a, b in iv2:
        tst = cc_eval(cond, *iadd_flags(a, b))
        exp.append(pad8([0xffffffff if tst else 0, int(tst), int(not tst)]))
    case('cset_%s' % cn, ['iadd cc $r9 $r8 $r20', 'raw 0x%016x' % cset_word(cond), 'raw 0x%016x' % cset_word(cond, True),
                          'sel $r1 $r255 0x1 not $p1', 'sel $r2 $r255 0x1 not $p2'], ins, exp, '')
# BF and the boolean operation with a predicate; float flags from FADD.CC
fv2 = [(rng.choice([1.0, -1.0, 0.0, -0.0, math.nan, 2.5, -3.0]), rng.choice([1.0, -1.0, 0.0, math.nan, -2.5, 3.0])) for _ in range(N)]
ins = [pad8([f2u(a), 0, 0, 0, f2u(b)]) for a, b in fv2]
for cond in (1, 2, 7, 8, 9, 13):
    exp = []
    for a, b in fv2:
        r = np.float32(a) + np.float32(b)
        z, sg, o = bool(r == 0), bool(r < 0), bool(np.isnan(r))
        tst = cc_eval(cond, z, sg, False, o)
        exp.append(pad8([f2u(1.0) if (tst or False) else 0]))
    case('cset_float_%s' % CSET_C[cond], ['fadd cc $r9 $r8 $r20', 'raw 0x%016x' % cset_word(cond, bop=1, bf=True, pnot=True)],
         ins, exp, '')

# =====================================================================================
# FCHK.DIVIDE (D-P4.4-6, model: true unless a and b are normal with unbiased exponents in [-100, 100]
# and their difference in [-100, 100])
# =====================================================================================
fch = [(rng.choice([rng.uniform(-1e6, 1e6), 1e-35, 1e35, 0.0, math.inf, math.nan, 1e-40, 2.0 ** 100, 2.0 ** 101, 2.0 ** -100,
                    2.0 ** -101, 3.0]),
        rng.choice([rng.uniform(-1e6, 1e6), 1e-35, 1e35, 0.0, -0.0, math.inf, math.nan, 1e-40, 2.0 ** -100, 2.0 ** 100, 7.0]))
       for _ in range(N)]


def fchk_model(a, b):
    def e(x):
        return (f2u(x) >> 23) & 0xff
    ea, eb = e(a), e(b)
    ok = 27 <= ea < 228 and 27 <= eb < 228 and 28 <= ea - eb + 128 < 229
    return not ok


ins = [pad8([f2u(a), 0, 0, 0, f2u(b)]) for a, b in fch]
case('fchk_divide', ['fchk divide $p1 $r8 $r20', 'sel $r0 $r255 0x1 not $p1'], ins, [pad8([int(fchk_model(a, b))]) for a, b in fch], '')

# =====================================================================================
# VOTE (D-P4.4-5): results that do not depend on the subgroup size (4 on SwiftShader, 8 on lavapipe)
# =====================================================================================
ins = [pad8([0] * 8) for _ in range(N)]
# a predicate uniform in each aligned block of 32: any = all = p, eq = true; own bit of the ballot
vbody = ['shr $r9 $r40 0x5', 'lop32i and $r9 $r9 0x1', 'isetp ne and $p1 0x1 $r9 0x0 0x1',
         'vote any $r0 $p2 $p1', 'sel $r1 $r255 0x1 not $p2', 'vote all $r2 $p3 $p1', 'sel $r3 $r255 0x1 not $p3',
         'vote eq $r4 $p4 $p1', 'sel $r5 $r255 0x1 not $p4', 'lop32i and $r6 $r40 0x1f', 'shr $r6 $r0 $r6',
         'lop32i and $r6 $r6 0x1']
exp = []
for t in range(N):
    p = (t >> 5) & 1
    exp.append(pad8([0, p, 0, p, 0, 1, p, 0]))   # ballots in R0/R2/R4 depend on the subgroup size: compared below
case('vote_uniform', vbody + ['mov32i $r0 0x0 0xf', 'mov32i $r2 0x0 0xf', 'mov32i $r4 0x0 0xf'], ins, exp, '')
# a mixed predicate (lane & 1): own and neighbour bits of the ballot (same subgroup for any size >= 2)
vbody2 = ['lop32i and $r9 $r40 0x1', 'isetp ne and $p1 0x1 $r9 0x0 0x1', 'vote any $r0 $p2 $p1', 'sel $r1 $r255 0x1 not $p2',
          'lop32i and $r6 $r40 0x1f', 'shr $r2 $r0 $r6', 'lop32i and $r2 $r2 0x1', 'lop32i xor $r7 $r6 0x1',
          'shr $r3 $r0 $r7', 'lop32i and $r3 $r3 0x1', 'vote all $r4 $p3 $p1', 'sel $r4 $r255 0x1 not $p3',
          'vote eq $r5 $p4 $p1', 'sel $r5 $r255 0x1 not $p4', 'mov32i $r0 0x0 0xf', 'mov32i $r6 0x0 0xf', 'mov32i $r7 0x0 0xf']
exp = [pad8([0, 1, t & 1, (t & 1) ^ 1, 0, 0]) for t in range(N)]
case('vote_mixed', vbody2, ins, exp, '')

# =====================================================================================
# IMADSP (D-P4.4-8, model) and IDP (PTX dp4a / dp2a)
# =====================================================================================
def sx(v, b):
    v &= (1 << b) - 1
    return v - (1 << b) if v >> (b - 1) else v


def ext_field(v, sgn, kind):
    if kind == 0:
        return sx(v, 32) if sgn else v
    if kind == 1:
        return sx(v, 24) if sgn else v & 0xffffff
    h = (v >> 16) & 0xffff if kind == 3 else v & 0xffff
    return sx(h, 16) if sgn else h


iins = [pad8([rng.getrandbits(32), 0, rng.getrandbits(32), 0, rng.getrandbits(32)]) for _ in range(N)]
for ta, tb, tc in ((0, 0, 0), (1, 1, 1), (2, 0, 2), (3, 3, 1), (6, 2, 4), (7, 3, 5), (5, 1, 3), (4, 2, 0)):
    # A: f(48,3) u32 s32 u24 s24 u16h0 s16h0 u16h1 s16h1; B: f(53,2) u24 s24 u16h0 s16h0; C (sign = A's bit 48):
    # 0 u32, 1 s32, 2 u24, 3 s24, 4 u16h0, 5 s16h0 -> kind bits 51-52
    sa = ta & 1
    if (tc & 1) != sa:
        tc ^= 1
    w = (0x5a80 << 48) | (ta << 48) | (tb << 53) | ((tc >> 1) << 51) | (20 << 20) | (10 << 39) | (8 << 8) | PT
    exp = []
    for row in iins:
        a, c, b = row[0], row[2], row[4]
        r = ext_field(a, sa, ta >> 1) * ext_field(b, tb & 1, 1 if tb < 2 else 2) + ext_field(c, sa, [0, 1, 2][tc >> 1])
        exp.append(pad8([r & 0xffffffff]))
    case('imadsp_%d%d%d' % (ta, tb, tc), ['raw 0x%016x' % w], iins, exp, '')

for mode, bsg in ((0, 0), (2, 1), (0, 1), (2, 0), (1, 0), (3, 1), (5, 1), (7, 0)):
    w = (0x53f8 << 48) | (mode << 48) | (bsg << 47) | (20 << 20) | (10 << 39) | (8 << 8) | PT
    exp = []
    for row in iins:
        a, c, b = row[0], row[2], row[4]
        bb = [sx((b >> (8 * k)) & 0xff, 8) if bsg else (b >> (8 * k)) & 0xff for k in range(4)]
        if mode in (0, 2):
            aa = [sx((a >> (8 * k)) & 0xff, 8) if mode == 2 else (a >> (8 * k)) & 0xff for k in range(4)]
            r = c + sum(x * y for x, y in zip(aa, bb))
        else:
            hs = [sx((a >> (16 * k)) & 0xffff, 16) if mode in (3, 7) else (a >> (16 * k)) & 0xffff for k in range(2)]
            off = 2 if mode >= 5 else 0
            r = c + hs[0] * bb[off] + hs[1] * bb[off + 1]
        exp.append(pad8([r & 0xffffffff]))
    case('idp_%d_%s' % (mode, 's8' if bsg else 'u8'), ['raw 0x%016x' % w], iins, exp, '')

# =====================================================================================
# System (D-P4.4-9 models), BAR.RED with B2R, SAM/RAM
# =====================================================================================
z8 = [pad8([0] * 8) for _ in range(N)]
flow_case('lepc', [('label', 'X'), 'lepc $r0'], lambda lb: [0] * 4, lambda t, i, lb: [lb['X']])
flow_case('crsptr', [fw('ssy', target='L1'), fw('ssy', target='L2'), 'getcrsptr $r0', 'mov32i $r9 0x4 0xf', 'setcrsptr $r9',
                     simple('sync'), 'mov32i $r1 0xbad 0xf', ('label', 'L2'), 'mov32i $r1 0xbad 0xf', ('label', 'L1'),
                     'mov32i $r2 0x3 0xf'], lambda lb: [0] * 4, lambda t, i, lb: [8, 0, 3])
case('lmembase', ['getlmembase $r0', 'mov32i $r9 0x1234 0xf', 'setlmembase $r9', 'getlmembase $r1'], z8,
     [pad8([0, 0x1234]) for _ in range(N)], '')
case('sam_ram', ['sam', 'mov32i $r0 0x1 0xf', 'ram', 'mov32i $r1 0x2 0xf'], z8, [pad8([1, 2]) for _ in range(N)], '')
case('r2b', ['r2b result 0x0 $r20', 'mov32i $r0 0x1 0xf'], z8, [pad8([1]) for _ in range(N)], '')


def bar_word(mode):
    """NAK's fields: mode bits 32-34 (1 ARV, 2 RED), reduction bits 35-36; id 0 and count 0 (immediates); $p1"""
    m, r = {0x02: (2, 0), 0x0a: (2, 1), 0x12: (2, 2), 0x81: (1, 0)}[mode]
    return (0xf0a8 << 48) | (m << 32) | (r << 35) | (3 << 43) | (1 << 39) | PT


for mode, nm, fn in ((0x02, 'popc', lambda ps: sum(ps)), (0x0a, 'and', lambda ps: int(all(ps))), (0x12, 'or', lambda ps: int(any(ps)))):
    for pname, pf in (('quarter', lambda t: t % 4 == 0), ('all', lambda t: True), ('one', lambda t: t == 37), ('none', lambda t: False)):
        ps = [pf(t) for t in range(N)]
        # p1 from a per-invocation input (R8 = 1 / 0)
        ins = [pad8([int(p)]) for p in ps]
        case('bar_red_%s_%s' % (nm, pname), ['isetp ne and $p1 0x1 $r8 0x0 0x1', 'raw 0x%016x' % bar_word(mode), 'b2r $r0 0x0'],
             ins, [pad8([fn(ps)]) for _ in range(N)], '')
case('bar_arrive', ['mov32i $r0 0x1 0xf', 'raw 0x%016x' % bar_word(0x81), 'mov32i $r1 0x2 0xf'], z8, [pad8([1, 2]) for _ in range(N)], '')


# =====================================================================================
# Textures and images (P4.4 §3, D-P4.4-11/12): the T2-T texture model (the same formulas as
# gen_shader_t2t.py and tests/test_shader_t2t.cpp: every texel holds its address)
# =====================================================================================
TEX_BASE = 0xa0 // 4        # deko3d compute: texture handles at c0[0xa0 + 4·slot]
IMG_BASE = 0x120 // 4       # images at c0[0x120 + 4·slot]
def texel(slot, x, y, k, l):
    return (u32(x + 1000 * l), u32(y + 1000 * k), u32((x * 3 + y * 5 + k * 7 + l * 11) & 0xff), u32(0xb00 + slot))


def depth(x, y, k, l):
    return ((x * 7 + y * 3 + k * 5 + l) % 16) / 16.0 + 1.0 / 32.0


class Tex:
    """slot (handle word index from TEX_BASE/IMG_BASE), view, fmt, w, h, d (layers / depth / 6),
    levels; fmt: u RGBA32UI, f RGBA32F, d D32 (compare LESS), r R32UI, s R32I, v RG32UI, 8 R8UI,
    w R16UI; handle: explicit c0 byte offset (bindless tests) or None (the slot's)."""

    def __init__(self, slot, view, fmt, w, h=1, d=1, levels=1, storage=False, handle=None, compare=False,
                 table='', index=0, address=2):
        self.slot, self.view, self.fmt, self.w, self.h, self.d, self.levels = slot, view, fmt, w, h, d, levels
        self.storage, self.compare = storage, compare
        self.handle = handle if handle is not None else 4 * ((IMG_BASE if storage else TEX_BASE) + slot)
        # P4.4 general bindless: an element of a run-time table ('t' sampled images and 'i' storage
        # images by TIC, 's' samplers by TSC; address: VkSamplerAddressMode of a sampler)
        self.table, self.index, self.address = table, index, address

    def dims(self, l):
        w = max(1, self.w >> l)
        h = 1 if self.view in ('1d', '1da', 'buf') else max(1, self.h >> l)
        d = max(1, self.d >> l) if self.view == '3d' else 1
        return w, h, d

    def layers(self):
        return self.d if self.view in ('2da', '1da', 'cube', 'cubea') else (self.h if self.view == '1da' else 1)

    def value(self, x, y, k, l):
        if self.fmt == 'd':
            return (f2u(depth(x, y, k, l)), 0, 0, 0)
        t = texel(self.slot, x, y, k, l)
        if self.fmt == 'f':
            return tuple(f2u(float(c)) for c in t)
        if self.fmt in ('r', 's'):
            return (u32(x * 16 + y + k * 256 + 0x10000 * self.slot), 0, 0, 0)
        if self.fmt == 'v':
            return (t[0], t[1], 0, 0)
        if self.fmt == '8':
            return ((x * 5 + y * 3 + k + 0x80) & 0xff, 0, 0, 0)
        if self.fmt == 'w':
            return ((x * 701 + y * 33 + k * 7 + 0x8000) & 0xffff, 0, 0, 0)
        return t

    def fetch(self, x, y, k, l):   # clamp to edge
        w, h, d = self.dims(l)
        x = min(max(x, 0), w - 1)
        y = min(max(y, 0), h - 1)
        if self.view == '3d':
            k = min(max(k, 0), d - 1)
        return self.value(x, y, k, l)




def center(i, n):
    return (i + 0.5) / n


def tid_xy(t, w=8):
    return t % w, (t // w) % w


def img_words(tex):
    out = []
    w, h, d = tex.dims(0)
    for k in range(tex.layers() if tex.view in ('2da', '1da') else d):
        for y in range(h):
            for x in range(w):
                v = tex.value(x, y, k, 0)
                n = {'u': 4, 'f': 4, 'v': 2}.get(tex.fmt, 1)
                out.extend(v[:n])
    return out


def tins(*words):
    w = [u32(x) if isinstance(x, int) else f2u(x) for x in words]
    return w + [0] * (8 - len(w))


XT = Tex(0, '2d', 'u', 8, 8, 1, 4)
# TLD with an offset register that cannot be traced (loaded from the inputs: R21)
ins, exp = [], []
for t in range(N):
    x, y = 2 + t % 4, 2 + (t // 4) % 4
    ox, oy = [(1, -2), (-1, 1), (2, 0), (0, -1)][t % 4]
    ins.append(tins(x, y, 0, 0, 0, u32((ox & 0xf) | (oy & 0xf) << 4)))
    exp.append(pad8(XT.fetch(x + ox, y + oy, 0, 0)))
case('tld_dyn_off', ['tld lz aoffi $r0 $r8 $r21 0x%x t2d 0xf' % (TEX_BASE + XT.slot)], ins, exp, '', texs=[XT])
# TEX.LL with a per-invocation offset (switch over the 256 values)
ins, exp = [], []
for t in range(N):
    x, y = 2 + t % 4, 2 + (t // 4) % 4
    l = t % 2
    ox, oy = [(1, -2), (-1, 1), (2, 0), (0, -1), (-3, 3), (7, -8)][t % 6]
    xs, ys = x >> l, y >> l
    w_ = 8 >> l
    ins.append(tins(center(xs, w_), center(ys, w_), 0, 0, float(l), u32((ox & 0xf) | (oy & 0xf) << 4)))
    exp.append(pad8(XT.fetch(xs + ox, ys + oy, 0, l)))
case('tex_dyn_off', ['tex ll aoffi $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + XT.slot)], ins, exp, '', texs=[XT])
# TXD with offsets in the high half of its layer/offset register (R10 here), not traceable
ins, exp = [], []
for t in range(N):
    x, y = 2 + t % 4, 2 + (t // 4) % 4
    l = t % 3
    g = (2 ** l) / 8.0
    ox, oy = [(1, 0), (-1, 1), (0, -2)][t % 3]
    ins.append(tins(center(x >> l, 8 >> l), center(y >> l, 8 >> l), u32(((ox & 0xf) | (oy & 0xf) << 4) << 16), 0, g, 0.0, 0.0, g))
    exp.append(pad8(XT.fetch((x >> l) + ox, (y >> l) + oy, 0, l)))
case('txd_dyn_off', ['txd aoffi $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + XT.slot)], ins, exp, '', texs=[XT])
# TLD4.PTP with register offsets (four gathers): texel n = texel i0j0 of the footprint at offset n
XG = Tex(1, '2d', 'u', 16, 16, 1, 1)


def gather(tex, x0, y0, comp, k=0, off=(0, 0)):
    i0, j0 = x0 + off[0], y0 + off[1]
    pts = [(i0, j0 + 1), (i0 + 1, j0 + 1), (i0 + 1, j0), (i0, j0)]
    return [tex.fetch(i, j, k, 0)[comp] for i, j in pts]


offs = [(1, 0), (-2, 3), (0, -1), (4, 4)]
ptp0 = (offs[0][0] & 0xff) | (offs[0][1] & 0xff) << 8 | (offs[1][0] & 0xff) << 16 | (offs[1][1] & 0xff) << 24
ptp1 = (offs[2][0] & 0xff) | (offs[2][1] & 0xff) << 8 | (offs[3][0] & 0xff) << 16 | (offs[3][1] & 0xff) << 24
ins, exp = [], []
for t in range(N):
    x, y = 2 + t % 8, 2 + (t // 8) % 8
    ins.append(tins((x + 1) / 16.0, (y + 1) / 16.0, 0, 0, ptp0, ptp1))
    exp.append(pad8([gather(XG, x, y, 2, off=offs[n])[3] for n in range(4)]))
case('tld4_ptp_dyn', ['tld4 b ptp $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + XG.slot)], ins, exp, '', texs=[XG])
# TXQ texture type: component 2 = the sample count (1), the others 0
ins = [tins(0) for _ in range(N)]
case('txq_type', ['tex lz $r4 $r8 $r20 0x%x t2d 0x1' % (TEX_BASE + XT.slot), 'raw 0x%016x' % (
     0xdf48000000000000 | (0xf << 31) | (2 << 22) | ((TEX_BASE + XT.slot) << 36) | PT | (8 << 8)), 'mov32i $r4 0x0 0xf'],
     ins, [pad8([0, 0, 1, 0]) for _ in range(N)], '', texs=[XT])

# images: R32UI 8x8 ('r': x*16 + y + k*256 + 0x10000*slot)
IR = Tex(0, '2d', 'r', 8, 8, storage=True)
IU = Tex(1, '2d', 'u', 8, 8, storage=True)
# SUST.D.BA b32: x in bytes
ins, exp = [], []
img = img_words(IR)
for t in range(N):
    x, y = tid_xy(t)
    ins.append(tins(4 * x, y, 0, 0, u32(0x5b000000 + t)))
    exp.append(pad8([u32(0x5b000000 + t)]))
    img[y * 8 + x] = u32(0x5b000000 + t)
case('sust_d_ba', ['mov $r0 $r20 0xf', 'raw 0x%016x' % (0xeb20000000000000 | (1 << 52) | (1 << 23) | (3 << 33) | (4 << 20) |
                                                    (1 << 51) | ((IMG_BASE + IR.slot) << 36) | PT | (8 << 8))],
     ins, exp, '', texs=[IR], images={IR.slot: img})
# SUST.P with a partial mask (r, b): the masked components from R0, R1; the others kept
for mask, nm in ((0x5, 'rb'), (0x8, 'a'), (0x6, 'gb')):
    ins, exp = [], []
    img = img_words(IU)
    for t in range(N):
        x, y = tid_xy(t)
        data = [u32(0x77000000 + t * 4 + c) for c in range(4)]
        ins.append(tins(x, y, 0, 0, *data))
        exp.append(pad8(data[:2]))
        j = 0
        for c in range(4):
            if (mask >> c) & 1:
                img[(y * 8 + x) * 4 + c] = data[j]
                j += 1
    case('sust_p_%s' % nm, ['mov $r0 $r20 0xf', 'mov $r1 $r21 0xf',
                            'raw 0x%016x' % (0xeb20000000000000 | (3 << 33) | (mask << 20) | (1 << 51) | ((IMG_BASE + IU.slot) << 36) |
                                             PT | (8 << 8))],
         ins, exp, '', texs=[IU], images={IU.slot: img})
# SUATOM.D INC / DEC (PTX atom.inc/dec, unsigned) and f32 ADD, one texel per invocation
for opc, nm in ((3, 'inc'), (4, 'dec')):
    ins, exp = [], []
    img = img_words(IR)
    for t in range(N):
        x, y = tid_xy(t)
        old = IR.value(x, y, 0, 0)[0]
        lim = [old, old + 1, old - 1, 0, 0xffffffff, old >> 1][t % 6] & 0xffffffff
        ins.append(tins(x, y, 0, 0, lim))
        exp.append(pad8([old]))
        if opc == 3:
            img[y * 8 + x] = 0 if old >= lim else old + 1
        else:
            img[y * 8 + x] = lim if (old == 0 or old > lim) else old - 1
    w = 0xea00000000000000 | (opc << 29) | (3 << 33) | ((IMG_BASE + IR.slot) << 36) | (20 << 20) | PT | (8 << 8)
    case('suatom_%s' % nm, ['raw 0x%016x' % w], ins, exp, '', texs=[IR], images={IR.slot: img})
    # SURED (no result)
    w = 0xeb40000000000000 | (1 << 52) | (opc << 24) | (3 << 33) | (1 << 51) | ((IMG_BASE + IR.slot) << 36) | PT | (8 << 8)
    case('sured_%s' % nm, ['mov $r0 $r20 0xf', 'raw 0x%016x' % w], ins, [pad8([r[4]]) for r in ins], '', texs=[IR],
         images={IR.slot: img})
IRF = Tex(2, '2d', 'r', 8, 8, storage=True)
ins, exp = [], []
img = img_words(IRF)
for t in range(N):
    x, y = tid_xy(t)
    old = IRF.value(x, y, 0, 0)[0]
    d = f2u(rng.uniform(-100, 100))
    ins.append(tins(x, y, 0, 0, d))
    exp.append(pad8([old]))
    r = np.float32(struct.unpack('<f', struct.pack('<I', old))[0]) + np.float32(struct.unpack('<f', struct.pack('<I', d))[0])
    img[y * 8 + x] = f2u(float(r))
w = 0xea00000000000000 | (0 << 29) | (3 << 51) | (3 << 33) | ((IMG_BASE + IRF.slot) << 36) | (20 << 20) | PT | (8 << 8)
case('suatom_f32_add', ['raw 0x%016x' % w], ins, exp, 'nan32', texs=[IRF], images={IRF.slot: img})

# =====================================================================================
# Memory forms P4.1 left out (P4_4_DISENO.md §3): ATOMS INC/DEC and 64-bit, ATOM/RED 64-bit and f32,
# IMNMX.XHI/XLO, P2R/R2P .CC
# =====================================================================================
def sx(x, b):
    x &= (1 << b) - 1
    return x - (1 << b) if x >> (b - 1) else x


def inc32(old, b):
    return 0 if old >= b else u32(old + 1)


def dec32(old, b):
    return b if (old == 0 or old > b) else old - 1


def split64(x):
    x &= (1 << 64) - 1
    return [x & 0xffffffff, x >> 32]


SMEM = ['shl $r42 $r40 0x3']   # an 8-byte slot per invocation
for nm, fn in (('inc', inc32), ('dec', dec32)):
    ins, exp = [], []
    for t in range(N):
        b = [0, 1, 5, 0xffffffff, 100, 7][t % 6]
        o = [0, 1, 5, 6, 3, 0xffffffff, 100, 101][t % 8]
        ins.append(tins(o, b))
        exp.append(pad8([o, fn(o, b)]))
    case('atoms_%s' % nm, SMEM + ['st b32 s[$r42] $r8', 'atoms %s u32 $r0 s[$r42] $r9' % nm, 'ld b32 $r1 s[$r42]'], ins, exp,
         'smem')

OPS64 = {'add': lambda a, b, s: a + b, 'min': lambda a, b, s: min(sx(a, 64), sx(b, 64)) if s else min(a, b),
         'max': lambda a, b, s: max(sx(a, 64), sx(b, 64)) if s else max(a, b), 'and': lambda a, b, s: a & b,
         'or': lambda a, b, s: a | b, 'xor': lambda a, b, s: a ^ b, 'exch': lambda a, b, s: b}
for nm, sg in (('add', 0), ('min', 1), ('max', 0), ('max', 1), ('xor', 0), ('exch', 0)):
    ins, exp = [], []
    for t in range(N):
        a, b = rng.getrandbits(64), rng.getrandbits(64)
        if t % 4 == 0:
            b = (b & 0xffffffff) | (a & ~0xffffffff)   # equal high words
        ins.append(tins(*split64(a), 0, 0, *split64(b)))
        exp.append(pad8(split64(a) + split64(OPS64[nm](a, b, sg))))
    ty = ('s64' if sg else 'u64')
    case('atoms_%s_%s' % (nm, ty), SMEM + ['st b64 s[$r42] $r8', 'atoms %s %s $r0 s[$r42] $r20' % (nm, ty), 'ld b64 $r2 s[$r42]'],
         ins, exp, 'smem i64atom')
ins, exp = [], []
for t in range(N):
    a, n = rng.getrandbits(64), rng.getrandbits(64)
    c = a if t % 2 else rng.getrandbits(64)
    ins.append(tins(*split64(a), 0, 0, *split64(c), *split64(n)))
    exp.append(pad8(split64(a) + split64(n if c == a else a)))
case('atoms_cas_b64', SMEM + ['st b64 s[$r42] $r8', 'atoms cas b64 $r0 s[$r42] $r20', 'ld b64 $r2 s[$r42]'], ins, exp,
     'smem i64atom')
ins, exp = [], []
for t in range(N):
    a, b0, b1 = rng.getrandbits(64), rng.choice([0, 3, 0xffffffff, rng.getrandbits(32)]), rng.choice([0, 7, rng.getrandbits(32)])
    if t % 3 == 0:
        a = (a & ~0xffffffff) | b0   # old == bound: INC wraps to 0
    if t % 4 == 1:
        a &= 0xffffffff              # high word 0: DEC wraps to the bound
    ins.append(tins(*split64(a), 0, 0, b0, b1))
    lo, hi = split64(a)
    exp.append(pad8([lo, hi] + [inc32(lo, b0), dec32(hi, b1)]))
case('atoms_incdec_in64', SMEM + ['st b64 s[$r42] $r8', 'atoms inc u32 $r0 s[$r42] $r20', 'atoms dec u32 $r1 s[$r42+0x4] $r21',
                                  'ld b64 $r2 s[$r42]', 'mov $r24 $r255 0xf', 'mov $r25 $r255 0xf', 'atoms add u64 $r4 s[$r42] $r24',
                                  'mov32i $r4 0x0 0xf', 'mov32i $r5 0x0 0xf'], ins, exp, 'smem i64atom')
# 32-bit accesses to the 64-bit words of a program with 64-bit ATOMS: add, max s32, CAS, INC, a u16 store
ins, exp = [], []
for t in range(N):
    a, w = rng.getrandbits(64), rng.getrandbits(32)
    v0, v1, v2 = rng.getrandbits(32), rng.getrandbits(32), rng.getrandbits(16)
    ins.append(tins(*split64(a), 0, 0, v0, v1, v2, w))
    lo, hi = split64(a)
    r0, r1 = lo, hi
    lo = u32(lo + v0)
    hi = u32(max(sx(hi, 32), sx(v1, 32)))
    lo = (lo & 0xffff) | (v2 << 16)
    exp.append(pad8([r0, r1] + split64((lo | hi << 32) + w)))   # then a u64 add of R23 (zero-extended)
case('atoms_mixed_64', SMEM + ['st b64 s[$r42] $r8', 'atoms add u32 $r0 s[$r42] $r20', 'atoms max s32 $r1 s[$r42+0x4] $r21',
                               'st u16 s[$r42+0x2] $r22', 'mov $r24 $r23 0xf', 'mov32i $r25 0x0 0xf',
                               'atoms add u64 $r4 s[$r42] $r24', 'ld b64 $r2 s[$r42]', 'mov32i $r4 0x0 0xf', 'mov32i $r5 0x0 0xf'],
     ins, exp, 'smem i64atom')

# global ATOM/RED: on the invocation's R6:R7 output slot (8-aligned; the epilogue then writes R6:R7 = 0)
GSLOT = ['iadd cc $r43 $r41 c0[0x140]', 'iadd x $r44 $r255 c0[0x144]', 'stg e b64 ncg[$r43+0x18] $r8']
GLOAD = ['ldg e b64 $r2 ncg[$r43+0x18]']
for nm, sg in (('add', 0), ('min', 1), ('max', 0), ('exch', 0)):
    ins, exp = [], []
    for t in range(N):
        a, b = rng.getrandbits(64), rng.getrandbits(64)
        if t % 4 == 0:
            b = (b & 0xffffffff) | (a & ~0xffffffff)
        ins.append(tins(*split64(a), 0, 0, *split64(b)))
        exp.append(pad8(split64(a) + split64(OPS64[nm](a, b, sg))))
    ty = 's64' if sg else 'u64'
    case('atom_%s_%s' % (nm, ty), GSLOT + ['atom %s e %s $r0 g[$r43+0x18] $r20' % (nm, ty)] + GLOAD, ins, exp, 'i64atom')
ins, exp = [], []
for t in range(N):
    a, n = rng.getrandbits(64), rng.getrandbits(64)
    c = a if t % 2 else rng.getrandbits(64)
    ins.append(tins(*split64(a), 0, 0, *split64(c), *split64(n)))
    exp.append(pad8(split64(a) + split64(n if c == a else a)))
case('atom_cas_b64', GSLOT + ['atom cas e b64 $r0 g[$r43+0x18] $r20'] + GLOAD, ins, exp, 'i64atom')
ins, exp = [], []
for t in range(N):
    a, b = rng.getrandbits(64), rng.getrandbits(64)
    ins.append(tins(*split64(a), 0, 0, *split64(b)))
    exp.append(pad8([0, 0] + split64(a + b)))
case('red_add_u64', GSLOT + ['red add e u64 g[$r43+0x18] $r20'] + GLOAD, ins, exp, 'i64atom')


def ftz32(x):
    x = np.float32(x)
    return np.float32(math.copysign(0.0, float(x))) if x != 0 and abs(x) < np.float32(2.0 ** -126) else x


FV = [1.5, -2.25, 3e38, 1e-39, -1e-40, 2.0 ** -126, -0.0, float('inf'), 1e-45, 0.1, -7.0, 2.0 ** -127]
w_atom = (0xed01000181472b00 & ~(7 << 49)) | (3 << 49)   # envyas: atom add e u32 $r0 g[$r43+0x18] $r20; type f32
w_red = (0xebf9000180072b14 & ~(7 << 20)) | (3 << 20)    # red add e u32 g[$r43+0x18] $r20; type f32
for nm, w in (('atom', w_atom), ('red', w_red)):
    ins, exp = [], []
    for t in range(N):
        a, b = FV[t % len(FV)], FV[(t * 5 + 3) % len(FV)]
        with np.errstate(all='ignore'):
            r = ftz32(np.float32(ftz32(a) + ftz32(b)))
        ins.append(tins(f2u(a), 0, 0, 0, f2u(b)))
        exp.append(pad8([f2u(a) if nm == 'atom' else 0, 0, int(np.float32(r).view(np.uint32)), 0]))
    case('%s_add_f32' % nm, GSLOT + ['raw 0x%016x' % w, 'ldg e b32 $r2 ncg[$r43+0x18]'], ins, exp, 'nan32')

# IMNMX.XHI then .XLO: a 64-bit minimum/maximum as Mesa's nv50_ir lowers it (R1:R0 from R9:R8, R11:R10)
def imx(d, a, b, sg, mx, xm, cc):
    return ((0x5c20 << 48) | (sg << 48) | (cc << 47) | (xm << 43) | (mx << 42) | (7 << 39) | (b << 20) | (a << 8) | d | PT)


for nm, mx in (('min', 0), ('max', 1)):
    for sg in (0, 1):
        ins, exp = [], []
        for t in range(N):
            a, b = rng.getrandbits(64), rng.getrandbits(64)
            if t % 3 == 0:
                b = (b & 0xffffffff) | (a & ~0xffffffff)
            if t % 7 == 0:
                b = a
            ins.append(tins(*split64(a), *split64(b)))
            va, vb = (sx(a, 64), sx(b, 64)) if sg else (a, b)
            r = max(va, vb) if mx else min(va, vb)
            exp.append(pad8(split64(r)))
        case('imnmx_x_%s_%s64' % (nm, 's' if sg else 'u'),
             ['raw 0x%016x' % imx(1, 9, 11, sg, mx, 3, 1), 'raw 0x%016x' % imx(0, 8, 10, 0, mx, 1, 0)], ins, exp, '')

# P2R/R2P .CC: the flags of an IADD.CC read back (Z S C O = bits 0-3), and flags written from a register
# then used by IADD.X (the carry)
ins, exp = [], []
for t in range(N):
    a, b = rng.getrandbits(32), rng.getrandbits(32)
    if t % 5 == 0:
        b = u32(-a)
    if t % 7 == 0:
        a, b = 0x7fffffff, rng.getrandbits(8) + 1
    c = rng.getrandbits(4) | (rng.getrandbits(28) << 4)
    r = u32(a + b)
    z, sgn, cy = int(r == 0), r >> 31, int(a + b > 0xffffffff)
    ov = int((sx(a, 32) + sx(b, 32)) != sx(r, 32))
    ins.append(tins(a, b, c))
    exp.append(pad8([z | sgn << 1 | cy << 2 | ov << 3, c & 0xf, r, (c >> 2) & 1]))
case('p2r_r2p_cc', ['iadd cc $r2 $r8 $r9', 'p2r $r0 cc $r255 0xf', 'r2p cc $r10 0xf', 'p2r $r1 cc $r255 0xf',
                    'iadd x $r3 $r255 $r255'], ins, exp, '')

# F2I from an f16 source (half 0 or 1 by bit 41; FTZ flushes f16 subnormals)
HV = [0x0000, 0x8000, 0x3c00, 0xbe00, 0x4100, 0xc100, 0x7bff, 0xfbff, 0x7c00, 0xfc00, 0x7e00, 0x0001, 0x8200, 0x3800,
      0x3a00, 0xba00, 0x5640, 0xd640]
for isz, sgn, mode, h1, ftzb, nm in ((2, True, 0, 0, 0, 's32'), (2, False, 3, 1, 0, 'u32_trunc_h1'), (1, True, 1, 0, 1, 's16_floor_ftz'),
                                     (0, False, 2, 1, 0, 'u8_ceil_h1')):
    ins, exp = [], []
    for t in range(N):
        a, b = HV[t % len(HV)], HV[(t * 7 + 1) % len(HV)]
        if t >= len(HV):
            a, b = rng.getrandbits(16), rng.getrandbits(16)
        word = a | b << 16
        hv = b if h1 else a
        x = float(np.array([hv], dtype=np.uint16).view(np.float16)[0])
        if ftzb and x != 0 and abs(x) < 2.0 ** -14:
            x = math.copysign(0.0, x)
        width = [8, 16, 32][isz]
        ins.append(tins(word))
        exp.append(pad8([f2int(x, width, sgn, mode) & 0xffffffff]))
    w = f2i_word(isz, sgn, 1, mode) | (h1 << 41) | (ftzb << 44)
    case('f2i_%s_f16' % nm, ['raw 0x%016x' % w], ins, exp, '')

# LEA.HI with negation (model: the 64-bit C:A negated, as LEA negates A): R1 = ((-(R9:R8)) << 5 >> 32) + R20
ins, exp = [], []
for t in range(N):
    a, c, b = rng.getrandbits(32), rng.getrandbits(32), rng.getrandbits(32)
    if t % 5 == 0:
        a = 0
    v = (-((c << 32) | a)) & ((1 << 64) - 1)
    ins.append(tins(a, c, 0, 0, b))
    exp.append(pad8([0, u32(((v << 5) >> 32) + b)]))
case('lea_hi_neg', ['lea hi 0x1 $r1 neg $r8 $r20 $r9 0x5'], ins, exp, '')

# LDC.IS (NAK: bank = imm + R[31:16], offset = imm + R[15:0]): c1 (zeros) or c2 (the inputs)
ins, exp, rows = [], [], []
for t in range(N):
    rows.append([rng.getrandbits(32) for _ in range(8)])
for t in range(N):
    d, j = t % 2, (t * 3) % 8
    r = rows[t]
    r[0] = (d << 16) | (t * 32 + 4 * j)
    ins.append(r)
for t in range(N):
    d, j = t % 2, (t * 3) % 8
    exp.append(pad8([ins[t][j] if d else 0]))
w_ldc_is = 0xef94001000070800 | (2 << 44)   # envyas: ld b32 $r0 c1[$r8]; mode IS
case('ldc_is', ['raw 0x%016x' % w_ldc_is], ins, exp, '')

# =====================================================================================
# P4.5: scalar video instructions as models (PTX semantics on envydis' fields; P4_5_DISENO.md)
# a = R8, b = R20, c = R9, d = R0
# =====================================================================================
def vpart(v, sgn, bits, sel):
    x = (v >> (8 * sel)) & ((1 << bits) - 1)
    return sx(x, bits) if sgn else x


def vsat(x, sgn, bits):
    lo, hi = (-(1 << (bits - 1)), (1 << (bits - 1)) - 1) if sgn else (0, (1 << bits) - 1)
    return min(max(x, lo), hi)


def vfinish(tmp, c, op2, dsgn, sat):
    field = 16 if op2 <= 1 else 8 if op2 <= 3 else 32
    r = u32(vsat(tmp, dsgn, field) if sat else tmp)
    if op2 == 0: r = (c & 0xffff) | ((r << 16) & 0xffffffff)
    elif op2 == 1: r = (c & 0xffff0000) | (r & 0xffff)
    elif op2 == 2: r = (c & 0xffffff00) | (r & 0xff)
    elif op2 == 3: r = (c & 0xff00ffff) | ((r & 0xff) << 16)
    elif op2 == 4: r = u32(r + c)
    elif op2 in (5, 6):
        x, y = (sx(r, 32), sx(c, 32)) if dsgn else (r, c)
        r = u32(min(x, y) if op2 == 5 else max(x, y))
    return r


def vword(base, asgn, a16, asel, b, op2=0, dsgn=0, sat=0, extra=0):
    """b: ('imm', value16, sgn) or ('reg', size 0-6, sgn)"""
    w = base | 0 | (8 << 8) | PT | (9 << 39) | (asel << 36) | (a16 << 38) | (asgn << 48) | (op2 << 51) | (dsgn << 54) | (sat << 55) | extra
    if b[0] == 'imm':
        w |= (b[1] & 0xffff) << 20 | (b[2] << 49)
    else:
        w |= (1 << 50) | (20 << 20) | (b[1] << 28) | (b[2] << 49)
    return w


def vb(b, rb):
    if b[0] == 'imm':
        return sx(b[1], 16) if b[2] else b[1] & 0xffff
    sz, sg = b[1], b[2]
    if sz < 4: return vpart(rb, sg, 8, sz)
    if sz < 6: return vpart(rb, sg, 16, 2 * (sz - 4))
    return sx(rb, 32) if sg else rb


VCASES = [  # (name, asgn, a16, asel, b, op2, dsgn, sat)
    ('u8b0_u32_none', 0, 0, 0, ('reg', 6, 0), 7, 0, 0), ('s8b3_s8b1_acc', 1, 0, 3, ('reg', 1, 1), 4, 1, 0),
    ('u16h1_s16h0_min_sd', 0, 1, 2, ('reg', 4, 1), 5, 1, 0), ('s16h0_imm_max', 1, 1, 0, ('imm', 0xfff3, 1), 6, 1, 0),
    ('u8b2_uimm_mrg16h', 0, 0, 2, ('imm', 0x8123, 0), 0, 0, 0), ('s8b1_u16h1_mrg16l', 1, 0, 1, ('reg', 5, 0), 1, 1, 0),
    ('u8b0_s32_mrg8b0', 0, 0, 0, ('reg', 6, 1), 2, 0, 0), ('s16h1_u8b3_mrg8b2', 1, 1, 2, ('reg', 3, 0), 3, 1, 0)]
for vop, base in (('vadd', 0x2000000000000000), ('vabsdiff', 0x5400000000000000)):
    for nm, asgn, a16, asel, b, op2, dsgn, sat in VCASES + [('sat_u32_sd', 1, 1, 0, ('reg', 6, 1), 7, 1, 1), ('sat_mrg8_ud', 0, 1, 2, ('reg', 6, 0), 2, 0, 1)]:
        if sat and vop == 'vadd':
            continue   # VADD: bit 55 is not described (no .sat)
        ins, exp = [], []
        for t in range(N):
            a, rb, c = rng.getrandbits(32), rng.getrandbits(32), rng.getrandbits(32)
            ins.append(tins(a, c, 0, 0, rb))
            ta, tb = vpart(a, asgn, 16 if a16 else 8, asel), vb(b, rb)
            tmp = ta + tb if vop == 'vadd' else abs(ta - tb)
            exp.append(pad8([vfinish(tmp, c, op2, dsgn, sat)]))
        case('%s_%s' % (vop, nm), ['raw 0x%016x' % vword(base, asgn, a16, asel, b, op2, dsgn, sat)], ins, exp, '')
for nm, asgn, a16, asel, b, scale, sat in (('u8_u8', 0, 0, 1, ('reg', 2, 0), 0, 0), ('s16_s16_shr7', 1, 1, 2, ('reg', 5, 1), 1, 0),
                                          ('u16_s32_shr15_sat', 0, 1, 0, ('reg', 6, 1), 2, 1), ('s8_imm_sat', 1, 0, 3, ('imm', 0x7abc, 1), 0, 1),
                                          ('u16_u32_sat', 0, 1, 2, ('reg', 6, 0), 0, 1)):
    ins, exp = [], []
    for t in range(N):
        a, rb, c = rng.getrandbits(32), rng.getrandbits(32), rng.getrandbits(32)
        ins.append(tins(a, c, 0, 0, rb))
        sg = bool(asgn or b[2])
        tmp = vpart(a, asgn, 16 if a16 else 8, asel) * vb(b, rb) + (sx(c, 32) if sg else c)
        tmp = sx(tmp & ((1 << 64) - 1), 64) if sg else tmp & ((1 << 64) - 1)
        tmp >>= [0, 7, 15][scale]
        exp.append(pad8([u32(vsat(tmp, sg, 32) if sat else tmp)]))
    w = vword(0x5f00000000000000, asgn, a16, asel, b) | (scale << 51) | (sat << 55)
    case('vmad_%s' % nm, ['raw 0x%016x' % w], ins, exp, '')
for vop, base in (('vshl', 0x5700000000000000), ('vshr', 0x5600000000000000)):
    for nm, asgn, a16, asel, imm, wrap, u8, op2, dsgn, sat in (('u8_5', 0, 0, 1, 5, 0, 0, 7, 0, 0), ('s16_40_clamp', 1, 1, 2, 40, 0, 0, 7, 1, 0),
                                                              ('s16_40_wrap', 1, 1, 2, 40, 1, 0, 4, 1, 0), ('u16_0x1ff_u8', 0, 1, 0, 0x1ff, 1, 1, 5, 0, 0),
                                                              ('s8_20_sat_mrg16h', 1, 0, 3, 20, 0, 0, 0, 1, 1), ('u16_31_sat', 0, 1, 2, 31, 0, 0, 7, 0, 1)):
        ins, exp = [], []
        for t in range(N):
            a, c = rng.getrandbits(32), rng.getrandbits(32)
            ins.append(tins(a, c))
            ta = vpart(a, asgn, 16 if a16 else 8, asel)
            n = imm & (0xff if u8 else 0xffff)
            n = n & 31 if wrap else min(n, 32)
            tmp = ta << n if vop == 'vshl' else ta >> n
            exp.append(pad8([vfinish(tmp, c, op2, dsgn, sat)]))
        w = (base | (8 << 8) | PT | (9 << 39) | (asel << 36) | (a16 << 38) | (asgn << 48) | (imm << 20) | (wrap << 49) | (u8 << 50) |
             (op2 << 51) | (dsgn << 54) | (sat << 55))
        case('%s_%s' % (vop, nm), ['raw 0x%016x' % w], ins, exp, '')
for cond in range(8):
    for bop in range(3) if cond == 1 else range(1):
        ins, exp = [], []
        b = ('reg', [6, 4, 0, 6, 5, 1, 6, 2][cond], cond & 1)
        asgn, a16, asel = cond >> 2 & 1, cond & 1, (cond & 1) * 2
        for t in range(N):
            a, rb = rng.getrandbits(32), rng.getrandbits(32)
            if t % 4 == 0:
                rb = a   # equal parts often enough
            pin = t & 1
            ins.append(tins(a, pin, 0, 0, rb))
            ta = vpart(a, asgn, 16 if a16 else 8, asel)
            if t % 4 == 1 and b[1] == 6:
                rb = ta & 0xffffffff   # P4.5 mutation: equal operands for LE/GE/EQ with a full-word B
            tb = vb(b, rb)
            ins[-1] = tins(a, pin, 0, 0, rb)
            tv = [False, ta < tb, ta == tb, ta <= tb, ta > tb, ta != tb, ta >= tb, True][cond]
            def bo(x, y): return [x and y, x or y, x != y][bop]
            p = bool(pin)
            exp.append(pad8([int(bo(not tv, p)), int(bo(tv, p))]))   # R0 = P1 (bits 0-2: !t), R1 = P2 (bits 3-5: t)
        w = (vword(0x50f0000000000000, asgn, a16, asel, b) & ~((0xff << 0) | (0xff << 39) | (1 << 47))) | \
            (1 << 0) | (2 << 3) | (1 << 39) | ((cond & 3) << 43) | ((cond >> 2) << 47) | (bop << 45)
        case('vsetp_c%d_b%d' % (cond, bop), ['isetp ne and $p1 0x1 $r9 0x0 0x1', 'raw 0x%016x' % w,
                                              'sel $r0 $r255 0x1 not $p1', 'sel $r1 $r255 0x1 not $p2'], ins, exp, '')

# texel buffers (D-P4.4-12): TLD 1D and TXQ of a TextureState::buffer handle; SULD/SUST/SUATOM b1d
XB = Tex(8, 'buf', 'u', 64)
ins, exp = [], []
for t in range(N):
    x = (t * 5) % 64
    ins.append(tins(x))
    exp.append(pad8(XB.value(x, 0, 0, 0)))
case('tld_buf', ['tld lz $r0 $r8 $r20 0x%x t1d 0xf' % (TEX_BASE + XB.slot)], ins, exp, '', texs=[XB])
case('txq_buf', ['txq $r0 $r8 dimension 0x%x 0xf' % (TEX_BASE + XB.slot)], [tins(0)] * N, [pad8([64, 1, 1, 1])] * N, '',
     texs=[XB])
XSB = Tex(9, 'buf', 'r', 64, storage=True)
ins, exp = [], []
for t in range(N):
    x = t if t < 56 else 64 + t   # the last ones out of range: 0
    ins.append(tins(x))
    exp.append(pad8([XSB.value(x, 0, 0, 0)[0] if x < 64 else 0]))
case('suld_b1d', ['mov32i $r0 0xdead 0xf', 'suld d b1d b32 ign $r0 g[$r8] 0x%x' % (IMG_BASE + XSB.slot)], ins, exp, '',
     texs=[XSB])
ins, exp = [], []
img = img_words(XSB)
for t in range(N):
    x = (t * 7) % 64
    v = rng.getrandbits(32)
    ins.append(tins(x, 0, 0, 0, v))
    exp.append(pad8([v]))
    img[x] = v
case('sust_b1d', ['mov $r0 $r20 0xf', 'sust d b1d b32 ign g[$r8] $r0 0x%x' % (IMG_BASE + XSB.slot)], ins, exp, '',
     texs=[XSB], images={XSB.slot: img})
ins, exp = [], []
img = img_words(XSB)
for t in range(N):
    v = rng.getrandbits(16)
    ins.append(tins(t, 0, 0, 0, v))   # one texel per invocation: R1 = the old value
    exp.append(pad8([0, img[t]]))
    img[t] = u32(img[t] + v)
case('suatom_b1d_add', ['suatom d u32 b1d add ign $r1 g[$r8] $r20 0x%x' % (IMG_BASE + XSB.slot)], ins, exp, '',
     texs=[XSB], images={XSB.slot: img})

# general bindless (D-P4.4-10): handles that come from memory, resolved in descriptor tables by TIC
# (bits 0-19) and TSC (bits 20-31). Four 4x4 RGBA32F textures (TIC 0-3), two samplers (TSC 0 clamp
# to edge, 1 repeat): x one texel past the right edge shows which sampler was used
BT = [Tex(10 + i, '2d', 'f', 4, 4, table='t', index=i) for i in range(4)]
BS = [Tex(0, '2d', 'f', 1, table='s', index=0, address=2), Tex(0, '2d', 'f', 1, table='s', index=1, address=0)]
ins, exp = [], []
for t in range(N):
    tic, tsc = t % 4, (t // 4) % 2
    x, y = (t // 8) % 4, t % 4
    past = t % 3 == 0
    hi = (t % 5 == 0) * ((t % 15) + 1) << 16   # TIC bits 16-19: past the table, clamped to its last entry
    ins.append(tins(center(x, 4) + (1.0 if past else 0.0), center(y, 4), 0, 0, u32(tic | hi | tsc << 20), 0.0))
    xx = x if (not past or tsc == 1) else 3
    exp.append(pad8(BT[3 if hi else tic].fetch(xx, y, 0, 0)))
w = 0xdeb8000000000000 | (3 << 37) | (0xf << 31) | (1 << 29) | (20 << 20) | (8 << 8) | 0 | PT
case('tex_bindless_dyn', ['raw 0x%016x' % w], ins, exp, 'bindless', texs=BT + BS)
BI = [Tex(14 + i, '2d', 'r', 8, 8, storage=True, table='i', index=i) for i in range(4)]
ins, exp = [], []
for t in range(N):
    x, y = tid_xy(t)
    tic = (t * 3) % 4
    ins.append(tins(x, y, 0, 0, tic))
    exp.append(pad8([BI[tic].value(x, y, 0, 0)[0]]))
w = 0xeb10000000000000 | (3 << 33) | (4 << 20) | (30 << 39) | PT | (8 << 8)
case('suld_bindless_dyn', ['mov $r30 $r20 0xf', 'raw 0x%016x' % w], ins, exp, 'bindless', texs=BI)


# =====================================================================================
# SHFL in compute (PTX shfl; quads of the warp model: invariant for subgroups of 4 or more lanes)
# and FSWZADD outside the fragment shader
# =====================================================================================
def shfl_word(mode, b, c, pdst=1):
    return (0xef10 << 48) | (mode << 30) | (1 << 28) | (1 << 29) | (b << 20) | (c << 34) | (pdst << 48) | PT | (8 << 8)


for mode, nm, b in ((0, 'idx', 2), (1, 'up', 1), (2, 'down', 1), (3, 'bfly', 3), (3, 'bfly1', 1)):
    ins, exp = [], []
    vals = [rng.getrandbits(32) for _ in range(N)]
    c = 0x1c03 if mode != 1 else 0x1c00
    for t in range(N):
        ins.append(tins(vals[t]))
        L = t & 31
        segmask, clamp = (c >> 8) & 31, c & 31
        maxl = (L & segmask) | (clamp & ~segmask & 31)
        minl = L & segmask
        if mode == 0:
            j = minl | (b & ~segmask & 31); pv = j <= maxl
        elif mode == 1:
            j = L - b; pv = j >= maxl
        elif mode == 2:
            j = L + b; pv = j <= maxl
        else:
            j = L ^ b; pv = j <= maxl
        if not pv:
            j = L
        exp.append(pad8([vals[(t & ~31) + j], int(pv)]))
    case('shfl_%s' % nm, ['raw 0x%016x' % shfl_word(mode, b, c), 'sel $r1 $r255 0x1 not $p1'], ins, exp, '')
ins, exp = [], []
for t in range(N):
    a, b = rng.uniform(-10, 10), rng.uniform(-10, 10)
    ins.append(tins(a, 0, 0, 0, b))
    q = t & 3
    m = 0x6c   # lanes 0..3: ops 1, 2, 3, 0 (bits 6-7 lane 0)
    o = (m >> (6 - 2 * q)) & 3
    fa, fb = np.float32(a), np.float32(b)
    r = [fa + fb, fb - fa, fa - fb, fb][o]
    exp.append(pad8([f2u(float(r))]))
case('fswzadd_compute', ['raw 0x%016x' % ((0x50f8 << 48) | (0x6c << 28) | (20 << 20) | PT | (8 << 8))], ins, exp, '')


# ---------------------------------------------------------------- output (T2-T's format + flags)
VIEWS = {'1d': 0, '2d': 1, '3d': 2, 'cube': 3, '1da': 4, '2da': 5, 'cubea': 6, 'buf': 7}
with open(OUT, 'w') as o:
    o.write('// Generated by tools/gpu_toolchain/gen_shader_t2x.py (envyas + numpy). Do not edit.\n')
    o.write('// %d cases.\n#pragma once\n#include <cstdint>\n\nnamespace lg_test::t2x {\n\n' % len(cases))
    o.write('struct Tex { uint32_t slot; uint32_t view; char fmt; uint32_t w, h, d, levels; bool storage; uint32_t handle; '
            'bool compare;\n             char table; uint32_t index; uint32_t address; };   // view 7: texel buffer\n')
    o.write('struct Image { uint32_t slot; const uint32_t* words; uint32_t count; };\n')
    o.write('struct Case { const char* name; const uint64_t* code; uint32_t words; const Tex* texs; uint32_t ntex;\n'
            '              const uint32_t* inputs; const uint32_t* expect; const Image* images; uint32_t nimages;\n'
            '              const char* body; const char* flags; const uint32_t* alt; };\n\n')
    for i, c in enumerate(cases):
        o.write('static const uint64_t k_code_%d[] = {\n' % i)
        for j in range(0, len(c['code']), 4):
            o.write('    ' + ', '.join('0x%016xull' % x for x in c['code'][j:j + 4]) + ',\n')
        o.write('};\n')
        if c['texs']:
            o.write('static const Tex k_tex_%d[] = {%s};\n' % (i, ', '.join(
                '{%d, %d, \'%s\', %d, %d, %d, %d, %s, 0x%x, %s, %s, %d, %d}' % (
                    t.slot, VIEWS[t.view], t.fmt, t.w, t.h, t.d, t.levels, 'true' if t.storage else 'false', t.handle,
                    'true' if t.compare else 'false', "'%s'" % t.table if t.table else '0', t.index, t.address)
                for t in c['texs'])))
        o.write('static const uint32_t k_in_%d[] = {%s};\n' % (i, ', '.join('0x%x' % x for row in c['inputs'] for x in row)))
        o.write('static const uint32_t k_out_%d[] = {%s};\n' % (i, ', '.join('0x%x' % x for row in c['expect'] for x in row)))
        if c['alt']:
            o.write('static const uint32_t k_alt_%d[] = {%s};\n' % (i, ', '.join('0x%x' % x for row in c['alt'] for x in row)))
        for slot, words in c['images'].items():
            o.write('static const uint32_t k_img_%d_%d[] = {%s};\n' % (i, slot, ', '.join('0x%x' % x for x in words)))
        if c['images']:
            o.write('static const Image k_imgs_%d[] = {%s};\n' % (i, ', '.join(
                '{%d, k_img_%d_%d, %d}' % (s, i, s, len(w)) for s, w in c['images'].items())))
        o.write('\n')
    o.write('static const Case kCases[] = {\n')
    for i, c in enumerate(cases):
        body = c['body'].replace('\\', '\\\\').replace('"', '\\"')
        o.write('    {"%s", k_code_%d, sizeof(k_code_%d) / 8, %s, %d, k_in_%d, k_out_%d, %s, %d, "%s", "%s", %s},\n' % (
            c['name'], i, i, ('k_tex_%d' % i) if c['texs'] else 'nullptr', len(c['texs']), i, i,
            ('k_imgs_%d' % i) if c['images'] else 'nullptr', len(c['images']), body, c['flags'],
            ('k_alt_%d' % i) if c['alt'] else 'nullptr'))
    o.write('};\n\n} // namespace lg_test::t2x\n')
print(len(cases), 'cases')
