#!/usr/bin/env bash
# P4.2 (P4_2_DISENO.md D-P4.2-1): builds the graphics oracle, lavapipe (Mesa's Vulkan driver on
# llvmpipe), which has every stage (SwiftShader has no geometry or tessellation shaders).
# Like the rest of the toolchain it is never linked into Lobo Gélido: only the shader tests load it.
#
#   Mesa         mesa-24.3.4 (github mirror chaotic-cx/mesa-mirror; gitlab.freedesktop.org is often
#                unreachable from CI)                                       lavapipe (MIT)
#   LLVM         the system's libLLVM-18.so + llvm-tblgen (Ubuntu 24.04: libllvm18, llvm-18), with the
#                headers of llvmorg-18.1.3 (llvm/include only, sparse clone): the -dev package is not
#                needed. The generated headers (llvm/Config/*, the tblgen .inc files) are made here.
#
# Two local edits to Mesa's meson.build, for this oracle only: no libdrm (no KMS on a headless
# builder): system_has_kms_drm = false and libdrm not required.
#
# Usage: bash build_lavapipe.sh <prefix>   (needs <prefix>/bin/meson and the mako/markupsafe sources
#        of build_toolchain.sh, ninja, a C/C++ compiler, python3; ~25 min on 2 cores)
# Then configure Lobo with -DLOBOGELIDO_SHADER_ORACLE_GFX_ICD=<prefix>/lvp/share/vulkan/icd.d/lvp_icd.x86_64.json
set -euo pipefail
P=$(realpath -m "${1:?prefix}")
S=$P/src
L=$S/llvm-project/llvm
I=$P/lvp-llvm-inc
TB=/usr/lib/llvm-18/bin/llvm-tblgen
export PATH=$P/bin:$PATH
export PYTHONPATH=$S/mako:$S/markupsafe/src
[ -x "$TB" ] && [ -e /usr/lib/x86_64-linux-gnu/libLLVM-18.so ] || { echo "hace falta LLVM 18 del sistema (libllvm18, llvm-18)"; exit 1; }
command -v flex >/dev/null && command -v bison >/dev/null || { echo "hacen falta flex y bison (build_toolchain.sh deja flex en <prefix>/bin)"; exit 1; }

# ---- LLVM 18.1.3 headers (sparse) and the generated ones
if [ ! -d "$S/llvm-project/.git" ]; then
    git clone -q --depth 1 --filter=blob:none --sparse -b llvmorg-18.1.3 https://github.com/llvm/llvm-project.git "$S/llvm-project"
    git -C "$S/llvm-project" sparse-checkout set llvm/include
fi
rm -rf "$I"
mkdir -p "$I"
cp -r "$L/include/llvm" "$L/include/llvm-c" "$I/"
(cd "$I/llvm/Config" && python3 - <<'EOF'
import re
vals = {'LLVM_DEFAULT_TARGET_TRIPLE': 'x86_64-pc-linux-gnu', 'LLVM_HOST_TRIPLE': 'x86_64-pc-linux-gnu', 'LLVM_NATIVE_ARCH': 'X86',
        'LLVM_ON_UNIX': '1', 'LLVM_VERSION_MAJOR': '18', 'LLVM_VERSION_MINOR': '1', 'LLVM_VERSION_PATCH': '3',
        'PACKAGE_VERSION': '18.1.3', 'HAVE_SYSEXITS_H': '1'}
on = {'LLVM_ENABLE_THREADS', 'LLVM_HAS_ATOMICS', 'LLVM_HOST_TRIPLE', 'LLVM_NATIVE_ARCH', 'LLVM_NATIVE_ASMPARSER',
      'LLVM_NATIVE_ASMPRINTER', 'LLVM_NATIVE_DISASSEMBLER', 'LLVM_NATIVE_TARGET', 'LLVM_NATIVE_TARGETINFO',
      'LLVM_NATIVE_TARGETMC', 'LLVM_NATIVE_TARGETMCA', 'LLVM_ON_UNIX', 'LLVM_ENABLE_ZLIB', 'LLVM_ENABLE_ZSTD',
      'HAVE_SYSEXITS_H', 'LLVM_BUILD_LLVM_DYLIB', 'LLVM_USE_PERF'}   # ABI-breaking checks off, as Ubuntu builds it
targets = ('AArch64 AMDGPU ARM AVR BPF Hexagon Lanai LoongArch M68k Mips MSP430 NVPTX PowerPC RISCV Sparc SystemZ VE '
           'WebAssembly X86 XCore Xtensa').split()
for t in targets:
    on.add('LLVM_HAS_%s_TARGET' % t.upper())


def sub(s):
    return re.sub(r'\$\{(\w+)\}', lambda m: vals.get(m.group(1), ''), s)


def conv(src, dst):
    out = []
    for line in open(src):
        m = re.match(r'#cmakedefine01 (\w+)', line)
        if m:
            out.append('#define %s %d\n' % (m.group(1), 1 if m.group(1) in on else 0))
            continue
        m = re.match(r'#cmakedefine (\w+)(.*)', line)
        if m:
            out.append(('#define %s%s\n' % (m.group(1), sub(m.group(2)))) if m.group(1) in on else '/* #undef %s */\n' % m.group(1))
            continue
        out.append(sub(line))
    open(dst, 'w').write(''.join(out))


conv('llvm-config.h.cmake', 'llvm-config.h')
conv('abi-breaking.h.cmake', 'abi-breaking.h')
for name, macro, kinds in [('Targets', 'LLVM_TARGET', targets), ('AsmPrinters', 'LLVM_ASM_PRINTER', targets),
                           ('AsmParsers', 'LLVM_ASM_PARSER', [t for t in targets if t != 'NVPTX']),
                           ('Disassemblers', 'LLVM_DISASSEMBLER', [t for t in targets if t != 'NVPTX']),
                           ('TargetMCAs', 'LLVM_TARGETMCA', ['AMDGPU', 'RISCV', 'X86']),
                           ('TargetExegesis', 'LLVM_EXEGESIS', ['AArch64', 'Mips', 'PowerPC', 'X86'])]:
    s = open(name + '.def.in').read()
    key = re.search(r'@(\w+)@', s).group(1)
    s = s.replace('@%s@' % key, ''.join('%s(%s)\n' % (macro, t) for t in kinds))
    open(name + '.def', 'w').write(s)
EOF
)
(cd "$I/llvm/IR"
 $TB -I "$L/include" -I "$L/include/llvm/IR" "$L/include/llvm/IR/Attributes.td" -gen-attrs -o Attributes.inc
 $TB -I "$L/include" "$L/include/llvm/IR/Intrinsics.td" -gen-intrinsic-impl -o IntrinsicImpl.inc
 $TB -I "$L/include" "$L/include/llvm/IR/Intrinsics.td" -gen-intrinsic-enums -o IntrinsicEnums.inc
 for p in aarch64:AArch64 amdgcn:AMDGPU arm:ARM bpf:BPF dx:DirectX hexagon:Hexagon loongarch:LoongArch mips:Mips \
          nvvm:NVPTX ppc:PowerPC r600:R600 riscv:RISCV spv:SPIRV s390:S390 wasm:WebAssembly x86:X86 xcore:XCore ve:VE; do
     $TB -I "$L/include" "$L/include/llvm/IR/Intrinsics.td" -gen-intrinsic-enums -intrinsic-prefix="${p%%:*}" -o "Intrinsics${p##*:}.h"
 done)
$TB -I "$L/include" "$L/include/llvm/CodeGen/ValueTypes.td" -gen-vt -o "$I/llvm/CodeGen/GenVT.inc"
printf '#undef LLVM_REVISION\n#undef LLVM_REPOSITORY\n' > "$I/llvm/Support/VCSRevision.h"
touch "$I/llvm/TargetParser/RISCVTargetParserDef.inc"

# ---- llvm-config for meson: the system library with these headers
cat > "$P/bin/lvp-llvm-config" <<EOF
#!/bin/bash
out=()
for a in "\$@"; do case "\$a" in
 --version) out+=("18.1.3");;
 --shared-mode) out+=("shared");;
 --libs) out+=("-lLLVM-18");;
 --ldflags) out+=("-L/usr/lib/x86_64-linux-gnu");;
 --libdir) out+=("/usr/lib/x86_64-linux-gnu");;
 --includedir) out+=("$I");;
 --cppflags|--cflags) out+=("-I$I -D_GNU_SOURCE -D__STDC_CONSTANT_MACROS -D__STDC_FORMAT_MACROS -D__STDC_LIMIT_MACROS");;
 --cxxflags) out+=("-I$I -std=c++17 -fno-exceptions -D_GNU_SOURCE -D__STDC_CONSTANT_MACROS -D__STDC_FORMAT_MACROS -D__STDC_LIMIT_MACROS");;
 --has-rtti) out+=("YES");;
 --assertion-mode) out+=("OFF");;
 --build-mode) out+=("Release");;
 --prefix) out+=("/usr/lib/llvm-18");;
 --bindir) out+=("/usr/lib/llvm-18/bin");;
 --host-target) out+=("x86_64-pc-linux-gnu");;
 --targets-built) out+=("AArch64 AMDGPU ARM AVR BPF Hexagon Lanai LoongArch M68k Mips MSP430 NVPTX PowerPC RISCV Sparc SystemZ VE WebAssembly X86 XCore Xtensa");;
 --components) out+=("all all-targets analysis asmparser asmprinter bitreader bitwriter codegen core coroutines coverage engine executionengine instcombine ipo irreader linker mc mcdisassembler mcjit native nativecodegen object orcjit passes scalaropts selectiondag support target transformutils vectorize x86 x86asmparser x86codegen x86desc x86disassembler x86info amdgpu");;
 *) ;;
esac; done
echo "\${out[*]}"
EOF
chmod +x "$P/bin/lvp-llvm-config"
printf "[binaries]\nllvm-config = '%s'\n" "$P/bin/lvp-llvm-config" > "$P/lvp-native.ini"

# ---- Mesa 24.3.4, lavapipe only
if [ ! -d "$S/mesa/.git" ]; then
    git clone -q --depth 1 -b mesa-24.3.4 https://github.com/chaotic-cx/mesa-mirror.git "$S/mesa"
fi
M=$S/mesa
git -C "$M" checkout -q -- meson.build
sed -i "s/^system_has_kms_drm = .*/system_has_kms_drm = false  # oracle build for Lobo Gelido tests: no libdrm/" "$M/meson.build"
python3 - "$M/meson.build" <<'EOF'
import sys
p = sys.argv[1]
s = open(p).read()
old = "    required : with_dri2 or with_dri or with_gbm\n"
assert old in s
open(p, 'w').write(s.replace(old, "    required : false\n", 1))
EOF
rm -rf "$M/build"
(cd "$M" && meson setup build --native-file "$P/lvp-native.ini" --prefix="$P/lvp" -Dbuildtype=release \
    -Dvulkan-drivers=swrast -Dgallium-drivers=llvmpipe -Dplatforms= -Dglx=disabled -Degl=disabled -Dgles1=disabled \
    -Dgles2=disabled -Dopengl=false -Dgbm=disabled -Dllvm=enabled -Dshared-llvm=enabled -Dvalgrind=disabled \
    -Dlibunwind=disabled -Dzstd=disabled -Dxmlconfig=disabled -Dbuild-tests=false -Dshared-glapi=disabled >/dev/null \
    || { tail -20 build/meson-logs/meson-log.txt; exit 1; }
 meson configure build -Dc_args=-DDRM_FORMAT_MOD_LINEAR=0ULL
 ninja -C build install >/dev/null)
echo "lavapipe listo: $P/lvp/share/vulkan/icd.d/lvp_icd.x86_64.json"
