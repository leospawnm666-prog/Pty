#!/usr/bin/env python3
# P4.3 T2-T (P4_3_DISENO.md §5.2): one test per form of the texture and image instructions.
#
# Each case is a compute program (64 invocations) assembled with envyas (envytools, MIT); the forms
# envyas does not write (bindless TEX, the scalar targets, register-handle surfaces) are raw words
# built from the field layout of the envydis tables. The scaffold loads each invocation's sources
# from c2 (R8..R11 = words 0..3, R20..R23 = words 4..7), runs the instruction and stores R0..R7 to a
# storage buffer. The textures hold their own address: texel(slot, x, y, k, level), k being the
# layer, cube face or 3D slice (the same formula is in tests/test_shader_t2t.cpp), so the result of
# every form is computed HERE from the documented semantics (Vulkan sampling rules for nearest
# filtering, gather order, cube face selection; the source/destination layouts of P4_3_DISENO.md
# §4), independently of the recompiler. Images: the expected contents after the run as well.
#
# Usage: gen_shader_t2t.py <envyas> <out .h>
import os
import re
import struct
import subprocess
import sys
import tempfile

ENVYAS, OUT = sys.argv[1:3]
SCHED = 0x001f8000fc0007e0
TMP = tempfile.mkdtemp()
PT = 7 << 16
TEX_BASE = 0xa0 // 4        # deko3d compute: texture handles at c0[0xa0 + 4·slot] (immediate = word)
IMG_BASE = 0x120 // 4       # images at c0[0x120 + 4·slot]


def f2u(f):
    return struct.unpack('<I', struct.pack('<f', f))[0]


def u32(x):
    return x & 0xffffffff


# ---------------------------------------------------------------- assembly
def assemble(lines):
    insns = []
    for ln in lines:
        insns.append(ln)
    raw = {}
    text = []
    for k, ln in enumerate(insns):
        if ln.startswith('raw '):
            raw[k] = int(ln.split()[1], 0)
            text.append('mov $r0 $r0 0xf')
        else:
            text.append(ln)
    src = os.path.join(TMP, 'p.s')
    open(src, 'w').write('\n'.join(text) + '\n')
    out = src + '.bin'
    r = subprocess.run([ENVYAS, '-m', 'gm107', '-w', src, '-o', out], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit('envyas failed on:\n%s\n%s' % ('\n'.join(text), r.stderr))
    w = [int(x, 16) for x in re.findall(r'0x[0-9a-f]+', open(out).read())]
    words = []
    for k in range(len(insns)):
        words.append(raw[k] if k in raw else w[2 * k] | (w[2 * k + 1] << 32))
    code = []
    for i, x in enumerate(words):
        if len(code) % 4 == 0:
            code.append(SCHED)
        code.append(x)
    while len(code) % 4:
        code.append(0x50b0000000070f00 if len(code) % 4 else SCHED)
    return code


PROLOGUE = [
    'mov $r40 $tidx',
    'shl $r41 $r40 0x5',
    'ld b32 $r8 c2[$r41]', 'ld b32 $r9 c2[$r41+0x4]', 'ld b32 $r10 c2[$r41+0x8]', 'ld b32 $r11 c2[$r41+0xc]',
    'ld b32 $r20 c2[$r41+0x10]', 'ld b32 $r21 c2[$r41+0x14]', 'ld b32 $r22 c2[$r41+0x18]', 'ld b32 $r23 c2[$r41+0x1c]',
] + ['mov32i $r%d 0x0 0xf' % r for r in range(8)]
EPILOGUE = [
    'iadd cc $r43 $r41 c0[0x140]',
    'iadd x $r44 $r255 c0[0x144]',
] + ['stg e b32 ncg[$r43+0x%x] $r%d' % (4 * r, r) for r in range(8)] + ['exit']


# ---------------------------------------------------------------- the textures
def texel(slot, x, y, k, l):
    return (u32(x + 1000 * l), u32(y + 1000 * k), u32((x * 3 + y * 5 + k * 7 + l * 11) & 0xff), u32(0xb00 + slot))


def depth(x, y, k, l):
    return ((x * 7 + y * 3 + k * 5 + l) % 16) / 16.0 + 1.0 / 32.0


class Tex:
    """slot (handle word index from TEX_BASE/IMG_BASE), view, fmt, w, h, d (layers / depth / 6),
    levels; fmt: u RGBA32UI, f RGBA32F, d D32 (compare LESS), r R32UI, s R32I, v RG32UI, 8 R8UI,
    w R16UI; handle: explicit c0 byte offset (bindless tests) or None (the slot's)."""

    def __init__(self, slot, view, fmt, w, h=1, d=1, levels=1, storage=False, handle=None, compare=False):
        self.slot, self.view, self.fmt, self.w, self.h, self.d, self.levels = slot, view, fmt, w, h, d, levels
        self.storage, self.compare = storage, compare
        self.handle = handle if handle is not None else 4 * ((IMG_BASE if storage else TEX_BASE) + slot)

    def dims(self, l):
        w = max(1, self.w >> l)
        h = 1 if self.view in ('1d', '1da') else max(1, self.h >> l)
        d = max(1, self.d >> l) if self.view == '3d' else 1
        return w, h, d

    def layers(self):
        return self.d if self.view in ('2da', '1da', 'cube', 'cubea') else (self.h if self.view == '1da' else 1)

    def value(self, x, y, k, l):
        if self.fmt == 'd':
            return (f2u(depth(x, y, k, l)), 0, 0, 0)
        t = texel(self.slot, x, y, k, l)
        if self.fmt == 'f':
            return tuple(f2u(float(c)) for c in t)
        if self.fmt in ('r', 's'):
            return (u32(x * 16 + y + k * 256 + 0x10000 * self.slot), 0, 0, 0)
        if self.fmt == 'v':
            return (t[0], t[1], 0, 0)
        if self.fmt == '8':
            return ((x * 5 + y * 3 + k + 0x80) & 0xff, 0, 0, 0)
        if self.fmt == 'w':
            return ((x * 701 + y * 33 + k * 7 + 0x8000) & 0xffff, 0, 0, 0)
        return t

    def fetch(self, x, y, k, l):   # clamp to edge
        w, h, d = self.dims(l)
        x = min(max(x, 0), w - 1)
        y = min(max(y, 0), h - 1)
        if self.view == '3d':
            k = min(max(k, 0), d - 1)
        return self.value(x, y, k, l)


cases = []


def case(name, body, texs, inputs, expect, image_expect=None, flags=''):
    """inputs: per invocation 8 words (R8..R11, R20..R23); expect: per invocation 8 words (R0..R7);
    image_expect: {slot: list of words of the whole image after the run}."""
    code = assemble(PROLOGUE + body + EPILOGUE)
    cases.append(dict(name=name, code=code, texs=texs, inputs=inputs, expect=expect, images=image_expect or {},
                      body=' | '.join(body), flags=flags))


N = 64


def center(i, n):
    return (i + 0.5) / n


def ins(*words):
    w = [u32(x) if isinstance(x, int) else f2u(x) for x in words]
    return w + [0] * (8 - len(w))


def outs(*words):
    w = [u32(x) for x in words]
    return w + [0] * (8 - len(w))


# ---------------------------------------------------------------- TEX (non-scalar)
T2D = Tex(0, '2d', 'u', 8, 8, 1, 4)


def tid_xy(t, w=8):
    return t % w, (t // w) % w


def tex_2d(name, mod, lodsrc, mask=0xf, dst='$r0'):
    inputs, expect = [], []
    for t in range(N):
        x, y = tid_xy(t)
        l = t % 4
        r20 = []
        if lodsrc == 'lod':
            r20 = [float(l)]
        elif lodsrc == 'bias':   # compute: the bias is the level (no derivatives)
            r20 = [float(l)]
        else:
            l = 0
        inputs.append(ins(center(x, 8), center(y, 8), 0, 0, *r20))
        v = T2D.fetch(x >> l, y >> l, 0, l)
        comps = [v[c] for c in range(4) if (mask >> c) & 1]
        expect.append(outs(*comps))
    case(name, ['tex %s %s $r8 $r20 0x%x t2d 0x%x' % (mod, dst, TEX_BASE + T2D.slot, mask)], [T2D], inputs, expect)


tex_2d('tex_2d_implicit', '', None)
tex_2d('tex_2d_lz', 'lz', None)
tex_2d('tex_2d_ll', 'll', 'lod')
tex_2d('tex_2d_lb', 'lb', 'bias')
tex_2d('tex_2d_mask5', 'll', 'lod', mask=0x5)
tex_2d('tex_2d_mask8', 'll', 'lod', mask=0x8)

# AOFFI: offset (1, -1) in R20 after the lod
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    inputs.append(ins(center(x, 8), center(y, 8), 0, 0, 0.0, 0))
    expect.append(outs(*T2D.fetch(x + 1, y - 1, 0, 0)))
case('tex_aoffi', ['mov32i $r21 0xf1 0xf', 'tex ll aoffi $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + T2D.slot)], [T2D], inputs, expect)

# arrays: R8 = layer, u, v
TA = Tex(1, '2da', 'u', 8, 8, 4, 2)
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    k, l = t % 4, (t // 4) % 2
    inputs.append(ins(k | 0xabcd0000, center(x, 8), center(y, 8), 0, float(l)))   # the layer is the low 16 bits
    expect.append(outs(*TA.fetch(x >> l, y >> l, k, l)))
case('tex_array_ll', ['tex ll $r0 $r8 $r20 0x%x array t2d 0xf' % (TEX_BASE + TA.slot)], [TA], inputs, expect)

T3 = Tex(2, '3d', 'f', 4, 4, 4, 2)
inputs, expect = [], []
for t in range(N):
    x, y, z = t % 4, (t // 4) % 4, (t // 16) % 4
    l = t % 2
    inputs.append(ins(center(x, 4), center(y, 4), center(z, 4), 0, float(l)))
    expect.append(outs(*T3.fetch(x >> l, y >> l, z >> l, l)))
case('tex_3d_ll', ['tex ll $r0 $r8 $r20 0x%x t3d 0xf' % (TEX_BASE + T3.slot)], [T3], inputs, expect)

T1 = Tex(3, '1d', 'u', 16, 1, 1, 2)
inputs, expect = [], []
for t in range(N):
    x, l = t % 16, (t // 16) % 2
    inputs.append(ins(center(x, 16), 0, 0, 0, float(l)))
    expect.append(outs(*T1.fetch(x >> l, 0, 0, l)))
case('tex_1d_ll', ['tex ll $r0 $r8 $r20 0x%x t1d 0xf' % (TEX_BASE + T1.slot)], [T1], inputs, expect)


# cube: a direction through texel (i, j) of face f (Vulkan's major-axis table, 16.5.4)
def cube_dir(f, i, j, n):
    sc = 2.0 * (i + 0.5) / n - 1.0
    tc = 2.0 * (j + 0.5) / n - 1.0
    if f == 0: return (1.0, -tc, -sc)
    if f == 1: return (-1.0, -tc, sc)
    if f == 2: return (sc, 1.0, tc)
    if f == 3: return (sc, -1.0, -tc)
    if f == 4: return (sc, -tc, 1.0)
    return (-sc, -tc, -1.0)


TC = Tex(4, 'cube', 'u', 4, 4, 6, 1)
inputs, expect = [], []
for t in range(N):
    f, i, j = t % 6, (t // 6) % 4, (t // 24) % 4
    inputs.append(ins(*cube_dir(f, i, j, 4), 0, 0.0))
    expect.append(outs(*TC.fetch(i, j, f, 0)))
case('tex_cube_ll', ['tex ll $r0 $r8 $r20 0x%x tcube 0xf' % (TEX_BASE + TC.slot)], [TC], inputs, expect)

# depth compare (nearest, LESS: pass when dref < texel)
TD = Tex(5, '2d', 'd', 8, 8, 1, 1, compare=True)
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    ref = ((t * 5) % 17) / 16.0
    inputs.append(ins(center(x, 8), center(y, 8), 0, 0, 0.0, ref))
    expect.append(outs(f2u(1.0 if ref < depth(x, y, 0, 0) else 0.0)))
case('tex_dc_ll', ['tex ll dc $r0 $r8 $r20 0x%x t2d 0x1' % (TEX_BASE + TD.slot)], [TD], inputs, expect)

# bindless TEX: the handle is the first R20 source, loaded from a cbuf word (traced: bound at 0x200)
TB = Tex(6, '2d', 'u', 8, 8, 1, 4, handle=0x200)
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    l = t % 4
    inputs.append(ins(center(x, 8), center(y, 8), 0, 0, 0, float(l)))
    expect.append(outs(*TB.fetch(x >> l, y >> l, 0, l)))
w = 0xdeb8000000000000 | (3 << 37) | (0xf << 31) | (1 << 29) | (20 << 20) | (8 << 8) | 0 | PT
case('tex_bindless_ll', ['mov $r20 c0[0x200] 0xf', 'raw 0x%016x' % w], [TB], inputs, expect)

# bindless TXQ (R8 = handle, lod) and TLD4 (R20 = handle first)
inputs, expect = [], []
for t in range(N):
    l = t % 4
    inputs.append(ins(0, l))
    expect.append(outs(8 >> l, 8 >> l, 1, 4))
w = 0xdf50000000000000 | (0xf << 31) | (1 << 22) | (8 << 8) | 0 | PT
case('txq_bindless', ['mov $r8 c0[0x200] 0xf', 'raw 0x%016x' % w], [TB], inputs, expect)   # (2D: the shape of a TXQ alone)

# ---------------------------------------------------------------- TLD
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    l = t % 4
    inputs.append(ins(x >> l, y >> l, 0, 0, l))
    expect.append(outs(*T2D.fetch(x >> l, y >> l, 0, l)))
case('tld_2d_ll', ['tld ll $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + T2D.slot)], [T2D], inputs, expect)
inputs, expect = [], []
for t in range(N):   # (x, y) with (x - 2, y + 3) inside the texture: an out-of-range fetch is undefined
    x, y = 2 + t % 6, (t // 6) % 5
    inputs.append(ins(x, y, 0, 0, 0))
    expect.append(outs(*T2D.fetch(x - 2, y + 3, 0, 0)))
case('tld_2d_lz_aoffi', ['mov32i $r20 0x3e 0xf', 'tld lz aoffi $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + T2D.slot)],
     [T2D], inputs, expect)
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    k = t % 4
    inputs.append(ins(k, x >> 1, y >> 1, 0, 1))
    expect.append(outs(*TA.fetch(x >> 1, y >> 1, k, 1)))
case('tld_array_ll', ['tld ll $r0 $r8 $r20 0x%x array t2d 0xf' % (TEX_BASE + TA.slot)], [TA], inputs, expect)

# ---------------------------------------------------------------- TLD4 (gather)
TG = Tex(7, '2d', 'u', 16, 16, 1, 1)   # footprints (with offsets) stay inside: edge behaviour differs between oracles


def gather(tex, x0, y0, comp, k=0, off=(0, 0)):
    i0, j0 = x0 + off[0], y0 + off[1]
    pts = [(i0, j0 + 1), (i0 + 1, j0 + 1), (i0 + 1, j0), (i0, j0)]
    return [tex.fetch(i, j, k, 0)[comp] for i, j in pts]


for comp, cn in enumerate('rgba'):
    inputs, expect = [], []
    for t in range(N):
        x, y = 2 + t % 8, 2 + (t // 8) % 8
        inputs.append(ins((x + 1) / 16.0, (y + 1) / 16.0))
        expect.append(outs(*gather(TG, x, y, comp)))
    case('tld4_%s' % cn, ['tld4 %s $r0 $r8 $r20 0x%x t2d 0xf' % (cn, TEX_BASE + TG.slot)], [TG], inputs, expect)
inputs, expect = [], []
for t in range(N):
    x, y = 2 + t % 8, 2 + (t // 8) % 8
    inputs.append(ins((x + 1) / 16.0, (y + 1) / 16.0))
    expect.append(outs(*gather(TG, x, y, 1, off=(2, -3))))
case('tld4_aoffi', ['mov32i $r20 0xfd02 0xf', 'tld4 g aoffi $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + TG.slot)], [TG], inputs,
     expect)
inputs, expect = [], []
offs = [(1, 0), (-2, 3), (0, -1), (4, 4)]
for t in range(N):
    x, y = 2 + t % 8, 2 + (t // 8) % 8
    inputs.append(ins((x + 1) / 16.0, (y + 1) / 16.0))
    # PTP: texel n of the result comes from the gather at offset n, at its position n
    g = [gather(TG, x, y, 2, off=offs[n])[3] for n in range(4)]   # GLSL: texel i0j0 of the footprint at offset n
    expect.append(outs(*g))
ptp0 = (offs[0][0] & 0xff) | (offs[0][1] & 0xff) << 8 | (offs[1][0] & 0xff) << 16 | (offs[1][1] & 0xff) << 24
ptp1 = (offs[2][0] & 0xff) | (offs[2][1] & 0xff) << 8 | (offs[3][0] & 0xff) << 16 | (offs[3][1] & 0xff) << 24
case('tld4_ptp', ['mov32i $r20 0x%x 0xf' % ptp0, 'mov32i $r21 0x%x 0xf' % ptp1,
                  'tld4 b ptp $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + TG.slot)], [TG], inputs, expect)
TGB = Tex(17, '2d', 'u', 16, 16, 1, 1, handle=0x204)
inputs, expect = [], []
for t in range(N):
    x, y = 2 + t % 8, 2 + (t // 8) % 8
    inputs.append(ins((x + 1) / 16.0, (y + 1) / 16.0))
    expect.append(outs(*gather(TGB, x, y, 3)))
w = 0xdef8000000000000 | (3 << 38) | (0xf << 31) | (1 << 29) | (20 << 20) | (8 << 8) | PT
case('tld4_bindless', ['mov $r20 c0[0x204] 0xf', 'raw 0x%016x' % w], [TGB], inputs, expect)
TGD = Tex(8, '2d', 'd', 16, 16, 1, 1, compare=True)
inputs, expect = [], []
for t in range(N):
    x, y = 2 + t % 8, 2 + (t // 8) % 8
    ref = ((t * 3) % 17) / 16.0
    inputs.append(ins((x + 1) / 16.0, (y + 1) / 16.0, 0, 0, ref))
    pts = [(x, y + 1), (x + 1, y + 1), (x + 1, y), (x, y)]
    expect.append(outs(*[f2u(1.0 if ref < depth(i, j, 0, 0) else 0.0) for i, j in pts]))
case('tld4_dc', ['tld4 r dc $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + TGD.slot)], [TGD], inputs, expect)

# ---------------------------------------------------------------- TXD: gradients giving an exact level
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    l = t % 4
    g = (2 ** l) / 8.0
    inputs.append(ins(center(x, 8), center(y, 8), 0, 0, g, 0.0, 0.0, g))
    expect.append(outs(*T2D.fetch(x >> l, y >> l, 0, l)))
case('txd_2d', ['txd $r0 $r8 $r20 0x%x t2d 0xf' % (TEX_BASE + T2D.slot)], [T2D], inputs, expect)

# ---------------------------------------------------------------- TXQ dimensions (model: w, h, depth|layers, levels; 1 if absent)
for tex, tn in ((T2D, '2d'), (TA, 'array'), (T3, '3d'), (T1, '1d'), (TC, 'cube')):
    inputs, expect = [], []
    for t in range(N):
        l = t % tex.levels
        w_, h_, d_ = tex.dims(l)
        z = tex.layers() if tex.view in ('2da', '1da') else d_ if tex.view == '3d' else 1
        if tex.view == 'cube':
            z = 1
        inputs.append(ins(l))
        expect.append(outs(w_, h_ if tex.view != '1d' else 1, z, tex.levels))
    dims = {'2d': 't2d', '2da': 'array t2d', '3d': 't3d', '1d': 't1d', 'cube': 'tcube'}[tex.view]
    # a use of the handle that gives its shape (a TXQ alone does not), writing R4..R7
    case('txq_%s' % tn, ['tex lz $r4 $r8 $r20 0x%x %s 0x1' % (TEX_BASE + tex.slot, dims),
                         'txq $r0 $r8 dimension 0x%x 0xf' % (TEX_BASE + tex.slot), 'mov32i $r4 0x0 0xf'], [tex], inputs, expect)

# ---------------------------------------------------------------- scalar forms (raw words: target/mask tables)
TEXS_T = {0: ('1d', 'lz'), 1: ('2d', ''), 2: ('2d', 'lz'), 3: ('2d', 'll'), 4: ('2d', 'dc'), 5: ('2d', 'lldc'),
          6: ('2d', 'lzdc'), 7: ('a2d', ''), 8: ('a2d', 'lz'), 9: ('a2d', 'lzdc'), 10: ('3d', ''), 11: ('3d', 'lz'),
          12: ('cube', ''), 13: ('cube', 'll')}
TWO = {0: 0x1, 1: 0x2, 2: 0x4, 3: 0x8, 4: 0x3, 5: 0x9, 6: 0xa, 7: 0xc}
FOUR = {0: 0x7, 1: 0xb, 2: 0xd, 3: 0xe, 4: 0xf}


def scalar_word(base, target, code, handle, r28, r0=0, r8=8, r20=20):
    return base | (target << 53) | (code << 50) | (handle << 36) | (r28 << 28) | (r20 << 20) | PT | (r8 << 8) | r0


def place(src, r8=8, r20=20):
    """the registers of a scalar source list: 1: R8 | 2: R8, R20 | 3: (R8, R8+1), R20 | 4: pairs."""
    n = len(src)
    if n <= 2:
        regs = [r8, r20][:n]
    elif n == 3:
        regs = [r8, r8 + 1, r20]
    else:
        regs = [r8, r8 + 1, r20, r20 + 1]
    words = {}
    for v, r in zip(src, regs):
        words[r] = v
    return [words.get(8, 0), words.get(9, 0), words.get(10, 0), words.get(11, 0),
            words.get(20, 0), words.get(21, 0), words.get(22, 0), words.get(23, 0)]


def scalar_dst(mask, vals, four):
    """components of the mask, in order, to R0, R1, R4, R5 (R28 = R4)."""
    slots = [0, 1, 4, 5]
    out = [0] * 8
    s = 0
    for c in range(4):
        if (mask >> c) & 1:
            out[slots[s]] = vals[c]
            s += 1
    return out


TS2 = Tex(9, '2d', 'u', 8, 8, 1, 4)
TSA = Tex(10, '2da', 'u', 8, 8, 4, 1)
TS3 = Tex(11, '3d', 'u', 4, 4, 4, 1)
TS1 = Tex(12, '1d', 'u', 16, 1, 1, 1)
TSC = Tex(13, 'cube', 'u', 4, 4, 6, 2)
TSD = Tex(14, '2d', 'd', 8, 8, 1, 2, compare=True)
TSAD = Tex(15, '2da', 'd', 8, 8, 4, 1, compare=True)
for tg, (kind, mods) in TEXS_T.items():
    for code_set, four in (((4, 0, 7, 5, 6), False), ((4, 0, 2), True)):
        for code in code_set:
            if four and code > 4:
                continue
            mask = FOUR[code] if four else TWO[code]
            dc = 'dc' in mods
            if dc and (mask & ~1):
                continue   # depth compare: one component
            tex = {'1d': TS1, '2d': TSD if dc else TS2, 'a2d': TSAD if dc else TSA, '3d': TS3, 'cube': TSC}[kind]
            inputs, expect = [], []
            for t in range(N):
                l = (t % 2) if 'll' in mods else 0
                if kind == 'cube':
                    f, i, j = t % 6, (t // 6) % 4, (t // 24) % 4
                    src = list(cube_dir(f, i, j, 4))
                    i, j = i >> l, j >> l
                    if 'll' in mods:
                        src.append(float(l))
                    v = tex.fetch(i, j, f, l)
                elif kind == '3d':
                    x, y, z = t % 4, (t // 4) % 4, (t // 16) % 4
                    src = [center(x, 4), center(y, 4), center(z, 4)]
                    v = tex.fetch(x, y, z, 0)
                elif kind == '1d':
                    x = t % 16
                    src = [center(x, 16)]
                    v = tex.fetch(x, 0, 0, 0)
                else:
                    x, y = tid_xy(t)
                    k = t % 4 if kind == 'a2d' else 0
                    src = ([k] if kind == 'a2d' else []) + [center(x, 8), center(y, 8)]
                    if 'll' in mods:
                        src.append(float(l))
                    if dc:
                        ref = ((t * 5) % 17) / 16.0
                        src.append(ref)
                        v = (f2u(1.0 if ref < depth(x >> l, y >> l, k, l) else 0.0), 0, 0, 0)
                    else:
                        v = tex.fetch(x >> l, y >> l, k, l)
                inputs.append(place([f2u(s) if isinstance(s, float) else s for s in src]))
                expect.append(scalar_dst(mask, v, four))
            word = scalar_word(0xd800000000000000, tg, code, TEX_BASE + tex.slot, 4 if four else 0xff)
            case('texs_t%x_%s%s' % (tg, 'rgba'[:0] + ('m%x' % mask), '_r28' if four else ''), ['raw 0x%016x' % word], [tex],
                 inputs, expect)

TLDS_T = {0: ('1d', 'lz', False), 1: ('1d', 'll', False), 2: ('2d', 'lz', False), 4: ('2d', 'lz', True),
          5: ('2d', 'll', False), 7: ('3d', 'lz', False), 8: ('a2d', 'lz', False), 12: ('2d', 'll', True)}
TL1 = Tex(16, '1d', 'u', 16, 1, 1, 2)
for tg, (kind, mods, aoffi) in TLDS_T.items():
    tex = {'1d': TL1, '2d': TS2, '3d': TS3, 'a2d': TSA}[kind]
    inputs, expect = [], []
    for t in range(N):
        l = (t % 2) if mods == 'll' else 0
        off = (1, -2) if aoffi else (0, 0)
        if kind == '1d':
            x = (t % 16) >> l
            src = [x] + ([l] if mods == 'll' else [])
            v = tex.fetch(x, 0, 0, l)
        elif kind == '3d':
            x, y, z = t % 4, (t // 4) % 4, (t // 16) % 4
            src = [x, y, z]
            v = tex.fetch(x, y, z, 0)
        elif kind == 'a2d':
            x, y = tid_xy(t)
            k = t % 4
            src = [k, x, y]
            v = tex.fetch(x, y, k, 0)
        else:
            x, y = tid_xy(t)
            x, y = x >> l, y >> l
            if aoffi:   # (x + 1, y - 2) inside the level: an out-of-range fetch is undefined
                wl = 8 >> l
                x, y = t % (wl - 1), 2 + (t // (wl - 1)) % (wl - 2)
            src = [x, y] + ([l] if mods == 'll' else []) + ([u32((off[0] & 0xf) | (off[1] & 0xf) << 4)] if aoffi else [])
            v = tex.fetch(x + off[0], y + off[1], 0, l)
        if kind == 'a2d':   # TLDS 2D array: R8 = layer, R20 = (x, y)
            words = [src[0], 0, 0, 0, src[1], src[2], 0, 0]
        else:
            words = place(src)
        inputs.append(words)
        expect.append(scalar_dst(0xf, v, True))
    word = scalar_word(0xda00000000000000, tg, 4, TEX_BASE + tex.slot, 4)
    pre = []
    if aoffi:   # the offset register must be a constant (D-P4.3-3): R20 (lz) or R21 (ll)
        pre = ['mov32i $r%d 0x%x 0xf' % (20 if mods == 'lz' else 21, (1 & 0xf) | ((-2 & 0xf) << 4))]
    case('tlds_t%x' % tg, pre + ['raw 0x%016x' % word], [tex], inputs, expect)

for comp in range(4):
    for aoffi, dc in ((False, False), (True, False), (False, True), (True, True)):
        tex = TGD if dc else TG
        inputs, expect = [], []
        for t in range(N):
            x, y = 2 + t % 8, 2 + (t // 8) % 8
            off = (-1, 2) if aoffi else (0, 0)
            src = [f2u((x + 1) / 16.0), f2u((y + 1) / 16.0)]
            if aoffi:
                src.append(u32((off[0] & 0xff) | (off[1] & 0xff) << 8))
            if dc:
                ref = ((t * 3) % 17) / 16.0
                src.append(f2u(ref))
                pts = [(x + off[0], y + off[1] + 1), (x + off[0] + 1, y + off[1] + 1), (x + off[0] + 1, y + off[1]),
                       (x + off[0], y + off[1])]
                vals = [f2u(1.0 if ref < depth(i, j, 0, 0) else 0.0) for i, j in pts]
            else:
                vals = gather(tex, x, y, comp, off=off)
            inputs.append(place(src))
            expect.append(scalar_dst(0xf, vals, True))
        if dc and comp:
            continue
        word = 0xdf00000000000000 | (comp << 52) | (int(aoffi) << 51) | (int(dc) << 50) | ((TEX_BASE + tex.slot) << 36) | \
            (4 << 28) | (20 << 20) | PT | (8 << 8)
        case('tld4s_%s%s%s' % ('rgba'[comp], '_aoffi' if aoffi else '', '_dc' if dc else ''), ['raw 0x%016x' % word], [tex],
             inputs, expect)

# ---------------------------------------------------------------- images
def img_words(tex):
    out = []
    w, h, d = tex.dims(0)
    for k in range(tex.layers() if tex.view in ('2da', '1da') else d):
        for y in range(h):
            for x in range(w):
                v = tex.value(x, y, k, 0)
                n = {'u': 4, 'f': 4, 'v': 2}.get(tex.fmt, 1)
                out.extend(v[:n])
    return out


def pack_small(words, fmt):
    """8/16-bit images: the words as bytes of the texel stream."""
    if fmt == '8':
        b = bytes(x & 0xff for x in words)
    elif fmt == 'w':
        b = b''.join(struct.pack('<H', x & 0xffff) for x in words)
    else:
        return words
    b += b'\0' * (-len(b) % 4)
    return list(struct.unpack('<%dI' % (len(b) // 4), b))


IR = Tex(0, '2d', 'r', 8, 8, storage=True)
IU = Tex(1, '2d', 'u', 8, 8, storage=True)
IV = Tex(2, '2d', 'v', 8, 8, storage=True)
I8 = Tex(3, '2d', '8', 8, 8, storage=True)
IW = Tex(4, '2d', 'w', 8, 8, storage=True)
IS = Tex(5, '2d', 's', 8, 8, storage=True)
IA = Tex(6, '2da', 'u', 4, 4, 4, storage=True)

SIZES = {'u8': (0, I8), 's8': (1, I8), 'u16': (2, IW), 's16': (3, IW), 'b32': (4, IR), 'b64': (5, IV), 'b128': (6, IU)}


def sext(v, b):
    v &= (1 << b) - 1
    return v - (1 << b) if v >> (b - 1) else v


for sz, (code, tex) in SIZES.items():
    inputs, expect = [], []
    for t in range(N):
        x, y = tid_xy(t)
        inputs.append(ins(x, y if t < 60 else 9))   # the last ones out of range: 0
        v = tex.value(x, y, 0, 0) if t < 60 else (0, 0, 0, 0)
        n = {4: 1, 5: 2, 6: 4}.get(code, 1)
        vals = list(v[:n])
        if sz == 's8':
            vals = [u32(sext(v[0], 8))] if t < 60 else [0]
        if sz == 's16':
            vals = [u32(sext(v[0], 16))] if t < 60 else [0]
        expect.append(outs(*vals))
    junk = ['mov32i $r%d 0x%x 0xf' % (c, 0xdead0000 + c) for c in range(n)]   # out of range: overwritten with 0
    case('suld_d_%s' % sz, junk + ['suld d t2d %s ign $r0 g[$r8] 0x%x' % (sz, IMG_BASE + tex.slot)], [tex], inputs, expect)

for mask in (0xf, 0x5, 0x2):
    names = ''.join('rgba'[c] for c in range(4) if (mask >> c) & 1)
    inputs, expect = [], []
    for t in range(N):
        x, y = tid_xy(t)
        inputs.append(ins(x, y))
        v = IU.value(x, y, 0, 0)
        expect.append(outs(*[v[c] for c in range(4) if (mask >> c) & 1]))
    case('suld_p_%s' % names, ['suld p t2d %s ign $r0 g[$r8] 0x%x' % (names, IMG_BASE + IU.slot)], [IU], inputs, expect)

# array image: (x, y, layer)
inputs, expect = [], []
for t in range(N):
    x, y, k = t % 4, (t // 4) % 4, (t // 16) % 4
    inputs.append(ins(x, y, k))
    expect.append(outs(*IA.value(x, y, k, 0)))
case('suld_p_array', ['suld p a2d rgba ign $r0 g[$r8] 0x%x' % (IMG_BASE + IA.slot)], [IA], inputs, expect)

# stores: every invocation writes its texel; the image is compared afterwards
for sz, (code, tex) in SIZES.items():
    inputs, expect = [], []
    img = img_words(tex)
    n = {4: 1, 5: 2, 6: 4}.get(code, 1)
    per = {'u': 4, 'v': 2}.get(tex.fmt, 1)
    for t in range(N):
        x, y = tid_xy(t)
        data = [u32(0x5a000000 + t * 16 + c) for c in range(n)]
        inputs.append(ins(x, y, 0, 0, *([0] * 4)))
        inputs[-1][0:2] = [x, y]
        expect.append(outs(*data))   # R0.. keep the data
        mask = 0xff if code < 2 else 0xffff if code < 4 else 0xffffffff
        for c in range(n):
            img[(y * 8 + x) * per + c] = data[c] & mask
    body = ['mov32i $r%d 0x%x 0xf' % (c, 0) for c in range(0)]
    # the data: R0.. from c2 words 4.. (R20..) moved to R0..
    body = ['mov $r%d $r%d 0xf' % (c, 20 + c) for c in range(n)] + \
        ['sust d t2d %s ign g[$r8] $r0 0x%x' % (sz, IMG_BASE + tex.slot)]
    for t in range(N):
        inputs[t][4:4 + n] = [u32(0x5a000000 + t * 16 + c) for c in range(n)]
    case('sust_d_%s' % sz, body, [tex], inputs, expect, {tex.slot: pack_small(img, tex.fmt)})

inputs, expect = [], []
img = img_words(IU)
for t in range(N):
    x, y = tid_xy(t)
    data = [u32(0x77000000 + t * 4 + c) for c in range(4)]
    inputs.append(ins(x, y, 0, 0, *data))
    expect.append(outs(*data))
    img[(y * 8 + x) * 4:(y * 8 + x) * 4 + 4] = data
case('sust_p_rgba', ['mov $r0 $r20 0xf', 'mov $r1 $r21 0xf', 'mov $r2 $r22 0xf', 'mov $r3 $r23 0xf',
                     'sust p t2d rgba ign g[$r8] $r0 0x%x' % (IMG_BASE + IU.slot)], [IU], inputs, expect, {IU.slot: img})

# atomics (SUATOM.D with the type at bits 51-53; one texel per invocation)
ATOM = [('add', lambda o, d: o + d), ('min', None), ('max', None), ('and', lambda o, d: o & d), ('or', lambda o, d: o | d),
        ('xor', lambda o, d: o ^ d), ('exch', lambda o, d: d)]
for signed, tex in ((False, IR), (True, IS)):
    for op, fn in ATOM:
        inputs, expect = [], []
        img = img_words(tex)
        for t in range(N):
            x, y = tid_xy(t)
            d = u32((t * 0x01010101) ^ 0x80000003) if signed else u32(t * 0x01010101 + 5)
            inputs.append(ins(x, y, 0, 0, d))
            old = tex.value(x, y, 0, 0)[0]
            if op in ('min', 'max'):
                a, b = (sext(old, 32), sext(d, 32)) if signed else (old, d)
                new = u32(min(a, b) if op == 'min' else max(a, b))
            else:
                new = u32(fn(old, d))
            expect.append(outs(old))
            img[y * 8 + x] = new
        case('suatom_%s_%s' % ('s32' if signed else 'u32', op),
             ['suatom d %s t2d %s ign $r0 g[$r8] $r20 0x%x' % ('s32' if signed else 'u32', op, IMG_BASE + tex.slot)],
             [tex], inputs, expect, {tex.slot: img})

# out of range (the last 4 invocations): the image is unchanged and the destination (junk before) becomes 0
inputs, expect = [], []
img = img_words(IR)
for t in range(N):
    x, y = tid_xy(t)
    inputs.append(ins(x, y if t < 60 else 9, 0, 0, t + 1))
    if t < 60:
        expect.append(outs(IR.value(x, y, 0, 0)[0]))
        img[y * 8 + x] = u32(IR.value(x, y, 0, 0)[0] + t + 1)
    else:
        expect.append(outs(0))
case('suatom_oob', ['mov32i $r0 0xdead0000 0xf', 'suatom d u32 t2d add ign $r0 g[$r8] $r20 0x%x' % (IMG_BASE + IR.slot)],
     [IR], inputs, expect, {IR.slot: img})

# CAS (R20 = comparator, R21 = value) succeeds on even invocations
inputs, expect = [], []
img = img_words(IR)
for t in range(N):
    x, y = tid_xy(t)
    old = IR.value(x, y, 0, 0)[0]
    cmpv = old if t % 2 == 0 else u32(old + 1)
    inputs.append(ins(x, y, 0, 0, cmpv, u32(0xcafe0000 + t)))
    expect.append(outs(old))
    if t % 2 == 0:
        img[y * 8 + x] = u32(0xcafe0000 + t)
w = 0xea80000000000000 | (0 << 51) | (3 << 33) | (IMG_BASE + IR.slot) << 36 | (20 << 20) | PT | (8 << 8)
case('suatom_cas', ['raw 0x%016x' % w], [IR], inputs, expect, {IR.slot: img})

# SURED (no result): add
inputs, expect = [], []
img = img_words(IR)
for t in range(N):
    x, y = tid_xy(t)
    inputs.append(ins(x, y, 0, 0, t + 1))
    expect.append(outs(t + 1))
    img[y * 8 + x] = u32(IR.value(x, y, 0, 0)[0] + t + 1)
case('sured_add', ['mov $r0 $r20 0xf', 'sured d t2d add ign g[$r8] $r0 0x%x' % (IMG_BASE + IR.slot)], [IR], inputs, expect,
     {IR.slot: img})

# register handle (bit 51 clear, handle in REG_39), traced to a cbuf word: bound at 0x210
IRB = Tex(7, '2d', 'r', 8, 8, storage=True, handle=0x210)
inputs, expect = [], []
for t in range(N):
    x, y = tid_xy(t)
    inputs.append(ins(x, y))
    expect.append(outs(IRB.value(x, y, 0, 0)[0]))
w = 0xeb10000000000000 | (3 << 33) | (4 << 20) | (30 << 39) | PT | (8 << 8)
case('suld_d_bindless', ['mov $r30 c0[0x210] 0xf', 'raw 0x%016x' % w], [IRB], inputs, expect)


# ---------------------------------------------------------------- output
VIEWS = {'1d': 0, '2d': 1, '3d': 2, 'cube': 3, '1da': 4, '2da': 5, 'cubea': 6}
with open(OUT, 'w') as o:
    o.write('// Generated by tools/gpu_toolchain/gen_shader_t2t.py (envyas). Do not edit.\n')
    o.write('// %d cases.\n#pragma once\n#include <cstdint>\n\nnamespace lg_test::t2t {\n\n' % len(cases))
    o.write('struct Tex { uint32_t slot; uint32_t view; char fmt; uint32_t w, h, d, levels; bool storage; uint32_t handle; '
            'bool compare; };\n')
    o.write('struct Image { uint32_t slot; const uint32_t* words; uint32_t count; };\n')
    o.write('struct Case { const char* name; const uint64_t* code; uint32_t words; const Tex* texs; uint32_t ntex;\n'
            '              const uint32_t* inputs; const uint32_t* expect; const Image* images; uint32_t nimages;\n'
            '              const char* body; };\n\n')
    for i, c in enumerate(cases):
        o.write('static const uint64_t k_code_%d[] = {\n' % i)
        for j in range(0, len(c['code']), 4):
            o.write('    ' + ', '.join('0x%016xull' % x for x in c['code'][j:j + 4]) + ',\n')
        o.write('};\n')
        o.write('static const Tex k_tex_%d[] = {%s};\n' % (i, ', '.join(
            '{%d, %d, \'%s\', %d, %d, %d, %d, %s, 0x%x, %s}' % (t.slot, VIEWS[t.view], t.fmt, t.w, t.h, t.d, t.levels,
                                                         'true' if t.storage else 'false', t.handle,
                                                         'true' if t.compare else 'false') for t in c['texs'])))
        o.write('static const uint32_t k_in_%d[] = {%s};\n' % (i, ', '.join('0x%x' % x for row in c['inputs'] for x in row)))
        o.write('static const uint32_t k_out_%d[] = {%s};\n' % (i, ', '.join('0x%x' % x for row in c['expect'] for x in row)))
        for slot, words in c['images'].items():
            o.write('static const uint32_t k_img_%d_%d[] = {%s};\n' % (i, slot, ', '.join('0x%x' % x for x in words)))
        if c['images']:
            o.write('static const Image k_imgs_%d[] = {%s};\n' % (i, ', '.join(
                '{%d, k_img_%d_%d, %d}' % (s, i, s, len(w)) for s, w in c['images'].items())))
        o.write('\n')
    o.write('static const Case kCases[] = {\n')
    for i, c in enumerate(cases):
        body = c['body'].replace('\\', '\\\\').replace('"', '\\"')
        o.write('    {"%s", k_code_%d, sizeof(k_code_%d) / 8, k_tex_%d, %d, k_in_%d, k_out_%d, %s, %d, "%s"},\n' % (
            c['name'], i, i, i, len(c['texs']), i, i, ('k_imgs_%d' % i) if c['images'] else 'nullptr', len(c['images']), body))
    o.write('};\n\n} // namespace lg_test::t2t\n')
print(len(cases), 'cases')
