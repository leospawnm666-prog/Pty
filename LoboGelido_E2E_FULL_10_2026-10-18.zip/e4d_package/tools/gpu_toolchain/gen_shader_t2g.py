#!/usr/bin/env python3
# P4.2 T2-G (P4_2_DISENO.md §4.2): one test per form of the graphics-stage instructions.
#
# Each case is one Maxwell stage (VS, GS or FS) assembled with envyas (envytools, MIT) with an SPH
# built here (layout: NVIDIA open-gpu-doc "Shader Program Header", MIT). The other stages of the
# pipeline are GLSL compiled here with glslangValidator. The test (tests/test_shader_t2g.cpp)
# translates the Maxwell stage with lg::shader::translate, draws on the oracle and compares render
# target 0 (RGBA32UI, cleared to 0) with the values computed HERE from the documented semantics of
# each instruction, independently of the recompiler:
#   - VS/GS cases draw points, one per pixel; the FS passes the varyings through;
#   - FS cases draw a 16x16-pixel square whose varyings are constant (flat, perspective and
#     screen-linear), so every IPA mode has an exact (or 2-ULP) known result.
# FSWZADD semantics: Mesa nv50_ir (MIT) QUADOP(UL, UR, LL, LR): lane 0 (upper left) in mask
# bits 6-7, lane 3 in bits 0-1; 0 a+b, 1 b-a, 2 a-b, 3 b. SHFL: the PTX shfl definition with a
# quad segment (c = 0x1c03).
#
# Usage: gen_shader_t2g.py <envyas> <glslangValidator> <out .h>
import os
import re
import struct
import subprocess
import sys
import tempfile

ENVYAS, GLSLANG, OUT = sys.argv[1:4]
SCHED = 0x001f8000fc0007e0   # an inert scheduling word (the recompiler ignores its contents)
TMP = tempfile.mkdtemp()


# ---------------------------------------------------------------- assembly (as gen_shader_t2.py)
def layout(lines):
    labels, addrs, insns = {}, [], []
    slot = 0
    for ln in lines:
        if ln.endswith(':') and ln.startswith('@'):
            if slot % 4 == 0:
                slot += 1
            labels[ln[1:-1]] = slot * 8
            continue
        if slot % 4 == 0:
            slot += 1
        addrs.append(slot * 8)
        insns.append(ln)
        slot += 1
    return labels, addrs, insns


def assemble(lines):
    labels, addrs, insns = layout(lines)
    text = []
    raw = {}   # 'raw 0x...': an encoding envyas does not produce (assembled as a nop, then replaced)
    for k, (a, ln) in enumerate(zip(addrs, insns)):
        if ln.startswith('raw '):
            raw[k] = int(ln.split()[1], 0)
            ln = 'mov $r0 $r0 0xf'   # placeholder of the same size
        text.append(re.sub(r'@([a-z0-9_]+)', lambda m: '0x%x' % (labels[m.group(1)] - a + k * 8), ln))
    src = os.path.join(TMP, 'p.s')
    open(src, 'w').write('\n'.join(text) + '\n')
    out = src + '.bin'
    r = subprocess.run([ENVYAS, '-m', 'gm107', '-w', src, '-o', out], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit('envyas failed on:\n%s\n%s' % ('\n'.join(text), r.stderr))
    w = [int(x, 16) for x in re.findall(r'0x[0-9a-f]+', open(out).read())]
    if len(w) != 2 * len(insns):
        raise SystemExit('unexpected envyas output size for %s' % insns)
    words = {}
    for k, a in enumerate(addrs):
        words[a // 8] = raw[k] if k in raw else w[2 * k] | (w[2 * k + 1] << 32)
    n = max(words) + 1
    return [SCHED if i % 4 == 0 else words.get(i, 0x50b0000000070f00) for i in range(n)]


def glslang(src, ext):
    path = os.path.join(TMP, 's.' + ext)
    open(path, 'w').write(src)
    spv = path + '.spv'
    r = subprocess.run([GLSLANG, '-V', '--target-env', 'vulkan1.1', '-o', spv, path], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit('glslang failed:\n%s\n%s%s' % (src, r.stdout, r.stderr))
    return open(spv, 'rb').read()


# ---------------------------------------------------------------- SPH (open-gpu-doc layout)
def sph_vtg(shader_type, imap=(), omap=(), threads=0, topology=0, max_vertices=0):
    """imap/omap: (location, component) generics read/written."""
    b = bytearray(80)
    struct.pack_into('<I', b, 0, 1 | (3 << 5) | (shader_type << 10))
    struct.pack_into('<I', b, 8, threads << 24)
    struct.pack_into('<I', b, 12, topology << 24)
    struct.pack_into('<I', b, 16, max_vertices & 0xfff)
    for loc, c in imap:
        bit = loc * 4 + c
        b[0x18 + bit // 8] |= 1 << (bit % 8)
    for loc, c in omap:
        bit = loc * 4 + c
        b[0x36 + bit // 8] |= 1 << (bit % 8)
    return list(struct.unpack('<20I', bytes(b)))


def sph_ps(imap, kills=False):
    """imap: {location: interpolation (1 constant, 2 perspective, 3 screen linear)}, 4 components."""
    b = bytearray(80)
    struct.pack_into('<I', b, 0, 2 | (3 << 5) | (5 << 10) | (1 << 14) | (int(kills) << 15))
    for loc, mode in imap.items():
        b[0x18 + loc] = mode | (mode << 2) | (mode << 4) | (mode << 6)
    struct.pack_into('<I', b, 0x48, 0xf)   # render target 0, four components
    return list(struct.unpack('<20I', bytes(b)))


# ---------------------------------------------------------------- data helpers
def f2u(f):
    return struct.unpack('<I', struct.pack('<f', f))[0]


def u32(x):
    return x & 0xffffffff


class Rng:
    def __init__(self, seed):
        self.x = seed

    def __call__(self):
        x = self.x
        x ^= (x << 13) & 0xffffffff
        x ^= x >> 17
        x ^= (x << 5) & 0xffffffff
        self.x = x
        return x


def point_pos(v):
    """vertex v -> the centre of pixel (v % 32, v // 32), as a vec4."""
    px, py = v % 32, v // 32
    return (2.0 * (px + 0.5) / 64.0 - 1.0, 2.0 * (py + 0.5) / 64.0 - 1.0, 0.5, 1.0)


def pix(v):
    """pixel index (y * 64 + x) of point v."""
    return (v // 32) * 64 + v % 32


def pack_f(vs):
    return b''.join(struct.pack('<4f', *v) for v in vs)


def pack_u(vs):
    return b''.join(struct.pack('<4I', *v) for v in vs)


cases = []


def case(name, stage, code, sph, others, topo, verts, attrs, expected, gfx=None, first_instance=0, fmask=0, tol=0):
    """others: {stage index: spirv}; attrs: [(location, type 0 f/2 u, bytes)];
    expected: {pixel index: (4 words)}; gfx: GraphicsState overrides."""
    cases.append(dict(name=name, stage=stage, code=assemble(code), sph=sph, others=others, topo=topo, verts=verts,
                      attrs=attrs, expected=expected, gfx=gfx or {}, first_instance=first_instance, fmask=fmask,
                      tol=tol, body=' | '.join(code)))


VERT, TESC, TESE, GEOM, FRAG = range(5)
TOPO = {'points': 0, 'triangles': 2}

# FS that passes generic 0 and 1 (flat uvec4) to the target: c = v0 + v1 * 0x10001
FS_PASS = glslang('''#version 460
layout(location=0) flat in uvec4 v0;
layout(location=1) flat in uvec4 v1;
layout(location=0) out uvec4 c;
void main() { c = v0 + v1 * 0x10001u; }
''', 'frag')


def fs_pass(o0, o1):
    return tuple(u32(a + b * 0x10001) for a, b in zip(o0, o1))


# ---------------------------------------------------------------- VS: ld/st a[] (ALD/AST)
N = 64
rng = Rng(0x1234567)
A = {loc: [tuple(rng() for _ in range(4)) for _ in range(N)] for loc in (1, 2, 3)}
POS = [point_pos(v) for v in range(N)]
VS_ATTRS = [(0, 0, pack_f(POS))] + [(loc, 2, pack_u(A[loc])) for loc in (1, 2, 3)]
VS_GFX = {'attrs': {0: 0, 1: 2, 2: 2, 3: 2}, 'varyings': {0: 2, 1: 2}}
VS_OMAP = [(l, c) for l in (0, 1) for c in range(4)]
VS_IMAP = [(l, c) for l in range(4) for c in range(4)]

exp = {}
for v in range(N):
    l1, l2, l3 = A[1][v], A[2][v], A[3][v]
    o0 = (l1[1], l3[0], l2[2], l2[3])
    o1 = (l3[0], l3[1], l3[2], l1[3])
    exp[pix(v)] = fs_pass(o0, o1)
case('vs_ld_st_sizes', VERT, [
    'ld b128 $r0 a[0x80] 0x0',       # position (generic 0)
    'st b128 a[0x70] $r0 0x0',
    'ld b32 $r4 a[0x94] 0x0',        # l1.y
    'ld b64 $r6 a[0xa8] 0x0',        # l2.zw
    'ld b96 $r8 a[0xb0] 0x0',        # l3.xyz
    'ld b128 $r12 a[0x90] 0x0',      # l1
    'st b32 a[0x80] $r4 0x0',        # o0.x = l1.y
    'st b32 a[0x84] $r8 0x0',        # o0.y = l3.x
    'st b64 a[0x88] $r6 0x0',        # o0.zw = l2.zw
    'st b96 a[0x90] $r8 0x0',        # o1.xyz = l3.xyz
    'st b32 a[0x9c] $r15 0x0',       # o1.w = l1.w
    'exit'], sph_vtg(1, VS_IMAP, VS_OMAP), {FRAG: FS_PASS}, 'points', N, VS_ATTRS, exp, VS_GFX)

# dynamic index: AL2P + ld/st a[R + imm]
exp = {}
for v in range(N):
    l1 = A[1][v]
    k = l1[0] & 1                    # generic 1 + k (1 or 2)
    src = A[1 + k][v]
    o0 = [0, 0, 0, 0]
    o0[l1[1] & 3] = src[0]           # dynamic store of src.x into o0[l1.y & 3]
    o1 = (src[2], src[3], l1[2], 0x55)
    exp[pix(v)] = fs_pass(tuple(o0), o1)
case('vs_dynamic_index', VERT, [
    'ld b128 $r0 a[0x80] 0x0',
    'st b128 a[0x70] $r0 0x0',
    'ld b128 $r4 a[0x90] 0x0',       # l1
    'lop and 0x1 $r8 $r4 0x1',       # k = l1.x & 1
    'shl $r8 $r8 0x4',
    'al2p b32 0x1 $r9 $r8 0x90',     # address of generic 1 + k
    'ld b32 $r10 a[$r9] 0x0',        # src.x
    'ld b64 $r12 a[$r9+0x8] 0x0',    # src.zw
    'mov32i $r16 0x0 0xf',
    'st b32 a[0x80] $r16 0x0',
    'st b32 a[0x84] $r16 0x0',
    'st b32 a[0x88] $r16 0x0',
    'st b32 a[0x8c] $r16 0x0',
    'lop and 0x1 $r17 $r5 0x3',      # j = l1.y & 3
    'shl $r17 $r17 0x2',
    'st b32 a[$r17+0x80] $r10 0x0',  # o0[j] = src.x
    'mov $r14 $r6 0xf',              # o1 = (src.z, src.w, l1.z, 0x55)
    'mov32i $r15 0x55 0xf',
    'st b64 a[0x90] $r12 0x0',
    'st b64 a[0x98] $r14 0x0',
    'exit'], sph_vtg(1, VS_IMAP, VS_OMAP), {FRAG: FS_PASS}, 'points', N, VS_ATTRS, exp, VS_GFX)

# vertex and instance id (GL semantics: the instance id excludes the base instance) and the
# alternative GraphicsState::instance_id_includes_base
for incl in (False, True):
    exp = {}
    for v in range(N):
        exp[pix(v)] = fs_pass((v, 3 if incl else 0, A[1][v][0], 0x1234), (0, 0, 0, 0))
    case('vs_sysattr' + ('_base' if incl else ''), VERT, [
        'ld b128 $r0 a[0x80] 0x0',
        'st b128 a[0x70] $r0 0x0',
        'ld b32 $r4 a[0x2fc] 0x0',
        'ld b32 $r5 a[0x2f8] 0x0',
        'ld b32 $r6 a[0x90] 0x0',
        'mov32i $r7 0x1234 0xf',
        'st b128 a[0x80] $r4 0x0',
        'mov32i $r8 0x0 0xf',
        'st b32 a[0x90] $r8 0x0',
        'st b32 a[0x94] $r8 0x0',
        'st b32 a[0x98] $r8 0x0',
        'st b32 a[0x9c] $r8 0x0',
        'exit'], sph_vtg(1, VS_IMAP, VS_OMAP), {FRAG: FS_PASS}, 'points', N, VS_ATTRS, exp,
        dict(VS_GFX, instance_includes_base=incl), first_instance=3)

# ---------------------------------------------------------------- GS: OUT, ISBERD, ld a[] per vertex
VS_GS = glslang('''#version 460
layout(location=0) in vec4 pos;
layout(location=1) in uvec4 u;
layout(location=0) flat out uvec4 o0;
void main() { gl_Position = pos; o0 = u; }
''', 'vert')
NG = 32   # points in row 0; the GS adds one 32 pixels right (+1.0 in x) and one a row below
exp = {}
for v in range(NG):
    l1 = A[1][v]
    exp[pix(v)] = fs_pass(l1, (0, 0, 0, 0))
    exp[pix(v) + 32] = fs_pass(tuple(u32(x + 0x100) for x in l1), (1, 0, 0, 0))
    exp[pix(v) + 64] = fs_pass(tuple(u32(x + 0x200) for x in l1), (2, 0, 0, 0))
case('gs_out_isberd', GEOM, [
    'mov32i $r0 0x0 0xf',
    'isberd $r20 p[$r0]',            # logical vertex 0 -> physical
    'ld b128 $r4 a[0x70] $r20',      # gl_in[0].gl_Position
    'ld b128 $r8 a[0x80] $r20',      # generic 0 of vertex 0
    'mov32i $r22 0x0 0xf',           # output vertex handle
    'mov32i $r12 0x0 0xf',
    'st b128 a[0x70] $r4 $r22',
    'st b128 a[0x80] $r8 $r22',
    'st b32 a[0x90] $r12 $r22',
    'st b32 a[0x94] $r12 $r22',
    'st b32 a[0x98] $r12 $r22',
    'st b32 a[0x9c] $r12 $r22',
    'out emit $r22 $r22 0x0',
    'fadd32i $r4 $r4 0x3f800000',    # x + 1.0: 32 pixels right
    'iadd32i $r8 $r8 0x100',
    'iadd32i $r9 $r9 0x100',
    'iadd32i $r10 $r10 0x100',
    'iadd32i $r11 $r11 0x100',
    'mov32i $r12 0x1 0xf',
    'st b128 a[0x70] $r4 $r22',
    'st b128 a[0x80] $r8 $r22',
    'st b32 a[0x90] $r12 $r22',
    'out emit_then_cut $r22 $r22 0x0',
    'fadd32i $r4 $r4 0xbf800000',    # back, and one row down (y + 2/64)
    'fadd32i $r5 $r5 0x3d000000',
    'iadd32i $r8 $r8 0x100',
    'iadd32i $r9 $r9 0x100',
    'iadd32i $r10 $r10 0x100',
    'iadd32i $r11 $r11 0x100',
    'mov32i $r12 0x2 0xf',
    'st b128 a[0x70] $r4 $r22',
    'st b128 a[0x80] $r8 $r22',
    'st b32 a[0x90] $r12 $r22',
    'raw 0xf6e0008000071616',         # out emit $r22 $r22 0x0: the immediate-stream form (stream 0)
    'raw 0xebe0010000071616',         # out cut $r22 $r22 c0[0x0]: the constant-buffer stream form
    'exit'],
    sph_vtg(4, [(0, c) for c in range(4)], VS_OMAP, threads=1, topology=1, max_vertices=3),
    {VERT: VS_GS, FRAG: FS_PASS}, 'points', NG, VS_ATTRS[:2], exp, {'attrs': {0: 0, 1: 2}, 'varyings': {0: 2, 1: 2},
                                                                   'gs_input': 'points'})

# ---------------------------------------------------------------- FS: IPA, KIL, SHFL, FSWZADD
FLAT_U = (0xcafe0001, 0x12345678, 0x9abcdef0, 0x0f0f0f0f)
PERSP = (2.0, 0.5, -3.0, 1.0)
LINEAR = (-3.0, 0.25, 4.0, 8.0)
VS_FS = glslang('''#version 460
layout(location=0) in vec4 pos;
layout(location=1) in uvec4 u;
layout(location=0) flat out uvec4 o0;
layout(location=1) out vec4 o1;
layout(location=2) noperspective out vec4 o2;
void main() { gl_Position = pos; o0 = u; o1 = vec4(2.0, 0.5, -3.0, 1.0); o2 = vec4(-3.0, 0.25, 4.0, 8.0); }
''', 'vert')
# a 16x16-pixel square at the top-left: x, y in [-1, -0.5]
SQ = [(-1.0, -1.0), (-0.5, -1.0), (-1.0, -0.5), (-0.5, -1.0), (-0.5, -0.5), (-1.0, -0.5)]
# w = 2 (xyz scaled): FragCoord.w = 1/w = 0.5, so IPA.PASS of a perspective input (value * w) is
# distinguishable from the value itself
# (z = 0.6 after the divide, so FragCoord.z is not 1/w either)
FS_ATTRS = [(0, 0, pack_f([(2.0 * x, 2.0 * y, 1.2, 2.0) for x, y in SQ])), (1, 2, pack_u([FLAT_U] * 6))]
FS_GFX = {'attrs': {0: 0, 1: 2}, 'varyings': {0: 2}, 'rt': 2}
FS_IMAP = {0: 1, 1: 2, 2: 3}
PIX = [(x, y) for y in range(16) for x in range(16)]


def fs_case(name, code, fn, fmask=0, tol=0, kills=False):
    exp = {}
    for x, y in PIX:
        r = fn(x, y)
        if r is not None:
            exp[y * 64 + x] = tuple(f2u(c) if isinstance(c, float) else c for c in r)
    case(name, FRAG, code, sph_ps(FS_IMAP, kills), {VERT: VS_FS}, 'triangles', 6, FS_ATTRS, exp, FS_GFX,
         fmask=fmask, tol=tol)


fs_case('fs_ipa_modes', [
    'ipa pass $r0 a[0x70] 0x0 0x0 0x1',       # FragCoord.x
    'ipa pass $r1 a[0x74] 0x0 0x0 0x1',       # FragCoord.y
    'ipa constant $r2 a[0x80] 0x0 0x0 0x1',   # flat generic 0.x
    'ipa pass $r4 a[0x7c] 0x0 0x0 0x1',       # FragCoord.w (1/w)
    'mufu rcp $r5 $r4',
    'ipa $r3 a[0x90] $r5 0x0 0x1',            # perspective generic 1.x, multiply mode
    'exit'], lambda x, y: (x + 0.5, y + 0.5, FLAT_U[0], PERSP[0]), fmask=0x8, tol=2)
fs_case('fs_ipa_sat_centroid_linear', [
    'ipa pass $r4 a[0x7c] 0x0 0x0 0x1',
    'mufu rcp $r5 $r4',
    'ipa pass sat $r0 a[0x70] 0x0 0x0 0x1',   # sat(x + 0.5): 0.5 at x = 0, else 1
    'ipa centroid $r1 a[0x94] $r5 0x0 0x1',   # perspective generic 1.y, centroid
    'ipa pass $r2 a[0xa0] 0x0 0x0 0x1',       # screen-linear generic 2.x
    'ipa sat $r3 a[0x98] $r5 0x0 0x1',        # sat(generic 1.z = -3) = 0
    'exit'], lambda x, y: (min(1.0, x + 0.5), PERSP[1], LINEAR[0], 0.0), fmask=0xf, tol=2)
fs_case('fs_ipa_pass_perspective', [
    'ipa pass $r0 a[0x90] 0x0 0x0 0x1',       # perspective generic 1.x, pass: value * (1/w) = 2.0 * 0.5
    'ipa pass $r1 a[0x7c] 0x0 0x0 0x1',       # FragCoord.w = 0.5
    'mufu rcp $r5 $r1',
    'ipa $r2 a[0x94] $r5 0x0 0x1',            # multiply mode: the corrected value, 0.5
    'ipa constant $r3 a[0x84] 0x0 0x0 0x1',   # flat generic 0.y
    'exit'], lambda x, y: (PERSP[0] * 0.5, 0.5, PERSP[1], FLAT_U[1]), fmask=0x7, tol=2)


def ipa_idx(dst, base, imm, mode, mult=0xff, sat=False):
    """IPA.IDX a[R + imm]: envyas cannot write it (envydis prints part of it as unknown); the word is
    uam's own encoding (tests/data/shader/gcorpus/g10_dynidx.frag) with the fields replaced."""
    w = 0xe043ffc000370202
    mask = 0xff | 0xff << 8 | 0xff << 20 | 0x3ff << 28 | 1 << 51 | 3 << 52 | 3 << 54
    w = (w & ~mask) | dst | base << 8 | mult << 20 | imm << 28 | int(sat) << 51 | mode << 54
    return 'raw 0x%016x' % w


fs_case('fs_ipa_indexed', [
    'ipa pass $r4 a[0x7c] 0x0 0x0 0x1',
    'mufu rcp $r5 $r4',
    'mov32i $r6 0x10 0xf',
    'al2p b32 0x1 $r7 $r6 0x80',              # 0x90: generic 1 (perspective)
    'mov32i $r8 0x84 0xf',                    # flat generic 0.y
    ipa_idx(0, 7, 0x0, 1, mult=5, sat=True),  # sat(generic 1.x = 2) = 1, multiply mode
    ipa_idx(1, 7, 0x4, 0),                    # pass: generic 1.y * (1/w) = 0.5 * 0.5
    ipa_idx(2, 7, 0x10, 0),                   # pass on screen-linear generic 2.x: the value
    ipa_idx(3, 8, 0x0, 2),                    # constant: flat generic 0.y
    'exit'], lambda x, y: (1.0, PERSP[1] * 0.5, LINEAR[0], FLAT_U[1]), fmask=0x7, tol=2)
fs_case('fs_kil', [
    'ipa pass $r0 a[0x70] 0x0 0x0 0x1',
    'ipa pass $r1 a[0x74] 0x0 0x0 0x1',
    'fsetp gt and $p0 0x1 $r0 0x41000000 0x1',   # x + 0.5 > 8
    '$p0 kil',
    'mov32i $r2 0x11111111 0xf',
    'mov32i $r3 0x22222222 0xf',
    'exit'], lambda x, y: (x + 0.5, y + 0.5, 0x11111111, 0x22222222) if x + 0.5 <= 8.0 else None, kills=True)


def quad(x, y):
    return (x & 1) | ((y & 1) << 1)


def lane_xy(x, y, j):
    """pixel of quad lane j in the quad of (x, y)."""
    return (x & ~1) | (j & 1), (y & ~1) | (j >> 1)


def shfl(x, y, val, mode, b):
    q = quad(x, y)
    if mode == 'idx':
        j, ok = b & 3, True
    elif mode == 'up':
        j, ok = q - b, b <= q
    elif mode == 'down':
        j, ok = q + b, q + b <= 3
    else:
        j, ok = q ^ b, (b & ~3) == 0
    if not ok:
        j = q
    return val(*lane_xy(x, y, j))


def fswz(x, y, mask, a, b):
    op = (mask >> (6 - 2 * quad(x, y))) & 3
    return [a + b, b - a, a - b, b][op]


FX = lambda x, y: x + 0.5   # noqa: E731
FY = lambda x, y: y + 0.5   # noqa: E731

fs_case('fs_quad_derivatives', [
    'ipa pass $r0 a[0x70] 0x0 0x0 0x1',
    'ipa pass $r1 a[0x74] 0x0 0x0 0x1',
    'shfl bfly 0x1 $r2 $r0 0x1 0x1c03',       # dFdx: the derivative idiom of the compilers
    'fswzadd $r2 $r2 $r0 0x99',
    'shfl bfly 0x1 $r3 $r1 0x2 0x1c03',       # dFdy
    'fswzadd $r3 $r3 $r1 0xa5',
    'shfl idx 0x1 $r4 $r0 0x3 0x1c03',        # x of quad lane 3
    'shfl down 0x1 $r5 $r0 0x1 0x1c03',       # x of lane q + 1 (own when out of the quad)
    'mov $r0 $r2 0xf',
    'mov $r1 $r3 0xf',
    'mov $r2 $r4 0xf',
    'mov $r3 $r5 0xf',
    'exit'], lambda x, y: (fswz(x, y, 0x99, shfl(x, y, FX, 'bfly', 1), FX(x, y)),
                           fswz(x, y, 0xa5, shfl(x, y, FY, 'bfly', 2), FY(x, y)),
                           shfl(x, y, FX, 'idx', 3), shfl(x, y, FX, 'down', 1)))
fs_case('fs_quad_masks', [
    'ipa pass $r0 a[0x70] 0x0 0x0 0x1',
    'ipa pass $r1 a[0x74] 0x0 0x0 0x1',
    'shfl bfly 0x1 $r2 $r0 0x3 0x1c03',       # x of the diagonal lane
    'fswzadd $r3 $r2 $r1 0x1b',               # asymmetric mask: UL a+b, UR b-a, LL a-b, LR b
    'shfl up 0x1 $r4 $r1 0x2 0x1c03',         # y of lane q - 2 (own in the top row)
    'fswzadd $r5 $r1 $r0 0xe4',               # UL b, UR a-b, LL b-a, LR a+b
    'mov $r0 $r2 0xf',
    'mov $r1 $r3 0xf',
    'mov $r2 $r4 0xf',
    'mov $r3 $r5 0xf',
    'exit'], lambda x, y: (shfl(x, y, FX, 'bfly', 3),
                           fswz(x, y, 0x1b, shfl(x, y, FX, 'bfly', 3), FY(x, y)),
                           shfl(x, y, FY, 'up', 2),
                           fswz(x, y, 0xe4, FY(x, y), FX(x, y))))




def shfl_ok(x, y, mode, b):
    q = quad(x, y)
    return {'idx': True, 'up': b <= q, 'down': q + b <= 3, 'bfly': (b & ~3) == 0}[mode]


fs_case('fs_quad_predicates', [
    'ipa pass $r0 a[0x70] 0x0 0x0 0x1',
    'ipa pass $r1 a[0x74] 0x0 0x0 0x1',
    'shfl down $p0 $r2 $r0 0x1 0x1c03',       # in range when q + 1 <= 3
    'shfl up $p1 $r3 $r1 0x2 0x1c03',         # in range when q >= 2
    'shfl bfly $p2 $r4 $r0 0x4 0x1c03',       # lane q ^ 4: outside the quad, own value, false
    'shfl idx $p3 $r5 $r1 0x2 0x1c03',        # always in range
    'mov32i $r8 0x0 0xf',
    'mov32i $r7 0x1 0xf',
    'sel $r9 $r7 $r8 $p0',
    'mov32i $r7 0x2 0xf',
    'sel $r10 $r7 $r8 $p1',
    'iadd $r9 $r9 $r10',
    'mov32i $r7 0x4 0xf',
    'sel $r10 $r7 $r8 $p2',
    'iadd $r9 $r9 $r10',
    'mov32i $r7 0x8 0xf',
    'sel $r10 $r7 $r8 $p3',
    'iadd $r9 $r9 $r10',
    'mov $r0 $r9 0xf',
    'mov $r1 $r3 0xf',
    'mov $r2 $r4 0xf',
    'mov $r3 $r5 0xf',
    'exit'], lambda x, y: (int(shfl_ok(x, y, 'down', 1)) | int(shfl_ok(x, y, 'up', 2)) << 1 |
                           int(shfl_ok(x, y, 'bfly', 4)) << 2 | int(shfl_ok(x, y, 'idx', 2)) << 3,
                           shfl(x, y, FY, 'up', 2), shfl(x, y, FX, 'bfly', 4), shfl(x, y, FY, 'idx', 2)))


# ---------------------------------------------------------------- output
def arr_u8(data):
    return '\n'.join('    ' + ', '.join('0x%02x' % b for b in data[j:j + 24]) + ',' for j in range(0, len(data), 24))


with open(OUT, 'w') as o:
    o.write('// Generated by tools/gpu_toolchain/gen_shader_t2g.py (envyas + glslangValidator). Do not edit.\n')
    o.write('// %d cases.\n#pragma once\n#include <cstdint>\n\nnamespace lg_test::t2g {\n\n' % len(cases))
    o.write('struct Attr { uint32_t location; int type; const uint8_t* data; uint32_t size; };   // type 0 f, 2 u\n')
    o.write('struct Expect { uint32_t pixel; uint32_t v[4]; };\n')
    o.write('struct Case {\n    const char* name; int stage; const uint64_t* code; uint32_t words; uint32_t sph[20];\n'
            '    const uint8_t* spirv[5]; uint32_t spirv_size[5]; int topology; uint32_t vertices; uint32_t first_instance;\n'
            '    const Attr* attrs; uint32_t num_attrs; uint32_t attr_types[4]; uint32_t varying_types[2];\n'
            '    bool instance_includes_base; int gs_input; const Expect* expect; uint32_t num_expect;\n'
            '    uint32_t fmask; uint32_t tol; const char* body;\n};\n\n')
    for i, c in enumerate(cases):
        o.write('static const uint64_t k_code_%d[] = {\n' % i)
        for j in range(0, len(c['code']), 4):
            o.write('    ' + ', '.join('0x%016xull' % x for x in c['code'][j:j + 4]) + ',\n')
        o.write('};\n')
        for s, spv in c['others'].items():
            o.write('static const uint8_t k_spv_%d_%d[] = {\n%s\n};\n' % (i, s, arr_u8(spv)))
        for k, (loc, t, data) in enumerate(c['attrs']):
            o.write('static const uint8_t k_attr_%d_%d[] = {\n%s\n};\n' % (i, k, arr_u8(data)))
        o.write('static const Attr k_attrs_%d[] = {%s};\n' % (i, ', '.join(
            '{%d, %d, k_attr_%d_%d, %d}' % (loc, t, i, k, len(data)) for k, (loc, t, data) in enumerate(c['attrs']))))
        o.write('static const Expect k_exp_%d[] = {\n' % i)
        for p in sorted(c['expected']):
            o.write('    {%d, {0x%08x, 0x%08x, 0x%08x, 0x%08x}},\n' % ((p,) + tuple(c['expected'][p])))
        o.write('};\n\n')
    o.write('static const Case kCases[] = {\n')
    for i, c in enumerate(cases):
        g = c['gfx']
        spv = ['k_spv_%d_%d' % (i, s) if s in c['others'] else 'nullptr' for s in range(5)]
        spvsz = ['sizeof(k_spv_%d_%d)' % (i, s) if s in c['others'] else '0' for s in range(5)]
        at = [g.get('attrs', {}).get(k, 0) for k in range(4)]
        vt = [g.get('varyings', {}).get(k, 0) for k in range(2)]
        gsin = {'points': 0, 'lines': 1, 'lines_adj': 2, 'triangles': 3, 'triangles_adj': 4}[g.get('gs_input', 'points')]   # GsInput order
        body = c['body'].replace('\\', '\\\\').replace('"', '\\"')
        o.write('    {"%s", %d, k_code_%d, sizeof(k_code_%d) / 8, {%s},\n     {%s}, {%s}, %d, %d, %d,\n'
                '     k_attrs_%d, %d, {%s}, {%s}, %s, %d, k_exp_%d, %d, 0x%x, %d,\n     "%s"},\n' % (
                    c['name'], c['stage'], i, i, ', '.join('0x%08x' % w for w in c['sph']), ', '.join(spv),
                    ', '.join(spvsz), TOPO[c['topo']], c['verts'], c['first_instance'], i, len(c['attrs']),
                    ', '.join(map(str, at)), ', '.join(map(str, vt)),
                    'true' if g.get('instance_includes_base') else 'false', gsin, i, len(c['expected']),
                    c['fmask'], c['tol'], body))
    o.write('};\n\n} // namespace lg_test::t2g\n')
print(len(cases), 'cases')
