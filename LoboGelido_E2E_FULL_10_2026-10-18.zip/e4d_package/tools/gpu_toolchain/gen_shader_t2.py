#!/usr/bin/env python3
# P4.1 T2 (P4_DISENO.md §5.2): one test per instruction form.
#
# Each case is a small Maxwell program assembled with envyas (envytools, MIT): a common scaffold
# loads A/B/C/predicates/CC for each of 64 invocations from constant buffer c2, runs the
# instruction(s) under test and stores r5..r8, the predicates and CF/ZF to a storage buffer.
# tests/test_shader_t2.cpp runs every case through lg::shader::translate on the oracle
# (SwiftShader) and through the reference interpreter (tests/shader/maxwell_ref.cpp) and compares.
#
# Usage: gen_shader_t2.py <envyas> <out .h>
import re
import subprocess
import sys
import tempfile

ENVYAS = sys.argv[1]
OUT = sys.argv[2]

SCHED = 0x001f8000fc0007e0   # an inert scheduling word (the recompiler ignores its contents)

PROLOGUE = [
    'mov $r20 $tidx',
    'shl $r21 $r20 0x4',
    'ld b32 $r1 c2[$r21]',
    'ld b32 $r2 c2[$r21+0x4]',
    'ld b32 $r3 c2[$r21+0x8]',
    'ld b32 $r4 c2[$r21+0xc]',
    'r2p pr $r4 0x7f',
    'mov $r5 $r3 0xf',
    'mov32i $r6 0x66666666 0xf',
    'mov32i $r7 0x77777777 0xf',
    'mov32i $r8 0x88888888 0xf',
    'bfe $r13 $r4 0x108',              # signed bfe: -1 when bit 8 of r4 is set
    'iadd cc $r255 $r13 0x1',          # CF = ZF = bit 8
    # scratch addresses: r14:r15 = c0 table entry 1 (scratch storage buffer) + A
    'iadd cc $r14 $r1 c0[0x150]',
    'iadd x $r15 $r255 c0[0x154]',
    'bfe $r13 $r4 0x108',
    'iadd cc $r255 $r13 0x1',          # restore CF/ZF after the address computation
]
EPILOGUE = [
    'p2r $r9 pr $r255 0x7f',
    'iadd x $r10 $r255 $r255',
    'isetp eq u32 x and $p0 0x1 $r255 $r255 0x1',
    'p2r $r11 pr $r255 0x1',
    'shl $r22 $r20 0x5',
    'iadd cc $r23 $r22 c0[0x140]',
    'iadd x $r24 $r255 c0[0x144]',
    'stg e b32 ncg[$r23] $r5',
    'stg e b32 ncg[$r23+0x4] $r6',
    'stg e b32 ncg[$r23+0x8] $r7',
    'stg e b32 ncg[$r23+0xc] $r8',
    'stg e b32 ncg[$r23+0x10] $r9',
    'stg e b32 ncg[$r23+0x14] $r10',
    'stg e b32 ncg[$r23+0x18] $r11',
    '@end:',
    'exit',
]

cases = []   # (name, kind, tol, flags, shared, local, body lines)


def case(name, body, kind='i', tol=0, flags='', shared=0, local=0):
    if isinstance(body, str):
        body = [body]
    cases.append((name, kind, tol, flags, shared, local, body))


# ---------------------------------------------------------------- moves, select, sysregs
case('mov_reg', 'mov $r5 $r1 0xf')
case('mov_cbuf', 'mov $r5 c3[0x10] 0xf')
case('mov_imm', 'mov $r5 -0x5 0xf')
case('mov32i', 'mov32i $r5 0xdeadbeef 0xf')
for sr in ['tidx', 'tidy', 'tidz', 'ctaidx', 'ctaidy', 'ctaidz', 'tid', 'laneid', 'eqmask', 'ltmask', 'lemask',
           'gtmask', 'gemask', 'ntid', 'smemsz']:
    case('s2r_' + sr, 'mov $r5 $%s' % sr, kind='s')
case('cs2r_tidx', 'cs2r $r5 $tidx', kind='s')
case('sel_p0', 'sel $r5 $r1 $r2 $p0')
case('sel_not_p1', 'sel $r5 $r1 $r2 not $p1')
case('sel_cbuf', 'sel $r5 $r1 c3[0x14] $p2')
case('sel_imm', 'sel $r5 $r1 0x777 $p3')

# ---------------------------------------------------------------- integer add family
case('iadd', 'iadd $r5 $r1 $r2')
case('iadd_nega', 'iadd $r5 neg $r1 $r2')
case('iadd_negb', 'iadd $r5 $r1 neg $r2')
case('iadd_sat', 'iadd sat $r5 $r1 $r2')
case('iadd_sat_negb', 'iadd sat $r5 $r1 neg $r2')
case('iadd_cc', 'iadd cc $r5 $r1 $r2')
case('iadd_x', 'iadd x $r5 $r1 $r2')
case('iadd_cc_x', 'iadd x cc $r5 $r1 $r2')
case('iadd_x_negb', 'iadd x $r5 $r1 neg $r2')
case('iadd_cbuf', 'iadd $r5 $r1 c3[0x18]')
case('iadd_imm', 'iadd $r5 $r1 -0x1234')
case('iadd_64', ['iadd cc $r5 $r1 $r2', 'iadd x $r6 $r3 $r1'])
case('iadd_sub64', ['iadd cc $r5 $r1 neg $r2', 'iadd x $r6 $r3 neg $r1'])
case('iadd32i', 'iadd32i $r5 $r1 0x7ffffff0')
case('iadd32i_nega', 'iadd32i $r5 neg $r1 0x10')
case('iadd32i_sat', 'iadd32i sat $r5 $r1 0x7fff0000')
case('iadd32i_cc_x', ['iadd32i cc $r5 $r1 -0x10', 'iadd32i x $r6 $r2 0x1'])
case('iadd32i_po', 'iadd32i po $r5 $r1 0x100')
case('iadd3', 'iadd3 $r5 $r1 $r2 $r3')
case('iadd3_negs', 'iadd3 $r5 neg $r1 $r2 neg $r3')
case('iadd3_cc_x', ['iadd3 cc $r5 $r1 $r2 $r3', 'iadd3 x $r6 $r1 $r2 $r255'])
case('iadd3_rs', 'iadd3 rs $r5 $r1 $r2 $r3')
case('iadd3_ls', 'iadd3 ls $r5 $r1 $r2 $r3')
case('iadd3_halves', 'iadd3 $r5 h1 $r1 h0 $r2 h1 $r3')
case('iadd3_cbuf', 'iadd3 $r5 $r1 c3[0x1c] $r3')
case('iadd3_imm', 'iadd3 $r5 $r1 0x4321 $r3')
for sh in [0, 1, 5, 31]:
    case('iscadd_%d' % sh, 'iscadd $r5 $r1 $r2 0x%x' % sh)
case('iscadd_negs', 'iscadd $r5 neg $r1 neg $r2 0x3')
case('iscadd_cc', 'iscadd cc $r5 $r1 $r2 0x2')
case('iscadd_cbuf', 'iscadd $r5 $r1 c3[0x20] 0x4')
case('iscadd_imm', 'iscadd $r5 $r1 0x100 0x2')
case('iscadd32i', 'iscadd32i $r5 $r1 0x12345678 0x3')
case('lea', 'lea 0x1 $r5 $r1 $r2 0x3')
case('lea_pred_neg', 'lea $p2 $r5 neg $r1 $r2 0x5')
case('lea_x', ['lea $p2 $r5 $r1 $r2 0x2', 'lea x 0x1 $r6 $r3 $r2 0x0'])
case('lea_cbuf', 'lea 0x1 $r5 $r1 c3[0x24] 0x4')
case('lea_imm', 'lea 0x1 $r5 $r1 0x40 0x1')
case('lea_hi', 'lea hi $p1 $r5 $r1 $r2 $r3 0x3')
case('lea_hi_0', 'lea hi 0x1 $r5 $r1 $r2 $r3 0x0')
case('lea_hi_cbuf', 'lea hi 0x1 $r5 $r1 c3[0x28] $r3 0x7')

# ---------------------------------------------------------------- multiplies
for su in ['u32 u32', 's32 s32', 'u32 s32', 's32 u32']:
    t = su.replace(' ', '_')
    case('imul_' + t, 'imul %s $r5 $r1 $r2' % su)
    case('imul_hi_' + t, 'imul %s hi $r5 $r1 $r2' % su)
    case('imad_' + t, 'imad %s $r5 $r1 $r2 $r3' % su)
    case('imad_hi_' + t, 'imad %s hi $r5 $r1 $r2 $r3' % su)
case('imul_cbuf', 'imul u32 u32 $r5 $r1 c3[0x2c]')
case('imul_imm', 'imul s32 s32 $r5 $r1 -0x3')
case('imul32i', 'imul32i u32 u32 $r5 $r1 -0x61c88647')
case('imul32i_hi', 'imul32i s32 s32 hi $r5 $r1 -0x61c88647')
case('imad_sat', 'imad s32 s32 sat $r5 $r1 $r2 $r3')
case('imad_cc_x', ['imad u32 u32 c $r5 $r1 $r2 $r3', 'imad u32 u32 x $r6 $r2 $r3 $r1'])
case('imad_cbuf_b', 'imad u32 u32 $r5 $r1 c3[0x30] $r3')
case('imad_cbuf_c', 'imad u32 u32 $r5 $r1 $r2 c3[0x34]')
case('imad_imm', 'imad s32 s32 $r5 $r1 0x777 $r3')
case('imad32i', 'imad32i u32 u32 $r5 $r1 0x10001 $r5')
for nm, mods in [('plain', ''), ('psl', 'psl '), ('mrg', 'mrg '), ('psl_mrg', 'psl mrg '), ('clo', 'clo '),
                 ('chi', 'chi '), ('csfu', 'csfu '), ('cbcc', 'cbcc '), ('x', 'x ')]:
    case('xmad_' + nm, 'xmad %s$r5 $r1 $r2 $r3' % mods)
case('xmad_h1a', 'xmad $r5 h1 $r1 $r2 $r3')
case('xmad_h1b', 'xmad $r5 $r1 h1 $r2 $r3')
case('xmad_s16_u16', 'xmad s16 u16 $r5 h1 $r1 $r2 $r3')
case('xmad_u16_s16', 'xmad u16 s16 $r5 $r1 h1 $r2 $r3')
case('xmad_s16_s16_csfu', 'xmad s16 s16 csfu $r5 h1 $r1 h1 $r2 $r3')
case('xmad_cc_x', ['xmad cc $r5 $r1 $r2 $r3', 'xmad x $r6 h1 $r1 h1 $r2 $r255'])
case('xmad_cbuf_b', 'xmad psl mrg $r5 h1 $r1 h1 c3[0x38] $r3')
case('xmad_cbuf_b_chi', 'xmad chi $r5 $r1 c3[0x38] $r3')
case('xmad_cbuf_c', 'xmad clo $r5 $r1 h1 $r2 c3[0x3c]')
case('xmad_imm', 'xmad psl $r5 h1 $r1 0xbeef $r3')
case('xmad_imm_cbcc', 'xmad cbcc $r5 $r1 0x1234 $r3')

# ---------------------------------------------------------------- min/max, logic, shifts, bits
case('imnmx_u_min', 'imnmx u32 $r5 $r1 $r2 0x1')
case('imnmx_s_max', 'imnmx $r5 $r1 $r2 not 0x1')
case('imnmx_s_pred', 'imnmx $r5 $r1 $r2 $p0')
case('imnmx_cbuf', 'imnmx $r5 $r1 c3[0x40] 0x1')
case('imnmx_imm', 'imnmx u32 $r5 $r1 0x1000 not 0x1')
for lop in ['and', 'or', 'xor', 'pass_b']:
    case('lop_' + lop, 'lop %s 0x1 $r5 $r1 $r2' % lop)
case('lop_inv', 'lop and 0x1 $r5 inv $r1 inv $r2')
case('lop_pred_t', 'lop xor t $p1 $r5 $r1 $r2')
case('lop_pred_z', 'lop and z $p2 $r5 $r1 $r2')
case('lop_pred_nz', 'lop or nz $p3 $r5 $r1 $r2')
case('lop_cc', 'lop and 0x1 cc $r5 $r1 $r2')
case('lop_cbuf', 'lop xor 0x1 $r5 $r1 c3[0x44]')
case('lop_imm', 'lop and 0x1 $r5 $r1 0xff0f')
case('lop32i', 'lop32i or $r5 $r1 0xf0f0f0f0')
case('lop32i_inv', 'lop32i xor $r5 inv $r1 inv 0x12345678')
for lut in [0x96, 0xe8, 0x00, 0xff, 0x80, 0x3c, 0xf0, 0x5a]:
    case('lop3_%02x' % lut, 'lop3 lut 0x1 $r5 $r1 $r2 $r3 0x%x' % lut)
case('lop3_pred_nz', 'lop3 lut nz $p4 $r5 $r1 $r2 $r3 0x6a')
case('lop3_cbuf', 'lop3 lut $r5 $r1 c3[0x48] $r3 0xd8')
case('lop3_imm', 'lop3 lut $r5 $r1 0x3333 0xe2')
for nm, ins in [('shl', 'shl $r5 $r1 $r2'), ('shl_w', 'shl w $r5 $r1 $r2'), ('shr_u', 'shr u32 $r5 $r1 $r2'),
                ('shr_s', 'shr $r5 $r1 $r2'), ('shr_u_w', 'shr u32 w $r5 $r1 $r2'), ('shr_s_w', 'shr w $r5 $r1 $r2'),
                ('shr_brev', 'shr u32 brev $r5 $r1 $r2'), ('shl_imm', 'shl $r5 $r1 0x7'),
                ('shr_cbuf', 'shr $r5 $r1 c3[0x4c]'), ('shl_cc', 'shl cc $r5 $r1 $r2')]:
    case(nm, ins, kind='h')
for d in ['l', 'r']:
    for ty in ['', 'u64 ', 's64 ']:
        for hi in ['', 'hi ']:
            for w in ['', 'w ']:
                nm = 'shf_%s_%s%s%s' % (d, ty.strip() or '32', '_hi' if hi else '', '_w' if w else '')
                case(nm, 'shf %s %s%s%s$r5 $r1 $r2 $r3' % (d, w, ty, hi), kind='h')
case('shf_r_imm', 'shf r u64 $r5 $r1 0x13 $r3', kind='h')
# immediate SHF.L (0x36f8): no envyas syntax; the register form re-encoded with S20 imm 0x2c
case('shf_l_imm_hi', 'shf l u64 hi $r5 $r1 $r2 $r3 !! 51:13=0x6df 20:8=0x2c', kind='h')
for nm, ins in [('bfe_u', 'bfe u32 $r5 $r1 $r2'), ('bfe_s', 'bfe $r5 $r1 $r2'), ('bfe_brev', 'bfe u32 brev $r5 $r1 $r2'),
                ('bfe_imm', 'bfe $r5 $r1 0x0c04'), ('bfe_cbuf', 'bfe u32 $r5 $r1 c3[0x50]'),
                ('bfi', 'bfi $r5 $r1 $r2 $r3'), ('bfi_imm', 'bfi $r5 $r1 0x0805 $r3'),
                ('bfi_cbuf_c', 'bfi $r5 $r1 $r2 c3[0x54]'), ('bfi_cbuf_b', 'bfi $r5 $r1 c3[0x58] $r3')]:
    case(nm, ins, kind='b')
for nm, ins in [('flo_u', 'flo u32 $r5 $r1'), ('flo_s', 'flo $r5 $r1'), ('flo_sh', 'flo u32 sh $r5 $r1'),
                ('flo_inv', 'flo u32 $r5 inv $r1'), ('flo_cbuf', 'flo u32 $r5 c3[0x5c]'), ('flo_imm', 'flo $r5 -0x8'),
                ('popc', 'popc $r5 $r1'), ('popc_inv', 'popc $r5 inv $r1'), ('popc_imm', 'popc $r5 0x7f0f')]:
    case(nm, ins)
for mode in ['', 'f4e ', 'b4e ', 'rc8 ', 'ecl ', 'ecr ', 'rc16 ']:
    case('prmt_%s' % (mode.strip() or 'idx'), 'prmt %s$r5 $r1 $r2 $r3' % mode, kind='m')
case('prmt_imm', 'prmt $r5 $r1 0x3210 $r3')
case('prmt_sign', 'prmt $r5 $r1 0x8b4a $r3')
case('prmt_cbuf', 'prmt $r5 $r1 c3[0x60] $r3')

# ---------------------------------------------------------------- integer compares
for c in ['f', 'lt', 'eq', 'le', 'gt', 'ne', 'ge', 't']:
    for s in ['u32 ', '']:
        case('isetp_%s_%s' % (c, s.strip() or 's32'), 'isetp %s %sand $p1 $p2 $r1 $r2 0x1' % (c, s))
case('isetp_or_p0', 'isetp lt or $p1 $p2 $r1 $r2 $p0')
case('isetp_xor_notp3', 'isetp ge u32 xor $p1 $p2 $r1 $r2 not $p3')
for c in ['lt', 'eq', 'le', 'gt', 'ne', 'ge']:
    case('isetp_x_' + c, ['iadd cc $r255 $r1 neg $r2', 'isetp %s x and $p1 $p2 $r3 $r1 0x1' % c])
    case('isetp_x_u_' + c, ['iadd cc $r255 $r1 neg $r2', 'isetp %s u32 x and $p1 $p2 $r3 $r3 0x1' % c])
case('isetp_cbuf', 'isetp le u32 and $p1 $p2 $r1 c3[0x64] 0x1')
case('isetp_imm', 'isetp gt and $p1 $p2 $r1 -0x10 0x1')
case('iset', 'iset lt and $r5 $r1 $r2 0x1')
case('iset_bf', 'iset bf ne u32 or $r5 $r1 $r2 $p1')
case('iset_cc', 'iset eq and cc $r5 $r1 $r2 0x1')
for c in ['lt', 'eq', 'ge', 'ne']:
    case('icmp_' + c, 'icmp %s $r5 $r1 $r2 $r3' % c)
case('icmp_u', 'icmp gt u32 $r5 $r1 $r2 $r3')
case('icmp_cbuf', 'icmp le $r5 $r1 $r2 c3[0x68]')
case('icmp_imm', 'icmp ne $r5 $r1 0x55 $r3')

# ---------------------------------------------------------------- float arithmetic
case('fadd', 'fadd $r5 $r1 $r2', kind='f')
case('fadd_negs', 'fadd $r5 neg $r1 neg $r2', kind='f')
case('fadd_abs', 'fadd $r5 abs $r1 abs $r2', kind='f')
case('fadd_ftz_sat', 'fadd ftz sat $r5 $r1 neg abs $r2', kind='f')
case('fadd_cc', 'fadd cc $r5 $r1 $r2', kind='f')
case('fadd_cbuf', 'fadd $r5 $r1 c3[0x70]', kind='f')
case('fadd_imm', 'fadd $r5 $r1 0x3f800000', kind='f')
case('fadd32i', 'fadd32i $r5 neg $r1 0x40490fdb', kind='f')
case('fadd32i_abs_ftz', 'fadd32i ftz $r5 abs $r1 0x3e800000', kind='f')
case('fmul', 'fmul $r5 $r1 $r2', kind='f')
case('fmul_neg_sat', 'fmul sat $r5 $r1 neg $r2', kind='f')
case('fmul_ftz', 'fmul ftz $r5 $r1 $r2', kind='f')
case('fmul_fmz', 'fmul fmz $r5 $r1 $r2', kind='f')
for sc in ['d2', 'd4', 'd8', 'm8', 'm4', 'm2']:
    case('fmul_' + sc, 'fmul %s $r5 $r1 $r2' % sc, kind='f')
case('fmul_cbuf', 'fmul $r5 $r1 c3[0x74]', kind='f')
case('fmul_imm', 'fmul $r5 $r1 0x40000000', kind='f')
case('fmul32i', 'fmul32i $r5 $r1 0x3dcccccd', kind='f')
case('fmul32i_fmz_sat', 'fmul32i fmz sat $r5 $r1 0x40400000', kind='f')
case('ffma', 'ffma $r5 $r1 $r2 $r3', kind='f')
case('ffma_negs', 'ffma $r5 $r1 neg $r2 neg $r3', kind='f')
case('ffma_sat', 'ffma sat $r5 $r1 $r2 $r3', kind='f')
case('ffma_ftz', 'ffma ftz $r5 $r1 $r2 $r3', kind='f')
case('ffma_fmz', 'ffma fmz $r5 $r1 $r2 $r3', kind='f')
case('ffma_cbuf_b', 'ffma $r5 $r1 c3[0x78] $r3', kind='f')
case('ffma_cbuf_c', 'ffma $r5 $r1 $r2 c3[0x7c]', kind='f')
case('ffma_imm', 'ffma $r5 $r1 0x3f000000 $r3', kind='f')
case('ffma32i', 'ffma32i $r5 $r1 0x3fc00000 $r5', kind='f')
case('ffma32i_negs', 'ffma32i $r5 neg $r1 0x3fc00000 neg $r5', kind='f')
case('fmnmx_min', 'fmnmx $r5 $r1 $r2 0x1', kind='f')
case('fmnmx_max', 'fmnmx $r5 $r1 $r2 not 0x1', kind='f')
case('fmnmx_pred_negabs', 'fmnmx ftz $r5 neg $r1 abs $r2 $p0', kind='f')
case('fmnmx_absa_negb', 'fmnmx $r5 abs $r1 neg $r2 not 0x1', kind='f')
case('fmnmx_cbuf', 'fmnmx $r5 $r1 c3[0x80] 0x1', kind='f')
case('fmnmx_imm', 'fmnmx $r5 $r1 0x3f800000 not 0x1', kind='f')
for c in ['f', 'lt', 'eq', 'le', 'gt', 'ne', 'ge', 'num', 'nan', 'ltu', 'equ', 'leu', 'gtu', 'neu', 'geu', 't']:
    case('fsetp_' + c, 'fsetp %s and $p1 $p2 $r1 $r2 0x1' % c, kind='f')
case('fsetp_negabs_or', 'fsetp lt or $p1 $p2 neg $r1 abs $r2 $p0', kind='f')
case('fsetp_absa_negb', 'fsetp lt and $p1 $p2 abs $r1 neg $r2 0x1', kind='f')
case('fsetp_absa', 'fsetp lt and $p1 $p2 abs $r1 $r2 0x1', kind='f')
case('fsetp_negb', 'fsetp gt and $p1 $p2 $r1 neg $r2 0x1', kind='f')
case('fsetp_ftz', 'fsetp eq ftz and $p1 $p2 $r1 $r2 0x1', kind='f')
case('fsetp_cbuf', 'fsetp gt and $p1 $p2 $r1 c3[0x84] 0x1', kind='f')
case('fsetp_imm', 'fsetp le and $p1 $p2 $r1 0x3f800000 0x1', kind='f')
case('fset', 'fset lt and $r5 $r1 $r2 0x1', kind='f')
case('fset_bf', 'fset bf geu xor $r5 neg $r1 abs $r2 $p1', kind='f')
case('fset_ftz_cbuf', 'fset bf ne and ftz $r5 $r1 c3[0x88] 0x1', kind='f')
case('fset_absa_negb', 'fset bf gt and $r5 abs $r1 neg $r2 0x1', kind='f')
for c in ['lt', 'eq', 'ge', 'nan']:
    case('fcmp_' + c, 'fcmp %s $r5 $r1 $r2 $r3' % c, kind='f')
case('fcmp_cbuf', 'fcmp le $r5 $r1 $r2 c3[0x8c]', kind='f')
case('fcmp_imm', 'fcmp gt $r5 $r1 0x3f800000 $r3', kind='f')
# sin/cos: Vulkan guarantees an absolute error of 2^-11 on [-pi, pi] (flag 'abs'), not ULPs
for fn, tol, fl in [('cos', 0, 'abs'), ('sin', 0, 'abs'), ('ex2', 64, ''), ('lg2', 64, ''), ('rcp', 2, ''), ('rsq', 4, '')]:
    case('mufu_' + fn, 'mufu %s $r5 $r1' % fn, kind='f', tol=tol, flags=fl)
case('mufu_sqrt', 'mufu rcp $r5 $r1 !! 20:4=8', kind='f', tol=4)   # SM52+ (Tegra X1 is SM53): envyas -m gm107 lacks it
case('mufu_rcp_negabs_sat', 'mufu rcp sat $r5 neg abs $r1', kind='f', tol=2)
case('rro_sincos', ['rro sincos $r6 $r1', 'mufu sin $r5 $r6'], kind='f', flags='abs')
case('rro_ex2', ['rro ex2 $r6 neg $r1', 'mufu ex2 $r5 $r6'], kind='f', tol=64)

# ---------------------------------------------------------------- conversions
for m in ['', 'round ', 'floor ', 'ceil ', 'trunc ']:
    case('f2f_' + (m.strip() or 'rn'), 'f2f f32 f32 %s$r5 $r1' % m, kind='f')
case('f2f_sat_negabs', 'f2f f32 f32 sat $r5 neg abs $r1', kind='f')
case('f2f_ftz', 'f2f ftz f32 f32 $r5 $r1', kind='f')
case('f2f_f16_f32', 'f2f f16 f32 $r5 $r1', kind='f')
case('f2f_f32_f16', 'f2f f32 f16 $r5 $r1', kind='x')
case('f2f_f32_f16_h1', 'f2f f32 f16 $r5 $r1 !! 41:1=1', kind='x')   # h1: bit 41 (no envyas syntax)
case('f2f_cbuf', 'f2f f32 f32 floor $r5 c3[0x90]', kind='f')
case('f2f_imm', 'f2f f32 f32 trunc $r5 0x40b00000', kind='f')
for it in ['s32', 'u32', 's16', 'u16', 's8', 'u8']:
    for m in ['', 'floor ', 'ceil ', 'trunc ']:
        case('f2i_%s_%s' % (it, m.strip() or 'rn'), 'f2i %s f32 %s$r5 $r1' % (it, m), kind='F')
case('f2i_negabs_ftz', 'f2i ftz s32 f32 trunc $r5 neg abs $r1', kind='F')
case('f2i_cbuf', 'f2i s32 f32 trunc $r5 c3[0x94]', kind='F')
case('f2i_imm', 'f2i u16 f32 floor $r5 0x477ff000', kind='F')
for it in ['s32', 'u32', 's16', 'u16', 's8', 'u8']:
    case('i2f_' + it, 'i2f f32 %s $r5 $r1' % it)
case('i2f_s8_b2', 'i2f f32 s8 $r5 b2 $r1')
case('i2f_u16_h1', 'i2f f32 u16 $r5 b2 $r1')
case('i2f_neg_abs', 'i2f f32 s32 $r5 neg abs $r1')
case('i2f_f16', 'i2f f16 s32 $r5 $r1')
case('i2f_cbuf', 'i2f f32 u32 $r5 c3[0x98]')
case('i2f_imm', 'i2f f32 s32 $r5 -0x7')
for dt in ['s32', 'u32', 's16', 'u16', 's8', 'u8']:
    for st in ['s32', 'u32', 's8']:
        case('i2i_%s_%s' % (dt, st), 'i2i %s %s $r5 $r1' % (dt, st))
        case('i2i_sat_%s_%s' % (dt, st), 'i2i %s %s sat $r5 $r1' % (dt, st))
case('i2i_neg_abs', 'i2i s32 s32 $r5 neg abs $r1')
case('i2i_sat_neg_u32_s16', 'i2i s16 u32 sat $r5 neg $r1')
case('i2i_sat_neg_u32_u8', 'i2i u8 u32 sat $r5 neg $r1')
case('i2i_b3', 'i2i s32 s8 $r5 b3 $r1')
case('i2i_cbuf', 'i2i s16 s32 sat $r5 c3[0x9c]')
case('i2i_imm', 'i2i u8 s32 $r5 0x1ff')

# ---------------------------------------------------------------- predicates
for b1 in ['and', 'or', 'xor']:
    for b2 in ['and', 'or', 'xor']:
        case('psetp_%s_%s' % (b1, b2), 'psetp %s %s $p5 $p6 $p0 not $p1 $p2' % (b1, b2))
case('pset', 'pset or and $r5 $p0 $p1 $p2')
case('pset_bf', 'pset bf xor or $r5 not $p3 $p4 not $p5')
case('p2r_b0', 'p2r $r5 pr $r1 0x5a')
case('p2r_b2', 'p2r b2 $r5 pr $r1 0xff')
case('p2r_cbuf', 'p2r $r5 pr $r1 c3[0xa0]')
case('r2p_b0', 'r2p pr $r1 0x3c')
case('r2p_b3', 'r2p pr b3 $r1 0x7f')
case('r2p_cbuf', 'r2p pr $r1 c3[0xa4]')

# ---------------------------------------------------------------- memory
case('ldc_b32', 'ld b32 $r5 c4[$r1+0x8]', kind='c4')
case('ldc_b64', 'ld b64 $r5 c4[$r1+0x10]', kind='c8')
case('ldc_u8', 'ld u8 $r5 c4[$r1+0x3]', kind='c1')
case('ldc_s8', 'ld s8 $r5 c4[$r1+0x1]', kind='c1')
case('ldc_u16', 'ld u16 $r5 c4[$r1+0x2]', kind='c2')
case('ldc_s16', 'ld s16 $r5 c4[$r1]', kind='c2')
case('ldc_rz', 'ld b32 $r5 c4[0x40]', kind='c4')
case('ldc_oob', 'ld b32 $r5 c4[$r1+0x7ffc]', kind='c4')
# kind aN: A = tid * 32 + an offset in [0, 16) aligned to N (disjoint per invocation)
for sz, al in [('u8', 1), ('s8', 1), ('u16', 2), ('s16', 2), ('b32', 4), ('b64', 8), ('b128', 16)]:
    k = 'a%d' % al
    case('ldg_' + sz, 'ldg e %s $r5 ncg[$r14]' % sz, kind=k)
    case('stg_' + sz, ['stg e %s ncg[$r14] $r2' % sz, 'lop and 0x1 $r16 $r1 -0x10', 'iadd cc $r18 $r16 c0[0x150]',
                       'iadd x $r19 $r255 c0[0x154]', 'ldg e b64 $r7 ncg[$r18]', 'ldg e b32 $r6 ncg[$r18+0x8]',
                       'ldg e b32 $r5 ncg[$r18+0xc]'], kind=k)
    case('lds_sts_' + sz, ['lop and 0x1 $r16 $r1 -0x10', 'st b128 s[$r16] $r1', 'st %s s[$r1] $r2' % sz,
                           'ld %s $r5 s[$r1]' % sz, 'ld b64 $r7 s[$r16]', 'ld b32 $r6 s[$r16+0x8]'],
         kind=k, shared=2048)
    case('ldl_stl_' + sz, ['lop and 0x1 $r16 $r1 0x1f', 'lop and 0x1 $r17 $r1 0x10', 'st b128 l[$r17] $r1',
                           'st %s l[$r16] $r2' % sz, 'ld %s $r5 l[$r16]' % sz, 'ld b64 $r7 l[$r17]',
                           'ld b32 $r6 l[$r17+0x8]'], kind=k, local=64)
case('ldg_rz_imm', 'ldg e b32 $r5 ncg[$r255+0x10]', kind='a4')
case('ld_generic', ['ld e b32 $r5 g[$r14+0x8] 0x1', 'st e b32 g[$r14+0x0] $r3 0x1', 'ldg e b32 $r6 ncg[$r14]'], kind='a4')
for op in ['add', 'min', 'max', 'and', 'or', 'xor', 'exch', 'inc', 'dec']:
    case('atom_' + op, 'atom %s e u32 $r5 g[$r14+0x0] $r2' % op, kind='a16')
    case('atom_s32_' + op, 'atom %s e s32 $r5 g[$r14+0x4] $r2' % op, kind='a16') if op in ('min', 'max', 'add') else None
case('atom_cas', 'atom cas e b32 $r5 g[$r14+0x0] $r2', kind='a16')
for op in ['add', 'min', 'max', 'and', 'or', 'xor']:
    case('red_' + op, ['red %s e u32 g[$r14+0x0] $r2' % op, 'ldg e b32 $r5 ncg[$r14]'], kind='a16')
case('red_add_shared_word', ['iadd cc $r16 $r255 c0[0x150]', 'iadd x $r17 $r255 c0[0x154]',
                             'red add e u32 g[$r16+0x10] $r2'], kind='a16')
for op in ['add', 'min', 'max', 'and', 'or', 'xor', 'exch']:
    case('atoms_' + op, ['shl $r16 $r20 0x4', 'st b32 s[$r16] $r3', 'atoms %s u32 $r5 s[$r16] $r2' % op,
                         'ld b32 $r6 s[$r16]'], shared=1024)
case('atoms_s32_min', ['shl $r16 $r20 0x4', 'st b32 s[$r16] $r3', 'atoms min s32 $r5 s[$r16] $r2',
                       'ld b32 $r6 s[$r16]'], shared=1024)
case('atoms_cas', ['shl $r16 $r20 0x4', 'st b32 s[$r16] $r3', 'mov $r2 $r3 0xf', 'atoms cas b32 $r5 s[$r16] $r2',
                   'ld b32 $r6 s[$r16]'], shared=1024)
case('bar_shared_exchange', ['shl $r16 $r20 0x2', 'st b32 s[$r16] $r1', 'bar sync 0x0 0x0 0x1',
                             'lop xor 0x1 $r17 $r16 0x4', 'ld b32 $r5 s[$r17]', 'membar cta', 'depbar le 0x5 0x0 0x0',
                             'nop 0x0', 'membar gl'], shared=256)

# ---------------------------------------------------------------- control flow
case('bra_pred', ['$p0 bra @t', 'mov32i $r5 0x1 0xf', '@t:', 'iadd32i $r5 $r5 0x10'])
case('bra_not_pred_loop', ['mov32i $r5 0x0 0xf', 'lop and 0x1 $r16 $r1 0x7', '@loop:', 'iadd32i $r5 $r5 0x3',
                           'iadd32i $r16 $r16 -0x1', 'isetp gt and $p0 0x1 $r16 0x0 0x1', '$p0 bra @loop'])
case('ssy_sync', ['ssy @join', '$p0 bra @else', 'mov32i $r5 0x1 0xf', 'sync', '@else:', 'mov32i $r5 0x2 0xf',
                  'sync', '@join:', 'iadd32i $r5 $r5 0x100'])
case('ssy_nested', ['ssy @j1', '$p0 bra @e1', 'ssy @j2', '$p1 bra @e2', 'mov32i $r5 0x1 0xf', 'sync', '@e2:',
                    'mov32i $r5 0x2 0xf', 'sync', '@j2:', 'iadd32i $r5 $r5 0x10', 'sync', '@e1:',
                    'mov32i $r5 0x3 0xf', 'sync', '@j1:', 'iadd32i $r5 $r5 0x100'])
case('pbk_brk', ['mov32i $r5 0x0 0xf', 'pbk @out', '@loop:', 'iadd32i $r5 $r5 0x1', 'lop and 0x1 $r16 $r5 0x7',
                 'isetp eq and $p0 0x1 $r16 $r2 0x1', '$p0 brk', 'isetp ge and $p0 0x1 $r5 0x40 0x1', '$p0 brk',
                 'bra @loop', '@out:', 'iadd32i $r5 $r5 0x1000'], kind='h')
case('pcnt_cont', ['mov32i $r5 0x0 0xf', 'mov32i $r16 0x0 0xf', 'pbk @out', '@loop:', 'pcnt @next',
                   'iadd32i $r16 $r16 0x1', 'lop and z $p0 $r255 $r16 0x1', '$p0 cont', 'iadd $r5 $r5 $r16',
                   'cont', '@next:', 'isetp lt and $p0 0x1 $r16 0x9 0x1', '$p0 bra @loop', 'brk', '@out:',
                   'iadd32i $r5 $r5 0x1000'])
case('cal_ret', ['mov32i $r5 0x1 0xf', 'cal @fn', 'iadd32i $r5 $r5 0x100', 'cal @fn', 'bra @done', '@fn:',
                 'iadd $r5 $r5 $r5', '$p0 ret', 'iadd32i $r5 $r5 0x1', 'ret', '@done:', 'iadd32i $r5 $r5 0x10000'])
case('brx', ['lop and 0x1 $r16 $r1 0x1', 'shl $r16 $r16 0x4', 'brx $r16 @^tbl', '@tbl:', 'mov32i $r5 0xa 0xf',
             'bra @after', 'mov32i $r5 0xb 0xf', '@after:', 'iadd32i $r5 $r5 0x100'])
case('jmp_abs', ['mov32i $r5 0x1 0xf', 'jmp @@abs', 'mov32i $r5 0x2 0xf', '@abs:', 'iadd32i $r5 $r5 0x10'])
case('exit_pred', ['mov32i $r5 0x5 0xf', '$p0 exit'])
case('kil_pred', ['mov32i $r5 0x6 0xf', '$p1 kil'])
case('bra_cc', ['iadd cc $r255 $r1 neg $r2', 'mov32i $r5 0x1 0xf', 'bra lt @t', 'mov32i $r5 0x2 0xf', '@t:',
                'iadd32i $r5 $r5 0x10'])
case('sync_pred', ['ssy @j', 'mov32i $r5 0x1 0xf', '$p0 sync', 'mov32i $r5 0x2 0xf', 'sync', '@j:',
                   'iadd32i $r5 $r5 0x30'])


# ---------------------------------------------------------------- assembly
def layout(lines):
    """Instruction lines -> real byte addresses (a scheduling word every 4th slot) and labels."""
    labels, addrs, insns = {}, [], []
    slot = 0
    for ln in lines:
        if ln.endswith(':') and ln.startswith('@'):
            if slot % 4 == 0:
                slot += 1
            labels[ln[1:-1]] = slot * 8
            continue
        if slot % 4 == 0:
            slot += 1
        addrs.append(slot * 8)
        insns.append(ln)
        slot += 1
    return labels, addrs, insns


def assemble(lines):
    labels, addrs, insns = layout(lines)
    patches = []
    for k, ln in enumerate(insns):
        if '!!' in ln:
            ln, spec = ln.split('!!')
            insns[k] = ln.strip()
            for item in spec.split():
                pos_len, val = item.split('=')
                pos, ln_ = (int(x) for x in pos_len.split(':'))
                patches.append((k, pos, ln_, int(val, 0)))
    text = []
    for k, (a, ln) in enumerate(zip(addrs, insns)):
        def repl(m):
            t = labels[m.group(2)]
            if m.group(1) == '@':      # absolute (JMP)
                return '0x%x' % t
            if m.group(1) == '^':      # plain immediate relative to the next instruction (BRX)
                d = t - (a + 8)
                return ('-0x%x' % -d) if d < 0 else '0x%x' % d
            # envyas encodes target - (its own position + 8); its position is k * 8
            return '0x%x' % (t - a + k * 8)
        text.append(re.sub(r'@([@^]?)([a-z0-9_]+)', repl, ln))
    with tempfile.NamedTemporaryFile('w', suffix='.s', delete=False) as f:
        f.write('\n'.join(text) + '\n')
        src = f.name
    out = src + '.bin'
    r = subprocess.run([ENVYAS, '-m', 'gm107', '-w', src, '-o', out], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit('envyas failed on:\n%s\n%s' % ('\n'.join(text), r.stderr))
    w = [int(x, 16) for x in re.findall(r'0x[0-9a-f]+', open(out).read())]
    if len(w) != 2 * len(insns):
        raise SystemExit('unexpected envyas output size for %s' % insns)
    words = {}
    for k, a in enumerate(addrs):
        words[a // 8] = w[2 * k] | (w[2 * k + 1] << 32)
    for k, pos, ln_, val in patches:
        m = ((1 << ln_) - 1) << pos
        words[addrs[k] // 8] = (words[addrs[k] // 8] & ~m) | ((val << pos) & m)
    n = max(words) + 1
    code = []
    for i in range(n):
        code.append(SCHED if i % 4 == 0 else words.get(i, 0x50b0000000070f00))   # nop fill
    return code


cases = [c for c in cases if c is not None]
with open(OUT, 'w') as o:
    o.write('// Generated by tools/gpu_toolchain/gen_shader_t2.py (envyas). Do not edit.\n')
    o.write('// %d cases: name, input kind, float ULP tolerance, flags, shared bytes, local bytes, code.\n' % len(cases))
    o.write('#pragma once\n#include <cstdint>\n\nnamespace lg_test::t2 {\n\n')
    for i, (name, kind, tol, flags, shared, local, body) in enumerate(cases):
        code = assemble(PROLOGUE + body + EPILOGUE)
        o.write('static const uint64_t k_code_%d[] = {\n' % i)
        for j in range(0, len(code), 4):
            o.write('    ' + ', '.join('0x%016xull' % x for x in code[j:j + 4]) + ',\n')
        o.write('};\n')
    o.write('\nstruct Case { const char* name; const char* kind; uint32_t tol; const char* flags; uint32_t shared;\n'
            '              uint32_t local; const uint64_t* code; uint32_t words; const char* body; };\n\n')
    o.write('static const Case kCases[] = {\n')
    for i, (name, kind, tol, flags, shared, local, body) in enumerate(cases):
        b = ' | '.join(body).replace('\\', '\\\\').replace('"', '\\"')
        o.write('    {"%s", "%s", %d, "%s", %d, %d, k_code_%d, sizeof(k_code_%d) / 8, "%s"},\n' % (
            name, kind, tol, flags, shared, local, i, i, b))
    o.write('};\n\n} // namespace lg_test::t2\n')
print(len(cases), 'cases')
