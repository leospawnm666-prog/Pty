#!/usr/bin/env python3
# P4.1 T3 (P4_DISENO.md §5.3): random compute shaders with a fixed seed for the differential
# corpus. Integer expressions are exact; float expressions avoid operations whose results depend
# on the front end (division, transcendental functions) and keep magnitudes small with clamp(),
# because uam may fuse a*b+c into FFMA where glslang does not (hence `atol`).
# Usage: gen_random_shaders.py <out dir> [count] [seed]
import os
import random
import sys

out_dir = sys.argv[1]
count = int(sys.argv[2]) if len(sys.argv) > 2 else 24
seed = int(sys.argv[3]) if len(sys.argv) > 3 else 20261014
rng = random.Random(seed)


def uconst():
    return rng.choice(['%uu' % rng.randrange(0, 64), '0x%xu' % rng.getrandbits(32)])


def iexpr(d, vars_):
    if d == 0 or rng.random() < 0.2:
        return rng.choice(vars_ + [uconst()])
    k = rng.randrange(17)
    a = lambda: iexpr(d - 1, vars_)
    if k == 0: return '(%s + %s)' % (a(), a())
    if k == 1: return '(%s - %s)' % (a(), a())
    if k == 2: return '(%s * %s)' % (a(), a())
    if k == 3: return '(%s & %s)' % (a(), a())
    if k == 4: return '(%s | %s)' % (a(), a())
    if k == 5: return '(%s ^ %s)' % (a(), a())
    if k == 6: return '(%s << (%s & 31u))' % (a(), a())
    if k == 7: return '(%s >> (%s & 31u))' % (a(), a())
    if k == 8: return 'uint(int(%s) >> int(%s & 31u))' % (a(), a())
    if k == 9: return 'min(%s, %s)' % (a(), a())
    if k == 10: return 'uint(max(int(%s), int(%s)))' % (a(), a())
    if k == 11: return '(%s %s %s ? %s : %s)' % (a(), rng.choice(['<', '>', '<=', '>=', '==', '!=']), a(), a(), a())
    if k == 12: return '(%s / %du)' % (a(), rng.choice([3, 5, 7, 10, 255, 1000]))
    if k == 13: return 'bitfieldExtract(%s, %d, %d)' % (a(), rng.randrange(0, 24), rng.randrange(1, 8))
    if k == 14: return 'uint(bitCount(%s))' % a()
    if k == 15: return '(~%s)' % a()
    return '(%s %% %du)' % (a(), rng.choice([3, 9, 16, 100]))


def fexpr(d, vars_):
    if d == 0 or rng.random() < 0.2:
        return rng.choice(vars_ + ['%.3f' % rng.uniform(-4, 4)])
    k = rng.randrange(11)
    a = lambda: fexpr(d - 1, vars_)
    if k == 0: return '(%s + %s)' % (a(), a())
    if k == 1: return '(%s - %s)' % (a(), a())
    if k == 2: return 'clamp(%s * %s, -64.0, 64.0)' % (a(), a())
    if k == 3: return 'min(%s, %s)' % (a(), a())
    if k == 4: return 'max(%s, %s)' % (a(), a())
    if k == 5: return 'abs(%s)' % a()
    if k == 6: return 'floor(%s)' % a()
    if k == 7: return 'ceil(%s)' % a()
    if k == 8: return '(%s %s %s ? %s : %s)' % (a(), rng.choice(['<', '>', '<=', '>=']), a(), a(), a())
    if k == 9: return '(-(%s))' % a()
    return 'float(int(clamp(%s, -1000.0, 1000.0)))' % a()


def shader(n):
    lines = ['#version 460',
             '// P4.1 T3: random shader %d (gen_random_shaders.py, seed %d). Generated: do not edit.' % (n, seed),
             '// dispatch: 2 1 1',
             '// buffer: 0 u 128', '// buffer: 1 f 128', '// buffer: 2 z 512', '// buffer: 3 w 256',
             '// tol: 16', '// atol: 0.001',
             'layout(local_size_x = 64) in;',
             'layout(std430, binding = 0) buffer A { uint a[]; };',
             'layout(std430, binding = 1) buffer B { float b[]; };',
             'layout(std430, binding = 2) buffer O { uint o[]; };',
             'layout(std430, binding = 3) buffer P { float p[]; };',
             'void main() {',
             '    uint i = gl_GlobalInvocationID.x;',
             '    uint x = a[i], y = a[(i + 17u) & 127u], z = i;',
             '    float f = b[i], g = b[(i + 5u) & 127u];']
    ivars = ['x', 'y', 'z']
    fvars = ['f', 'g']
    body = []
    for s in range(rng.randrange(3, 7)):
        kind = rng.randrange(5)
        if kind == 0:
            body.append('    x = %s;' % iexpr(3, ivars))
        elif kind == 1:
            body.append('    f = clamp(%s, -64.0, 64.0);' % fexpr(3, fvars))
        elif kind == 2:
            body.append('    if (%s %s %s) { y = %s; } else { g = clamp(%s, -64.0, 64.0); }' % (
                iexpr(2, ivars), rng.choice(['<', '>', '==', '!=']), iexpr(2, ivars), iexpr(2, ivars), fexpr(2, fvars)))
        elif kind == 3:
            body.append('    for (uint k = 0u; k < (%s & 7u); ++k) { x = %s; if ((x & 3u) == 1u) break; }' % (
                iexpr(1, ivars), iexpr(2, ivars + ['k'])))
        else:
            body.append('    y = y + uint(int(clamp(%s, -100000.0, 100000.0)));' % fexpr(2, fvars))
    lines += body
    lines += ['    o[4u * i + 0u] = x;', '    o[4u * i + 1u] = y;', '    o[4u * i + 2u] = x ^ y;',
              '    o[4u * i + 3u] = z * 3u;',
              '    p[2u * i + 0u] = f;', '    p[2u * i + 1u] = g;', '}', '']
    return '\n'.join(lines)


os.makedirs(out_dir, exist_ok=True)
for n in range(count):
    with open(os.path.join(out_dir, 'r%02d_random.comp' % n), 'w') as f:
        f.write(shader(n))
print(count, 'shaders')
