#!/usr/bin/env bash
# Step 2 E2E — verify native .so in APK: presence, arch, TEXTREL, DYNAMIC
set -euo pipefail

fail() { echo "FAIL: $*"; exit 1; }
pass() { echo "PASS: $*"; }
warn() { echo "WARN: $*"; }

APK="${1:-}"
if [[ -z "$APK" || ! -f "$APK" ]]; then
  fail "usage: $0 <path-to.apk>"
fi

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "=== verify_native_so ==="
echo "APK=$APK"

unzip -l "$APK" | grep -E 'lib/.*/liblobogelido' || warn "no liblobogelido* entries in APK listing"

# Prefer arm64-v8a
SO_REL=$(unzip -Z1 "$APK" | grep -E 'lib/arm64-v8a/liblobogelido.*\.so$' | head -1 || true)
if [[ -z "$SO_REL" ]]; then
  SO_REL=$(unzip -Z1 "$APK" | grep -E 'lib/.*/liblobogelido.*\.so$' | head -1 || true)
fi
[[ -n "$SO_REL" ]] || fail "liblobogelido*.so not found inside APK"

pass "found $SO_REL"
unzip -qo "$APK" "$SO_REL" -d "$TMP"
SO="$TMP/$SO_REL"
[[ -f "$SO" ]] || fail "extract failed"

# Size sanity
SZ=$(wc -c < "$SO" | tr -d ' ')
[[ "$SZ" -gt 10000 ]] || fail "native .so too small ($SZ bytes)"
pass "size=${SZ} bytes"

# ELF magic
if command -v file >/dev/null 2>&1; then
  file "$SO" | grep -qiE 'ELF|shared' && pass "file: $(file -b "$SO" | head -c 80)" || warn "file(1) unexpected"
fi

READELF=""
for c in llvm-readelf readelf llvm-readobj; do
  if command -v "$c" >/dev/null 2>&1; then READELF=$c; break; fi
done

if [[ -z "$READELF" ]]; then
  warn "readelf/llvm-readelf not installed — TEXTREL check skipped"
  # Fallback: scan for DT_TEXTREL string is unreliable; require tool
  exit 0
fi

echo "Using $READELF"

# Machine / class
if "$READELF" -h "$SO" 2>/dev/null | grep -qi 'AArch64\|ARM aarch64\|Machine:.*AArch64'; then
  pass "ELF machine AArch64"
elif "$READELF" -h "$SO" 2>/dev/null | grep -qi 'ARM\|Machine:'; then
  warn "ELF machine not clearly AArch64 — check ABI"
fi

# TEXTREL: dynamic section must NOT contain TEXTREL / TEXTREL flag
DYN=$("$READELF" -d "$SO" 2>/dev/null || true)
if echo "$DYN" | grep -qiE 'TEXTREL|FLAGS_1.*TEXTREL'; then
  fail "TEXTREL present — dlopen will fail on Android 6+"
fi
pass "no TEXTREL in dynamic section"

# NEEDED libs (informational)
echo "$DYN" | grep -i NEEDED | head -20 || true

# Writable+executable segments (W+E) — often related to bad relro / textrel setups
if "$READELF" -l "$SO" 2>/dev/null | grep -A2 'GNU_STACK' | grep -qi 'RWE\|WE'; then
  warn "GNU_STACK executable (unusual)"
else
  pass "GNU_STACK check ok (or absent)"
fi

pass "verify_native_so complete"
