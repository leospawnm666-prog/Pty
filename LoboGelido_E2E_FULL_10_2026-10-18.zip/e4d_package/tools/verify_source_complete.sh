#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
required=(
  "CMakeLists.txt"
  "android/settings.gradle.kts"
  "android/build.gradle.kts"
  "android/app/build.gradle.kts"
  "android/app/src/main/AndroidManifest.xml"
  "android/app/src/main/cpp/CMakeLists.txt"
  "android/app/src/main/cpp/native.cpp"
  "android/app/src/main/cpp/native_runtime_host.cpp"
  "loader/content_loader.cpp"
  "loader/nca_loader.cpp"
  "loader/nso_loader.cpp"
  "loader/romfs.cpp"
  "loader/content_metadata.cpp"
  "crypto/aes128.cpp"
  "crypto/sha256.cpp"
  "runtime/runtime_coordinator.cpp"
  "runtime/runtime_storage.cpp"
)
for f in "${required[@]}"; do
  [[ -f "$ROOT/$f" ]] || { echo "MISSING: $f" >&2; exit 1; }
done
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
for cm in (root/'CMakeLists.txt', root/'android/app/src/main/cpp/CMakeLists.txt'):
    for line in cm.read_text().splitlines():
        token=line.strip()
        if not token.endswith('.cpp'):
            continue
        if token.startswith('${LG_ROOT}/'):
            path=root/token[len('${LG_ROOT}/'):]
        elif cm.parent.name == 'cpp':
            path=cm.parent/token
        else:
            path=root/token
        if not path.is_file():
            raise SystemExit(f"MISSING CMAKE SOURCE: {path}")
print("Lobo Gélido source completeness: OK")
PY
