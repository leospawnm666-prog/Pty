// P3.6 (P3_6_DISENO.md §2.4): throughput of the coordinator on native NROs, per engine.
//   compute  100 M iterations of 4 integer instructions     -> M instr/s
//   branchy  10 M bl/ret calls (5 instructions each)        -> M instr/s
//   svcloop  1 M svcGetSystemTick                           -> ns per SVC
// Not a ctest test: the numbers depend on the machine. Build type Release for real numbers.
#include "bench_nro_fixtures.h"
#include "../../runtime/runtime_coordinator.h"

#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace {
using lg::runtime::RuntimeCoordinator;
using lg::runtime::State;

template <size_t N> std::string write(const char* name, const unsigned char (&a)[N]) {
    const auto p = std::filesystem::temp_directory_path() / (std::string("lobo_bench_") + name + ".nro");
    std::ofstream(p, std::ios::binary | std::ios::trunc).write(reinterpret_cast<const char*>(a), long(N));
    return p.string();
}
struct Engine { const char* name; bool force_interpreter; bool fastmem; };

void run(const char* prog, const std::string& path, const Engine& e, double units, const char* unit_name, bool per_unit_ns) {
    RuntimeCoordinator rt;
    rt.set_guest_memory_budget(64ull << 20);
    rt.set_force_interpreter(e.force_interpreter);
    rt.set_jit_fastmem(e.fastmem);
    if (!rt.prepare(path).ok() || !rt.start().ok()) { std::printf("%-8s %-14s prepare failed\n", prog, e.name); return; }
    const uint64_t quantum = rt.native_quantum();
    const auto t0 = std::chrono::steady_clock::now();
    uint64_t frames = 0;
    std::string err;
    while (rt.state() == State::Running) {
        const auto r = rt.run_frame(rt.entry_point());
        ++frames;
        if (!r.ok()) { err = r.error(); break; }
    }
    const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    if (per_unit_ns)
        std::printf("%-8s %-14s %8.3f s  %8.1f ns/%s  frames=%llu  quantum=%llu %s\n", prog, e.name, s, s * 1e9 / units, unit_name,
                    (unsigned long long)frames, (unsigned long long)quantum, err.c_str());
    else
        std::printf("%-8s %-14s %8.3f s  %8.1f M %s/s  frames=%llu  quantum=%llu %s\n", prog, e.name, s, units / s / 1e6, unit_name,
                    (unsigned long long)frames, (unsigned long long)quantum, err.c_str());
}
} // namespace

int main() {
    std::vector<Engine> engines = {{"Block", true, false}};
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    engines.push_back({"JIT", false, false});
    engines.push_back({"JIT+fastmem", false, true});
#endif
    const std::string compute = write("compute", bench_nro::compute);
    const std::string branchy = write("branchy", bench_nro::branchy);
    const std::string svcloop = write("svcloop", bench_nro::svcloop);
    for (const auto& e : engines) run("compute", compute, e, 400e6, "instr", false);
    for (const auto& e : engines) run("branchy", branchy, e, 50e6, "instr", false);
    for (const auto& e : engines) run("svcloop", svcloop, e, 1e6, "SVC", true);
    return 0;
}
