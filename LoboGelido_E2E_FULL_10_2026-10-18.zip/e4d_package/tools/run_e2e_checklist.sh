#!/usr/bin/env bash
# Lobo Gélido — E2E checklist runner (host + optional device)
set -euo pipefail
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

echo "=== E2E Lobo Gélido ==="
echo "ROOT=$ROOT"
echo "JAVA=$(java -version 2>&1 | head -1 || true)"
echo "DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ)"

fail() { echo "FAIL: $1"; exit 1; }
pass() { echo "PASS: $1"; }
warn() { echo "WARN: $1"; }

REPORT="${LOBO_E2E_REPORT:-$ROOT/e2e_report.txt}"
: > "$REPORT"
log() { echo "$*" | tee -a "$REPORT"; }

# ---------- Step 0: preflight ----------
log "--- Step 0: preflight ---"
java -version 2>&1 | grep -qE 'version "17|version "17\.' && pass "JDK 17" || warn "JDK 17 recommended for AGP 8.x"
test -f android/gradle/wrapper/gradle-wrapper.jar || fail "gradle-wrapper.jar missing"
test -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" && pass "ANDROID_HOME set" || warn "ANDROID_HOME not set"
command -v unzip >/dev/null || fail "unzip required"

# ---------- Step 0b: shader/ICD oracle ----------
log "--- Step 0b: shader oracle host ---"
if [[ -x tools/run_shader_oracle_host.sh ]]; then
  tools/run_shader_oracle_host.sh 2>&1 | tee -a "$REPORT" || warn "oracle host issues"
  pass "oracle host invoked"
else
  warn "run_shader_oracle_host.sh missing"
fi

# ---------- Step 1: APK + arm64 lib listing ----------
log "--- Step 1: APK presence ---"
APK="${LOBO_APK:-}"
if [[ -z "$APK" ]]; then
  APK=$(ls android/app/build/outputs/apk/debug/*.apk 2>/dev/null | head -1 || true)
fi
if [[ -z "$APK" ]]; then
  APK=$(ls android/app/build/outputs/apk/release/*.apk 2>/dev/null | head -1 || true)
fi
if [[ -n "$APK" && -f "$APK" ]]; then
  pass "APK=$APK"
  log "APK=$APK"
  unzip -l "$APK" | grep -E 'lib/arm64-v8a/.*\.so' | tee -a "$REPORT" || warn "no arm64-v8a .so listing"
else
  warn "no APK — set LOBO_APK= or assembleDebug"
  APK=""
fi

# ---------- Step 2: native .so / TEXTREL ----------
log "--- Step 2: verify_native_so (TEXTREL) ---"
if [[ -n "$APK" && -f "$APK" ]]; then
  if [[ -x tools/verify_native_so.sh ]]; then
    tools/verify_native_so.sh "$APK" 2>&1 | tee -a "$REPORT"
    pass "step2 verify_native_so finished"
  else
    fail "tools/verify_native_so.sh missing"
  fi
else
  warn "step2 skipped (no APK)"
fi

# ---------- Step 3: adb ----------
log "--- Step 3: adb ---"
if [[ -x tools/e2e_step3_adb.sh ]]; then
  tools/e2e_step3_adb.sh ${APK:+"$APK"} 2>&1 | tee -a "$REPORT" || warn "step3 issues"
  pass "step3 invoked"
else
  warn "e2e_step3_adb.sh missing"
fi

# ---------- Steps 4–10 (device helper) ----------
log "--- Steps 4–10: device helper ---"
if [[ "${LOBO_E2E_DEVICE:-0}" == "1" ]] && command -v adb >/dev/null 2>&1 && adb devices 2>/dev/null | grep -q $'device$'; then
  if [[ -x tools/e2e_steps_4_10_device.sh ]]; then
    tools/e2e_steps_4_10_device.sh 2>&1 | tee -a "$REPORT" || warn "steps 4–10 helper reported issues"
    pass "steps 4–10 helper finished"
  else
    warn "e2e_steps_4_10_device.sh missing"
  fi
else
  cat << 'STEPS' | tee -a "$REPORT"
Steps 4–10: set LOBO_E2E_DEVICE=1 with adb device to run helper
  export LOBO_PROD_KEYS=/path/prod.keys
  export LOBO_FIRMWARE=/path/fw_or_dir
  export LOBO_GAME=/path/game.nsp_or_dir
  export LOBO_E2E_DEVICE=1
  bash tools/e2e_steps_4_10_device.sh
STEPS
  warn "device helper skipped (LOBO_E2E_DEVICE!=1 or no adb)"
fi

log "=== E2E automated portion done ==="
log "REPORT=$REPORT"
pass "checklist runner complete"
