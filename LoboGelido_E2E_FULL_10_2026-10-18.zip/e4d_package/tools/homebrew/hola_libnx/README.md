# hola_libnx (hito H5)

El primer homebrew real de devkitPro para Lobo Gélido. Con devkitPro se compila así:

```sh
export DEVKITPRO=/opt/devkitpro     # con devkitA64 y libnx instalados (pacman: switch-dev)
make                                # -> hola_libnx.nro
```

## Ejecutarlo en Lobo
1. Copia `hola_libnx.nro` al teléfono y añádelo a la biblioteca.
2. Arranca con la JIT (es el valor por defecto del APK de P3.5; no actives "Forzar intérprete":
   el intérprete no ejecuta AdvSIMD/FP y libnx las usa).
3. Mira el log del guest (pantalla Rendimiento) o `adb logcat -s LoboGuest`.

## Criterio de H5
El log contiene exactamente:
```
Hola desde libnx: argc=1 HOS=5.1.0
time=<hora del sistema, en segundos POSIX>
adios
```
y la sesión termina en `exit=guest code=0` (resumen: `Estado: terminado (código 0)`).

Si algo falla, el resumen de la sesión dice dónde: una instrucción no soportada
(`[AdvSIMD/FP: …]`), una SVC o un comando IPC sin implementar ("IPC no implementada: …"),
o un servicio que nadie registra (el bloqueo lo nombra).

## Prueba en los tests (P3.5-H1)
`tests/data/nro/h5/gen_h5_fixture.sh` compila este mismo `main.c`, sin cambios, con todo el
*runtime* de devkitPro construido desde fuentes (libnx, newlib de devkitPro con libsysbase,
compiler-rt) usando clang/lld, porque devkitA64 no se puede descargar en el entorno de
desarrollo. `tests/test_h5.cpp` comprueba el criterio de H5 en los 5 motores. La compilación
con el GCC de devkitPro sigue siendo la prueba definitiva.
