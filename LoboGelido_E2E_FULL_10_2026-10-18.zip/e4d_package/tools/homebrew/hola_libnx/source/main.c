// P3.5 (H5): the first real devkitPro homebrew for Lobo Gélido. Built with devkitA64 + libnx
// (see README.md); Lobo runs the resulting hola_libnx.nro with its JIT.
// Everything it prints goes to svcOutputDebugString, which Lobo shows in the guest log and in
// logcat (tag "LoboGuest").
#include <stdio.h>
#include <sys/iosupport.h>
#include <switch.h>

int main(int argc, char** argv) {
    (void)argv;
    consoleDebugInit(debugDevice_SVC);                 // stderr -> svcOutputDebugString
    devoptab_list[STD_OUT] = devoptab_list[STD_ERR];   // printf too
    setvbuf(stdout, NULL, _IOLBF, 0);
    const u32 hos = hosversionGet();
    printf("Hola desde libnx: argc=%d HOS=%u.%u.%u\n", argc, HOSVER_MAJOR(hos), HOSVER_MINOR(hos), HOSVER_MICRO(hos));
    u64 t = 0;
    if (R_SUCCEEDED(timeGetCurrentTime(TimeType_UserSystemClock, &t))) printf("time=%llu\n", (unsigned long long)t);
    printf("adios\n");
    return 0;                                          // exit -> __appExit -> back to the loader
}
