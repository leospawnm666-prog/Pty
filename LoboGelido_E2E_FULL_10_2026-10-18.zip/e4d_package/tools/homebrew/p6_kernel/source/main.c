// P6.0 guest test program (P6_0_DISENO.md §6): the SVCs P6.0 adds, called the way libnx and
// Horizon servers call them, from a real libnx program. Every check prints one line
// "P6 <name> ok" or "P6 <name> FAIL ..." through svcOutputDebugString; the last line is
// "P6 DONE fails=<n>". Lobo's own code (ISC-compatible use of libnx's public API).
#include <switch.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_fails;
static void say(const char* fmt, ...) {
    char b[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(b, sizeof b, fmt, ap);
    va_end(ap);
    svcOutputDebugString(b, n < 0 ? 0 : (u64)(n < (int)sizeof b ? n : (int)sizeof b - 1));
}
#define CHECK(name, cond, fmt, ...)                                          \
    do {                                                                     \
        if (cond) say("P6 %s ok\n", name);                                   \
        else { ++g_fails; say("P6 %s FAIL " fmt "\n", name, __VA_ARGS__); }  \
    } while (0)

static u32* tls_msg(void) { return (u32*)armGetTls(); }

// ---- the server thread -----------------------------------------------------------------------
enum { CmdEcho = 1, CmdProcessHandle = 2, CmdQuit = 3, CmdRaw = 4, CmdIndexed = 5, CmdXToMsg = 6, CmdLockInfo = 7 };
static Handle g_server_session, g_port_server, g_accepted = INVALID_HANDLE, g_extra = INVALID_HANDLE;
static u8 g_server_recv[0x100] __attribute__((aligned(16)));
static u8 g_server_recv1[0x100] __attribute__((aligned(16)));
static volatile Result g_moved_close = 1, g_late_reply = 1;
static volatile int g_closed_seen, g_extra_closed;
static volatile u32 g_lock_info[6];
static volatile u64 g_client_a, g_client_b;   // the client's A and B pages, for the server to query
static volatile u64 g_my_pid;

static void prepare_receive(void) {
    // an empty header whose receive list (mode ToSingleBuffer) points at g_server_recv
    u32* m = tls_msg();
    memset(m, 0, 0x100);
    HipcHeader* h = (HipcHeader*)m;
    h->recv_static_mode = 2 + 2;   // two indexed entries
    HipcRecvListEntry* e = (HipcRecvListEntry*)(m + 2);
    e[0] = hipcMakeRecvStatic(g_server_recv, sizeof g_server_recv);
    e[1] = hipcMakeRecvStatic(g_server_recv1, sizeof g_server_recv1);
}

static void serve_one(Handle session) {
    HipcParsedRequest p = hipcParseRequest(tls_msg());
    const u32 cmd = p.meta.num_data_words ? p.data.data_words[0] : 0;
    if (cmd == CmdEcho) {
        // check what the kernel delivered, then reply: raw sums, a moved event, an X static back
        u32 a_sum = 0, x_sum = 0;
        const u8* a = (const u8*)hipcGetBufferAddress(&p.data.send_buffers[0]);
        for (size_t i = 0; i < hipcGetBufferSize(&p.data.send_buffers[0]); ++i) a_sum += a[i];
        // the client's IPC-locked pages, seen from here (KMemoryBlock::LockForIpc)
        MemoryInfo mi; u32 pi;
        svcQueryMemory(&mi, &pi, g_client_a);
        g_lock_info[0] = mi.perm; g_lock_info[1] = mi.ipc_refcount; g_lock_info[2] = mi.attr;
        const u8* x = (const u8*)hipcGetStaticAddress(&p.data.send_statics[0]);
        for (size_t i = 0; i < hipcGetStaticSize(&p.data.send_statics[0]); ++i) x_sum += x[i];
        u8* b = (u8*)hipcGetBufferAddress(&p.data.recv_buffers[0]);
        const size_t bn = hipcGetBufferSize(&p.data.recv_buffers[0]);
        svcQueryMemory(&mi, &pi, g_client_b);
        g_lock_info[3] = mi.perm; g_lock_info[4] = mi.ipc_refcount; g_lock_info[5] = mi.attr;
        for (size_t i = 0; i < bn; ++i) b[i] = (u8)(i * 7 + 3);
        s32 idx = -1;
        const Result copy_ok = svcWaitSynchronization(&idx, &p.data.copy_handles[0], 1, 0);   // signaled by the client
        svcCloseHandle(p.data.copy_handles[0]);
        Handle we, re;
        svcCreateEvent(&we, &re);
        svcSignalEvent(we);
        svcCloseHandle(we);
        static const char back[16] = "reply-static-16";
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_send_statics = 1, .num_data_words = 5, .num_move_handles = 1});
        r.send_statics[0] = hipcMakeSendStatic(back, sizeof back, 0);
        r.move_handles[0] = re;
        r.data_words[0] = 0;
        r.data_words[1] = a_sum;
        r.data_words[2] = x_sum;
        r.data_words[3] = (u32)p.pid;
        r.data_words[4] = copy_ok;
    } else if (cmd == CmdIndexed) {
        // the X with index 1 went to the second receive entry
        const int ok = hipcGetStaticAddress(&p.data.send_statics[0]) == (void*)g_server_recv1 &&
                       memcmp(g_server_recv1, "indexed!", 8) == 0;
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 2});
        r.data_words[0] = 0;
        r.data_words[1] = ok;
    } else if (cmd == CmdXToMsg) {
        static const char five[5] = "hello";
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_send_statics = 1, .num_data_words = 1});
        r.send_statics[0] = hipcMakeSendStatic(five, 5, 0);
        r.data_words[0] = 0;
    } else if (cmd == CmdProcessHandle) {
        // hbloader's trick: the client's CUR_PROCESS copy handle arrives as a real handle; it goes back moved
        const Handle h = p.data.copy_handles[0];
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 1, .num_move_handles = 1});
        r.move_handles[0] = h;
        r.data_words[0] = 0;
    } else {   // CmdRaw / CmdQuit: echo the second word + 1
        const u32 v = p.meta.num_data_words > 1 ? p.data.data_words[1] : 0;
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 2});
        r.data_words[0] = 0;
        r.data_words[1] = v + 1;
    }
    Handle moved = INVALID_HANDLE;
    if (cmd == CmdEcho) moved = hipcParseResponse(tls_msg()).move_handles[0];
    s32 idx;
    const Result rc = svcReplyAndReceive(&idx, NULL, 0, session, 0);   // reply only: no handles, timeout 0
    if (session == g_extra) g_late_reply = rc;                          // the client closed first
    else if (rc != 0xEA01) say("P6 server-reply FAIL rc=0x%x\n", rc), ++g_fails;   // TimedOut after the reply
    if (cmd == CmdEcho) g_moved_close = svcCloseHandle(moved);         // gone: it moved to the client
}

static void server_main(void* arg) {
    (void)arg;
    Handle handles[4];
    for (;;) {
        s32 n = 0;
        handles[n++] = g_server_session;
        handles[n++] = g_port_server;
        if (g_accepted != INVALID_HANDLE) handles[n++] = g_accepted;
        if (g_extra != INVALID_HANDLE) handles[n++] = g_extra;
        prepare_receive();
        s32 idx = -1;
        Result rc = svcReplyAndReceive(&idx, handles, n, INVALID_HANDLE, UINT64_MAX);
        if (rc == 0xF601) {   // SessionClosed: the client of that session went away
            if (idx == 0) return;
            if (handles[idx] == g_accepted) { svcCloseHandle(g_accepted); g_accepted = INVALID_HANDLE; }
            else if (handles[idx] == g_extra) { svcCloseHandle(g_extra); g_extra = INVALID_HANDLE; g_extra_closed = 1; }
            ++g_closed_seen;
            continue;
        }
        if (rc != 0) { say("P6 server-wait FAIL rc=0x%x idx=%d\n", rc, idx); ++g_fails; return; }
        if (idx == 1) {   // a client connected to the named port
            rc = svcAcceptSession(&g_accepted, g_port_server);
            if (rc) { say("P6 accept FAIL rc=0x%x\n", rc); ++g_fails; }
            continue;
        }
        const Handle s = handles[idx];
        HipcParsedRequest p = hipcParseRequest(tls_msg());
        const u32 cmd = p.meta.num_data_words ? p.data.data_words[0] : 0;
        serve_one(s);
        if (cmd == CmdQuit && idx == 0) return;
    }
}

// ---- light IPC -------------------------------------------------------------------------------
static Result light_call(u32 svc_id, Handle h, u32 d[7]) {
    register u64 x0 __asm__("x0") = h;
    register u64 x1 __asm__("x1") = d[0], x2 __asm__("x2") = d[1], x3 __asm__("x3") = d[2], x4 __asm__("x4") = d[3];
    register u64 x5 __asm__("x5") = d[4], x6 __asm__("x6") = d[5], x7 __asm__("x7") = d[6];
    if (svc_id == 0x20)
        __asm__ volatile("svc 0x20" : "+r"(x0), "+r"(x1), "+r"(x2), "+r"(x3), "+r"(x4), "+r"(x5), "+r"(x6), "+r"(x7) : : "memory");
    else
        __asm__ volatile("svc 0x42" : "+r"(x0), "+r"(x1), "+r"(x2), "+r"(x3), "+r"(x4), "+r"(x5), "+r"(x6), "+r"(x7) : : "memory");
    d[0] = (u32)x1; d[1] = (u32)x2; d[2] = (u32)x3; d[3] = (u32)x4; d[4] = (u32)x5; d[5] = (u32)x6; d[6] = (u32)x7;
    return (Result)x0;
}
static Handle g_light_server;
static void light_server_main(void* arg) {
    (void)arg;
    u32 d[7] = {0};
    for (int round = 0; round < 3; ++round) {
        Result rc = light_call(0x42, g_light_server, d);   // round 0 receives; later rounds reply + receive
        if (rc == 0xF601) return;                          // the client closed
        if (rc) { say("P6 light-server FAIL rc=0x%x\n", rc); ++g_fails; return; }
        for (int i = 0; i < 7; ++i) d[i] = d[i] * 2 + 1;
        d[0] |= 0x80000000u;   // ReplyFlag on the next call
    }
}

// ---- a thread to pause ------------------------------------------------------------------------
static volatile u64 g_spin;
static volatile int g_stop;
static void spinner_main(void* arg) {
    (void)arg;
    while (!g_stop) g_spin++;
}

typedef u32 (*Fn)(void);

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    u64 pid = 0;
    svcGetProcessId(&pid, CUR_PROCESS_HANDLE);
    g_my_pid = pid;

    // ---- GetInfo ids added by P6.0 ----
    u64 v = 0;
    Result rc = svcGetInfo(&v, InfoType_IsApplication, CUR_PROCESS_HANDLE, 0);
    CHECK("getinfo-isapplication", rc == 0 && v == 0, "rc=0x%x v=%lu", rc, v);
    rc = svcGetInfo(&v, InfoType_FreeThreadCount, CUR_PROCESS_HANDLE, 0);
    CHECK("getinfo-freethreads", rc == 0 && v > 0, "rc=0x%x v=%lu", rc, v);
    rc = svcGetInfo(&v, InfoType_IdleTickCount, INVALID_HANDLE, UINT64_MAX);
    CHECK("getinfo-idleticks", rc == 0, "rc=0x%x", rc);
    rc = svcGetInfo(&v, InfoType_UserExceptionContextAddress, CUR_PROCESS_HANDLE, 0);
    CHECK("getinfo-plr", rc == 0 && v != 0 && *(volatile u64*)v == 0, "rc=0x%x v=0x%lx", rc, v);
    rc = svcGetInfo(&v, InfoType_IsSvcPermitted, INVALID_HANDLE, 0x36);
    CHECK("getinfo-svcpermitted", rc == 0 && v == 1, "rc=0x%x v=%lu", rc, v);
    Handle rl = INVALID_HANDLE;
    rc = svcGetInfo(&v, InfoType_ResourceLimit, INVALID_HANDLE, 0);
    rl = (Handle)v;
    s64 lim = 0, cur = 0;
    Result rc2 = svcGetResourceLimitLimitValue(&lim, rl, LimitableResource_Threads);
    Result rc3 = svcGetResourceLimitCurrentValue(&cur, rl, LimitableResource_Threads);
    CHECK("resource-limit", rc == 0 && rc2 == 0 && rc3 == 0 && lim > 0 && cur >= 1 && cur <= lim, "rc=0x%x/0x%x/0x%x lim=%ld cur=%ld", rc, rc2, rc3, lim, cur);
    svcCloseHandle(rl);
    rc = svcGetSystemInfo(&v, 0, INVALID_HANDLE, 0);
    CHECK("getsysteminfo", rc == 0 && v > 0, "rc=0x%x v=%lu", rc, v);

    rc = svcGetInfo(&v, InfoType_IsApplication, INVALID_HANDLE, 0);
    CHECK("getinfo-badhandle", rc == 0xE401, "rc=0x%x", rc);
    {   // CreateProcess: Horizon's checks, then no free process slot (one-process console)
        struct { char name[12]; u32 version; u64 program_id, code_address; s32 code_pages; u32 flags; Handle reslimit; s32 sys_pages; } pp;
        memset(&pp, 0, sizeof pp);
        memcpy(pp.name, "child", 5);
        pp.code_address = 0x8000000;
        pp.code_pages = 16;
        pp.flags = 1 | (3 << 1);   // 64-bit, 39-bit address space
        Handle ph = 0;
        Result a = svcCreateProcess(&ph, &pp, NULL, 0);
        pp.flags = 1 << 30;
        Result b = svcCreateProcess(&ph, &pp, NULL, 0);
        pp.flags = 1 | (3 << 1);
        pp.code_address = 0x8001000;
        Result c = svcCreateProcess(&ph, &pp, NULL, 0);
        CHECK("create-process", a == 0xCE01 && b == 0xF001 && c == 0xCC01, "a=0x%x b=0x%x c=0x%x", a, b, c);
    }
    {   // IdleTickCount: a busy core is not idle
        u64 i0 = 0, i1 = 0;
        svcGetInfo(&i0, InfoType_IdleTickCount, INVALID_HANDLE, UINT64_MAX);
        const u64 t0 = armGetSystemTick();
        volatile u64 spin = 0;
        for (u64 i = 0; i < 20000000; ++i) spin += i;
        const u64 t1 = armGetSystemTick();
        svcGetInfo(&i1, InfoType_IdleTickCount, INVALID_HANDLE, UINT64_MAX);
        CHECK("idle-ticks-busy", t1 > t0 && (i1 - i0) < (t1 - t0) / 2, "idle=%lu elapsed=%lu", i1 - i0, t1 - t0);
    }

    // ---- retail answers ----
    s32 n = 0; u64 ids[4];
    rc = svcGetProcessList(&n, ids, 4);
    CHECK("retail-processlist", rc == 0x4201, "rc=0x%x", rc);
    Handle dbg = 0;
    rc = svcDebugActiveProcess(&dbg, pid);
    CHECK("retail-debug", rc == 0x4201, "rc=0x%x", rc);
    LastThreadContext ltc; u64 tid = 0;
    rc = svcGetDebugFutureThreadInfo(&ltc, &tid, INVALID_HANDLE, 0);
    CHECK("retail-futurethread", rc == 0x10201, "rc=0x%x", rc);
    SecmonArgs sm = {{0xC3000401, 1, 2, 3, 4, 5, 6, 7}};
    svcCallSecureMonitor(&sm);
    CHECK("smc-frontier", sm.X[0] == 1 && sm.X[1] == 1, "x0=0x%lx", sm.X[0]);
    rc = svcCreateIoPool(&dbg, 0);
    CHECK("io-pool", rc == 0xF201, "rc=0x%x", rc);
    rc = svcCreateInterruptEvent(&dbg, 32, 0);
    CHECK("interrupt", rc == 0xF201, "rc=0x%x", rc);
    rc = svcCreateDeviceAddressSpace(&dbg, 0, 0x100000000ull);
    CHECK("device-as", rc == 0x4201, "rc=0x%x", rc);
    s64 st = 0;   // libnx stores w1 only
    rc = svcGetProcessInfo(&st, CUR_PROCESS_HANDLE, ProcessInfoType_ProcessState);
    CHECK("process-info", rc == 0 && st == 2, "rc=0x%x st=%ld", rc, st);

    // ---- physical / insecure memory ----
    static u8 heapish[0x2000] __attribute__((aligned(0x1000)));
    heapish[0] = 1;
    PhysicalMemoryInfo pmi = {0};
    rc = svcQueryPhysicalAddress(&pmi, (u64)heapish);
    CHECK("query-physical", rc == 0 && pmi.physical_address >= 0x80000000ull && pmi.virtual_address <= (u64)heapish &&
                                (u64)heapish < pmi.virtual_address + pmi.size, "rc=0x%x pa=0x%lx", rc, pmi.physical_address);
    virtmemLock();
    void* ins = virtmemFindAslr(0x4000, 0x1000);
    rc = svcMapInsecurePhysicalMemory(ins, 0x4000);
    virtmemUnlock();
    if (rc == 0) {
        ((volatile u32*)ins)[0] = 0x12345678;
        MemoryInfo mi; u32 pi;
        svcQueryMemory(&mi, &pi, (u64)ins);
        const u32 back = ((volatile u32*)ins)[0];
        Result u = svcUnmapInsecurePhysicalMemory(ins, 0x4000);
        CHECK("insecure-memory", back == 0x12345678 && mi.type == 0x17 && u == 0, "type=0x%x u=0x%x", mi.type, u);
    } else {
        CHECK("insecure-memory", 0, "rc=0x%x", rc);
    }

    // ---- shared memory ----
    Handle shm;
    rc = svcCreateSharedMemory(&shm, 0x2000, Perm_Rw, Perm_R);
    if (rc == 0) {
        virtmemLock();
        void* a = virtmemFindAslr(0x2000, 0x1000);
        Result m = svcMapSharedMemory(shm, a, 0x2000, Perm_Rw);
        virtmemUnlock();
        if (m == 0) ((volatile u32*)a)[100] = 0xCAFE;
        const u32 got = m == 0 ? ((volatile u32*)a)[100] : 0;
        Result um = m == 0 ? svcUnmapSharedMemory(shm, a, 0x2000) : m;
        svcCloseHandle(shm);
        CHECK("shared-memory", m == 0 && got == 0xCAFE && um == 0, "map=0x%x unmap=0x%x", m, um);
    } else {
        CHECK("shared-memory", 0, "rc=0x%x", rc);
    }

    // ---- code memory through libnx's JIT ----
    Jit jit;
    rc = jitCreate(&jit, 0x1000);
    if (rc == 0) {
        u32* w = (u32*)jitGetRwAddr(&jit);
        w[0] = 0x52800540;   // mov w0, #42
        w[1] = 0xD65F03C0;   // ret
        Result t = jitTransitionToExecutable(&jit);
        u32 r = t == 0 ? ((Fn)jitGetRxAddr(&jit))() : 0;
        jitClose(&jit);
        CHECK("jit-codememory", t == 0 && r == 42, "t=0x%x r=%u", t, r);
    } else {
        CHECK("jit-codememory", 0, "rc=0x%x", rc);
    }

    // ---- thread activity / context ----
    Thread sp;
    rc = threadCreate(&sp, spinner_main, NULL, NULL, 0x4000, 0x2C, 1);   // its own core: it never yields
    if (rc == 0 && threadStart(&sp) == 0) {
        while (g_spin < 100) svcSleepThread(1000);
        Result p = svcSetThreadActivity(sp.handle, ThreadActivity_Paused);
        const u64 s1 = g_spin;
        svcSleepThread(1000000);
        const u64 s2 = g_spin;
        ThreadContext tc;
        memset(&tc, 0, sizeof tc);
        Result c = svcGetThreadContext3(&tc, sp.handle);
        Result self_busy = svcGetThreadContext3(&tc, CUR_THREAD_HANDLE);
        Result badptr = svcGetThreadContext3((ThreadContext*)0x10, sp.handle);
        Result badself = svcGetThreadContext3((ThreadContext*)0x10, CUR_THREAD_HANDLE);   // the pointer is checked first
        Result rr = svcSetThreadActivity(sp.handle, ThreadActivity_Runnable);
        g_stop = 1;
        threadWaitForExit(&sp);
        threadClose(&sp);
        CHECK("thread-activity", p == 0 && s1 == s2 && c == 0 && tc.pc.x != 0 && self_busy == 0xF401 && rr == 0 && badptr == 0xE601 && badself == 0xE601,
              "p=0x%x s1=%lu s2=%lu c=0x%x pc=0x%lx busy=0x%x rr=0x%x bad=0x%x", p, s1, s2, c, tc.pc.x, self_busy, rr, badptr);
    } else {
        CHECK("thread-activity", 0, "rc=0x%x", rc);
    }

    // ---- guest IPC: a server thread ----
    Handle client;
    rc = svcCreateSession(&g_server_session, &client, 0, 0);
    Result rp = svcManageNamedPort(&g_port_server, "p6:port", 2);
    CHECK("create-session-port", rc == 0 && rp == 0, "rc=0x%x rp=0x%x", rc, rp);
    Handle extra_client;
    svcCreateSession(&g_extra, &extra_client, 0, 0);
    Thread srv;
    threadCreate(&srv, server_main, NULL, NULL, 0x8000, 0x2C, -2);
    threadStart(&srv);

    {   // CmdEcho: pid, a copy handle, an X static, an A and a B buffer, a C receive buffer
        static u8 abuf[0x2200] __attribute__((aligned(0x1000))), bbuf[0x2600] __attribute__((aligned(0x1000))), xdata[24], creply[0x40];
        for (size_t i = 0; i < sizeof abuf; ++i) abuf[i] = (u8)i;
        for (size_t i = 0; i < sizeof xdata; ++i) xdata[i] = (u8)(i + 1);
        u32 a_expect = 0, x_expect = 0;
        const size_t aoff = 0x123, alen = 0x2000, boff = 0x45, blen = 0x2400;   // each covers a whole page
        for (size_t i = 0; i < alen; ++i) a_expect += abuf[aoff + i];
        for (size_t i = 0; i < sizeof xdata; ++i) x_expect += xdata[i];
        Handle we, re;
        svcCreateEvent(&we, &re);
        svcSignalEvent(we);
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_send_statics = 1, .num_send_buffers = 1,
                                                                   .num_recv_buffers = 1, .num_data_words = 1,
                                                                   .num_recv_statics = 1, .send_pid = 1, .num_copy_handles = 1});
        r.send_statics[0] = hipcMakeSendStatic(xdata, sizeof xdata, 0);
        r.send_buffers[0] = hipcMakeBuffer(abuf + aoff, alen, HipcBufferMode_Normal);
        r.recv_buffers[0] = hipcMakeBuffer(bbuf + boff, blen, HipcBufferMode_Normal);
        r.recv_list[0] = hipcMakeRecvStatic(creply, sizeof creply);
        r.copy_handles[0] = re;
        r.data_words[0] = CmdEcho;
        g_client_a = ((u64)(abuf + aoff) + 0xFFF) & ~0xFFFull;
        g_client_b = ((u64)(bbuf + boff) + 0xFFF) & ~0xFFFull;
        rc = svcSendSyncRequest(client);
        HipcResponse resp = hipcParseResponse(tls_msg());
        int b_ok = 1;
        for (size_t i = 0; i < blen; ++i) if (bbuf[boff + i] != (u8)(i * 7 + 3)) { b_ok = 0; break; }
        const int b_untouched = bbuf[boff - 1] == 0 && bbuf[boff + blen] == 0;
        s32 idx = -1;
        Result moved = resp.num_move_handles == 1 ? svcWaitSynchronization(&idx, &resp.move_handles[0], 1, 0) : 1;
        if (resp.num_move_handles == 1) svcCloseHandle(resp.move_handles[0]);
        const int x_ok = memcmp(creply, "reply-static-16", 16) == 0 && resp.num_statics == 1;
        CHECK("ipc-echo", rc == 0 && resp.num_data_words == 5 && resp.data_words[0] == 0 && resp.data_words[1] == a_expect &&
                              resp.data_words[2] == x_expect && resp.data_words[3] == (u32)pid && resp.data_words[4] == 0 &&
                              b_ok && b_untouched && moved == 0 && x_ok,
              "rc=0x%x words=%u a=%u/%u x=%u/%u pid=%u copy=0x%x b=%d/%d moved=0x%x xs=%d", rc, resp.num_data_words,
              resp.data_words[1], a_expect, resp.data_words[2], x_expect, resp.data_words[3], resp.data_words[4], b_ok,
              b_untouched, moved, x_ok);
        // the server closed its copy of `re`: the event lives on through the client's handles
        svcCloseHandle(we);
        Result still = svcWaitSynchronization(&idx, &re, 1, 0);
        svcCloseHandle(re);
        MemoryInfo mi; u32 pi;
        svcQueryMemory(&mi, &pi, ((u64)(abuf + aoff) + 0xFFF) & ~0xFFFull);
        CHECK("ipc-locks", still == 0 && g_lock_info[0] == Perm_R && g_lock_info[1] == 1 && g_lock_info[2] == 2 &&
                               g_lock_info[3] == 0 && g_lock_info[4] == 1 && g_lock_info[5] == 2 &&
                               mi.perm == Perm_Rw && mi.ipc_refcount == 0 && mi.attr == 0,
              "still=0x%x a=%u/%u/%u b=%u/%u/%u after=%u/%u/%u", still, g_lock_info[0], g_lock_info[1], g_lock_info[2],
              g_lock_info[3], g_lock_info[4], g_lock_info[5], mi.perm, mi.ipc_refcount, mi.attr);
    }

    Handle own = INVALID_HANDLE;
    {   // CmdProcessHandle: hbloader's way to a real handle to the own process
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 1, .num_copy_handles = 1});
        r.copy_handles[0] = CUR_PROCESS_HANDLE;
        r.data_words[0] = CmdProcessHandle;
        rc = svcSendSyncRequest(client);
        HipcResponse resp = hipcParseResponse(tls_msg());
        own = resp.num_move_handles == 1 ? resp.move_handles[0] : INVALID_HANDLE;
        u64 opid = 0;
        Result g = svcGetProcessId(&opid, own);
        CHECK("ipc-process-handle", rc == 0 && own != INVALID_HANDLE && g == 0 && opid == pid, "rc=0x%x own=0x%x g=0x%x", rc, own, g);
        CHECK("ipc-move-handle", g_moved_close == 0xE401, "close=0x%x", g_moved_close);
    }

    {   // an X with index 1 goes to the server's second receive entry
        static const char ix[8] = {'i', 'n', 'd', 'e', 'x', 'e', 'd', '!'};
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_send_statics = 1, .num_data_words = 1});
        r.send_statics[0] = hipcMakeSendStatic(ix, sizeof ix, 1);
        r.data_words[0] = CmdIndexed;
        rc = svcSendSyncRequest(client);
        HipcResponse resp = hipcParseResponse(tls_msg());
        CHECK("ipc-x-indexed", rc == 0 && resp.data_words[1] == 1, "rc=0x%x ok=%u", rc, resp.data_words[1]);
    }
    {   // receive mode ToMessageBuffer: the reply's X lands in the message buffer, 16-aligned
        hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 1}).data_words[0] = CmdXToMsg;
        ((HipcHeader*)tls_msg())->recv_static_mode = 1;
        rc = svcSendSyncRequest(client);
        HipcResponse resp = hipcParseResponse(tls_msg());
        const u8* at = resp.num_statics == 1 ? (const u8*)hipcGetStaticAddress(&resp.statics[0]) : NULL;
        CHECK("ipc-x-to-message", rc == 0 && at == (const u8*)tls_msg() + 32 && memcmp(at, "hello", 5) == 0,
              "rc=0x%x at=%p tls=%p", rc, at, tls_msg());
    }

    {   // MapProcessMemory with that handle: the module's own .bss (AliasCodeData: CanMapProcess)
        static u8 src[0x2000] __attribute__((aligned(0x1000)));
        memset(src, 0x5A, sizeof src);
        virtmemLock();
        void* dst = virtmemFindAslr(0x2000, 0x1000);
        Result m = svcMapProcessMemory(dst, own, (u64)src, 0x2000);
        virtmemUnlock();
        MemoryInfo mi = {0}; u32 pi;
        if (m == 0) svcQueryMemory(&mi, &pi, (u64)dst);
        u8 seen = m == 0 ? ((volatile u8*)dst)[0x1FFF] : 0;
        if (m == 0) ((volatile u8*)dst)[0] = 0xA5;
        const u8 back = ((volatile u8*)src)[0];
        Result pseudo = svcMapProcessMemory(dst, CUR_PROCESS_HANDLE, (u64)src, 0x2000);   // no pseudo-handles
        Result um = m == 0 ? svcUnmapProcessMemory(dst, own, (u64)src, 0x2000) : m;
        CHECK("process-memory", m == 0 && mi.type == 0x0F && seen == 0x5A && back == 0xA5 && pseudo == 0xE401 && um == 0,
              "m=0x%x type=0x%x seen=0x%x back=0x%x pseudo=0x%x um=0x%x", m, mi.type, seen, back, pseudo, um);
    }

    {   // SendSyncRequestWithUserBuffer and SendAsyncRequestWithUserBuffer
        u32* ub = (u32*)aligned_alloc(0x1000, 0x1000);
        memset(ub, 0, 0x1000);
        HipcRequest r = hipcMakeRequest(ub, (HipcMetadata){.num_data_words = 2});
        r.data_words[0] = CmdRaw;
        r.data_words[1] = 41;
        rc = svcSendSyncRequestWithUserBuffer(ub, 0x1000, client);
        HipcResponse resp = hipcParseResponse(ub);
        CHECK("ipc-user-buffer", rc == 0 && resp.num_data_words == 2 && resp.data_words[1] == 42, "rc=0x%x v=%u", rc, resp.data_words[1]);
        memset(ub, 0, 0x1000);
        r = hipcMakeRequest(ub, (HipcMetadata){.num_data_words = 2});
        r.data_words[0] = CmdRaw;
        r.data_words[1] = 99;
        Handle ev = INVALID_HANDLE;
        rc = svcSendAsyncRequestWithUserBuffer(&ev, ub, 0x1000, client);
        s32 idx = -1;
        Result w = rc == 0 ? svcWaitSynchronization(&idx, &ev, 1, 1000000000ull) : rc;
        resp = hipcParseResponse(ub);
        CHECK("ipc-async", rc == 0 && w == 0 && resp.data_words[1] == 100, "rc=0x%x w=0x%x v=%u", rc, w, resp.data_words[1]);
        if (ev != INVALID_HANDLE) svcCloseHandle(ev);
        free(ub);
    }

    {   // a named port served by the same thread
        Handle pc = INVALID_HANDLE;
        rc = svcConnectToNamedPort(&pc, "p6:port");
        Result s = 1;
        u32 got = 0;
        if (rc == 0) {
            HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 2});
            r.data_words[0] = CmdRaw;
            r.data_words[1] = 7;
            s = svcSendSyncRequest(pc);
            got = hipcParseResponse(tls_msg()).data_words[1];
            svcCloseHandle(pc);
        }
        CHECK("named-port", rc == 0 && s == 0 && got == 8, "rc=0x%x s=0x%x got=%u", rc, s, got);
    }

    {   // a port's session limit, and a name taken by an HLE port
        Handle ps, c1 = 0, c2 = 0, c3 = 0, sh = 0;
        Result m = svcManageNamedPort(&ps, "p6:lim", 2);
        Result a = svcConnectToNamedPort(&c1, "p6:lim"), b = svcConnectToNamedPort(&c2, "p6:lim"), d = svcConnectToNamedPort(&c3, "p6:lim");
        Result taken = svcManageNamedPort(&sh, "sm:", 1);
        if (c1) svcCloseHandle(c1);
        if (c2) svcCloseHandle(c2);
        // the server ends wait in the port's queue (the port holds them): the slots stay taken
        Result after = svcConnectToNamedPort(&c3, "p6:lim");
        if (after == 0) svcCloseHandle(c3);
        svcCloseHandle(ps);
        svcManageNamedPort(&sh, "p6:lim", 0);
        CHECK("port-limit", m == 0 && a == 0 && b == 0 && d == 0xE01 && taken == 0xFA01 && after == 0xE01,
              "m=0x%x a=0x%x b=0x%x d=0x%x taken=0x%x after=0x%x", m, a, b, d, taken, after);
    }

    {   // the client goes away while the server holds its request
        u32* ub = (u32*)aligned_alloc(0x1000, 0x1000);
        memset(ub, 0, 0x1000);
        HipcRequest r = hipcMakeRequest(ub, (HipcMetadata){.num_data_words = 2});
        r.data_words[0] = CmdRaw;
        r.data_words[1] = 5;
        Handle ev = INVALID_HANDLE;
        svcSleepThread(10000000);   // the server is back in its wait: it takes the request at once
        rc = svcSendAsyncRequestWithUserBuffer(&ev, ub, 0x1000, extra_client);
        svcCloseHandle(extra_client);
        s32 idx = -1;
        Result w = svcWaitSynchronization(&idx, &ev, 1, 1000000000ull);
        for (int i = 0; i < 100 && !g_extra_closed; ++i) svcSleepThread(1000000);
        CHECK("ipc-late-reply", rc == 0 && w == 0 && g_late_reply == 0xF601 && ub[2] == 0xF601 && g_extra_closed,
              "rc=0x%x w=0x%x late=0x%x word2=0x%x closed=%d", rc, w, g_late_reply, ub[2], g_extra_closed);
        svcCloseHandle(ev);
        free(ub);
    }

    {   // ReplyAndReceiveWithUserBuffer that times out: its buffer is unlocked again
        Handle s, c;
        svcCreateSession(&s, &c, 0, 0);
        u8* ub = (u8*)aligned_alloc(0x1000, 0x1000);
        memset(ub, 0, 0x1000);
        s32 idx = -1;
        Result w = svcReplyAndReceiveWithUserBuffer(&idx, ub, 0x1000, &s, 1, INVALID_HANDLE, 1000000);
        MemoryInfo mi; u32 pi;
        svcQueryMemory(&mi, &pi, (u64)ub);
        ub[0] = 1;
        CHECK("ipc-user-buffer-timeout", w == 0xEA01 && mi.attr == 0 && mi.perm == Perm_Rw, "w=0x%x attr=%u perm=%u", w, mi.attr, mi.perm);
        svcCloseHandle(c);
        svcCloseHandle(s);
        free(ub);
    }

    {   // SendSyncRequestWithUserBuffer to an HLE service (sm: RegisterClient)
        u8* ub = (u8*)aligned_alloc(0x1000, 0x1000);
        memset(ub, 0, 0x1000);
        CmifRequest q = cmifMakeRequest(ub, (CmifRequestFormat){.request_id = 0, .data_size = 8, .send_pid = 1});
        *(u64*)q.data = 0;
        Result w = svcSendSyncRequestWithUserBuffer(ub, 0x1000, smGetServiceSession()->session);
        MemoryInfo mi; u32 pi;
        svcQueryMemory(&mi, &pi, (u64)ub);
        CHECK("hle-user-buffer", w == 0 && mi.attr == 0 && mi.perm == Perm_Rw, "w=0x%x attr=%u perm=%u", w, mi.attr, mi.perm);
        free(ub);
    }

    {   // light IPC
        Handle lc;
        rc = svcCreateSession(&g_light_server, &lc, 1, 0);
        Thread lt;
        threadCreate(&lt, light_server_main, NULL, NULL, 0x4000, 0x2C, -2);
        threadStart(&lt);
        u32 d[7] = {1, 2, 3, 4, 5, 6, 7};
        Result a = light_call(0x20, lc, d);
        const int ok1 = d[0] == (3u | 0x80000000u) && d[6] == 15;
        u32 e[7] = {10, 0, 0, 0, 0, 0, 1};
        Result b = light_call(0x20, lc, e);
        const int ok2 = e[0] == (21u | 0x80000000u) && e[6] == 3;
        svcCloseHandle(lc);
        threadWaitForExit(&lt);
        threadClose(&lt);
        svcCloseHandle(g_light_server);
        CHECK("light-ipc", rc == 0 && a == 0 && b == 0 && ok1 && ok2, "rc=0x%x a=0x%x b=0x%x d0=0x%x d6=%u e0=0x%x", rc, a, b, d[0], d[6], e[0]);
    }

    {   // the server goes away: CmdQuit, then requests fail with SessionClosed
        HipcRequest r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 2});
        r.data_words[0] = CmdQuit;
        r.data_words[1] = 0;
        rc = svcSendSyncRequest(client);
        threadWaitForExit(&srv);
        threadClose(&srv);
        svcCloseHandle(g_server_session);
        svcCloseHandle(g_port_server);
        r = hipcMakeRequest(tls_msg(), (HipcMetadata){.num_data_words = 1});
        r.data_words[0] = CmdRaw;
        Result closed = svcSendSyncRequest(client);
        svcCloseHandle(client);
        Handle again;
        Result gone = svcConnectToNamedPort(&again, "p6:port");
        CHECK("ipc-close", rc == 0 && closed == 0xF601 && gone != 0, "rc=0x%x closed=0x%x gone=0x%x", rc, closed, gone);
    }
    if (own != INVALID_HANDLE) svcCloseHandle(own);

    say("P6 DONE fails=%d\n", g_fails);
    return 0;
}
