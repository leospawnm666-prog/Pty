#!/usr/bin/env bash
# Print shader ISA/dispatch coverage report.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="${ROOT}/build/print_shader_coverage"
if [[ ! -x "$BIN" ]]; then
  if [[ -d "${ROOT}/build" ]]; then
    cmake --build "${ROOT}/build" --target print_shader_coverage -j"$(nproc 2>/dev/null || echo 2)"
  else
    echo "Configure first: cmake -S \"$ROOT\" -B \"$ROOT/build\" && cmake --build \"$ROOT/build\" --target print_shader_coverage" >&2
    exit 2
  fi
fi
exec "$BIN"
