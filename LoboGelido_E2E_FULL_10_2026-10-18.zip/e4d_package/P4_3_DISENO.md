# P4.3 — Diseño: texturas e imágenes en el recompilador Maxwell

Estado: **implementado** (continuación del plan P4 aprobado: P4.3 es la fase siguiente de
`P4_DISENO.md` §6, tras P4.2). Resultados, desviaciones y fallos de herramientas encontrados:
`P4_3_INFORME.md`.

## 1. Objetivo y metas
P4.2 dejó las seis etapas traducidas. Sin texturas, casi ningún *shader* de juego es utilizable;
P4.3 añade el muestreo y las imágenes:

| Meta | P4.2 | P4.3 |
|---|---|---|
| M1 — traducción | 184/296 | + las 13 codificaciones de textura e imagen (`TEX`, `TEXS`, `TLD`, `TLDS`, `TLD4`, `TLD4S`, `TXQ`, `TMML`, `TXD`, `SULD`, `SUST`, `SUATOM`, `SURED`), en sus formas *bound* y *bindless* rastreable |
| M2 — corpus | 50 *compute* + 25 tuberías | + corpus de muestreo e imágenes (T3-T), A = B al 100 % en el oráculo |
| M4 — SPIR-V válido | 100 % | 100 % |
| T2 — instrucciones nuevas | — | T2-T: cada forma (destino, máscara, objetivo, LOD, *offset*, profundidad, *gather*, consultas, imágenes crudas y con formato, atómicas) con resultado exacto conocido |

**Hito H9:** las 13 codificaciones traducidas (salvo las formas listadas en §6 con error
explícito), T3-T al 100 % en lavapipe, M4 al 100 % y T2-T de todas las formas.

## 2. Qué emiten los compiladores (comprobado con uam y desensamblando)
### 2.1 El *handle*
- En deko3d/NVN la textura *bound* se nombra con un inmediato de 13 bits (`U13_36`): la palabra
  del *constbuffer* del *driver* (banco 0) donde está el *handle* de 32 bits
  (índice TIC en los bits 0–19, índice TSC en los bits 20–31).
- Disposición de deko3d (`resbase` por etapa, la de P4.2): texturas en
  `c0[resbase + 4·binding]`, imágenes en `c0[resbase + 0x80 + 4·binding]`.
  Ej.: FS (`resbase` 0x690), binding 0 → inmediato 0x1a4.
- **Bindless** (`.B`): el *handle* llega en un registro. NVN lo carga antes con `LDC`/`MOV c[]`.

### 2.2 Instrucciones (semántica: emisor y bajadas GM107 de Mesa nv50_ir, MIT)
| Instrucción | Qué hace | Fuentes |
|---|---|---|
| `TEX` | muestreo; LOD implícito, `LZ` (0), `LB` (sesgo), `LL` (explícito); `AOFFI`; `DC` (comparación) | vector R8: [capa u16] coordenadas; vector R20: [*handle* bindless] [LOD/sesgo] [*offset*] [referencia] |
| `TLD` | lectura de texel entera (`texelFetch`), `LZ`/`LL`, `MS`, `AOFFI` | igual, coordenadas enteras |
| `TLD4` | *gather* (componente en un campo), `AOFFI`/`PTP` (4 *offsets*), `DC` | igual; *offsets* de 8 bits por componente |
| `TXD` | gradientes explícitos | R8: [*handle*] coordenadas [capa + *offset* en los 16 bits altos]; R20: dx/dy intercalados |
| `TMML` | `textureQueryLod` | coordenadas; resultado en punto fijo 8.8: comp 0 = LOD calculado (s16), comp 1 = LOD accedido (u16) |
| `TXQ` | consultas: 1 dimensiones (w, h, d/capas, niveles), 2 tipo, 0x12 LOD… | R8 = nivel |
| `TEXS` / `TLDS` / `TLD4S` | formas escalares compactas: objetivo y máscara codificados en tablas (`getTEXSTarget`, `getTLDSTarget`, `getTEXSMask`), dos destinos (R0, R28) y dos fuentes (R8, R20) de 1 o 2 registros | según el número de fuentes (§4.2) |
| `SULD.D` / `SUST.D` | lectura/escritura **cruda** de imagen (u8…b128) | R8: coordenadas [capa] |
| `SULD.P` / `SUST.P` | lectura/escritura **con formato** (máscara RGBA) | igual |
| `SUATOM` / `SURED` | atómicas de imagen (con y sin resultado), `CAS` | igual + valor(es) |

- uam escribe las imágenes con formato declarado (`rgba8`) como `SULD.D b32` + desempaquetado
  aritmético, y `SUST.P`: un mismo *shader* mezcla acceso crudo y con formato a la misma imagen.
- Las coordenadas de cubo llegan ya normalizadas (división por el máximo valor absoluto).

## 3. Decisiones
| # | Decisión | Recomendación |
|---|---|---|
| D-P4.3-1 | **Modelo de recursos** | Un descriptor por **desplazamiento de *handle*** (banco, offset) usado. Textura: *combined image sampler* (TIC + TSC del mismo *handle*). El tipo SPIR-V sale de la instrucción (dimensión, *array*, sombra, MS), el **tipo de componente** (float/sint/uint) lo da quien llama en `TextureState` (en P5, del formato de la TIC). `translate()` devuelve la lista (offset → *binding*, tipo) para que P5 lea el *handle* en cada dibujo y cree vista y *sampler*. |
| D-P4.3-2 | **Bindless** | Si el registro del *handle* se rastrea (dentro del bloque) hasta una lectura de *constbuffer* con dirección constante, se trata como *bound* con ese (banco, offset). Si no, error explícito (la indexación de descriptores es de P4.4). |
| D-P4.3-3 | ***Offsets*** | Vulkan solo admite *offset* no constante en *gather*. `AOFFI` y los *offsets* de `TLD4` se rastrean hasta un inmediato (`MOV32I`/`MOV` inmediato en el bloque) → `ConstOffset(s)`. Si no son constantes: `TLD4` usa `Offset` (`ImageGatherExtended`); el resto, error explícito. |
| D-P4.3-4 | **LOD implícito fuera del FS** | Como el *hardware* (sin derivadas): LOD explícito 0 (+ sesgo si `LB`). |
| D-P4.3-5 | **Imágenes** | Un descriptor por (offset, clase de acceso): **crudo** → imagen `uint` del formato del tamaño del acceso (`R8ui`…`RGBA32ui`; P5 crea esa vista de la superficie); **con formato** → el formato de `ImageState` si se da, si no `Unknown` (capacidades `StorageImage{Read,Write}WithoutFormat`); **atómicas** → `R32ui`/`R32i`. 64 bits y f32: P4.4. |
| D-P4.3-6 | **Oráculo y corpus** | lavapipe y SwiftShader (P4.2). Corpus T3-T de muestreo en VS+FS (derivadas implícitas) y *compute*/VS (LOD explícito), con texturas generadas (patrón determinista, varios niveles, capas, cubo, 3D, profundidad) y *samplers* `nearest`/`linear`/`clamp`/`repeat`/comparación; imágenes en *compute*. |
| D-P4.3-7 | **Consultas** | `TXQ` dimensiones → `OpImageQuerySizeLod` + `OpImageQueryLevels`; `TMML` → `OpImageQueryLod` convertido a punto fijo 8.8 (s16/u16), que es lo que el código del compilador espera. Otras consultas de `TXQ` (tipo, filtro, *wrap*, borde): error explícito (P4.4). |

## 4. Traducción
### 4.1 Fuentes de `TEX`/`TLD`/`TLD4`/`TMML`
- **Vector R8:** las primeras `argc − ms` fuentes, con `argc` de la tabla de objetivos de nv50_ir
  (1D 1, 2D 2, 3D 3, cubo 3, 2D *array* 3, cubo *array* 4…). En los *arrays*, la capa (u16) va
  **primero**.
- **Vector R20:** el resto, en orden: [*handle* bindless], [muestra MS], [LOD/sesgo], [*offset*],
  [referencia de profundidad].
- **Destinos:** las componentes de la máscara (bits 31–34), consecutivas desde R0.

### 4.2 Formas escalares
- **Objetivo:** el campo de 4 bits (`TEXS`: 1D-LZ, 2D, 2D-LZ, 2D-LL, sombra 2D, 2D *array*, 3D,
  cubo…; `TLDS`: 1D, 2D-LZ, 2D con *offset*, 2D-LL, MS, 3D, 2D *array*).
- **Fuentes:**

  | Número | R8 | R20 |
  |---|---|---|
  | 1 | s0 | — |
  | 2 | s0 | s1 |
  | 3 | (s0, s1) | s2 |
  | 4 | (s0, s1) | (s2, s3) |

  Caso especial: `TLDS` 2D *array* va R8 = capa, R20 = (x, y).
- **Destinos:** la máscara de 3 bits y si R28 es `RZ` dan las componentes. Se escriben en R0,
  R0+1, R28, R28+1.

### 4.3 SPIR-V
- **Texturas:** `OpTypeImage` + `OpTypeSampledImage`, una variable `UniformConstant` por
  descriptor.
- **Muestreo:**
  - `OpImageSample{Implicit,Explicit}Lod` (FS) y la versión `Dref` para sombra;
  - `OpImageFetch` (`TLD`, con `Sample` en MS);
  - `OpImage{Dref}Gather` (`TLD4`, con `ConstOffsets` si `PTP`);
  - `Grad` (`TXD`).
- **Imágenes:** `OpImageRead`/`OpImageWrite`/`OpImageTexelPointer` + `OpAtomic*`.
- **Resultados:** vector de 4; se escriben las componentes de la máscara. Sombra → 1 componente.

## 5. Pruebas
### 5.1 T3-T — corpus diferencial
- **Qué:** GLSL propio con texturas.
- **Caminos:** A (uam → traductor) y B (glslang), con las mismas texturas y *samplers*.
- **Configuración:** el *harness* crea las texturas y *samplers* a partir de comentarios del
  *shader* (formato, tamaño, niveles, capas, tipo, filtro, modo de direccionamiento, comparación).
- **Correspondencia:** cada *binding* GLSL corresponde al offset del *handle* que el traductor
  devuelve.
- **Comparación:** imagen, profundidad y SSBO, como T3/T3-G.
- **Oráculos:** T3-T solo en lavapipe. SwiftShader se excluye de T3-T porque corrompe su propio
  *heap* al destruir *pipelines* de *compute* con *offsets* de texel. Lo reproduce un *shader*
  glslang mínimo con `texelFetchOffset` + `textureLodOffset`, sin el traductor. T2-T corre en
  los dos oráculos, con exclusiones documentadas por fallo conocido del oráculo (ver
  `P4_3_INFORME.md` §4); cada caso queda verificado por al menos uno.

### 5.2 T2-T — instrucciones nuevas
- **Qué:** programas Maxwell ensamblados con `envyas` (o palabras crudas cuando `envyas` no sabe).
- **Texturas:** contenido "dirección = valor" (cada texel guarda sus propias coordenadas, nivel y
  capa, en RGBA32UI/F) para que el resultado exacto sea conocido.
- **Cobertura:** cada forma de cada instrucción; las imágenes, crudas y con formato.

### 5.3 Matriz
- La de siempre: *host*, JIT, ASan, TSan, descarga de Dynarmic, compilación Android, ARM64.
- Mutación de lo nuevo.
- `spirv-val` de todo.

## 6. Fuera de P4.3 (error explícito)
| Forma | Fase |
|---|---|
| *Bindless* no rastreable (*handle* calculado), indexación dinámica de descriptores | P4.4 |
| *Offset* no constante fuera de `TLD4` | P4.4 |
| `TXQ` distinto de dimensiones/niveles; `TXA`; `TLD.CL`; `TEX .LBA/.LLA` | P4.4 |
| Atómicas de imagen de 64 bits o f32; `SULD`/`SUST` de *buffer* (1D *buffer*) | P4.4 |
| Texturas de *buffer* (`samplerBuffer`) | P4.4 |
| FP16 (`.F16` de las formas escalares, SM60) | no aplica a Tegra X1 |

## 7. Matriz de riesgos
| # | Riesgo | P | I | Mitigación | Detección |
|---|---|---|---|---|---|
| R1 | Disposición de fuentes/destinos mal interpretada (sobre todo formas escalares) | A | A | Tablas de Mesa; T2-T con resultado exacto por forma; contraste con el código real de uam | T2-T, T3-T |
| R2 | El tipo de componente o formato no está en la instrucción | A | M | `TextureState`/`ImageState` explícitos, como `GraphicsState` en P4.2; por defecto float | E1, T3-T |
| R3 | Diferencias de filtrado entre oráculos (bilineal, LOD, cubo) | M | M | Comparar A con B en el mismo oráculo; tolerancias por caso; `nearest` para lo exacto | T3-T |
| R4 | Restricciones de Vulkan (*offsets* constantes, LOD implícito solo en FS, formatos de imagen) | A | M | D-P4.3-3/4/5; error explícito si no se cumplen | `spirv-val`, E1 |
| R5 | El acceso crudo a imágenes exige vistas de formato distinto en P5 | M | M | El traductor informa de la clase de acceso por descriptor; el *harness* lo hace igual que P5 | T3-T con imágenes |
| R6 | Tamaño del trabajo | A | M | Por pasos: `TEX`/`TLD`/`TXQ` → formas escalares → `TLD4`/`TXD`/`TMML` → imágenes → *bindless* | M1 por pasos |

## 8. Análisis de impacto
| Área | Cambio |
|---|---|
| `shader/translate.{h,cpp}` | `ShaderInfo` gana `textures`/`images` (estado por offset; por defecto vacío: P4.1/P4.2 no cambian); `ResourceUse` gana texturas e imágenes; nuevo `shader/translate_texture.inc` |
| `shader/spirv/builder.h` | códigos de operación de imagen, *image operands*, `Dim` |
| `tests/` | *harness* de texturas e imágenes en `vk_graphics`/`vk_compute`, T3-T, T2-T |
| `tools/gpu_toolchain/` | generadores del corpus T3-T y de T2-T |
| `CMakeLists.txt` | tests nuevos bajo `LOBOGELIDO_SHADER_ORACLE` |
| **Sin cambios** | `gpu/`, CPU, kernel, IPC, cargadores, Android/Kotlin, `crypto/` |
