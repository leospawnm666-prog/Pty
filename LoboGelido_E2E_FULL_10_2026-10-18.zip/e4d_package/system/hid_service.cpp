#include "hid_service.h"

namespace lg::system {
namespace {
void put_u32(std::vector<uint8_t>& p, uint32_t v) {
    for (int i = 0; i < 4; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
void put_i32(std::vector<uint8_t>& p, int32_t v) { put_u32(p, static_cast<uint32_t>(v)); }
void put_u64(std::vector<uint8_t>& p, uint64_t v) {
    for (int i = 0; i < 8; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
bool get_i32(const std::vector<uint8_t>& p, size_t off, int32_t& out) {
    uint32_t u{}; if (!get_u32(p, off, u)) return false; out = static_cast<int32_t>(u); return true;
}
IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }
} // namespace

core::Result<IpcMessage> HidService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // GetControllerState
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u64(out.payload, buttons_);
            put_i32(out.payload, lx_);
            put_i32(out.payload, ly_);
            put_i32(out.payload, rx_);
            put_i32(out.payload, ry_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 1: { // SetButton
            uint32_t index{}, pressed{};
            if (!get_u32(r.payload, 0, index) || !get_u32(r.payload, 4, pressed))
                return core::Result<IpcMessage>::Error("hid SetButton: short payload");
            if (index >= 64) return core::Result<IpcMessage>::Error("hid SetButton: index out of range");
            const uint64_t bit = uint64_t(1) << index;
            {
                std::lock_guard lock(mutex_);
                if (pressed) buttons_ |= bit; else buttons_ &= ~bit;
            }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        case 2: { // SetAnalog
            int32_t lx{}, ly{}, rx{}, ry{};
            if (!get_i32(r.payload, 0, lx) || !get_i32(r.payload, 4, ly) ||
                !get_i32(r.payload, 8, rx) || !get_i32(r.payload, 12, ry))
                return core::Result<IpcMessage>::Error("hid SetAnalog: short payload");
            {
                std::lock_guard lock(mutex_);
                lx_ = lx; ly_ = ly; rx_ = rx; ry_ = ry;
            }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        case 3: { // GetNpadStyleSet
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u32(out.payload, style_set_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        default:
            return core::Result<IpcMessage>::Error("hid: unknown command");
    }
}

void HidService::set_button(uint32_t index, bool pressed) noexcept {
    if (index >= 64) return;
    const uint64_t bit = uint64_t(1) << index;
    std::lock_guard lock(mutex_);
    if (pressed) buttons_ |= bit; else buttons_ &= ~bit;
}

void HidService::set_analog(int32_t lx, int32_t ly, int32_t rx, int32_t ry) noexcept {
    std::lock_guard lock(mutex_);
    lx_ = lx; ly_ = ly; rx_ = rx; ry_ = ry;
}

uint64_t HidService::buttons() const noexcept { std::lock_guard lock(mutex_); return buttons_; }

std::unique_ptr<IpcEndpoint> make_hid_service() { return std::make_unique<HidService>(); }

} // namespace lg::system
