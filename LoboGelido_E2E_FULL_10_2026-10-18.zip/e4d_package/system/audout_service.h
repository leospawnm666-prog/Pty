#pragma once
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <vector>
#include "ipc.h"

namespace lg::system {

/**
 * Expanded audout:u-style HLE.
 * Commands:
 *  0 OpenDefault / Open  -> [u32 channels][u32 rate] optional
 *  1 Start
 *  2 Stop
 *  3 AppendBuffer        <- [u32 frames][f32 PCM...]
 *  4 GetReleasedBuffers  -> [u32 count]
 *  5 GetState            -> [u32]
 *  6 SetVolume           <- [f32 linear 0..1]
 *  7 GetBufferCount      -> [u32 appended][u32 released]
 *  8 FlushBuffers
 */
class AudOutService final : public IpcEndpoint {
public:
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

private:
    mutable std::mutex mutex_;
    uint32_t state_{0};
    uint32_t channels_{2};
    uint32_t sample_rate_{48000};
    float volume_{1.0f};
    uint64_t buffers_appended_{0};
    uint64_t buffers_released_{0};
    uint64_t frames_pushed_{0};
    std::deque<uint32_t> release_queue_;
};

std::unique_ptr<IpcEndpoint> make_audout_service();

} // namespace lg::system
