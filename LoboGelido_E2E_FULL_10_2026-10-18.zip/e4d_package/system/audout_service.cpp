#include "audout_service.h"
#include "audio/audio_output_bridge.h"
#include <algorithm>
#include <cstring>

namespace lg::system {

std::unique_ptr<IpcEndpoint> make_audout_service() {
    return std::make_unique<AudOutService>();
}

core::Result<IpcMessage> AudOutService::dispatch(const IpcMessage& request) {
    // Fusion fix (2026-10-16): IpcMessage carries `command_id` and no result field; errors are
    // reported through core::Result, as in hid_service.cpp. Semantics are unchanged.
    IpcMessage reply;
    reply.command_id = request.command_id;

    std::lock_guard lock(mutex_);
    switch (request.command_id) {
    case 0: { // OpenDefault / Open
        if (request.payload.size() >= 8) {
            std::memcpy(&channels_, request.payload.data(), 4);
            std::memcpy(&sample_rate_, request.payload.data() + 4, 4);
            channels_ = std::clamp(channels_, 1u, 8u);
            sample_rate_ = std::clamp(sample_rate_, 8000u, 192000u);
        }
        state_ = 0;
        reply.payload.resize(8);
        std::memcpy(reply.payload.data(), &channels_, 4);
        std::memcpy(reply.payload.data() + 4, &sample_rate_, 4);
        break;
    }
    case 1: // Start
        state_ = 1;
        break;
    case 2: // Stop
        state_ = 0;
        break;
    case 3: { // AppendBuffer
        if (request.payload.size() < 4)
            return core::Result<IpcMessage>::Error("audout AppendBuffer: short payload");
        uint32_t frames = 0;
        std::memcpy(&frames, request.payload.data(), 4);
        const size_t need = 4 + size_t(frames) * channels_ * sizeof(float);
        if (frames == 0 || request.payload.size() < need)
            return core::Result<IpcMessage>::Error("audout AppendBuffer: bad frame count");
        if (state_ == 1) {
            const float* pcm = reinterpret_cast<const float*>(request.payload.data() + 4);
            std::vector<float> scaled;
            const float* src = pcm;
            if (volume_ != 1.0f) {
                scaled.resize(size_t(frames) * channels_);
                for (size_t i = 0; i < scaled.size(); ++i)
                    scaled[i] = pcm[i] * volume_;
                src = scaled.data();
            }
#if defined(__ANDROID__)
            (void)lg::audio::AudioOutputBridge::instance().submit(src, frames);
#else
            (void)src;
#endif
            frames_pushed_ += frames;
        }
        ++buffers_appended_;
        release_queue_.push_back(frames);
        // Auto-release after append (host-consumed model)
        if (!release_queue_.empty()) {
            release_queue_.pop_front();
            ++buffers_released_;
        }
        break;
    }
    case 4: { // GetReleasedBuffers
        uint32_t count = static_cast<uint32_t>(std::min<size_t>(release_queue_.size(), 16));
        // Also report already-auto-released count this tick as 1 if we had activity
        if (count == 0 && buffers_released_ > 0) count = 1;
        reply.payload.resize(4);
        std::memcpy(reply.payload.data(), &count, 4);
        while (!release_queue_.empty()) release_queue_.pop_front();
        break;
    }
    case 5: { // GetState
        reply.payload.resize(4);
        std::memcpy(reply.payload.data(), &state_, 4);
        break;
    }
    case 6: { // SetVolume
        if (request.payload.size() >= 4) {
            std::memcpy(&volume_, request.payload.data(), 4);
            if (volume_ < 0.f) volume_ = 0.f;
            if (volume_ > 1.f) volume_ = 1.f;
        }
        break;
    }
    case 7: { // GetBufferCount
        reply.payload.resize(8);
        uint32_t a = static_cast<uint32_t>(std::min<uint64_t>(buffers_appended_, 0xffffffffu));
        uint32_t r = static_cast<uint32_t>(std::min<uint64_t>(buffers_released_, 0xffffffffu));
        std::memcpy(reply.payload.data(), &a, 4);
        std::memcpy(reply.payload.data() + 4, &r, 4);
        break;
    }
    case 8: // FlushBuffers
        release_queue_.clear();
        break;
    default:
        return core::Result<IpcMessage>::Error("audout: unknown command");
    }
    return core::Result<IpcMessage>::Ok(std::move(reply));
}

} // namespace lg::system
