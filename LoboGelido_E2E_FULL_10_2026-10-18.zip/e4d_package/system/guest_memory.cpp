#include "guest_memory.h"

#include <algorithm>
#include <cstring>

namespace lg::system {
namespace {
constexpr uint64_t kPage = memory::Mmu::PageSize;
}

std::optional<uint64_t> GuestMemory::translate(uint64_t va, bool write) const noexcept {
    const auto t = mmu_.translate(va, write, false);
    if (!t.ok()) return std::nullopt;
    const uint32_t need = memory::User | (write ? memory::Write : memory::Read);
    if ((t.value().permissions & need) != need) return std::nullopt;
    return t.value().physical;
}

bool GuestMemory::accessible(uint64_t va, uint64_t size, bool write) const noexcept {
    if (size == 0) return true;
    if (va + size < va) return false;                                   // wraps around 2^64
    const uint64_t first = va & ~(kPage - 1);
    const uint64_t last = (va + size - 1) & ~(kPage - 1);
    for (uint64_t page = first;; page += kPage) {
        if (!translate(page == first ? va : page, write)) return false;
        if (page == last) break;
    }
    return true;
}

bool GuestMemory::read(uint64_t va, void* dst, size_t size) const noexcept {
    if (!accessible(va, size, false)) return false;
    auto* out = static_cast<uint8_t*>(dst);
    for (size_t done = 0; done < size;) {
        const uint64_t at = va + done;
        const auto pa = translate(at, false);
        if (!pa) return false;                                          // unreachable after accessible()
        const size_t n = static_cast<size_t>(std::min<uint64_t>(kPage - (at & (kPage - 1)), size - done));
        if (const uint8_t* src = memory_.host_ptr(*pa); src && memory_.host_ptr(*pa + n - 1) == src + (n - 1)) {
            std::memcpy(out + done, src, n);
        } else {
            for (size_t i = 0; i < n; ++i) {
                const auto b = memory_.read8(*pa + i);
                if (!b) return false;
                out[done + i] = *b;
            }
        }
        done += n;
    }
    return true;
}

bool GuestMemory::write(uint64_t va, const void* src, size_t size) noexcept {
    if (!accessible(va, size, true)) return false;
    const auto* in = static_cast<const uint8_t*>(src);
    for (size_t done = 0; done < size;) {
        const uint64_t at = va + done;
        const auto pa = translate(at, true);
        if (!pa) return false;
        const size_t n = static_cast<size_t>(std::min<uint64_t>(kPage - (at & (kPage - 1)), size - done));
        for (size_t i = 0; i < n; ++i)
            if (!memory_.try_write8(*pa + i, in[done + i])) return false;   // notifies code watches
        done += n;
    }
    return true;
}

std::optional<uint32_t> GuestMemory::compare_exchange32(uint64_t va, uint32_t expected, uint32_t desired) noexcept {
    if (va & 3) return std::nullopt;
    const auto pa = translate(va, true);
    if (!pa || !translate(va, false)) return std::nullopt;
    for (;;) {
        uint32_t current = 0;
        if (!memory_.atomic_load(*pa, 4, &current)) return std::nullopt;
        if (current != expected) return current;
        if (memory_.compare_exchange(*pa, 4, &expected, &desired)) return expected;
    }
}

std::optional<uint32_t> GuestMemory::read32(uint64_t va) const noexcept {
    uint32_t v{};
    if (!read(va, &v, sizeof v)) return std::nullopt;
    return v;
}

} // namespace lg::system
