// P6.0 (P6_DISENO.md §3.3, P6_0_DISENO.md): the SVCs of threads, the own process, the
// retail answers of the debug and profiling SVCs, insecure and physical memory, kernel
// debug, power, registers and the secure monitor (frontier).
//
// Lobo emulates ONE retail console running ONE process (D-P6.0-1/2). Validation order and
// Result codes are the Horizon kernel's as Atmosphère's mesosphere documents them
// (kern_svc_thread.cpp, kern_svc_activity.cpp, kern_svc_thread_profiler.cpp,
// kern_svc_debug.cpp, kern_svc_process.cpp, kern_svc_process_memory.cpp, kern_svc_cache.cpp,
// kern_svc_query_memory.cpp, kern_svc_address_translation.cpp, kern_svc_info.cpp,
// kern_svc_insecure_memory.cpp, kern_svc_kernel_debug.cpp, kern_svc_power_management.cpp,
// kern_svc_register.cpp, kern_k_system_control_base.cpp); the code is Lobo's own.
// Registers: libnx's svc.s (an output pointer of the C prototype occupies its register slot).
#include <cstdio>
#include <cstring>

#include "svc_dispatcher.h"

namespace lg::system {
namespace {
namespace r = kmem::result;
constexpr uint64_t kPage = kmem::PageSize;
constexpr bool aligned(uint64_t v, uint64_t a = kPage) noexcept { return (v & (a - 1)) == 0; }
uint32_t w(const cpu::CpuState& ctx, int i) noexcept { return static_cast<uint32_t>(ctx.x[i]); }
SvcOutcome done(cpu::CpuState& ctx, uint32_t rc) {
    ctx.x[0] = rc;
    return SvcOutcome::resume();
}
SvcOutcome after(VmManager& vm, cpu::CpuState& ctx, uint32_t rc) {
    if (vm.broken()) return SvcOutcome::fatal("estado interno de memoria inconsistente (Mmu/AddressSpace)");
    return done(ctx, rc);
}

/** A guest exception the kernel raises instead of running the SVC (the thread's SVC access
 *  flags do not include it): an unhandled user exception ends the process (D-P6.0-3). */
SvcOutcome undefined_system_call(const SvcCall& c, const char* why) {
    char pc[24];
    std::snprintf(pc, sizeof pc, "0x%llx", static_cast<unsigned long long>(c.pc));
    return SvcOutcome::fatal(std::string("guest_exception=UndefinedSystemCall svc=") + svc_entry(c.id)->name + " (" + why +
                             ") @" + pc);
}

// The kernel pieces the handlers need; synthetic images have none of them (fail closed, D3).
VmManager* vm_of(SvcDispatcher& d, SvcOutcome& fatal) {
    VmManager* vm = d.session().vm;
    if (!vm || !vm->active()) { fatal = SvcOutcome::fatal("memoria del proceso no disponible para imágenes sintéticas"); return nullptr; }
    return vm;
}
KernelThreads* threads_of(SvcDispatcher& d, const SvcCall& c, KThread*& self, SvcOutcome& fatal) {
    KernelThreads* kt = d.session().kthreads;
    if (!kt || !kt->active()) { fatal = SvcOutcome::fatal("hilos del kernel no disponibles para imágenes sintéticas"); return nullptr; }
    self = kt->current();
    if (!self || self->id != c.thread) {
        fatal = SvcOutcome::fatal("estado interno de hilos inconsistente (SVC fuera del turno)");
        return nullptr;
    }
    return kt;
}
#define LG_VM(d)                          \
    SvcOutcome fatal_;                    \
    VmManager* vmp = vm_of(d, fatal_);    \
    if (!vmp) return fatal_;              \
    VmManager& vm = *vmp
#define LG_KT(d, c)                                         \
    KThread* self = nullptr;                                \
    SvcOutcome fatal_;                                      \
    KernelThreads* kt = threads_of(d, c, self, fatal_);     \
    if (!kt) return fatal_

/** GetObject<KProcess>: pseudo-handle allowed. Lobo's only process is the caller. */
bool is_own_process(SvcDispatcher& d, const SvcCall& c, uint32_t handle) {
    const auto obj = d.handles().resolve(handle, c.thread, d.session().process_id);
    return obj && obj->type == KObjectType::Process && obj->id == d.session().process_id;
}
/** GetObjectWithoutPseudoHandle<KProcess>: a real handle (from IPC) to the own process. */
bool is_own_process_no_pseudo(SvcDispatcher& d, uint32_t handle) {
    const KObjectRef* obj = d.handles().get(handle);
    return obj && obj->type == KObjectType::Process && obj->id == d.session().process_id;
}

/** KPageTableBase::Contains(address, size): inside the process address space. */
bool in_space(const VmManager& vm, uint64_t a, uint64_t s) {
    return s && a + s > a && vm.block_at(a) && vm.block_at(a + s - 1);
}

/** The checks every process-memory SVC starts with (kern_svc_process_memory.cpp). */
uint32_t two_range_checks(uint64_t dst, uint64_t src, uint64_t size) {
    if (!aligned(dst) || !aligned(src)) return r::InvalidAddress;
    if (!aligned(size) || size == 0) return r::InvalidSize;
    if (dst + size <= dst || src + size <= src) return r::InvalidCurrentMemory;
    return r::Success;
}
} // namespace

// ==== threads =================================================================================

SvcOutcome SvcHandlers::return_from_exception(SvcDispatcher&, SvcCall& c) {
    // KThread::SetUsermodeExceptionSvcPermissions grants ReturnFromException only while a user
    // exception handler runs; Lobo never enters one (D-P6.0-3).
    return undefined_system_call(c, "solo dentro de un manejador de excepciones de usuario");
}

SvcOutcome SvcHandlers::synchronize_preemption_state(SvcDispatcher&, SvcCall& c) {
    // KThread::SetUnpinnedSvcPermissions clears it; only a pinned thread may call it, and Lobo
    // never pins threads (no user exception / interrupt flag protocol, D-P6.0-3).
    return undefined_system_call(c, "solo en un hilo fijado (pinned)");
}

SvcOutcome SvcHandlers::get_debug_future_thread_info(SvcDispatcher&, SvcCall& c) {
    // kern_svc_thread_profiler.cpp: R_UNLESS(IsDebugMode(), NoThread) comes first (retail).
    for (int i = 1; i <= 5; ++i) c.ctx.x[i] = 0;
    return done(c.ctx, r::NoThread);
}

SvcOutcome SvcHandlers::get_last_thread_info(SvcDispatcher&, SvcCall& c) {
    for (int i = 1; i <= 6; ++i) c.ctx.x[i] = 0;
    return done(c.ctx, r::NoThread);
}

SvcOutcome SvcHandlers::set_thread_activity(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return done(c.ctx, kt->set_thread_activity(*self, w(c.ctx, 0), w(c.ctx, 1)));
}

SvcOutcome SvcHandlers::get_thread_context3(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    const uint64_t out = c.ctx.x[0];
    const uint32_t handle = w(c.ctx, 1);
    // kern_svc_thread.cpp: handle, safe output pointer, owner, not the caller, context.
    if (!kt->is_thread_handle(handle)) return done(c.ctx, r::InvalidHandle);
    if (!d.guest_memory().accessible(out, 0x320, true)) return done(c.ctx, r::InvalidPointer);
    std::vector<uint8_t> context;
    const uint32_t rc = kt->get_thread_context3(*self, handle, context);
    if (rc) return done(c.ctx, rc);
    if (!d.guest_memory().write(out, context.data(), context.size())) return done(c.ctx, r::InvalidPointer);
    return done(c.ctx, r::Success);
}

// ==== process =================================================================================

SvcOutcome SvcHandlers::set_process_activity(SvcDispatcher& d, SvcCall& c) {
    const uint32_t activity = w(c.ctx, 1);
    if (activity > 1) return done(c.ctx, r::InvalidEnumValue);
    if (!is_own_process(d, c, w(c.ctx, 0))) return done(c.ctx, r::InvalidHandle);
    return done(c.ctx, r::Busy);   // R_UNLESS(process != GetCurrentProcessPointer(), Busy)
}

SvcOutcome SvcHandlers::get_process_info(SvcDispatcher& d, SvcCall& c) {
    const uint32_t type = w(c.ctx, 2), handle = w(c.ctx, 1);
    c.ctx.x[1] = 0;
    if (!is_own_process(d, c, handle)) return done(c.ctx, r::InvalidHandle);
    switch (type) {
        case 0: c.ctx.x[1] = 2; return done(c.ctx, r::Success);   // ProcessState_Running (the caller runs)
        case 1: c.ctx.x[1] = 0; return done(c.ctx, r::Success);   // exit tag: none while running
        default: return done(c.ctx, r::InvalidEnumValue);
    }
}

SvcOutcome SvcHandlers::terminate_process(SvcDispatcher& d, SvcCall& c) {
    if (!is_own_process(d, c, w(c.ctx, 0))) return done(c.ctx, r::InvalidHandle);
    // process == GetCurrentProcessPointer(): ExitProcess (no exit code, as svcExitProcess).
    d.exit_ = {true, false, 0, c.pc};
    return {SvcOutcome::Kind::ExitProcess, {}};
}

SvcOutcome SvcHandlers::start_process(SvcDispatcher& d, SvcCall& c) {
    const auto priority = static_cast<int32_t>(w(c.ctx, 1));
    const auto core = static_cast<int32_t>(w(c.ctx, 2));
    const uint64_t stack = c.ctx.x[3];
    const uint64_t aligned_stack = (stack + kPage - 1) & ~(kPage - 1);
    if (aligned_stack < stack) return done(c.ctx, r::OutOfMemory);
    if (!is_own_process(d, c, w(c.ctx, 0))) return done(c.ctx, r::InvalidHandle);
    if (core < 0 || core >= 64 || ((1ull << core) & SvcDispatcher::kCoreMask) == 0) return done(c.ctx, 0xE201);   // InvalidCoreId
    if (priority < 0 || priority > 63 || ((SvcDispatcher::kPriorityMask >> priority) & 1) == 0) return done(c.ctx, 0xE001);
    return done(c.ctx, r::InvalidState);   // KProcess::Run: the process is not in state Created
}

SvcOutcome SvcHandlers::create_process(SvcDispatcher& d, SvcCall& c) {
    // kern_svc_process.cpp CreateProcess: every parameter check of Horizon, then the slot
    // search. Lobo emulates a single process (D-P6.0-2): no slot is ever free (OutOfResource).
    const uint64_t params_ptr = c.ctx.x[1];
    c.ctx.x[1] = 0;
    struct Params { char name[12]; uint32_t version; uint64_t program_id, code_address; int32_t code_num_pages;
                    uint32_t flags; uint32_t reslimit; int32_t system_resource_num_pages; };
    static_assert(sizeof(Params) == 0x30);
    Params p{};
    if (!d.guest_memory().read(params_ptr, &p, sizeof p)) return done(c.ctx, r::InvalidPointer);
    const uint64_t caps = c.ctx.x[2];
    const auto num_caps = static_cast<int32_t>(w(c.ctx, 3));
    if (num_caps < 0) return done(c.ctx, r::InvalidPointer);
    if (num_caps > 0 && !d.guest_memory().accessible(caps, uint64_t(num_caps) * 4, false)) return done(c.ctx, r::InvalidPointer);
    constexpr uint32_t k64Bit = 1u << 0, kAsMask = 7u << 1, kAs32 = 0u << 1, kAs36 = 1u << 1, kAs32NoReserved = 2u << 1,
                       kAs39 = 3u << 1, kAs42 = 4u << 1, kIsApplication = 1u << 6, kPoolMask = 0xFu << 7,
                       kOptimize = 1u << 11, kAsan = 1u << 13;
    constexpr uint32_t kAll = k64Bit | kAsMask | (1u << 4) | (1u << 5) | kIsApplication | kPoolMask | kOptimize | (1u << 12) |
                              kAsan | (1u << 17);
    if (p.flags & ~kAll) return done(c.ctx, r::InvalidEnumValue);
    const uint32_t as = p.flags & kAsMask;
    if (as == kAs42) return done(c.ctx, r::InvalidCombination);
    const bool is_64 = (p.flags & k64Bit) != 0;
    constexpr uint64_t MB = 1ull << 20, GB = 1ull << 30;
    uint64_t map_start = 0, map_end = 0, map_size = 0;   // KAddressSpaceInfo (svc_memory_map.hpp)
    switch (as) {
        case kAs32: case kAs32NoReserved:
            map_start = 2 * MB; map_size = 1 * GB - 2 * MB; map_end = map_start + map_size; break;
        case kAs36:
            if (!is_64) return done(c.ctx, r::InvalidCombination);
            map_start = 128 * MB; map_size = 2 * GB - 128 * MB; map_end = map_start + map_size; break;
        case kAs39:
            if (!is_64) return done(c.ctx, r::InvalidCombination);
            map_start = 128 * MB; map_end = 512 * GB; map_size = 8 * GB; break;   // MapHuge; size = Heap39
        default: return done(c.ctx, r::InvalidEnumValue);
    }
    if (((p.flags & kPoolMask) >> 7) > 3) return done(c.ctx, r::InvalidEnumValue);   // 5.0.0+
    if (!aligned(p.code_address, 2 * MB)) return done(c.ctx, r::InvalidAddress);     // KProcess::AslrAlignment
    if (p.code_num_pages < 0 || p.system_resource_num_pages < 0) return done(c.ctx, r::InvalidSize);
    if (p.flags & kAsan) return done(c.ctx, r::InvalidState);   // needs 39-bit + resource + debug mode: never on retail
    const uint64_t code_pages = uint64_t(p.code_num_pages), res_pages = uint64_t(p.system_resource_num_pages);
    const uint64_t code_size = code_pages * kPage;
    if (code_pages >= map_size / kPage) return done(c.ctx, r::InvalidMemoryRegion);
    if (map_start > p.code_address) return done(c.ctx, r::InvalidMemoryRegion);
    if (!(p.code_address < p.code_address + code_size)) return done(c.ctx, r::InvalidMemoryRegion);
    if (p.code_address + code_size - 1 > map_end - 1) return done(c.ctx, r::InvalidMemoryRegion);
    constexpr uint64_t kMaxPages = (8 * GB) / 4096;   // MainMemorySizeMax / PageSize
    if (code_pages >= kMaxPages || res_pages >= kMaxPages || code_pages + res_pages >= kMaxPages)
        return done(c.ctx, r::OutOfMemory);
    if ((p.flags & kOptimize) && !(p.flags & kIsApplication)) return done(c.ctx, r::Busy);
    // KCapabilities::CheckCapabilities: MapRegion capabilities must name a physical region.
    for (int32_t i = 0; i < num_caps; ++i) {
        const auto cap = d.guest_memory().read32(caps + 4 * uint64_t(i));
        if (!cap) return done(c.ctx, r::InvalidPointer);
        const uint32_t v = *cap;
        if (((~v & (v + 1)) - 1) != (1u << 10) - 1) continue;   // not MapRegion
        for (int k = 0; k < 3; ++k) {
            const uint32_t type = (v >> (11 + 7 * k)) & 0x3F;
            if (type == 0) continue;                               // NoMapping
            if (type > 3) return done(c.ctx, r::NotFound);
            return done(c.ctx, r::OutOfRange);   // KernelTraceBuffer/OnMemoryBootImage/DTB: none on retail (D-P6.0-2)
        }
    }
    return done(c.ctx, r::OutOfResource);   // CreateProcessForAddressSpace: no KProcess slot
}

// ==== process memory ==========================================================================

SvcOutcome SvcHandlers::set_process_memory_permission(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t a = c.ctx.x[1], s = c.ctx.x[2];
    const uint32_t perm = w(c.ctx, 3);
    if (!aligned(a)) return done(c.ctx, r::InvalidAddress);
    if (!aligned(s) || s == 0) return done(c.ctx, r::InvalidSize);
    if (a + s <= a) return done(c.ctx, r::InvalidCurrentMemory);
    if (perm != 0 && perm != 1 && perm != 3 && perm != 5 && perm != 4) return done(c.ctx, r::InvalidNewMemoryPermission);
    if (!is_own_process(d, c, w(c.ctx, 0))) return done(c.ctx, r::InvalidHandle);
    return after(vm, c.ctx, vm.set_process_memory_permission(a, s, perm));
}

SvcOutcome SvcHandlers::map_process_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t dst = c.ctx.x[0], src = c.ctx.x[2], s = c.ctx.x[3];
    if (const uint32_t rc = two_range_checks(dst, src, s); rc) return done(c.ctx, rc);
    if (!is_own_process_no_pseudo(d, w(c.ctx, 1))) return done(c.ctx, r::InvalidHandle);
    if (!in_space(vm, src, s)) return done(c.ctx, r::InvalidCurrentMemory);   // src_pt.Contains
    if (!vm.can_contain(dst, s, kmem::SharedCode)) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.map_process_memory(dst, src, s));
}

SvcOutcome SvcHandlers::unmap_process_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t dst = c.ctx.x[0], src = c.ctx.x[2], s = c.ctx.x[3];
    if (const uint32_t rc = two_range_checks(dst, src, s); rc) return done(c.ctx, rc);
    if (!is_own_process_no_pseudo(d, w(c.ctx, 1))) return done(c.ctx, r::InvalidHandle);
    if (!in_space(vm, src, s)) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.can_contain(dst, s, kmem::SharedCode)) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.unmap_process_memory(dst, src, s));
}

SvcOutcome SvcHandlers::map_process_code_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t dst = c.ctx.x[1], src = c.ctx.x[2], s = c.ctx.x[3];
    if (const uint32_t rc = two_range_checks(dst, src, s); rc) return done(c.ctx, rc);
    if (!is_own_process_no_pseudo(d, w(c.ctx, 0))) return done(c.ctx, r::InvalidHandle);
    if (!in_space(vm, src, s)) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.can_contain(dst, s, kmem::AliasCode)) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.map_process_code_memory(dst, src, s));
}

SvcOutcome SvcHandlers::unmap_process_code_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t dst = c.ctx.x[1], src = c.ctx.x[2], s = c.ctx.x[3];
    if (const uint32_t rc = two_range_checks(dst, src, s); rc) return done(c.ctx, rc);
    if (!is_own_process_no_pseudo(d, w(c.ctx, 0))) return done(c.ctx, r::InvalidHandle);
    if (!in_space(vm, src, s)) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.can_contain(dst, s, kmem::AliasCode)) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.unmap_process_code_memory(dst, src, s));
}

SvcOutcome SvcHandlers::query_process_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t out = c.ctx.x[0];
    c.ctx.x[1] = 0;
    if (!d.guest_memory().accessible(out, sizeof(kmem::MemoryInfo), true)) return done(c.ctx, r::InvalidPointer);
    if (!is_own_process(d, c, w(c.ctx, 2))) return done(c.ctx, r::InvalidHandle);
    const kmem::MemoryInfo info = vm.query(c.ctx.x[3]);
    if (!d.guest_memory().write(out, &info, sizeof info)) return done(c.ctx, r::InvalidPointer);
    return done(c.ctx, r::Success);
}

namespace {
/** Invalidate/Store/FlushProcessDataCache: the common checks (kern_svc_cache.cpp). */
uint32_t cache_checks(SvcDispatcher& d, const SvcCall& c, VmManager& vm, bool invalidate) {
    const uint64_t a = c.ctx.x[1], s = c.ctx.x[2];
    if (s == 0) return r::InvalidSize;
    if (!is_own_process(d, c, w(c.ctx, 0))) return r::InvalidHandle;
    if (a + s < a || !in_space(vm, a, s)) return r::InvalidCurrentMemory;   // Contains
    if (invalidate)   // InvalidateCurrentProcessDataCache: reference-counted, user RW, cached
        return vm.check_state(a, s, kmem::FlagReferenceCounted, kmem::FlagReferenceCounted, kmem::PermRW, kmem::PermRW,
                              kmem::AttrUncached, 0);
    // cpu::StoreDataCache / FlushDataCache on the caller's VA: a fault is InvalidCurrentMemory
    return d.guest_memory().accessible(a, s, false) ? r::Success : r::InvalidCurrentMemory;
}
} // namespace

SvcOutcome SvcHandlers::invalidate_process_data_cache(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);   // the host keeps guest memory coherent: the maintenance itself has nothing to do
    return done(c.ctx, cache_checks(d, c, vm, true));
}
SvcOutcome SvcHandlers::store_process_data_cache(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    return done(c.ctx, cache_checks(d, c, vm, false));
}
SvcOutcome SvcHandlers::flush_process_data_cache(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    return done(c.ctx, cache_checks(d, c, vm, false));
}

// ==== physical / insecure memory ===============================================================

SvcOutcome SvcHandlers::query_physical_address(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t va = c.ctx.x[1];
    c.ctx.x[1] = c.ctx.x[2] = c.ctx.x[3] = 0;
    if (!vm.block_at(va)) return done(c.ctx, r::InvalidCurrentMemory);   // pt.Contains(address, 1)
    VmManager::PhysicalInfo info{};
    const uint32_t rc = vm.query_physical_address(va, info);
    if (rc == r::Success) {
        c.ctx.x[1] = info.physical_address;
        c.ctx.x[2] = info.virtual_address;
        c.ctx.x[3] = info.size;
    }
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::query_memory_mapping(SvcDispatcher&, SvcCall& c) {
    // kern_svc_address_translation.cpp: Lobo maps no I/O and no static region into the process
    // (no MapIoPage/MapRegion capability is ever honoured, D-P6.0-2), so every lookup ends in
    // NotFound after the size checks.
    const uint64_t pa = c.ctx.x[2], size = c.ctx.x[3];
    c.ctx.x[1] = c.ctx.x[2] = 0;
    if (aligned(pa)) {
        if (size == 0) return done(c.ctx, r::InvalidSize);
        return done(c.ctx, r::NotFound);
    }
    return done(c.ctx, r::NotFound);   // 8.0.0+: pa < PageSize names a region type; none is mapped
}

SvcOutcome SvcHandlers::map_insecure_physical_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t a = c.ctx.x[0], s = c.ctx.x[1];
    if (!aligned(s) || s == 0) return done(c.ctx, r::InvalidSize);
    if (!aligned(a)) return done(c.ctx, r::InvalidAddress);
    if (a + s <= a) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.can_contain(a, s, kmem::Insecure)) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.map_insecure_memory(a, s));
}

SvcOutcome SvcHandlers::unmap_insecure_physical_memory(SvcDispatcher& d, SvcCall& c) {
    LG_VM(d);
    const uint64_t a = c.ctx.x[0], s = c.ctx.x[1];
    if (!aligned(s) || s == 0) return done(c.ctx, r::InvalidSize);
    if (!aligned(a)) return done(c.ctx, r::InvalidAddress);
    if (a + s <= a) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.can_contain(a, s, kmem::Insecure)) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.unmap_insecure_memory(a, s));
}

// ==== debug (retail) ===========================================================================

SvcOutcome SvcHandlers::debug_retail(SvcDispatcher& d, SvcCall& c) {
    // kern_svc_debug.cpp / kern_svc_process.cpp / kern_svc_thread.cpp: every debug SVC starts
    // with R_UNLESS(KTargetSystem::IsDebugMode() [|| CanForceDebugProd()], NotImplemented).
    // Lobo is a retail console and hbl.json does not set force_debug_prod (D-P6.0-1).
    // QueryDebugProcessMemory checks its output pointer before that.
    switch (c.id) {
        case 0x60: case 0x65: case 0x66: c.ctx.x[1] = 0; break;              // out handle / count
        case 0x69:
            if (!d.guest_memory().accessible(c.ctx.x[0], sizeof(kmem::MemoryInfo), true)) {
                c.ctx.x[1] = 0;
                return done(c.ctx, r::InvalidPointer);
            }
            c.ctx.x[1] = 0;
            break;
        case 0x6D: c.ctx.x[1] = c.ctx.x[2] = 0; break;                       // out64, out32
        default: break;
    }
    return done(c.ctx, r::NotImplemented);
}

// ==== system ===================================================================================

SvcOutcome SvcHandlers::kernel_debug(SvcDispatcher&, SvcCall&) {
    return SvcOutcome::resume();   // stubbed in the retail kernel (Switchbrew; void: no register changes)
}

SvcOutcome SvcHandlers::change_kernel_trace_state(SvcDispatcher&, SvcCall&) {
    return SvcOutcome::resume();   // stubbed in the retail kernel
}

SvcOutcome SvcHandlers::sleep_system(SvcDispatcher& d, SvcCall&) {
    // KSystemControl::SleepSystem: the console sleeps until a wake event. The emulated console
    // has no power state and no wake source: it wakes at once (D-P6.0-4). void.
    ++d.sleep_requests_;
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::read_write_register(SvcDispatcher&, SvcCall& c) {
    // *out = 0; KSystemControl::ReadWriteRegister. Lobo emulates no memory controller / PMC
    // registers: the kernel of a board without them answers NotImplemented
    // (KSystemControlBase::ReadWriteRegister, D-P6.0-4).
    c.ctx.x[1] = 0;
    return done(c.ctx, r::NotImplemented);
}

SvcOutcome SvcHandlers::call_secure_monitor(SvcDispatcher& d, SvcCall& c) {
    // FRONTIER (D-P6-3): the secure monitor holds the keys and the crypto engine; Lobo has none
    // and never will. The kernel part is honoured (KSystemControlBase::CallSecureMonitorFromUser):
    // registers flagged in the function id (bit 8 + n for x[n]) that point at user RW pages are
    // translated to physical addresses, others become 0; then the call fails as on a kernel with
    // no secure monitor: x0 = 1 (SMC NotImplemented). No secure-monitor function is emulated.
    const uint64_t function_id = c.ctx.x[0];
    VmManager* vm = d.session().vm;
    for (int reg = 1; reg <= 7; ++reg) {
        if (!(function_id & (1ull << (8 + reg)))) continue;
        const uint64_t va = c.ctx.x[reg];
        uint64_t pa = 0;
        if (vm && vm->active()) {
            const uint64_t page = va & ~(kPage - 1);
            if (vm->check_state(page, kPage, kmem::FlagReferenceCounted, kmem::FlagReferenceCounted, kmem::PermRW, kmem::PermRW,
                                kmem::All, 0) == r::Success) {
                if (const auto p = vm->physical(page)) pa = VmManager::kDramBase + *p + (va & (kPage - 1));
            }
        }
        c.ctx.x[reg] = pa;
    }
    c.ctx.x[0] = 1;
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::get_system_info(SvcDispatcher& d, SvcCall& c) {
    // kern_svc_info.cpp GetSystemInfo. The emulated console's DRAM is one application pool
    // (the process's memory budget); the applet/system pools hold nothing (D-P6.0-5).
    const uint32_t type = w(c.ctx, 1), handle = w(c.ctx, 2);
    const uint64_t sub = c.ctx.x[3];
    c.ctx.x[1] = 0;
    switch (type) {
        case 0: case 1: {
            if (handle != HandleTable::kInvalidHandle) return done(c.ctx, r::InvalidHandle);
            if (sub > 3) return done(c.ctx, r::InvalidCombination);   // IsValidMemoryPool
            const VmManager* vm = d.session().vm;
            if (sub == 0 && vm && vm->active()) c.ctx.x[1] = type == 0 ? vm->total_memory() : vm->used_memory();
            return done(c.ctx, r::Success);
        }
        case 2:
            if (handle != HandleTable::kInvalidHandle) return done(c.ctx, r::InvalidHandle);
            if (sub > 1) return done(c.ctx, r::InvalidCombination);
            c.ctx.x[1] = sub == 0 ? 1 : 0x50;   // KProcess's initial-process id range (D-P6.0-5)
            return done(c.ctx, r::Success);
        default: return done(c.ctx, r::InvalidEnumValue);
    }
}

// ==== hardware the emulated console lacks ======================================================
// kern_svc_io_pool.cpp + kern_k_io_pool.unsupported.inc (no valid pool type),
// kern_svc_interrupt_event.cpp (no interrupt capability), kern_svc_device_address_space.cpp +
// board/generic/kern_k_device_page_table.hpp (no SMMU: NotImplemented). The checks before the
// missing device are Horizon's, in order (D-P6.0-4).

SvcOutcome SvcHandlers::create_io_pool(SvcDispatcher&, SvcCall& c) {
    c.ctx.x[1] = 0;
    return done(c.ctx, r::NotFound);   // KIoPool::IsValidIoPoolType: no PCIe pool on this console
}

SvcOutcome SvcHandlers::create_io_region(SvcDispatcher&, SvcCall& c) {
    const uint64_t pa = c.ctx.x[2], size = c.ctx.x[3];
    const uint32_t mapping = w(c.ctx, 4), perm = w(c.ctx, 5);
    c.ctx.x[1] = 0;
    if (size == 0 || !aligned(size)) return done(c.ctx, r::InvalidSize);
    if (!aligned(pa)) return done(c.ctx, r::InvalidAddress);
    if (pa + size <= pa) return done(c.ctx, r::InvalidMemoryRegion);
    if (mapping > 2) return done(c.ctx, r::InvalidEnumValue);                       // IoRegister/Uncached/Memory
    if (perm != kmem::PermR && perm != kmem::PermRW) return done(c.ctx, r::InvalidEnumValue);
    return done(c.ctx, r::InvalidHandle);   // no KIoPool can exist
}

namespace {
uint32_t io_map_checks(SvcDispatcher& d, const SvcCall& c) {
    const uint64_t a = c.ctx.x[1], s = c.ctx.x[2];
    if (s == 0 || !aligned(s)) return r::InvalidSize;
    if (!aligned(a)) return r::InvalidAddress;
    if (a + s <= a) return r::InvalidCurrentMemory;
    const VmManager* vm = d.session().vm;
    if (!vm || !vm->can_contain(a, s, 0x00182001 /* KMemoryState_IoMemory */)) return r::InvalidMemoryRegion;
    return r::Success;
}
} // namespace

SvcOutcome SvcHandlers::map_io_region(SvcDispatcher& d, SvcCall& c) {
    if (const uint32_t rc = io_map_checks(d, c); rc) return done(c.ctx, rc);
    const uint32_t perm = w(c.ctx, 3);
    if (perm != kmem::PermR && perm != kmem::PermRW) return done(c.ctx, r::InvalidNewMemoryPermission);
    return done(c.ctx, r::InvalidHandle);   // no KIoRegion can exist
}

SvcOutcome SvcHandlers::unmap_io_region(SvcDispatcher& d, SvcCall& c) {
    if (const uint32_t rc = io_map_checks(d, c); rc) return done(c.ctx, rc);
    return done(c.ctx, r::InvalidHandle);
}

SvcOutcome SvcHandlers::create_interrupt_event(SvcDispatcher&, SvcCall& c) {
    const uint32_t type = w(c.ctx, 2);
    c.ctx.x[1] = 0;
    if (type > 1) return done(c.ctx, r::InvalidEnumValue);   // Edge / Level
    return done(c.ctx, r::NotFound);   // KCapabilities::IsPermittedInterrupt: no InterruptPair capability
}

SvcOutcome SvcHandlers::create_device_address_space(SvcDispatcher&, SvcCall& c) {
    const uint64_t a = c.ctx.x[1], s = c.ctx.x[2];
    c.ctx.x[1] = 0;
    if (!aligned(a) || !aligned(s) || s == 0 || a + s <= a) return done(c.ctx, r::InvalidMemoryRegion);
    return done(c.ctx, r::NotImplemented);   // KDevicePageTable::Initialize without an SMMU
}

SvcOutcome SvcHandlers::attach_device_address_space(SvcDispatcher&, SvcCall& c) {
    return done(c.ctx, r::InvalidHandle);    // Attach/Detach: no KDeviceAddressSpace can exist
}

SvcOutcome SvcHandlers::map_device_address_space(SvcDispatcher&, SvcCall& c) {
    const uint64_t pa = c.ctx.x[2], size = c.ctx.x[3], da = c.ctx.x[4];
    const uint32_t option = w(c.ctx, 5);
    const uint32_t perm = option & 0xFFFF, reserved = option >> 17;
    if (!aligned(pa) || !aligned(da)) return done(c.ctx, r::InvalidAddress);
    if (c.id == 0x5A && ((pa ^ da) & ((1ull << 22) - 1)) != 0) return done(c.ctx, r::InvalidAddress);   // Aligned
    if (!aligned(size) || size == 0) return done(c.ctx, r::InvalidSize);
    if (pa + size <= pa) return done(c.ctx, r::InvalidCurrentMemory);
    if (da + size <= da) return done(c.ctx, r::InvalidMemoryRegion);
    if (perm != kmem::PermR && perm != kmem::PermW && perm != kmem::PermRW) return done(c.ctx, r::InvalidNewMemoryPermission);
    if (reserved != 0) return done(c.ctx, r::InvalidEnumValue);
    return done(c.ctx, r::InvalidHandle);
}

SvcOutcome SvcHandlers::unmap_device_address_space(SvcDispatcher&, SvcCall& c) {
    const uint64_t pa = c.ctx.x[2], size = c.ctx.x[3], da = c.ctx.x[4];
    if (!aligned(pa) || !aligned(da)) return done(c.ctx, r::InvalidAddress);
    if (!aligned(size) || size == 0) return done(c.ctx, r::InvalidSize);
    if (pa + size <= pa) return done(c.ctx, r::InvalidCurrentMemory);
    if (da + size <= da) return done(c.ctx, r::InvalidMemoryRegion);
    return done(c.ctx, r::InvalidHandle);
}

SvcOutcome SvcHandlers::legacy_map_device_address_space(SvcDispatcher&, SvcCall& c) {
    // MapDeviceAddressSpace (1.0.0-12.1.0) left the kernel in 13.0.0; Lobo emulates the newest
    // kernel (D-P6.0-9), where the number has no handler: an invalid SVC is a user exception.
    return undefined_system_call(c, "retirada en 13.0.0");
}

// ==== GetInfo (P6.0 ids) =======================================================================

bool SvcHandlers::get_info_p6(SvcDispatcher& d, SvcCall& c, uint32_t id0, uint32_t handle, uint64_t id1) {
    auto answer = [&](uint32_t rc, uint64_t value) {
        c.ctx.x[0] = rc;
        c.ctx.x[1] = rc == r::Success ? value : 0;
        return true;
    };
    KernelThreads* kt = d.session().kthreads;
    KernelObjects* ko = d.session().kobjects;
    const VmManager* vm = d.session().vm;
    const bool native = kt && kt->active() && ko && ko->active() && vm && vm->active();
    switch (id0) {
        case 9: {   // ResourceLimit: a new handle to the process's limit
            if (!native) return answer(r::InvalidEnumValue, 0);   // synthetic image: no kernel objects (D3)
            if (handle != HandleTable::kInvalidHandle) return answer(r::InvalidHandle, 0);
            if (id1 != 0) return answer(r::InvalidCombination, 0);
            uint32_t h = 0;
            const uint32_t rc = ko->open_process_resource_limit(h);
            return answer(rc, h);
        }
        case 10: {  // IdleTickCount of the current core
            if (!native) return answer(r::InvalidEnumValue, 0);
            if (handle != HandleTable::kInvalidHandle) return answer(r::InvalidHandle, 0);
            const int core = kt->current_core();
            if (id1 != ~uint64_t{0} && id1 != static_cast<uint64_t>(core)) return answer(r::InvalidCombination, 0);
            return answer(r::Success, kt->idle_ticks(core, d.session().clock ? d.session().clock->ticks() : 0));
        }
        case 20: case 23: case 24: case 28: case 36: case 37: case 38: {   // process ids
            if (id1 != 0) return answer(r::InvalidCombination, 0);
            if (!is_own_process(d, c, handle)) return answer(r::InvalidHandle, 0);
            // the kernel parts each id reads (absent on synthetic images: fail closed, D3)
            const bool has_vm = vm && vm->active();
            if (!has_vm || (id0 == 20 && !(kt && kt->active())) || (id0 == 24 && !(ko && ko->active())))
                return answer(r::InvalidEnumValue, 0);
            switch (id0) {
                case 20: return answer(r::Success, kt->process_local_region());          // UserExceptionContextAddress
                case 23: return answer(r::Success, d.session().is_application ? 1 : 0);  // IsApplication
                case 24: {                                                              // FreeThreadCount
                    const int64_t free = ko->process_limit_free(LimitableResource::ThreadCountMax);
                    return answer(r::Success, static_cast<uint64_t>(free));
                }
                case 28: return answer(r::Success, 0);                                  // AliasRegionExtraSize
                case 36: return answer(r::Success, vm->config().space_end);             // AddressSpaceSize (from 0)
                default: return answer(r::Success, 0);                                  // ShadowStack: none
            }
        }
        case 26:    // IsSvcPermitted (only SynchronizePreemptionState may be asked)
            if (handle != HandleTable::kInvalidHandle) return answer(r::InvalidHandle, 0);
            if (id1 != 0x36) return answer(r::InvalidCombination, 0);
            return answer(r::Success, 1);   // hbl.json grants every SVC (D-P6.0-1)
        case 27:    // IoRegionHint: no KIoRegion can exist (CreateIoPool fails, P6.0)
            if (id1 != 0) return answer(r::InvalidCombination, 0);
            return answer(r::InvalidHandle, 0);
        case 34: {  // TransferMemoryHint
            if (id1 != 0) return answer(r::InvalidCombination, 0);
            if (!native) return answer(r::InvalidHandle, 0);
            const auto t = ko->transfer_from_handle(handle);
            if (!t) return answer(r::InvalidHandle, 0);
            const uint64_t mask = t->size >= (2ull << 20) ? (2ull << 20) - 1 : t->size >= 0x10000 ? 0xFFFF
                                : t->size >= 0x1000 ? 0xFFF : 0;
            return answer(r::Success, t->address & mask);
        }
        default: return false;
    }
}

#undef LG_VM
#undef LG_KT

} // namespace lg::system
