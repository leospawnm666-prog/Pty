#include "handle_table.h"

namespace lg::system {

HandleTable::HandleTable() : slots_(kCapacity + 1) {
    free_.reserve(kCapacity);
    for (uint32_t i = kCapacity; i >= 1; --i) free_.push_back(i);   // index 1 is handed out first
}

void HandleTable::bump(Slot& s) noexcept {
    s.generation = static_cast<uint16_t>((s.generation + 1) & kGenerationMask);
    if (s.generation == 0) s.generation = 1;   // a handle is never 0 in its generation bits
}

std::optional<uint32_t> HandleTable::add(KObjectRef object) {
    if (object.type == KObjectType::None || free_.empty()) return std::nullopt;
    const uint32_t index = free_.back();
    free_.pop_back();
    Slot& s = slots_[index];
    s.object = object;
    s.used = true;
    ++used_;
    return make(index, s.generation);
}

const HandleTable::Slot* HandleTable::slot_of(uint32_t handle) const noexcept {
    if (handle == kInvalidHandle || is_pseudo(handle)) return nullptr;
    if (handle >> (2 * kIndexBits)) return nullptr;                    // bits 30-31 must be 0
    const uint32_t index = handle & kIndexMask;
    const uint32_t generation = (handle >> kIndexBits) & kGenerationMask;
    if (index == 0 || index > kCapacity || generation == 0) return nullptr;
    const Slot& s = slots_[index];
    if (!s.used || s.generation != generation) return nullptr;
    return &s;
}

const KObjectRef* HandleTable::get(uint32_t handle) const noexcept {
    const Slot* s = slot_of(handle);
    return s ? &s->object : nullptr;
}

std::optional<KObjectRef> HandleTable::resolve(uint32_t handle, uint64_t current_thread,
                                               uint64_t current_process) const noexcept {
    if (handle == kCurrentThread) return KObjectRef{KObjectType::Thread, current_thread};
    if (handle == kCurrentProcess) return KObjectRef{KObjectType::Process, current_process};
    if (const KObjectRef* o = get(handle)) return *o;
    return std::nullopt;
}

bool HandleTable::close(uint32_t handle) noexcept {
    if (!slot_of(handle)) return false;
    Slot& s = slots_[handle & kIndexMask];
    s.object = {};
    s.used = false;
    bump(s);
    --used_;
    free_.push_back(handle & kIndexMask);
    return true;
}

void HandleTable::clear() noexcept {
    free_.clear();
    for (uint32_t i = kCapacity; i >= 1; --i) {
        Slot& s = slots_[i];
        if (s.used) { s.object = {}; s.used = false; bump(s); }
        free_.push_back(i);
    }
    used_ = 0;
}

} // namespace lg::system
