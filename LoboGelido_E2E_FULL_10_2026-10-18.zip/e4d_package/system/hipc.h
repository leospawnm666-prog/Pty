#pragma once
// P3.4: the HIPC message codec (P3_4_DISENO.md §2.3). Pure functions over the 0x100-byte
// message buffer of a thread's TLS: no guest memory, no kernel state, so every field can be
// tested byte for byte and fuzzed.
//
// Layout (Atmosphère svc_message_buffer.hpp / libnx hipc.h):
//   word0: type[0:15] | X count[16:19] | A count[20:23] | B count[24:27] | W count[28:31]
//   word1: raw data words[0:9] | receive list (C) mode[10:13] | C offset (words)[20:30] |
//          has special header[31]
//   special: pid[0] | copy handles[1:4] | move handles[5:8]
//   then: [pid u64] copy handles, move handles, X (2 words), A, B, W (3 words), raw data,
//         receive list (2 words per entry).
// Addresses are decoded with the kernel's 39-bit width (what Horizon honours).
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace lg::system::hipc {

constexpr size_t kMessageBytes = 0x100;
constexpr size_t kMessageWords = kMessageBytes / 4;
using Message = std::array<uint32_t, kMessageWords>;

namespace result {   // kernel results (module 1) the codec can produce
constexpr uint32_t Success = 0;
constexpr uint32_t InvalidCombination = 0xE801;     // 116
constexpr uint32_t MessageTooLarge = 0x20801;       // 260
} // namespace result

/** Receive list (C) modes. n > 2 means n - 2 indexed entries. */
namespace recv_mode {
constexpr uint32_t None = 0;
constexpr uint32_t ToMessageBuffer = 1;
constexpr uint32_t ToSingleBuffer = 2;
constexpr uint32_t kCountMax = 13;   // ReceiveListCountType_CountMax
} // namespace recv_mode

struct StaticDescriptor {   // X
    uint32_t index{};
    uint64_t address{};
    uint64_t size{};
    bool operator==(const StaticDescriptor&) const = default;
};
struct BufferDescriptor {   // A / B / W
    uint64_t address{};
    uint64_t size{};
    uint32_t mode{};        // 0 Ipc, 1 NonSecureIpc, 2 invalid, 3 NonDeviceIpc
    bool operator==(const BufferDescriptor&) const = default;
};
struct ReceiveEntry {       // C
    uint64_t address{};
    uint64_t size{};
    bool operator==(const ReceiveEntry&) const = default;
};

struct Request {
    uint32_t type{};
    bool has_special{};
    bool send_pid{};
    uint64_t pid_value{};                // what the sender wrote (the kernel replaces it)
    std::vector<uint32_t> copy_handles;
    std::vector<uint32_t> move_handles;
    std::vector<StaticDescriptor> x;
    std::vector<BufferDescriptor> a, b, w;
    uint32_t data_offset{};              // word index of the raw data
    uint32_t data_words{};
    uint32_t recv_mode{};
    uint32_t recv_offset{};              // as written (0 = right after the raw data)
    uint32_t recv_index{};               // word index where the receive list really starts
    std::vector<ReceiveEntry> c;         // ToSingleBuffer: 1 entry; indexed: mode - 2 entries
    uint32_t end_bytes{};                // GetMessageBufferSize
};

/** Word index of the raw data for a header (no validation). */
uint32_t raw_data_index(const Message& m) noexcept;

/** Decodes a message as the kernel receives it (KServerSession::ReceiveMessage):
 *  InvalidCombination when the message (with its receive list) does not fit in `size` bytes or
 *  the receive-list offset points inside the message body; MessageTooLarge when the body does
 *  not fit. Move handles are decoded; rejecting them in a request is the caller's rule. */
uint32_t parse(const Message& m, Request& out, size_t size = kMessageBytes);

/** A reply to write back (HLE server -> client). Replies never carry A/B/W. */
struct Response {
    uint32_t type{};                     // 0 for CMIF replies
    std::vector<uint32_t> copy_handles;
    std::vector<uint32_t> move_handles;
    std::vector<StaticDescriptor> x;
    uint32_t data_words{};
};

/** Writes the header part of `r` into `m` (zeroing the rest) and returns the word index where
 *  the raw data starts, or 0 when it does not fit in the message (the caller then fails). */
uint32_t build(const Response& r, Message& m) noexcept;

// Descriptor packing, exposed for the tests (the inverse of what parse() decodes).
void pack_static(const StaticDescriptor& d, uint32_t out[2]) noexcept;
void pack_buffer(const BufferDescriptor& d, uint32_t out[3]) noexcept;
void pack_receive(const ReceiveEntry& d, uint32_t out[2]) noexcept;

} // namespace lg::system::hipc
