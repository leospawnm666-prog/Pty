#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include "ipc.h"

// High-level emulation of the Switch "system information & settings" services:
//   set:sys  — nn::settings::ISystemSettingsServer (firmware version, color set)
//   set      — nn::settings::ISettingsServer        (language codes)
//   apm      — nn::apm                              (performance mode)
//   time     — nn::timesrv (user system clock)      (current POSIX time)
//
// SCOPE / HONESTY: the Lobo IpcMessage transport is a simplified {command_id,
// payload} channel, not raw HIPC/cmif. These endpoints implement the SERVICE
// LAYER a cmif dispatcher would call into, with command IDs aligned to the real
// nn services and payloads marshalled little-endian in the documented layouts
// below. They report neutral, functional metadata (no vendor firmware images).
//
// Every endpoint is thread-safe: mutable settings are guarded, matching the
// concurrency contract verified for the JNI bridge (services can be dispatched
// from multiple guest threads at once).

namespace lg::system {

// set:sys — command IDs aligned to nn::settings::ISystemSettingsServer.
//   3  GetFirmwareVersion   -> SystemVersion (0x100 bytes)
//   4  GetFirmwareVersion2  -> SystemVersion (0x100 bytes)
//   23 GetColorSetId        -> i32 (0=light, 1=dark)
//   24 SetColorSetId        <- i32
class SetSysService final : public IpcEndpoint {
public:
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;
private:
    mutable std::mutex mutex_;
    int32_t color_set_id_{0};
};

// set — command IDs aligned to nn::settings::ISettingsServer.
//   0 GetLanguageCode              -> u64 LanguageCode
//   1 GetAvailableLanguageCodes    -> i32 count, then count * u64
//   2 MakeLanguageCode             <- i32 index -> u64 LanguageCode
//   3 GetAvailableLanguageCodeCount-> i32
//   8 SetLanguageCode (Lobo ext.)  <- u64 LanguageCode
class SetService final : public IpcEndpoint {
public:
    SetService();
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;
private:
    mutable std::mutex mutex_;
    uint64_t language_code_;
};

// apm — performance mode.
//   0 GetPerformanceMode -> u32 (0=normal, 1=boost)
//   1 SetPerformanceMode <- u32
class ApmService final : public IpcEndpoint {
public:
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;
private:
    mutable std::mutex mutex_;
    uint32_t performance_mode_{0};
};

// time — user system clock.
//   0 GetCurrentTime   -> u64 POSIX seconds
//   1 GetTimeZoneName  -> UTF-8 string
class TimeService final : public IpcEndpoint {
public:
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;
};

std::unique_ptr<IpcEndpoint> make_set_sys_service();
std::unique_ptr<IpcEndpoint> make_set_service();
std::unique_ptr<IpcEndpoint> make_apm_service();
std::unique_ptr<IpcEndpoint> make_time_service();

// Pack an ASCII language code ("en-US") into a Switch LanguageCode u64.
uint64_t pack_language_code(const char* code) noexcept;

} // namespace lg::system
