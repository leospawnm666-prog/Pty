#pragma once
// P3.2: physical memory for the guest after the process is built (P3_2_DISENO.md §2.3).
//
// A bitmap of 64 KiB granules over the part of the guest arena that the P3.0 bump allocator
// did not take (image, main stack, TLS, P3.1 pages). 64 KiB keeps VA and PA congruent with
// 16 KiB host pages, so the JIT's fastmem window can map whole pages.
// First fit, NOT necessarily contiguous: an allocation is a list of runs. All-or-nothing.
// Pure bookkeeping: zero-filling and returning RAM is the caller's job (VmManager scrubs
// freed granules through AddressSpace).
#include <cstdint>
#include <optional>
#include <vector>

namespace lg::system {

struct PhysicalRun {
    uint64_t pa{};
    uint64_t size{};
    bool operator==(const PhysicalRun& o) const noexcept { return pa == o.pa && size == o.size; }
};

class ArenaAllocator {
public:
    static constexpr uint64_t kGranule = 0x10000;

    /** Manages [base, base + size). base and size are rounded inwards to granules. */
    void reset(uint64_t base, uint64_t size);
    void clear() noexcept { bits_.clear(); base_ = count_ = used_ = 0; }
    /** `bytes` (rounded up to granules) as runs in ascending PA order; nullopt (and nothing
     *  taken) if they do not fit. 0 bytes -> an empty list. */
    std::optional<std::vector<PhysicalRun>> allocate(uint64_t bytes);
    /** Frees whole granules. false (and nothing freed) if the range is not granule aligned,
     *  outside the managed range, or contains a granule that is not allocated. */
    bool free(uint64_t pa, uint64_t bytes);
    bool is_allocated(uint64_t pa) const noexcept;
    uint64_t used() const noexcept { return used_ * kGranule; }
    uint64_t capacity() const noexcept { return count_ * kGranule; }
    uint64_t base() const noexcept { return base_; }

private:
    bool test(uint64_t i) const noexcept { return (bits_[i >> 6] >> (i & 63)) & 1; }
    void set(uint64_t i, bool v) noexcept {
        if (v) bits_[i >> 6] |= 1ull << (i & 63); else bits_[i >> 6] &= ~(1ull << (i & 63));
    }
    std::vector<uint64_t> bits_;
    uint64_t base_{}, count_{}, used_{};
};

} // namespace lg::system
