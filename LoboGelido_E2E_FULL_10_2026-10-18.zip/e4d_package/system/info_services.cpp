#include "info_services.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>

namespace lg::system {
namespace {

// ---- little-endian payload writers -------------------------------------------
void put_u32(std::vector<uint8_t>& p, uint32_t v) {
    for (int i = 0; i < 4; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
void put_i32(std::vector<uint8_t>& p, int32_t v) { put_u32(p, static_cast<uint32_t>(v)); }
void put_u64(std::vector<uint8_t>& p, uint64_t v) {
    for (int i = 0; i < 8; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}

// ---- little-endian payload readers (return false on short buffer) ------------
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
bool get_i32(const std::vector<uint8_t>& p, size_t off, int32_t& out) {
    uint32_t u{}; if (!get_u32(p, off, u)) return false; out = static_cast<int32_t>(u); return true;
}
bool get_u64(const std::vector<uint8_t>& p, size_t off, uint64_t& out) {
    if (off + 8 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 8; ++i) out |= static_cast<uint64_t>(p[off + i]) << (8 * i);
    return true;
}

IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }

// The set of LanguageCodes Lobo Gélido reports as available, in nn::settings
// index order (ja, en-US, fr, ...). Representative firmware set.
const std::array<const char*, 18> kLanguages = {
    "ja", "en-US", "fr", "de", "it", "es", "zh-CN", "ko", "nl",
    "pt", "ru", "zh-TW", "en-GB", "fr-CA", "es-419", "zh-Hans", "zh-Hant", "pt-BR"};

// Build the 0x100-byte SystemVersion structure reported by GetFirmwareVersion.
// Layout follows the real nn::settings::system::FirmwareVersion record.
std::vector<uint8_t> build_system_version() {
    std::vector<uint8_t> v(0x100, 0);
    v[0] = 18;  // major
    v[1] = 0;   // minor
    v[2] = 0;   // micro
    v[4] = 1;   // revision_major
    v[5] = 0;   // revision_minor
    auto put_str = [&](size_t off, size_t cap, const char* s) {
        const size_t n = std::min(cap - 1, std::strlen(s));
        std::memcpy(v.data() + off, s, n);  // remaining bytes stay NUL
    };
    put_str(0x08, 0x20, "NX");                          // platform
    put_str(0x28, 0x40, "lobo-hle-0000000000000000");   // version hash (neutral)
    put_str(0x68, 0x18, "18.0.0");                       // display version
    put_str(0x80, 0x80, "Lobo Gélido HLE 18.0.0");       // display title (neutral)
    return v;
}

} // namespace

uint64_t pack_language_code(const char* code) noexcept {
    uint64_t packed = 0;
    if (!code) return 0;
    for (size_t i = 0; i < 8 && code[i] != '\0'; ++i)
        packed |= static_cast<uint64_t>(static_cast<uint8_t>(code[i])) << (8 * i);
    return packed;
}

// ============================ set:sys ========================================
core::Result<IpcMessage> SetSysService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 3:   // GetFirmwareVersion
        case 4: { // GetFirmwareVersion2
            IpcMessage out = reply(r.command_id);
            out.payload = build_system_version();
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 23: { // GetColorSetId
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_i32(out.payload, color_set_id_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 24: { // SetColorSetId
            int32_t id{};
            if (!get_i32(r.payload, 0, id)) return core::Result<IpcMessage>::Error("set:sys SetColorSetId: short payload");
            if (id != 0 && id != 1) return core::Result<IpcMessage>::Error("set:sys SetColorSetId: invalid id");
            { std::lock_guard lock(mutex_); color_set_id_ = id; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        default:
            return core::Result<IpcMessage>::Error("set:sys: unknown command");
    }
}

// ============================== set ==========================================
SetService::SetService() : language_code_(pack_language_code("en-US")) {}

core::Result<IpcMessage> SetService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // GetLanguageCode
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u64(out.payload, language_code_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 1: { // GetAvailableLanguageCodes
            IpcMessage out = reply(r.command_id);
            put_i32(out.payload, static_cast<int32_t>(kLanguages.size()));
            for (const char* c : kLanguages) put_u64(out.payload, pack_language_code(c));
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 2: { // MakeLanguageCode
            int32_t index{};
            if (!get_i32(r.payload, 0, index)) return core::Result<IpcMessage>::Error("set MakeLanguageCode: short payload");
            if (index < 0 || static_cast<size_t>(index) >= kLanguages.size())
                return core::Result<IpcMessage>::Error("set MakeLanguageCode: index out of range");
            IpcMessage out = reply(r.command_id);
            put_u64(out.payload, pack_language_code(kLanguages[static_cast<size_t>(index)]));
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 3: { // GetAvailableLanguageCodeCount
            IpcMessage out = reply(r.command_id);
            put_i32(out.payload, static_cast<int32_t>(kLanguages.size()));
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 8: { // SetLanguageCode (Lobo extension)
            uint64_t code{};
            if (!get_u64(r.payload, 0, code)) return core::Result<IpcMessage>::Error("set SetLanguageCode: short payload");
            { std::lock_guard lock(mutex_); language_code_ = code; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        default:
            return core::Result<IpcMessage>::Error("set: unknown command");
    }
}

// ============================== apm ==========================================
core::Result<IpcMessage> ApmService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // GetPerformanceMode
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u32(out.payload, performance_mode_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 1: { // SetPerformanceMode
            uint32_t mode{};
            if (!get_u32(r.payload, 0, mode)) return core::Result<IpcMessage>::Error("apm SetPerformanceMode: short payload");
            if (mode > 1) return core::Result<IpcMessage>::Error("apm SetPerformanceMode: invalid mode");
            { std::lock_guard lock(mutex_); performance_mode_ = mode; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        default:
            return core::Result<IpcMessage>::Error("apm: unknown command");
    }
}

// ============================== time =========================================
core::Result<IpcMessage> TimeService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // GetCurrentTime -> POSIX seconds
            IpcMessage out = reply(r.command_id);
            const auto now = std::chrono::system_clock::now().time_since_epoch();
            const auto secs = std::chrono::duration_cast<std::chrono::seconds>(now).count();
            put_u64(out.payload, static_cast<uint64_t>(secs));
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 1: { // GetTimeZoneName
            IpcMessage out = reply(r.command_id);
            const char tz[] = "UTC";
            out.payload.assign(tz, tz + sizeof(tz) - 1);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        default:
            return core::Result<IpcMessage>::Error("time: unknown command");
    }
}

std::unique_ptr<IpcEndpoint> make_set_sys_service() { return std::make_unique<SetSysService>(); }
std::unique_ptr<IpcEndpoint> make_set_service() { return std::make_unique<SetService>(); }
std::unique_ptr<IpcEndpoint> make_apm_service() { return std::make_unique<ApmService>(); }
std::unique_ptr<IpcEndpoint> make_time_service() { return std::make_unique<TimeService>(); }

} // namespace lg::system
