#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include "ipc.h"

// HLE of the Switch power-state manager (nn::psm / psm).
//
// Reports battery charge and charger type to guest titles. The frontend can feed
// the real device values through the Lobo setter commands (10/11); by default it
// reports a full battery on AC so titles that gate on power behave. Thread-safe.
//
// Charger types (nn::psm::ChargerType): 0 Unconnected, 1 EnoughPower (AC),
// 2 LowPower (USB).
//
//   0  GetBatteryChargePercentage -> [u32 percent 0..100]
//   1  GetChargerType             -> [u32 type]
//   10 SetBatteryChargePercentage <- [u32 percent]   (Lobo frontend bridge)
//   11 SetChargerType             <- [u32 type]       (Lobo frontend bridge)

namespace lg::system {

class PsmService final : public IpcEndpoint {
public:
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

    // Introspection (for diagnostics/tests).
    uint32_t charge_percent() const noexcept;
    uint32_t charger_type() const noexcept;

private:
    mutable std::mutex mutex_;
    uint32_t charge_percent_{100};
    uint32_t charger_type_{1}; // EnoughPower / AC
};

std::unique_ptr<IpcEndpoint> make_psm_service();

} // namespace lg::system
