// P6.0 (P6_0_DISENO.md §4): guest-written IPC servers.
//
// KSession/KLightSession/KPort created by the guest (CreateSession, CreatePort,
// ManageNamedPort), served by guest threads (AcceptSession, ReplyAndReceive*,
// ReplyAndReceiveLight) for requests from guest threads (SendSyncRequest*,
// SendAsyncRequestWithUserBuffer, SendSyncRequestLight). Message transfer follows Horizon's
// KServerSession::ReceiveRequest / SendReply as Atmosphère's mesosphere documents them
// (kern_k_server_session.cpp, kern_k_light_server_session.cpp, kern_k_client_port.cpp,
// kern_k_server_port.cpp, kern_svc_ipc.cpp, kern_svc_port.cpp, kern_svc_session.cpp,
// KPageTableBase::SetupForIpc*/CleanupForIpc*): special data (process id, copy and move
// handles), pointer (X) descriptors into the receiver's receive list (C), map-alias (A/B/W)
// buffers mapped into the alias region, and raw data. The code is Lobo's own.
//
// Lobo has one process, so client and server always share it (D-P6.0-2).
//
// D-P6.0-10: Horizon's server thread runs ReceiveRequest itself after its wait ends. Lobo
// has no kernel continuation after a wake, so the request is received INTO the waiting
// server thread when it arrives (try_deliver), and the thread wakes with it. The observable
// result is the same: the server's ReplyAndReceive returns with the message in its buffer.
#include <algorithm>
#include <cstring>

#include "kipc.h"

namespace lg::system {
namespace {
namespace kr = kresult_ipc;
namespace km = kmem;
constexpr uint32_t kSuccess = 0;
constexpr uint32_t kNotFound = kr::NotFound;
constexpr uint64_t kPage = km::PageSize;
constexpr uint32_t kReplyFlag = 1u << 31;   // KLightSession::ReplyFlag (w1 bit 31)

constexpr uint32_t bits(uint32_t v, unsigned lo, unsigned n) noexcept { return (v >> lo) & ((1u << n) - 1u); }

/** The header fields of a message (svc::ipc::MessageBuffer). */
struct Header {
    uint32_t type{}, nx{}, na{}, nb{}, nw{}, raw{}, recv_mode{}, recv_offset{};
    bool special{}, pid{};
    uint32_t ncopy{}, nmove{};
    uint32_t special_index() const { return 2 + (special ? 1 : 0); }
    uint32_t x_index() const { return special_index() + (pid ? 2 : 0) + ncopy + nmove; }
    uint32_t map_index() const { return x_index() + nx * 2; }
    uint32_t raw_index() const { return map_index() + (na + nb + nw) * 3; }
    uint32_t raw_end() const { return raw_index() + raw; }
    uint32_t recv_index() const { return recv_offset ? recv_offset : raw_end(); }
    uint32_t entries() const { return recv_mode == 2 ? 1 : recv_mode > 2 ? recv_mode - 2 : 0; }
    size_t buffer_size() const { return size_t{recv_index()} * 4 + size_t{entries()} * 8; }   // GetMessageBufferSize
};
Header decode(const std::vector<uint32_t>& w) {
    Header h;
    h.type = bits(w[0], 0, 16);
    h.nx = bits(w[0], 16, 4); h.na = bits(w[0], 20, 4); h.nb = bits(w[0], 24, 4); h.nw = bits(w[0], 28, 4);
    h.raw = bits(w[1], 0, 10);
    h.recv_mode = bits(w[1], 10, 4);
    h.recv_offset = bits(w[1], 20, 11);
    h.special = bits(w[1], 31, 1) != 0;
    if (h.special && w.size() > 2) {
        h.pid = bits(w[2], 0, 1) != 0;
        h.ncopy = bits(w[2], 1, 4);
        h.nmove = bits(w[2], 5, 4);
    }
    return h;
}
hipc::StaticDescriptor unpack_x(const uint32_t* w) {
    return {bits(w[0], 0, 4), uint64_t{w[1]} | (uint64_t{bits(w[0], 12, 4)} << 32) | (uint64_t{bits(w[0], 6, 3)} << 36),
            bits(w[0], 16, 16)};
}
hipc::BufferDescriptor unpack_map(const uint32_t* w) {
    return {uint64_t{w[1]} | (uint64_t{bits(w[2], 28, 4)} << 32) | (uint64_t{bits(w[2], 2, 3)} << 36),
            uint64_t{w[0]} | (uint64_t{bits(w[2], 24, 4)} << 32), bits(w[2], 0, 2)};
}
hipc::ReceiveEntry unpack_recv(const uint32_t* w) {
    return {uint64_t{w[0]} | (uint64_t{bits(w[1], 0, 7)} << 32), bits(w[1], 16, 16)};
}
uint32_t map_state(uint32_t mode) {   // GetMapAliasMemoryState
    switch (mode) {
        case 0: return km::Ipc;
        case 1: return km::NonSecureIpc;
        case 3: return km::NonDeviceIpc;
        default: return 0;
    }
}
uint32_t test_state_of(uint32_t state) {
    return state == km::Ipc ? km::FlagCanUseIpc : state == km::NonSecureIpc ? km::FlagCanUseNonSecureIpc : km::FlagCanUseNonDeviceIpc;
}

/** The receiver's receive list (the ReceiveList helper of kern_k_server_session.cpp). */
struct ReceiveList {
    uint32_t mode{};
    std::vector<hipc::ReceiveEntry> entries;
    uint64_t msg_end{}, space_end{};
    bool is_index() const { return mode > 2; }
    bool to_message_buffer() const { return mode == 1; }
    uint64_t get(uint64_t size, int& key) const {
        switch (mode) {
            case 0: return 0;
            case 1: {
                const uint64_t buf = (msg_end + key + 15) & ~uint64_t{15};
                if (buf < buf + size && buf + size <= space_end) { key = static_cast<int>(buf + size - msg_end); return buf; }
                return 0;
            }
            case 2: {
                const auto& e = entries[0];
                const uint64_t buf = (e.address + key + 15) & ~uint64_t{15};
                if (buf < buf + size && e.address < e.address + e.size && buf + size <= e.address + e.size) {
                    key = static_cast<int>(buf + size - e.address);
                    return buf;
                }
                return 0;
            }
            default:
                if (key >= 0 && static_cast<size_t>(key) < entries.size()) {
                    const auto& e = entries[static_cast<size_t>(key)];
                    if (e.address < e.address + e.size && e.size >= size) return e.address;
                }
                return 0;
        }
    }
};
ReceiveList receive_list(const std::vector<uint32_t>& dst, const Header& h, uint64_t dst_va, uint64_t dst_size,
                         uint32_t src_end_offset) {
    ReceiveList rl;
    rl.mode = h.recv_mode;
    rl.msg_end = dst_va + 4ull * src_end_offset;
    rl.space_end = dst_va + dst_size;
    const uint32_t idx = h.recv_index();
    for (uint32_t k = 0; k < h.entries() && idx + 2 * k + 1 < dst.size(); ++k) rl.entries.push_back(unpack_recv(&dst[idx + 2 * k]));
    return rl;
}
} // namespace

// ==== objects =================================================================================

KernelIpc::GuestSession* KernelIpc::guest_session(uint32_t handle, KObjectType type) {
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != type) return nullptr;
    auto it = gsessions_.find(o->id);
    return it == gsessions_.end() ? nullptr : &it->second;
}

KernelIpc::GuestPort* KernelIpc::guest_port(uint32_t handle, KObjectType type) {
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != type) return nullptr;
    auto it = gports_.find(o->id);
    return it == gports_.end() ? nullptr : &it->second;
}

bool KernelIpc::is_guest_client_session(uint32_t handle) const {
    const KObjectRef* o = config_.handles->get(handle);
    return o && o->type == KObjectType::ClientSession && gsessions_.count(o->id);
}

uint32_t KernelIpc::new_session(bool light, uint64_t port, uint64_t& out_id) {
    // KScopedResourceReservation(SessionCountMax): Lobo's process has its own resource limit
    if (config_.reserve_session && !config_.reserve_session()) return kr::LimitReached;
    out_id = next_session_++;   // one id space with the HLE sessions
    GuestSession s;
    s.light = light;
    s.port = port;
    gsessions_.emplace(out_id, std::move(s));
    return kSuccess;
}

uint32_t KernelIpc::create_session(bool light, uint64_t /*name*/, uint32_t& out_server, uint32_t& out_client) {
    out_server = out_client = 0;
    uint64_t id = 0;
    if (const uint32_t rc = new_session(light, 0, id); rc) return rc;
    const KObjectType st = light ? KObjectType::LightServerSession : KObjectType::ServerSession;
    const KObjectType ct = light ? KObjectType::LightClientSession : KObjectType::ClientSession;
    const auto sh = config_.handles->add({st, id});
    if (!sh) { gsessions_.erase(id); return kr::OutOfHandles; }
    const auto ch = config_.handles->add({ct, id});
    if (!ch) { config_.handles->close(*sh); gsessions_.erase(id); return kr::OutOfHandles; }
    auto& s = gsessions_.at(id);
    s.server_refs = 1;
    s.client_refs = 1;
    out_server = *sh;
    out_client = *ch;
    return kSuccess;
}

uint32_t KernelIpc::create_port(int32_t max_sessions, bool light, uint64_t /*name*/, uint32_t& out_server, uint32_t& out_client) {
    out_server = out_client = 0;
    if (max_sessions <= 0) return kr::OutOfRange;
    const uint64_t id = next_port_++;
    GuestPort p;
    p.light = light;
    p.max_sessions = max_sessions;
    gports_.emplace(id, std::move(p));
    const auto ch = config_.handles->add({KObjectType::ClientPort, id});
    if (!ch) { gports_.erase(id); return kr::OutOfHandles; }
    const auto sh = config_.handles->add({KObjectType::ServerPort, id});
    if (!sh) { config_.handles->close(*ch); gports_.erase(id); return kr::OutOfHandles; }
    auto& gp = gports_.at(id);
    gp.client_refs = gp.server_refs = 1;
    out_server = *sh;
    out_client = *ch;
    return kSuccess;
}

uint32_t KernelIpc::read_port_name(uint64_t address, std::string& out) const {
    // kern_svc_port.cpp GetPortName: up to 12 bytes; the name must end in NUL inside them.
    char name[kNameMax] = {};
    bool terminated = false;
    for (size_t i = 0; i < kNameMax; ++i) {
        char ch = 0;
        if (!config_.memory->read(address + i, &ch, 1)) return kr::InvalidPointer;
        name[i] = ch;
        if (ch == 0) { terminated = true; break; }
    }
    if (!terminated) return kr::OutOfRange;
    out = name;
    return kSuccess;
}

uint32_t KernelIpc::manage_named_port(uint64_t name_address, int32_t max_sessions, uint32_t& out_server) {
    out_server = 0;
    std::string name;
    if (const uint32_t rc = read_port_name(name_address, name); rc) return rc;
    if (max_sessions < 0) return kr::OutOfRange;
    if (max_sessions == 0) {
        // KObjectName::Delete<KClientPort>(name): the name goes; the port lives on
        if (auto g = gnames_.find(name); g != gnames_.end()) {
            const uint64_t port = g->second;
            gnames_.erase(g);
            if (auto p = gports_.find(port); p != gports_.end()) {
                p->second.name.clear();
                if (p->second.client_refs) --p->second.client_refs;
                if (p->second.client_refs == 0) p->second.client_closed = true;
                maybe_finalize_port(port);
            }
            return kSuccess;
        }
        if (ports_.erase(name)) return kSuccess;   // an HLE named port: its name, too
        return kNotFound;
    }
    uint32_t client = 0;
    if (const uint32_t rc = create_port(max_sessions, false, 0, out_server, client); rc) return rc;
    const KObjectRef* o = config_.handles->get(client);
    const uint64_t port = o->id;
    config_.handles->close(client);   // the name table keeps the client port's reference
    if (gnames_.count(name) || ports_.count(name)) {   // KObjectName::NewFromName: InvalidState
        config_.handles->close(out_server);
        gports_.erase(port);
        out_server = 0;
        return kr::InvalidState;
    }
    gnames_[name] = port;
    gports_.at(port).name = name;
    return kSuccess;
}

uint32_t KernelIpc::port_create_session(uint64_t port_id, uint32_t& out_handle) {
    // KClientPort::CreateSession / CreateLightSession + KPort::EnqueueSession
    out_handle = 0;
    auto pit = gports_.find(port_id);
    if (pit == gports_.end()) return kr::PortClosed;
    const bool light = pit->second.light;
    if (config_.handles->size() >= HandleTable::kCapacity) return kr::OutOfHandles;   // handle_table.Reserve
    if (config_.reserve_session && !config_.reserve_session()) return kr::LimitReached;
    if (pit->second.num_sessions >= pit->second.max_sessions) return kr::OutOfSessions;
    if (pit->second.server_closed) return kr::PortClosed;
    uint64_t id = 0;
    if (const uint32_t rc = new_session(light, port_id, id); rc) return rc;
    auto& p = gports_.at(port_id);
    ++p.num_sessions;
    const auto ch = config_.handles->add({light ? KObjectType::LightClientSession : KObjectType::ClientSession, id});
    if (!ch) { --p.num_sessions; gsessions_.erase(id); return kr::OutOfHandles; }
    auto& s = gsessions_.at(id);
    s.client_refs = 1;
    s.queued = true;
    p.queue.push_back(id);
    if (p.queue.size() == 1) config_.kthreads->notify_external(kExtServerPort | port_id);
    out_handle = *ch;
    return kSuccess;
}

uint32_t KernelIpc::connect_to_port(uint32_t port_handle, uint32_t& out_handle) {
    out_handle = 0;
    const KObjectRef* o = config_.handles->get(port_handle);
    if (!o || o->type != KObjectType::ClientPort || !gports_.count(o->id)) return kr::InvalidHandle;
    return port_create_session(o->id, out_handle);
}

uint32_t KernelIpc::accept_session(uint32_t port_handle, uint32_t& out_handle) {
    out_handle = 0;
    GuestPort* p = guest_port(port_handle, KObjectType::ServerPort);
    if (!p) return kr::InvalidHandle;
    if (config_.handles->size() >= HandleTable::kCapacity) return kr::OutOfHandles;
    if (p->queue.empty()) return kNotFound;
    const uint64_t id = p->queue.front();
    auto& s = gsessions_.at(id);
    const auto h = config_.handles->add({s.light ? KObjectType::LightServerSession : KObjectType::ServerSession, id});
    if (!h) return kr::OutOfHandles;
    p->queue.pop_front();
    s.queued = false;
    s.server_refs = 1;
    out_handle = *h;
    return kSuccess;
}

bool KernelIpc::add_handle_ref(const KObjectRef& o) {
    switch (o.type) {
        case KObjectType::ClientSession: case KObjectType::LightClientSession: {
            auto it = gsessions_.find(o.id);
            if (it == gsessions_.end()) return false;
            ++it->second.client_refs;
            return true;
        }
        case KObjectType::ServerSession: case KObjectType::LightServerSession: {
            auto it = gsessions_.find(o.id);
            if (it == gsessions_.end()) return false;
            ++it->second.server_refs;
            return true;
        }
        case KObjectType::ClientPort: case KObjectType::ServerPort: {
            auto it = gports_.find(o.id);
            if (it == gports_.end()) return false;
            ++(o.type == KObjectType::ClientPort ? it->second.client_refs : it->second.server_refs);
            return true;
        }
        default: return false;
    }
}

// ==== lifetime ================================================================================

void KernelIpc::guest_handle_closed(const KObjectRef& o) {
    switch (o.type) {
        case KObjectType::ClientSession: case KObjectType::LightClientSession: {
            auto it = gsessions_.find(o.id);
            if (it == gsessions_.end()) return;
            if (it->second.client_refs) --it->second.client_refs;
            if (it->second.client_refs == 0 && !it->second.client_closed) on_guest_client_closed(o.id);
            maybe_finalize_session(o.id);
            return;
        }
        case KObjectType::ServerSession: case KObjectType::LightServerSession: {
            auto it = gsessions_.find(o.id);
            if (it == gsessions_.end()) return;
            if (it->second.server_refs) --it->second.server_refs;
            if (it->second.server_refs == 0 && !it->second.queued && !it->second.server_closed) on_guest_server_closed(o.id);
            maybe_finalize_session(o.id);
            return;
        }
        case KObjectType::ClientPort: {
            auto it = gports_.find(o.id);
            if (it == gports_.end()) return;
            if (it->second.client_refs) --it->second.client_refs;
            if (it->second.client_refs == 0) it->second.client_closed = true;   // KPort::OnClientClosed
            maybe_finalize_port(o.id);
            return;
        }
        case KObjectType::ServerPort: {
            auto it = gports_.find(o.id);
            if (it == gports_.end()) return;
            if (it->second.server_refs) --it->second.server_refs;
            if (it->second.server_refs == 0 && !it->second.server_closed) {
                // KServerPort::Destroy: OnServerClosed, then the queued sessions are closed
                it->second.server_closed = true;
                const std::deque<uint64_t> queued = std::move(it->second.queue);
                it->second.queue.clear();
                for (uint64_t sid : queued) {
                    auto s = gsessions_.find(sid);
                    if (s == gsessions_.end()) continue;
                    s->second.queued = false;
                    on_guest_server_closed(sid);
                    maybe_finalize_session(sid);
                }
            }
            maybe_finalize_port(o.id);
            return;
        }
        default: return;
    }
}

void KernelIpc::maybe_finalize_session(uint64_t id) {
    auto it = gsessions_.find(id);
    if (it == gsessions_.end()) return;
    const GuestSession& s = it->second;
    if (s.client_refs || s.server_refs || s.queued) return;
    const uint64_t port = s.port;
    gsessions_.erase(it);
    // KSession::Finalize -> KClientPort::OnSessionFinalized
    if (port) {
        auto p = gports_.find(port);
        if (p != gports_.end()) {
            const bool was_full = p->second.num_sessions == p->second.max_sessions;
            if (p->second.num_sessions) --p->second.num_sessions;
            if (was_full) config_.kthreads->notify_external(kExtClientPort | port);
            maybe_finalize_port(port);
        }
    }
}

void KernelIpc::maybe_finalize_port(uint64_t id) {
    auto it = gports_.find(id);
    if (it == gports_.end()) return;
    if (it->second.client_refs || it->second.server_refs || it->second.num_sessions || !it->second.queue.empty()) return;
    gports_.erase(it);
}

void KernelIpc::cleanup_maps(GuestRequest& r) {
    // CleanupMap: the server's mappings go, the client's pages are unlocked
    for (const auto& m : r.maps) {
        config_.vm->ipc_unmap_server(m.server, m.size, m.state);
        config_.vm->ipc_unlock_client(m.client, m.size, m.state);
    }
    r.maps.clear();
}

void KernelIpc::finish_request(GuestRequest& r, uint32_t client_result) {
    KThread* t = config_.kthreads->find(r.thread);
    if (r.event) {
        // async: ReplyAsyncError + UnlockForIpcUserBuffer + Signal
        if (client_result != kSuccess) {
            const uint32_t v = client_result;
            config_.vm->write_linear(r.message + 8, &v, 4);   // MessageBuffer::SetAsyncResult (word 2)
        }
        config_.vm->unlock_memory(r.message, r.size, km::FlagCanIpcUserBuffer, km::FlagCanIpcUserBuffer, 0, 0, km::All,
                                  km::AttrLocked, km::PermRW, km::AttrLocked, nullptr);
        config_.kthreads->signal_kernel_event(r.event);
        config_.kthreads->release_kernel_event(r.event);
        r.event = 0;
        return;
    }
    if (r.message)   // SendSyncRequestWithUserBuffer: the svc unlocks the buffer on the way out
        config_.vm->unlock_memory(r.message, r.size, km::FlagCanIpcUserBuffer, km::FlagCanIpcUserBuffer, 0, 0, km::All,
                                  km::AttrLocked, km::PermRW, km::AttrLocked, nullptr);
    if (t) config_.kthreads->end_ipc_wait(*t, client_result);
}

void KernelIpc::on_guest_client_closed(uint64_t id) {
    GuestSession& s = gsessions_.at(id);
    s.client_closed = true;
    if (s.light) {
        // KLightServerSession::OnClientClosed -> CleanupRequests
        auto end = [&](uint64_t tid) { if (KThread* t = config_.kthreads->find(tid)) config_.kthreads->end_ipc_wait(*t, kr::SessionClosed); };
        if (s.light_current) { end(s.light_current); s.light_current = 0; s.light_server = 0; }
        for (uint64_t tid : s.light_requests) end(tid);
        s.light_requests.clear();
        if (s.light_waiting) { end(s.light_waiting); s.light_waiting = 0; }
        return;
    }
    if (s.server_closed) return;
    // KServerSession::OnClientClosed: pending asynchronous requests fail with SessionClosed.
    // A pending synchronous request (only possible when another thread closed the handle)
    // ends the same way (D-P6.0-10: Lobo does not leave its thread waiting forever).
    std::deque<GuestRequest> pending = std::move(s.requests);
    s.requests.clear();
    for (auto& r : pending) finish_request(r, kr::SessionClosed);
    // NotifyAvailable(SessionClosed): every waiter on the server session wakes with it
    const uint64_t obj = KernelThreads::kExternalObject | kExtServerSession | id;
    for (uint64_t tid : config_.kthreads->waiters_of(obj)) config_.kthreads->end_sync_wait(tid, obj, kr::SessionClosed);
}

void KernelIpc::on_guest_server_closed(uint64_t id) {
    GuestSession& s = gsessions_.at(id);
    s.server_closed = true;
    if (s.light) {
        auto end = [&](uint64_t tid) { if (KThread* t = config_.kthreads->find(tid)) config_.kthreads->end_ipc_wait(*t, kr::SessionClosed); };
        if (s.light_current) { end(s.light_current); s.light_current = 0; s.light_server = 0; }
        for (uint64_t tid : s.light_requests) end(tid);
        s.light_requests.clear();
        if (s.light_waiting) { end(s.light_waiting); s.light_waiting = 0; }
        return;
    }
    // KServerSession::CleanupRequests: the current and the pending requests end
    std::vector<GuestRequest> all;
    if (s.current) { all.push_back(std::move(*s.current)); s.current.reset(); }
    for (auto& r : s.requests) all.push_back(std::move(r));
    s.requests.clear();
    for (auto& r : all) {
        cleanup_maps(r);
        finish_request(r, kr::SessionClosed);
    }
}

// ==== the sync-object side ====================================================================

std::optional<uint64_t> KernelIpc::sync_object_of(uint32_t handle) const {
    const KObjectRef* o = config_.handles->get(handle);
    if (!o) return std::nullopt;
    switch (o->type) {
        case KObjectType::ServerSession: if (gsessions_.count(o->id)) return kExtServerSession | o->id; break;
        case KObjectType::ServerPort: if (gports_.count(o->id)) return kExtServerPort | o->id; break;
        case KObjectType::ClientPort: if (gports_.count(o->id)) return kExtClientPort | o->id; break;
        default: break;
    }
    return std::nullopt;
}

bool KernelIpc::sync_signaled(uint64_t ext) const {
    const uint64_t kind = ext & ~kExtIdMask, id = ext & kExtIdMask;
    if (kind == kExtServerSession) {
        auto it = gsessions_.find(id);
        if (it == gsessions_.end()) return false;
        const GuestSession& s = it->second;
        if (s.client_closed) return true;   // KServerSession::IsSignaledImpl
        return !s.requests.empty() && !s.current;
    }
    auto it = gports_.find(id);
    if (it == gports_.end()) return false;
    if (kind == kExtServerPort) return !it->second.queue.empty();
    return it->second.num_sessions < it->second.max_sessions;   // KClientPort::IsSignaled
}

void KernelIpc::on_wait_ended(uint64_t tid) {
    auto it = server_waits_.find(tid);
    if (it == server_waits_.end()) return;
    const ServerWait w = it->second;
    server_waits_.erase(it);
    if (w.message)   // ReplyAndReceiveWithUserBuffer: the svc unlocks its buffer on the way out
        config_.vm->unlock_memory(w.message, w.size, km::FlagCanIpcUserBuffer, km::FlagCanIpcUserBuffer, 0, 0, km::All,
                                  km::AttrLocked, km::PermRW, km::AttrLocked, nullptr);
}

void KernelIpc::try_deliver(uint64_t id) {
    // NotifyAvailable on a server session with a request: plain WaitSynchronization waiters
    // wake; a ReplyAndReceive waiter receives the request (D-P6.0-10).
    const uint64_t obj = KernelThreads::kExternalObject | kExtServerSession | id;
    for (uint64_t tid : config_.kthreads->waiters_of(obj)) {
        auto it = gsessions_.find(id);
        if (it == gsessions_.end() || !sync_signaled(kExtServerSession | id)) return;
        if (it->second.client_closed) {
            config_.kthreads->end_sync_wait(tid, obj, kr::SessionClosed);
            continue;
        }
        auto w = server_waits_.find(tid);
        if (w == server_waits_.end()) { config_.kthreads->end_sync_wait(tid, obj, kSuccess); continue; }
        KThread* server = config_.kthreads->find(tid);
        if (!server) continue;
        const ServerWait wait = w->second;
        // the server's buffer is locked for the svc; the kernel writes it through the linear map
        uint32_t rc = kNotFound;
        while (rc == kNotFound && sync_signaled(kExtServerSession | id)) {
            rc = receive_request(id, *server, wait.message, wait.size);
            if (rc == kNotFound && !gsessions_.count(id)) break;
        }
        if (rc == kNotFound) continue;   // nothing delivered to this waiter: it keeps waiting
        config_.kthreads->end_sync_wait(tid, obj, rc);
    }
}

// ==== message transfer ========================================================================

bool KernelIpc::read_words(const KThread& t, uint64_t va, uint64_t size, std::vector<uint32_t>& out) const {
    if (!va) {   // the thread's TLS message buffer
        out.assign(hipc::kMessageWords, 0);
        return t.tls_va && config_.memory->read(t.tls_va, out.data(), hipc::kMessageBytes);
    }
    out.assign(static_cast<size_t>(size / 4), 0);
    return config_.vm->read_linear(va, out.data(), size);
}

bool KernelIpc::write_words(const KThread& t, uint64_t va, const std::vector<uint32_t>& w, size_t count) {
    count = std::min(count, w.size());
    if (!va) return t.tls_va && config_.memory->write(t.tls_va, w.data(), count * 4);
    return config_.vm->write_linear(va, w.data(), count * 4);
}

uint32_t KernelIpc::receive_message(KThread& server, uint64_t dst_va, uint64_t dst_size, GuestRequest& req, bool& broken) {
    // KServerSession ReceiveMessage: client (src) -> server (dst)
    broken = false;
    KThread* client = config_.kthreads->find(req.thread);
    if (!client) return kr::SessionClosed;
    const bool dst_user = dst_va != 0, src_user = req.message != 0;
    std::vector<uint32_t> dst, src;
    if (!read_words(server, dst_va, dst_size, dst) || !read_words(*client, req.message, req.size, src)) return kr::InvalidCurrentMemory;
    const uint64_t dst_bytes = dst_user ? dst_size : hipc::kMessageBytes, src_bytes = src_user ? req.size : hipc::kMessageBytes;
    const uint64_t dst_base = dst_user ? dst_va : server.tls_va;
    const Header dh = decode(dst), sh = decode(src);
    if (dh.buffer_size() > dst_bytes || sh.buffer_size() > src_bytes) return kr::InvalidCombination;
    if (dh.recv_offset && dh.recv_offset < dh.raw_end()) return kr::InvalidCombination;
    const uint32_t src_end = sh.raw_end();
    if (dst_bytes < uint64_t{src_end} * 4) return kr::MessageTooLarge;
    const uint32_t recv_idx = dh.recv_index();
    const ReceiveList rl = receive_list(dst, dh, dst_base, dst_bytes, src_end);
    if (sh.special && sh.nmove != 0) return kr::InvalidCombination;
    std::vector<uint32_t> out = dst;   // the kernel writes over the server's buffer
    std::vector<uint32_t> added;       // handles created for the server (CleanupSpecialData)
    uint32_t offset = 2;
    uint32_t result = kSuccess;
    auto fail = [&](uint32_t rc) {
        cleanup_maps(req);
        for (uint32_t h : added) {
            const KObjectRef* o = config_.handles->get(h);
            const KObjectRef obj = o ? *o : KObjectRef{};
            if (config_.handles->close(h) && config_.release) config_.release(obj);
        }
        broken = offset > recv_idx;
        if (broken) {   // what was written stays; the handle slots are cleared
            write_words(server, dst_va, out, std::min<size_t>(out.size(), offset));
        }
        return rc;
    };
    out[0] = src[0];
    out[1] = src[1];
    if (sh.special) {
        out[2] = src[2];
        offset = 3;
        if (sh.pid) {   // the kernel writes the sender's process id
            out[offset] = static_cast<uint32_t>(config_.process_id);
            out[offset + 1] = static_cast<uint32_t>(config_.process_id >> 32);
            offset += 2;
        }
        for (uint32_t i = 0; i < sh.ncopy; ++i, ++offset) {
            const uint32_t h = src[offset];
            uint32_t dh_ = 0;
            if (result == kSuccess && h != 0) {
                const auto obj = config_.handles->resolve(h, client->id, config_.process_id);   // GetObjectForIpc
                if (obj && obj->type != KObjectType::InterruptEvent) {
                    const auto nh = config_.handles->add(*obj);
                    if (!nh) result = kr::OutOfHandles;
                    else {
                        if (config_.retain) config_.retain(*obj);
                        dh_ = *nh;
                        added.push_back(*nh);
                    }
                } else {
                    result = kr::InvalidHandle;
                }
            }
            out[offset] = dh_;
        }
        if (result != kSuccess) return fail(result);
    }
    int pointer_key = 0;
    for (uint32_t i = 0; i < sh.nx; ++i, offset += 2) {
        const auto d = unpack_x(&src[offset]);
        uint64_t recv = 0;
        if (d.size > 0) {
            if (rl.is_index()) pointer_key = static_cast<int>(d.index);
            recv = rl.get(d.size, pointer_key);
            if (!recv) return fail(kr::OutOfResource);
            if (config_.vm->check_each(d.address, d.size, km::FlagLinearMapped, km::FlagLinearMapped, km::PermR, km::PermR,
                                       km::AttrUncached, 0))
                return fail(kr::InvalidCurrentMemory);
            std::vector<uint8_t> data(static_cast<size_t>(d.size));
            if (!config_.vm->read_linear(d.address, data.data(), d.size)) return fail(kr::InvalidCurrentMemory);
            const bool ok = (dst_user && rl.to_message_buffer()) ? config_.vm->write_linear(recv, data.data(), d.size)
                                                                  : config_.memory->write(recv, data.data(), data.size());
            if (!ok) return fail(kr::InvalidCurrentMemory);
        }
        hipc::pack_static({d.index, recv, d.size}, &out[offset]);
    }
    const uint32_t nmap = sh.na + sh.nb + sh.nw;
    for (uint32_t i = 0; i < nmap; ++i, offset += 3) {
        const auto d = unpack_map(&src[offset]);
        const bool write = i >= sh.na;                                // B and W: RW
        const bool send = i < sh.na || i >= sh.na + sh.nb;            // A and W carry data
        const uint32_t state = map_state(d.mode);
        if (!state) return fail(kr::InvalidCombination);
        uint64_t server_address = 0;
        if (d.size > 0) {
            if (const uint32_t rc = config_.vm->ipc_lock_client(d.address, d.size, state, write); rc) return fail(rc);
            if (const uint32_t rc = config_.vm->ipc_map_server(d.address, d.size, state, write, send, server_address); rc) {
                config_.vm->ipc_unlock_client(d.address, d.size, state);
                return fail(rc);
            }
            req.maps.push_back({d.address, server_address, d.size, state,
                                static_cast<uint8_t>(i < sh.na ? 0 : i < sh.na + sh.nb ? 1 : 2)});
        }
        hipc::pack_buffer({server_address, d.size, d.mode}, &out[offset]);
    }
    for (uint32_t i = 0; i < sh.raw; ++i, ++offset) out[offset] = src[offset];
    // only the message itself is written: the receive area after it holds the X data
    if (!write_words(server, dst_va, out, src_end)) return fail(kr::InvalidCurrentMemory);
    return kSuccess;
}

uint32_t KernelIpc::send_message(KThread& server, uint64_t src_va, uint64_t src_size, GuestRequest& req) {
    // KServerSession SendMessage: server (src) -> client (dst)
    KThread* client = config_.kthreads->find(req.thread);
    if (!client) { cleanup_maps(req); return kr::SessionClosed; }
    const bool src_user = src_va != 0, dst_user = req.message != 0;
    std::vector<uint32_t> dst, src;
    if (!read_words(*client, req.message, req.size, dst) || !read_words(server, src_va, src_size, src)) {
        cleanup_maps(req);
        return kr::InvalidCurrentMemory;
    }
    const uint64_t dst_bytes = dst_user ? req.size : hipc::kMessageBytes, src_bytes = src_user ? src_size : hipc::kMessageBytes;
    const uint64_t dst_base = dst_user ? req.message : client->tls_va;
    const Header dh = decode(dst), sh = decode(src);
    bool processed_special = false;
    std::vector<uint32_t> added;
    auto fail = [&](uint32_t rc) {
        if (processed_special) {
            for (uint32_t h : added) {
                const KObjectRef* o = config_.handles->get(h);
                const KObjectRef obj = o ? *o : KObjectRef{};
                if (config_.handles->close(h) && config_.release) config_.release(obj);
            }
        } else if (sh.special) {
            // CleanupServerHandles: the server's move handles are dropped
            uint32_t off = sh.special_index() + (sh.pid ? 2 : 0) + sh.ncopy;
            for (uint32_t i = 0; i < sh.nmove && off < src.size(); ++i, ++off) {
                const KObjectRef* o = config_.handles->get(src[off]);
                const KObjectRef obj = o ? *o : KObjectRef{};
                if (config_.handles->close(src[off]) && config_.release) config_.release(obj);
            }
        }
        cleanup_maps(req);
        return rc;
    };
    if (sh.buffer_size() > src_bytes || dh.buffer_size() > dst_bytes) return fail(kr::InvalidCombination);
    if (dh.recv_offset && dh.recv_offset < dh.raw_end()) return fail(kr::InvalidCombination);
    const uint32_t src_end = sh.raw_end();
    if (dst_bytes < uint64_t{src_end} * 4) return fail(kr::MessageTooLarge);
    if (sh.na || sh.nb || sh.nw) return fail(kr::InvalidCombination);
    const ReceiveList rl = receive_list(dst, dh, dst_base, dst_bytes, src_end);
    // ProcessSendMessageReceiveMapping: the partial pages of B/W buffers go back to the client
    for (const auto& m : req.maps) {
        if (m.kind == 0 || m.size == 0) continue;
        const uint64_t a_start = m.client & ~(kPage - 1), a_end = (m.client + m.size + kPage - 1) & ~(kPage - 1);
        const uint64_t m_start = (m.client + kPage - 1) & ~(kPage - 1), m_end = (m.client + m.size) & ~(kPage - 1);
        const uint64_t src_map_end = (m.server + m.size) & ~(kPage - 1);
        const uint32_t ts = test_state_of(m.state);
        const uint32_t attr_mask = m.state == km::Ipc ? (km::AttrUncached | km::AttrDeviceShared | km::AttrLocked)
                                                      : (km::AttrUncached | km::AttrLocked);
        auto copy_back = [&](uint64_t client_at, uint64_t server_at, uint64_t n) -> uint32_t {
            if (config_.vm->check_each(client_at, n, ts, ts, km::PermRW, km::PermRW, attr_mask, 0)) return kr::InvalidCurrentMemory;
            std::vector<uint8_t> b(static_cast<size_t>(n));
            if (!config_.memory->read(server_at, b.data(), b.size())) return kr::InvalidCurrentMemory;
            return config_.vm->write_linear(client_at, b.data(), n) ? kSuccess : kr::InvalidCurrentMemory;
        };
        if (a_start != m_start)
            if (const uint32_t rc = copy_back(m.client, m.server, std::min(m.size, m_start - m.client)); rc) return fail(rc);
        if (m_end < a_end && (a_start == m_start || a_start < m_end))
            if (const uint32_t rc = copy_back(m_end, src_map_end, m.client + m.size - m_end); rc) return fail(rc);
    }
    std::vector<uint32_t> out = dst;
    out[0] = src[0];
    out[1] = src[1];
    uint32_t offset = 2;
    processed_special = true;
    uint32_t result = kSuccess;
    if (sh.special) {
        out[2] = src[2];
        offset = 3;
        if (sh.pid) {
            out[offset] = static_cast<uint32_t>(config_.process_id);
            out[offset + 1] = static_cast<uint32_t>(config_.process_id >> 32);
            offset += 2;
        }
        for (uint32_t i = 0; i < sh.ncopy; ++i, ++offset) {
            const uint32_t h = src[offset];
            uint32_t nh_ = 0;
            if (result == kSuccess && h != 0) {
                const auto obj = config_.handles->resolve(h, server.id, config_.process_id);
                if (obj && obj->type != KObjectType::InterruptEvent) {
                    const auto nh = config_.handles->add(*obj);
                    if (!nh) result = kr::OutOfHandles;
                    else { if (config_.retain) config_.retain(*obj); nh_ = *nh; added.push_back(*nh); }
                } else {
                    result = kr::InvalidHandle;
                }
            }
            out[offset] = nh_;
        }
        for (uint32_t i = 0; i < sh.nmove; ++i, ++offset) {
            const uint32_t h = src[offset];
            uint32_t nh_ = 0;
            if (h != 0) {
                const KObjectRef* o = HandleTable::is_pseudo(h) ? nullptr : config_.handles->get(h);   // without pseudo
                if (result == kSuccess && o) {
                    const KObjectRef obj = *o;
                    config_.handles->close(h);   // the reference moves to the new handle
                    const auto nh = config_.handles->add(obj);
                    if (!nh) { result = kr::OutOfHandles; if (config_.release) config_.release(obj); }
                    else { nh_ = *nh; added.push_back(*nh); }
                } else if (result == kSuccess) {
                    result = kr::InvalidHandle;
                } else if (o) {
                    const KObjectRef obj = *o;
                    if (config_.handles->close(h) && config_.release) config_.release(obj);
                }
            }
            out[offset] = nh_;
        }
        if (result != kSuccess) return fail(result);
    }
    int pointer_key = 0;
    for (uint32_t i = 0; i < sh.nx; ++i, offset += 2) {
        const auto d = unpack_x(&src[offset]);
        uint64_t recv = 0;
        if (d.size > 0) {
            if (rl.is_index()) pointer_key = static_cast<int>(d.index);
            recv = rl.get(d.size, pointer_key);
            if (!recv) return fail(kr::OutOfResource);
            std::vector<uint8_t> data(static_cast<size_t>(d.size));
            if (!config_.memory->read(d.address, data.data(), data.size())) return fail(kr::InvalidCurrentMemory);
            const bool heap = dst_user && rl.to_message_buffer();
            const uint32_t st = heap ? km::FlagReferenceCounted : km::FlagLinearMapped;
            if (config_.vm->check_each(recv, d.size, st, st, heap ? 0 : km::PermRW, heap ? 0 : km::PermRW, km::AttrUncached, 0))
                return fail(kr::InvalidCurrentMemory);
            if (!config_.vm->write_linear(recv, data.data(), d.size)) return fail(kr::InvalidCurrentMemory);
        }
        hipc::pack_static({d.index, recv, d.size}, &out[offset]);
    }
    for (uint32_t i = 0; i < sh.raw; ++i, ++offset) out[offset] = src[offset];
    if (!write_words(*client, req.message, out, src_end)) return fail(kr::InvalidCurrentMemory);
    cleanup_maps(req);
    return kSuccess;
}

uint32_t KernelIpc::receive_request(uint64_t id, KThread& server, uint64_t message, uint64_t size) {
    // KServerSession::ReceiveRequest
    auto it = gsessions_.find(id);
    if (it == gsessions_.end()) return kr::SessionClosed;
    GuestSession& s = it->second;
    if (s.client_closed) return kr::SessionClosed;
    if (s.current || s.requests.empty()) return kNotFound;
    s.current = std::move(s.requests.front());
    s.requests.pop_front();
    bool broken = false;
    const uint32_t rc = receive_message(server, message, size, *s.current, broken);
    if (rc == kSuccess) return kSuccess;
    GuestRequest failed = std::move(*s.current);
    s.current.reset();
    finish_request(failed, rc);   // the client gets the error
    return broken ? kr::ReceiveListBroken : kNotFound;
}

uint32_t KernelIpc::send_reply(uint64_t id, KThread& server, uint64_t message, uint64_t size) {
    // KServerSession::SendReply
    auto it = gsessions_.find(id);
    if (it == gsessions_.end()) return kr::SessionClosed;
    GuestSession& s = it->second;
    if (!s.current) return kr::InvalidState;
    GuestRequest req = std::move(*s.current);
    s.current.reset();
    const bool closed = s.client_closed;
    uint32_t result;
    if (!closed) {
        result = send_message(server, message, size, req);
    } else {
        cleanup_maps(req);   // CleanupServerHandles + CleanupMap
        std::vector<uint32_t> src;
        if (read_words(server, message, size, src)) {
            const Header sh = decode(src);
            uint32_t off = sh.special_index() + (sh.pid ? 2 : 0) + sh.ncopy;
            for (uint32_t i = 0; sh.special && i < sh.nmove && off < src.size(); ++i, ++off) {
                const KObjectRef* o = config_.handles->get(src[off]);
                const KObjectRef obj = o ? *o : KObjectRef{};
                if (config_.handles->close(src[off]) && config_.release) config_.release(obj);
            }
        }
        result = kSuccess;
    }
    uint32_t client_result = result;
    uint32_t server_result = kSuccess;
    if (closed && result == kSuccess) server_result = client_result = kr::SessionClosed;
    finish_request(req, client_result);
    if (gsessions_.count(id) && !gsessions_.at(id).requests.empty()) try_deliver(id);
    return server_result;
}

// ==== SVCs ====================================================================================

KernelIpc::SendResult KernelIpc::send_guest_request(KThread& self, uint32_t handle, uint64_t message, uint64_t size) {
    SendResult out;
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != KObjectType::ClientSession || !gsessions_.count(o->id)) { out.result = kr::InvalidHandle; return out; }
    const uint64_t id = o->id;
    GuestSession& s = gsessions_.at(id);
    // KServerSession::OnRequest
    if (s.server_closed) { out.result = kr::SessionClosed; return out; }
    ++requests_;
    GuestRequest r;
    r.thread = self.id;
    r.message = message;
    r.size = size;
    s.requests.push_back(std::move(r));
    config_.kthreads->begin_ipc_wait(self, "guest-ipc session " + std::to_string(id));
    out.blocked = true;
    try_deliver(id);
    return out;
}

uint32_t KernelIpc::send_async_request(KThread& self, uint64_t message, uint64_t size, uint32_t handle, uint32_t& out_event) {
    out_event = 0;
    if (config_.reserve_event && !config_.reserve_event()) return kr::LimitReached;
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != KObjectType::ClientSession) return kr::InvalidHandle;
    auto sit = gsessions_.find(o->id);
    if (sit == gsessions_.end()) return kr::InvalidHandle;   // HLE servers answer synchronously only (D-P6.0-10)
    uint32_t read = 0;
    uint64_t event = 0;
    if (const uint32_t rc = config_.kthreads->create_kernel_event(read, event); rc) return rc;
    if (sit->second.server_closed) {
        config_.handles->close(read);
        config_.kthreads->on_handle_closed({KObjectType::ReadableEvent, event});
        config_.kthreads->release_kernel_event(event);
        return kr::SessionClosed;
    }
    ++requests_;
    GuestRequest r;
    r.thread = self.id;
    r.message = message;
    r.size = size;
    r.event = event;
    sit->second.requests.push_back(std::move(r));
    out_event = read;
    try_deliver(o->id);
    return kSuccess;
}

KernelIpc::SendResult KernelIpc::reply_and_receive(KThread& self, uint64_t message, uint64_t size, uint64_t handles,
                                                   int32_t count, uint32_t reply_target, int64_t timeout_ns,
                                                   int32_t& out_index) {
    SendResult out;
    out_index = -1;
    // the handles first (GetMultipleObjects), then the reply, then the wait
    std::vector<uint64_t> objects;
    if (const uint32_t rc = config_.kthreads->resolve_sync_handles(handles, count, objects); rc) { out.result = rc; return out; }
    if (reply_target != HandleTable::kInvalidHandle) {
        const KObjectRef* o = config_.handles->get(reply_target);
        if (!o || o->type != KObjectType::ServerSession || !gsessions_.count(o->id)) { out.result = kr::InvalidHandle; return out; }
        if (const uint32_t rc = send_reply(o->id, self, message, size); rc) { out.result = rc; return out; }
    }
    // KSynchronizationObject::Wait + ReceiveRequest, first signaled object in order
    for (size_t i = 0; i < objects.size(); ++i) {
        const uint64_t obj = objects[i];
        if (!config_.kthreads->object_signaled(obj)) continue;
        const uint64_t ext = obj & ~KernelThreads::kExternalObject;
        if ((obj & KernelThreads::kExternalObject) && (ext & ~kExtIdMask) == kExtServerSession) {
            uint32_t rc = kNotFound;
            while (rc == kNotFound && config_.kthreads->object_signaled(obj)) rc = receive_request(ext & kExtIdMask, self, message, size);
            if (rc == kNotFound) continue;
            out_index = static_cast<int32_t>(i);
            out.result = rc;
            return out;
        }
        out_index = static_cast<int32_t>(i);
        out.result = kSuccess;
        return out;
    }
    bool blocked = false;
    out.result = config_.kthreads->block_on_objects(self, objects, timeout_ns, blocked);
    out.blocked = blocked;
    if (blocked) server_waits_[self.id] = ServerWait{message, size, std::move(objects)};
    return out;
}

KernelIpc::SendResult KernelIpc::send_sync_request_light(KThread& self, cpu::CpuState& ctx, uint32_t handle) {
    (void)ctx;   // the data stays in the caller's saved registers until the server copies it
    SendResult out;
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != KObjectType::LightClientSession || !gsessions_.count(o->id)) { out.result = kr::InvalidHandle; return out; }
    GuestSession& s = gsessions_.at(o->id);
    if (s.server_closed) { out.result = kr::SessionClosed; return out; }   // KLightServerSession::OnRequest
    ++requests_;
    s.light_requests.push_back(self.id);
    config_.kthreads->begin_ipc_wait(self, "guest-ipc light session " + std::to_string(o->id));
    out.blocked = true;
    light_deliver(o->id);
    return out;
}

void KernelIpc::light_deliver(uint64_t id) {
    // OnRequest: m_server_thread->EndWait(Success); the server then takes the head request
    auto it = gsessions_.find(id);
    if (it == gsessions_.end()) return;
    GuestSession& s = it->second;
    if (!s.light_waiting || s.light_requests.empty() || s.light_current) return;
    KThread* server = config_.kthreads->find(s.light_waiting);
    const uint64_t client = s.light_requests.front();
    cpu::CpuState* sc = config_.kthreads->context_of(s.light_waiting);
    const cpu::CpuState* cc = config_.kthreads->context_of(client);
    if (!server || !sc || !cc) return;
    s.light_requests.pop_front();
    s.light_current = client;
    s.light_server = server->id;
    s.light_waiting = 0;
    for (int i = 1; i <= 7; ++i) sc->x[i] = static_cast<uint32_t>(cc->x[i]);
    config_.kthreads->end_ipc_wait(*server, kSuccess);
}

KernelIpc::SendResult KernelIpc::reply_and_receive_light(KThread& self, cpu::CpuState& ctx, uint32_t handle) {
    SendResult out;
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != KObjectType::LightServerSession || !gsessions_.count(o->id)) { out.result = kr::InvalidHandle; return out; }
    const uint64_t id = o->id;
    GuestSession& s = gsessions_.at(id);
    // KLightServerSession::ReplyAndReceive
    if (static_cast<uint32_t>(ctx.x[1]) & kReplyFlag) {
        if (s.client_closed || s.server_closed) { out.result = kr::SessionClosed; return out; }
        if (!s.light_current || s.light_server != self.id) { out.result = kr::InvalidState; return out; }
        if (cpu::CpuState* cc = config_.kthreads->context_of(s.light_current))
            for (int i = 1; i <= 7; ++i) cc->x[i] = static_cast<uint32_t>(ctx.x[i]);
        if (KThread* c = config_.kthreads->find(s.light_current)) config_.kthreads->end_ipc_wait(*c, kSuccess);
        s.light_current = 0;
        s.light_server = 0;
    }
    if (s.light_waiting || s.light_server) { out.result = kr::InvalidState; return out; }
    if (s.client_closed || s.server_closed) { out.result = kr::SessionClosed; return out; }
    if (!s.light_requests.empty()) {
        const uint64_t client = s.light_requests.front();
        s.light_requests.pop_front();
        s.light_current = client;
        s.light_server = self.id;
        if (const cpu::CpuState* cc = config_.kthreads->context_of(client))
            for (int i = 1; i <= 7; ++i) ctx.x[i] = static_cast<uint32_t>(cc->x[i]);
        out.result = kSuccess;
        return out;
    }
    if (self.wait_cancelled) { self.wait_cancelled = false; out.result = kr::Cancelled; return out; }
    s.light_waiting = self.id;
    config_.kthreads->begin_ipc_wait(self, "guest-ipc light receive " + std::to_string(id));
    out.blocked = true;
    return out;
}

} // namespace lg::system
