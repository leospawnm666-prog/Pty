#include "vm_manager.h"

#include <algorithm>

namespace lg::system {
namespace {
using namespace kmem;
namespace r = kmem::result;

constexpr bool page_aligned(uint64_t v) noexcept { return (v & (PageSize - 1)) == 0; }
uint32_t mmu_permissions(uint32_t perm) noexcept {
    uint32_t p = memory::User;
    if (perm & PermR) p |= memory::Read;
    if (perm & PermW) p |= memory::Write | memory::Read;
    if (perm & PermX) p |= memory::Execute;
    return p;
}
} // namespace

void VmManager::reset() noexcept {
    active_ = false;
    broken_ = false;
    config_ = {};
    blocks_.clear();
    backing_.clear();
    allocator_.clear();
    heap_used_ = 0;
    scrubbed_ = 0;
    physical_mapped_ = 0;          // P6.0: the allocator cleared above owned these granules
    physical_owned_.clear();
    insecure_mapped_ = 0;
}

bool VmManager::begin(const VmConfig& c) {
    reset();
    if (c.space_begin >= c.space_end || !page_aligned(c.space_begin) || !page_aligned(c.space_end)) return false;
    auto inside = [&](uint64_t b, uint64_t s) { return s && b >= c.space_begin && b + s > b && b + s <= c.space_end; };
    if (!inside(c.heap_base, c.heap_size) || !inside(c.alias_base, c.alias_size) || !inside(c.stack_base, c.stack_size))
        return false;
    config_ = c;
    blocks_.emplace(c.space_begin, Block{c.space_end - c.space_begin, Free, PermNone, 0, vm_merge::None});
    allocator_.reset(c.arena_free_base, c.arena_free_size);
    active_ = true;
    return true;
}

bool VmManager::contains(uint64_t a, uint64_t s) const noexcept {
    return active_ && s && a >= config_.space_begin && a + s > a && a + s <= config_.space_end;
}

bool VmManager::can_contain_stack(uint64_t a, uint64_t s) const noexcept {
    // KPageTableBase::CanContain(addr, size, Stack): inside the stack region and outside the
    // heap and alias regions.
    if (!active_ || !s || a + s <= a) return false;
    const uint64_t end = a + s, last = end - 1;
    const bool in_region = config_.stack_base <= a && last <= config_.stack_base + config_.stack_size - 1;
    if (!in_region) return false;
    const auto overlaps = [&](uint64_t b, uint64_t sz) { return sz && a < b + sz && b < end; };
    return !overlaps(config_.heap_base, config_.heap_size) && !overlaps(config_.alias_base, config_.alias_size);
}

// ---- Block bookkeeping -------------------------------------------------------------------

void VmManager::split_block(uint64_t a) {
    if (a <= config_.space_begin || a >= config_.space_end) return;
    auto it = blocks_.upper_bound(a);
    --it;                                               // the block containing a (space is covered)
    if (it->first == a) return;
    Block right = it->second;
    right.size = it->first + it->second.size - a;
    right.head = vm_merge::None;                        // KMemoryBlock::Split: the left flags stay on the left part
    it->second.size = a - it->first;
    blocks_.emplace(a, right);
}

void VmManager::split_backing(uint64_t a) {
    auto it = backing_.upper_bound(a);
    if (it == backing_.begin()) return;
    --it;
    if (it->first == a || it->first + it->second.size <= a) return;
    Backing right = it->second;
    right.size = it->first + it->second.size - a;
    right.pa = it->second.pa + (a - it->first);
    it->second.size = a - it->first;
    backing_.emplace(a, right);
}

bool VmManager::can_merge(const Block& l, const Block& r_) noexcept {
    // KMemoryBlock::CanMergeWith (no "disable merge right" flags are used by Lobo).
    return l.state == r_.state && l.perm == r_.perm && l.attr == r_.attr && r_.head == vm_merge::None &&
           l.ipc == r_.ipc && l.orig_perm == r_.orig_perm;   // P6.0: HasSameProperties includes the IPC lock
}

void VmManager::coalesce(uint64_t begin, uint64_t end) {
    auto it = blocks_.upper_bound(begin);
    if (it != blocks_.begin()) --it;
    if (it != blocks_.begin()) --it;                    // one block of margin on the left
    while (it != blocks_.end()) {
        auto next = std::next(it);
        if (next == blocks_.end()) break;
        if (can_merge(it->second, next->second)) {
            it->second.size += next->second.size;
            blocks_.erase(next);
            continue;
        }
        if (next->first > end) break;
        it = next;
    }
}

void VmManager::update(uint64_t begin, uint64_t end, uint32_t state, uint32_t perm, uint32_t attr, uint8_t set_head,
                       uint8_t clear_head) {
    split_block(begin);
    split_block(end);
    for (auto it = blocks_.find(begin); it != blocks_.end() && it->first < end; ++it) {
        Block& b = it->second;
        if (b.state == state && b.perm == perm && b.attr == attr) continue;   // HasProperties: untouched
        b.state = state; b.perm = perm; b.attr = attr;
        if (it->first == begin && set_head) b.head |= set_head;
        b.head &= static_cast<uint8_t>(~clear_head);
    }
    coalesce(begin, end);
}

void VmManager::update_attribute(uint64_t begin, uint64_t end, uint32_t mask, uint32_t attr) {
    split_block(begin);
    split_block(end);
    for (auto it = blocks_.find(begin); it != blocks_.end() && it->first < end; ++it)
        it->second.attr = (it->second.attr & ~mask) | attr;
    coalesce(begin, end);
}

uint32_t VmManager::check(uint64_t begin, uint64_t end, uint32_t state_mask, uint32_t state, uint32_t perm_mask,
                          uint32_t perm, uint32_t attr_mask, uint32_t attr, uint32_t ignore_attr, uint32_t* out_state,
                          uint32_t* out_perm, uint32_t* out_attr) const {
    // KPageTableBase::CheckMemoryState: every block of the range has the same properties,
    // and they match the masks.
    auto it = blocks_.upper_bound(begin);
    --it;
    const Block& f = it->second;
    for (; it != blocks_.end() && it->first < end; ++it) {
        const Block& b = it->second;
        if (b.state != f.state || b.perm != f.perm || (b.attr | ignore_attr) != (f.attr | ignore_attr))
            return r::InvalidCurrentMemory;
        if ((b.state & state_mask) != state || (b.perm & perm_mask) != perm || (b.attr & attr_mask) != attr)
            return r::InvalidCurrentMemory;
    }
    if (out_state) *out_state = f.state;
    if (out_perm) *out_perm = f.perm;
    if (out_attr) *out_attr = f.attr & ~ignore_attr;
    return r::Success;
}

// ---- Physical backing --------------------------------------------------------------------

std::vector<VmManager::Run> VmManager::runs(uint64_t begin, uint64_t end) const {
    std::vector<Run> out;
    auto it = backing_.upper_bound(begin);
    if (it != backing_.begin()) --it;
    for (; it != backing_.end() && it->first < end; ++it) {
        const uint64_t lo = std::max(begin, it->first), hi = std::min(end, it->first + it->second.size);
        if (lo < hi) out.push_back({lo, hi - lo, it->second.pa + (lo - it->first), it->second.owned});
    }
    return out;
}

std::vector<VmManager::Run> VmManager::remove_backing(uint64_t begin, uint64_t end) {
    split_backing(begin);
    split_backing(end);
    std::vector<Run> out;
    for (auto it = backing_.lower_bound(begin); it != backing_.end() && it->first < end;) {
        out.push_back({it->first, it->second.size, it->second.pa, it->second.owned});
        it = backing_.erase(it);
    }
    return out;
}

void VmManager::scrub(uint64_t pa, uint64_t size) {
    // Unmapped arena pages are zeroed and their RAM returned (AddressSpace, phases D/E);
    // mapping them again keeps them usable. Heap memory is zero when it grows (Horizon's
    // heap fill value 0).
    if (!memory_.unmap(pa, size) || !memory_.map(pa, size)) broken_ = true;
    scrubbed_ += size;
}

void VmManager::sync_mmu(uint64_t begin, uint64_t end) {
    // The Mmu of [begin, end) is rebuilt from the blocks and the backing.
    if (!mmu_.unmap(begin, end - begin)) { broken_ = true; return; }
    auto it = blocks_.upper_bound(begin);
    --it;
    for (; it != blocks_.end() && it->first < end; ++it) {
        if (it->second.perm == PermNone) continue;
        const uint64_t lo = std::max(begin, it->first), hi = std::min(end, it->first + it->second.size);
        for (const Run& run : runs(lo, hi))
            if (!mmu_.map(run.va, run.pa, run.size, mmu_permissions(it->second.perm))) broken_ = true;
    }
}

// ---- Seeding -----------------------------------------------------------------------------

bool VmManager::seed(uint64_t va, uint64_t size, uint32_t state, uint32_t perm) {
    if (!contains(va, size) || !page_aligned(va) || !page_aligned(size) || state == Free || perm == PermNone) return false;
    if (check(va, va + size, All, Free, 0, 0, 0, 0) != r::Success) return false;
    uint64_t rva = 0, rpa = 0, rsize = 0;
    uint32_t rperms = 0;
    if (!mmu_.find_region(va, rva, rpa, rsize, rperms) || va + size > rva + rsize) return false;
    backing_.emplace(va, Backing{size, rpa + (va - rva), false});
    update(va, va + size, state, perm, 0, vm_merge::Normal, vm_merge::None);   // each segment is its own block
    return true;
}

// ---- SVCs --------------------------------------------------------------------------------

uint32_t VmManager::set_heap_size(uint64_t size, uint64_t& out) {
    out = 0;
    // svc layer (kern_svc_physical_memory.cpp)
    if (size % HeapSizeAlignment) return r::InvalidSize;
    if (size >= MainMemorySizeMax) return r::InvalidSize;
    // KPageTableBase::SetHeapSize
    if (size > config_.heap_size) return r::OutOfMemory;
    const uint64_t base = config_.heap_base;
    if (size < heap_used_) {
        const uint64_t a = base + size, b = base + heap_used_;
        if (const auto rc = check(a, b, All, Normal, All, PermRW, All, 0); rc) return rc;
        for (const Run& run : remove_backing(a, b)) {
            if (!run.owned) continue;
            release_owned({run.pa, run.size});   // P6.0: MapProcessMemory may still map them
        }
        update(a, b, Free, PermNone, 0, vm_merge::None, size == 0 ? vm_merge::Normal : vm_merge::None);
        sync_mmu(a, b);
        heap_used_ = size;
        out = base;
        return r::Success;
    }
    if (size == heap_used_) { out = base; return r::Success; }
    const uint64_t a = base + heap_used_, b = base + size;
    if (const auto rc = check(a, b, All, Free, 0, 0, 0, 0); rc) return rc;
    auto got = allocator_.allocate(b - a);
    if (!got) return r::LimitReached;
    uint64_t va = a;
    for (const auto& run : *got) { backing_.emplace(va, Backing{run.size, run.pa, true}); va += run.size; }
    // DisableMergeAttribute_Normal on the heap's head block.
    update(a, b, Normal, PermRW, 0, heap_used_ == 0 ? vm_merge::Normal : vm_merge::None, vm_merge::None);
    sync_mmu(a, b);
    heap_used_ = size;
    out = base;
    return r::Success;
}

uint32_t VmManager::set_memory_permission(uint64_t address, uint64_t size, uint32_t perm) {
    if (!page_aligned(address)) return r::InvalidAddress;
    if (!page_aligned(size) || size == 0) return r::InvalidSize;
    if (address + size <= address) return r::InvalidCurrentMemory;
    if (perm != PermNone && perm != PermR && perm != PermRW) return r::InvalidNewMemoryPermission;
    if (!contains(address, size)) return r::InvalidCurrentMemory;
    uint32_t old_state = 0, old_perm = 0;
    if (const auto rc = check(address, address + size, FlagCanReprotect, FlagCanReprotect, 0, 0, All, 0,
                              AttrIpcLocked | AttrDeviceShared, &old_state, &old_perm); rc)
        return rc;
    if (old_perm == perm) return r::Success;
    update(address, address + size, old_state, perm, 0, vm_merge::None, vm_merge::None);
    sync_mmu(address, address + size);
    return r::Success;
}

uint32_t VmManager::set_memory_attribute(uint64_t address, uint64_t size, uint32_t mask, uint32_t attr) {
    if (!page_aligned(address)) return r::InvalidAddress;
    if (!page_aligned(size) || size == 0) return r::InvalidSize;
    if (address + size <= address) return r::InvalidCurrentMemory;
    if ((mask | attr) != mask) return r::InvalidCombination;
    if ((mask | attr | AttrSetMask) != AttrSetMask) return r::InvalidCombination;
    if ((mask & AttrPermissionLocked) != (attr & AttrPermissionLocked)) return r::InvalidCombination;
    if (!contains(address, size)) return r::InvalidCurrentMemory;
    const uint32_t state_test = ((mask & AttrUncached) ? FlagCanChangeAttribute : 0) |
                                ((mask & AttrPermissionLocked) ? FlagCanPermissionLock : 0);
    constexpr uint32_t attr_test = ~(AttrSetMask | AttrDeviceShared);
    if (const auto rc = check(address, address + size, state_test, state_test, 0, 0, attr_test, 0, ~attr_test); rc)
        return rc;
    update_attribute(address, address + size, mask, attr);
    return r::Success;   // attributes do not change the host mapping (Uncached has no host effect)
}

uint32_t VmManager::map_memory(uint64_t dst, uint64_t src, uint64_t size) {
    if (!page_aligned(dst) || !page_aligned(src)) return r::InvalidAddress;
    if (size == 0 || !page_aligned(size)) return r::InvalidSize;
    if (src + size <= src || dst + size <= dst) return r::InvalidCurrentMemory;
    if (!contains(src, size)) return r::InvalidCurrentMemory;
    if (!can_contain_stack(dst, size)) return r::InvalidMemoryRegion;
    uint32_t src_state = 0;
    if (const auto rc = check(src, src + size, FlagCanAlias, FlagCanAlias, All, PermRW, All, 0,
                              AttrIpcLocked | AttrDeviceShared, &src_state); rc) return rc;
    if (const auto rc = check(dst, dst + size, All, Free, 0, 0, 0, 0); rc) return rc;
    // The destination aliases the source's physical pages; the source becomes inaccessible
    // (kernel-read / not mapped) and Locked.
    for (const Run& run : runs(src, src + size))
        backing_.emplace(dst + (run.va - src), Backing{run.size, run.pa, false});
    update(src, src + size, src_state, PermNone, AttrLocked, vm_merge::Locked, vm_merge::None);
    update(dst, dst + size, Stack, PermRW, 0, vm_merge::Normal, vm_merge::None);
    sync_mmu(src, src + size);
    sync_mmu(dst, dst + size);
    return r::Success;
}

uint32_t VmManager::unmap_memory(uint64_t dst, uint64_t src, uint64_t size) {
    if (!page_aligned(dst) || !page_aligned(src)) return r::InvalidAddress;
    if (size == 0 || !page_aligned(size)) return r::InvalidSize;
    if (src + size <= src || dst + size <= dst) return r::InvalidCurrentMemory;
    if (!contains(src, size)) return r::InvalidCurrentMemory;
    if (!can_contain_stack(dst, size)) return r::InvalidMemoryRegion;
    uint32_t src_state = 0;
    if (const auto rc = check(src, src + size, FlagCanAlias, FlagCanAlias, All, PermNone, All, AttrLocked,
                              AttrIpcLocked | AttrDeviceShared, &src_state); rc) return rc;
    if (const auto rc = check(dst, dst + size, All, Stack, 0, 0, All, 0); rc) return rc;
    // IsValidPageGroup: the destination must alias exactly the source's physical pages.
    const auto d = runs(dst, dst + size);
    uint64_t covered = 0;
    for (const Run& run : d) covered += run.size;
    if (covered != size) return r::InvalidMemoryRegion;
    for (const Run& run : d) {
        for (uint64_t off = 0; off < run.size; off += PageSize) {
            const auto sp = physical(src + (run.va - dst) + off);
            if (!sp || *sp != run.pa + off) return r::InvalidMemoryRegion;
        }
    }
    remove_backing(dst, dst + size);                    // aliases: nothing to free
    update(src, src + size, src_state, PermRW, 0, vm_merge::None, vm_merge::Locked);
    update(dst, dst + size, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    sync_mmu(dst, dst + size);
    sync_mmu(src, src + size);
    return r::Success;
}

bool VmManager::map_thread_local_page(uint64_t va) {
    if (!page_aligned(va) || !contains(va, PageSize)) return false;
    if (check(va, va + PageSize, All, Free, 0, 0, 0, 0) != r::Success) return false;
    auto got = allocator_.allocate(PageSize);
    if (!got || got->empty()) return false;
    backing_.emplace(va, Backing{PageSize, got->front().pa, false});   // never freed during the session
    update(va, va + PageSize, ThreadLocal, PermRW, 0, vm_merge::Normal, vm_merge::None);
    sync_mmu(va, va + PageSize);
    return !broken_;
}

uint32_t VmManager::check_ipc_buffer(uint64_t address, uint64_t size, uint32_t mode, bool write) const {
    uint32_t flag = 0, attr_mask = 0;
    switch (mode) {
        case 0: flag = FlagCanUseIpc; attr_mask = ~(AttrPermissionLocked | AttrIpcLocked); break;
        case 1: flag = FlagCanUseNonSecureIpc; attr_mask = ~(AttrPermissionLocked | AttrDeviceShared | AttrIpcLocked); break;
        case 3: flag = FlagCanUseNonDeviceIpc; attr_mask = ~(AttrPermissionLocked | AttrDeviceShared | AttrIpcLocked); break;
        default: return r::InvalidCombination;
    }
    if (size == 0) return r::Success;
    if (!active_ || address + size < address) return r::InvalidCurrentMemory;
    const uint64_t begin = address & ~(PageSize - 1);
    const uint64_t end_unaligned = address + size;
    if (end_unaligned > ~uint64_t{0} - (PageSize - 1)) return r::InvalidCurrentMemory;
    const uint64_t end = (end_unaligned + PageSize - 1) & ~(PageSize - 1);
    if (!contains(begin, end - begin)) return r::InvalidCurrentMemory;
    const uint32_t perm = write ? PermRW : PermR;
    auto it = blocks_.upper_bound(begin);
    --it;
    for (; it != blocks_.end() && it->first < end; ++it) {
        const Block& b = it->second;
        if ((b.state & flag) != flag || (b.perm & perm) != perm || (b.attr & attr_mask) != 0) return r::InvalidCurrentMemory;
    }
    return r::Success;
}

// ---- P6.0: page groups of the memory objects ----------------------------------------------

std::optional<VmManager::PageGroup> VmManager::allocate_group(uint64_t size) {
    if (!active_ || size == 0 || !page_aligned(size)) return std::nullopt;
    auto got = allocator_.allocate(size);
    if (!got) return std::nullopt;
    PageGroup g;
    g.owned = *got;
    uint64_t left = size;
    for (const auto& run : *got) {
        const uint64_t n = std::min(left, run.size);
        if (n) g.runs.push_back({run.pa, n});
        left -= n;
    }
    return g;   // free arena granules are zero (scrubbed when they were freed)
}

void VmManager::free_group(PageGroup& g) {
    for (const auto& run : g.owned) {
        scrub(run.pa, run.size);
        if (!allocator_.free(run.pa, run.size)) broken_ = true;
    }
    g.owned.clear();
    g.runs.clear();
}

bool VmManager::in_alias_region(uint64_t a, uint64_t s) const noexcept {
    if (!active_ || !s || a + s <= a) return false;
    return config_.alias_base <= a && a + s - 1 <= config_.alias_base + config_.alias_size - 1;
}

bool VmManager::can_contain(uint64_t a, uint64_t s, uint32_t state) const noexcept {
    // KPageTableBase::CanContain: Normal in the heap region, Ipc kinds in the alias region,
    // Stack in the stack region; the object states in the alias-code region (the whole
    // address space for 39-bit processes) outside the heap and alias regions.
    if (!active_ || !s || a + s <= a) return false;
    const uint64_t end = a + s, last = end - 1;
    auto in = [&](uint64_t b, uint64_t sz) { return sz && b <= a && last <= b + sz - 1; };
    auto overlaps = [&](uint64_t b, uint64_t sz) { return sz && a < b + sz && b < end; };
    switch (state & StateMask) {
        case Normal & StateMask: return in(config_.heap_base, config_.heap_size);
        case Ipc & StateMask: case NonSecureIpc & StateMask: case NonDeviceIpc & StateMask:
            return in(config_.alias_base, config_.alias_size);
        case Stack & StateMask: return can_contain_stack(a, s);
        default:
            return in(config_.space_begin, config_.space_end - config_.space_begin) &&
                   !overlaps(config_.heap_base, config_.heap_size) && !overlaps(config_.alias_base, config_.alias_size);
    }
}

uint32_t VmManager::map_page_group(uint64_t a, uint64_t s, const PageGroup& g, uint32_t state, uint32_t perm) {
    if (!contains(a, s) || g.size() != s) return r::InvalidCurrentMemory;
    if (const auto rc = check(a, a + s, All, Free, 0, 0, 0, 0); rc) return rc;
    uint64_t va = a;
    for (const auto& run : g.runs) { backing_.emplace(va, Backing{run.size, run.pa, false}); va += run.size; }
    update(a, a + s, state, perm, 0, vm_merge::Normal, vm_merge::None);
    sync_mmu(a, a + s);
    return r::Success;
}

uint32_t VmManager::unmap_page_group(uint64_t a, uint64_t s, const PageGroup& g, uint32_t state) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    if (const auto rc = check(a, a + s, All, state, 0, 0, All, 0); rc) return rc;
    // IsValidPageGroup: the range must be backed by exactly the group's pages, in order.
    uint64_t va = a;
    for (const auto& run : g.runs) {
        for (uint64_t off = 0; off < run.size; off += PageSize) {
            const auto pa = physical(va + off);
            if (!pa || *pa != run.pa + off) return r::InvalidMemoryRegion;
        }
        va += run.size;
    }
    if (va != a + s) return r::InvalidMemoryRegion;
    remove_backing(a, a + s);   // the group keeps its pages
    update(a, a + s, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    sync_mmu(a, a + s);
    collect_owned();
    return r::Success;
}

uint32_t VmManager::lock_memory(uint64_t a, uint64_t s, uint32_t state_mask, uint32_t state, uint32_t perm_mask, uint32_t perm,
                                uint32_t attr_mask, uint32_t attr, uint32_t new_perm, uint32_t lock_attr, PageGroup* out) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    uint32_t old_state = 0, old_perm = 0, old_attr = 0;
    if (const auto rc = check(a, a + s, state_mask | FlagReferenceCounted, state | FlagReferenceCounted, perm_mask, perm,
                              attr_mask, attr, AttrIpcLocked | AttrDeviceShared, &old_state, &old_perm, &old_attr); rc)
        return rc;
    if (out) {
        out->runs.clear();
        out->owned.clear();
        for (const Run& run : runs(a, a + s)) out->runs.push_back({run.pa, run.size});
        if (out->size() != s) return r::InvalidCurrentMemory;
    }
    const uint32_t np = new_perm == kKeepPerm ? old_perm : new_perm;
    update(a, a + s, old_state, np, old_attr | lock_attr, vm_merge::Locked, vm_merge::None);
    if (np != old_perm) sync_mmu(a, a + s);
    return r::Success;
}

uint32_t VmManager::unlock_memory(uint64_t a, uint64_t s, uint32_t state_mask, uint32_t state, uint32_t perm_mask, uint32_t perm,
                                  uint32_t attr_mask, uint32_t attr, uint32_t new_perm, uint32_t lock_attr, const PageGroup* g) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    uint32_t old_state = 0, old_perm = 0, old_attr = 0;
    if (const auto rc = check(a, a + s, state_mask, state, perm_mask, perm, attr_mask, attr, AttrIpcLocked | AttrDeviceShared,
                              &old_state, &old_perm, &old_attr); rc)
        return rc;
    if (g) {
        uint64_t va = a;
        for (const auto& run : g->runs) {
            for (uint64_t off = 0; off < run.size; off += PageSize) {
                const auto pa = physical(va + off);
                if (!pa || *pa != run.pa + off) return r::InvalidMemoryRegion;
            }
            va += run.size;
        }
    }
    const uint32_t np = new_perm == kKeepPerm ? old_perm : new_perm;
    update(a, a + s, old_state, np, old_attr & ~lock_attr, vm_merge::None, vm_merge::Locked);
    if (np != old_perm) sync_mmu(a, a + s);
    return r::Success;
}

uint32_t VmManager::map_physical_memory(uint64_t a, uint64_t s) {
    if (!in_alias_region(a, s)) return r::InvalidMemoryRegion;
    // KPageTableBase::MapPhysicalMemory: what is already Normal stays; the Free parts get new
    // zeroed pages (all or nothing).
    uint64_t mapped = 0;
    auto it = blocks_.upper_bound(a);
    --it;
    for (; it != blocks_.end() && it->first < a + s; ++it) {
        const uint64_t lo = std::max(a, it->first), hi = std::min(a + s, it->first + it->second.size);
        if (it->second.state == Free) continue;
        if (it->second.state != Normal || it->second.attr != 0) return r::InvalidCurrentMemory;
        mapped += hi - lo;
    }
    if (mapped == s) return r::Success;
    auto g = allocate_group(s - mapped);
    if (!g) return r::LimitReached;
    // the pages of the group, in order, onto the Free parts
    size_t ri = 0;
    uint64_t roff = 0;
    std::vector<std::pair<uint64_t, uint64_t>> free_parts;
    it = blocks_.upper_bound(a);
    --it;
    for (; it != blocks_.end() && it->first < a + s; ++it) {
        if (it->second.state != Free) continue;
        free_parts.push_back({std::max(a, it->first), std::min(a + s, it->first + it->second.size)});
    }
    for (const auto& [lo, hi] : free_parts) {
        uint64_t va = lo;
        while (va < hi) {
            const auto& run = g->runs[ri];
            const uint64_t n = std::min(hi - va, run.size - roff);
            backing_.emplace(va, Backing{n, run.pa + roff, false});
            va += n;
            roff += n;
            if (roff == run.size) { ++ri; roff = 0; }
        }
        update(lo, hi, Normal, PermRW, 0, vm_merge::Normal, vm_merge::None);
        sync_mmu(lo, hi);
    }
    for (const auto& o : g->owned) physical_owned_.push_back(o);
    physical_mapped_ += s - mapped;
    return r::Success;
}

uint32_t VmManager::unmap_physical_memory(uint64_t a, uint64_t s) {
    if (!in_alias_region(a, s)) return r::InvalidMemoryRegion;
    auto it = blocks_.upper_bound(a);
    --it;
    for (; it != blocks_.end() && it->first < a + s; ++it) {
        const bool normal = it->second.state == Normal && it->second.attr == 0;
        if (!normal && it->second.state != Free) return r::InvalidCurrentMemory;
    }
    uint64_t freed = 0;
    for (const Run& run : remove_backing(a, a + s)) freed += run.size;
    update(a, a + s, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    sync_mmu(a, a + s);
    physical_mapped_ -= std::min(physical_mapped_, freed);
    // granules no page of the alias region uses any more go back to the arena
    collect_owned();
    return r::Success;
}

std::optional<VmBlock> VmManager::block_at(uint64_t address) const {
    if (!contains(address, 1)) return std::nullopt;
    auto it = blocks_.upper_bound(address);
    --it;
    return VmBlock{it->first, it->second.size, it->second.state, it->second.perm, it->second.attr, it->second.head != 0, it->second.head};
}

uint32_t VmManager::set_process_memory_permission(uint64_t a, uint64_t s, uint32_t perm) {
    // KPageTableBase::SetProcessMemoryPermission: code that becomes writable turns into data
    // (Code -> CodeData, AliasCode -> AliasCodeData); everything else keeps its state.
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    uint32_t old_state = 0, old_perm = 0;
    if (const auto rc = check(a, a + s, FlagCode, FlagCode, 0, 0, All, 0, AttrIpcLocked | AttrDeviceShared, &old_state, &old_perm); rc)
        return rc;
    uint32_t new_state = old_state;
    if (perm & PermW) {
        if (old_state == Code) new_state = CodeData;
        else if (old_state == AliasCode) new_state = AliasCodeData;
        else return r::InvalidCurrentMemory;
    }
    if (new_state == old_state && perm == old_perm) return r::Success;
    update(a, a + s, new_state, perm, 0, vm_merge::None, vm_merge::None);
    sync_mmu(a, a + s);
    return r::Success;
}

uint32_t VmManager::map_process_code_memory(uint64_t dst, uint64_t src, uint64_t s) {
    // KPageTableBase::MapCodeMemory: src (FlagCanCodeAlias? no: Normal heap/CodeData that can
    // alias) becomes Locked/no permission, dst (Free, alias-code region) AliasCode, RX later
    // through SetProcessMemoryPermission (it starts kernel-RW: user None).
    if (!contains(src, s) || !contains(dst, s)) return r::InvalidCurrentMemory;
    if (!can_contain(dst, s, AliasCode)) return r::InvalidMemoryRegion;
    uint32_t src_state = 0;
    if (const auto rc = check(src, src + s, All, Normal, All, PermRW, All, 0, AttrIpcLocked | AttrDeviceShared, &src_state); rc)
        return rc;
    if (const auto rc = check(dst, dst + s, All, Free, 0, 0, 0, 0); rc) return rc;
    for (const Run& run : runs(src, src + s)) backing_.emplace(dst + (run.va - src), Backing{run.size, run.pa, false});
    update(src, src + s, src_state, PermNone, AttrLocked, vm_merge::Locked, vm_merge::None);
    update(dst, dst + s, AliasCode, PermNone, 0, vm_merge::Normal, vm_merge::None);
    sync_mmu(src, src + s);
    sync_mmu(dst, dst + s);
    return r::Success;
}

uint32_t VmManager::unmap_process_code_memory(uint64_t dst, uint64_t src, uint64_t s) {
    if (!contains(src, s) || !contains(dst, s)) return r::InvalidCurrentMemory;
    if (!can_contain(dst, s, AliasCode)) return r::InvalidMemoryRegion;
    uint32_t src_state = 0;
    if (const auto rc = check(src, src + s, All, Normal, All, PermNone, All, AttrLocked, AttrIpcLocked | AttrDeviceShared, &src_state); rc)
        return rc;
    // the destination: AliasCode or AliasCodeData (after SetProcessMemoryPermission), unlocked
    auto it = blocks_.upper_bound(dst);
    --it;
    for (; it != blocks_.end() && it->first < dst + s; ++it)
        if ((it->second.state != AliasCode && it->second.state != AliasCodeData) || it->second.attr != 0) return r::InvalidCurrentMemory;
    for (uint64_t off = 0; off < s; off += PageSize) {
        const auto d = physical(dst + off), sp = physical(src + off);
        if (!d || !sp || *d != *sp) return r::InvalidMemoryRegion;
    }
    remove_backing(dst, dst + s);
    update(dst, dst + s, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    update(src, src + s, src_state, PermRW, 0, vm_merge::None, vm_merge::Locked);
    sync_mmu(dst, dst + s);
    sync_mmu(src, src + s);
    return r::Success;
}

MemoryInfo VmManager::query(uint64_t address) const {
    if (!contains(address, 1)) {
        const uint64_t end = active_ ? config_.space_end : 0;
        return MemoryInfo{end, 0 - end, Inaccessible & StateMask, 0, PermNone, 0, 0, 0};
    }
    auto it = blocks_.upper_bound(address);
    --it;
    return MemoryInfo{it->first, it->second.size, it->second.state & StateMask, it->second.attr, it->second.perm,
                      it->second.ipc, 0, 0};
}

std::vector<VmBlock> VmManager::blocks() const {
    std::vector<VmBlock> out;
    out.reserve(blocks_.size());
    for (const auto& [va, b] : blocks_) out.push_back({va, b.size, b.state, b.perm, b.attr, b.head != 0, b.head});
    return out;
}

std::optional<uint64_t> VmManager::physical(uint64_t va) const {
    auto it = backing_.upper_bound(va);
    if (it == backing_.begin()) return std::nullopt;
    --it;
    if (va >= it->first + it->second.size) return std::nullopt;
    return it->second.pa + (va - it->first);
}

// ---- P6.0: granules shared between mappings ------------------------------------------------
// Horizon reference-counts pages: a heap page mapped elsewhere by MapProcessMemory outlives its
// heap mapping. Lobo keeps such granules in physical_owned_ until no backing uses them.

bool VmManager::referenced(const PhysicalRun& o) const noexcept {
    for (const auto& [va, b] : backing_)
        if (b.pa < o.pa + o.size && o.pa < b.pa + b.size) return true;
    return false;
}

void VmManager::release_owned(const PhysicalRun& run) {
    if (!referenced(run)) {
        scrub(run.pa, run.size);
        if (!allocator_.free(run.pa, run.size)) broken_ = true;
        return;
    }
    // granule by granule: only the ones another mapping uses are kept
    const uint64_t g = ArenaAllocator::kGranule;
    for (uint64_t off = 0; off < run.size; off += g) {
        const PhysicalRun piece{run.pa + off, std::min(g, run.size - off)};
        if (referenced(piece)) { physical_owned_.push_back(piece); continue; }
        scrub(piece.pa, piece.size);
        if (!allocator_.free(piece.pa, piece.size)) broken_ = true;
    }
}

void VmManager::collect_owned() {
    for (auto o = physical_owned_.begin(); o != physical_owned_.end();) {
        if (referenced(*o)) { ++o; continue; }
        scrub(o->pa, o->size);
        if (!allocator_.free(o->pa, o->size)) broken_ = true;
        o = physical_owned_.erase(o);
    }
}

// ---- P6.0: the process memory SVCs on the own process -------------------------------------

uint32_t VmManager::check_state(uint64_t a, uint64_t s, uint32_t state_mask, uint32_t state, uint32_t perm_mask,
                                uint32_t perm, uint32_t attr_mask, uint32_t attr) const {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    return check(a, a + s, state_mask, state, perm_mask, perm, attr_mask, attr);
}

uint32_t VmManager::check_each(uint64_t a, uint64_t s, uint32_t state_mask, uint32_t state, uint32_t perm_mask,
                               uint32_t perm, uint32_t attr_mask, uint32_t attr) const {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    auto it = blocks_.upper_bound(a);
    --it;
    for (; it != blocks_.end() && it->first < a + s; ++it) {
        const Block& b = it->second;
        if ((b.state & state_mask) != state || (b.perm & perm_mask) != perm || (b.attr & attr_mask) != attr)
            return r::InvalidCurrentMemory;
    }
    return r::Success;
}

uint32_t VmManager::map_process_memory(uint64_t dst, uint64_t src, uint64_t s) {
    // svc MapProcessMemory: src_pt.MakeAndOpenPageGroup(CanMapProcess, any permission, no
    // attribute), then dst_pt.MapPageGroup(SharedCode, RW). The svc layer checked alignment,
    // Contains(src) and CanContain(dst, SharedCode).
    if (!contains(src, s) || !contains(dst, s)) return r::InvalidCurrentMemory;
    if (const auto rc = check(src, src + s, FlagCanMapProcess | FlagReferenceCounted, FlagCanMapProcess | FlagReferenceCounted,
                              0, 0, All, 0);
        rc)
        return rc;
    PageGroup g;
    for (const Run& run : runs(src, src + s)) g.runs.push_back({run.pa, run.size});
    if (g.size() != s) return r::InvalidCurrentMemory;
    return map_page_group(dst, s, g, SharedCode, PermRW);
}

uint32_t VmManager::unmap_process_memory(uint64_t dst, uint64_t src, uint64_t s) {
    // KPageTableBase::UnmapProcessMemory: dst SharedCode RW without attributes, src
    // CanMapProcess without attributes, and both backed by the same pages.
    if (!contains(dst, s) || !contains(src, s)) return r::InvalidCurrentMemory;
    if (const auto rc = check(dst, dst + s, All, SharedCode, PermRW, PermRW, All, 0); rc) return rc;
    if (const auto rc = check(src, src + s, FlagCanMapProcess, FlagCanMapProcess, 0, 0, All, 0); rc) return rc;
    for (uint64_t off = 0; off < s; off += PageSize) {
        const auto a = physical(src + off), b = physical(dst + off);
        if (!a || !b || *a != *b) return r::InvalidMemoryRegion;
    }
    remove_backing(dst, dst + s);
    update(dst, dst + s, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    sync_mmu(dst, dst + s);
    collect_owned();
    return r::Success;
}

uint32_t VmManager::map_insecure_memory(uint64_t a, uint64_t s) {
    // KPageTableBase::MapInsecurePhysicalMemory: reserve (OutOfMemory, not LimitReached),
    // allocate zeroed pages, the range must be Free, map Insecure RW.
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    auto g = allocate_group(s);
    if (!g) return r::OutOfMemory;
    if (const auto rc = check(a, a + s, All, Free, 0, 0, 0, 0); rc) { free_group(*g); return rc; }
    uint64_t va = a;
    for (const auto& run : g->runs) { backing_.emplace(va, Backing{run.size, run.pa, false}); va += run.size; }
    update(a, a + s, Insecure, PermRW, 0, vm_merge::Normal, vm_merge::None);
    sync_mmu(a, a + s);
    for (const auto& o : g->owned) physical_owned_.push_back(o);
    insecure_mapped_ += s;
    return r::Success;
}

uint32_t VmManager::unmap_insecure_memory(uint64_t a, uint64_t s) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    if (const auto rc = check(a, a + s, All, Insecure, All, PermRW, All, 0); rc) return rc;
    remove_backing(a, a + s);
    update(a, a + s, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    sync_mmu(a, a + s);
    insecure_mapped_ -= std::min(insecure_mapped_, s);
    collect_owned();
    return r::Success;
}

uint32_t VmManager::query_physical_address(uint64_t address, PhysicalInfo& out) const {
    // KPageTableBase::QueryPhysicalAddress: the block must have CanQueryPhysical and be user
    // readable and not executable; the answer is the physically contiguous run of the block
    // that contains the address. Physical addresses are the arena's plus kDramBase (D-P6.0-7).
    out = {};
    address &= ~(PageSize - 1);
    if (!contains(address, 1)) return r::InvalidCurrentMemory;
    auto it = blocks_.upper_bound(address);
    --it;
    const Block& b = it->second;
    if ((b.state & FlagCanQueryPhysical) == 0 || (b.perm & PermRX) != PermR) return r::InvalidCurrentMemory;
    const uint64_t block_begin = it->first, block_end = it->first + b.size;
    const auto rs = runs(block_begin, block_end);
    if (rs.empty()) return r::InvalidCurrentMemory;
    // group the runs into physically contiguous extents; pick the one holding `address`
    uint64_t ext_va = rs[0].va, ext_pa = rs[0].pa, ext_size = 0;
    for (const Run& run : rs) {
        const bool continues = run.va == ext_va + ext_size && run.pa == ext_pa + ext_size;
        if (!continues) {
            if (ext_va <= address && address < ext_va + ext_size) break;
            ext_va = run.va;
            ext_pa = run.pa;
            ext_size = 0;
        }
        ext_size += run.size;
    }
    if (!(ext_va <= address && address < ext_va + ext_size)) return r::InvalidCurrentMemory;
    out = {kDramBase + ext_pa, ext_va, ext_size};
    return r::Success;
}

// ---- P6.0: guest IPC -----------------------------------------------------------------------

namespace {
/** Byte copies through the AddressSpace (its read8/write8 keep code-watch semantics). */
bool as_read(const memory::AddressSpace& m, uint64_t pa, void* dst, uint64_t n) {
    auto* o = static_cast<uint8_t*>(dst);
    for (uint64_t i = 0; i < n; ++i) { const auto v = m.read8(pa + i); if (!v) return false; o[i] = *v; }
    return true;
}
bool as_write(memory::AddressSpace& m, uint64_t pa, const void* src, uint64_t n) {
    const auto* in = static_cast<const uint8_t*>(src);
    for (uint64_t i = 0; i < n; ++i) if (!m.try_write8(pa + i, in[i])) return false;
    return true;
}
} // namespace

bool VmManager::read_linear(uint64_t va, void* dst, uint64_t size) const {
    auto* out = static_cast<uint8_t*>(dst);
    while (size) {
        const auto pa = physical(va);
        if (!pa) return false;
        const uint64_t n = std::min(size, PageSize - (va & (PageSize - 1)));
        if (!as_read(memory_, *pa, out, n)) return false;
        va += n; out += n; size -= n;
    }
    return true;
}

bool VmManager::write_linear(uint64_t va, const void* src, uint64_t size) {
    // checked first: all or nothing
    for (uint64_t p = va & ~(PageSize - 1); p < va + size; p += PageSize)
        if (!physical(p)) return false;
    const auto* in = static_cast<const uint8_t*>(src);
    while (size) {
        const auto pa = physical(va);
        const uint64_t n = std::min(size, PageSize - (va & (PageSize - 1)));
        if (!pa || !as_write(memory_, *pa, in, n)) { broken_ = true; return false; }
        va += n; in += n; size -= n;
    }
    return true;
}

namespace {
/** KPageTableBase::SetupForIpcClient's tests per destination state. */
bool ipc_test(uint32_t dst_state, uint32_t& test_state, uint32_t& test_attr_mask) {
    const uint32_t all_attr = AttrLocked | AttrIpcLocked | AttrDeviceShared | AttrUncached | AttrPermissionLocked;
    switch (dst_state) {
        case Ipc: test_state = FlagCanUseIpc; test_attr_mask = all_attr & ~(AttrPermissionLocked | AttrIpcLocked); return true;
        case NonSecureIpc:
            test_state = FlagCanUseNonSecureIpc;
            test_attr_mask = all_attr & ~(AttrPermissionLocked | AttrDeviceShared | AttrIpcLocked);
            return true;
        case NonDeviceIpc:
            test_state = FlagCanUseNonDeviceIpc;
            test_attr_mask = all_attr & ~(AttrPermissionLocked | AttrDeviceShared | AttrIpcLocked);
            return true;
        default: return false;
    }
}
} // namespace

uint32_t VmManager::ipc_lock_client(uint64_t a, uint64_t s, uint32_t dst_state, bool write) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    uint32_t test_state = 0, test_attr = 0;
    if (!ipc_test(dst_state, test_state, test_attr)) return r::InvalidCombination;
    const uint32_t test_perm = write ? PermRW : PermR;
    const uint64_t aligned_start = a & ~(PageSize - 1), aligned_end = (a + s + PageSize - 1) & ~(PageSize - 1);
    const uint64_t map_start = (a + PageSize - 1) & ~(PageSize - 1), map_end = (a + s) & ~(PageSize - 1);
    // every block of the aligned range is checked on its own (CheckMemoryState(iterator))
    auto it = blocks_.upper_bound(aligned_start);
    --it;
    for (; it != blocks_.end() && it->first < aligned_end; ++it) {
        const Block& b = it->second;
        if ((b.state & test_state) != test_state || (b.perm & test_perm) != test_perm || (b.attr & test_attr) != 0)
            return r::InvalidCurrentMemory;
    }
    if (map_start >= map_end) return r::Success;   // no whole page: nothing is locked
    split_block(map_start);
    split_block(map_end);
    for (auto b = blocks_.find(map_start); b != blocks_.end() && b->first < map_end; ++b) {
        Block& blk = b->second;
        if (blk.ipc++ == 0) {   // KMemoryBlock::LockForIpc
            blk.orig_perm = blk.perm;
            blk.perm = write ? (blk.perm & PermX) : ((blk.perm & PermX) | PermR);
        }
        blk.attr |= AttrIpcLocked;
    }
    coalesce(map_start, map_end);
    sync_mmu(map_start, map_end);
    return r::Success;
}

uint32_t VmManager::ipc_unlock_client(uint64_t a, uint64_t s, uint32_t dst_state) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    const uint64_t map_start = (a + PageSize - 1) & ~(PageSize - 1), map_end = (a + s) & ~(PageSize - 1);
    if (map_start >= map_end) return r::Success;
    uint32_t test_state = 0, test_attr = 0;
    if (!ipc_test(dst_state, test_state, test_attr)) return r::InvalidCombination;
    auto it = blocks_.upper_bound(map_start);
    --it;
    for (auto c = it; c != blocks_.end() && c->first < map_end; ++c)
        if ((c->second.state & test_state) != test_state || (c->second.attr & AttrIpcLocked) == 0 || c->second.ipc == 0)
            return r::InvalidCurrentMemory;
    split_block(map_start);
    split_block(map_end);
    for (auto b = blocks_.find(map_start); b != blocks_.end() && b->first < map_end; ++b) {
        Block& blk = b->second;
        if (--blk.ipc == 0) {   // KMemoryBlock::UnlockForIpc
            blk.perm = blk.orig_perm;
            blk.orig_perm = 0;
            blk.attr &= ~AttrIpcLocked;
        }
    }
    coalesce(map_start, map_end);
    sync_mmu(map_start, map_end);
    return r::Success;
}

uint64_t VmManager::find_free_area(uint64_t region, uint64_t region_size, uint64_t size, uint64_t align, uint64_t offset,
                                   uint64_t guard) const {
    // KMemoryBlockManager::FindFreeArea, first fit: a Free block holding guard + size + guard
    // with the start at `offset` modulo `align`.
    const uint64_t region_end = region + region_size;
    auto it = blocks_.upper_bound(region);
    if (it != blocks_.begin()) --it;
    for (; it != blocks_.end() && it->first < region_end; ++it) {
        if (it->second.state != Free) continue;
        const uint64_t lo = std::max(it->first, region), hi = std::min(it->first + it->second.size, region_end);
        if (hi <= lo) continue;
        uint64_t cand = ((lo + guard + align - 1 - offset) / align) * align + offset;
        if (cand < lo + guard) cand += align;
        if (cand + size + guard <= hi && cand + size > cand) return cand;
    }
    return 0;
}

uint32_t VmManager::ipc_map_server(uint64_t src, uint64_t s, uint32_t dst_state, bool write, bool send, uint64_t& out) {
    out = 0;
    // KPageTableBase::SetupForIpcServer (the destination is this process's alias region)
    if (s >= config_.alias_size) return r::OutOfAddressSpace;
    const uint64_t src_end = src + s;
    const uint64_t aligned_start = src & ~(PageSize - 1), aligned_end = (src_end + PageSize - 1) & ~(PageSize - 1);
    const uint64_t map_start = (src + PageSize - 1) & ~(PageSize - 1), map_end = src_end & ~(PageSize - 1);
    const uint64_t aligned_size = aligned_end - aligned_start;
    // the largest block alignment the source offset allows first (KPageTable block sizes)
    uint64_t dst = 0;
    for (const uint64_t align : {uint64_t{1} << 30, uint64_t{32} << 20, uint64_t{2} << 20, uint64_t{64} << 10, uint64_t{PageSize}}) {
        dst = find_free_area(config_.alias_base, config_.alias_size, aligned_size, align, aligned_start & (align - 1),
                             4 * PageSize);   // GetNumGuardPages() for a user process
        if (dst) break;
    }
    if (!dst) return r::OutOfAddressSpace;
    const bool start_partial = aligned_start < map_start;
    const bool end_partial = map_end < aligned_end && (aligned_start < map_end || aligned_start == map_start);
    std::optional<PageGroup> head, tail;
    if (start_partial && !(head = allocate_group(PageSize))) return r::OutOfMemory;
    if (end_partial && !(tail = allocate_group(PageSize))) { if (head) free_group(*head); return r::OutOfMemory; }
    std::vector<uint8_t> page(PageSize, 0);   // m_ipc_fill_value: zero on retail
    if (head) {
        std::fill(page.begin(), page.end(), 0);
        if (send) {
            const uint64_t off = src - aligned_start;
            const uint64_t copy = src_end < map_start ? s : map_start - src;
            if (!read_linear(src, page.data() + off, copy)) { free_group(*head); if (tail) free_group(*tail); return r::InvalidCurrentMemory; }
        }
        if (!as_write(memory_, head->runs[0].pa, page.data(), PageSize)) broken_ = true;
    }
    if (tail) {
        std::fill(page.begin(), page.end(), 0);
        if (send && !read_linear(map_end, page.data(), src_end - map_end)) {
            if (head) free_group(*head);
            free_group(*tail);
            return r::InvalidCurrentMemory;
        }
        if (!as_write(memory_, tail->runs[0].pa, page.data(), PageSize)) broken_ = true;
    }
    uint64_t va = dst;
    if (head) { backing_.emplace(va, Backing{PageSize, head->runs[0].pa, false}); va += PageSize; }
    if (map_start < map_end)
        for (const Run& run : runs(map_start, map_end)) { backing_.emplace(va, Backing{run.size, run.pa, false}); va += run.size; }
    if (tail) { backing_.emplace(va, Backing{PageSize, tail->runs[0].pa, false}); va += PageSize; }
    if (va != dst + aligned_size) {   // a hole in the client's backing: never for user memory
        remove_backing(dst, va);
        if (head) free_group(*head);
        if (tail) free_group(*tail);
        return r::InvalidCurrentMemory;
    }
    if (head) for (const auto& o : head->owned) physical_owned_.push_back(o);
    if (tail) for (const auto& o : tail->owned) physical_owned_.push_back(o);
    update(dst, dst + aligned_size, dst_state, write ? PermRW : PermR, 0, vm_merge::Normal, vm_merge::None);
    sync_mmu(dst, dst + aligned_size);
    out = dst + (src - aligned_start);
    return r::Success;
}

uint32_t VmManager::ipc_unmap_server(uint64_t a, uint64_t s, uint32_t dst_state) {
    if (!contains(a, s)) return r::InvalidCurrentMemory;
    if (const auto rc = check(a, a + s, All, dst_state, PermR, PermR, All, 0); rc) return rc;
    const uint64_t start = a & ~(PageSize - 1), end = (a + s + PageSize - 1) & ~(PageSize - 1);
    remove_backing(start, end);
    update(start, end, Free, PermNone, 0, vm_merge::None, vm_merge::Normal);
    sync_mmu(start, end);
    collect_owned();   // the partial pages
    return r::Success;
}

uint64_t VmManager::ipc_locked_blocks() const noexcept {
    uint64_t n = 0;
    for (const auto& [va, b] : blocks_) n += b.ipc;
    return n;
}

} // namespace lg::system
