#pragma once
// P3.1: the system-call dispatcher (P3_1_DISENO.md §2.1-2.8).
//
// Contract with the CPU engines (audit A1/A2): every engine stops a guest thread AT its SVC
// with exception = {Svc, pc of the SVC, imm16} and execute_state() returning an error. The
// coordinator's thread entry calls handle() for exactly that case. For a Continue outcome
// handle() leaves the thread ready to resume: pc = SVC + 4, no pending exception, not halted,
// exclusive reservation cleared (an exception return clears the local monitor), and the
// handler's results in the registers (w0 = Result, outputs as in libnx's svc.s). The engines
// reload the whole CpuState on the next execute, so no engine is modified.
//
// Terminal and fatal outcomes leave the context untouched (pc still at the SVC) for the
// diagnostics; the coordinator ends the thread / the session.
//
// Not internally synchronised: runs on the guest-execution thread under the coordinator lock.
#include <array>
#include <cstdint>
#include <functional>
#include <string>
#include <string_view>

#include "guest_memory.h"
#include "handle_table.h"
#include "kipc.h"
#include "kobjects.h"
#include "kthread.h"
#include "svc_table.h"
#include "vm_manager.h"
#include "../cpu/guest_clock.h"

namespace lg::system {

/** Guest debug output (svcOutputDebugString): the last 64 KiB, byte exact. */
class GuestLog {
public:
    static constexpr size_t kCapacity = 64 * 1024;
    void append(std::string_view text);
    const std::string& contents() const noexcept { return buf_; }
    /** Bytes ever appended in this session (not capped by the ring). */
    uint64_t total_bytes() const noexcept { return total_; }
    /** Last non-empty line, escaped for a one-line key=value field: printable ASCII kept,
     *  '"' and '\\' escaped, every other byte as \xNN (JNI's modified UTF-8 is never fed
     *  guest bytes). At most `max_chars` characters ("..." marks a cut). */
    std::string last_line(size_t max_chars = 80) const;
    void clear() noexcept { buf_.clear(); total_ = 0; }
private:
    std::string buf_;
    uint64_t total_{};
};

/** The last SVC serviced (tests/diagnostics). */
struct SvcRecord {
    bool valid{};
    uint32_t id{};
    uint64_t pc{};
    uint64_t thread{};
    uint64_t x0{}, x1{};   // first two arguments, as the guest passed them
};

/** How the guest ended its process (P3 decision D5). */
struct GuestExit {
    bool exited{};
    bool has_code{};    // true when the program returned through Lobo's exit stub (x0 = code)
    int32_t code{};
    uint64_t pc{};      // address of the ExitProcess SVC
};

/** Per-session facts the dispatcher answers with. */
struct SvcSessionConfig {
    uint64_t process_id{};
    uint64_t program_id{};                 // D-P3.1-1: the NCA's title id; 0 for NRO/plain NSO
    uint64_t exit_stub_va{};               // 0 = no homebrew exit stub (NSO/NCA/synthetic)
    const cpu::GuestClock* clock{};        // the session's GuestClock (outlives the session)
    std::array<uint64_t, 4> entropy{};     // GetInfo(RandomEntropy), fixed per prepare()
    VmManager* vm{};                       // P3.2: the process memory (nullptr = synthetic image)
    KernelThreads* kthreads{};             // P3.3: threads and synchronization (nullptr = synthetic image)
    KernelIpc* ipc{};                      // P3.4: ports, sessions, HLE services (nullptr = synthetic image)
    KernelObjects* kobjects{};             // P6.0: memory objects, resource limit (nullptr = synthetic image)
    bool is_application{};                 // P6.0: GetInfo(IsApplication), D-P6.0-6
};

class SvcDispatcher {
public:
    static constexpr size_t kMaxDebugString = 64 * 1024;        // D-P3.1-3
    // hbloader's NPDM (hbl.json): cores 0-2 (core 3 belongs to the system), priorities 28-59.
    static constexpr uint64_t kCoreMask = 0x7;
    static constexpr uint64_t kPriorityMask = ((1ull << 60) - 1) & ~((1ull << 28) - 1);
    using LogSink = std::function<void(const std::string&)>;

    SvcDispatcher(memory::AddressSpace& memory, const memory::Mmu& mmu) noexcept : memory_(memory, mmu) {}

    /** New session: clears handles, the guest log, the counters and the exit record. */
    void begin_session(const SvcSessionConfig& config);
    /** Session teardown: drops the handles (their kernel objects are gone). The log, the
     *  counters and the exit record stay readable until the next begin_session(). */
    void end_session() noexcept;

    /** Services the SVC the thread stopped at (ctx.exception.kind == Svc). */
    SvcOutcome handle(uint64_t thread, cpu::CpuState& ctx);

    HandleTable& handles() noexcept { return handles_; }
    const HandleTable& handles() const noexcept { return handles_; }
    GuestMemory& guest_memory() noexcept { return memory_; }
    const GuestLog& log() const noexcept { return log_; }
    /** Optional mirror of every debug string (Android: logcat "LoboGuest", D-P3.1-4). Called
     *  on the guest-execution thread; it must not call back into the coordinator. */
    void set_log_sink(LogSink sink) { sink_ = std::move(sink); }
    const GuestExit& exit() const noexcept { return exit_; }
    const SvcRecord& last() const noexcept { return last_; }
    uint64_t calls(uint32_t id) const noexcept { return id < kSvcCount ? calls_[id] : 0; }
    uint64_t total_calls() const noexcept { return total_calls_; }
    uint64_t invalid_calls() const noexcept { return invalid_calls_; }
    uint64_t break_notifications() const noexcept { return break_notifications_; }
    const SvcSessionConfig& session() const noexcept { return config_; }

    /** 4 x 64 random bits for a new session. */
    static std::array<uint64_t, 4> fresh_entropy();
    /** "2345-0030" for a Horizon Result (2000 + module, description). */
    static std::string result_text(uint32_t result);
    static const char* break_reason_name(uint32_t reason) noexcept;

private:
    friend struct SvcHandlers;
    GuestMemory memory_;
    HandleTable handles_;
    GuestLog log_;
    LogSink sink_;
    SvcSessionConfig config_{};
    GuestExit exit_{};
    SvcRecord last_{};
    std::array<uint64_t, kSvcCount> calls_{};
    uint64_t total_calls_{};
    uint64_t invalid_calls_{};
    uint64_t break_notifications_{};
    uint64_t unsafe_limit_{}, unsafe_used_{};   // P6.0: KUnsafeMemory (SetUnsafeLimit)
    uint64_t sleep_requests_{};                 // P6.0: SleepSystem calls (diagnostics)
public:
    uint64_t sleep_requests() const noexcept { return sleep_requests_; }
};

/** The P3.1 handlers (registers from libnx's svc.s / svc.h). */
struct SvcHandlers {
    static SvcOutcome exit_process(SvcDispatcher& d, SvcCall& c);          // 0x07
    static SvcOutcome close_handle(SvcDispatcher& d, SvcCall& c);          // 0x16  W0 handle -> W0
    static SvcOutcome get_system_tick(SvcDispatcher& d, SvcCall& c);       // 0x1E  -> X0
    static SvcOutcome get_process_id(SvcDispatcher& d, SvcCall& c);        // 0x24  W1 handle -> W0, X1
    static SvcOutcome break_(SvcDispatcher& d, SvcCall& c);                // 0x26  W0 reason, X1 addr, X2 size
    static SvcOutcome output_debug_string(SvcDispatcher& d, SvcCall& c);   // 0x27  X0 str, X1 size -> W0
    static SvcOutcome get_info(SvcDispatcher& d, SvcCall& c);              // 0x29  W1 id0, W2 handle, X3 id1 -> W0, X1
    // P3.2 (P3_2_DISENO.md): process memory.
    static SvcOutcome set_heap_size(SvcDispatcher& d, SvcCall& c);         // 0x01  X1 size -> W0, X1 address
    static SvcOutcome set_memory_permission(SvcDispatcher& d, SvcCall& c); // 0x02  X0 addr, X1 size, W2 perm -> W0
    static SvcOutcome set_memory_attribute(SvcDispatcher& d, SvcCall& c);  // 0x03  X0 addr, X1 size, W2 mask, W3 attr -> W0
    static SvcOutcome map_memory(SvcDispatcher& d, SvcCall& c);            // 0x04  X0 dst, X1 src, X2 size -> W0
    static SvcOutcome unmap_memory(SvcDispatcher& d, SvcCall& c);          // 0x05  X0 dst, X1 src, X2 size -> W0
    static SvcOutcome query_memory(SvcDispatcher& d, SvcCall& c);          // 0x06  X0 MemoryInfo*, X2 addr -> W0, W1 page info
    static SvcOutcome flush_entire_data_cache(SvcDispatcher& d, SvcCall& c); // 0x2A -> W0
    static SvcOutcome flush_data_cache(SvcDispatcher& d, SvcCall& c);      // 0x2B  X0 addr, X1 size -> W0
    // P3.3 (P3_3_DISENO.md): threads and synchronization.
    static SvcOutcome create_thread(SvcDispatcher& d, SvcCall& c);         // 0x08  X1 entry, X2 arg, X3 stack, W4 prio, W5 core -> W0, W1 handle
    static SvcOutcome start_thread(SvcDispatcher& d, SvcCall& c);          // 0x09  W0 handle -> W0
    static SvcOutcome exit_thread(SvcDispatcher& d, SvcCall& c);           // 0x0A
    static SvcOutcome sleep_thread(SvcDispatcher& d, SvcCall& c);          // 0x0B  X0 ns
    static SvcOutcome get_thread_priority(SvcDispatcher& d, SvcCall& c);   // 0x0C  W1 handle -> W0, W1 prio
    static SvcOutcome set_thread_priority(SvcDispatcher& d, SvcCall& c);   // 0x0D  W0 handle, W1 prio -> W0
    static SvcOutcome get_thread_core_mask(SvcDispatcher& d, SvcCall& c);  // 0x0E  W2 handle -> W0, W1 core, X2 mask
    static SvcOutcome set_thread_core_mask(SvcDispatcher& d, SvcCall& c);  // 0x0F  W0 handle, W1 core, X2 mask -> W0
    static SvcOutcome get_current_processor_number(SvcDispatcher& d, SvcCall& c); // 0x10 -> W0
    static SvcOutcome signal_event(SvcDispatcher& d, SvcCall& c);          // 0x11  W0 handle -> W0
    static SvcOutcome clear_event(SvcDispatcher& d, SvcCall& c);           // 0x12  W0 handle -> W0
    static SvcOutcome reset_signal(SvcDispatcher& d, SvcCall& c);          // 0x17  W0 handle -> W0
    static SvcOutcome wait_synchronization(SvcDispatcher& d, SvcCall& c);  // 0x18  X1 handles*, W2 n, X3 timeout -> W0, W1 index
    static SvcOutcome cancel_synchronization(SvcDispatcher& d, SvcCall& c); // 0x19 W0 handle -> W0
    static SvcOutcome arbitrate_lock(SvcDispatcher& d, SvcCall& c);        // 0x1A  W0 owner, X1 addr, W2 tag -> W0
    static SvcOutcome arbitrate_unlock(SvcDispatcher& d, SvcCall& c);      // 0x1B  X0 addr -> W0
    static SvcOutcome wait_process_wide_key_atomic(SvcDispatcher& d, SvcCall& c); // 0x1C X0 addr, X1 key, W2 tag, X3 timeout -> W0
    static SvcOutcome signal_process_wide_key(SvcDispatcher& d, SvcCall& c); // 0x1D X0 key, W1 count
    static SvcOutcome get_thread_id(SvcDispatcher& d, SvcCall& c);         // 0x25  W1 handle -> W0, X1 id
    static SvcOutcome wait_for_address(SvcDispatcher& d, SvcCall& c);      // 0x34  X0 addr, W1 type, X2 value, X3 timeout -> W0
    static SvcOutcome signal_to_address(SvcDispatcher& d, SvcCall& c);     // 0x35  X0 addr, W1 type, W2 value, W3 count -> W0
    static SvcOutcome create_event(SvcDispatcher& d, SvcCall& c);          // 0x45  -> W0, W1 write, W2 read
    // P3.4 (P3_4_DISENO.md): IPC.
    static SvcOutcome connect_to_named_port(SvcDispatcher& d, SvcCall& c); // 0x1F  X1 name -> W0, W1 handle
    static SvcOutcome send_sync_request(SvcDispatcher& d, SvcCall& c);     // 0x21  W0 session (message in the TLS) -> W0
    // P6.0 (P6_DISENO.md §3.3), svc_p6.cpp: memory objects and resource limits.
    static SvcOutcome map_shared_memory(SvcDispatcher& d, SvcCall& c);     // 0x13  W0 shmem, X1 addr, X2 size, W3 perm -> W0
    static SvcOutcome unmap_shared_memory(SvcDispatcher& d, SvcCall& c);   // 0x14  W0 shmem, X1 addr, X2 size -> W0
    static SvcOutcome create_transfer_memory(SvcDispatcher& d, SvcCall& c); // 0x15 X1 addr, X2 size, W3 perm -> W0, W1 handle
    static SvcOutcome map_physical_memory(SvcDispatcher& d, SvcCall& c);   // 0x2C  X0 addr, X1 size -> W0
    static SvcOutcome unmap_physical_memory(SvcDispatcher& d, SvcCall& c); // 0x2D  X0 addr, X1 size -> W0
    static SvcOutcome get_resource_limit_limit_value(SvcDispatcher& d, SvcCall& c);   // 0x30 W1 handle, W2 which -> W0, X1
    static SvcOutcome get_resource_limit_current_value(SvcDispatcher& d, SvcCall& c); // 0x31
    static SvcOutcome get_resource_limit_peak_value(SvcDispatcher& d, SvcCall& c);    // 0x37
    static SvcOutcome map_physical_memory_unsafe(SvcDispatcher& d, SvcCall& c);       // 0x48 X0 addr, X1 size -> W0
    static SvcOutcome unmap_physical_memory_unsafe(SvcDispatcher& d, SvcCall& c);     // 0x49
    static SvcOutcome set_unsafe_limit(SvcDispatcher& d, SvcCall& c);      // 0x4A  X0 limit -> W0
    static SvcOutcome create_code_memory(SvcDispatcher& d, SvcCall& c);    // 0x4B  X1 addr, X2 size -> W0, W1 handle
    static SvcOutcome control_code_memory(SvcDispatcher& d, SvcCall& c);   // 0x4C  W0 h, W1 op, X2 addr, X3 size, W4 perm -> W0
    static SvcOutcome create_shared_memory(SvcDispatcher& d, SvcCall& c);  // 0x50  X1 size, W2 owner, W3 remote -> W0, W1 handle
    static SvcOutcome map_transfer_memory(SvcDispatcher& d, SvcCall& c);   // 0x51  W0 h, X1 addr, X2 size, W3 perm -> W0
    static SvcOutcome unmap_transfer_memory(SvcDispatcher& d, SvcCall& c); // 0x52  W0 h, X1 addr, X2 size -> W0
    static SvcOutcome create_resource_limit(SvcDispatcher& d, SvcCall& c); // 0x7D  -> W0, W1 handle
    static SvcOutcome set_resource_limit_limit_value(SvcDispatcher& d, SvcCall& c); // 0x7E W0 h, W1 which, X2 value -> W0
    // P6.0, svc_p6_system.cpp: threads, the retail debug/profiling answers, the own process,
    // insecure and physical memory, kernel debug, power, registers and the secure monitor.
    static SvcOutcome return_from_exception(SvcDispatcher& d, SvcCall& c);        // 0x28 W0 result
    static SvcOutcome get_debug_future_thread_info(SvcDispatcher& d, SvcCall& c); // 0x2E W2 debug, X3 ns -> W0, X1-X4 ctx, X5 tid
    static SvcOutcome get_last_thread_info(SvcDispatcher& d, SvcCall& c);         // 0x2F -> W0, X1-X4 ctx, X5 tls, W6 flags
    static SvcOutcome set_thread_activity(SvcDispatcher& d, SvcCall& c);          // 0x32 W0 h, W1 activity -> W0
    static SvcOutcome get_thread_context3(SvcDispatcher& d, SvcCall& c);          // 0x33 X0 ctx*, W1 h -> W0
    static SvcOutcome synchronize_preemption_state(SvcDispatcher& d, SvcCall& c); // 0x36
    static SvcOutcome kernel_debug(SvcDispatcher& d, SvcCall& c);                 // 0x3C W0 type, X1-X3 args
    static SvcOutcome change_kernel_trace_state(SvcDispatcher& d, SvcCall& c);    // 0x3D W0 state
    static SvcOutcome sleep_system(SvcDispatcher& d, SvcCall& c);                 // 0x4D
    static SvcOutcome read_write_register(SvcDispatcher& d, SvcCall& c);          // 0x4E X1 addr, W2 mask, W3 value -> W0, W1
    static SvcOutcome set_process_activity(SvcDispatcher& d, SvcCall& c);         // 0x4F W0 h, W1 activity -> W0
    static SvcOutcome query_physical_address(SvcDispatcher& d, SvcCall& c);       // 0x54 X1 va -> W0, X1 pa, X2 va, X3 size
    static SvcOutcome query_memory_mapping(SvcDispatcher& d, SvcCall& c);         // 0x55 X2 pa, X3 size -> W0, X1 va, X2 size
    static SvcOutcome invalidate_process_data_cache(SvcDispatcher& d, SvcCall& c); // 0x5D W0 h, X1 addr, X2 size -> W0
    static SvcOutcome store_process_data_cache(SvcDispatcher& d, SvcCall& c);     // 0x5E
    static SvcOutcome flush_process_data_cache(SvcDispatcher& d, SvcCall& c);     // 0x5F
    static SvcOutcome debug_retail(SvcDispatcher& d, SvcCall& c);                 // 0x60-0x6D (retail: NotImplemented)
    static SvcOutcome get_system_info(SvcDispatcher& d, SvcCall& c);              // 0x6F W1 type, W2 h, X3 sub -> W0, X1
    static SvcOutcome set_process_memory_permission(SvcDispatcher& d, SvcCall& c); // 0x73 W0 h, X1 addr, X2 size, W3 perm
    static SvcOutcome map_process_memory(SvcDispatcher& d, SvcCall& c);           // 0x74 X0 dst, W1 h, X2 src, X3 size
    static SvcOutcome unmap_process_memory(SvcDispatcher& d, SvcCall& c);         // 0x75
    static SvcOutcome query_process_memory(SvcDispatcher& d, SvcCall& c);         // 0x76 X0 info*, W2 h, X3 addr -> W0, W1
    static SvcOutcome map_process_code_memory(SvcDispatcher& d, SvcCall& c);      // 0x77 W0 h, X1 dst, X2 src, X3 size
    static SvcOutcome unmap_process_code_memory(SvcDispatcher& d, SvcCall& c);    // 0x78
    static SvcOutcome create_process(SvcDispatcher& d, SvcCall& c);               // 0x79 X1 params*, X2 caps*, W3 n -> W0, W1
    static SvcOutcome start_process(SvcDispatcher& d, SvcCall& c);                // 0x7A W0 h, W1 prio, W2 core, X3 stack
    static SvcOutcome terminate_process(SvcDispatcher& d, SvcCall& c);            // 0x7B W0 h
    static SvcOutcome get_process_info(SvcDispatcher& d, SvcCall& c);             // 0x7C W1 h, W2 type -> W0, X1
    static SvcOutcome call_secure_monitor(SvcDispatcher& d, SvcCall& c);          // 0x7F X0-X7 (frontier, D-P6-3)
    static SvcOutcome map_insecure_physical_memory(SvcDispatcher& d, SvcCall& c);   // 0x90 X0 addr, X1 size
    static SvcOutcome unmap_insecure_physical_memory(SvcDispatcher& d, SvcCall& c); // 0x91
    // P6.0: hardware the emulated console does not have (no PCIe I/O pool, no interrupt
    // capability, no SMMU): Horizon's answers on such a board (D-P6.0-4).
    static SvcOutcome create_io_pool(SvcDispatcher& d, SvcCall& c);       // 0x39 W1 type -> W0, W1
    static SvcOutcome create_io_region(SvcDispatcher& d, SvcCall& c);     // 0x3A W1 pool, X2 pa, X3 size, W4 map, W5 perm
    static SvcOutcome map_io_region(SvcDispatcher& d, SvcCall& c);        // 0x46 W0 h, X1 addr, X2 size, W3 perm
    static SvcOutcome unmap_io_region(SvcDispatcher& d, SvcCall& c);      // 0x47 W0 h, X1 addr, X2 size
    static SvcOutcome create_interrupt_event(SvcDispatcher& d, SvcCall& c); // 0x53 W1 irq, W2 type -> W0, W1
    static SvcOutcome create_device_address_space(SvcDispatcher& d, SvcCall& c); // 0x56 X1 addr, X2 size -> W0, W1
    static SvcOutcome attach_device_address_space(SvcDispatcher& d, SvcCall& c); // 0x57/0x58 W0 device, W1 h
    static SvcOutcome map_device_address_space(SvcDispatcher& d, SvcCall& c);    // 0x59/0x5A W0 das, W1 proc, X2, X3, X4, W5
    static SvcOutcome legacy_map_device_address_space(SvcDispatcher& d, SvcCall& c); // 0x5B (removed in 13.0.0)
    static SvcOutcome unmap_device_address_space(SvcDispatcher& d, SvcCall& c);  // 0x5C W0 das, W1 proc, X2, X3, X4
    // P6.0, svc_p6_ipc.cpp: guest-written servers, user buffers, async and light IPC.
    static SvcOutcome send_sync_request_light(SvcDispatcher& d, SvcCall& c);            // 0x20 W0 h, W1-W7 data
    static SvcOutcome send_sync_request_with_user_buffer(SvcDispatcher& d, SvcCall& c); // 0x22 X0 buf, X1 size, W2 h
    static SvcOutcome send_async_request_with_user_buffer(SvcDispatcher& d, SvcCall& c); // 0x23 X1 buf, X2 size, W3 h -> W1 event
    static SvcOutcome create_session(SvcDispatcher& d, SvcCall& c);                     // 0x40 W2 light, X3 name -> W1, W2
    static SvcOutcome accept_session(SvcDispatcher& d, SvcCall& c);                     // 0x41 W1 port -> W1
    static SvcOutcome reply_and_receive_light(SvcDispatcher& d, SvcCall& c);            // 0x42 W0 h, W1-W7 data
    static SvcOutcome reply_and_receive(SvcDispatcher& d, SvcCall& c);                  // 0x43 X1 handles, W2 n, W3 reply, X4 ns -> W1
    static SvcOutcome reply_and_receive_with_user_buffer(SvcDispatcher& d, SvcCall& c); // 0x44 X1 buf, X2 size, X3 h*, W4, W5, X6
    static SvcOutcome create_port(SvcDispatcher& d, SvcCall& c);                        // 0x70 W2 max, W3 light, X4 name -> W1, W2
    static SvcOutcome manage_named_port(SvcDispatcher& d, SvcCall& c);                  // 0x71 X1 name, W2 max -> W1
    static SvcOutcome connect_to_port(SvcDispatcher& d, SvcCall& c);                    // 0x72 W1 port -> W1
    /** GetInfo ids added by P6.0 (9, 10, 20, 23, 24, 26-28, 34, 36-38); false = not one of them. */
    static bool get_info_p6(SvcDispatcher& d, SvcCall& c, uint32_t id0, uint32_t handle, uint64_t id1);
};

} // namespace lg::system
