#include "process_layout.h"

#include <algorithm>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

namespace lg::system {
namespace {
using memory::Execute;
using memory::Read;
using memory::User;
using memory::Write;

constexpr uint64_t align_up(uint64_t v, uint64_t a) noexcept { return (v + a - 1) & ~(a - 1); }
core::Result<ProcessLayout> fail(const char* why) {
    return core::Result<ProcessLayout>::Error((std::string("process layout: ") + why).c_str());
}
} // namespace

core::Result<uint64_t> PhysicalArenaAllocator::allocate(uint64_t bytes) noexcept {
    if (bytes == 0 || bytes > size_) return core::Result<uint64_t>::Error("guest memory budget too small");
    const uint64_t rounded = align_up(bytes, ProcessLayout::kAlign);
    const uint64_t start = align_up(next_, ProcessLayout::kAlign);
    if (start > size_ || rounded > size_ - start) return core::Result<uint64_t>::Error("guest memory budget too small");
    next_ = start + rounded;
    return core::Result<uint64_t>::Ok(base_ + start);
}

namespace {
struct Region { uint64_t offset, size; uint32_t perms; const char* what; };   // offsets from the image base
struct Chunk { uint64_t offset; const uint8_t* bytes; uint64_t size; };        // file bytes to copy

// Shared by every executable format: reserves the image, the main stack and the TLS page
// from the arena, copies the chunks, maps the image regions + stack + TLS. Nothing stays
// mapped on error. The arena is fresh (zero) on every prepare(): nothing else is written.
core::Result<ProcessLayout> build_process(uint64_t extent, const std::vector<Region>& regions,
                                          const std::vector<Chunk>& chunks, memory::AddressSpace& memory,
                                          memory::Mmu& mmu, uint64_t arena_base, uint64_t arena_size) {
    if (extent == 0 || extent > loader::NroLoader::kMaxMappedSize) return fail("invalid image size");
    if ((arena_base & (ProcessLayout::kAlign - 1)) != 0) return fail("arena base is not 64 KiB aligned");

    ProcessLayout l{};
    PhysicalArenaAllocator pa(arena_base, arena_size);
    const auto image_pa = pa.allocate(extent);
    if (!image_pa.ok()) return fail("the image does not fit in the guest memory budget");
    const auto stack_pa = pa.allocate(ProcessLayout::kMainStackSize);
    if (!stack_pa.ok()) return fail("the main stack does not fit in the guest memory budget");
    const auto tls_pa = pa.allocate(ProcessLayout::kTlsPageSize);
    if (!tls_pa.ok()) return fail("the TLS page does not fit in the guest memory budget");
    // P3.1: exit stub and configuration page (after the P3.0 regions: their addresses do not move).
    const auto stub_pa = pa.allocate(ProcessLayout::kSmallPageSize);
    if (!stub_pa.ok()) return fail("the exit stub does not fit in the guest memory budget");
    const auto config_pa = pa.allocate(ProcessLayout::kSmallPageSize);
    if (!config_pa.ok()) return fail("the configuration page does not fit in the guest memory budget");

    l.code_va = ProcessLayout::kCodeBase;
    l.image_pa = image_pa.value();
    l.mapped_size = extent;
    l.stack_bottom_va = ProcessLayout::kStackRegion + ProcessLayout::kGuardSize;
    l.stack_top_va = l.stack_bottom_va + ProcessLayout::kMainStackSize;
    l.stack_pa = stack_pa.value();
    l.tls_va = l.stack_top_va + ProcessLayout::kGuardSize;
    l.tls_pa = tls_pa.value();
    l.exit_stub_va = ProcessLayout::kExitStubVa;
    l.exit_stub_pa = stub_pa.value();
    l.config_va = ProcessLayout::kConfigVa;
    l.config_pa = config_pa.value();
    l.arena_used = pa.used();
    for (size_t i = 0; i < regions.size() && i < l.image_regions.size(); ++i)   // P3.2
        l.image_regions[i] = {regions[i].offset, regions[i].size, regions[i].perms};

    // Copy page by page through the arena (before any translation exists, so there is no
    // watched code to notify).
    for (const auto& c : chunks) {
        if (c.offset > extent || c.size > extent - c.offset) return fail("segment lies outside the image");
        for (uint64_t done = 0; done < c.size;) {
            const uint64_t pa_at = l.image_pa + c.offset + done;
            uint8_t* dst = memory.host_ptr(pa_at);
            if (!dst) return fail("arena page for the image is not mapped");
            const uint64_t room = memory::Mmu::PageSize - (pa_at & (memory::Mmu::PageSize - 1));
            const uint64_t n = std::min<uint64_t>(room, c.size - done);
            std::memcpy(dst, c.bytes + done, static_cast<size_t>(n));
            done += n;
        }
    }

    // P3.1: the exit stub's two instructions (the configuration page stays zero until the
    // coordinator writes the ConfigEntry list through GuestMemory).
    for (size_t i = 0; i < 2; ++i) {
        uint8_t* dst = memory.host_ptr(l.exit_stub_pa + 4 * i);
        if (!dst) return fail("arena page for the exit stub is not mapped");
        std::memcpy(dst, &ProcessLayout::kExitStubCode[i], 4);
    }

    std::vector<Region> maps = regions;
    maps.push_back({l.stack_bottom_va - l.code_va, ProcessLayout::kMainStackSize, Read | Write | User, "main stack"});
    maps.push_back({l.tls_va - l.code_va, ProcessLayout::kTlsPageSize, Read | Write | User, "TLS"});
    maps.push_back({l.exit_stub_va - l.code_va, ProcessLayout::kSmallPageSize, Read | Execute | User, "exit stub"});
    maps.push_back({l.config_va - l.code_va, ProcessLayout::kSmallPageSize, Read | Write | User, "configuration page"});
    const uint64_t extra_pa[] = {l.stack_pa, l.tls_pa, l.exit_stub_pa, l.config_pa};
    for (size_t i = 0; i < maps.size(); ++i) {
        const auto& m = maps[i];
        if (m.size == 0) continue;
        const bool image_region = i < regions.size();
        const uint64_t pa_at = image_region ? l.image_pa + m.offset : extra_pa[i - regions.size()];
        if (!mmu.map(l.code_va + m.offset, pa_at, m.size, m.perms)) {
            mmu.clear();   // nothing is left half-mapped
            return fail((std::string("failed to map ") + m.what).c_str());
        }
    }
    return core::Result<ProcessLayout>::Ok(l);
}
} // namespace

core::Result<ProcessLayout> build_nro_process(const loader::NroImage& image, const std::vector<uint8_t>& file,
                                              memory::AddressSpace& memory, memory::Mmu& mmu,
                                              uint64_t arena_base, uint64_t arena_size) {
    if (image.image_size > file.size()) return fail("image is larger than the file");
    if (image.mapped_size == 0 || image.mapped_size > loader::NroLoader::kMaxMappedSize)
        return fail("invalid image size");
    const std::vector<Region> regions = {
        {image.text.offset, image.text.size, Read | Execute | User, ".text"},
        {image.ro.offset, image.ro.size, Read | User, ".rodata"},
        {image.data.offset, image.rw_size, Read | Write | User, ".data/.bss"},
    };
    return build_process(image.mapped_size, regions, {{0, file.data(), image.image_size}}, memory, mmu,
                         arena_base, arena_size);
}

core::Result<ProcessLayout> build_nso_process(const loader::NsoImage& image, memory::AddressSpace& memory,
                                              memory::Mmu& mmu, uint64_t arena_base, uint64_t arena_size) {
    const auto lay = loader::NsoLoader::layout(image);
    if (!lay.ok()) return fail(lay.error().c_str());
    const auto& l = lay.value();
    const std::vector<Region> regions = {
        {l.text.begin, l.text.end - l.text.begin, Read | Execute | User, ".text"},
        {l.ro.begin, l.ro.end - l.ro.begin, Read | User, ".rodata"},
        {l.rw.begin, l.rw.end - l.rw.begin, Read | Write | User, ".data/.bss"},
    };
    std::vector<Chunk> chunks;
    for (const auto& s : image.segments) chunks.push_back({s.memory_offset, s.bytes.data(), s.bytes.size()});
    return build_process(l.extent, regions, chunks, memory, mmu, arena_base, arena_size);
}

} // namespace lg::system
