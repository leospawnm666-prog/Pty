#include "kthread.h"

#include <cstring>

#include <algorithm>
#include <cstdio>
#include <optional>
#include <limits>

#include "memory_state.h"
#include "svc_table.h"

namespace lg::system {
namespace {
namespace kt = kresult_thread;
constexpr uint32_t kSuccess = 0;
constexpr int32_t kIdealCoreDontCare = -1;
constexpr int32_t kIdealCoreUseProcessValue = -2;
constexpr int32_t kIdealCoreNoUpdate = -3;
constexpr uint64_t kInfinite = ~0ull;
constexpr bool valid_virtual_core(int32_t c) noexcept { return c >= 0 && c < 4; }
int ctz64(uint64_t v) noexcept { return __builtin_ctzll(v); }
} // namespace

// ==== KPriorityQueue =========================================================================

void KernelThreads::QueueImpl::push_back(int prio, int core, KThread* t) {
    auto& e = t->queue_entry[static_cast<size_t>(core)];
    KThread* tl = tail[static_cast<size_t>(prio)][static_cast<size_t>(core)];
    e.prev = tl;
    e.next = nullptr;
    if (tl) tl->queue_entry[static_cast<size_t>(core)].next = t;
    else head[static_cast<size_t>(prio)][static_cast<size_t>(core)] = t;
    tail[static_cast<size_t>(prio)][static_cast<size_t>(core)] = t;
    available[static_cast<size_t>(core)] |= 1ull << prio;
}

void KernelThreads::QueueImpl::push_front(int prio, int core, KThread* t) {
    auto& e = t->queue_entry[static_cast<size_t>(core)];
    KThread* hd = head[static_cast<size_t>(prio)][static_cast<size_t>(core)];
    e.prev = nullptr;
    e.next = hd;
    if (hd) hd->queue_entry[static_cast<size_t>(core)].prev = t;
    else tail[static_cast<size_t>(prio)][static_cast<size_t>(core)] = t;
    head[static_cast<size_t>(prio)][static_cast<size_t>(core)] = t;
    available[static_cast<size_t>(core)] |= 1ull << prio;
}

void KernelThreads::QueueImpl::remove(int prio, int core, KThread* t) {
    auto& e = t->queue_entry[static_cast<size_t>(core)];
    if (e.prev) e.prev->queue_entry[static_cast<size_t>(core)].next = e.next;
    else head[static_cast<size_t>(prio)][static_cast<size_t>(core)] = e.next;
    if (e.next) e.next->queue_entry[static_cast<size_t>(core)].prev = e.prev;
    else tail[static_cast<size_t>(prio)][static_cast<size_t>(core)] = e.prev;
    e = {};
    if (!head[static_cast<size_t>(prio)][static_cast<size_t>(core)]) available[static_cast<size_t>(core)] &= ~(1ull << prio);
}

KThread* KernelThreads::QueueImpl::front(int core) const {
    const uint64_t a = available[static_cast<size_t>(core)];
    return a ? head[static_cast<size_t>(ctz64(a))][static_cast<size_t>(core)] : nullptr;
}

KThread* KernelThreads::QueueImpl::front(int prio, int core) const {
    return head[static_cast<size_t>(prio)][static_cast<size_t>(core)];
}

KThread* KernelThreads::QueueImpl::next(int core, const KThread* t) const {
    KThread* n = t->queue_entry[static_cast<size_t>(core)].next;
    if (n) return n;
    const uint64_t above = t->priority >= 63 ? 0 : available[static_cast<size_t>(core)] & ~((2ull << t->priority) - 1);
    return above ? head[static_cast<size_t>(ctz64(above))][static_cast<size_t>(core)] : nullptr;
}

void KernelThreads::QueueImpl::move_to_front(int prio, int core, KThread* t) {
    remove(prio, core, t);
    push_front(prio, core, t);
}

KThread* KernelThreads::QueueImpl::move_to_back(int prio, int core, KThread* t) {
    remove(prio, core, t);
    push_back(prio, core, t);
    return front(prio, core);
}

void KernelThreads::pq_push_back(int prio, KThread* t) {
    uint64_t affinity = t->affinity;
    if (t->active_core >= 0) {
        scheduled_.push_back(prio, t->active_core, t);
        affinity &= ~(1ull << t->active_core);
    }
    while (affinity) {
        const int core = ctz64(affinity);
        affinity &= affinity - 1;
        if (core < kNumVirtualCores) suggested_.push_back(prio, core, t);
    }
}

void KernelThreads::pq_push_front(int prio, KThread* t) {
    uint64_t affinity = t->affinity;
    if (t->active_core >= 0) {
        scheduled_.push_front(prio, t->active_core, t);
        affinity &= ~(1ull << t->active_core);
    }
    while (affinity) {
        const int core = ctz64(affinity);
        affinity &= affinity - 1;
        if (core < kNumVirtualCores) suggested_.push_back(prio, core, t);   // as KPriorityQueue::PushFront
    }
}

void KernelThreads::pq_remove(int prio, KThread* t) {
    uint64_t affinity = t->affinity;
    if (t->active_core >= 0) {
        scheduled_.remove(prio, t->active_core, t);
        affinity &= ~(1ull << t->active_core);
    }
    while (affinity) {
        const int core = ctz64(affinity);
        affinity &= affinity - 1;
        if (core < kNumVirtualCores) suggested_.remove(prio, core, t);
    }
}

void KernelThreads::pq_change_priority(int prev, bool is_running, KThread* t) {
    pq_remove(prev, t);
    if (is_running) pq_push_front(t->priority, t);
    else pq_push_back(t->priority, t);
}

void KernelThreads::pq_change_affinity(int prev_core, uint64_t prev_affinity, KThread* t) {
    for (int core = 0; core < kNumVirtualCores; ++core) {
        if (prev_affinity & (1ull << core)) {
            if (core == prev_core) scheduled_.remove(t->priority, core, t);
            else suggested_.remove(t->priority, core, t);
        }
    }
    for (int core = 0; core < kNumVirtualCores; ++core) {
        if (t->affinity & (1ull << core)) {
            if (core == t->active_core) scheduled_.push_back(t->priority, core, t);
            else suggested_.push_back(t->priority, core, t);
        }
    }
}

void KernelThreads::pq_change_core(int prev_core, KThread* t, bool to_front) {
    const int new_core = t->active_core;
    const int prio = t->priority;
    if (prev_core == new_core) return;
    if (prev_core >= 0) scheduled_.remove(prio, prev_core, t);
    if (new_core >= 0) {
        suggested_.remove(prio, new_core, t);
        if (to_front) scheduled_.push_front(prio, new_core, t);
        else scheduled_.push_back(prio, new_core, t);
    }
    if (prev_core >= 0) suggested_.push_back(prio, prev_core, t);
}

KThread* KernelThreads::move_to_scheduled_back(KThread* t) {
    return scheduled_.move_to_back(t->priority, t->active_core, t);
}

// ==== KScheduler =============================================================================

void KernelThreads::update_highest_priority_threads() {
    // KScheduler::UpdateHighestPriorityThreadsImpl (no pinned threads in Lobo).
    uint64_t idle_cores = 0;
    for (int core = 0; core < kNumVirtualCores; ++core) {
        top_[static_cast<size_t>(core)] = scheduled_.front(core);
        if (!top_[static_cast<size_t>(core)]) idle_cores |= 1ull << core;
    }
    while (idle_cores) {
        const int core = ctz64(idle_cores);
        if (KThread* suggested = suggested_.front(core); suggested != nullptr) {
            int candidates[kNumVirtualCores];
            size_t num_candidates = 0;
            while (suggested) {
                const int sc = suggested->active_core;
                KThread* top_thread = sc >= 0 ? top_[static_cast<size_t>(sc)] : nullptr;
                if (top_thread != suggested) {
                    if (top_thread && top_thread->priority < kHighestCoreMigrationAllowedPriority) break;
                    suggested->active_core = core;
                    pq_change_core(sc, suggested);
                    top_[static_cast<size_t>(core)] = suggested;
                    break;
                }
                candidates[num_candidates++] = sc;
                suggested = suggested_.next(core, suggested);
            }
            if (!suggested) {
                for (size_t i = 0; i < num_candidates; ++i) {
                    const int cc = candidates[i];
                    suggested = top_[static_cast<size_t>(cc)];
                    if (KThread* nxt = scheduled_.next(cc, suggested); nxt != nullptr) {
                        top_[static_cast<size_t>(cc)] = nxt;
                        suggested->active_core = core;
                        pq_change_core(cc, suggested);
                        top_[static_cast<size_t>(core)] = suggested;
                        break;
                    }
                }
            }
        }
        idle_cores &= ~(1ull << core);
    }
}

void KernelThreads::rotate_scheduled_queue(int core, int priority) {
    // KScheduler::RotateScheduledQueue.
    KThread* top_thread = scheduled_.front(priority, core);
    KThread* next_thread = nullptr;
    if (top_thread) {
        next_thread = move_to_scheduled_back(top_thread);
        if (next_thread != top_thread) increment_scheduled_count();
    }
    {
        KThread* suggested = suggested_.front(priority, core);
        while (suggested) {
            const int sc = suggested->active_core;
            KThread* top_on = sc >= 0 ? scheduled_.front(sc) : nullptr;
            if (top_on != suggested) {
                if (top_thread != next_thread && next_thread && next_thread->last_scheduled_tick < suggested->last_scheduled_tick) {
                    suggested = nullptr;
                    break;
                }
                if (!top_on || top_on->priority >= kHighestCoreMigrationAllowedPriority) {
                    suggested->active_core = core;
                    pq_change_core(sc, suggested, true);
                    increment_scheduled_count();
                    break;
                }
            }
            suggested = suggested->queue_entry[static_cast<size_t>(core)].next;   // GetSamePriorityNext
        }
    }
    {
        KThread* best = scheduled_.front(core);
        if (best == current_) best = best ? scheduled_.next(core, best) : nullptr;
        if (best && best->priority >= priority) {
            KThread* suggested = suggested_.front(core);
            while (suggested) {
                if (suggested->priority >= best->priority) break;
                const int sc = suggested->active_core;
                KThread* top_on = sc >= 0 ? scheduled_.front(sc) : nullptr;
                if (top_on != suggested) {
                    if (!top_on || top_on->priority >= kHighestCoreMigrationAllowedPriority) {
                        suggested->active_core = core;
                        pq_change_core(sc, suggested, true);
                        increment_scheduled_count();
                        break;
                    }
                }
                suggested = suggested_.next(core, suggested);
            }
        }
    }
}

void KernelThreads::yield_without_core_migration(KThread& t) {
    if (t.yield_schedule_count == scheduled_count_) return;
    if (t.state != KThreadState::Runnable) return;
    if (t.active_core < 0) return;                                     // not on a core: it is not running
    KThread* next = move_to_scheduled_back(&t);
    increment_scheduled_count();
    if (next == &t) t.yield_schedule_count = scheduled_count_;
}

void KernelThreads::yield_with_core_migration(KThread& t) {
    if (t.yield_schedule_count == scheduled_count_) return;
    if (t.state != KThreadState::Runnable) return;
    if (t.active_core < 0) return;                                     // not on a core: it is not running
    const int core = t.active_core;
    KThread* next = move_to_scheduled_back(&t);
    increment_scheduled_count();
    bool recheck = false;
    KThread* suggested = suggested_.front(core);
    while (suggested) {
        const int sc = suggested->active_core;
        KThread* running = sc >= 0 ? top_[static_cast<size_t>(sc)] : nullptr;
        if (running != suggested) {
            if (suggested->priority > t.priority ||
                (suggested->priority == t.priority && next != &t && next->last_scheduled_tick < suggested->last_scheduled_tick)) {
                suggested = nullptr;
                break;
            }
            if (!running || running->priority >= kHighestCoreMigrationAllowedPriority) {
                suggested->active_core = core;
                pq_change_core(sc, suggested, true);
                increment_scheduled_count();
                break;
            }
            recheck = true;
        }
        suggested = suggested_.next(core, suggested);
    }
    if (!suggested && next == &t && !recheck) t.yield_schedule_count = scheduled_count_;
}

void KernelThreads::yield_to_any_thread(KThread& t) {
    if (t.yield_schedule_count == scheduled_count_) return;
    if (t.state != KThreadState::Runnable) return;
    if (t.active_core < 0) return;                                     // not on a core: it is not running
    const int core = t.active_core;
    t.active_core = -1;
    pq_change_core(core, &t);
    increment_scheduled_count();
    if (!scheduled_.front(core)) {
        KThread* suggested = suggested_.front(core);
        while (suggested) {
            const int sc = suggested->active_core;
            KThread* top_on = sc >= 0 ? scheduled_.front(sc) : nullptr;
            if (top_on != suggested) {
                if (!top_on || top_on->priority >= kHighestCoreMigrationAllowedPriority) {
                    suggested->active_core = core;
                    pq_change_core(sc, suggested);
                    increment_scheduled_count();
                }
                break;
            }
            suggested = suggested_.next(core, suggested);
        }
        if (suggested == &t) t.yield_schedule_count = scheduled_count_;
    }
}

// ==== lifecycle =============================================================================

void KernelThreads::reset() noexcept {
    active_ = false;
    config_ = {};
    threads_.clear();
    events_.clear();
    object_waiters_.clear();
    next_event_id_ = 1;
    scheduled_ = {};
    suggested_ = {};
    top_ = {};
    current_ = nullptr;
    current_core_ = -1;
    scheduled_count_ = 0;
    running_count_ = 0;
    timers_.clear();
    cv_tree_.clear();
    arbiter_tree_.clear();
    next_rotation_ = 0;
    free_tls_.clear();
    next_tls_page_ = 0;
    begin_tick_ = 0;
    core_busy_ticks_ = {};
    process_local_region_ = 0;
    provider_ = {};
}

bool KernelThreads::begin(const KernelThreadsConfig& c) {
    reset();
    if (!c.clock || !c.handles || !c.memory || !c.threads || !c.contexts || !c.host.spawn) return false;
    config_ = c;
    next_tls_page_ = c.tls_region_base;
    next_rotation_ = c.clock->ticks() + kPreemptionPeriodTicks;
    begin_tick_ = c.clock->ticks();   // P6.0: IdleTickCount counts from here
    active_ = true;
    return true;
}

bool KernelThreads::register_main_thread(uint64_t id, uint32_t handle, int32_t priority, uint64_t tls_va) {
    if (!active_ || threads_.count(id)) return false;
    auto t = std::make_unique<KThread>();
    t->id = id;
    t->handle = handle;
    t->base_priority = t->priority = priority;
    t->ideal_core = config_.ideal_core;
    t->affinity = 1ull << config_.ideal_core;
    t->active_core = config_.ideal_core;
    t->tls_va = tls_va;
    t->handle_refs = 1;
    t->running_counted = true;
    t->state = KThreadState::Runnable;
    KThread* raw = t.get();
    threads_.emplace(id, std::move(t));
    pq_push_back(raw->priority, raw);
    ++running_count_;
    increment_scheduled_count();
    // The main TLS page holds 8 regions of 0x200 bytes; the first is the main thread's.
    for (uint64_t slot = 7; slot >= 1; --slot) free_tls_.push_back(tls_va + slot * 0x200);
    update_highest_priority_threads();
    return true;
}

KThread* KernelThreads::find(uint64_t id) noexcept {
    auto it = threads_.find(id);
    return it == threads_.end() ? nullptr : it->second.get();
}

const KThread* KernelThreads::find(uint64_t id) const noexcept {
    auto it = threads_.find(id);
    return it == threads_.end() ? nullptr : it->second.get();
}

size_t KernelThreads::live_count() const noexcept {
    size_t n = 0;
    for (const auto& [id, t] : threads_) if (t->state == KThreadState::Runnable || t->state == KThreadState::Waiting) ++n;
    return n;
}

size_t KernelThreads::waiting_count() const noexcept {
    size_t n = 0;
    for (const auto& [id, t] : threads_) if (t->state == KThreadState::Waiting) ++n;
    return n;
}

std::string KernelThreads::describe_waits() const {
    static constexpr const char* kKinds[] = {"none", "sleep", "sync", "mutex", "condvar", "arbiter", "ipc"};
    std::string out;
    char buf[96];
    for (const auto& [id, t] : threads_) {
        if (t->state != KThreadState::Waiting) continue;
        if (!out.empty()) out += ',';
        switch (t->wait) {
            case KWaitKind::Lock:
                std::snprintf(buf, sizeof buf, "%llu:mutex@0x%llx:owner=%llu", (unsigned long long)id,
                              (unsigned long long)t->address_key, (unsigned long long)(t->lock_owner ? t->lock_owner->id : 0));
                break;
            case KWaitKind::ConditionVariable:
                std::snprintf(buf, sizeof buf, "%llu:condvar@0x%llx", (unsigned long long)id, (unsigned long long)t->cv_key);
                break;
            case KWaitKind::Arbiter:
                std::snprintf(buf, sizeof buf, "%llu:arbiter@0x%llx", (unsigned long long)id, (unsigned long long)t->arbiter_key);
                break;
            case KWaitKind::Ipc:
                std::snprintf(buf, sizeof buf, "%llu:ipc@%.60s", (unsigned long long)id, t->ipc_wait.c_str());
                break;
            default:
                std::snprintf(buf, sizeof buf, "%llu:%s", (unsigned long long)id, kKinds[static_cast<size_t>(t->wait)]);
        }
        out += buf;
    }
    return out;
}

void KernelThreads::begin_turn(int core, KThread* thread, uint64_t now_ticks) noexcept {
    current_ = thread;
    current_core_ = core;
    if (thread) thread->last_scheduled_tick = now_ticks;
}

void KernelThreads::end_turn(uint64_t now_ticks) noexcept {
    if (current_ && current_core_ >= 0 && current_core_ < kNumVirtualCores && now_ticks > current_->last_scheduled_tick) {
        current_->cpu_ticks[static_cast<size_t>(current_core_)] += now_ticks - current_->last_scheduled_tick;
        core_busy_ticks_[static_cast<size_t>(current_core_)] += now_ticks - current_->last_scheduled_tick;   // P6.0
    }
    end_turn();
}

void KernelThreads::update(uint64_t now) {
    // Timers (KHardwareTimer): a sleep ends with success, every other wait with TimedOut.
    while (!timers_.empty() && timers_.begin()->first <= now) {
        const uint64_t tid = timers_.begin()->second;
        timers_.erase(timers_.begin());
        KThread* t = find(tid);
        if (!t || t->state != KThreadState::Waiting) continue;
        t->wait_deadline = 0;
        end_wait(*t, t->wait == KWaitKind::Sleep ? kSuccess : kt::TimedOut);
    }
    // The preemption DPC: rotate priority 59 on cores 0-2 every 10 ms (D-P3.3-3).
    if (now >= next_rotation_) {
        for (int core = 0; core < kNumVirtualCores; ++core) rotate_scheduled_queue(core, kPreemptionPriority);
        next_rotation_ = now + kPreemptionPeriodTicks;
    }
    update_highest_priority_threads();
}

// ==== state, waits, timers ==================================================================

void KernelThreads::set_state(KThread& t, KThreadState s) {
    const KThreadState old = t.state;
    t.state = s;
    if (old == s) return;
    // P6.0: a suspended thread is never in the queues (KThread::GetRawState vs GetState)
    const bool was_queued = old == KThreadState::Runnable && !t.suspended;
    const bool now_queued = s == KThreadState::Runnable && !t.suspended;
    if (was_queued) {
        pq_remove(t.priority, &t);
        increment_scheduled_count();
    } else if (now_queued) {
        pq_push_back(t.priority, &t);
        increment_scheduled_count();
    }
    if (s == KThreadState::Terminated) config_.threads->terminate(t.id);
    else if (now_queued) config_.threads->make_ready(t.id);
    else config_.threads->block(t.id);
}

uint32_t KernelThreads::set_thread_activity(KThread& self, uint32_t handle, uint32_t activity) {
    // kern_svc_activity.cpp + KThread::SetActivity
    if (activity > 1) return 0xF001;   // InvalidEnumValue
    KThread* t = thread_from_handle(handle);
    if (!t) return 0xE401;   // InvalidHandle
    if (t == &self) return 0xF401;   // Busy
    if (t->state != KThreadState::Waiting && t->state != KThreadState::Runnable) return kresult_thread::InvalidState;
    if (activity == 1) {
        if (t->suspended) return kresult_thread::InvalidState;
        if (t->state == KThreadState::Runnable) {
            pq_remove(t->priority, t);
            increment_scheduled_count();
            config_.threads->block(t->id);
        }
        t->suspended = true;
    } else {
        if (!t->suspended) return kresult_thread::InvalidState;
        t->suspended = false;
        if (t->state == KThreadState::Runnable) {
            pq_push_back(t->priority, t);
            increment_scheduled_count();
            config_.threads->make_ready(t->id);
        }
    }
    update_highest_priority_threads();
    return 0;
}

uint32_t KernelThreads::get_thread_context3(KThread& self, uint32_t handle, std::vector<uint8_t>& out) {
    KThread* t = thread_from_handle(handle);
    if (!t) return 0xE401;
    if (t == &self) return 0xF401;
    if (!t->suspended) return kresult_thread::InvalidState;
    const cpu::CpuState* c = config_.contexts->get(t->id);
    out.assign(0x320, 0);
    if (!c) return 0;
    auto put64 = [&](size_t off, uint64_t v) { std::memcpy(out.data() + off, &v, 8); };
    auto put32 = [&](size_t off, uint32_t v) { std::memcpy(out.data() + off, &v, 4); };
    for (int i = 0; i < 29; ++i) put64(8 * i, c->x[i]);
    put64(232, c->x[29]);
    put64(240, c->x[30]);
    put64(248, c->sp);
    put64(256, c->pc);
    put32(264, c->nzcv & 0xF0000000u);   // PSTATE of EL0: the flags
    for (int i = 0; i < 32; ++i) { put64(272 + 16 * i, c->v[i][0]); put64(272 + 16 * i + 8, c->v[i][1]); }
    put32(784, c->fpcr);
    put32(788, c->fpsr);
    put64(792, c->tpidr_el0);
    return 0;
}

uint64_t KernelThreads::idle_ticks(int core, uint64_t now_ticks) const noexcept {
    // kern_svc_info.cpp (IdleTickCount): the idle thread's CPU time minus the interrupt tasks'.
    // Lobo has neither; a core is idle whenever no guest thread runs on it.
    if (core < 0 || core >= kNumVirtualCores) return 0;
    uint64_t busy = core_busy_ticks_[static_cast<size_t>(core)];
    if (current_ && current_core_ == core && now_ticks > current_->last_scheduled_tick)
        busy += now_ticks - current_->last_scheduled_tick;
    const uint64_t elapsed = now_ticks > begin_tick_ ? now_ticks - begin_tick_ : 0;
    return elapsed > busy ? elapsed - busy : 0;
}

uint64_t KernelThreads::process_local_region() {
    // KProcess::Initialize creates the process local region (svc::ProcessLocalRegion, 0x200
    // bytes, the user exception context) in a thread-local page. Lobo reserves it on first use.
    if (!process_local_region_) process_local_region_ = allocate_tls();
    return process_local_region_;
}

std::vector<uint64_t> KernelThreads::thread_ids() const {
    std::vector<uint64_t> out;
    for (const auto& [id, t] : threads_)
        if (t->state != KThreadState::Terminated) out.push_back(id);
    return out;
}

uint64_t KernelThreads::deadline_from_ns(int64_t ns) const noexcept {
    // ns > 0: GetTick() + ticks(ns) + 2 (saturating to "never"). svc::Tick(TimeSpan) rounds
    // UP (util::ScaleByConstantFactorUp), so any positive ns is at least one tick.
    __extension__ typedef unsigned __int128 u128;
    const u128 up = (static_cast<u128>(static_cast<uint64_t>(ns)) * 12u + 624u) / 625u;
    const uint64_t offset = up > kInfinite ? kInfinite : static_cast<uint64_t>(up);
    if (offset == 0) return kInfinite;
    const uint64_t now = config_.clock->ticks();
    if (offset > kInfinite - now - 2) return kInfinite;
    return now + offset + 2;
}

void KernelThreads::timer_insert(KThread& t, uint64_t deadline) {
    t.wait_deadline = deadline;
    if (deadline != kInfinite) timers_.emplace(deadline, t.id);
}

void KernelThreads::timer_remove(KThread& t) {
    if (!t.wait_deadline) return;
    auto [lo, hi] = timers_.equal_range(t.wait_deadline);
    for (auto it = lo; it != hi; ++it) {
        if (it->second == t.id) { timers_.erase(it); break; }
    }
    t.wait_deadline = 0;
}

void KernelThreads::begin_wait(KThread& t, KWaitKind kind, uint64_t deadline) {
    t.wait = kind;
    if (deadline) timer_insert(t, deadline);
    set_state(t, KThreadState::Waiting);
}

void KernelThreads::cancel_wait_structures(KThread& t) {
    timer_remove(t);
    for (uint64_t obj : t.sync_objects) {
        auto it = object_waiters_.find(obj);
        if (it == object_waiters_.end()) continue;
        auto& v = it->second;
        v.erase(std::remove(v.begin(), v.end(), &t), v.end());
        if (v.empty()) object_waiters_.erase(it);
    }
    t.sync_objects.clear();
    if (t.in_cv_tree) {
        auto [lo, hi] = cv_tree_.equal_range({t.cv_key, t.priority});
        for (auto it = lo; it != hi; ++it) if (it->second == &t) { cv_tree_.erase(it); break; }
        t.in_cv_tree = false;
    }
    if (t.in_arbiter_tree) {
        auto [lo, hi] = arbiter_tree_.equal_range({t.arbiter_key, t.priority});
        for (auto it = lo; it != hi; ++it) if (it->second == &t) { arbiter_tree_.erase(it); break; }
        t.in_arbiter_tree = false;
    }
    if (t.lock_owner) remove_waiter(*t.lock_owner, t);
}

void KernelThreads::write_wait_outputs(KThread& t) {
    cpu::CpuState* ctx = config_.contexts->get(t.id);
    if (!ctx) return;
    switch (t.wait) {
        case KWaitKind::Sleep: break;                                       // SleepThread returns nothing
        case KWaitKind::Synchronization:
            ctx->x[0] = t.wait_result;
            ctx->x[1] = static_cast<uint32_t>(t.synced_index);
            break;
        default: ctx->x[0] = t.wait_result; break;
    }
}

void KernelThreads::begin_ipc_wait(KThread& self, std::string what) {
    self.ipc_wait = std::move(what);
    begin_wait(self, KWaitKind::Ipc, 0);
}

void KernelThreads::end_ipc_wait(KThread& t, uint32_t result) {
    if (t.state != KThreadState::Waiting || t.wait != KWaitKind::Ipc) return;
    end_wait(t, result);
}

void KernelThreads::end_wait(KThread& t, uint32_t result) {
    if (t.state != KThreadState::Waiting) return;
    const bool sync = t.wait == KWaitKind::Synchronization;
    cancel_wait_structures(t);
    t.wait_result = result;
    write_wait_outputs(t);
    t.wait = KWaitKind::None;
    t.ipc_wait.clear();
    set_state(t, KThreadState::Runnable);
    if (sync && provider_.wait_ended) provider_.wait_ended(t.id);   // P6.0: ReplyAndReceive bookkeeping
}

// ==== priority inheritance (KThread) ========================================================

KThread::HeldLock* KernelThreads::find_held_lock(KThread& owner, uint64_t key) {
    for (auto& l : owner.held_locks) if (l.key == key) return &l;
    return nullptr;
}

void KernelThreads::add_waiter_impl(KThread& owner, KThread& waiter) {
    KThread::HeldLock* lock = find_held_lock(owner, waiter.address_key);
    if (!lock) {
        owner.held_locks.push_back({waiter.address_key, {}});
        lock = &owner.held_locks.back();
    }
    auto pos = std::find_if(lock->waiters.begin(), lock->waiters.end(),
                            [&](const KThread* w) { return w->priority > waiter.priority; });
    lock->waiters.insert(pos, &waiter);
    waiter.lock_owner = &owner;
}

void KernelThreads::remove_waiter_impl(KThread& owner, KThread& waiter) {
    for (auto it = owner.held_locks.begin(); it != owner.held_locks.end(); ++it) {
        auto w = std::find(it->waiters.begin(), it->waiters.end(), &waiter);
        if (w == it->waiters.end()) continue;
        it->waiters.erase(w);
        if (it->waiters.empty()) owner.held_locks.erase(it);
        break;
    }
    waiter.lock_owner = nullptr;
}

void KernelThreads::set_priority(KThread& t, int32_t priority) {
    const int32_t old = t.priority;
    t.priority = priority;
    if (t.state == KThreadState::Runnable && !t.suspended) {   // P6.0: a suspended thread is not queued
        pq_change_priority(old, &t == current_, &t);
        increment_scheduled_count();
    }
}

void KernelThreads::restore_priority(KThread* thread) {
    while (thread) {
        int32_t new_priority = thread->base_priority;
        for (const auto& l : thread->held_locks) new_priority = std::min(new_priority, l.waiters.front()->priority);
        if (new_priority == thread->priority) return;
        KThread* const owner = thread->lock_owner;
        if (owner) remove_waiter_impl(*owner, *thread);
        // Keep the condition-variable / arbiter trees ordered (Before/AfterUpdatePriority).
        const bool in_cv = thread->in_cv_tree, in_arb = thread->in_arbiter_tree;
        if (in_cv || in_arb) {
            auto& tree = in_cv ? cv_tree_ : arbiter_tree_;
            const uint64_t key = in_cv ? thread->cv_key : thread->arbiter_key;
            auto [lo, hi] = tree.equal_range({key, thread->priority});
            for (auto it = lo; it != hi; ++it) if (it->second == thread) { tree.erase(it); break; }
        }
        set_priority(*thread, new_priority);
        if (in_cv || in_arb) {
            auto& tree = in_cv ? cv_tree_ : arbiter_tree_;
            tree.emplace(std::make_pair(in_cv ? thread->cv_key : thread->arbiter_key, thread->priority), thread);
        }
        if (owner) add_waiter_impl(*owner, *thread);
        thread = owner;
    }
}

void KernelThreads::add_waiter(KThread& owner, KThread& waiter) {
    add_waiter_impl(owner, waiter);
    if (waiter.priority < owner.priority) restore_priority(&owner);
}

void KernelThreads::remove_waiter(KThread& owner, KThread& waiter) {
    remove_waiter_impl(owner, waiter);
    if (owner.priority == waiter.priority && owner.priority < owner.base_priority) restore_priority(&owner);
}

KThread* KernelThreads::remove_waiter_by_key(KThread& owner, bool& has_waiters, uint64_t key) {
    auto it = std::find_if(owner.held_locks.begin(), owner.held_locks.end(), [&](const KThread::HeldLock& l) { return l.key == key; });
    if (it == owner.held_locks.end()) { has_waiters = false; return nullptr; }
    KThread::HeldLock lock = std::move(*it);
    owner.held_locks.erase(it);
    KThread* next = lock.waiters.front();
    lock.waiters.erase(lock.waiters.begin());
    next->lock_owner = nullptr;
    if (lock.waiters.empty()) {
        has_waiters = false;
    } else {
        has_waiters = true;
        for (KThread* w : lock.waiters) w->lock_owner = next;          // the lock info changes owner
        next->held_locks.push_back(std::move(lock));
    }
    if (owner.priority == next->priority && owner.priority < owner.base_priority) restore_priority(&owner);
    return next;
}

// ==== guest memory helpers ==================================================================

bool KernelThreads::store32(uint64_t address, uint32_t value) {
    // A kernel store to a lock word: through compare_exchange so guest exclusives see it.
    for (int i = 0; i < 64; ++i) {
        const auto cur = config_.memory->read32(address);
        if (!cur) return false;
        const auto got = config_.memory->compare_exchange32(address, *cur, value);
        if (!got) return false;
        if (*got == *cur) return true;
    }
    return config_.memory->write32(address, value);
}

// ==== handles, objects ======================================================================

KThread* KernelThreads::thread_from_handle(uint32_t handle, bool allow_pseudo) const {
    if (!allow_pseudo && HandleTable::is_pseudo(handle)) return nullptr;
    const auto obj = config_.handles->resolve(handle, current_ ? current_->id : 0, config_.process_id);
    if (!obj || obj->type != KObjectType::Thread) return nullptr;
    return const_cast<KThread*>(find(obj->id));
}

KernelThreads::KEvent* KernelThreads::event_from_handle(uint32_t handle, KObjectType type) const {
    const KObjectRef* obj = config_.handles->get(handle);
    if (!obj || obj->type != type) return nullptr;
    auto it = events_.find(obj->id);
    return it == events_.end() ? nullptr : it->second.get();
}

bool KernelThreads::is_signaled(uint64_t object) const {
    if (object & kExternalObject) return provider_.signaled && provider_.signaled(object & ~kExternalObject);   // P6.0
    if (object & 1) {
        auto it = events_.find(object >> 1);
        return it != events_.end() && it->second->signaled;
    }
    const KThread* t = find(object >> 1);
    return t && t->state == KThreadState::Terminated;
}

void KernelThreads::notify_available(uint64_t object) {
    auto it = object_waiters_.find(object);
    if (it == object_waiters_.end()) return;
    const std::vector<KThread*> waiters = it->second;               // end_wait edits the list
    for (KThread* t : waiters) {
        if (t->state != KThreadState::Waiting || t->wait != KWaitKind::Synchronization) continue;
        const auto pos = std::find(t->sync_objects.begin(), t->sync_objects.end(), object);
        t->synced_index = static_cast<int32_t>(pos - t->sync_objects.begin());
        end_wait(*t, kSuccess);
    }
}

void KernelThreads::on_handle_closed(const KObjectRef& object) {
    if (object.type == KObjectType::Thread) {
        if (KThread* t = find(object.id)) {
            if (t->handle_refs) --t->handle_refs;
            maybe_free_thread(*t);
        }
    } else if (object.type == KObjectType::Event || object.type == KObjectType::ReadableEvent) {
        auto it = events_.find(object.id);
        if (it != events_.end()) {
            if (it->second->refs) --it->second->refs;
            if (it->second->refs == 0 && !object_waiters_.count(object_id_for_event(object.id))) events_.erase(it);
        }
    }
}

void KernelThreads::maybe_free_thread(KThread& t) {
    if (t.handle_refs || !t.held_locks.empty() || object_waiters_.count(object_id_for_thread(t.id))) return;
    if (&t == current_ && t.state != KThreadState::Initialized && t.state != KThreadState::Terminated) return;
    if (t.state == KThreadState::Initialized) {                       // never started: destroyed with its last handle
        release_tls(t.tls_va);
        t.tls_va = 0;
        set_state(t, KThreadState::Terminated);
    }
    if (t.state != KThreadState::Terminated) return;
    if (&t == current_) current_ = nullptr;                             // the turn ends without it
    threads_.erase(t.id);
}

uint64_t KernelThreads::allocate_tls() {
    if (free_tls_.empty()) {
        // Next free 64 KiB slot of the region (the guest may have mapped stacks there).
        if (!config_.vm) return 0;
        uint64_t page = 0;
        while (next_tls_page_ + 0x1000 <= config_.tls_region_end && next_tls_page_ >= config_.tls_region_base) {
            const uint64_t candidate = next_tls_page_;
            const kmem::MemoryInfo info = config_.vm->query(candidate);
            if (info.state != kmem::Free || info.base_address + info.size < candidate + 0x1000) {
                next_tls_page_ += 0x10000;                            // taken by the guest: skip it
                continue;
            }
            if (!config_.vm->map_thread_local_page(candidate)) return 0;   // out of memory: retry later
            next_tls_page_ += 0x10000;
            page = candidate;
            break;
        }
        if (!page) return 0;
        for (uint64_t slot = 8; slot-- > 0;) free_tls_.push_back(page + slot * 0x200);
        const uint64_t va = free_tls_.back();
        free_tls_.pop_back();
        return va;                                                     // a fresh page is zero
    }
    const uint64_t va = free_tls_.back();
    free_tls_.pop_back();
    static const std::array<uint8_t, 0x200> zeros{};
    config_.memory->write(va, zeros.data(), zeros.size());            // Horizon clears the region
    return va;
}

void KernelThreads::release_tls(uint64_t tls_va) {
    if (tls_va) free_tls_.push_back(tls_va);
}

// ==== SVCs: threads =========================================================================

uint32_t KernelThreads::create_thread(uint64_t entry, uint64_t arg, uint64_t stack_top, int32_t priority, int32_t core,
                                      uint32_t& out_handle) {
    out_handle = 0;
    if (core == kIdealCoreUseProcessValue) core = config_.ideal_core;
    if (!valid_virtual_core(core)) return kt::InvalidCoreId;
    if (((1ull << core) & config_.core_mask) == 0) return kt::InvalidCoreId;
    if (priority < 0 || priority > 63) return kt::InvalidPriority;
    if (((config_.priority_mask >> priority) & 1) == 0) return kt::InvalidPriority;
    if (live_count() >= kMaxThreads) return kmem::result::LimitReached;
    const uint64_t tls = allocate_tls();
    if (!tls) return kmem::result::OutOfMemory;
    const uint64_t tid = config_.host.spawn(entry, stack_top);
    if (!tid) { release_tls(tls); return kmem::result::LimitReached; }
    cpu::CpuState* ctx = config_.contexts->get(tid);
    if (!ctx) { release_tls(tls); return kmem::result::LimitReached; }
    ctx->x[0] = arg;
    ctx->x[30] = 0;
    ctx->tpidrro_el0 = tls;
    // svc::CreateThread: thread->GetContext().CloneFpuStatus() (the creator's FPCR/FPSR).
    if (current_) {
        if (const cpu::CpuState* parent = config_.contexts->get(current_->id)) {
            ctx->fpcr = parent->fpcr;
            ctx->fpsr = parent->fpsr;
        }
    }
    const auto handle = config_.handles->add({KObjectType::Thread, tid});
    if (!handle) { release_tls(tls); config_.threads->terminate(tid); return kresult::OutOfHandles; }
    auto t = std::make_unique<KThread>();
    t->id = tid;
    t->handle = *handle;
    t->base_priority = t->priority = priority;
    t->ideal_core = core;
    t->affinity = 1ull << core;
    t->active_core = core;
    t->tls_va = tls;
    t->handle_refs = 1;
    t->state = KThreadState::Initialized;
    threads_.emplace(tid, std::move(t));
    config_.threads->block(tid);                                       // not runnable until StartThread
    out_handle = *handle;
    return kSuccess;
}

uint32_t KernelThreads::start_thread(uint32_t handle) {
    KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    if (t->state != KThreadState::Initialized) return kt::InvalidState;
    t->running_counted = true;
    ++running_count_;
    set_state(*t, KThreadState::Runnable);
    return kSuccess;
}

bool KernelThreads::exit_thread(KThread& self) {
    set_state(self, KThreadState::Terminated);
    if (self.running_counted) { self.running_counted = false; --running_count_; }
    release_tls(self.tls_va);
    self.tls_va = 0;
    notify_available(object_id_for_thread(self.id));                    // a terminated thread is signaled
    const bool last = running_count_ == 0;
    maybe_free_thread(self);                                           // `self` may be gone after this
    return last;
}

bool KernelThreads::sleep_thread(KThread& self, int64_t ns) {
    if (ns > 0) {
        begin_wait(self, KWaitKind::Sleep, deadline_from_ns(ns));
        return true;
    }
    if (ns == 0) yield_without_core_migration(self);
    else if (ns == -1) yield_with_core_migration(self);
    else if (ns == -2) yield_to_any_thread(self);
    return false;                                                      // other values: nothing (as Horizon)
}

uint32_t KernelThreads::get_thread_priority(uint32_t handle, int32_t& out) const {
    const KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    out = t->priority;
    return kSuccess;
}

uint32_t KernelThreads::set_thread_priority(uint32_t handle, int32_t priority) {
    KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    if (priority < 0 || priority > 63) return kt::InvalidPriority;
    if (((config_.priority_mask >> priority) & 1) == 0) return kt::InvalidPriority;
    t->base_priority = priority;
    restore_priority(t);
    return kSuccess;
}

uint32_t KernelThreads::get_thread_core_mask(uint32_t handle, int32_t& out_core, uint64_t& out_mask) const {
    const KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    out_core = t->ideal_core;
    out_mask = t->affinity;
    return kSuccess;
}

uint32_t KernelThreads::set_thread_core_mask(uint32_t handle, int32_t core, uint64_t mask) {
    KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    if (core == kIdealCoreUseProcessValue) {
        core = config_.ideal_core;
        mask = 1ull << core;
    } else {
        if ((mask | config_.core_mask) != config_.core_mask) return kt::InvalidCoreId;
        if (mask == 0) return kresult::InvalidCombination;
        if (valid_virtual_core(core)) {
            if (((1ull << core) & mask) == 0) return kresult::InvalidCombination;
        } else if (core != kIdealCoreNoUpdate && core != kIdealCoreDontCare) {
            return kt::InvalidCoreId;
        }
    }
    // KThread::SetCoreMask
    if (core != kIdealCoreNoUpdate) {
        t->ideal_core = core;
    } else {
        core = t->ideal_core;
        if (core >= 0 && ((1ull << core) & mask) == 0) return kresult::InvalidCombination;
    }
    const uint64_t old_mask = t->affinity;
    t->affinity = mask;
    if (mask != old_mask) {
        const int active = t->active_core;
        if (active >= 0 && !(mask & (1ull << active))) {
            t->active_core = t->ideal_core >= 0 ? t->ideal_core : 63 - __builtin_clzll(mask);
        }
        if (t->state == KThreadState::Runnable && !t->suspended) {   // P6.0
            pq_change_affinity(active, old_mask, t);
            increment_scheduled_count();
        }
    }
    return kSuccess;
}

uint32_t KernelThreads::get_thread_id(uint32_t handle, uint64_t& out) const {
    const KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    out = t->id;
    return kSuccess;
}

uint32_t KernelThreads::thread_tick_count(uint32_t handle, uint64_t subtype, uint64_t now_ticks, uint64_t& out) const {
    // kern_svc_info.cpp (InfoType_ThreadTickCount): the core check comes before the handle.
    out = 0;
    if (subtype != ~uint64_t{0} && subtype >= 4) return kresult::InvalidCombination;
    const KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    const bool running = t == current_ && now_ticks > t->last_scheduled_tick;
    if (subtype == ~uint64_t{0}) {
        for (uint64_t v : t->cpu_ticks) out += v;
        if (running) out += now_ticks - t->last_scheduled_tick;
    } else if (subtype < static_cast<uint64_t>(kNumVirtualCores)) {
        out = t->cpu_ticks[static_cast<size_t>(subtype)];
        if (running && static_cast<uint64_t>(current_core_) == subtype) out += now_ticks - t->last_scheduled_tick;
    }                                                                  // core 3: never used by the process
    return kSuccess;
}

// ==== SVCs: events and synchronization ======================================================

uint32_t KernelThreads::create_event(uint32_t& out_write, uint32_t& out_read) {
    out_write = out_read = 0;
    const uint64_t id = next_event_id_++;
    const auto w = config_.handles->add({KObjectType::Event, id});
    if (!w) return kresult::OutOfHandles;
    const auto r = config_.handles->add({KObjectType::ReadableEvent, id});
    if (!r) { config_.handles->close(*w); return kresult::OutOfHandles; }
    auto e = std::make_unique<KEvent>();
    e->id = id;
    e->refs = 2;
    events_.emplace(id, std::move(e));
    out_write = *w;
    out_read = *r;
    return kSuccess;
}

uint32_t KernelThreads::signal_event(uint32_t handle) {
    KEvent* e = event_from_handle(handle, KObjectType::Event);
    if (!e) return kresult::InvalidHandle;
    if (!e->signaled) {                                                // KReadableEvent::Signal
        e->signaled = true;
        notify_available(object_id_for_event(e->id));
    }
    return kSuccess;
}

uint32_t KernelThreads::clear_event(uint32_t handle) {
    KEvent* e = event_from_handle(handle, KObjectType::Event);
    if (!e) e = event_from_handle(handle, KObjectType::ReadableEvent);
    if (!e) return kresult::InvalidHandle;
    e->signaled = false;
    return kSuccess;
}

uint32_t KernelThreads::reset_signal(uint32_t handle) {
    if (KEvent* e = event_from_handle(handle, KObjectType::ReadableEvent)) {
        if (!e->signaled) return kt::InvalidState;
        e->signaled = false;
        return kSuccess;
    }
    const auto obj = config_.handles->resolve(handle, current_ ? current_->id : 0, config_.process_id);
    if (obj && obj->type == KObjectType::Process) return kt::InvalidState;   // a running process is never signaled
    return kresult::InvalidHandle;
}

uint32_t KernelThreads::wait_synchronization(KThread& self, uint64_t handles_ptr, int32_t count, int64_t timeout_ns,
                                             int32_t& out_index, bool& blocked) {
    blocked = false;
    out_index = -1;
    std::vector<uint64_t> objects;
    if (const uint32_t rc = resolve_sync_handles(handles_ptr, count, objects); rc) return rc;
    // KSynchronizationObject::Wait
    for (size_t i = 0; i < objects.size(); ++i) {
        if (is_signaled(objects[i])) { out_index = static_cast<int32_t>(i); return kSuccess; }
    }
    return block_on_objects(self, std::move(objects), timeout_ns, blocked);
}

uint32_t KernelThreads::resolve_sync_handles(uint64_t handles_ptr, int32_t count, std::vector<uint64_t>& objects) const {
    objects.clear();
    if (count < 0 || count > kArgumentHandleCountMax) return kt::OutOfRange;
    if (count > 0) {
        if (!config_.memory->accessible(handles_ptr, static_cast<uint64_t>(count) * 4, false)) return kmem::result::InvalidPointer;
        std::vector<uint32_t> handles(static_cast<size_t>(count));
        if (!config_.memory->read(handles_ptr, handles.data(), handles.size() * 4)) return kmem::result::InvalidPointer;
        for (uint32_t h : handles) {
            if (KEvent* e = event_from_handle(h, KObjectType::ReadableEvent)) { objects.push_back(object_id_for_event(e->id)); continue; }
            if (KThread* t = thread_from_handle(h, false)) { objects.push_back(object_id_for_thread(t->id)); continue; }
            if (provider_.resolve) {   // P6.0: guest IPC sessions and ports
                if (const auto ext = provider_.resolve(h)) { objects.push_back(kExternalObject | *ext); continue; }
            }
            return kresult::InvalidHandle;
        }
    }
    return kSuccess;
}

uint32_t KernelThreads::block_on_objects(KThread& self, std::vector<uint64_t> objects, int64_t timeout_ns, bool& blocked) {
    blocked = false;
    if (timeout_ns == 0) return kt::TimedOut;
    if (self.wait_cancelled) { self.wait_cancelled = false; return kt::Cancelled; }
    for (uint64_t obj : objects) object_waiters_[obj].push_back(&self);
    self.sync_objects = std::move(objects);
    self.synced_index = -1;
    begin_wait(self, KWaitKind::Synchronization, timeout_ns > 0 ? deadline_from_ns(timeout_ns) : 0);
    blocked = true;
    return kSuccess;
}

std::vector<uint64_t> KernelThreads::waiters_of(uint64_t object) const {
    std::vector<uint64_t> out;
    auto it = object_waiters_.find(object);
    if (it == object_waiters_.end()) return out;
    for (const KThread* t : it->second)
        if (t->state == KThreadState::Waiting && t->wait == KWaitKind::Synchronization) out.push_back(t->id);
    return out;
}

void KernelThreads::end_sync_wait(uint64_t tid, uint64_t object, uint32_t result) {
    KThread* t = find(tid);
    if (!t || t->state != KThreadState::Waiting || t->wait != KWaitKind::Synchronization) return;
    const auto pos = std::find(t->sync_objects.begin(), t->sync_objects.end(), object);
    t->synced_index = pos == t->sync_objects.end() ? -1 : static_cast<int32_t>(pos - t->sync_objects.begin());
    end_wait(*t, result);
}

bool KernelThreads::add_handle_ref(const KObjectRef& object) {
    if (object.type == KObjectType::Thread) {
        KThread* t = find(object.id);
        if (!t) return false;
        ++t->handle_refs;
        return true;
    }
    if (object.type == KObjectType::Event || object.type == KObjectType::ReadableEvent) {
        auto it = events_.find(object.id);
        if (it == events_.end()) return false;
        ++it->second->refs;
        return true;
    }
    return false;
}

uint32_t KernelThreads::create_kernel_event(uint32_t& out_read, uint64_t& out_id) {
    out_read = 0;
    out_id = 0;
    const uint64_t id = next_event_id_++;
    const auto r = config_.handles->add({KObjectType::ReadableEvent, id});
    if (!r) return kresult::OutOfHandles;
    auto e = std::make_unique<KEvent>();
    e->id = id;
    e->refs = 2;   // the readable handle + the kernel's (the request) reference
    events_.emplace(id, std::move(e));
    out_read = *r;
    out_id = id;
    return kSuccess;
}

void KernelThreads::signal_kernel_event(uint64_t id) {
    auto it = events_.find(id);
    if (it == events_.end() || it->second->signaled) return;
    it->second->signaled = true;
    notify_available(object_id_for_event(id));
}

void KernelThreads::clear_kernel_event(uint64_t id) {
    auto it = events_.find(id);
    if (it != events_.end()) it->second->signaled = false;
}

uint64_t KernelThreads::create_host_event() {
    const uint64_t id = next_event_id_++;
    auto e = std::make_unique<KEvent>();
    e->id = id;
    e->refs = 1;
    events_.emplace(id, std::move(e));
    return id;
}

void KernelThreads::release_kernel_event(uint64_t id) {
    on_handle_closed({KObjectType::Event, id});   // drops the kernel's reference like a handle
}

uint32_t KernelThreads::cancel_synchronization(uint32_t handle) {
    KThread* t = thread_from_handle(handle);
    if (!t) return kresult::InvalidHandle;
    if (t->state == KThreadState::Waiting && t->wait == KWaitKind::Synchronization) end_wait(*t, kt::Cancelled);
    else t->wait_cancelled = true;
    return kSuccess;
}

// ==== SVCs: KConditionVariable ==============================================================

uint32_t KernelThreads::arbitrate_lock(KThread& self, uint32_t owner_handle, uint64_t address, uint32_t tag, bool& blocked) {
    blocked = false;
    if (address & 3) return kmem::result::InvalidAddress;
    const auto test_tag = config_.memory->read32(address);
    if (!test_tag) return kmem::result::InvalidCurrentMemory;
    if (*test_tag != (owner_handle | kHandleWaitMask)) return kSuccess;
    KThread* owner = thread_from_handle(owner_handle, false);
    if (!owner) return kresult::InvalidHandle;
    self.address_key = address;
    self.address_key_value = tag;
    add_waiter(*owner, self);
    begin_wait(self, KWaitKind::Lock, 0);
    blocked = true;
    return kSuccess;
}

uint32_t KernelThreads::arbitrate_unlock(KThread& self, uint64_t address) {
    if (address & 3) return kmem::result::InvalidAddress;
    bool has_waiters = false;
    KThread* next = remove_waiter_by_key(self, has_waiters, address);
    uint32_t next_value = 0;
    if (next) {
        next_value = next->address_key_value;
        if (has_waiters) next_value |= kHandleWaitMask;
    }
    const uint32_t result = store32(address, next_value) ? kSuccess : kmem::result::InvalidCurrentMemory;
    if (next) end_wait(*next, result);
    return result;
}

uint32_t KernelThreads::wait_process_wide_key(KThread& self, uint64_t address, uint64_t cv_key, uint32_t tag,
                                              int64_t timeout_ns, bool& blocked) {
    blocked = false;
    if (address & 3) return kmem::result::InvalidAddress;
    cv_key &= ~uint64_t{3};
    const uint64_t deadline = timeout_ns > 0 ? deadline_from_ns(timeout_ns) : 0;
    // KConditionVariable::Wait: release the lock (hand it to the next waiter), mark the cv.
    bool has_waiters = false;
    KThread* next = remove_waiter_by_key(self, has_waiters, address);
    uint32_t next_value = 0;
    if (next) {
        next_value = next->address_key_value;
        if (has_waiters) next_value |= kHandleWaitMask;
        end_wait(*next, kSuccess);
    }
    (void)store32(cv_key, 1);                                          // HasWaiterFlag
    if (!store32(address, next_value)) return kmem::result::InvalidCurrentMemory;
    if (timeout_ns == 0) return kt::TimedOut;
    self.cv_key = cv_key;
    self.address_key = address;
    self.address_key_value = tag;
    self.in_cv_tree = true;
    cv_tree_.emplace(std::make_pair(cv_key, self.priority), &self);
    begin_wait(self, KWaitKind::ConditionVariable, deadline);
    blocked = true;
    return kSuccess;
}

void KernelThreads::signal_cv_impl(KThread& t) {
    // KConditionVariable::SignalImpl: UpdateLockAtomic(prev, addr, if_zero = own tag, orr = wait mask).
    const uint64_t address = t.address_key;
    const uint32_t own_tag = t.address_key_value;
    std::optional<uint32_t> prev;
    for (int i = 0; i < 64; ++i) {
        const auto cur = config_.memory->read32(address);
        if (!cur) break;
        const uint32_t desired = *cur == 0 ? own_tag : (*cur | kHandleWaitMask);
        const auto got = config_.memory->compare_exchange32(address, *cur, desired);
        if (!got) break;
        if (*got == *cur) { prev = *cur; break; }
    }
    if (!prev) { end_wait(t, kmem::result::InvalidCurrentMemory); return; }
    if (*prev == HandleTable::kInvalidHandle) { end_wait(t, kSuccess); return; }
    KThread* owner = thread_from_handle(*prev & ~kHandleWaitMask, false);
    if (owner) add_waiter(*owner, t);                                  // still waiting, now for the mutex
    else end_wait(t, kt::InvalidState);
}

void KernelThreads::signal_process_wide_key(uint64_t cv_key, int32_t count) {
    cv_key &= ~uint64_t{3};
    int32_t n = 0;
    auto it = cv_tree_.lower_bound({cv_key, std::numeric_limits<int32_t>::min()});
    while (it != cv_tree_.end() && it->first.first == cv_key && (count <= 0 || n < count)) {
        KThread* t = it->second;
        it = cv_tree_.erase(it);
        t->in_cv_tree = false;
        signal_cv_impl(*t);
        ++n;
        it = cv_tree_.lower_bound({cv_key, std::numeric_limits<int32_t>::min()});
    }
    if (it == cv_tree_.end() || it->first.first != cv_key) (void)store32(cv_key, 0);   // HasNoWaiterFlag
}

// ==== SVCs: KAddressArbiter =================================================================

uint32_t KernelThreads::wait_for_address(KThread& self, uint64_t address, uint32_t type, int64_t value, int64_t timeout_ns,
                                         bool& blocked) {
    blocked = false;
    constexpr uint32_t kWaitIfEqual64 = 3;
    if (type == kWaitIfEqual64) { if (address & 7) return kmem::result::InvalidAddress; }
    else if (address & 3) return kmem::result::InvalidAddress;
    if (type > 2) return kresult::InvalidEnumValue;                    // D-P3.3-6: no 64-bit type on 5.1.0
    const int64_t timeout = timeout_ns;
    const auto v = static_cast<int32_t>(value);
    std::optional<uint32_t> user;
    if (type == 1) {                                                   // DecrementAndWaitIfLessThan
        for (int i = 0; i < 64; ++i) {
            const auto cur = config_.memory->read32(address);
            if (!cur) break;
            if (static_cast<int32_t>(*cur) >= v) { user = *cur; break; }
            const auto got = config_.memory->compare_exchange32(address, *cur, *cur - 1);
            if (!got) break;
            if (*got == *cur) { user = *cur; break; }
        }
    } else {
        user = config_.memory->read32(address);
    }
    if (!user) return kmem::result::InvalidCurrentMemory;
    if (type == 2) {
        if (static_cast<int32_t>(*user) != v) return kt::InvalidState;
    } else if (static_cast<int32_t>(*user) >= v) {
        return kt::InvalidState;
    }
    if (timeout == 0) return kt::TimedOut;
    self.arbiter_key = address;
    self.in_arbiter_tree = true;
    arbiter_tree_.emplace(std::make_pair(address, self.priority), &self);
    begin_wait(self, KWaitKind::Arbiter, timeout > 0 ? deadline_from_ns(timeout) : 0);
    blocked = true;
    return kSuccess;
}

void KernelThreads::arbiter_wake(uint64_t address, int32_t count) {
    int32_t n = 0;
    auto it = arbiter_tree_.lower_bound({address, std::numeric_limits<int32_t>::min()});
    while (it != arbiter_tree_.end() && it->first.first == address && (count <= 0 || n < count)) {
        KThread* t = it->second;
        arbiter_tree_.erase(it);
        t->in_arbiter_tree = false;
        end_wait(*t, kSuccess);
        ++n;
        it = arbiter_tree_.lower_bound({address, std::numeric_limits<int32_t>::min()});
    }
}

uint32_t KernelThreads::signal_to_address(uint64_t address, uint32_t type, int32_t value, int32_t count) {
    if (address & 3) return kmem::result::InvalidAddress;
    if (type > 2) return kresult::InvalidEnumValue;
    if (type == 0) { arbiter_wake(address, count); return kSuccess; }
    auto update_if_equal = [&](int32_t expect, int32_t desired) -> std::optional<int32_t> {
        const auto got = config_.memory->compare_exchange32(address, static_cast<uint32_t>(expect), static_cast<uint32_t>(desired));
        if (!got) return std::nullopt;
        return static_cast<int32_t>(*got);
    };
    if (type == 1) {                                                   // SignalAndIncrementIfEqual
        const auto user = update_if_equal(value, value + 1);
        if (!user) return kmem::result::InvalidCurrentMemory;
        if (*user != value) return kt::InvalidState;
        arbiter_wake(address, count);
        return kSuccess;
    }
    // SignalAndModifyByWaitingCountIfEqual
    auto it = arbiter_tree_.lower_bound({address, std::numeric_limits<int32_t>::min()});
    const bool any = it != arbiter_tree_.end() && it->first.first == address;
    int32_t new_value;
    if (count <= 0) {
        new_value = any ? value - 1 : value + 1;
    } else if (any) {
        auto tmp = it;
        int32_t tmp_waiters = 0;
        while (++tmp != arbiter_tree_.end() && tmp->first.first == address) {
            if (++tmp_waiters >= count) break;
        }
        new_value = tmp_waiters < count ? value - 1 : value;
    } else {
        new_value = value + 1;
    }
    std::optional<int32_t> user;
    if (value != new_value) user = update_if_equal(value, new_value);
    else if (const auto r = config_.memory->read32(address)) user = static_cast<int32_t>(*r);
    if (!user) return kmem::result::InvalidCurrentMemory;
    if (*user != value) return kt::InvalidState;
    arbiter_wake(address, count);
    return kSuccess;
}

// ==== invariants (tests) =====================================================================

std::string KernelThreads::check_invariants() const {
    char buf[160];
    auto fail = [&](const char* what, const KThread* t) {
        std::snprintf(buf, sizeof buf, "%s (thread %llu)", what, (unsigned long long)(t ? t->id : 0));
        return std::string(buf);
    };
    if (!active_) return threads_.empty() ? "" : "inactive with threads";
    std::map<const KThread*, int> in_scheduled, in_suggested;
    for (int pass = 0; pass < 2; ++pass) {
        const QueueImpl& q = pass == 0 ? scheduled_ : suggested_;
        for (int core = 0; core < kNumVirtualCores; ++core) {
            for (int prio = 0; prio < kNumThreadPriorities; ++prio) {
                const KThread* h = q.head[static_cast<size_t>(prio)][static_cast<size_t>(core)];
                const bool bit = (q.available[static_cast<size_t>(core)] >> prio) & 1;
                if (bit != (h != nullptr)) return fail("available bit out of sync", h);
                const KThread* prev = nullptr;
                size_t guard = 0;
                for (const KThread* t = h; t; t = t->queue_entry[static_cast<size_t>(core)].next) {
                    if (++guard > threads_.size()) return fail("queue cycle", t);
                    if (t->queue_entry[static_cast<size_t>(core)].prev != prev) return fail("queue prev link", t);
                    if (!find(t->id) || find(t->id) != t) return fail("queued thread not owned", t);
                    if (t->state != KThreadState::Runnable) return fail("non-runnable thread queued", t);
                    if (t->priority != prio) return fail("queued at the wrong priority", t);
                    if (!((t->affinity >> core) & 1)) return fail("queued outside its affinity", t);
                    if ((pass == 0) != (t->active_core == core)) return fail("scheduled/suggested vs active core", t);
                    ++(pass == 0 ? in_scheduled : in_suggested)[t];
                    prev = t;
                }
                if (q.tail[static_cast<size_t>(prio)][static_cast<size_t>(core)] != prev) return fail("queue tail", prev);
            }
        }
    }
    size_t running = 0;
    for (const auto& [id, up] : threads_) {
        const KThread* t = up.get();
        if (t->running_counted) ++running;
        const int cores = __builtin_popcountll(t->affinity & ((1ull << kNumVirtualCores) - 1));
        const int sched = in_scheduled.count(t) ? in_scheduled.at(t) : 0;
        const int sugg = in_suggested.count(t) ? in_suggested.at(t) : 0;
        if (t->state == KThreadState::Runnable && !t->suspended) {
            if (sched != (t->active_core >= 0 ? 1 : 0)) return fail("scheduled membership", t);
            if (sugg != cores - sched) return fail("suggested membership", t);
        } else if (sched || sugg) {
            return fail("queued while not runnable", t);
        }
        // ThreadManager mirror
        const ThreadInfo* info = config_.threads->info(id);
        if (!info) return fail("no ThreadManager thread", t);
        switch (t->state) {
            case KThreadState::Runnable:
                if (t->suspended) { if (info->state != ThreadState::Blocked) return fail("TM not blocked (suspended)", t); break; }
                if (info->state != ThreadState::Ready && info->state != ThreadState::Running) return fail("TM not ready", t);
                break;
            case KThreadState::Terminated:
                if (info->state != ThreadState::Terminated) return fail("TM not terminated", t);
                break;
            default:
                if (info->state != ThreadState::Blocked) return fail("TM not blocked", t);
        }
        // wait structures
        const bool waiting = t->state == KThreadState::Waiting;
        if (!waiting && (t->wait != KWaitKind::None || t->in_cv_tree || t->in_arbiter_tree || t->lock_owner ||
                         !t->sync_objects.empty() || t->wait_deadline))
            return fail("wait state on a thread that does not wait", t);
        size_t timers = 0;
        for (const auto& [deadline, tid] : timers_) if (tid == id) { ++timers; if (deadline != t->wait_deadline) return fail("timer key", t); }
        const bool has_timer = waiting && t->wait_deadline != 0 && t->wait_deadline != kInfinite;
        if (timers != (has_timer ? 1u : 0u)) return fail("timer membership", t);
        size_t cv = 0, arb = 0;
        for (const auto& [key, w] : cv_tree_) if (w == t) { ++cv; if (key.first != t->cv_key || key.second != t->priority) return fail("cv key", t); }
        for (const auto& [key, w] : arbiter_tree_) if (w == t) { ++arb; if (key.first != t->arbiter_key || key.second != t->priority) return fail("arbiter key", t); }
        if (cv != (t->in_cv_tree ? 1u : 0u) || arb != (t->in_arbiter_tree ? 1u : 0u)) return fail("tree membership", t);
        if (waiting) {
            switch (t->wait) {
                case KWaitKind::Sleep: if (!t->wait_deadline || t->lock_owner || cv || arb || !t->sync_objects.empty()) return fail("sleep wait", t); break;
                case KWaitKind::Lock: if (!t->lock_owner || cv || arb || !t->sync_objects.empty()) return fail("lock wait", t); break;
                case KWaitKind::ConditionVariable:
                    if ((cv != 0) == (t->lock_owner != nullptr) || arb || !t->sync_objects.empty()) return fail("condvar wait", t);
                    break;
                case KWaitKind::Arbiter: if (!arb || cv || t->lock_owner || !t->sync_objects.empty()) return fail("arbiter wait", t); break;
                case KWaitKind::Synchronization:
                    if (cv || arb || t->lock_owner) return fail("sync wait", t);
                    for (uint64_t obj : t->sync_objects) {
                        auto it = object_waiters_.find(obj);
                        // one entry per occurrence (a handle may be listed twice, as in mesosphere)
                        if (it == object_waiters_.end() ||
                            std::count(it->second.begin(), it->second.end(), t) !=
                                std::count(t->sync_objects.begin(), t->sync_objects.end(), obj))
                            return fail("sync object membership", t);
                        if (is_signaled(obj)) return fail("waiting on a signaled object", t);
                    }
                    break;
                case KWaitKind::Ipc:
                    if (t->wait_deadline || cv || arb || t->lock_owner || !t->sync_objects.empty() || t->ipc_wait.empty())
                        return fail("ipc wait", t);
                    break;
                case KWaitKind::None: return fail("waiting without a kind", t);
            }
        }
        if (t->lock_owner) {
            const KThread* o = t->lock_owner;
            size_t n = 0;
            for (const auto& l : o->held_locks)
                for (const KThread* w : l.waiters) if (w == t) { ++n; if (l.key != t->address_key) return fail("lock key", t); }
            if (n != 1) return fail("lock owner membership", t);
        }
        int32_t expect = t->base_priority;
        for (const auto& l : t->held_locks) {
            if (l.waiters.empty()) return fail("empty held lock", t);
            for (size_t i = 0; i < l.waiters.size(); ++i) {
                if (l.waiters[i]->lock_owner != t) return fail("waiter owner link", l.waiters[i]);
                if (i && l.waiters[i - 1]->priority > l.waiters[i]->priority) return fail("waiters out of priority order", t);
            }
            expect = std::min(expect, l.waiters.front()->priority);
        }
        if (t->priority != expect) return fail("inherited priority", t);
    }
    for (const auto& [obj, list] : object_waiters_) {
        if (list.empty()) return "empty object waiter list";
        for (const KThread* t : list)
            if (!find(t->id) || t->wait != KWaitKind::Synchronization ||
                std::count(t->sync_objects.begin(), t->sync_objects.end(), obj) != std::count(list.begin(), list.end(), t))
                return fail("stale object waiter", t);
    }
    if (running != running_count_) return "running count";
    for (int core = 0; core < kNumVirtualCores; ++core) {
        const KThread* t = top_[static_cast<size_t>(core)];
        if (t && (!find(t->id) || t->state != KThreadState::Runnable || t->active_core != core)) return fail("top thread", t);
    }
    return {};
}

} // namespace lg::system
