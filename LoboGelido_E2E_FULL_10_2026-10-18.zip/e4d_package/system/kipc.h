#pragma once
// P3.4: IPC objects of the guest kernel (P3_4_DISENO.md §2.1-2.2, §2.6).
//
// Ports and sessions with Horizon's semantics on the CLIENT side (the guest): named ports
// (KObjectName, up to 11 characters), KClientPort session limits (OutOfSessions at once),
// KSession close states (SessionClosed), and the message checks the kernel does when a
// request reaches a server (move handles refused, copy handles translated or the whole IPC
// fails, A/B/W buffer state and permission, pointer buffer space). The SERVER side is a
// high-level-emulated service (hle::HleService) run synchronously in the caller's turn
// (D-P3.4-1). Guest-written servers (CreateSession, ReplyAndReceive, ...) are out of P3.4
// (D-P3.4-7); the session keeps the server side behind one object so they can be added.
//
// Not internally synchronised: the guest-execution thread, under the coordinator lock.
#include <cstdint>
#include <deque>
#include <functional>
#include <optional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "guest_memory.h"
#include "handle_table.h"
#include "hipc.h"
#include "kthread.h"
#include "vm_manager.h"
#include "hle/hle_service.h"
#include "../cpu/guest_clock.h"

namespace lg::system {

namespace kresult_ipc {   // kernel results (module 1)
constexpr uint32_t OutOfSessions = 0xE01;        // 7
constexpr uint32_t OutOfResource = 0xCE01;       // 103
constexpr uint32_t OutOfHandles = 0xD201;        // 105
constexpr uint32_t InvalidCurrentMemory = 0xD401;
constexpr uint32_t InvalidHandle = 0xE401;
constexpr uint32_t InvalidPointer = 0xE601;
constexpr uint32_t InvalidCombination = 0xE801;
constexpr uint32_t OutOfRange = 0xEE01;          // 119
constexpr uint32_t NotFound = 0xF201;            // 121
constexpr uint32_t SessionClosed = 0xF601;       // 123
constexpr uint32_t PortClosed = 0x10601;         // 131
constexpr uint32_t MessageTooLarge = 0x20801;    // 260
constexpr uint32_t ReceiveListBroken = 0x20A01;  // 261 (P6.0)
constexpr uint32_t OutOfAddressSpace = 0x20601;  // 259 (P6.0)
constexpr uint32_t InvalidState = 0xFA01;        // 125 (P6.0)
constexpr uint32_t LimitReached = 0x10801;       // 132 (P6.0)
constexpr uint32_t Cancelled = 0xEC01;           // 118 (P6.0)
constexpr uint32_t InvalidAddress = 0xCC01;      // 102 (P6.0)
constexpr uint32_t InvalidSize = 0xCA01;         // 101 (P6.0)
} // namespace kresult_ipc

struct KernelIpcConfig {
    uint64_t process_id{};
    const cpu::GuestClock* clock{};
    HandleTable* handles{};
    GuestMemory* memory{};
    VmManager* vm{};
    KernelThreads* kthreads{};
    int64_t wall_clock_base{};           // POSIX seconds at begin() (D-P3.4-5)
    // P6.0 (guest IPC): the other kernel parts' references to an object a message carries
    std::function<bool(const KObjectRef&)> retain;    // one more handle to it (copy handles)
    std::function<void(const KObjectRef&)> release;   // a handle to it went away (cleanup)
    std::function<bool()> reserve_session;            // SessionCountMax has room
    std::function<bool()> reserve_event;              // EventCountMax has room
    /** Optional: create host-owned shared memory (KernelObjects::create_host_shared_memory). */
    std::function<uint64_t(uint64_t size)> create_host_shared;
};

class KernelIpc {
public:
    static constexpr uint32_t kPointerBufferSize = 0x8000;   // D-P3.4-4
    static constexpr int32_t kPortMaxSessions = 64;          // D-P3.4-8
    static constexpr size_t kDomainMaxObjects = 64;          // D-P3.4-8
    static constexpr size_t kNameMax = 12;                   // KObjectName::NameLengthMax
    using Factory = std::function<std::shared_ptr<hle::HleService>()>;

    KernelIpc() = default;
    KernelIpc(const KernelIpc&) = delete;
    KernelIpc& operator=(const KernelIpc&) = delete;

    void reset() noexcept;
    bool begin(const KernelIpcConfig& config);
    bool active() const noexcept { return active_; }

    // ---- host side: what exists --------------------------------------------------------
    /** A named port served by the host (ManageNamedPort equivalent). false if the name is
     *  empty, too long, or taken. */
    bool create_named_port(const std::string& name, int32_t max_sessions, Factory factory);
    /** A service in sm's table; deferred GetServiceHandle requests for it are retried. */
    bool register_service(const std::string& name, Factory factory);
    bool service_registered(const std::string& name) const { return services_.count(name) != 0; }
    /** New interface object of a registered service (sm GetServiceHandle); nullptr if none. */
    std::shared_ptr<hle::HleService> open_service(const std::string& name) const;

    // ---- SVCs ------------------------------------------------------------------------------
    uint32_t connect_to_named_port(uint64_t name_address, uint32_t& out_handle);
    struct SendResult {
        uint32_t result{};
        bool blocked{};       // deferred: the thread now waits (SvcOutcome::Block)
        std::string fatal;    // non-empty: unimplemented command / message type (D3)
    };
    SendResult send_sync_request(KThread& self, uint32_t handle);
    void on_handle_closed(const KObjectRef& object);

    // ---- P6.0: guest-written servers (kipc_guest.cpp, P6_0_DISENO.md §4) -----------------
    uint32_t create_session(bool light, uint64_t name, uint32_t& out_server, uint32_t& out_client);
    uint32_t create_port(int32_t max_sessions, bool light, uint64_t name, uint32_t& out_server, uint32_t& out_client);
    uint32_t manage_named_port(uint64_t name_address, int32_t max_sessions, uint32_t& out_server);
    uint32_t connect_to_port(uint32_t port_handle, uint32_t& out_handle);
    uint32_t accept_session(uint32_t port_handle, uint32_t& out_handle);
    /** SendSyncRequest[WithUserBuffer] on a session whose server is a guest thread. `message`
     *  0 = the thread's TLS. The thread waits (blocked) until the reply. */
    SendResult send_guest_request(KThread& self, uint32_t handle, uint64_t message, uint64_t size);
    /** SendSyncRequestWithUserBuffer on any session: an HLE server reads the first 0x100 bytes
     *  of the (locked) user buffer as its message (P6.0). */
    SendResult send_sync_request_user(KThread& self, uint32_t handle, uint64_t message, uint64_t size);
    bool is_guest_client_session(uint32_t handle) const;
    /** SendAsyncRequestWithUserBuffer (the user buffer is already locked by the caller's
     *  checks here). */
    uint32_t send_async_request(KThread& self, uint64_t message, uint64_t size, uint32_t handle, uint32_t& out_event);
    /** ReplyAndReceive[WithUserBuffer] (`message` 0 = TLS). */
    SendResult reply_and_receive(KThread& self, uint64_t message, uint64_t size, uint64_t handles, int32_t count,
                                 uint32_t reply_target, int64_t timeout_ns, int32_t& out_index);
    /** Light IPC: the data words are w1-w7 of `ctx` (the caller's registers). */
    SendResult send_sync_request_light(KThread& self, cpu::CpuState& ctx, uint32_t handle);
    SendResult reply_and_receive_light(KThread& self, cpu::CpuState& ctx, uint32_t handle);
    /** One more handle to an IPC object (copy handles of a message). */
    bool add_handle_ref(const KObjectRef& object);
    /** KernelThreads' SyncProvider (KServerSession, KServerPort, KClientPort). */
    std::optional<uint64_t> sync_object_of(uint32_t handle) const;
    bool sync_signaled(uint64_t external_id) const;
    /** A wait of `tid` ended (any reason): its ReplyAndReceive bookkeeping goes. */
    void on_wait_ended(uint64_t tid);
    size_t guest_session_count() const noexcept { return gsessions_.size(); }
    size_t guest_port_count() const noexcept { return gports_.size(); }

    // ---- P6.0: kernel objects owned by HLE services -----------------------------------------
    /** A KEvent for a service (the service holds one reference): push it to the client with
     *  HleRequest::push_copy_handle(); signal and clear it from the host side. */
    KObjectRef create_service_event();
    /** Host-owned shared memory for HLE (e.g. HID applet resource). id==0 on failure. */
    KObjectRef create_service_shared_memory(uint64_t size);
    void signal_service_event(const KObjectRef& event);
    void clear_service_event(const KObjectRef& event);
    /** The service drops its reference (the event lives while the client has handles). */
    void release_service_event(const KObjectRef& event);

    // ---- used by the services ----------------------------------------------------------
    GuestMemory& memory() noexcept { return *config_.memory; }
    /** POSIX seconds now: wall clock at begin() + GuestClock time since (D-P3.4-5). */
    int64_t posix_now() const noexcept;
    uint64_t process_id() const noexcept { return config_.process_id; }

    // ---- diagnostics / tests ----------------------------------------------------------
    uint64_t request_count() const noexcept { return requests_; }
    size_t session_count() const noexcept { return sessions_.size() + gsessions_.size(); }
    size_t domain_count() const noexcept;
    size_t deferred_count() const noexcept { return deferred_.size(); }
    const std::string& last_request() const noexcept { return last_; }
    /** Tests/mutation: ports, sessions, domains and handles agree. "" when they do. */
    std::string check_invariants() const;

private:
    struct Domain {
        std::vector<std::shared_ptr<hle::HleService>> objects;   // id = index + 1; nullptr = free
    };
    struct Port {
        int32_t max_sessions{};
        int32_t num_sessions{};
        Factory factory;
    };
    struct Session {
        uint64_t id{};
        uint32_t handle{};
        bool server_closed{};
        std::string port;                                       // named port it counts against
        std::shared_ptr<hle::HleService> object;               // non-domain
        std::shared_ptr<Domain> domain;                         // after ConvertCurrentObjectToDomain
    };
    struct Deferred { uint64_t thread; uint32_t handle; std::string service; uint64_t message{}; uint64_t message_size{}; };

    SendResult process(KThread& t, uint32_t handle, bool retry, uint64_t message = 0, uint64_t message_size = 0);
    Session* session_from_handle(uint32_t handle);
    /** A new session on `object` (or on `domain`) with a client handle; 0 if the table is full. */
    uint32_t open_session(std::shared_ptr<hle::HleService> object, std::shared_ptr<Domain> domain, const std::string& port);
    void close_session(uint64_t id);
    std::string dump(const hipc::Message& m, size_t words) const;
    void retry_deferred(const std::string& service);

    // ---- P6.0: guest IPC objects ---------------------------------------------------------
    struct GuestMap { uint64_t client, server, size; uint32_t state; uint8_t kind; };   // kind 0 send 1 recv 2 exch
    struct GuestRequest {
        uint64_t thread{};            // client thread
        uint64_t message{}, size{};   // user buffer; 0 = the client's TLS
        uint64_t event{};             // async: KEvent id (0 = synchronous)
        std::vector<GuestMap> maps;
    };
    struct GuestSession {
        bool light{};
        uint32_t client_refs{}, server_refs{};
        bool client_closed{}, server_closed{};
        uint64_t port{};              // the port it was created through (0: CreateSession)
        bool queued{};                // in its port's accept queue (the port holds the server end)
        std::deque<GuestRequest> requests;
        std::optional<GuestRequest> current;
        // light sessions
        std::deque<uint64_t> light_requests;
        uint64_t light_current{}, light_server{}, light_waiting{};
    };
    struct GuestPort {
        bool light{};
        int32_t max_sessions{}, num_sessions{};
        uint32_t client_refs{}, server_refs{};
        bool client_closed{}, server_closed{};
        std::string name;             // ManageNamedPort: the name table holds a client reference
        std::deque<uint64_t> queue;   // sessions waiting for AcceptSession
    };
    struct ServerWait { uint64_t message{}, size{}; std::vector<uint64_t> objects; };
    static constexpr uint64_t kExtServerSession = 1ull << 56, kExtServerPort = 2ull << 56, kExtClientPort = 3ull << 56;
    static constexpr uint64_t kExtIdMask = (1ull << 56) - 1;

    GuestSession* guest_session(uint32_t handle, KObjectType type);
    GuestPort* guest_port(uint32_t handle, KObjectType type);
    uint32_t new_session(bool light, uint64_t port, uint64_t& out_id);
    uint32_t port_create_session(uint64_t port_id, uint32_t& out_handle);
    void maybe_finalize_session(uint64_t id);
    void maybe_finalize_port(uint64_t id);
    void on_guest_client_closed(uint64_t id);
    void on_guest_server_closed(uint64_t id);
    void guest_handle_closed(const KObjectRef& object);
    void finish_request(GuestRequest& r, uint32_t client_result);
    void cleanup_maps(GuestRequest& r);
    void try_deliver(uint64_t session_id);
    void light_deliver(uint64_t session_id);
    /** KServerSession::ReceiveRequest into `server` (its wait buffer). NotFound / ReceiveListBroken
     *  / SessionClosed as the kernel. */
    uint32_t receive_request(uint64_t session_id, KThread& server, uint64_t message, uint64_t size);
    uint32_t send_reply(uint64_t session_id, KThread& server, uint64_t message, uint64_t size);
    uint32_t receive_message(KThread& server, uint64_t dst_va, uint64_t dst_size, GuestRequest& req, bool& recv_list_broken);
    uint32_t send_message(KThread& server, uint64_t src_va, uint64_t src_size, GuestRequest& req);
    bool read_words(const KThread& t, uint64_t va, uint64_t size, std::vector<uint32_t>& out) const;
    bool write_words(const KThread& t, uint64_t va, const std::vector<uint32_t>& w, size_t count);
    uint32_t read_port_name(uint64_t address, std::string& out) const;
    std::map<uint64_t, GuestSession> gsessions_;
    std::map<uint64_t, GuestPort> gports_;
    std::map<std::string, uint64_t> gnames_;
    std::map<uint64_t, ServerWait> server_waits_;   // thread id -> ReplyAndReceive in progress
    uint64_t next_port_{1};

    KernelIpcConfig config_{};
    bool active_{false};
    uint64_t tick0_{};
    std::map<std::string, Port> ports_;
    std::map<std::string, Factory> services_;
    std::map<uint64_t, Session> sessions_;
    uint64_t next_session_{1};
    std::vector<Deferred> deferred_;
    uint64_t requests_{};
    std::string last_;
};

} // namespace lg::system
