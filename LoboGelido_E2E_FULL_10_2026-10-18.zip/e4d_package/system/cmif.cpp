#include "cmif.h"

#include <cstring>

namespace lg::system::cmif {
namespace {
const uint8_t* bytes(const hipc::Message& m) noexcept { return reinterpret_cast<const uint8_t*>(m.data()); }
uint8_t* bytes(hipc::Message& m) noexcept { return reinterpret_cast<uint8_t*>(m.data()); }
uint32_t rd32(const uint8_t* p) noexcept { uint32_t v; std::memcpy(&v, p, 4); return v; }
void wr32(uint8_t* p, uint32_t v) noexcept { std::memcpy(p, &v, 4); }
} // namespace

uint32_t parse_request(const hipc::Message& m, const hipc::Request& h, bool domain, InRequest& out) {
    out = InRequest{};
    out.domain = domain;
    const uint32_t begin = payload_offset(h.data_offset);
    const uint32_t end = (h.data_offset + h.data_words) * 4;         // <= 0x100 (hipc::parse)
    const uint8_t* b = bytes(m);
    uint32_t p = begin;
    uint32_t raw_end = end;
    if (domain) {
        if (p + 16 > end) return result::InvalidHeaderSize;
        out.domain_type = b[p];
        const uint8_t num_in = b[p + 1];
        const uint16_t data_size = static_cast<uint16_t>(b[p + 2] | (b[p + 3] << 8));
        out.object_id = rd32(b + p + 4);
        out.token = rd32(b + p + 12);
        p += 16;
        if (out.domain_type == domain_type::Close) return 0;          // no SFCI header
        if (data_size < 16 || p + data_size > end) return result::InvalidHeaderSize;
        raw_end = p + data_size;
        if (raw_end + uint32_t{num_in} * 4 > end) return result::InvalidNumInObjects;
        for (uint32_t k = 0; k < num_in; ++k) out.in_objects.push_back(rd32(b + raw_end + 4 * k));
    }
    if (p + 16 > raw_end) return result::InvalidHeaderSize;
    if (rd32(b + p) != kInMagic) return result::InvalidInHeader;
    out.version = rd32(b + p + 4);
    out.command = rd32(b + p + 8);
    if (!domain) out.token = rd32(b + p + 12);
    p += 16;
    out.raw.assign(b + p, b + raw_end);
    return 0;
}

bool write_reply(hipc::Message& m, const hipc::Response& handles, bool domain, const OutReply& reply) {
    const size_t ids = domain ? reply.object_ids.size() : 0;
    const size_t data_bytes = 16 /* alignment */ + (domain ? 16 : 0) + 16 + reply.raw.size() + ids * 4;
    if (data_bytes > kDataBytesMax) return false;
    hipc::Response r = handles;
    r.type = 0;
    r.data_words = static_cast<uint32_t>((data_bytes + 3) / 4);
    const uint32_t data_index = hipc::build(r, m);
    if (!data_index) return false;
    uint32_t p = payload_offset(data_index);
    const size_t needed = (domain ? 16 : 0) + 16 + reply.raw.size() + ids * 4;
    if (p + needed > (data_index + r.data_words) * 4 || p + needed > hipc::kMessageBytes) return false;
    uint8_t* b = bytes(m);
    if (domain) {
        wr32(b + p, static_cast<uint32_t>(ids));                      // CmifDomainOutHeader
        p += 16;
    }
    wr32(b + p, kOutMagic);
    wr32(b + p + 4, 0);
    wr32(b + p + 8, reply.result);
    wr32(b + p + 12, 0);
    p += 16;
    if (!reply.raw.empty()) std::memcpy(b + p, reply.raw.data(), reply.raw.size());
    p += static_cast<uint32_t>(reply.raw.size());
    for (size_t k = 0; k < ids; ++k, p += 4) wr32(b + p, reply.object_ids[k]);
    return true;
}

} // namespace lg::system::cmif
