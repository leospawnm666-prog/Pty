#include "hipc.h"

namespace lg::system::hipc {
namespace {
constexpr uint32_t bits(uint32_t v, unsigned lo, unsigned n) noexcept { return (v >> lo) & ((1u << n) - 1u); }

StaticDescriptor unpack_static(const uint32_t* w) noexcept {
    StaticDescriptor d;
    d.index = bits(w[0], 0, 4);
    d.address = uint64_t{w[1]} | (uint64_t{bits(w[0], 12, 4)} << 32) | (uint64_t{bits(w[0], 6, 3)} << 36);
    d.size = bits(w[0], 16, 16);
    return d;
}
BufferDescriptor unpack_buffer(const uint32_t* w) noexcept {
    BufferDescriptor d;
    d.size = uint64_t{w[0]} | (uint64_t{bits(w[2], 24, 4)} << 32);
    d.address = uint64_t{w[1]} | (uint64_t{bits(w[2], 28, 4)} << 32) | (uint64_t{bits(w[2], 2, 3)} << 36);
    d.mode = bits(w[2], 0, 2);
    return d;
}
ReceiveEntry unpack_receive(const uint32_t* w) noexcept {
    ReceiveEntry d;
    d.address = uint64_t{w[0]} | (uint64_t{bits(w[1], 0, 7)} << 32);
    d.size = bits(w[1], 16, 16);
    return d;
}
} // namespace

void pack_static(const StaticDescriptor& d, uint32_t out[2]) noexcept {
    out[0] = (d.index & 0xF) | (static_cast<uint32_t>((d.address >> 36) & 7) << 6) |
             (static_cast<uint32_t>((d.address >> 32) & 0xF) << 12) | (static_cast<uint32_t>(d.size & 0xFFFF) << 16);
    out[1] = static_cast<uint32_t>(d.address);
}

void pack_buffer(const BufferDescriptor& d, uint32_t out[3]) noexcept {
    out[0] = static_cast<uint32_t>(d.size);
    out[1] = static_cast<uint32_t>(d.address);
    out[2] = (d.mode & 3) | (static_cast<uint32_t>((d.address >> 36) & 7) << 2) |
             (static_cast<uint32_t>((d.size >> 32) & 0xF) << 24) | (static_cast<uint32_t>((d.address >> 32) & 0xF) << 28);
}

void pack_receive(const ReceiveEntry& d, uint32_t out[2]) noexcept {
    out[0] = static_cast<uint32_t>(d.address);
    out[1] = static_cast<uint32_t>((d.address >> 32) & 0x7F) | (static_cast<uint32_t>(d.size & 0xFFFF) << 16);
}

uint32_t raw_data_index(const Message& m) noexcept {
    const uint32_t w0 = m[0], w1 = m[1];
    uint32_t idx = 2;
    if (bits(w1, 31, 1)) {
        const uint32_t s = m[2];
        idx += 1 + (bits(s, 0, 1) ? 2 : 0) + bits(s, 1, 4) + bits(s, 5, 4);
    }
    idx += bits(w0, 16, 4) * 2;
    idx += (bits(w0, 20, 4) + bits(w0, 24, 4) + bits(w0, 28, 4)) * 3;
    return idx;
}

uint32_t parse(const Message& m, Request& out, size_t size) {
    out = Request{};
    if (size > kMessageBytes) size = kMessageBytes;
    const uint32_t w0 = m[0], w1 = m[1];
    out.type = bits(w0, 0, 16);
    const uint32_t nx = bits(w0, 16, 4), na = bits(w0, 20, 4), nb = bits(w0, 24, 4), nw = bits(w0, 28, 4);
    out.data_words = bits(w1, 0, 10);
    out.recv_mode = bits(w1, 10, 4);
    out.recv_offset = bits(w1, 20, 11);
    out.has_special = bits(w1, 31, 1) != 0;
    uint32_t special = 0;
    if (out.has_special) special = m[2];
    const uint32_t ncopy = out.has_special ? bits(special, 1, 4) : 0;
    const uint32_t nmove = out.has_special ? bits(special, 5, 4) : 0;
    out.send_pid = out.has_special && bits(special, 0, 1);

    // KServerSession::ReceiveMessage / MessageBuffer::GetMessageBufferSize
    const uint32_t special_index = 2 + (out.has_special ? 1 : 0);
    const uint32_t x_index = special_index + (out.send_pid ? 2 : 0) + ncopy + nmove;
    const uint32_t map_index = x_index + nx * 2;
    const uint32_t raw_index = map_index + (na + nb + nw) * 3;
    const uint32_t raw_end = raw_index + out.data_words;
    out.recv_index = out.recv_offset ? out.recv_offset : raw_end;
    size_t msg_size = size_t{out.recv_index} * 4;
    uint32_t entries = 0;
    if (out.recv_mode == recv_mode::ToSingleBuffer) entries = 1;
    else if (out.recv_mode > recv_mode::ToSingleBuffer) entries = out.recv_mode - 2;
    msg_size += size_t{entries} * 8;
    out.end_bytes = static_cast<uint32_t>(msg_size);
    if (msg_size > size) return result::InvalidCombination;
    if (size_t{raw_end} * 4 > size) return result::MessageTooLarge;
    // The client's receive list is where the reply goes: its offset may not overlap the body.
    if (out.recv_offset && out.recv_offset < raw_end) return result::InvalidCombination;

    uint32_t i = special_index;
    if (out.send_pid) { out.pid_value = uint64_t{m[i]} | (uint64_t{m[i + 1]} << 32); i += 2; }
    for (uint32_t k = 0; k < ncopy; ++k) out.copy_handles.push_back(m[i++]);
    for (uint32_t k = 0; k < nmove; ++k) out.move_handles.push_back(m[i++]);
    for (uint32_t k = 0; k < nx; ++k, i += 2) out.x.push_back(unpack_static(&m[i]));
    for (uint32_t k = 0; k < na; ++k, i += 3) out.a.push_back(unpack_buffer(&m[i]));
    for (uint32_t k = 0; k < nb; ++k, i += 3) out.b.push_back(unpack_buffer(&m[i]));
    for (uint32_t k = 0; k < nw; ++k, i += 3) out.w.push_back(unpack_buffer(&m[i]));
    out.data_offset = raw_index;
    for (uint32_t k = 0; k < entries; ++k) out.c.push_back(unpack_receive(&m[out.recv_index + 2 * k]));
    return result::Success;
}

uint32_t build(const Response& r, Message& m) noexcept {
    m.fill(0);
    const bool special = !r.copy_handles.empty() || !r.move_handles.empty();
    if (r.copy_handles.size() > 15 || r.move_handles.size() > 15 || r.x.size() > 15 || r.data_words > 0x3FF) return 0;
    const size_t total = 2 + (special ? 1 + r.copy_handles.size() + r.move_handles.size() : 0) + r.x.size() * 2 + r.data_words;
    if (total > kMessageWords) return 0;
    m[0] = (r.type & 0xFFFF) | (static_cast<uint32_t>(r.x.size()) << 16);
    m[1] = (r.data_words & 0x3FF) | (special ? 1u << 31 : 0u);
    uint32_t i = 2;
    if (special) {
        m[i++] = (static_cast<uint32_t>(r.copy_handles.size()) << 1) | (static_cast<uint32_t>(r.move_handles.size()) << 5);
        for (uint32_t h : r.copy_handles) m[i++] = h;
        for (uint32_t h : r.move_handles) m[i++] = h;
    }
    for (const auto& x : r.x) { pack_static(x, &m[i]); i += 2; }
    return i;
}

} // namespace lg::system::hipc
