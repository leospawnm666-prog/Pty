#pragma once
// P3.4: CMIF on top of HIPC (P3_4_DISENO.md §2.4; libnx cmif.h, Atmosphère sf).
//
// The CMIF payload starts 16-byte aligned from the TLS base, inside the raw data words:
//   [DomainInHeader (16) — domain sessions only] SFCI header (16) raw input … [in object ids]
// and a reply:
//   [DomainOutHeader (16)] SFCO header (16) raw output … [out object ids — domain only]
// Pure functions: no guest memory, no kernel state.
#include <cstdint>
#include <vector>

#include "hipc.h"

namespace lg::system::cmif {

constexpr uint32_t kInMagic = 0x49434653;    // "SFCI"
constexpr uint32_t kOutMagic = 0x4F434653;   // "SFCO"
constexpr uint32_t kDataBytesMax = 0x3FF * 4;

namespace type {
constexpr uint32_t Invalid = 0, LegacyRequest = 1, Close = 2, LegacyControl = 3, Request = 4, Control = 5,
                   RequestWithContext = 6, ControlWithContext = 7;
} // namespace type

namespace domain_type {
constexpr uint8_t SendMessage = 1, Close = 2;
} // namespace domain_type

/** sf (module 10) results used by the CMIF layer (Atmosphère sf_results.hpp). */
namespace result {
constexpr uint32_t NotSupported = 0x20A;           // 1
constexpr uint32_t InvalidHeaderSize = 0x1940A;    // 202
constexpr uint32_t InvalidInHeader = 0x1A60A;      // 211
constexpr uint32_t UnknownCommandId = 0x1BA0A;     // 221
constexpr uint32_t InvalidNumInObjects = 0x1D60A;  // 235
constexpr uint32_t InvalidInObject = 0x1DE0A;      // 239
constexpr uint32_t TargetNotFound = 0x20A0A;       // 261
constexpr uint32_t OutOfDomainEntries = 0x25A0A;   // 301
} // namespace result

struct InRequest {
    bool domain{};
    uint8_t domain_type{};                // domain sessions only
    uint32_t object_id{};                 // domain sessions only
    std::vector<uint32_t> in_objects;     // domain sessions only
    uint32_t version{};
    uint32_t command{};
    uint32_t token{};
    std::vector<uint8_t> raw;             // after the SFCI header, to the end of the data words
};

/** Byte offset of the CMIF payload for a raw-data word index. */
constexpr uint32_t payload_offset(uint32_t data_index) noexcept { return (data_index * 4 + 15) & ~15u; }

/** Decodes the CMIF part of a Request/Control message. 0 or an sf result (InvalidHeaderSize,
 *  InvalidInHeader, InvalidNumInObjects). A domain Close message has no SFCI header. */
uint32_t parse_request(const hipc::Message& m, const hipc::Request& h, bool domain, InRequest& out);

struct OutReply {
    uint32_t result{};
    std::vector<uint8_t> raw;
    std::vector<uint32_t> object_ids;     // domain replies only
};

/** Writes a complete reply (HIPC header with `handles`, CMIF out header, data, object ids).
 *  false when it does not fit in the 0x100-byte message. */
bool write_reply(hipc::Message& m, const hipc::Response& handles, bool domain, const OutReply& reply);

} // namespace lg::system::cmif
