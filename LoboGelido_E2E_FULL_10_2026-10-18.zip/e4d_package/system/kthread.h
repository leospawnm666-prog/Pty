#pragma once
// P3.3: guest threads and synchronization (P3_3_DISENO.md §2).
//
// A transcription of Atmosphère mesosphere's semantics onto Lobo's single host thread:
//  * KThread / KEvent objects with the Horizon states and results;
//  * KPriorityQueue (per-core "scheduled" and "suggested" queues, 64 priorities) and
//    KScheduler::UpdateHighestPriorityThreadsImpl (idle cores migrate suggested threads),
//    the three yields and RotateScheduledQueue (priority 59 on cores 0-2 every 10 ms);
//  * KConditionVariable (ArbitrateLock/Unlock, WaitProcessWideKeyAtomic/Signal) with priority
//    inheritance (AddWaiter / RemoveWaiterByKey / RestorePriority);
//  * KAddressArbiter (WaitIfLessThan, DecrementAndWaitIfLessThan, WaitIfEqual; Signal,
//    SignalAndIncrementIfEqual, SignalAndModifyByWaitingCountIfEqual);
//  * KSynchronizationObject::Wait (WaitSynchronization) over readable events and threads.
//
// Execution: the coordinator runs, for each virtual core, one quantum of top(core) through
// ThreadManager::dispatch (D-P3.3-1). A thread that waits returns SvcOutcome::Block: its
// CpuState already points after the SVC; whoever ends the wait writes the final registers
// (w0 = Result, and w1 for WaitSynchronization) and makes it runnable again.
// Time: every deadline is a GuestClock tick (D1 / D-P3.3-2).
// Not internally synchronised: the guest-execution thread, under the coordinator lock.
#include <array>
#include <cstdint>
#include <functional>
#include <optional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "guest_memory.h"
#include "guest_thread_context.h"
#include "handle_table.h"
#include "thread_manager.h"
#include "vm_manager.h"
#include "../cpu/guest_clock.h"

namespace lg::system {

constexpr int kNumVirtualCores = 3;                    // D-P3.3-1: cores 0-2 (hbl.json)
constexpr int kNumThreadPriorities = 64;
constexpr int kHighestCoreMigrationAllowedPriority = 2;
constexpr int kPreemptionPriority = 59;                // RotateScheduledQueue on cores 0-2
constexpr uint64_t kPreemptionPeriodTicks = 192'000;    // 10 ms at 19.2 MHz
constexpr uint32_t kHandleWaitMask = 0x40000000u;
constexpr size_t kMaxThreads = 1024;                   // D-P3.3-7
constexpr int kArgumentHandleCountMax = 64;

namespace kresult_thread {
constexpr uint32_t TerminationRequested = 0x7601;      // 59
constexpr uint32_t InvalidPriority = 0xE001;           // 112
constexpr uint32_t InvalidCoreId = 0xE201;             // 113
constexpr uint32_t TimedOut = 0xEA01;                  // 117
constexpr uint32_t Cancelled = 0xEC01;                 // 118
constexpr uint32_t OutOfRange = 0xEE01;                // 119
constexpr uint32_t InvalidState = 0xFA01;              // 125
} // namespace kresult_thread

enum class KThreadState : uint8_t { Initialized, Runnable, Waiting, Terminated };
enum class KWaitKind : uint8_t { None, Sleep, Synchronization, Lock, ConditionVariable, Arbiter, Ipc /* P3.4 */ };

struct KThread {
    // identity
    uint64_t id{};                  // == ThreadManager id
    uint32_t handle{};              // the handle created with the thread (tag of its mutexes)
    // scheduling (priority 0 = highest ... 63)
    int32_t base_priority{};
    int32_t priority{};
    int32_t ideal_core{};
    uint64_t affinity{};
    int32_t active_core{-1};
    KThreadState state{KThreadState::Initialized};
    uint64_t last_scheduled_tick{};
    std::array<uint64_t, kNumVirtualCores> cpu_ticks{};   // GetInfo(ThreadTickCount), per virtual core
    uint64_t yield_schedule_count{~0ull};
    struct QueueEntry { KThread* prev{}; KThread* next{}; };
    std::array<QueueEntry, kNumVirtualCores> queue_entry{};
    // waiting
    KWaitKind wait{KWaitKind::None};
    uint64_t wait_deadline{};       // GuestClock tick; 0 = no timer
    uint32_t wait_result{};
    int32_t synced_index{-1};
    std::vector<uint64_t> sync_objects;   // object ids waited on (Synchronization)
    bool wait_cancelled{};
    // locks / condition variables / arbiter
    uint64_t address_key{};
    uint32_t address_key_value{};
    KThread* lock_owner{};
    struct HeldLock { uint64_t key; std::vector<KThread*> waiters; };   // waiters: priority order, FIFO within
    std::vector<HeldLock> held_locks;
    bool in_cv_tree{};
    uint64_t cv_key{};
    bool in_arbiter_tree{};
    uint64_t arbiter_key{};
    // IPC (P3.4): what a deferred request waits for (diagnostics)
    std::string ipc_wait;
    // memory
    uint64_t tls_va{};
    // lifetime
    uint32_t handle_refs{};
    bool running_counted{};         // counted in the process running-thread count
    // P6.0: SetThreadActivity(Paused) (SuspendType_Thread): a Runnable thread leaves the queues
    bool suspended{};
};

/** What the kernel needs from the coordinator to create a host-level guest thread. */
struct KThreadHost {
    /** Creates the ThreadManager thread + CPU context (pc, sp) for a new guest thread and
     *  returns its id (0 on failure). The thread must start Blocked (not runnable). */
    std::function<uint64_t(uint64_t pc, uint64_t sp)> spawn;
};

struct KernelThreadsConfig {
    uint64_t process_id{};
    uint64_t core_mask{0x7};
    uint64_t priority_mask{((1ull << 60) - 1) & ~((1ull << 28) - 1)};
    int32_t ideal_core{0};
    uint64_t tls_region_base{};      // VA where new TLS pages are placed (stack region)
    uint64_t tls_region_end{};
    const cpu::GuestClock* clock{};
    HandleTable* handles{};
    GuestMemory* memory{};
    VmManager* vm{};
    ThreadManager* threads{};
    GuestThreadContextManager* contexts{};
    KThreadHost host{};
};

class KernelThreads {
public:
    KernelThreads() = default;
    KernelThreads(const KernelThreads&) = delete;
    KernelThreads& operator=(const KernelThreads&) = delete;

    void reset() noexcept;
    bool begin(const KernelThreadsConfig& config);
    bool active() const noexcept { return active_; }
    /** Registers the main thread (already created and runnable in the ThreadManager). */
    bool register_main_thread(uint64_t id, uint32_t handle, int32_t priority, uint64_t tls_va);

    // ---- scheduling (coordinator) ------------------------------------------------------
    /** Fires expired timers, performs due priority-59 rotations and recomputes top(core). */
    void update(uint64_t now_ticks);
    /** The thread core `core` should run now (nullptr = idle). */
    KThread* top(int core) const noexcept { return top_[static_cast<size_t>(core)]; }
    /** Called by the coordinator around each quantum. */
    void begin_turn(int core, KThread* thread, uint64_t now_ticks) noexcept;
    void end_turn() noexcept { current_ = nullptr; current_core_ = -1; }
    /** end_turn() that also charges the turn's ticks to the thread (if it still exists). */
    void end_turn(uint64_t now_ticks) noexcept;
    KThread* current() const noexcept { return current_; }
    int current_core() const noexcept { return current_core_; }
    /** Earliest pending timer (tick), or 0 if none. */
    uint64_t next_deadline() const noexcept { return timers_.empty() ? 0 : timers_.begin()->first; }
    /** Threads started and not terminated (Horizon's running thread count). */
    size_t running_count() const noexcept { return running_count_; }
    size_t live_count() const noexcept;
    /** KThread objects alive (includes created-not-started and terminated-but-referenced). */
    size_t object_count() const noexcept { return threads_.size(); }
    /** P6.0: live events (the resource limit's EventCountMax). */
    size_t event_count() const noexcept { return events_.size(); }
    size_t waiting_count() const noexcept;
    size_t timer_count() const noexcept { return timers_.size(); }
    /** "tid:kind@key" for every waiting thread (deadlock diagnostics). */
    std::string describe_waits() const;
    KThread* find(uint64_t id) noexcept;
    const KThread* find(uint64_t id) const noexcept;
    uint64_t scheduled_count() const noexcept { return scheduled_count_; }

    /** Tests/mutation (R2): every structural invariant of the queues, the wait structures,
     *  priority inheritance and the ThreadManager mirror. "" when they all hold, else the
     *  first violation. O(threads * priorities); never called on the execution path. */
    std::string check_invariants() const;

    // ---- SVC implementations (Result code; `self` = the calling thread) ------------------
    uint32_t create_thread(uint64_t entry, uint64_t arg, uint64_t stack_top, int32_t priority, int32_t core,
                           uint32_t& out_handle);
    uint32_t start_thread(uint32_t handle);
    /** ExitThread: true if it was the last running thread (the process ends). */
    bool exit_thread(KThread& self);
    /** SleepThread: true if the thread now waits (Block). */
    bool sleep_thread(KThread& self, int64_t ns);
    uint32_t get_thread_priority(uint32_t handle, int32_t& out) const;
    uint32_t set_thread_priority(uint32_t handle, int32_t priority);
    uint32_t get_thread_core_mask(uint32_t handle, int32_t& out_core, uint64_t& out_mask) const;
    uint32_t set_thread_core_mask(uint32_t handle, int32_t core, uint64_t mask);
    uint32_t get_thread_id(uint32_t handle, uint64_t& out) const;
    /** GetInfo(ThreadTickCount = 25): subtype ~0 = every core, else a virtual core 0-3. */
    uint32_t thread_tick_count(uint32_t handle, uint64_t subtype, uint64_t now_ticks, uint64_t& out) const;
    uint32_t create_event(uint32_t& out_write, uint32_t& out_read);
    uint32_t signal_event(uint32_t handle);
    uint32_t clear_event(uint32_t handle);
    uint32_t reset_signal(uint32_t handle);
    /** WaitSynchronization: Result; `blocked` = the thread now waits. */
    uint32_t wait_synchronization(KThread& self, uint64_t handles_ptr, int32_t count, int64_t timeout_ns,
                                  int32_t& out_index, bool& blocked);
    uint32_t cancel_synchronization(uint32_t handle);
    uint32_t arbitrate_lock(KThread& self, uint32_t owner_handle, uint64_t address, uint32_t tag, bool& blocked);
    uint32_t arbitrate_unlock(KThread& self, uint64_t address);
    uint32_t wait_process_wide_key(KThread& self, uint64_t address, uint64_t cv_key, uint32_t tag, int64_t timeout_ns,
                                   bool& blocked);
    void signal_process_wide_key(uint64_t cv_key, int32_t count);
    uint32_t wait_for_address(KThread& self, uint64_t address, uint32_t type, int64_t value, int64_t timeout_ns,
                              bool& blocked);
    uint32_t signal_to_address(uint64_t address, uint32_t type, int32_t value, int32_t count);
    /** P3.4: a deferred IPC request (sm GetServiceHandle of a service not registered yet).
     *  The thread waits without a timer until end_ipc_wait(); `what` names it in
     *  describe_waits(). */
    void begin_ipc_wait(KThread& self, std::string what);
    /** Ends an IPC wait: w0 = result (the reply is already in the thread's TLS). */
    void end_ipc_wait(KThread& t, uint32_t result);
    /** CloseHandle of a thread/event handle drops the object's reference. */
    void on_handle_closed(const KObjectRef& object);
    // ---- P6.0 (P6_DISENO.md §3.3) ---------------------------------------------------------
    /** SetThreadActivity: 0 Runnable (resume), 1 Paused (suspend); not on the caller. */
    uint32_t set_thread_activity(KThread& self, uint32_t handle, uint32_t activity);
    /** GetThreadContext3: the svc::ThreadContext (0x320 bytes) of a paused thread. */
    uint32_t get_thread_context3(KThread& self, uint32_t handle, std::vector<uint8_t>& out);
    /** Ids of the process's threads that are not terminated, in creation order. */
    std::vector<uint64_t> thread_ids() const;
    // ---- P6.0: synchronization objects of other kernel parts (guest IPC), duplication ------
    /** Object ids >= kExternalObject belong to the provider (KServerSession, KServerPort,
     *  KClientPort of guest IPC): WaitSynchronization / ReplyAndReceive accept their handles. */
    static constexpr uint64_t kExternalObject = 1ull << 63;
    struct SyncProvider {
        std::function<std::optional<uint64_t>(uint32_t handle)> resolve;   // external id (no bit)
        std::function<bool(uint64_t external_id)> signaled;
        std::function<void(uint64_t tid)> wait_ended;   // a Synchronization wait ended (any reason)
    };
    void set_sync_provider(SyncProvider p) { provider_ = std::move(p); }
    /** KHandleTable::GetMultipleObjects<KSynchronizationObject>: object ids of `count` handles
     *  read from the guest (OutOfRange, InvalidPointer, InvalidHandle as WaitSynchronization). */
    uint32_t resolve_sync_handles(uint64_t handles_ptr, int32_t count, std::vector<uint64_t>& out) const;
    bool object_signaled(uint64_t object) const { return is_signaled(object); }
    /** The waiting part of KSynchronizationObject::Wait after the scan found nothing signaled:
     *  TimedOut for timeout 0, Cancelled after CancelSynchronization, else the thread waits
     *  (blocked = true; the waker writes w0 and w1 = index). */
    uint32_t block_on_objects(KThread& self, std::vector<uint64_t> objects, int64_t timeout_ns, bool& blocked);
    /** Threads waiting on `object`, in the order they started waiting. */
    std::vector<uint64_t> waiters_of(uint64_t object) const;
    /** Ends the Synchronization wait of `tid` as if `object` had signaled it with `result`. */
    void end_sync_wait(uint64_t tid, uint64_t object, uint32_t result);
    /** NotifyAvailable of an external object: every waiter wakes with success. */
    void notify_external(uint64_t external_id) { notify_available(kExternalObject | external_id); }
    /** One more handle to a thread or event (IPC copy handles): its handle reference. */
    bool add_handle_ref(const KObjectRef& object);
    /** A KEvent the kernel creates for SendAsyncRequestWithUserBuffer: only the readable
     *  handle is returned; the kernel keeps one reference until release_kernel_event(). */
    uint32_t create_kernel_event(uint32_t& out_read_handle, uint64_t& out_event_id);
    void signal_kernel_event(uint64_t event_id);
    void clear_kernel_event(uint64_t event_id);
    /** A KEvent with no handle and one kernel reference (HLE services, P6.0). Its id. */
    uint64_t create_host_event();
    void release_kernel_event(uint64_t event_id);
    /** Light IPC: the 7 data words of a thread (w1-w7 of its saved context or of `ctx`). */
    cpu::CpuState* context_of(uint64_t tid) const { return config_.contexts ? config_.contexts->get(tid) : nullptr; }
    /** true if `handle` (pseudo-handle included) names one of the process's threads. */
    bool is_thread_handle(uint32_t handle) const { return thread_from_handle(handle) != nullptr; }
    /** GetInfo(IdleTickCount): ticks virtual core `core` spent without a guest thread since
     *  begin() (Lobo has no interrupt tasks: the idle thread's time is all of it). */
    uint64_t idle_ticks(int core, uint64_t now_ticks) const noexcept;
    /** GetInfo(UserExceptionContextAddress): the process local region, one 0x200-byte slot of
     *  a TLS page reserved on first use and kept for the whole session. 0 if no page is free. */
    uint64_t process_local_region();

private:
    struct KEvent {
        uint64_t id{};
        bool signaled{};
        uint32_t refs{};              // handles open (write + read)
    };
    // KPriorityQueue
    struct QueueImpl {
        std::array<std::array<KThread*, kNumVirtualCores>, kNumThreadPriorities> head{}, tail{};
        std::array<uint64_t, kNumVirtualCores> available{};
        void push_back(int prio, int core, KThread* t);
        void push_front(int prio, int core, KThread* t);
        void remove(int prio, int core, KThread* t);
        KThread* front(int core) const;
        KThread* front(int prio, int core) const;
        KThread* next(int core, const KThread* t) const;
        void move_to_front(int prio, int core, KThread* t);
        KThread* move_to_back(int prio, int core, KThread* t);
    };
    void pq_push_back(int prio, KThread* t);
    void pq_push_front(int prio, KThread* t);
    void pq_remove(int prio, KThread* t);
    void pq_change_priority(int prev, bool is_running, KThread* t);
    void pq_change_affinity(int prev_core, uint64_t prev_affinity, KThread* t);
    void pq_change_core(int prev_core, KThread* t, bool to_front = false);
    KThread* move_to_scheduled_back(KThread* t);

    void update_highest_priority_threads();
    void rotate_scheduled_queue(int core, int priority);
    void yield_without_core_migration(KThread& t);
    void yield_with_core_migration(KThread& t);
    void yield_to_any_thread(KThread& t);
    void increment_scheduled_count() noexcept { ++scheduled_count_; }

    // state transitions
    void set_state(KThread& t, KThreadState s);
    void begin_wait(KThread& t, KWaitKind kind, uint64_t deadline);
    void end_wait(KThread& t, uint32_t result);
    void cancel_wait_structures(KThread& t);
    void set_priority(KThread& t, int32_t priority);
    void restore_priority(KThread* t);
    void add_waiter(KThread& owner, KThread& waiter);
    void add_waiter_impl(KThread& owner, KThread& waiter);
    void remove_waiter(KThread& owner, KThread& waiter);
    void remove_waiter_impl(KThread& owner, KThread& waiter);
    KThread* remove_waiter_by_key(KThread& owner, bool& has_waiters, uint64_t key);
    KThread::HeldLock* find_held_lock(KThread& owner, uint64_t key);
    void signal_cv_impl(KThread& t);
    void notify_available(uint64_t object);
    void arbiter_wake(uint64_t address, int32_t count);
    uint64_t deadline_from_ns(int64_t ns) const noexcept;
    void timer_insert(KThread& t, uint64_t deadline);
    void timer_remove(KThread& t);
    void write_wait_outputs(KThread& t);
    KThread* thread_from_handle(uint32_t handle, bool allow_pseudo = true) const;
    KEvent* event_from_handle(uint32_t handle, KObjectType type) const;
    bool store32(uint64_t address, uint32_t value);
    bool is_signaled(uint64_t object) const;
    uint64_t allocate_tls();
    void release_tls(uint64_t tls_va);
    void maybe_free_thread(KThread& t);
    static uint64_t object_id_for_thread(uint64_t tid) noexcept { return tid << 1; }
    static uint64_t object_id_for_event(uint64_t eid) noexcept { return (eid << 1) | 1; }

    KernelThreadsConfig config_{};
    bool active_{false};
    std::map<uint64_t, std::unique_ptr<KThread>> threads_;
    std::map<uint64_t, std::unique_ptr<KEvent>> events_;
    std::map<uint64_t, std::vector<KThread*>> object_waiters_;   // sync object id -> waiting threads
    uint64_t next_event_id_{1};
    QueueImpl scheduled_, suggested_;
    std::array<KThread*, kNumVirtualCores> top_{};
    KThread* current_{};
    int current_core_{-1};
    uint64_t scheduled_count_{};
    size_t running_count_{};
    std::multimap<uint64_t, uint64_t> timers_;                    // deadline -> thread id
    std::multimap<std::pair<uint64_t, int32_t>, KThread*> cv_tree_;       // (key, priority)
    std::multimap<std::pair<uint64_t, int32_t>, KThread*> arbiter_tree_;  // (address, priority)
    uint64_t next_rotation_{};
    std::vector<uint64_t> free_tls_;
    uint64_t next_tls_page_{};
    SyncProvider provider_;                         // P6.0: guest IPC objects
    // P6.0: GetInfo(IdleTickCount, UserExceptionContextAddress)
    uint64_t begin_tick_{};
    std::array<uint64_t, kNumVirtualCores> core_busy_ticks_{};
    uint64_t process_local_region_{};
};

} // namespace lg::system
