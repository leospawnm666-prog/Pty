#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <mutex>
#include "ipc.h"

// HLE of the Switch shared-font service (nn::pl / pl:u).
//
// SCOPE: real pl:u serves the actual system font data through a shared memory
// block and returns per-font sizes/offsets into it. The Lobo IpcMessage
// transport is a simplified request/response channel, so this endpoint reports
// the font METADATA (load state, nominal size, offset) that a shared-memory
// adapter would expose; it does not ship font blobs. Sizes are deterministic
// nominal placeholders. Thread-safe.
//
// Font types (nn::pl::SharedFontType):
//   0 Standard  1 ChineseSimplified  2 ExtChineseSimplified
//   3 ChineseTraditional  4 KOrean  5 NintendoExtension
//
//   0 RequestLoad                    <- [u32 fontType]
//   1 GetLoadState                   <- [u32 fontType] -> [u32 state] (0=unloaded,1=loaded)
//   2 GetSize                        <- [u32 fontType] -> [u32 size]
//   3 GetSharedMemoryAddressOffset   <- [u32 fontType] -> [u32 offset]

namespace lg::system {

class PlService final : public IpcEndpoint {
public:
    static constexpr uint32_t kFontCount = 6;
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

private:
    mutable std::mutex mutex_;
    std::array<uint8_t, kFontCount> loaded_{};  // 0 = unloaded, 1 = loaded
};

std::unique_ptr<IpcEndpoint> make_pl_service();

} // namespace lg::system
