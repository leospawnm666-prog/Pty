#include "arena_allocator.h"

namespace lg::system {

void ArenaAllocator::reset(uint64_t base, uint64_t size) {
    const uint64_t first = (base + kGranule - 1) & ~(kGranule - 1);
    const uint64_t end = base + size < base ? ~0ull & ~(kGranule - 1) : (base + size) & ~(kGranule - 1);
    base_ = first;
    count_ = end > first ? (end - first) / kGranule : 0;
    used_ = 0;
    bits_.assign(static_cast<size_t>((count_ + 63) / 64), 0);
}

std::optional<std::vector<PhysicalRun>> ArenaAllocator::allocate(uint64_t bytes) {
    std::vector<PhysicalRun> runs;
    if (bytes == 0) return runs;
    if (bytes > ~0ull - (kGranule - 1)) return std::nullopt;
    const uint64_t want = (bytes + kGranule - 1) / kGranule;
    if (want > count_ - used_) return std::nullopt;
    uint64_t got = 0;
    for (uint64_t i = 0; i < count_ && got < want;) {
        if (bits_[i >> 6] == ~0ull && (i & 63) == 0) { i += 64; continue; }   // full word
        if (test(i)) { ++i; continue; }
        const uint64_t start = i;
        while (i < count_ && !test(i) && got < want) { set(i, true); ++i; ++got; }
        runs.push_back({base_ + start * kGranule, (i - start) * kGranule});
    }
    used_ += got;
    return runs;   // got == want: the free count was checked above
}

bool ArenaAllocator::free(uint64_t pa, uint64_t bytes) {
    if (bytes == 0) return true;
    if (pa < base_ || ((pa - base_) % kGranule) || (bytes % kGranule)) return false;
    const uint64_t first = (pa - base_) / kGranule, n = bytes / kGranule;
    if (first > count_ || n > count_ - first) return false;
    for (uint64_t i = first; i < first + n; ++i) if (!test(i)) return false;
    for (uint64_t i = first; i < first + n; ++i) set(i, false);
    used_ -= n;
    return true;
}

bool ArenaAllocator::is_allocated(uint64_t pa) const noexcept {
    if (pa < base_) return false;
    const uint64_t i = (pa - base_) / kGranule;
    return i < count_ && test(i);
}

} // namespace lg::system
