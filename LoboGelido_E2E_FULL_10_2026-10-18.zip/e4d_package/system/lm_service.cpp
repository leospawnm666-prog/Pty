#include "lm_service.h"

namespace lg::system {
namespace {
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }
} // namespace

core::Result<IpcMessage> LmService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // Log
            uint32_t severity{};
            if (!get_u32(r.payload, 0, severity)) return core::Result<IpcMessage>::Error("lm Log: missing severity");
            std::string text(r.payload.begin() + 4, r.payload.end());
            {
                std::lock_guard lock(mutex_);
                ++count_;
                last_severity_ = severity;
                last_message_ = std::move(text);
            }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        case 1: { // SetDestination
            uint32_t dest{};
            if (!get_u32(r.payload, 0, dest)) return core::Result<IpcMessage>::Error("lm SetDestination: short payload");
            { std::lock_guard lock(mutex_); destination_ = dest; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        default:
            return core::Result<IpcMessage>::Error("lm: unknown command");
    }
}

uint64_t LmService::logged_count() const noexcept { std::lock_guard lock(mutex_); return count_; }
std::string LmService::last_message() const { std::lock_guard lock(mutex_); return last_message_; }
uint32_t LmService::last_severity() const noexcept { std::lock_guard lock(mutex_); return last_severity_; }
uint32_t LmService::destination() const noexcept { std::lock_guard lock(mutex_); return destination_; }

std::unique_ptr<IpcEndpoint> make_lm_service() { return std::make_unique<LmService>(); }

} // namespace lg::system
