#include "display_server.h"

#include <algorithm>

namespace lg::system {

uint64_t DisplayServer::open_display(const std::string& name) {
    if (name != "Default" && name != "Internal" && name != "External") return 0;
    std::lock_guard lock(mutex_);
    const uint64_t id = next_display_++;
    displays_[id] = Display{name, 0};
    return id;
}

bool DisplayServer::close_display(uint64_t display_id) {
    std::lock_guard lock(mutex_);
    return displays_.erase(display_id) > 0;
}

bool DisplayServer::display_valid(uint64_t display_id) const {
    std::lock_guard lock(mutex_);
    return displays_.find(display_id) != displays_.end();
}

uint32_t DisplayServer::display_count() const {
    std::lock_guard lock(mutex_);
    return static_cast<uint32_t>(displays_.size());
}

bool DisplayServer::signal_vsync(uint64_t display_id) {
    std::lock_guard lock(mutex_);
    auto it = displays_.find(display_id);
    if (it == displays_.end()) return false;
    ++it->second.vsync;
    return true;
}

uint64_t DisplayServer::vsync_count(uint64_t display_id) const {
    std::lock_guard lock(mutex_);
    auto it = displays_.find(display_id);
    return it == displays_.end() ? 0 : it->second.vsync;
}

uint64_t DisplayServer::create_layer(uint64_t display_id) {
    std::lock_guard lock(mutex_);
    if (displays_.find(display_id) == displays_.end()) return 0;
    const uint64_t id = next_layer_++;
    Layer layer;
    layer.display_id = display_id;
    layers_[id] = std::move(layer);
    return id;
}

bool DisplayServer::destroy_layer(uint64_t layer_id) {
    std::lock_guard lock(mutex_);
    return layers_.erase(layer_id) > 0;
}

bool DisplayServer::layer_valid(uint64_t layer_id) const {
    std::lock_guard lock(mutex_);
    return layers_.find(layer_id) != layers_.end();
}

bool DisplayServer::set_scaling_mode(uint64_t layer_id, uint32_t mode) {
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l) return false;
    l->scaling = mode;
    return true;
}

uint32_t DisplayServer::scaling_mode(uint64_t layer_id) const {
    std::lock_guard lock(mutex_);
    const Layer* l = find_layer_locked(layer_id);
    return l ? l->scaling : 0;
}

uint32_t DisplayServer::buffer_count(uint64_t layer_id) const {
    std::lock_guard lock(mutex_);
    const Layer* l = find_layer_locked(layer_id);
    return l ? l->buffers : 0;
}

bool DisplayServer::set_buffer_count(uint64_t layer_id, uint32_t count) {
    if (count < 1 || count > kMaxBuffers) return false;
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l) return false;
    // Only permitted when the queue is idle (all slots free), like a real BufferQueue.
    for (auto s : l->slots) if (s != SlotState::Free) return false;
    l->buffers = count;
    l->slots.assign(count, SlotState::Free);
    l->queued.clear();
    return true;
}

int32_t DisplayServer::dequeue(uint64_t layer_id) {
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l) return -1;
    for (uint32_t i = 0; i < l->buffers; ++i) {
        if (l->slots[i] == SlotState::Free) {
            l->slots[i] = SlotState::Dequeued;
            return static_cast<int32_t>(i);
        }
    }
    return -1; // no free buffer available
}

bool DisplayServer::queue(uint64_t layer_id, uint32_t slot) {
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l || slot >= l->buffers) return false;
    if (l->slots[slot] != SlotState::Dequeued) return false;
    l->slots[slot] = SlotState::Queued;
    l->queued.push_back(slot);
    return true;
}

bool DisplayServer::cancel(uint64_t layer_id, uint32_t slot) {
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l || slot >= l->buffers) return false;
    if (l->slots[slot] != SlotState::Dequeued) return false;
    l->slots[slot] = SlotState::Free;
    return true;
}

int32_t DisplayServer::acquire(uint64_t layer_id) {
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l || l->queued.empty()) return -1;
    const uint32_t slot = l->queued.front();
    l->queued.erase(l->queued.begin());
    if (slot >= l->buffers || l->slots[slot] != SlotState::Queued) return -1; // defensive
    l->slots[slot] = SlotState::Acquired;
    return static_cast<int32_t>(slot);
}

bool DisplayServer::release(uint64_t layer_id, uint32_t slot) {
    std::lock_guard lock(mutex_);
    Layer* l = find_layer_locked(layer_id);
    if (!l || slot >= l->buffers) return false;
    if (l->slots[slot] != SlotState::Acquired) return false;
    l->slots[slot] = SlotState::Free;
    ++l->presented;
    return true;
}

uint64_t DisplayServer::presented_frames(uint64_t layer_id) const {
    std::lock_guard lock(mutex_);
    const Layer* l = find_layer_locked(layer_id);
    return l ? l->presented : 0;
}

DisplayServer::Layer* DisplayServer::find_layer_locked(uint64_t layer_id) {
    auto it = layers_.find(layer_id);
    return it == layers_.end() ? nullptr : &it->second;
}

const DisplayServer::Layer* DisplayServer::find_layer_locked(uint64_t layer_id) const {
    auto it = layers_.find(layer_id);
    return it == layers_.end() ? nullptr : &it->second;
}

} // namespace lg::system
