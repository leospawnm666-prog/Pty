#include "kipc.h"

#include <algorithm>
#include <cinttypes>
#include <cstdio>
#include <set>

#include "cmif.h"

namespace lg::system {
namespace {
namespace kr = kresult_ipc;
constexpr uint32_t kSuccess = 0;

std::vector<uint8_t> u32_bytes(uint32_t v) {
    std::vector<uint8_t> b(4);
    std::memcpy(b.data(), &v, 4);
    return b;
}
} // namespace

// ==== lifecycle ==============================================================================

void KernelIpc::reset() noexcept {
    active_ = false;
    config_ = {};
    tick0_ = 0;
    ports_.clear();
    services_.clear();
    sessions_.clear();
    next_session_ = 1;
    deferred_.clear();
    requests_ = 0;
    last_.clear();
    gsessions_.clear();   // P6.0
    gports_.clear();
    gnames_.clear();
    server_waits_.clear();
    next_port_ = 1;
}

bool KernelIpc::begin(const KernelIpcConfig& c) {
    reset();
    if (!c.clock || !c.handles || !c.memory || !c.vm || !c.kthreads) return false;
    config_ = c;
    tick0_ = c.clock->ticks();
    active_ = true;
    return true;
}

int64_t KernelIpc::posix_now() const noexcept {
    if (!config_.clock) return config_.wall_clock_base;
    const uint64_t t = config_.clock->ticks();
    return config_.wall_clock_base + static_cast<int64_t>((t >= tick0_ ? t - tick0_ : 0) / cpu::GuestClock::kFrequency);
}

size_t KernelIpc::domain_count() const noexcept {
    std::set<const Domain*> d;
    for (const auto& [id, s] : sessions_) if (s.domain) d.insert(s.domain.get());
    return d.size();
}

// ==== host side ==============================================================================

bool KernelIpc::create_named_port(const std::string& name, int32_t max_sessions, Factory factory) {
    if (!active_ || name.empty() || name.size() >= kNameMax || name.find('\0') != std::string::npos) return false;
    if (max_sessions <= 0 || !factory || ports_.count(name)) return false;
    ports_[name] = Port{max_sessions, 0, std::move(factory)};
    return true;
}

bool KernelIpc::register_service(const std::string& name, Factory factory) {
    if (!active_ || name.empty() || name.size() > 8 || !factory || services_.count(name)) return false;
    services_[name] = std::move(factory);
    retry_deferred(name);
    return true;
}

std::shared_ptr<hle::HleService> KernelIpc::open_service(const std::string& name) const {
    auto it = services_.find(name);
    return it == services_.end() ? nullptr : it->second();
}

// ==== sessions ===============================================================================

KernelIpc::Session* KernelIpc::session_from_handle(uint32_t handle) {
    const KObjectRef* o = config_.handles->get(handle);   // no pseudo-handles
    if (!o || o->type != KObjectType::ClientSession) return nullptr;
    auto it = sessions_.find(o->id);
    return it == sessions_.end() ? nullptr : &it->second;
}

uint32_t KernelIpc::open_session(std::shared_ptr<hle::HleService> object, std::shared_ptr<Domain> domain,
                                 const std::string& port) {
    const uint64_t id = next_session_++;
    const auto handle = config_.handles->add({KObjectType::ClientSession, id});
    if (!handle) return 0;
    Session s;
    s.id = id;
    s.handle = *handle;
    s.port = port;
    s.object = std::move(object);
    s.domain = std::move(domain);
    sessions_.emplace(id, std::move(s));
    if (!port.empty()) ++ports_[port].num_sessions;
    return *handle;
}

void KernelIpc::close_session(uint64_t id) {
    auto it = sessions_.find(id);
    if (it == sessions_.end()) return;
    if (!it->second.port.empty()) {
        auto p = ports_.find(it->second.port);
        if (p != ports_.end() && p->second.num_sessions > 0) --p->second.num_sessions;
    }
    sessions_.erase(it);
}

void KernelIpc::on_handle_closed(const KObjectRef& object) {
    if (object.type == KObjectType::ClientSession && sessions_.count(object.id)) { close_session(object.id); return; }
    guest_handle_closed(object);   // P6.0: guest sessions and ports
}

// ==== SVCs ===================================================================================

uint32_t KernelIpc::connect_to_named_port(uint64_t name_address, uint32_t& out_handle) {
    out_handle = 0;
    // kern_svc_port.cpp GetPortName: copy up to 12 bytes (InvalidPointer on a fault), then the
    // last byte must be NUL (OutOfRange).
    char name[kNameMax] = {};
    bool terminated = false;
    for (size_t i = 0; i < kNameMax; ++i) {
        char ch = 0;
        if (!config_.memory->read(name_address + i, &ch, 1)) return kr::InvalidPointer;
        name[i] = ch;
        if (ch == 0) { terminated = true; break; }
    }
    if (!terminated) return kr::OutOfRange;
    auto it = ports_.find(std::string(name));
    if (it == ports_.end()) {
        // P6.0: a port named by the guest (ManageNamedPort)
        const auto g = gnames_.find(std::string(name));
        if (g == gnames_.end()) return kr::NotFound;
        return port_create_session(g->second, out_handle);
    }
    if (config_.handles->size() >= HandleTable::kCapacity) return kr::OutOfHandles;
    if (it->second.num_sessions >= it->second.max_sessions) return kr::OutOfSessions;   // at once, no wait
    auto object = it->second.factory();
    if (!object) return kr::OutOfResource;
    const uint32_t h = open_session(std::move(object), nullptr, it->first);
    if (!h) return kr::OutOfHandles;
    out_handle = h;
    return kSuccess;
}

KernelIpc::SendResult KernelIpc::send_sync_request(KThread& self, uint32_t handle) {
    if (is_guest_client_session(handle)) return send_guest_request(self, handle, 0, 0);   // P6.0
    return process(self, handle, false);
}

std::string KernelIpc::dump(const hipc::Message& m, size_t words) const {
    std::string out;
    char b[12];
    for (size_t i = 0; i < words && i < m.size(); ++i) {
        std::snprintf(b, sizeof b, i ? " %08x" : "%08x", m[i]);
        out += b;
    }
    return out;
}

KernelIpc::SendResult KernelIpc::send_sync_request_user(KThread& self, uint32_t handle, uint64_t message, uint64_t size) {
    if (is_guest_client_session(handle)) return send_guest_request(self, handle, message, size);
    return process(self, handle, false, message, size);
}

KernelIpc::SendResult KernelIpc::process(KThread& t, uint32_t handle, bool retry, uint64_t message, uint64_t message_size) {
    SendResult out;
    Session* s = session_from_handle(handle);
    if (!s) { out.result = retry ? kr::SessionClosed : kr::InvalidHandle; return out; }
    if (s->server_closed) { out.result = kr::SessionClosed; return out; }
    hipc::Message msg{};
    const bool read_ok = message ? config_.vm->read_linear(message, msg.data(), hipc::kMessageBytes)   // P6.0: user buffer
                                 : (t.tls_va && config_.memory->read(t.tls_va, msg.data(), hipc::kMessageBytes));
    if (!read_ok) {
        out.result = kr::InvalidCurrentMemory;
        return out;
    }
    hipc::Request req;
    if (const uint32_t rc = hipc::parse(msg, req); rc) { out.result = rc; return out; }
    // KServerSession::ReceiveMessage: no move handles from a client; copy handles are
    // translated (pseudo-handles allowed) or the whole IPC fails with InvalidHandle.
    if (!req.move_handles.empty()) { out.result = kr::InvalidCombination; return out; }
    std::vector<KObjectRef> copies;
    for (uint32_t h : req.copy_handles) {
        if (h == 0) { copies.push_back({}); continue; }
        const auto o = config_.handles->resolve(h, t.id, config_.process_id);
        if (!o) { out.result = kr::InvalidHandle; return out; }
        copies.push_back(*o);
    }
    // Pointer (X) data is copied into the server's pointer buffer.
    uint64_t pointer_used = 0;
    for (const auto& x : req.x) {
        if (!x.size) continue;
        pointer_used += (x.size + 15) & ~uint64_t{15};
        if (pointer_used > kPointerBufferSize) { out.result = kr::OutOfResource; return out; }
        if (!config_.memory->accessible(x.address, x.size, false)) { out.result = kr::InvalidCurrentMemory; return out; }
    }
    // Map-alias (A/B/W) buffers: KPageTableBase::SetupForIpcClient checks.
    for (const auto& a : req.a)
        if (const uint32_t rc = config_.vm->check_ipc_buffer(a.address, a.size, a.mode, false); rc) { out.result = rc; return out; }
    for (const auto* list : {&req.b, &req.w})
        for (const auto& d : *list)
            if (const uint32_t rc = config_.vm->check_ipc_buffer(d.address, d.size, d.mode, true); rc) { out.result = rc; return out; }
    if (!retry) ++requests_;

    // The HLE server's side.
    const std::string service = s->domain ? (s->domain->objects.empty() || !s->domain->objects[0] ? std::string("domain")
                                                                                                 : s->domain->objects[0]->name())
                                          : (s->object ? s->object->name() : std::string("?"));
    char label[96];
    const uint64_t session_id = s->id;
    auto fatal = [&](const std::string& what) {
        out.fatal = what + " [" + dump(msg, std::min<size_t>(req.data_offset + req.data_words, hipc::kMessageWords)) + "]";
        return out;
    };
    switch (req.type) {
        case cmif::type::Close:
            // The server closes its end: this and every later request get SessionClosed;
            // the client still owns (and must close) its handle.
            s->server_closed = true;
            s->object.reset();
            s->domain.reset();
            std::snprintf(label, sizeof label, "%s:close", service.c_str());
            last_ = label;
            out.result = kr::SessionClosed;
            return out;
        case cmif::type::Request:
        case cmif::type::RequestWithContext:
        case cmif::type::Control:
        case cmif::type::ControlWithContext:
            break;
        default: {
            std::snprintf(label, sizeof label, "IPC: tipo de mensaje %u no soportado (%s)", req.type, service.c_str());
            return fatal(label);
        }
    }
    const bool control = req.type == cmif::type::Control || req.type == cmif::type::ControlWithContext;
    const bool domain = s->domain != nullptr && !control;
    cmif::InRequest in;
    hipc::Response handles_out;
    cmif::OutReply reply;
    auto finish = [&](bool reply_domain) -> SendResult {
        if (!cmif::write_reply(msg, handles_out, reply_domain, reply)) {
            std::snprintf(label, sizeof label, "IPC: la respuesta de %s no cabe en el mensaje", service.c_str());
            return fatal(label);
        }
        const uint32_t end = hipc::raw_data_index(msg) + (msg[1] & 0x3FF);
        const bool ok = message ? config_.vm->write_linear(message, msg.data(), size_t{end} * 4)
                                : config_.memory->write(t.tls_va, msg.data(), size_t{end} * 4);
        if (!ok) out.result = kr::InvalidCurrentMemory;
        return out;
    };
    if (const uint32_t rc = cmif::parse_request(msg, req, domain, in); rc) {
        reply.result = rc;
        return finish(domain);
    }
    // New sessions/handles created for the reply, undone if the reply cannot be delivered.
    std::vector<uint32_t> created;
    auto rollback = [&] {
        for (uint32_t h : created) {
            const KObjectRef* o = config_.handles->get(h);
            if (!o) continue;
            const KObjectRef obj = *o;
            config_.handles->close(h);
            if (obj.type == KObjectType::ClientSession && sessions_.count(obj.id)) close_session(obj.id);
            else if (config_.release) config_.release(obj);   // P6.0: a reply copy/move handle
        }
        created.clear();
    };

    if (control) {
        std::snprintf(label, sizeof label, "%s:control%u", service.c_str(), in.command);
        last_ = label;
        s = &sessions_.at(session_id);
        switch (in.command) {
            case 0:   // ConvertCurrentObjectToDomain
                if (s->domain) { reply.result = cmif::result::NotSupported; break; }
                s->domain = std::make_shared<Domain>();
                s->domain->objects.push_back(std::move(s->object));
                s->object.reset();
                reply.raw = u32_bytes(1);
                break;
            case 1: {  // CopyFromCurrentDomain
                uint32_t id = 0;
                if (in.raw.size() >= 4) std::memcpy(&id, in.raw.data(), 4);
                if (!s->domain || id == 0 || id > s->domain->objects.size() || !s->domain->objects[id - 1]) {
                    reply.result = cmif::result::TargetNotFound;
                    break;
                }
                auto object = s->domain->objects[id - 1];
                const uint32_t h = open_session(std::move(object), nullptr, {});
                if (!h) { out.result = kr::OutOfHandles; return out; }
                created.push_back(h);
                handles_out.move_handles.push_back(h);
                break;
            }
            case 2:   // CloneCurrentObject
            case 4: { // CloneCurrentObjectEx(tag)
                const uint32_t h = open_session(s->object, s->domain, {});
                if (!h) { out.result = kr::OutOfHandles; return out; }
                created.push_back(h);
                handles_out.move_handles.push_back(h);
                break;
            }
            case 3: {  // QueryPointerBufferSize
                const uint16_t v = static_cast<uint16_t>(kPointerBufferSize);
                reply.raw.assign(reinterpret_cast<const uint8_t*>(&v), reinterpret_cast<const uint8_t*>(&v) + 2);
                break;
            }
            default:
                std::snprintf(label, sizeof label, "IPC no implementada: %s control %u", service.c_str(), in.command);
                return fatal(label);
        }
        SendResult r = finish(false);
        if (!r.fatal.empty() || r.result) rollback();
        return r;
    }

    // Request: the target object.
    std::shared_ptr<hle::HleService> object;
    if (domain) {
        auto& objs = s->domain->objects;
        const bool valid = in.object_id != 0 && in.object_id <= objs.size() && objs[in.object_id - 1];
        if (in.domain_type == cmif::domain_type::Close) {
            if (!valid) { reply.result = cmif::result::TargetNotFound; return finish(true); }
            std::snprintf(label, sizeof label, "%s:close-object%u", objs[in.object_id - 1]->name().c_str(), in.object_id);
            last_ = label;
            objs[in.object_id - 1].reset();
            return finish(true);
        }
        if (in.domain_type != cmif::domain_type::SendMessage) { reply.result = cmif::result::InvalidInHeader; return finish(true); }
        if (!valid) { reply.result = cmif::result::TargetNotFound; return finish(true); }
        object = objs[in.object_id - 1];
    } else {
        object = s->object;
    }
    if (!object) {
        std::snprintf(label, sizeof label, "IPC: sesión %llu sin objeto", (unsigned long long)session_id);
        return fatal(label);
    }
    if (object->has(in.command)) std::snprintf(label, sizeof label, "%s:%s", object->name().c_str(), object->command_name(in.command));
    else std::snprintf(label, sizeof label, "%s:%u", object->name().c_str(), in.command);
    last_ = label;
    if (!object->has(in.command)) {
        std::snprintf(label, sizeof label, "IPC no implementada: %s cmd %u%s", object->name().c_str(), in.command,
                      domain ? " (dominio)" : "");
        return fatal(label);
    }
    hle::HleRequest r(*this, in.command, req.send_pid, config_.process_id, std::move(in.raw), &req);
    r.in_copies_ = copies;   // P6.0
    object->invoke(in.command, r);
    if (!r.failure_.empty()) {
        std::snprintf(label, sizeof label, "IPC: %s cmd %u (%s): ", object->name().c_str(), in.command,
                      object->command_name(in.command));
        return fatal(label + r.failure_);
    }
    if (r.deferred_) {
        if (!retry) {
            deferred_.push_back({t.id, handle, r.defer_reason_, message, message_size});
            config_.kthreads->begin_ipc_wait(t, object->name() + ":" + object->command_name(in.command) + "(\"" + r.defer_reason_ + "\")");
        }
        out.blocked = true;
        return out;
    }
    reply.result = r.result_;
    if (r.result_ == kSuccess) {
        reply.raw = std::move(r.out_raw_);
        handles_out.x = r.out_statics_;
        s = &sessions_.at(session_id);
        for (auto& o : r.out_objects_) {
            if (domain) {
                auto& objs = s->domain->objects;
                auto slot = std::find(objs.begin(), objs.end(), nullptr);
                if (slot == objs.end() && objs.size() >= kDomainMaxObjects) {
                    reply = {cmif::result::OutOfDomainEntries, {}, {}};
                    handles_out = {};
                    rollback();
                    break;
                }
                if (slot == objs.end()) { objs.push_back(o); reply.object_ids.push_back(static_cast<uint32_t>(objs.size())); }
                else { *slot = o; reply.object_ids.push_back(static_cast<uint32_t>(slot - objs.begin() + 1)); }
            } else {
                const uint32_t h = open_session(o, nullptr, {});
                if (!h) { rollback(); out.result = kr::OutOfHandles; return out; }
                created.push_back(h);
                handles_out.move_handles.push_back(h);
            }
        }
        if (reply.result == kSuccess) {
            // P6.0: copy and move handles of the reply (copies before moves, as the message)
            for (const KObjectRef& o : r.out_copies_) {
                const auto h = config_.handles->add(o);
                if (!h) { rollback(); out.result = kr::OutOfHandles; return out; }
                if (config_.retain) config_.retain(o);
                created.push_back(*h);
                handles_out.copy_handles.push_back(*h);
            }
            for (const KObjectRef& o : r.out_moves_) {
                const auto h = config_.handles->add(o);
                if (!h) { rollback(); out.result = kr::OutOfHandles; return out; }
                created.push_back(*h);
                handles_out.move_handles.push_back(*h);
            }
            for (auto& o : r.out_sessions_) {
                const uint32_t h = open_session(o, nullptr, {});
                if (!h) { rollback(); out.result = kr::OutOfHandles; return out; }
                created.push_back(h);
                handles_out.move_handles.push_back(h);
            }
        }
    }
    SendResult res = finish(domain);
    if (!res.fatal.empty() || res.result) rollback();
    return res;
}

void KernelIpc::retry_deferred(const std::string& service) {
    for (size_t i = 0; i < deferred_.size();) {
        if (deferred_[i].service != service) { ++i; continue; }
        const Deferred d = deferred_[i];
        KThread* t = config_.kthreads->find(d.thread);
        if (!t || t->state != KThreadState::Waiting || t->wait != KWaitKind::Ipc) {
            deferred_.erase(deferred_.begin() + static_cast<std::ptrdiff_t>(i));
            continue;
        }
        const SendResult r = process(*t, d.handle, true, d.message, d.message_size);
        if (r.blocked) { ++i; continue; }
        deferred_.erase(deferred_.begin() + static_cast<std::ptrdiff_t>(i));
        if (!r.fatal.empty()) last_ = r.fatal;
        if (d.message)   // P6.0: SendSyncRequestWithUserBuffer unlocks its buffer on the way out
            config_.vm->unlock_memory(d.message, d.message_size, kmem::FlagCanIpcUserBuffer, kmem::FlagCanIpcUserBuffer, 0, 0,
                                      kmem::All, kmem::AttrLocked, kmem::PermRW, kmem::AttrLocked, nullptr);
        config_.kthreads->end_ipc_wait(*t, r.fatal.empty() ? r.result : kr::SessionClosed);
    }
}

// ==== invariants =============================================================================

std::string KernelIpc::check_invariants() const {
    std::map<std::string, int32_t> counts;
    for (const auto& [id, s] : sessions_) {
        const KObjectRef* o = config_.handles->get(s.handle);
        if (!o || o->type != KObjectType::ClientSession || o->id != id) return "session without its handle";
        if (!s.port.empty()) ++counts[s.port];
        if (!s.server_closed && !s.object && !s.domain) return "open session without an object";
        if (s.server_closed && (s.object || s.domain)) return "closed session keeps its object";
        if (s.object && s.domain) return "session with an object and a domain";
        if (s.domain && s.domain->objects.size() > kDomainMaxObjects) return "domain over its limit";
    }
    for (const auto& [name, p] : ports_) {
        const int32_t n = counts.count(name) ? counts.at(name) : 0;
        if (n != p.num_sessions || n > p.max_sessions) return "port session count (" + name + ")";
    }
    // P6.0: guest sessions and ports
    for (const auto& [id, gs] : gsessions_) {
        if (sessions_.count(id)) return "guest session id shared with an HLE session";
        if (!gs.client_refs && !gs.server_refs && !gs.queued) return "guest session without references";
        if (gs.current && gs.light) return "light session with a message request";
        if (gs.server_closed && (!gs.requests.empty() || gs.current)) return "closed server keeps requests";
        if (gs.port && gports_.count(gs.port) == 0) return "guest session of a missing port";
    }
    for (const auto& [id, gp] : gports_) {
        int32_t n = 0;
        for (const auto& [sid, gs] : gsessions_) if (gs.port == id) ++n;
        if (n != gp.num_sessions || n > gp.max_sessions) return "guest port session count";
        for (uint64_t q : gp.queue) if (!gsessions_.count(q) || !gsessions_.at(q).queued) return "guest port queue";
    }
    for (const auto& [name, port] : gnames_) if (!gports_.count(port) || gports_.at(port).name != name) return "guest port name";
    for (const auto& [tid, w] : server_waits_) {
        const KThread* t = config_.kthreads->find(tid);
        if (!t || t->state != KThreadState::Waiting || t->wait != KWaitKind::Synchronization) return "server wait without a waiting thread";
    }
    for (const auto& d : deferred_) {
        const KThread* t = config_.kthreads->find(d.thread);
        if (!t || t->state != KThreadState::Waiting || t->wait != KWaitKind::Ipc) return "deferred request without a waiting thread";
    }
    return {};
}

// ==== P6.0: kernel objects owned by HLE services ============================================


KObjectRef KernelIpc::create_service_shared_memory(uint64_t size) {
    if (!active_ || size == 0) return {};
    if (!config_.create_host_shared) return {};
    const uint64_t id = config_.create_host_shared(size);
    if (!id) return {};
    return KObjectRef{KObjectType::SharedMemory, id};
}

KObjectRef KernelIpc::create_service_event() {
    // a KEvent whose writable side the service keeps: one reference for the service
    return {KObjectType::ReadableEvent, config_.kthreads->create_host_event()};
}

void KernelIpc::signal_service_event(const KObjectRef& event) { config_.kthreads->signal_kernel_event(event.id); }

void KernelIpc::clear_service_event(const KObjectRef& event) { config_.kthreads->clear_kernel_event(event.id); }

void KernelIpc::release_service_event(const KObjectRef& event) { config_.kthreads->release_kernel_event(event.id); }

} // namespace lg::system
