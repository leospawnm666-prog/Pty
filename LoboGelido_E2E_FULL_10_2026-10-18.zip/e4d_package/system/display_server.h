#pragma once
#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

// Shared display model behind the HLE display stack (vi + dispdrv).
//
// SCOPE: on real hardware the display pipeline is nn::vi (window manager) driving
// nvnflinger, whose BufferQueue is the Android surfaceflinger producer/consumer
// protocol carried over Binder parcels. The Lobo IpcMessage transport is a
// simplified request/response channel, so this models the OBSERVABLE STATE that
// pipeline maintains: displays, layers, a per-layer triple-buffered BufferQueue
// (dequeue/queue/acquire/release) and a vsync counter. It carries no pixels and no
// protected content — it is the bookkeeping a compositor adapter would drive, so a
// guest (or homebrew) that opens a display, creates a layer and cycles buffers gets
// a coherent, deterministic response. Presentation of actual frames is done by the
// existing Vulkan presenter; this only tracks which buffer is ready to show.
//
// Thread-safe: the guest producer, the compositor/consumer and the vsync source all
// touch this concurrently, matching the concurrency contract of the JNI bridge.

namespace lg::system {

class DisplayServer {
public:
    enum class SlotState : uint32_t { Free = 0, Dequeued = 1, Queued = 2, Acquired = 3 };

    static constexpr uint32_t kDefaultBuffers = 3;   // triple buffering
    static constexpr uint32_t kMaxBuffers = 8;
    static constexpr uint32_t kWidth = 1920;         // docked default
    static constexpr uint32_t kHeight = 1080;

    // ---- Displays ----
    // Returns a non-zero display id for a known name ("Default"/"Internal"/"External"),
    // or 0 for an unknown name.
    uint64_t open_display(const std::string& name);
    bool close_display(uint64_t display_id);
    bool display_valid(uint64_t display_id) const;
    uint32_t display_count() const;
    // vsync tick published to a display; false if the display id is unknown.
    bool signal_vsync(uint64_t display_id);
    // Current vsync count; requires display_valid() to disambiguate the initial 0.
    uint64_t vsync_count(uint64_t display_id) const;

    // ---- Layers ----
    // Creates a layer on a valid display; returns a non-zero layer id or 0 on failure.
    uint64_t create_layer(uint64_t display_id);
    bool destroy_layer(uint64_t layer_id);
    bool layer_valid(uint64_t layer_id) const;
    bool set_scaling_mode(uint64_t layer_id, uint32_t mode);
    uint32_t scaling_mode(uint64_t layer_id) const;

    // ---- Per-layer BufferQueue ----
    uint32_t buffer_count(uint64_t layer_id) const;              // 0 if layer unknown
    bool set_buffer_count(uint64_t layer_id, uint32_t count);    // only when all slots free
    int32_t dequeue(uint64_t layer_id);                          // producer: free slot or -1
    bool queue(uint64_t layer_id, uint32_t slot);               // producer: submit filled slot
    bool cancel(uint64_t layer_id, uint32_t slot);              // producer: return without queueing
    int32_t acquire(uint64_t layer_id);                          // consumer: next queued slot or -1
    bool release(uint64_t layer_id, uint32_t slot);            // consumer: return slot, counts a frame
    uint64_t presented_frames(uint64_t layer_id) const;          // 0 if layer unknown

private:
    struct Display {
        std::string name;
        uint64_t vsync{0};
    };
    struct Layer {
        uint64_t display_id{0};
        uint32_t scaling{0};
        uint32_t buffers{kDefaultBuffers};
        std::vector<SlotState> slots{std::vector<SlotState>(kDefaultBuffers, SlotState::Free)};
        std::vector<uint32_t> queued;   // FIFO order of queued slot indices
        uint64_t presented{0};
    };

    mutable std::mutex mutex_;
    std::unordered_map<uint64_t, Display> displays_;
    std::unordered_map<uint64_t, Layer> layers_;
    uint64_t next_display_{1};
    uint64_t next_layer_{1};

    // Lock must be held by the caller.
    Layer* find_layer_locked(uint64_t layer_id);
    const Layer* find_layer_locked(uint64_t layer_id) const;
};

} // namespace lg::system
