// P6.0 (P6_0_DISENO.md §4): the IPC SVCs of guest-written servers, user message buffers,
// asynchronous requests and light IPC. Validation as kern_svc_ipc.cpp, kern_svc_light_ipc.cpp,
// kern_svc_session.cpp and kern_svc_port.cpp (mesosphere); the work is KernelIpc's.
#include "svc_dispatcher.h"

namespace lg::system {
namespace {
namespace r = kmem::result;
constexpr uint64_t kPage = kmem::PageSize;
uint32_t w(const cpu::CpuState& ctx, int i) noexcept { return static_cast<uint32_t>(ctx.x[i]); }
SvcOutcome done(cpu::CpuState& ctx, uint32_t rc) {
    ctx.x[0] = rc;
    return SvcOutcome::resume();
}
struct Kernel {
    KThread* self{};
    KernelIpc* ipc{};
    VmManager* vm{};
};
bool kernel(SvcDispatcher& d, const SvcCall& c, Kernel& k, SvcOutcome& fatal) {
    KernelThreads* kt = d.session().kthreads;
    k.ipc = d.session().ipc;
    k.vm = d.session().vm;
    if (!kt || !kt->active() || !k.ipc || !k.ipc->active() || !k.vm || !k.vm->active()) {
        fatal = SvcOutcome::fatal("IPC no disponible para imágenes sintéticas");
        return false;
    }
    k.self = kt->current();
    if (!k.self || k.self->id != c.thread) {
        fatal = SvcOutcome::fatal("estado interno de hilos inconsistente (SVC fuera del turno)");
        return false;
    }
    return true;
}
#define LG_IPC(d, c)                              \
    Kernel k;                                     \
    SvcOutcome fatal_;                            \
    if (!kernel(d, c, k, fatal_)) return fatal_

/** The checks of the *WithUserBuffer SVCs, then LockForIpcUserBuffer. */
uint32_t lock_user_buffer(VmManager& vm, uint64_t message, uint64_t size) {
    if (message & (kPage - 1)) return r::InvalidAddress;
    if (size == 0 || (size & (kPage - 1))) return r::InvalidSize;
    if (message + size <= message) return r::InvalidCurrentMemory;
    return vm.lock_memory(message, size, kmem::FlagCanIpcUserBuffer, kmem::FlagCanIpcUserBuffer, kmem::PermRW | kmem::PermX,
                          kmem::PermRW, kmem::All, 0, kmem::PermNone, kmem::AttrLocked, nullptr);
}
void unlock_user_buffer(VmManager& vm, uint64_t message, uint64_t size) {
    vm.unlock_memory(message, size, kmem::FlagCanIpcUserBuffer, kmem::FlagCanIpcUserBuffer, 0, 0, kmem::All, kmem::AttrLocked,
                     kmem::PermRW, kmem::AttrLocked, nullptr);
}
SvcOutcome after(VmManager& vm, cpu::CpuState& ctx, const KernelIpc::SendResult& res) {
    if (!res.fatal.empty()) return SvcOutcome::fatal(res.fatal);
    if (vm.broken()) return SvcOutcome::fatal("estado interno de memoria inconsistente (Mmu/AddressSpace)");
    ctx.x[0] = res.result;
    return res.blocked ? SvcOutcome::block() : SvcOutcome::resume();
}
} // namespace

SvcOutcome SvcHandlers::create_session(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    uint32_t server = 0, client = 0;
    const uint32_t rc = k.ipc->create_session(w(c.ctx, 2) != 0, c.ctx.x[3], server, client);
    c.ctx.x[1] = server;
    c.ctx.x[2] = client;
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::accept_session(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    uint32_t h = 0;
    const uint32_t rc = k.ipc->accept_session(w(c.ctx, 1), h);
    c.ctx.x[1] = h;
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::create_port(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    uint32_t server = 0, client = 0;
    const uint32_t rc = k.ipc->create_port(static_cast<int32_t>(w(c.ctx, 2)), w(c.ctx, 3) != 0, c.ctx.x[4], server, client);
    c.ctx.x[1] = server;
    c.ctx.x[2] = client;
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::manage_named_port(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    uint32_t h = 0;
    const uint32_t rc = k.ipc->manage_named_port(c.ctx.x[1], static_cast<int32_t>(w(c.ctx, 2)), h);
    c.ctx.x[1] = h;
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::connect_to_port(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    uint32_t h = 0;
    const uint32_t rc = k.ipc->connect_to_port(w(c.ctx, 1), h);
    c.ctx.x[1] = h;
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::send_sync_request_with_user_buffer(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    const uint64_t message = c.ctx.x[0], size = c.ctx.x[1];
    if (const uint32_t rc = lock_user_buffer(*k.vm, message, size); rc) return done(c.ctx, rc);
    const auto res = k.ipc->send_sync_request_user(*k.self, w(c.ctx, 2), message, size);
    // a guest server unlocks the buffer when it replies (KernelIpc::finish_request), a deferred
    // HLE request when it is retried; otherwise the svc does it now
    if (!res.blocked) unlock_user_buffer(*k.vm, message, size);
    return after(*k.vm, c.ctx, res);
}

SvcOutcome SvcHandlers::send_async_request_with_user_buffer(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    const uint64_t message = c.ctx.x[1], size = c.ctx.x[2];
    c.ctx.x[1] = 0;
    if (const uint32_t rc = lock_user_buffer(*k.vm, message, size); rc) return done(c.ctx, rc);
    uint32_t event = 0;
    const uint32_t rc = k.ipc->send_async_request(*k.self, message, size, w(c.ctx, 3), event);
    if (rc) unlock_user_buffer(*k.vm, message, size);   // ON_RESULT_FAILURE
    c.ctx.x[1] = event;
    return done(c.ctx, rc);
}

SvcOutcome SvcHandlers::reply_and_receive(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    int32_t index = -1;
    const auto res = k.ipc->reply_and_receive(*k.self, 0, 0, c.ctx.x[1], static_cast<int32_t>(w(c.ctx, 2)), w(c.ctx, 3),
                                              static_cast<int64_t>(c.ctx.x[4]), index);
    c.ctx.x[1] = static_cast<uint32_t>(index);
    return after(*k.vm, c.ctx, res);
}

SvcOutcome SvcHandlers::reply_and_receive_with_user_buffer(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    const uint64_t message = c.ctx.x[1], size = c.ctx.x[2];
    if (const uint32_t rc = lock_user_buffer(*k.vm, message, size); rc) {
        c.ctx.x[1] = static_cast<uint32_t>(-1);
        return done(c.ctx, rc);
    }
    int32_t index = -1;
    const auto res = k.ipc->reply_and_receive(*k.self, message, size, c.ctx.x[3], static_cast<int32_t>(w(c.ctx, 4)),
                                              w(c.ctx, 5), static_cast<int64_t>(c.ctx.x[6]), index);
    if (!res.blocked) unlock_user_buffer(*k.vm, message, size);   // blocked: KernelIpc::on_wait_ended
    c.ctx.x[1] = static_cast<uint32_t>(index);
    return after(*k.vm, c.ctx, res);
}

SvcOutcome SvcHandlers::send_sync_request_light(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    return after(*k.vm, c.ctx, k.ipc->send_sync_request_light(*k.self, c.ctx, w(c.ctx, 0)));
}

SvcOutcome SvcHandlers::reply_and_receive_light(SvcDispatcher& d, SvcCall& c) {
    LG_IPC(d, c);
    return after(*k.vm, c.ctx, k.ipc->reply_and_receive_light(*k.self, c.ctx, w(c.ctx, 0)));
}

#undef LG_IPC

} // namespace lg::system
