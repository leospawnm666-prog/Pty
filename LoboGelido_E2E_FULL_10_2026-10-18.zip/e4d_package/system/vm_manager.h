#pragma once
// P3.2: the process memory manager (P3_2_DISENO.md §2.2).
//
// Three layers, one authority:
//  1. state blocks {va, size, KMemoryState, user permission, attribute, disable-merge
//     flags}, sorted and covering [space_begin, space_end) with no gaps. QueryMemory answers
//     from here. Blocks are updated and merged exactly like Horizon's KMemoryBlockManager:
//     an update sets its "disable merge left" flags (Normal: heap head, MapMemory
//     destination, seeded segment; Locked: MapMemory source) only on the block at the start
//     of the range, clears its clear-mask on every updated block, skips blocks that already
//     have the new properties, and two neighbours merge iff their properties are equal and
//     the right one has no disable-merge-left flag (KMemoryBlock::CanMergeWith / Split);
//  2. physical backing: VA -> PA runs, kept even while the permission is None (the source
//     of a MapMemory, SetMemoryPermission(None));
//  3. the Mmu, DERIVED from 1 + 2 (mapped iff permission != None). After seeding, only this
//     class changes the Mmu, always as unmap + map of the affected range, so every engine
//     sees the change through the Mmu generation and the JIT's observer.
//
// Validation mirrors Atmosphère mesosphere (svc layer + KPageTableBase): same checks, same
// order, same Result codes. Every operation is all-or-nothing.
// Not internally synchronised: the guest-execution thread, under the coordinator lock.
#include <cstdint>
#include <map>
#include <optional>
#include <vector>

#include "arena_allocator.h"
#include "memory_state.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"

namespace lg::system {

struct VmConfig {
    uint64_t space_begin{}, space_end{};      // the process address space (Aslr region)
    uint64_t heap_base{}, heap_size{};        // heap region (VA)
    uint64_t alias_base{}, alias_size{};      // alias region (VA)
    uint64_t stack_base{}, stack_size{};      // stack region (VA): MapMemory destinations
    uint64_t arena_free_base{}, arena_free_size{};   // PA left for the ArenaAllocator
    uint64_t system_resource_size{};          // P6.0: NPDM system resource (0: MapPhysicalMemory refused)
    uint64_t total_memory{};                  // GetInfo(TotalMemorySize), D-P3.2-1
    uint64_t static_used{};                   // arena bytes the process build already took
};

struct VmBlock {
    uint64_t va{}, size{};
    uint32_t state{}, perm{}, attr{};
    bool no_merge_left{};       // head_flags != 0
    uint8_t head_flags{};       // KMemoryBlockDisableMergeAttribute (left side): Normal 1, Locked 8
};

/** KMemoryBlockDisableMergeAttribute (the "left" flags Lobo uses). */
namespace vm_merge {
constexpr uint8_t None = 0;
constexpr uint8_t Normal = 1u << 0;
constexpr uint8_t Locked = 1u << 3;
} // namespace vm_merge

class VmManager {
public:
    VmManager(memory::AddressSpace& memory, memory::Mmu& mmu) noexcept : memory_(memory), mmu_(mmu) {}

    /** Inactive (synthetic images, between sessions). Does not touch the Mmu. */
    void reset() noexcept;
    /** Starts a process: the whole space Free, the allocator over the free arena. */
    bool begin(const VmConfig& config);
    bool active() const noexcept { return active_; }
    /** Registers a mapping build_*_process already put in the Mmu: [va, va + size) must be
     *  Free here and mapped in the Mmu with one contiguous PA. The Mmu is not touched. */
    bool seed(uint64_t va, uint64_t size, uint32_t state, uint32_t perm);

    // ---- The SVCs (validation + effect; Result code, 0 = success) ------------------------
    uint32_t set_heap_size(uint64_t size, uint64_t& out_address);
    uint32_t set_memory_permission(uint64_t address, uint64_t size, uint32_t perm);
    uint32_t set_memory_attribute(uint64_t address, uint64_t size, uint32_t mask, uint32_t attr);
    uint32_t map_memory(uint64_t dst, uint64_t src, uint64_t size);
    uint32_t unmap_memory(uint64_t dst, uint64_t src, uint64_t size);
    /** P3.3: maps one 4 KiB ThreadLocal RW page at `va` (Free, inside the space) on a fresh,
     *  zero granule of the arena. The granule is kept for the whole session. */
    bool map_thread_local_page(uint64_t va);
    /** P3.4: may [address, address + size) be an IPC A/B/W buffer of the client?
     *  KPageTableBase::SetupForIpcClient: every block needs the state flag of `mode`
     *  (0 CanUseIpc, 1 CanUseNonSecureIpc, 3 CanUseNonDeviceIpc), the permission (R; RW when
     *  `write`) and no attribute outside the ignored ones. InvalidCombination for mode 2,
     *  InvalidCurrentMemory otherwise; size 0 always succeeds. */
    uint32_t check_ipc_buffer(uint64_t address, uint64_t size, uint32_t mode, bool write) const;
    // ---- P6.0 (P6_DISENO.md §3.1): page groups of the memory objects ----------------------
    /** Physical pages of a kernel object: `runs` cover the object byte for byte (page
     *  multiples); `owned` are the arena allocations behind them (64 KiB granules). */
    struct PageGroup {
        std::vector<PhysicalRun> runs;
        std::vector<PhysicalRun> owned;
        uint64_t size() const noexcept { uint64_t n = 0; for (const auto& r : runs) n += r.size; return n; }
    };
    /** `size` (page multiple) zero-filled bytes from the arena; nullopt if it is exhausted. */
    std::optional<PageGroup> allocate_group(uint64_t size);
    /** Returns the owned granules of a group (scrubbed). */
    void free_group(PageGroup& group);
    /** KPageTableBase::CanContain(address, size, state) for the states of the memory objects. */
    bool can_contain(uint64_t address, uint64_t size, uint32_t state) const noexcept;
    bool in_alias_region(uint64_t address, uint64_t size) const noexcept;
    /** MapPageGroup: the range must be Free; it becomes `state` with `perm` over the group. */
    uint32_t map_page_group(uint64_t address, uint64_t size, const PageGroup& group, uint32_t state, uint32_t perm);
    /** UnmapPageGroup: the range must be `state` and backed by exactly the group's pages. */
    uint32_t unmap_page_group(uint64_t address, uint64_t size, const PageGroup& group, uint32_t state);
    /** LockMemoryAndOpen / UnlockMemory (transfer and code memory). new_perm kNoPerm keeps it. */
    static constexpr uint32_t kKeepPerm = 0xFFFFFFFFu;
    uint32_t lock_memory(uint64_t address, uint64_t size, uint32_t state_mask, uint32_t state, uint32_t perm_mask,
                         uint32_t perm, uint32_t attr_mask, uint32_t attr, uint32_t new_perm, uint32_t lock_attr,
                         PageGroup* out);
    uint32_t unlock_memory(uint64_t address, uint64_t size, uint32_t state_mask, uint32_t state, uint32_t perm_mask,
                           uint32_t perm, uint32_t attr_mask, uint32_t attr, uint32_t new_perm, uint32_t lock_attr,
                           const PageGroup* group);
    /** MapPhysicalMemory / UnmapPhysicalMemory in the alias region (KPageTableBase). */
    uint32_t map_physical_memory(uint64_t address, uint64_t size);
    uint32_t unmap_physical_memory(uint64_t address, uint64_t size);
    uint64_t physical_memory_mapped() const noexcept { return physical_mapped_; }
    /** The state/perm/attr of the block at `address` (tests, process memory SVCs). */
    std::optional<VmBlock> block_at(uint64_t address) const;
    /** SetProcessMemoryPermission (KPageTableBase::SetProcessMemoryPermission): code states. */
    uint32_t set_process_memory_permission(uint64_t address, uint64_t size, uint32_t perm);
    /** MapProcessCodeMemory / UnmapProcessCodeMemory on the own process (loaders: ro, hbloader). */
    uint32_t map_process_code_memory(uint64_t dst, uint64_t src, uint64_t size);
    uint32_t unmap_process_code_memory(uint64_t dst, uint64_t src, uint64_t size);
    // ---- P6.0: process memory SVCs on the own process, insecure memory, physical queries ----
    /** KPageTableBase::CheckMemoryState over [a, a + s) (InvalidCurrentMemory if outside). */
    uint32_t check_state(uint64_t a, uint64_t s, uint32_t state_mask, uint32_t state, uint32_t perm_mask, uint32_t perm,
                         uint32_t attr_mask, uint32_t attr) const;
    /** KPageTableBase::CheckMemoryStateContiguous: every block on its own against the masks. */
    uint32_t check_each(uint64_t a, uint64_t s, uint32_t state_mask, uint32_t state, uint32_t perm_mask, uint32_t perm,
                        uint32_t attr_mask, uint32_t attr) const;
    /** MapProcessMemory / UnmapProcessMemory with the process as its own source. */
    uint32_t map_process_memory(uint64_t dst, uint64_t src, uint64_t size);
    uint32_t unmap_process_memory(uint64_t dst, uint64_t src, uint64_t size);
    /** MapInsecurePhysicalMemory / UnmapInsecurePhysicalMemory (state Insecure, RW). */
    uint32_t map_insecure_memory(uint64_t address, uint64_t size);
    uint32_t unmap_insecure_memory(uint64_t address, uint64_t size);
    uint64_t insecure_memory_mapped() const noexcept { return insecure_mapped_; }
    /** svc::PhysicalMemoryInfo. */
    struct PhysicalInfo { uint64_t physical_address, virtual_address, size; };
    /** The emulated DRAM's physical base (the Tegra X1's): guest physical = arena PA + this. */
    static constexpr uint64_t kDramBase = 0x80000000ull;
    uint32_t query_physical_address(uint64_t address, PhysicalInfo& out) const;
    // ---- P6.0: guest IPC (KPageTableBase::SetupForIpc*, CleanupForIpc*, user buffers) ------
    /** The kernel's linear-map copies: through the backing, whatever the user permission.
     *  false (nothing copied) if a page of the range has no backing. */
    bool read_linear(uint64_t va, void* dst, uint64_t size) const;
    bool write_linear(uint64_t va, const void* src, uint64_t size);
    /** SetupForIpcClient: the client's buffer is checked (state flag of `dst_state`, R or RW,
     *  attributes) and its fully covered pages are IPC-locked (user RW buffers lose user
     *  access, R buffers lose write; attribute IpcLocked; lock count +1). */
    uint32_t ipc_lock_client(uint64_t address, uint64_t size, uint32_t dst_state, bool write);
    /** CleanupForIpcClient: lock count -1; at 0 the original permission comes back. */
    uint32_t ipc_unlock_client(uint64_t address, uint64_t size, uint32_t dst_state);
    /** SetupForIpcServer: maps the buffer in the alias region (state `dst_state`, R or RW):
     *  whole pages share the client's, partial head/tail pages are new pages holding a copy
     *  (`send`) or zeros. `out` = the buffer's address in the mapping. */
    uint32_t ipc_map_server(uint64_t src, uint64_t size, uint32_t dst_state, bool write, bool send, uint64_t& out);
    /** CleanupForIpcServer: unmaps it (the partial pages are freed). */
    uint32_t ipc_unmap_server(uint64_t address, uint64_t size, uint32_t dst_state);
    /** Sum of the IPC lock counts of the blocks (invariants/tests). */
    uint64_t ipc_locked_blocks() const noexcept;
    /** The block containing `address`; outside the space, Horizon's fake block
     *  [space_end, 2^64) Inaccessible (also for addresses BELOW the space, as the kernel). */
    kmem::MemoryInfo query(uint64_t address) const;

    const VmConfig& config() const noexcept { return config_; }
    uint64_t heap_size() const noexcept { return heap_used_; }
    uint64_t used_memory() const noexcept { return config_.static_used + allocator_.used(); }
    uint64_t total_memory() const noexcept { return config_.total_memory; }
    size_t block_count() const noexcept { return blocks_.size(); }
    std::vector<VmBlock> blocks() const;
    /** Backing PA of `va` (tests), whatever the permission. */
    std::optional<uint64_t> physical(uint64_t va) const;
    /** Bytes zeroed and returned to the OS when the heap shrank (diagnostics/tests). */
    uint64_t scrubbed_bytes() const noexcept { return scrubbed_; }
    /** An internal Mmu/AddressSpace operation failed (must never happen): the caller treats
     *  the process as broken. */
    bool broken() const noexcept { return broken_; }
    const ArenaAllocator& allocator() const noexcept { return allocator_; }

private:
    struct Block {
        uint64_t size; uint32_t state, perm, attr; uint8_t head;
        uint16_t ipc{};          // P6.0: KMemoryBlock::m_ipc_lock_count (guest IPC map-alias buffers)
        uint32_t orig_perm{};    // P6.0: m_original_permission while ipc > 0
    };
    struct Backing { uint64_t size; uint64_t pa; bool owned; };
    struct Run { uint64_t va, size, pa; bool owned; };

    bool contains(uint64_t address, uint64_t size) const noexcept;
    bool can_contain_stack(uint64_t address, uint64_t size) const noexcept;
    void split_block(uint64_t address);
    void split_backing(uint64_t address);
    static bool can_merge(const Block& left, const Block& right) noexcept;
    void coalesce(uint64_t begin, uint64_t end);
    /** KMemoryBlockManager::Update. */
    void update(uint64_t begin, uint64_t end, uint32_t state, uint32_t perm, uint32_t attr, uint8_t set_head,
                uint8_t clear_head);
    /** KMemoryBlockManager::UpdateAttribute. */
    void update_attribute(uint64_t begin, uint64_t end, uint32_t mask, uint32_t attr);
    uint32_t check(uint64_t begin, uint64_t end, uint32_t state_mask, uint32_t state, uint32_t perm_mask, uint32_t perm,
                   uint32_t attr_mask, uint32_t attr, uint32_t ignore_attr = kmem::AttrIpcLocked | kmem::AttrDeviceShared,
                   uint32_t* out_state = nullptr, uint32_t* out_perm = nullptr, uint32_t* out_attr = nullptr) const;
    std::vector<Run> runs(uint64_t begin, uint64_t end) const;
    std::vector<Run> remove_backing(uint64_t begin, uint64_t end);
    void sync_mmu(uint64_t begin, uint64_t end);
    void scrub(uint64_t pa, uint64_t size);
    /** P6.0: an owned granule that left its mapping: freed now, or kept in physical_owned_
     *  while another mapping still uses it; collect_owned() frees the ones no longer used. */
    uint64_t find_free_area(uint64_t region, uint64_t region_size, uint64_t size, uint64_t align, uint64_t offset,
                            uint64_t guard) const;
    bool referenced(const PhysicalRun& run) const noexcept;
    void release_owned(const PhysicalRun& run);
    void collect_owned();

    memory::AddressSpace& memory_;
    memory::Mmu& mmu_;
    VmConfig config_{};
    bool active_{false};
    bool broken_{false};
    std::map<uint64_t, Block> blocks_;
    std::map<uint64_t, Backing> backing_;
    ArenaAllocator allocator_;
    uint64_t heap_used_{};
    uint64_t scrubbed_{};
    uint64_t physical_mapped_{};   // P6.0: MapPhysicalMemory bytes
    std::vector<PhysicalRun> physical_owned_;   // P6.0: the granules behind them (and insecure / kept ones)
    uint64_t insecure_mapped_{};                 // P6.0: MapInsecurePhysicalMemory bytes
};

} // namespace lg::system
