#include "kobjects.h"

#include <algorithm>
#include <cstring>
#include <string>

namespace lg::system {
namespace {
using namespace kmem;
namespace r = kmem::result;
constexpr bool aligned(uint64_t v) noexcept { return (v & (PageSize - 1)) == 0; }
constexpr uint32_t PermRX_ = PermR | PermX;
} // namespace

void KernelObjects::reset() noexcept {
    // The pages of the objects belong to the session's arena, which VmManager resets with
    // the process; the bookkeeping just goes.
    active_ = false;
    config_ = {};
    shared_.clear();
    transfer_.clear();
    code_.clear();
    limits_.clear();
    process_limit_ = 0;
    next_id_ = 1;
}

bool KernelObjects::begin(const KernelObjectsConfig& config) {
    reset();
    if (!config.handles || !config.vm || !config.memory) return false;
    config_ = config;
    Limit l;
    l.limit = config.limits;
    l.refs = 1;   // the process's own reference
    process_limit_ = next_id_++;
    limits_.emplace(process_limit_, l);
    active_ = true;
    return true;
}

uint32_t KernelObjects::add_object_handle(KObjectType type, uint64_t id, uint32_t& out) {
    const auto h = config_.handles->add({type, id});
    if (!h) return 0xD201;   // OutOfHandles (105)
    out = *h;
    return r::Success;
}

template <class T> T* KernelObjects::find(std::map<uint64_t, T>& m, uint32_t handle, KObjectType type) {
    const KObjectRef* o = config_.handles->get(handle);
    if (!o || o->type != type) return nullptr;
    auto it = m.find(o->id);
    return it == m.end() ? nullptr : &it->second;
}

std::optional<uint32_t> KernelObjects::add_handle(KObjectType type, uint64_t id) {
    uint32_t* refs = nullptr;
    if (type == KObjectType::SharedMemory) { auto it = shared_.find(id); if (it != shared_.end()) refs = &it->second.refs; }
    else if (type == KObjectType::TransferMemory) { auto it = transfer_.find(id); if (it != transfer_.end()) refs = &it->second.refs; }
    else if (type == KObjectType::CodeMemory) { auto it = code_.find(id); if (it != code_.end()) refs = &it->second.refs; }
    else if (type == KObjectType::ResourceLimit) { auto it = limits_.find(id); if (it != limits_.end()) refs = &it->second.refs; }
    if (!refs) return std::nullopt;
    const auto h = config_.handles->add({type, id});
    if (h) ++*refs;
    return h;
}

bool KernelObjects::add_ref(const KObjectRef& o) {
    if (!active_) return false;
    uint32_t* refs = nullptr;
    if (o.type == KObjectType::SharedMemory) { auto it = shared_.find(o.id); if (it != shared_.end()) refs = &it->second.refs; }
    else if (o.type == KObjectType::TransferMemory) { auto it = transfer_.find(o.id); if (it != transfer_.end()) refs = &it->second.refs; }
    else if (o.type == KObjectType::CodeMemory) { auto it = code_.find(o.id); if (it != code_.end()) refs = &it->second.refs; }
    else if (o.type == KObjectType::ResourceLimit) { auto it = limits_.find(o.id); if (it != limits_.end()) refs = &it->second.refs; }
    if (!refs) return false;
    ++*refs;
    return true;
}

// ---- resource limit -----------------------------------------------------------------------

bool KernelObjects::reserve(LimitableResource res, int64_t amount) {
    auto it = limits_.find(process_limit_);
    if (it == limits_.end()) return false;
    const auto i = static_cast<size_t>(res);
    Limit& l = it->second;
    const int64_t now = res == LimitableResource::TransferMemoryCountMax || !config_.current_count ? l.current[i]
                                                                                                    : config_.current_count(res);
    if (now + amount > l.limit[i]) return false;
    l.current[i] = now + amount;
    l.peak[i] = std::max(l.peak[i], l.current[i]);
    return true;
}

void KernelObjects::release(LimitableResource res, int64_t amount) {
    auto it = limits_.find(process_limit_);
    if (it == limits_.end()) return;
    const auto i = static_cast<size_t>(res);
    it->second.current[i] = std::max<int64_t>(0, it->second.current[i] - amount);
}

uint32_t KernelObjects::create_resource_limit(uint32_t& out) {
    out = 0;
    const uint64_t id = next_id_++;
    Limit l;
    limits_.emplace(id, l);
    const uint32_t rc = add_object_handle(KObjectType::ResourceLimit, id, out);
    if (rc) { limits_.erase(id); return rc; }
    limits_[id].refs = 1;
    return r::Success;
}

uint32_t KernelObjects::open_process_resource_limit(uint32_t& out) {
    out = 0;
    const auto h = add_handle(KObjectType::ResourceLimit, process_limit_);
    if (!h) return 0xD201;
    out = *h;
    return r::Success;
}

uint32_t KernelObjects::get_resource_limit_value(uint32_t handle, uint32_t which, int kind, int64_t& out) {
    out = 0;
    // kern_svc_resource_limit.cpp: the enum first, then the handle
    if (which >= static_cast<uint32_t>(LimitableResource::Count)) return r::InvalidEnumValue;
    Limit* l = find(limits_, handle, KObjectType::ResourceLimit);
    if (!l) return r::InvalidHandle;
    const bool is_process = config_.handles->get(handle)->id == process_limit_;
    const auto res = static_cast<LimitableResource>(which);
    int64_t current = l->current[which];
    if (is_process && config_.current_count && res != LimitableResource::TransferMemoryCountMax) {
        current = config_.current_count(res);
        l->peak[which] = std::max(l->peak[which], current);
    }
    out = kind == 0 ? l->limit[which] : kind == 1 ? current : std::max(l->peak[which], current);
    return r::Success;
}

int64_t KernelObjects::process_limit_free(LimitableResource res) const {
    const auto it = limits_.find(process_limit_);
    if (it == limits_.end()) return 0;
    const auto which = static_cast<size_t>(res);
    int64_t current = it->second.current[which];
    if (config_.current_count && res != LimitableResource::TransferMemoryCountMax) current = config_.current_count(res);
    return it->second.limit[which] - current;
}

uint32_t KernelObjects::set_resource_limit_value(uint32_t handle, uint32_t which, int64_t value) {
    if (which >= static_cast<uint32_t>(LimitableResource::Count)) return r::InvalidEnumValue;
    Limit* l = find(limits_, handle, KObjectType::ResourceLimit);
    if (!l) return r::InvalidHandle;
    // KResourceLimit::SetLimitValue: never below what is in use
    int64_t current = l->current[which];
    if (config_.handles->get(handle)->id == process_limit_ && config_.current_count &&
        static_cast<LimitableResource>(which) != LimitableResource::TransferMemoryCountMax)
        current = config_.current_count(static_cast<LimitableResource>(which));
    if (current > value) return r::InvalidState;
    l->limit[which] = value;
    return r::Success;
}

// ---- shared memory ------------------------------------------------------------------------

uint32_t KernelObjects::create_shared_memory(uint64_t size, uint32_t owner_perm, uint32_t remote_perm, uint32_t& out) {
    out = 0;
    // kern_svc_shared_memory.cpp: size, then the permissions
    if (size == 0 || size >= MainMemorySizeMax || !aligned(size)) return r::InvalidSize;
    const auto valid = [](uint32_t p) { return p == PermR || p == PermRW; };
    if (!valid(owner_perm)) return r::InvalidNewMemoryPermission;
    if (!valid(remote_perm) && remote_perm != PermDontCare) return r::InvalidNewMemoryPermission;
    if (!reserve(LimitableResource::PhysicalMemoryMax, static_cast<int64_t>(size))) return r::LimitReached;
    auto g = config_.vm->allocate_group(size);
    if (!g) { release(LimitableResource::PhysicalMemoryMax, static_cast<int64_t>(size)); return r::OutOfMemory; }
    const uint64_t id = next_id_++;
    Shared sh;
    sh.size = size;
    sh.pages = std::move(*g);
    sh.owner_perm = owner_perm;
    sh.remote_perm = remote_perm;
    shared_.emplace(id, std::move(sh));
    const uint32_t rc = add_object_handle(KObjectType::SharedMemory, id, out);
    if (rc) { destroy_shared_if_unused(id); return rc; }
    shared_[id].refs = 1;
    return r::Success;
}

uint64_t KernelObjects::create_host_shared_memory(uint64_t size, uint32_t remote_perm) {
    if (!active_ || size == 0 || !aligned(size)) return 0;
    auto g = config_.vm->allocate_group(size);
    if (!g) return 0;
    const uint64_t id = next_id_++;
    Shared sh;
    sh.size = size;
    sh.pages = std::move(*g);
    sh.owner_perm = PermRW;
    sh.remote_perm = remote_perm;
    sh.host_owned = true;
    sh.refs = 1;   // the service's reference (for the session)
    shared_.emplace(id, std::move(sh));
    return id;
}

uint32_t KernelObjects::map_shared_memory(uint32_t handle, uint64_t a, uint64_t s, uint32_t perm) {
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    if (perm != PermR && perm != PermRW) return r::InvalidNewMemoryPermission;
    Shared* sh = find(shared_, handle, KObjectType::SharedMemory);
    if (!sh) return r::InvalidHandle;
    if (!config_.vm->can_contain(a, s, kmem::Shared)) return r::InvalidMemoryRegion;
    // KSharedMemory::Map: the size of the object; the permission of the side (the process
    // created it: owner; a system service did: remote)
    if (sh->pages.size() != s) return r::InvalidSize;
    const uint32_t test = sh->host_owned ? sh->remote_perm : sh->owner_perm;
    if (test != PermDontCare && perm != test) return r::InvalidNewMemoryPermission;
    if (const uint32_t rc = config_.vm->map_page_group(a, s, sh->pages, kmem::Shared, perm); rc) return rc;
    sh->mappings.push_back({a, s});
    ++sh->refs;   // KProcess::AddSharedMemory
    return r::Success;
}

uint32_t KernelObjects::unmap_shared_memory(uint32_t handle, uint64_t a, uint64_t s) {
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    const KObjectRef* o = config_.handles->get(handle);
    Shared* sh = find(shared_, handle, KObjectType::SharedMemory);
    if (!sh) return r::InvalidHandle;
    if (!config_.vm->can_contain(a, s, kmem::Shared)) return r::InvalidMemoryRegion;
    if (sh->pages.size() != s) return r::InvalidSize;
    if (const uint32_t rc = config_.vm->unmap_page_group(a, s, sh->pages, kmem::Shared); rc) return rc;
    auto m = std::find(sh->mappings.begin(), sh->mappings.end(), std::make_pair(a, s));
    if (m != sh->mappings.end()) {
        sh->mappings.erase(m);
        if (sh->refs) --sh->refs;
    }
    destroy_shared_if_unused(o->id);
    return r::Success;
}

void KernelObjects::destroy_shared_if_unused(uint64_t id) {
    auto it = shared_.find(id);
    if (it == shared_.end() || it->second.refs || !it->second.mappings.empty()) return;
    config_.vm->free_group(it->second.pages);
    if (!it->second.host_owned) release(LimitableResource::PhysicalMemoryMax, static_cast<int64_t>(it->second.size));
    shared_.erase(it);
}

bool KernelObjects::host_rw(memory::AddressSpace& mem, const VmManager::PageGroup& g, uint64_t offset, void* data,
                            uint64_t size, bool write) {
    auto* p = static_cast<uint8_t*>(data);
    uint64_t base = 0;
    for (const auto& run : g.runs) {
        if (size == 0) break;
        if (offset < base + run.size) {
            const uint64_t in = offset - base;
            const uint64_t n = std::min(size, run.size - in);
            for (uint64_t k = 0; k < n; ++k) {   // byte by byte across host pages (small structures)
                if (write) mem.write8(run.pa + in + k, p[k]);
                else {
                    const auto v = mem.read8(run.pa + in + k);
                    if (!v) return false;
                    p[k] = *v;
                }
            }
            p += n;
            offset += n;
            size -= n;
        }
        base += run.size;
    }
    return size == 0;
}

bool KernelObjects::shared_write(uint64_t id, uint64_t offset, const void* data, uint64_t size) {
    auto it = shared_.find(id);
    if (it == shared_.end() || offset + size < offset || offset + size > it->second.size) return false;
    return host_rw(*config_.memory, it->second.pages, offset, const_cast<void*>(data), size, true);
}

bool KernelObjects::shared_read(uint64_t id, uint64_t offset, void* data, uint64_t size) const {
    auto it = shared_.find(id);
    if (it == shared_.end() || offset + size < offset || offset + size > it->second.size) return false;
    return host_rw(*config_.memory, it->second.pages, offset, data, size, false);
}

uint64_t KernelObjects::shared_size(uint64_t id) const {
    auto it = shared_.find(id);
    return it == shared_.end() ? 0 : it->second.size;
}

// ---- transfer memory ----------------------------------------------------------------------

uint32_t KernelObjects::create_transfer_memory(uint64_t a, uint64_t s, uint32_t perm, uint32_t& out) {
    out = 0;
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    // IsValidTransferMemoryPermission: None, Read, ReadWrite
    if (perm != PermNone && perm != PermR && perm != PermRW) return r::InvalidNewMemoryPermission;
    if (!reserve(LimitableResource::TransferMemoryCountMax, 1)) return r::LimitReached;
    const uint64_t id = next_id_++;
    Transfer t;
    t.address = a;
    t.size = s;
    t.owner_perm = perm;
    // LockForTransferMemory: CanTransfer, user RW, no attribute; the owner keeps `perm` (None:
    // LockMemoryAndOpen keeps the old permission), Locked
    const uint32_t rc = config_.vm->lock_memory(a, s, FlagCanTransfer, FlagCanTransfer, All, PermRW, All, 0,
                                                perm == PermNone ? VmManager::kKeepPerm : perm, AttrLocked, &t.pages);
    if (rc) { release(LimitableResource::TransferMemoryCountMax, 1); return rc; }
    transfer_.emplace(id, std::move(t));
    const uint32_t hr = add_object_handle(KObjectType::TransferMemory, id, out);
    if (hr) { destroy_transfer(id); return hr; }
    transfer_[id].refs = 1;
    return r::Success;
}

uint32_t KernelObjects::map_transfer_memory(uint32_t handle, uint64_t a, uint64_t s, uint32_t perm) {
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    if (perm != PermNone && perm != PermR && perm != PermRW) return r::InvalidState;
    Transfer* t = find(transfer_, handle, KObjectType::TransferMemory);
    if (!t) return r::InvalidHandle;
    if (!config_.vm->can_contain(a, s, Transfered)) return r::InvalidMemoryRegion;
    if (t->pages.size() != s) return r::InvalidSize;
    if (t->owner_perm != perm) return r::InvalidState;
    if (t->mapped) return r::InvalidState;
    const uint32_t state = t->owner_perm == PermNone ? Transfered : SharedTransfered;
    if (const uint32_t rc = config_.vm->map_page_group(a, s, t->pages, state, PermRW); rc) return rc;
    t->mapped = true;
    t->mapped_at = a;
    return r::Success;
}

uint32_t KernelObjects::unmap_transfer_memory(uint32_t handle, uint64_t a, uint64_t s) {
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    Transfer* t = find(transfer_, handle, KObjectType::TransferMemory);
    if (!t) return r::InvalidHandle;
    if (!config_.vm->can_contain(a, s, Transfered)) return r::InvalidMemoryRegion;
    if (t->pages.size() != s) return r::InvalidSize;
    const uint32_t state = t->owner_perm == PermNone ? Transfered : SharedTransfered;
    if (const uint32_t rc = config_.vm->unmap_page_group(a, s, t->pages, state); rc) return rc;
    t->mapped = false;
    return r::Success;
}

void KernelObjects::destroy_transfer(uint64_t id) {
    auto it = transfer_.find(id);
    if (it == transfer_.end()) return;
    Transfer& t = it->second;
    if (t.mapped) config_.vm->unmap_page_group(t.mapped_at, t.size, t.pages, t.owner_perm == PermNone ? Transfered : SharedTransfered);
    // KTransferMemory::Finalize: UnlockForTransferMemory (the owner gets RW back)
    config_.vm->unlock_memory(t.address, t.size, FlagCanTransfer, FlagCanTransfer, 0, 0, All, AttrLocked, PermRW, AttrLocked, &t.pages);
    release(LimitableResource::TransferMemoryCountMax, 1);
    transfer_.erase(it);
}

std::optional<KernelObjects::TransferInfo> KernelObjects::transfer_from_handle(uint32_t handle) const {
    const KObjectRef* o = config_.handles ? config_.handles->get(handle) : nullptr;
    if (!o || o->type != KObjectType::TransferMemory) return std::nullopt;
    auto it = transfer_.find(o->id);
    if (it == transfer_.end()) return std::nullopt;
    return TransferInfo{o->id, it->second.address, it->second.size, it->second.owner_perm};
}

bool KernelObjects::transfer_read(uint64_t id, uint64_t offset, void* data, uint64_t size) const {
    auto it = transfer_.find(id);
    if (it == transfer_.end() || offset + size < offset || offset + size > it->second.size) return false;
    return host_rw(*config_.memory, it->second.pages, offset, data, size, false);
}

bool KernelObjects::transfer_write(uint64_t id, uint64_t offset, const void* data, uint64_t size) {
    auto it = transfer_.find(id);
    if (it == transfer_.end() || offset + size < offset || offset + size > it->second.size) return false;
    return host_rw(*config_.memory, it->second.pages, offset, const_cast<void*>(data), size, true);
}

bool KernelObjects::retain_transfer(uint64_t id) {
    auto it = transfer_.find(id);
    if (it == transfer_.end()) return false;
    ++it->second.refs;
    return true;
}

void KernelObjects::release_transfer(uint64_t id) {
    auto it = transfer_.find(id);
    if (it == transfer_.end()) return;
    if (it->second.refs) --it->second.refs;
    if (it->second.refs == 0) destroy_transfer(id);
}

// ---- code memory --------------------------------------------------------------------------

uint32_t KernelObjects::create_code_memory(uint64_t a, uint64_t s, uint32_t& out) {
    out = 0;
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    const uint64_t id = next_id_++;
    Code c;
    c.address = a;
    c.size = s;
    // LockForCodeMemory: CanCodeMemory, user RW, no attribute; the owner loses access (kernel
    // RW, not mapped for the user) and the range is Locked
    if (const uint32_t rc = config_.vm->lock_memory(a, s, FlagCanCodeMemory, FlagCanCodeMemory, All, PermRW, All, 0, PermNone,
                                                    AttrLocked, &c.pages); rc)
        return rc;
    // KCodeMemory::Initialize fills the pages with 0xFF
    std::vector<uint8_t> ff(4096, 0xFF);
    for (uint64_t off = 0; off < s; off += ff.size())
        host_rw(*config_.memory, c.pages, off, ff.data(), std::min<uint64_t>(ff.size(), s - off), true);
    code_.emplace(id, std::move(c));
    const uint32_t hr = add_object_handle(KObjectType::CodeMemory, id, out);
    if (hr) { code_[id].refs = 0; destroy_code_if_unused(id); return hr; }
    code_[id].refs = 1;
    return r::Success;
}

uint32_t KernelObjects::control_code_memory(uint32_t handle, uint32_t op, uint64_t a, uint64_t s, uint32_t perm) {
    if (!aligned(a)) return r::InvalidAddress;
    if (!aligned(s) || s == 0) return r::InvalidSize;
    if (a + s <= a) return r::InvalidCurrentMemory;
    Code* c = find(code_, handle, KObjectType::CodeMemory);
    if (!c) return r::InvalidHandle;
    // svc::CodeMemoryOperation: 0 Map, 1 MapToOwner, 2 Unmap, 3 UnmapFromOwner (Atmosphère
    // allows them on one's own process: homebrew JITs)
    switch (op) {
        case 0:
            if (!config_.vm->can_contain(a, s, CodeOut)) return r::InvalidMemoryRegion;
            if (perm != PermRW) return r::InvalidNewMemoryPermission;
            if (c->pages.size() != s) return r::InvalidSize;
            if (c->slave_mapped) return r::InvalidState;
            if (const uint32_t rc = config_.vm->map_page_group(a, s, c->pages, CodeOut, PermRW); rc) return rc;
            c->slave_mapped = true;
            c->slave_at = a;
            return r::Success;
        case 1:
            if (!config_.vm->can_contain(a, s, GeneratedCode)) return r::InvalidMemoryRegion;
            if (perm != PermR && perm != PermRX_) return r::InvalidNewMemoryPermission;
            if (c->pages.size() != s) return r::InvalidSize;
            if (c->owner_mapped) return r::InvalidState;
            if (const uint32_t rc = config_.vm->map_page_group(a, s, c->pages, GeneratedCode, perm); rc) return rc;
            c->owner_mapped = true;
            c->owner_at = a;
            return r::Success;
        case 2:
            if (!config_.vm->can_contain(a, s, CodeOut)) return r::InvalidMemoryRegion;
            if (perm != PermNone) return r::InvalidNewMemoryPermission;
            if (c->pages.size() != s) return r::InvalidSize;
            if (const uint32_t rc = config_.vm->unmap_page_group(a, s, c->pages, CodeOut); rc) return rc;
            c->slave_mapped = false;
            return r::Success;
        case 3:
            if (!config_.vm->can_contain(a, s, GeneratedCode)) return r::InvalidMemoryRegion;
            if (perm != PermNone) return r::InvalidNewMemoryPermission;
            if (c->pages.size() != s) return r::InvalidSize;
            if (const uint32_t rc = config_.vm->unmap_page_group(a, s, c->pages, GeneratedCode); rc) return rc;
            c->owner_mapped = false;
            return r::Success;
        default:
            return r::InvalidEnumValue;
    }
}

void KernelObjects::destroy_code_if_unused(uint64_t id) {
    auto it = code_.find(id);
    if (it == code_.end() || it->second.refs) return;
    Code& c = it->second;
    if (c.slave_mapped) config_.vm->unmap_page_group(c.slave_at, c.size, c.pages, CodeOut);
    if (c.owner_mapped) config_.vm->unmap_page_group(c.owner_at, c.size, c.pages, GeneratedCode);
    // KCodeMemory::Finalize: UnlockForCodeMemory (user RW again)
    config_.vm->unlock_memory(c.address, c.size, FlagCanCodeMemory, FlagCanCodeMemory, 0, 0, All, AttrLocked, PermRW, AttrLocked,
                              &c.pages);
    code_.erase(it);
}

// ---- handles ------------------------------------------------------------------------------

void KernelObjects::on_handle_closed(const KObjectRef& o) {
    if (!active_) return;
    switch (o.type) {
        case KObjectType::SharedMemory: {
            auto it = shared_.find(o.id);
            if (it != shared_.end() && it->second.refs) --it->second.refs;
            destroy_shared_if_unused(o.id);
            break;
        }
        case KObjectType::TransferMemory: release_transfer(o.id); break;
        case KObjectType::CodeMemory: {
            auto it = code_.find(o.id);
            if (it != code_.end() && it->second.refs) --it->second.refs;
            destroy_code_if_unused(o.id);
            break;
        }
        case KObjectType::ResourceLimit: {
            auto it = limits_.find(o.id);
            if (it != limits_.end() && it->second.refs) --it->second.refs;
            if (it != limits_.end() && it->second.refs == 0 && o.id != process_limit_) limits_.erase(it);
            break;
        }
        default: break;
    }
}

std::string KernelObjects::check_invariants() const {
    for (const auto& [id, sh] : shared_) {
        if (sh.pages.size() != sh.size) return "shared " + std::to_string(id) + ": page group size";
        if (sh.refs < sh.mappings.size()) return "shared " + std::to_string(id) + ": fewer references than mappings";
    }
    for (const auto& [id, t] : transfer_)
        if (t.pages.size() != t.size || t.refs == 0) return "transfer " + std::to_string(id) + ": pages/references";
    for (const auto& [id, c] : code_)
        if (c.pages.size() != c.size || c.refs == 0) return "code " + std::to_string(id) + ": pages/references";
    return {};
}

} // namespace lg::system
