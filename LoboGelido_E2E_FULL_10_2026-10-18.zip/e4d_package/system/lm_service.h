#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include "ipc.h"

// HLE of the Switch log manager (nn::lm). Guest titles push log messages here
// constantly; this endpoint consumes them so they can surface in Lobo's
// diagnostics instead of being lost.
//
// SCOPE: the Lobo IpcMessage transport is a simplified {command_id, payload}
// channel. This uses a documented Lobo log format rather than the raw nn::lm
// TLV LogPacket over a logger session; a cmif adapter would translate the real
// packet into these calls. Thread-safe (guest threads log concurrently).
//
//   0 Log            <- [u32 severity][utf8 text...]
//   1 SetDestination <- [u32 destination]   (0=none, 1=host log, 2=uart, ...)

namespace lg::system {

class LmService final : public IpcEndpoint {
public:
    // Severity levels, aligned to nn::diag log severities.
    enum Severity : uint32_t { kTrace = 0, kInfo = 1, kWarn = 2, kError = 3, kFatal = 4 };

    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

    // Introspection (for diagnostics/tests).
    uint64_t logged_count() const noexcept;
    std::string last_message() const;
    uint32_t last_severity() const noexcept;
    uint32_t destination() const noexcept;

private:
    mutable std::mutex mutex_;
    uint64_t count_{0};
    uint32_t destination_{1};
    uint32_t last_severity_{kInfo};
    std::string last_message_;
};

std::unique_ptr<IpcEndpoint> make_lm_service();

} // namespace lg::system
