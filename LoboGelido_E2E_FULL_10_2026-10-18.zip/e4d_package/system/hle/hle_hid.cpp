#include "hle_services.h"
#include "hle_hid_shm.h"
#include "../handle_table.h"

#include "../cmif.h"

namespace lg::system::hle {
namespace {

// Minimal AppletResource: homebrew often only needs the interface to open.
class AppletResource final : public HleService {
public:
    AppletResource() : HleService("IAppletResource") {
        add(0, "GetSharedMemoryHandle", [](HleRequest& r) {
            // HID shared memory layout size (nn::hid): 0x40000 bytes.
            constexpr uint64_t kHidSharedSize = 0x40000ull;
            auto ref = r.ipc().create_service_shared_memory(kHidSharedSize);
            if (ref.type == lg::system::KObjectType::None || ref.id == 0) {
                r.set_result(result::NotImplemented);
                return;
            }
            set_active_hid_shared_id(ref.id);
            r.push_copy_handle(ref);
        });
        add(1, "EnableAppletToGetInput", [](HleRequest& /*r*/) {
            // Success no-op
        });
    }
};

class HidService final : public HleService {
public:
    HidService() : HleService("hid") {
        add(0, "CreateAppletResource", [](HleRequest& r) {
            (void)r.pop<uint64_t>();  // applet resource user id
            r.push_object(std::make_shared<AppletResource>());
        });
        add(11, "ActivateNpad", [](HleRequest& r) {
            (void)r.pop<uint32_t>();
        });
        add(21, "SetSupportedNpadStyleSet", [](HleRequest& r) {
            (void)r.pop<uint32_t>();
        });
        add(100, "SetNpadJoyHoldType", [](HleRequest& r) {
            (void)r.pop<uint64_t>();
            (void)r.pop<uint64_t>();
        });
        add(120, "SetNpadJoyAssignmentModeSingleByDefault", [](HleRequest& r) {
            (void)r.pop<uint32_t>();
        });
        add(122, "SetNpadJoyAssignmentModeDual", [](HleRequest& r) {
            (void)r.pop<uint32_t>();
        });
    }
};

} // namespace

std::shared_ptr<HleService> make_hid_hle_service() { return std::make_shared<HidService>(); }

std::vector<CatalogEntry> hid_catalog() {
    return {
        {"services/hid.c", "hid",
         [] { return std::shared_ptr<HleService>(std::make_shared<HidService>()); }},
        {"services/hid.c", "IAppletResource",
         [] { return std::shared_ptr<HleService>(std::make_shared<AppletResource>()); }},
    };
}

} // namespace lg::system::hle
