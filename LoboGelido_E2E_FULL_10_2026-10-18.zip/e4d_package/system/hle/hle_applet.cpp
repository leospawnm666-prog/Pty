#include "hle_services.h"

#include "../cmif.h"

namespace lg::system::hle {
namespace {

class ApplicationProxy final : public HleService {
public:
    ApplicationProxy() : HleService("IApplicationProxy") {
        add(0, "GetCommonStateGetter", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(1, "GetSelfController", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(2, "GetWindowController", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(3, "GetAudioController", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(4, "GetDisplayController", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(11, "GetLibraryAppletCreator", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(20, "GetApplicationFunctions", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
        add(1000, "GetDebugFunctions", [](HleRequest& r) {
            r.set_result(result::NotImplemented);
        });
    }
};

class AppletOE final : public HleService {
public:
    AppletOE() : HleService("appletOE") {
        add(0, "OpenApplicationProxy", [](HleRequest& r) {
            // ProcessId + reserved — open proxy session
            (void)r.pop<uint64_t>();
            (void)r.pop<uint64_t>();
            r.push_session(std::make_shared<ApplicationProxy>());
        });
    }
};

} // namespace

std::shared_ptr<HleService> make_applet_oe_service() { return std::make_shared<AppletOE>(); }

std::vector<CatalogEntry> applet_catalog() {
    return {
        {"services/applet.c", "appletOE",
         [] { return std::shared_ptr<HleService>(std::make_shared<AppletOE>()); }},
        {"services/applet.c", "IApplicationProxy",
         [] { return std::shared_ptr<HleService>(std::make_shared<ApplicationProxy>()); }},
    };
}

} // namespace lg::system::hle
