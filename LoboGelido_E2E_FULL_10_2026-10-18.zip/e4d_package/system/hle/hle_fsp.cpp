#include "hle_services.h"
#include "hle_content.h"

#include "../cmif.h"

#include <algorithm>
#include <cstring>

namespace lg::system::hle {
namespace {

/** nn::fs::IStorage-like: linear read over the mounted RomFS blob. */
class StorageService final : public HleService {
public:
    explicit StorageService(std::shared_ptr<const std::vector<uint8_t>> linear)
        : HleService("IStorage"), linear_(std::move(linear)) {
        add(0, "Read", [this](HleRequest& r) {
            const auto offset = r.pop<uint64_t>();
            const auto size = r.pop<uint64_t>();
            if (!offset || !size || !linear_) {
                r.set_result(cmif::result::InvalidHeaderSize);
                return;
            }
            if (*offset > linear_->size() || *size > linear_->size() - *offset) {
                r.set_result(result::FsSdCardNotPresent);
                return;
            }
            if (*size > (64u << 20)) {
                r.set_result(cmif::result::InvalidHeaderSize);
                return;
            }
            // Prefer HIPC buffer B/C; fall back to inline push of small reads is not CMIF-correct
            // but write_buffer is the real path.
            if (!r.write_buffer(0, linear_->data() + *offset, static_cast<size_t>(*size))) {
                // No guest buffer: still succeed for GetSize-only clients; report error for Read.
                r.set_result(cmif::result::InvalidHeaderSize);
            }
        });
        add(4, "GetSize", [this](HleRequest& r) {
            r.push(uint64_t{linear_ ? linear_->size() : 0});
        });
        add(1, "Write", [](HleRequest& r) {
            r.set_result(result::NotImplemented);  // RomFS is read-only
        });
        add(2, "Flush", [](HleRequest& /*r*/) {});
        add(3, "SetSize", [](HleRequest& r) { r.set_result(result::NotImplemented); });
        add(5, "OperateRange", [](HleRequest& r) { r.set_result(result::NotImplemented); });
    }

private:
    std::shared_ptr<const std::vector<uint8_t>> linear_;
};

/** Minimal path-based view: OpenFile returns a tiny file storage of one RomFS file. */
class FileStorage final : public HleService {
public:
    explicit FileStorage(std::vector<uint8_t> data)
        : HleService("IFile"), data_(std::move(data)) {
        add(0, "Read", [this](HleRequest& r) {
            const auto option = r.pop<uint32_t>();
            (void)option;
            const auto offset = r.pop<uint64_t>();
            const auto size = r.pop<uint64_t>();
            if (!offset || !size) {
                r.set_result(cmif::result::InvalidHeaderSize);
                return;
            }
            if (*offset > data_.size() || *size > data_.size() - *offset) {
                r.set_result(result::FsSdCardNotPresent);
                return;
            }
            if (!r.write_buffer(0, data_.data() + *offset, static_cast<size_t>(*size)))
                r.set_result(cmif::result::InvalidHeaderSize);
        });
        add(4, "GetSize", [this](HleRequest& r) { r.push(uint64_t{data_.size()}); });
        add(1, "Write", [](HleRequest& r) { r.set_result(result::NotImplemented); });
        add(2, "Flush", [](HleRequest& /*r*/) {});
        add(3, "SetSize", [](HleRequest& r) { r.set_result(result::NotImplemented); });
    }

private:
    std::vector<uint8_t> data_;
};

class FileSystemService final : public HleService {
public:
    explicit FileSystemService(std::shared_ptr<loader::RomFsImage> img)
        : HleService("IFileSystem"), img_(std::move(img)) {
        add(7, "GetEntryType", [this](HleRequest& r) {
            // path as buffer A[0]
            auto path = r.read_buffer(0);
            if (!path || !img_) {
                r.set_result(cmif::result::InvalidHeaderSize);
                return;
            }
            std::string p(path->begin(), path->end());
            while (!p.empty() && p.back() == '\0') p.pop_back();
            if (p.empty() || p[0] != '/') p = "/" + p;
            for (const auto& e : img_->entries()) {
                if (e.path == p) {
                    r.push(uint32_t{e.directory ? 1u : 0u});  // Directory=1, File=0 (simplified)
                    return;
                }
            }
            r.set_result(result::FsSdCardNotPresent);
        });
        add(8, "OpenFile", [this](HleRequest& r) {
            const auto mode = r.pop<uint32_t>();
            (void)mode;
            auto path = r.read_buffer(0);
            if (!path || !img_) {
                r.set_result(cmif::result::InvalidHeaderSize);
                return;
            }
            std::string p(path->begin(), path->end());
            while (!p.empty() && p.back() == '\0') p.pop_back();
            if (p.empty() || p[0] != '/') p = "/" + p;
            auto bytes = img_->read_file(p);
            if (!bytes.ok()) {
                r.set_result(result::FsSdCardNotPresent);
                return;
            }
            r.push_object(std::make_shared<FileStorage>(std::move(bytes.value())));
        });
        add(10, "Commit", [](HleRequest& /*r*/) {});
        add(11, "GetFreeSpaceSize", [](HleRequest& r) { r.push(uint64_t{0}); });
        add(12, "GetTotalSpaceSize", [](HleRequest& r) { r.push(uint64_t{0}); });
    }

private:
    std::shared_ptr<loader::RomFsImage> img_;
};

class FileSystemProxy final : public HleService {
public:
    FileSystemProxy() : HleService("fsp-srv") {
        add(1, "SetCurrentProcess", [this](HleRequest& r) {
            if (!r.has_pid() || !r.pop<uint64_t>()) {
                r.set_result(cmif::result::InvalidHeaderSize);
                return;
            }
            pid_ = r.pid();
        });

        add(200, "OpenDataStorageByCurrentProcess", [](HleRequest& r) {
            auto& mount = process_content();
            if (!mount.has_romfs()) {
                r.set_result(result::FsSdCardNotPresent);
                return;
            }
            r.push_object(std::make_shared<StorageService>(mount.shared_linear()));
        });

        add(202, "OpenDataStorageByDataId", [](HleRequest& r) {
            (void)r.pop<uint64_t>();
            (void)r.pop<uint8_t>();
            auto& mount = process_content();
            if (!mount.has_romfs()) {
                r.set_result(result::FsSdCardNotPresent);
                return;
            }
            r.push_object(std::make_shared<StorageService>(mount.shared_linear()));
        });

        // OpenFileSystemWithId-style: return path FS over RomFS when mounted
        add(8, "OpenFileSystemWithId", [](HleRequest& r) {
            (void)r.pop<uint64_t>();  // title id
            (void)r.pop<uint32_t>();  // type
            auto& mount = process_content();
            if (!mount.has_romfs() || !mount.romfs()) {
                r.set_result(result::FsSdCardNotPresent);
                return;
            }
            r.push_object(std::make_shared<FileSystemService>(mount.romfs()));
        });

        add(18, "OpenSdCardFileSystem", [](HleRequest& r) {
            r.set_result(result::FsSdCardNotPresent);
        });
        add(100, "OpenBisFileSystem", [](HleRequest& r) {
            (void)r.pop<uint32_t>();
            r.set_result(result::FsSdCardNotPresent);
        });
        add(27, "IsSdCardInserted", [](HleRequest& r) { r.push(uint8_t{0}); });
        add(51, "GetFreeSpaceSize", [](HleRequest& r) { r.push(uint64_t{0}); });
        add(52, "GetTotalSpaceSize", [](HleRequest& r) { r.push(uint64_t{0}); });
    }

private:
    uint64_t pid_{};
};
} // namespace

std::shared_ptr<HleService> make_fsp_service() { return std::make_shared<FileSystemProxy>(); }

std::vector<CatalogEntry> fsp_catalog() {
    return {{"services/fs.c", "&g_fsSrv",
             [] { return std::shared_ptr<HleService>(std::make_shared<FileSystemProxy>()); }}};
}

} // namespace lg::system::hle
