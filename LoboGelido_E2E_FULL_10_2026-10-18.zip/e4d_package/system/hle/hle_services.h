#pragma once
// Horizon HLE services reachable through real CMIF IPC (KernelIpc).
// Boot set grows from P3.4 (sm:, time:u, fsp-srv) toward playable surface:
// set:sys, set, hid, appletOE — still partial; catalog measures honest coverage.
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "hle_service.h"

namespace lg::system {
class KernelIpc;
}

namespace lg::system::hle {

namespace result {
constexpr uint32_t SmInvalidClient = 0x415;
constexpr uint32_t SmInvalidServiceName = 0xC15;
constexpr uint32_t FsSdCardNotPresent = 0xFA202;
constexpr uint32_t NotImplemented = 0x4A8;  // generic module-local not-implemented style
} // namespace result

std::shared_ptr<HleService> make_sm_service();
std::shared_ptr<HleService> make_time_service();
std::shared_ptr<HleService> make_fsp_service();
std::shared_ptr<HleService> make_set_sys_service();   // "set:sys"
std::shared_ptr<HleService> make_set_service();       // "set"
std::shared_ptr<HleService> make_hid_hle_service();   // "hid"
std::shared_ptr<HleService> make_applet_oe_service(); // "appletOE"

struct CatalogEntry {
    const char* libnx_file;
    const char* libnx_interface;
    std::function<std::shared_ptr<HleService>()> make;
};
std::vector<CatalogEntry> catalog();
std::vector<CatalogEntry> sm_catalog();
std::vector<CatalogEntry> time_catalog();
std::vector<CatalogEntry> fsp_catalog();
std::vector<CatalogEntry> set_catalog();
std::vector<CatalogEntry> hid_catalog();
std::vector<CatalogEntry> applet_catalog();

/** Boot services registered into KernelIpc before the guest runs. */
bool register_boot_services(KernelIpc& ipc);

/** One-line coverage summary for logs / diagnostics (families + total commands). */
std::string coverage_summary();

struct CivilTime { int64_t year; uint32_t month, day, hour, minute, second, wday, yday; };
bool civil_from_posix(int64_t t, CivilTime& out) noexcept;

} // namespace lg::system::hle
