#include "hle_service.h"

#include "../kipc.h"

namespace lg::system::hle {

const char* HleService::command_name(uint32_t command) const noexcept {
    auto it = commands_.find(command);
    return it == commands_.end() ? "?" : it->second.name;
}

void HleService::invoke(uint32_t command, HleRequest& request) const {
    auto it = commands_.find(command);
    if (it != commands_.end()) it->second.handler(request);
}

void HleService::add(uint32_t command, const char* name, Handler handler) {
    commands_[command] = Command{name, std::move(handler)};
}

std::optional<std::vector<uint8_t>> HleRequest::read_buffer(size_t i) const {
    if (!hipc_) return std::nullopt;
    const hipc::StaticDescriptor* x = nullptr;
    for (const auto& d : hipc_->x) if (d.index == i) { x = &d; break; }
    uint64_t address = 0, size = 0;
    if (i < hipc_->a.size() && hipc_->a[i].size) { address = hipc_->a[i].address; size = hipc_->a[i].size; }
    else if (x) { address = x->address; size = x->size; }
    else return std::nullopt;
    if (size > (64u << 20)) return std::nullopt;                  // never allocate from a guest size blindly
    std::vector<uint8_t> out(static_cast<size_t>(size));
    if (size && !ipc_.memory().read(address, out.data(), out.size())) return std::nullopt;
    return out;
}

bool HleRequest::write_buffer(size_t i, const void* data, size_t size) {
    if (!hipc_) return false;
    if (i < hipc_->b.size() && hipc_->b[i].size) {
        if (hipc_->b[i].size < size) return false;
        return ipc_.memory().write(hipc_->b[i].address, data, size);
    }
    if (hipc_->recv_mode > hipc::recv_mode::ToSingleBuffer && i < hipc_->c.size()) {
        const auto& c = hipc_->c[i];
        if (c.size < size || !ipc_.memory().write(c.address, data, size)) return false;
        out_statics_.push_back({static_cast<uint32_t>(i), c.address, size});
        return true;
    }
    return false;
}

} // namespace lg::system::hle
