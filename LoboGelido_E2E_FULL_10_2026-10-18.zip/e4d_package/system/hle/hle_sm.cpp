#include "hle_services.h"
#include <cstdio>

#include "../cmif.h"
#include "../kipc.h"

namespace lg::system::hle {
namespace {
class SmService final : public HleService {
public:
    SmService() : HleService("sm:") {
        add(0, "RegisterClient", [this](HleRequest& r) {
            // RegisterClient(ClientProcessId): the PID comes from the kernel, the raw u64 is a
            // placeholder.
            if (!r.has_pid() || !r.pop<uint64_t>()) { r.set_result(cmif::result::InvalidHeaderSize); return; }
            registered_ = true;
        });
        add(1, "GetServiceHandle", [this](HleRequest& r) {
            if (!registered_) { r.set_result(result::SmInvalidClient); return; }
            const auto encoded = r.pop<uint64_t>();
            if (!encoded) { r.set_result(cmif::result::InvalidHeaderSize); return; }
            // sm::ValidateServiceName: non-empty, all zero after the terminator.
            char name[9] = {};
            std::memcpy(name, &*encoded, 8);
            if (name[0] == 0) { r.set_result(result::SmInvalidServiceName); return; }
            size_t len = 1;
            while (len < 8 && name[len] != 0) ++len;
            for (size_t i = len; i < 8; ++i)
                if (name[i] != 0) { r.set_result(result::SmInvalidServiceName); return; }
            const std::string service(name, len);
            if (auto object = r.ipc().open_service(service)) r.push_session(std::move(object));
            else r.defer(service);   // D-P3.4-3: waits until someone registers it
        });
    }

private:
    bool registered_{};
};
} // namespace

std::shared_ptr<HleService> make_sm_service() { return std::make_shared<SmService>(); }

std::vector<CatalogEntry> sm_catalog() {
    // libnx sends RegisterClient (0) through "0" (smInitialize's literal) and the rest through
    // &g_smSrv.cmif (the inventory's names)
    return {{"services/sm.c", "&g_smSrv.cmif", [] { return std::shared_ptr<HleService>(std::make_shared<SmService>()); }},
            {"services/sm.c", "0", [] { return std::shared_ptr<HleService>(std::make_shared<SmService>()); }}};
}

std::vector<CatalogEntry> catalog() {
    std::vector<CatalogEntry> all;
    for (auto part : {sm_catalog(), time_catalog(), fsp_catalog(), set_catalog(), hid_catalog(),
                      applet_catalog()})
        for (auto& e : part) all.push_back(std::move(e));
    return all;
}

bool register_boot_services(KernelIpc& ipc) {
    return ipc.create_named_port("sm:", KernelIpc::kPortMaxSessions, [] { return make_sm_service(); }) &&
           ipc.register_service("time:u", [] { return make_time_service(); }) &&
           ipc.register_service("fsp-srv", [] { return make_fsp_service(); }) &&
           ipc.register_service("set:sys", [] { return make_set_sys_service(); }) &&
           ipc.register_service("set", [] { return make_set_service(); }) &&
           ipc.register_service("hid", [] { return make_hid_hle_service(); }) &&
           ipc.register_service("appletOE", [] { return make_applet_oe_service(); });
}

std::string coverage_summary() {
    const auto entries = catalog();
    uint32_t families = static_cast<uint32_t>(entries.size());
    uint32_t commands = 0;
    for (const auto& e : entries) {
        if (auto obj = e.make()) commands += static_cast<uint32_t>(obj->command_ids().size());
    }
    char buf[160];
    std::snprintf(buf, sizeof buf, "hleFamilies=%u;hleCommands=%u;boot=sm,time,fsp,set:sys,set,hid,appletOE",
                  families, commands);
    return buf;
}

} // namespace lg::system::hle
