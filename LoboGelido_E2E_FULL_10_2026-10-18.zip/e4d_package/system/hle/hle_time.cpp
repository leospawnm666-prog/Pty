#include "hle_services.h"

#include "../kipc.h"

namespace lg::system::hle {

bool civil_from_posix(int64_t t, CivilTime& out) noexcept {
    // Howard Hinnant's days_from_civil / civil_from_days (public domain algorithms).
    int64_t days = t / 86400;
    int64_t secs = t % 86400;
    if (secs < 0) { secs += 86400; --days; }
    out.hour = static_cast<uint32_t>(secs / 3600);
    out.minute = static_cast<uint32_t>(secs / 60 % 60);
    out.second = static_cast<uint32_t>(secs % 60);
    out.wday = static_cast<uint32_t>(((days % 7) + 11) % 7);   // 1970-01-01 was a Thursday (4)
    const int64_t z = days + 719468;
    const int64_t era = (z >= 0 ? z : z - 146096) / 146097;
    const int64_t doe = z - era * 146097;
    const int64_t yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    int64_t y = yoe + era * 400;
    const int64_t doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const int64_t mp = (5 * doy + 2) / 153;
    const int64_t d = doy - (153 * mp + 2) / 5 + 1;
    const int64_t m = mp < 10 ? mp + 3 : mp - 9;
    if (m <= 2) ++y;
    out.year = y;
    out.month = static_cast<uint32_t>(m);
    out.day = static_cast<uint32_t>(d);
    // day of the year: days since January 1st of `y`
    const int64_t yy = y - 1;   // days_from_civil(y, 1, 1)
    const int64_t era1 = (yy >= 0 ? yy : yy - 399) / 400;
    const int64_t yoe1 = yy - era1 * 400;
    const int64_t doy1 = (153 * (1 + 9) + 2) / 5;               // March-based day of January 1st
    const int64_t doe1 = yoe1 * 365 + yoe1 / 4 - yoe1 / 100 + doy1;
    const int64_t jan1 = era1 * 146097 + doe1 - 719468;
    out.yday = static_cast<uint32_t>(days - jan1);
    return y >= 0 && y <= 0xFFFF;
}

namespace {
class SystemClock final : public HleService {
public:
    explicit SystemClock(const char* name) : HleService(name) {
        add(0, "GetCurrentTime", [](HleRequest& r) { r.push<int64_t>(r.ipc().posix_now()); });
    }
};

class SteadyClock final : public HleService {
public:
    SteadyClock() : HleService("ISteadyClock") {}   // libnx's startup opens it and uses nothing
};

class TimeZoneService final : public HleService {
public:
    TimeZoneService() : HleService("ITimeZoneService") {
        add(101, "ToCalendarTimeWithMyRule", [](HleRequest& r) {
            const auto t = r.pop<int64_t>();
            if (!t) { r.set_result(0x1940A); return; }            // sf InvalidHeaderSize
            CivilTime c{};
            if (!civil_from_posix(*t, c)) { r.fail("ToCalendarTimeWithMyRule: year out of range"); return; }
            // CalendarTime {u16 year; u8 month, day, hour, minute, second, pad}
            const uint16_t year = static_cast<uint16_t>(c.year);
            r.push(year);
            for (uint32_t v : {c.month, c.day, c.hour, c.minute, c.second, 0u}) r.push(static_cast<uint8_t>(v));
            // CalendarAdditionalInfo {u32 wday; u32 yday; char tz[8]; u32 dst; s32 offset}: UTC
            r.push(c.wday);
            r.push(c.yday);
            const char tz[8] = {'U', 'T', 'C', 0, 0, 0, 0, 0};
            r.push(tz);
            r.push(uint32_t{0});
            r.push(int32_t{0});
        });
    }
};

class StaticService final : public HleService {
public:
    StaticService() : HleService("time:u") {
        add(0, "GetStandardUserSystemClock", [](HleRequest& r) { r.push_object(std::make_shared<SystemClock>("ISystemClock(user)")); });
        add(1, "GetStandardNetworkSystemClock", [](HleRequest& r) { r.push_object(std::make_shared<SystemClock>("ISystemClock(network)")); });
        add(2, "GetStandardSteadyClock", [](HleRequest& r) { r.push_object(std::make_shared<SteadyClock>()); });
        add(3, "GetTimeZoneService", [](HleRequest& r) { r.push_object(std::make_shared<TimeZoneService>()); });
        add(4, "GetStandardLocalSystemClock", [](HleRequest& r) { r.push_object(std::make_shared<SystemClock>("ISystemClock(local)")); });
    }
};
} // namespace

std::shared_ptr<HleService> make_time_service() { return std::make_shared<StaticService>(); }

std::vector<CatalogEntry> time_catalog() {
    return {{"services/time.c", "&g_timeSrv", [] { return std::shared_ptr<HleService>(std::make_shared<StaticService>()); }},
            {"services/time.c", "&g_timeSteadyClock", [] { return std::shared_ptr<HleService>(std::make_shared<SteadyClock>()); }},
            {"services/time.c", "&g_timeTimeZoneService", [] { return std::shared_ptr<HleService>(std::make_shared<TimeZoneService>()); }},
            {"services/time.c", "srv", [] { return std::shared_ptr<HleService>(std::make_shared<SystemClock>("ISystemClock")); }}};
}

} // namespace lg::system::hle
