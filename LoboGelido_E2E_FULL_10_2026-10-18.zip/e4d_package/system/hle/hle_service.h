#pragma once
// P3.4: the framework of the high-level-emulated services the guest reaches through real IPC
// (P3_4_DISENO.md §2.5). A service object is one CMIF interface (IStaticService, ISystemClock…):
// a table {command id -> handler, name}. Handlers run synchronously in the calling thread's
// turn (D-P3.4-1) and see the request through HleRequest.
//
// Not the legacy transport of system/ipc.h (IpcEndpoint / {command_id, payload}), which stays
// as it is and is unreachable from the guest (D-P3.4-9).
#include <cstdint>
#include <cstring>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "../handle_table.h"
#include "../hipc.h"

namespace lg::system {
class KernelIpc;
}

namespace lg::system::hle {

class HleRequest;

class HleService {
public:
    using Handler = std::function<void(HleRequest&)>;
    explicit HleService(std::string name) : name_(std::move(name)) {}
    virtual ~HleService() = default;
    HleService(const HleService&) = delete;
    HleService& operator=(const HleService&) = delete;

    const std::string& name() const noexcept { return name_; }
    bool has(uint32_t command) const noexcept { return commands_.count(command) != 0; }
    const char* command_name(uint32_t command) const noexcept;
    /** P6.0: the command ids the object implements (catalog / coverage). */
    std::vector<uint32_t> command_ids() const {
        std::vector<uint32_t> out;
        for (const auto& [id, c] : commands_) out.push_back(id);
        return out;
    }
    /** Runs the handler of `command` (the caller checked has()). */
    void invoke(uint32_t command, HleRequest& request) const;

protected:
    void add(uint32_t command, const char* name, Handler handler);

private:
    struct Command { const char* name; Handler handler; };
    std::string name_;
    std::map<uint32_t, Command> commands_;
};

/** One CMIF request as a service sees it. */
class HleRequest {
public:
    HleRequest(KernelIpc& ipc, uint32_t command, bool has_pid, uint64_t pid, std::vector<uint8_t> raw,
               const hipc::Request* hipc)
        : ipc_(ipc), command_(command), has_pid_(has_pid), pid_(pid), raw_(std::move(raw)), hipc_(hipc) {}

    KernelIpc& ipc() noexcept { return ipc_; }
    uint32_t command() const noexcept { return command_; }
    bool has_pid() const noexcept { return has_pid_; }
    /** The sender's process id, written by the kernel (the guest's value is ignored). */
    uint64_t pid() const noexcept { return pid_; }

    // ---- raw input (sequential, little-endian, bounds checked) ----------------------------
    size_t raw_size() const noexcept { return raw_.size(); }
    /** Next T of the raw input; nullopt (and input_ok() == false) if it does not fit. */
    template <class T> std::optional<T> pop() {
        if (pos_ + sizeof(T) > raw_.size()) { input_ok_ = false; return std::nullopt; }
        T v;
        std::memcpy(&v, raw_.data() + pos_, sizeof(T));
        pos_ += sizeof(T);
        return v;
    }
    bool input_ok() const noexcept { return input_ok_; }

    // ---- output ----------------------------------------------------------------------------
    template <class T> void push(const T& v) {
        const auto* p = reinterpret_cast<const uint8_t*>(&v);
        out_raw_.insert(out_raw_.end(), p, p + sizeof(T));
    }
    void set_result(uint32_t result) noexcept { result_ = result; }
    uint32_t result() const noexcept { return result_; }
    /** A new interface: a domain object id in a domain session, otherwise a new session
     *  (move handle). */
    void push_object(std::shared_ptr<HleService> object) { out_objects_.push_back(std::move(object)); }
    /** Always a new session (move handle), whatever the session is (sm GetServiceHandle). */
    void push_session(std::shared_ptr<HleService> object) { out_sessions_.push_back(std::move(object)); }
    // ---- P6.0 (P6_DISENO.md §3.1): handles --------------------------------------------------
    /** The objects behind the request's copy handles, as the kernel translated them (pseudo-
     *  handles resolved); None for a handle 0. */
    size_t copy_handle_count() const noexcept { return in_copies_.size(); }
    std::optional<KObjectRef> copy_handle(size_t i) const {
        if (i >= in_copies_.size()) return std::nullopt;
        return in_copies_[i];
    }
    /** A copy handle in the reply: the kernel adds a handle to `object` for the client (one
     *  more reference in its owner). */
    void push_copy_handle(KObjectRef object) { out_copies_.push_back(object); }
    /** A move handle in the reply: `object` already carries the reference the new handle takes
     *  (KernelIpc::create_service_event() and the like). */
    void push_move_handle(KObjectRef object) { out_moves_.push_back(object); }
    /** The request waits (the client thread blocks) until the kernel retries it. */
    void defer(std::string reason) { deferred_ = true; defer_reason_ = std::move(reason); }
    /** A malformed request the service cannot answer (fatal with diagnostics, D3). */
    void fail(std::string message) { failure_ = std::move(message); }

    // ---- buffers (Eden's rule): in i = A[i] if non-empty, else the X with index i;
    //      out i = B[i] if non-empty, else receive list entry i ---------------------------------
    std::optional<std::vector<uint8_t>> read_buffer(size_t i) const;
    /** Writes `size` bytes to out buffer i; false if there is none or it is too small. */
    bool write_buffer(size_t i, const void* data, size_t size);

private:
    friend class lg::system::KernelIpc;
    KernelIpc& ipc_;
    uint32_t command_;
    bool has_pid_;
    uint64_t pid_;
    std::vector<uint8_t> raw_;
    const hipc::Request* hipc_;
    size_t pos_{};
    bool input_ok_{true};
    uint32_t result_{};
    std::vector<uint8_t> out_raw_;
    std::vector<std::shared_ptr<HleService>> out_objects_;
    std::vector<std::shared_ptr<HleService>> out_sessions_;
    std::vector<hipc::StaticDescriptor> out_statics_;   // X of the reply for C writes
    std::vector<KObjectRef> in_copies_;                 // P6.0
    std::vector<KObjectRef> out_copies_, out_moves_;    // P6.0
    bool deferred_{};
    std::string defer_reason_;
    std::string failure_;
};

} // namespace lg::system::hle
