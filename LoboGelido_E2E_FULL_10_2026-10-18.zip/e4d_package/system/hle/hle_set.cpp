#include "hle_services.h"

#include "../cmif.h"

#include <array>
#include <cstring>

namespace lg::system::hle {
namespace {

uint64_t pack_lang(const char* code) {
    uint64_t packed = 0;
    if (!code) return 0;
    for (size_t i = 0; i < 8 && code[i]; ++i)
        packed |= static_cast<uint64_t>(static_cast<uint8_t>(code[i])) << (8 * i);
    return packed;
}

// nn::settings::system::FirmwareVersion-style 0x100 blob (major 18).
void push_firmware_version(HleRequest& r) {
    std::array<uint8_t, 0x100> v{};
    v[0] = 18;
    v[1] = 0;
    v[2] = 0;
    v[4] = 1;
    const char* plat = "NX";
    std::memcpy(v.data() + 0x08, plat, 2);
    const char* disp = "18.0.0";
    std::memcpy(v.data() + 0x68, disp, 6);
    const char* title = "Lobo Gelido HLE";
    std::memcpy(v.data() + 0x80, title, 15);
    // Push as raw bytes via successive u64 / remainder
    for (size_t i = 0; i < 0x100; i += 8) {
        uint64_t w = 0;
        std::memcpy(&w, v.data() + i, 8);
        r.push(w);
    }
}

class SetSysService final : public HleService {
public:
    SetSysService() : HleService("set:sys") {
        add(3, "GetFirmwareVersion", [](HleRequest& r) { push_firmware_version(r); });
        add(4, "GetFirmwareVersion2", [](HleRequest& r) { push_firmware_version(r); });
        add(23, "GetLanguageCode", [](HleRequest& r) { r.push(pack_lang("en-US")); });
        add(24, "GetAvailableLanguageCodes", [](HleRequest& r) {
            // count + codes (simplified: report 1 language)
            r.push(int32_t{1});
            r.push(pack_lang("en-US"));
        });
        add(37, "GetRegionCode", [](HleRequest& r) {
            r.push(uint32_t{1});  // Usa
        });
        add(91, "GetDeviceNickName", [](HleRequest& r) {
            // 0x80 buffer style — push short name as u64 words
            char name[0x80] = {};
            std::memcpy(name, "LoboGelido", 10);
            for (size_t i = 0; i < 0x80; i += 8) {
                uint64_t w = 0;
                std::memcpy(&w, name + i, 8);
                r.push(w);
            }
        });
    }
};

class SetService final : public HleService {
public:
    SetService() : HleService("set") {
        add(0, "GetLanguageCode", [](HleRequest& r) { r.push(pack_lang("en-US")); });
        add(1, "GetAvailableLanguageCodes", [](HleRequest& r) {
            r.push(int32_t{1});
            r.push(pack_lang("en-US"));
        });
    }
};

} // namespace

std::shared_ptr<HleService> make_set_sys_service() { return std::make_shared<SetSysService>(); }
std::shared_ptr<HleService> make_set_service() { return std::make_shared<SetService>(); }

std::vector<CatalogEntry> set_catalog() {
    return {
        {"services/set.c", "set:sys",
         [] { return std::shared_ptr<HleService>(std::make_shared<SetSysService>()); }},
        {"services/set.c", "set",
         [] { return std::shared_ptr<HleService>(std::make_shared<SetService>()); }},
    };
}

} // namespace lg::system::hle
