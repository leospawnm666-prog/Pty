#pragma once
// P3.1: kernel-side access to guest VIRTUAL memory (P3_1_DISENO.md §2.9).
//
// Every access goes through the process Mmu with user permissions (the page must carry the
// User bit and Read/Write), page by page. A range is all-or-nothing: if any page is missing
// or lacks the permission nothing is copied (read) or written (write), so a hostile guest
// pointer can never make the host touch memory outside the arena.
// Writes go through AddressSpace::try_write8, so they notify code watches (note_write) and
// self-modifying code / JIT translations stay coherent.
// Not internally synchronised: the Mmu's TLB is refilled on lookups. Use it on the
// guest-execution thread under the coordinator lock, like the CPU engines.
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>

#include "../memory/address_space.h"
#include "../memory/mmu.h"

namespace lg::system {

class GuestMemory {
public:
    GuestMemory(memory::AddressSpace& memory, const memory::Mmu& mmu) noexcept : memory_(memory), mmu_(mmu) {}

    /** true if [va, va + size) is mapped, user-accessible and readable (writable if `write`).
     *  size 0 is always accessible; a range that wraps around 2^64 never is. */
    bool accessible(uint64_t va, uint64_t size, bool write) const noexcept;
    /** Copies `size` bytes from guest VA into `dst`. false (and nothing copied) on any fault. */
    bool read(uint64_t va, void* dst, size_t size) const noexcept;
    /** Writes `size` bytes at guest VA. Checked first: false (and nothing written) on any fault. */
    bool write(uint64_t va, const void* src, size_t size) noexcept;
    std::optional<uint32_t> read32(uint64_t va) const noexcept;
    bool write64(uint64_t va, uint64_t value) noexcept { return write(va, &value, sizeof value); }
    bool write32(uint64_t va, uint32_t value) noexcept { return write(va, &value, sizeof value); }
    /** P3.3: atomic compare-exchange of an aligned u32 (user read+write). Goes through
     *  AddressSpace::compare_exchange (P2 E.1), so it invalidates guest exclusive
     *  reservations like a guest STXR would. nullopt = not accessible; otherwise the value
     *  that was there (swapped iff it equals `expected`). */
    std::optional<uint32_t> compare_exchange32(uint64_t va, uint32_t expected, uint32_t desired) noexcept;

private:
    std::optional<uint64_t> translate(uint64_t va, bool write) const noexcept;
    memory::AddressSpace& memory_;
    const memory::Mmu& mmu_;
};

} // namespace lg::system
