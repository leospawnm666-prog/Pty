#pragma once
// P3.2: Horizon memory states, permissions and attributes (P3_2_DISENO.md §2.1).
//
// The KMemoryState values are the kernel's FULL values - the SVC-visible state in bits 0-7
// plus the capability flags the page table checks (CanReprotect, CanAlias, ...). They are
// copied from Atmosphère mesosphere (kern_k_memory_block.hpp, whose static_asserts pin
// them); QueryMemory reports only the low 8 bits, as the kernel does.
#include <cstdint>

namespace lg::system::kmem {

// ---- KMemoryState flags ---------------------------------------------------------------
constexpr uint32_t FlagCanReprotect = 1u << 8;
constexpr uint32_t FlagCanUseIpc = 1u << 10;            // P3.4 (the values below already carry them)
constexpr uint32_t FlagCanUseNonDeviceIpc = 1u << 11;   // P3.4
constexpr uint32_t FlagCanUseNonSecureIpc = 1u << 12;   // P3.4
constexpr uint32_t FlagMapped = 1u << 13;
constexpr uint32_t FlagCanAlias = 1u << 15;
constexpr uint32_t FlagCanChangeAttribute = 1u << 24;
constexpr uint32_t FlagCanPermissionLock = 1u << 27;
// P6.0 (P6_DISENO.md §3.1): the flags of the memory objects (shared, transfer, code, physical)
constexpr uint32_t FlagCanDebug = 1u << 9;
constexpr uint32_t FlagCode = 1u << 14;
constexpr uint32_t FlagCanCodeAlias = 1u << 16;
constexpr uint32_t FlagCanTransfer = 1u << 17;
constexpr uint32_t FlagCanQueryPhysical = 1u << 18;
constexpr uint32_t FlagCanDeviceMap = 1u << 19;
constexpr uint32_t FlagCanAlignedDeviceMap = 1u << 20;
constexpr uint32_t FlagCanIpcUserBuffer = 1u << 21;
constexpr uint32_t FlagReferenceCounted = 1u << 22;
constexpr uint32_t FlagCanMapProcess = 1u << 23;
constexpr uint32_t FlagCanCodeMemory = 1u << 25;
constexpr uint32_t FlagLinearMapped = 1u << 26;
constexpr uint32_t StateMask = 0xFF;          // the SVC MemoryState
constexpr uint32_t All = ~0u;

// ---- KMemoryState values (mesosphere) ---------------------------------------------------
constexpr uint32_t Free = 0x00000000;
constexpr uint32_t Code = 0x04DC7E03;
constexpr uint32_t CodeData = 0x0FFEBD04;
constexpr uint32_t Normal = 0x077EBD05;         // heap (libnx: MemType_Heap)
constexpr uint32_t AliasCode = 0x04DD7E08;      // code of a module mapped by a loader (hbloader)
constexpr uint32_t AliasCodeData = 0x0FFFBD09;
constexpr uint32_t Stack = 0x045C3C0B;          // libnx: MemType_MappedMemory
constexpr uint32_t ThreadLocal = 0x0400000C;
constexpr uint32_t Inaccessible = 0x00000010;   // libnx: MemType_Reserved
// P6.0: the states of the memory objects (mesosphere's values, as above)
constexpr uint32_t Shared = 0x04402006;
constexpr uint32_t Ipc = 0x045C3C0A;
constexpr uint32_t Transfered = 0x055C3C0D;
constexpr uint32_t SharedTransfered = 0x045C380E;
constexpr uint32_t SharedCode = 0x0440380F;
constexpr uint32_t NonSecureIpc = 0x045C3811;
constexpr uint32_t NonDeviceIpc = 0x044C2812;
constexpr uint32_t GeneratedCode = 0x04402214;
constexpr uint32_t CodeOut = 0x04402015;
constexpr uint32_t Insecure = 0x055C3817;       // P6.0: MapInsecurePhysicalMemory
constexpr uint32_t Static = 0x00040002;         // P6.0: (QueryMemoryMapping: never mapped in Lobo)

// ---- Permissions (user view, svc::MemoryPermission) ---------------------------------------
constexpr uint32_t PermNone = 0;
constexpr uint32_t PermR = 1;
constexpr uint32_t PermW = 2;
constexpr uint32_t PermX = 4;
constexpr uint32_t PermRW = PermR | PermW;
constexpr uint32_t PermRX = PermR | PermX;

// ---- Attributes (svc::MemoryAttribute) ---------------------------------------------------
constexpr uint32_t AttrLocked = 1u << 0;
constexpr uint32_t AttrIpcLocked = 1u << 1;
constexpr uint32_t AttrDeviceShared = 1u << 2;
constexpr uint32_t AttrUncached = 1u << 3;
constexpr uint32_t AttrPermissionLocked = 1u << 4;
constexpr uint32_t AttrSetMask = AttrUncached | AttrPermissionLocked;   // what SetMemoryAttribute may touch

// ---- Result codes (module 1, description << 9) -------------------------------------------
namespace result {
constexpr uint32_t Success = 0;
constexpr uint32_t InvalidSize = 0xCA01;                 // 101
constexpr uint32_t InvalidAddress = 0xCC01;              // 102
constexpr uint32_t OutOfMemory = 0xD001;                 // 104
constexpr uint32_t InvalidCurrentMemory = 0xD401;        // 106
constexpr uint32_t InvalidNewMemoryPermission = 0xD801;  // 108
constexpr uint32_t InvalidMemoryRegion = 0xDC01;         // 110
constexpr uint32_t InvalidPointer = 0xE601;              // 115
constexpr uint32_t InvalidCombination = 0xE801;          // 116
constexpr uint32_t LimitReached = 0x10801;               // 132
constexpr uint32_t OutOfResource = 0xCE01;               // 103 (P6.0)
constexpr uint32_t InvalidHandle = 0xE401;               // 114
constexpr uint32_t OutOfRange = 0xEE01;                  // 119
constexpr uint32_t InvalidEnumValue = 0xF001;            // 120
constexpr uint32_t NotFound = 0xF201;                    // 121
constexpr uint32_t InvalidState = 0xFA01;                // 125
constexpr uint32_t NotImplemented = 0x4201;              // 33
constexpr uint32_t NoEvent = 0x8C01;                     // 70
constexpr uint32_t Busy = 0xF401;                        // 122
constexpr uint32_t NotHandled = 0xF801;                  // 124
constexpr uint32_t NotSupported = 0xFE01;                // 127
constexpr uint32_t NoThread = 0x10201;                   // 129
constexpr uint32_t InvalidMemoryPool = 0x10A01;          // 133
constexpr uint32_t InvalidProcessId = 0x40A01;           // 517
constexpr uint32_t InvalidThreadId = 0x40C01;            // 518
constexpr uint32_t InvalidId = 0x40E01;                  // 519
constexpr uint32_t OutOfAddressSpace = 0x20601;          // 259 (P6.0: IPC map-alias)
constexpr uint32_t SessionClosed = 0xF601;               // 123
constexpr uint32_t ReceiveListBroken = 0x20A01;          // 261
constexpr uint32_t MessageTooLarge = 0x20801;            // 260
constexpr uint32_t PortClosed = 0x10601;                 // 131
constexpr uint32_t OutOfSessions = 0xE01;                // 7
constexpr uint32_t Cancelled = 0xEC01;                   // 118
constexpr uint32_t TimedOut = 0xEA01;                    // 117
} // namespace result

// ---- Sizes -------------------------------------------------------------------------------
constexpr uint64_t PageSize = 0x1000;
constexpr uint64_t HeapSizeAlignment = 0x200000;         // 2 MiB
constexpr uint64_t MainMemorySizeMax = 8ull << 30;       // 8 GiB (board nintendo/nx)

/** svc::MemoryInfo (lp64), 40 bytes, as QueryMemory writes it to the guest. */
struct MemoryInfo {
    uint64_t base_address;
    uint64_t size;
    uint32_t state;
    uint32_t attribute;
    uint32_t permission;
    uint32_t ipc_count;
    uint32_t device_count;
    uint32_t padding;
};
static_assert(sizeof(MemoryInfo) == 40, "svc::MemoryInfo is 40 bytes");

} // namespace lg::system::kmem
