#include "nvdrv_service.h"

#include <string>

namespace lg::system {
namespace {

void put_u32(std::vector<uint8_t>& p, uint32_t v) {
    for (int i = 0; i < 4; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }

using R = core::Result<IpcMessage>;

} // namespace

bool NvDrvService::known_device(const std::string& path) {
    static const char* kDevices[] = {
        "/dev/nvhost-ctrl", "/dev/nvhost-gpu", "/dev/nvhost-ctrl-gpu",
        "/dev/nvhost-as-gpu", "/dev/nvmap", "/dev/nvhost-vic", "/dev/nvhost-nvdec",
    };
    for (const char* d : kDevices) if (path == d) return true;
    return false;
}

core::Result<IpcMessage> NvDrvService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // Open <- utf8 path
            std::string path(r.payload.begin(), r.payload.end());
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            if (!known_device(path)) {
                put_u32(out.payload, 0);       // fd
                put_u32(out.payload, ERR_NOENT);  // status
                return R::Ok(std::move(out));
            }
            const uint32_t fd = next_fd_++;
            open_fds_.insert(fd);
            put_u32(out.payload, fd);
            put_u32(out.payload, OK);
            return R::Ok(std::move(out));
        }
        case 1: { // Ioctl <- [u32 fd][u32 code][in...]
            uint32_t fd{}, code{};
            if (!get_u32(r.payload, 0, fd) || !get_u32(r.payload, 4, code))
                return R::Error("nvdrv Ioctl: short payload");
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            if (open_fds_.find(fd) == open_fds_.end()) {
                put_u32(out.payload, ERR_BADF);
                return R::Ok(std::move(out));
            }
            switch (code) {
                case NVMAP_CREATE: {
                    uint32_t size{};
                    if (!get_u32(r.payload, 8, size)) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    if (size == 0) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    const uint32_t handle = next_handle_++;
                    nvmap_[handle] = size;
                    put_u32(out.payload, OK);
                    put_u32(out.payload, handle);
                    return R::Ok(std::move(out));
                }
                case NVMAP_ALLOC: {
                    uint32_t handle{};
                    if (!get_u32(r.payload, 8, handle)) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    put_u32(out.payload, nvmap_.count(handle) ? OK : ERR_INVAL);
                    return R::Ok(std::move(out));
                }
                case NVMAP_PARAM: {
                    uint32_t handle{};
                    if (!get_u32(r.payload, 8, handle)) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    auto it = nvmap_.find(handle);
                    if (it == nvmap_.end()) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    put_u32(out.payload, OK);
                    put_u32(out.payload, it->second);
                    return R::Ok(std::move(out));
                }
                case NVMAP_FREE: {
                    uint32_t handle{};
                    if (!get_u32(r.payload, 8, handle)) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    put_u32(out.payload, nvmap_.erase(handle) ? OK : ERR_INVAL);
                    return R::Ok(std::move(out));
                }
                case SYNCPT_READ: {
                    uint32_t id{};
                    if (!get_u32(r.payload, 8, id) || id >= kSyncpts) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    put_u32(out.payload, OK);
                    put_u32(out.payload, syncpts_[id]);
                    return R::Ok(std::move(out));
                }
                case SYNCPT_INCR: {
                    uint32_t id{};
                    if (!get_u32(r.payload, 8, id) || id >= kSyncpts) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    ++syncpts_[id];
                    put_u32(out.payload, OK);
                    return R::Ok(std::move(out));
                }
                case SUBMIT: {
                    uint32_t id{};
                    if (!get_u32(r.payload, 8, id) || id >= kSyncpts) { put_u32(out.payload, ERR_INVAL); return R::Ok(std::move(out)); }
                    ++syncpts_[id];
                    put_u32(out.payload, OK);
                    put_u32(out.payload, syncpts_[id]);   // fence = post-increment value
                    return R::Ok(std::move(out));
                }
                default:
                    put_u32(out.payload, ERR_NOTTY);
                    return R::Ok(std::move(out));
            }
        }
        case 2: { // Close <- u32 fd
            uint32_t fd{};
            if (!get_u32(r.payload, 0, fd)) return R::Error("nvdrv Close: short payload");
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u32(out.payload, open_fds_.erase(fd) ? OK : ERR_BADF);
            return R::Ok(std::move(out));
        }
        case 3: { // QueryEvent <- [u32 fd][u32 event_id]
            uint32_t fd{}, event_id{};
            if (!get_u32(r.payload, 0, fd) || !get_u32(r.payload, 4, event_id))
                return R::Error("nvdrv QueryEvent: short payload");
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            if (open_fds_.find(fd) == open_fds_.end()) {
                put_u32(out.payload, 0);       // handle
                put_u32(out.payload, ERR_BADF);
                return R::Ok(std::move(out));
            }
            put_u32(out.payload, fd * 1000u + event_id);  // deterministic non-zero event handle
            put_u32(out.payload, OK);
            return R::Ok(std::move(out));
        }
        default:
            return R::Error("nvdrv: unknown command");
    }
}

size_t NvDrvService::open_fd_count() const {
    std::lock_guard lock(mutex_);
    return open_fds_.size();
}

uint32_t NvDrvService::syncpt(uint32_t id) const {
    std::lock_guard lock(mutex_);
    return id < kSyncpts ? syncpts_[id] : 0;
}

std::unique_ptr<IpcEndpoint> make_nvdrv_service() { return std::make_unique<NvDrvService>(); }

} // namespace lg::system
