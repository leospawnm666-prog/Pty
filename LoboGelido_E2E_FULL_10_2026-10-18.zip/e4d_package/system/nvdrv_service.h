#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include "ipc.h"

// HLE of the Switch NVIDIA driver interface (nvdrv / nn::nvhost) over the simplified
// IpcMessage transport.
//
// SCOPE: real nvdrv opens device nodes (/dev/nvmap, /dev/nvhost-gpu, ...) and drives
// them with binary ioctls carrying large structs, plus syncpoint events. This models
// the OBSERVABLE bookkeeping a driver adapter maintains — file descriptors, nvmap
// allocations (handle -> size) and syncpoints — with a small, representative ioctl
// set. It performs no GPU work and touches no protected content; it lets a guest that
// opens the driver, allocates an nvmap handle and reads/increments a syncpoint get
// coherent, deterministic responses.
//
//   0 Open       <- [utf8 device_path]                 -> [u32 fd][u32 status]
//   1 Ioctl      <- [u32 fd][u32 code][in...]          -> [u32 status][out...]
//   2 Close      <- [u32 fd]                           -> [u32 status]
//   3 QueryEvent <- [u32 fd][u32 event_id]             -> [u32 handle][u32 status]
//
// Ioctl codes (simplified/functional):
//   0x01 NVMAP_CREATE       in [u32 size]   -> out [u32 handle]
//   0x02 NVMAP_ALLOC        in [u32 handle]
//   0x03 NVMAP_PARAM (size) in [u32 handle] -> out [u32 size]
//   0x04 NVMAP_FREE         in [u32 handle]
//   0x10 SYNCPT_READ        in [u32 id]     -> out [u32 value]
//   0x11 SYNCPT_INCR        in [u32 id]
//   0x12 SUBMIT             in [u32 id]     -> out [u32 fence]   (increments, returns new value)
//
// status: 0 OK, 2 ENOENT (bad device), 9 EBADF (bad fd), 22 EINVAL, 25 ENOTTY.
// A nonzero status is a normal driver-level result carried in the reply (Ok); only a
// short payload or unknown command is a core::Result error.

namespace lg::system {

class NvDrvService final : public IpcEndpoint {
public:
    static constexpr uint32_t kSyncpts = 32;

    // status codes (named ERR_* to avoid the <cerrno> macros ENOENT/EBADF/EINVAL/ENOTTY)
    static constexpr uint32_t OK = 0;
    static constexpr uint32_t ERR_NOENT = 2;   // bad device
    static constexpr uint32_t ERR_BADF = 9;    // bad fd
    static constexpr uint32_t ERR_INVAL = 22;  // bad argument/handle
    static constexpr uint32_t ERR_NOTTY = 25;  // unsupported ioctl

    // ioctl codes
    static constexpr uint32_t NVMAP_CREATE = 0x01;
    static constexpr uint32_t NVMAP_ALLOC = 0x02;
    static constexpr uint32_t NVMAP_PARAM = 0x03;
    static constexpr uint32_t NVMAP_FREE = 0x04;
    static constexpr uint32_t SYNCPT_READ = 0x10;
    static constexpr uint32_t SYNCPT_INCR = 0x11;
    static constexpr uint32_t SUBMIT = 0x12;

    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

    // Introspection (diagnostics/tests).
    size_t open_fd_count() const;
    uint32_t syncpt(uint32_t id) const;   // 0 if id out of range

private:
    mutable std::mutex mutex_;
    std::unordered_set<uint32_t> open_fds_;
    std::unordered_map<uint32_t, uint32_t> nvmap_;   // handle -> size
    std::array<uint32_t, kSyncpts> syncpts_{};
    uint32_t next_fd_{1};
    uint32_t next_handle_{1};

    static bool known_device(const std::string& path);
};

std::unique_ptr<IpcEndpoint> make_nvdrv_service();

} // namespace lg::system
