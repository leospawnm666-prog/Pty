#pragma once
// P3.1: per-process kernel handle table (Horizon semantics, P3_1_DISENO.md §2.5).
//
// A handle is a u32: index (bits 0-14, from 1) | generation (bits 15-29, never 0).
//  - it is never 0 (INVALID_HANDLE) and never >= 0xFFFF8000 (pseudo-handle range);
//  - closing a handle bumps its slot's generation, so a stale copy of a closed handle stays
//    invalid even after the slot is reused.
// Pseudo-handles (0xFFFF8000 = current thread, 0xFFFF8001 = current process) are resolved by
// resolve() and are never stored in, nor removable from, the table.
//
// In P3.1 the table stores {type, id} references (the main thread, processes); the kernel
// objects themselves (events, sessions, ...) arrive with P3.3/P3.4.
// Not internally synchronised: used on the guest-execution thread under the coordinator lock.
#include <cstdint>
#include <optional>
#include <vector>

namespace lg::system {

enum class KObjectType : uint8_t { None, Thread, Process, Event /* P3.3: writable */, ReadableEvent /* P3.3 */,
                                   ClientSession /* P3.4 */, ServerSession, ClientPort, ServerPort /* reserved (guest servers) */,
                                   // P6.0 (P6_DISENO.md §3.1): the memory objects and the resource limit
                                   SharedMemory, TransferMemory, CodeMemory, ResourceLimit,
                                   // P6.0: system objects of the one-process model
                                   Debug, DeviceAddressSpace, IoPool, IoRegion, InterruptEvent, LightClientSession,
                                   LightServerSession };

struct KObjectRef {
    KObjectType type{KObjectType::None};
    uint64_t id{};
    bool operator==(const KObjectRef& o) const noexcept { return type == o.type && id == o.id; }
};

class HandleTable {
public:
    static constexpr uint32_t kCapacity = 1024;
    static constexpr uint32_t kInvalidHandle = 0;
    static constexpr uint32_t kCurrentThread = 0xFFFF8000u;
    static constexpr uint32_t kCurrentProcess = 0xFFFF8001u;
    static constexpr uint32_t kIndexBits = 15;
    static constexpr uint32_t kIndexMask = (1u << kIndexBits) - 1;
    static constexpr uint32_t kGenerationMask = (1u << 15) - 1;

    HandleTable();

    /** New handle for `object`; nullopt when the table is full (Horizon: OutOfHandles) or the
     *  object is None. */
    std::optional<uint32_t> add(KObjectRef object);
    /** The object behind a stored handle; nullptr for 0, pseudo-handles, closed or stale
     *  handles. */
    const KObjectRef* get(uint32_t handle) const noexcept;
    /** Pseudo-handles resolved against the calling thread/process, then the table. */
    std::optional<KObjectRef> resolve(uint32_t handle, uint64_t current_thread, uint64_t current_process) const noexcept;
    /** Closes a stored handle. false for 0, pseudo-handles, closed or stale handles. */
    bool close(uint32_t handle) noexcept;
    size_t size() const noexcept { return used_; }
    /** Drops every handle (session end). Generations keep counting, so handles from a
     *  previous session never become valid again by accident. */
    void clear() noexcept;

    static constexpr bool is_pseudo(uint32_t handle) noexcept { return handle >= 0xFFFF8000u; }

private:
    struct Slot { KObjectRef object{}; uint16_t generation{1}; bool used{}; };
    static constexpr uint32_t make(uint32_t index, uint32_t generation) noexcept {
        return index | (generation << kIndexBits);
    }
    const Slot* slot_of(uint32_t handle) const noexcept;
    void bump(Slot& s) noexcept;

    std::vector<Slot> slots_;         // [1, kCapacity]; slot 0 is never used
    std::vector<uint32_t> free_;      // free indices (LIFO: a closed index is reused first)
    size_t used_{};
};

} // namespace lg::system
