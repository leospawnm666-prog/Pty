#include "vi_service.h"

#include <string>

namespace lg::system {
namespace {

void put_u32(std::vector<uint8_t>& p, uint32_t v) {
    for (int i = 0; i < 4; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
void put_i32(std::vector<uint8_t>& p, int32_t v) { put_u32(p, static_cast<uint32_t>(v)); }
void put_u64(std::vector<uint8_t>& p, uint64_t v) {
    for (int i = 0; i < 8; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
bool get_u64(const std::vector<uint8_t>& p, size_t off, uint64_t& out) {
    if (off + 8 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 8; ++i) out |= static_cast<uint64_t>(p[off + i]) << (8 * i);
    return true;
}
IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }

using R = core::Result<IpcMessage>;

} // namespace

core::Result<IpcMessage> ViService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // ListDisplays
            IpcMessage out = reply(r.command_id);
            put_u32(out.payload, server_->display_count());
            return R::Ok(std::move(out));
        }
        case 1: { // OpenDisplay <- utf8 name
            std::string name(r.payload.begin(), r.payload.end());
            const uint64_t id = server_->open_display(name);
            if (id == 0) return R::Error("vi OpenDisplay: unknown display name");
            IpcMessage out = reply(r.command_id);
            put_u64(out.payload, id);
            return R::Ok(std::move(out));
        }
        case 2: { // CloseDisplay <- u64 id
            uint64_t id{};
            if (!get_u64(r.payload, 0, id)) return R::Error("vi CloseDisplay: short payload");
            if (!server_->close_display(id)) return R::Error("vi CloseDisplay: unknown display");
            return R::Ok(reply(r.command_id));
        }
        case 3: { // GetDisplayResolution <- u64 id
            uint64_t id{};
            if (!get_u64(r.payload, 0, id)) return R::Error("vi GetDisplayResolution: short payload");
            if (!server_->display_valid(id)) return R::Error("vi GetDisplayResolution: unknown display");
            IpcMessage out = reply(r.command_id);
            put_u32(out.payload, DisplayServer::kWidth);
            put_u32(out.payload, DisplayServer::kHeight);
            return R::Ok(std::move(out));
        }
        case 4: { // OpenLayer <- u64 display_id
            uint64_t id{};
            if (!get_u64(r.payload, 0, id)) return R::Error("vi OpenLayer: short payload");
            const uint64_t layer = server_->create_layer(id);
            if (layer == 0) return R::Error("vi OpenLayer: unknown display");
            IpcMessage out = reply(r.command_id);
            put_u64(out.payload, layer);
            return R::Ok(std::move(out));
        }
        case 5: { // CloseLayer <- u64 layer_id
            uint64_t layer{};
            if (!get_u64(r.payload, 0, layer)) return R::Error("vi CloseLayer: short payload");
            if (!server_->destroy_layer(layer)) return R::Error("vi CloseLayer: unknown layer");
            return R::Ok(reply(r.command_id));
        }
        case 6: { // SetLayerScalingMode <- u64 layer_id, u32 mode
            uint64_t layer{}; uint32_t mode{};
            if (!get_u64(r.payload, 0, layer) || !get_u32(r.payload, 8, mode))
                return R::Error("vi SetLayerScalingMode: short payload");
            if (!server_->set_scaling_mode(layer, mode)) return R::Error("vi SetLayerScalingMode: unknown layer");
            return R::Ok(reply(r.command_id));
        }
        case 7: { // GetDisplayVsyncEvent <- u64 display_id
            uint64_t id{};
            if (!get_u64(r.payload, 0, id)) return R::Error("vi GetDisplayVsyncEvent: short payload");
            if (!server_->display_valid(id)) return R::Error("vi GetDisplayVsyncEvent: unknown display");
            IpcMessage out = reply(r.command_id);
            put_u64(out.payload, server_->vsync_count(id));
            return R::Ok(std::move(out));
        }
        case 8: { // SignalVsync <- u64 display_id (Lobo extension)
            uint64_t id{};
            if (!get_u64(r.payload, 0, id)) return R::Error("vi SignalVsync: short payload");
            if (!server_->signal_vsync(id)) return R::Error("vi SignalVsync: unknown display");
            return R::Ok(reply(r.command_id));
        }
        default:
            return R::Error("vi: unknown command");
    }
}

core::Result<IpcMessage> DispdrvService::dispatch(const IpcMessage& r) {
    // All commands operate on a layer id in the first 8 bytes.
    uint64_t layer{};
    if (!get_u64(r.payload, 0, layer)) return R::Error("dispdrv: short payload (layer id)");
    if (!server_->layer_valid(layer)) return R::Error("dispdrv: unknown layer");

    switch (r.command_id) {
        case 0: { // DequeueBuffer -> i32 slot (-1 = none free)
            IpcMessage out = reply(r.command_id);
            put_i32(out.payload, server_->dequeue(layer));
            return R::Ok(std::move(out));
        }
        case 1: { // QueueBuffer <- u32 slot
            uint32_t slot{};
            if (!get_u32(r.payload, 8, slot)) return R::Error("dispdrv QueueBuffer: short payload");
            if (!server_->queue(layer, slot)) return R::Error("dispdrv QueueBuffer: slot not dequeued");
            return R::Ok(reply(r.command_id));
        }
        case 2: { // CancelBuffer <- u32 slot
            uint32_t slot{};
            if (!get_u32(r.payload, 8, slot)) return R::Error("dispdrv CancelBuffer: short payload");
            if (!server_->cancel(layer, slot)) return R::Error("dispdrv CancelBuffer: slot not dequeued");
            return R::Ok(reply(r.command_id));
        }
        case 3: { // AcquireBuffer -> i32 slot (-1 = none queued)
            IpcMessage out = reply(r.command_id);
            put_i32(out.payload, server_->acquire(layer));
            return R::Ok(std::move(out));
        }
        case 4: { // ReleaseBuffer <- u32 slot
            uint32_t slot{};
            if (!get_u32(r.payload, 8, slot)) return R::Error("dispdrv ReleaseBuffer: short payload");
            if (!server_->release(layer, slot)) return R::Error("dispdrv ReleaseBuffer: slot not acquired");
            return R::Ok(reply(r.command_id));
        }
        case 5: { // GetBufferCount -> u32
            IpcMessage out = reply(r.command_id);
            put_u32(out.payload, server_->buffer_count(layer));
            return R::Ok(std::move(out));
        }
        case 6: { // SetBufferCount <- u32 count
            uint32_t count{};
            if (!get_u32(r.payload, 8, count)) return R::Error("dispdrv SetBufferCount: short payload");
            if (!server_->set_buffer_count(layer, count))
                return R::Error("dispdrv SetBufferCount: invalid count or queue busy");
            return R::Ok(reply(r.command_id));
        }
        case 7: { // PresentedFrames -> u64
            IpcMessage out = reply(r.command_id);
            put_u64(out.payload, server_->presented_frames(layer));
            return R::Ok(std::move(out));
        }
        default:
            return R::Error("dispdrv: unknown command");
    }
}

std::shared_ptr<DisplayServer> make_display_server() {
    return std::make_shared<DisplayServer>();
}
std::unique_ptr<IpcEndpoint> make_vi_service(std::shared_ptr<DisplayServer> server) {
    return std::make_unique<ViService>(std::move(server));
}
std::unique_ptr<IpcEndpoint> make_dispdrv_service(std::shared_ptr<DisplayServer> server) {
    return std::make_unique<DispdrvService>(std::move(server));
}

} // namespace lg::system
