#pragma once
// P3.1: the Horizon system-call table (P3_1_DISENO.md §2.2).
//
// 0xC0 entries (0x00-0xBF), one per SVC number, named after libnx's svc.s (146c3d1). Each
// entry has a class that says what the call does to the calling thread, and a handler when
// Lobo implements it. Everything else is "not implemented" and FATAL (P3 decision D3): a
// call is never answered with an invented success. An id >= 0xC0 is invalid and fatal too.
//
// The homebrew ABI's SyscallAvailableHint/Hint2 entries are generated from this table
// (syscall_hint_word), so they can never claim an SVC that Lobo does not implement.
#include <array>
#include <cstdint>
#include <string>

#include "../cpu/interpreter.h"

namespace lg::system {

class SvcDispatcher;

/** What an SVC does to the calling thread (planning attribute; dispatch is decided by the
 *  handler). */
enum class SvcClass : uint8_t {
    Immediate,       // answers at once (most calls)
    Blocking,        // may put the thread to sleep/wait (P3.3/P3.4)
    Terminal,        // ends the thread or the process
    Neutral,         // no guest-visible effect besides the result (cache maintenance, debug output)
    Unimplemented,   // reserved/unassigned number: never implemented
};

/** One SVC being serviced. `ctx` is the calling thread's register file. */
struct SvcCall {
    uint64_t thread{};
    cpu::CpuState& ctx;
    uint32_t id{};
    uint64_t pc{};    // address of the SVC instruction
};

/** What the coordinator must do after the handler ran. */
struct SvcOutcome {
    enum class Kind : uint8_t {
        Continue,      // the thread resumes at pc + 4 on its next turn
        Block,         // P3.3: the thread now waits; it resumes at pc + 4 once woken
        ExitThread,    // P3.3: the calling thread ended (other threads go on)
        ExitProcess,   // every thread ends; the session closes cleanly
        Fatal,         // guest error: the session goes to Error with `message`
    };
    Kind kind{Kind::Continue};
    std::string message;
    static SvcOutcome resume() { return {}; }
    static SvcOutcome block() { return {Kind::Block, {}}; }   // P3.3
    static SvcOutcome fatal(std::string m) { return {Kind::Fatal, std::move(m)}; }
};

using SvcHandler = SvcOutcome (*)(SvcDispatcher&, SvcCall&);

struct SvcEntry {
    uint32_t id{};
    const char* name{};       // libnx name without the "svc" prefix ("OutputDebugString")
    SvcClass klass{SvcClass::Unimplemented};
    SvcHandler handler{};     // nullptr = not implemented (fatal)
};

constexpr uint32_t kSvcCount = 0xC0;

const std::array<SvcEntry, kSvcCount>& svc_table() noexcept;
/** nullptr for id >= 0xC0. */
const SvcEntry* svc_entry(uint32_t id) noexcept;
bool svc_implemented(uint32_t id) noexcept;
/** Bit n of word w is set iff SVC (64 * w + n) is implemented. w = 0, 1 -> SyscallAvailableHint
 *  Value[0], Value[1]; w = 2 -> SyscallAvailableHint2 Value[0]. 0 for w > 2. */
uint64_t syscall_hint_word(unsigned word) noexcept;

// Horizon kernel Result codes used by P3.1 (module 1, description << 9).
namespace kresult {
constexpr uint32_t Success = 0;
constexpr uint32_t OutOfHandles = 0xD201;         // 105
constexpr uint32_t InvalidHandle = 0xE401;        // 114
constexpr uint32_t InvalidPointer = 0xE601;       // 115 (InvalidUserBuffer in libnx)
constexpr uint32_t InvalidCombination = 0xE801;   // 116
constexpr uint32_t OutOfRange = 0xEE01;           // 119
constexpr uint32_t InvalidEnumValue = 0xF001;     // 120
} // namespace kresult

} // namespace lg::system
