#include "pl_service.h"

namespace lg::system {
namespace {
// Nominal, deterministic per-font sizes (bytes) for the HLE metadata. Real pl:u
// reports the true sizes of the font blobs it maps into shared memory.
constexpr std::array<uint32_t, PlService::kFontCount> kFontSizes = {
    0x0011C000, // Standard
    0x001B0000, // ChineseSimplified
    0x00190000, // ExtChineseSimplified
    0x001F0000, // ChineseTraditional
    0x00170000, // KOrean
    0x00008000  // NintendoExtension
};

void put_u32(std::vector<uint8_t>& p, uint32_t v) {
    for (int i = 0; i < 4; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
uint32_t font_offset(uint32_t type) {
    uint32_t offset = 0;
    for (uint32_t i = 0; i < type; ++i) offset += kFontSizes[i];
    return offset;
}
IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }
} // namespace

core::Result<IpcMessage> PlService::dispatch(const IpcMessage& r) {
    uint32_t type{};
    const bool has_type = get_u32(r.payload, 0, type);
    const bool type_ok = has_type && type < kFontCount;

    switch (r.command_id) {
        case 0: { // RequestLoad
            if (!type_ok) return core::Result<IpcMessage>::Error("pl:u RequestLoad: invalid font type");
            { std::lock_guard lock(mutex_); loaded_[type] = 1; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        case 1: { // GetLoadState
            if (!type_ok) return core::Result<IpcMessage>::Error("pl:u GetLoadState: invalid font type");
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u32(out.payload, loaded_[type]);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 2: { // GetSize
            if (!type_ok) return core::Result<IpcMessage>::Error("pl:u GetSize: invalid font type");
            IpcMessage out = reply(r.command_id);
            put_u32(out.payload, kFontSizes[type]);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 3: { // GetSharedMemoryAddressOffset
            if (!type_ok) return core::Result<IpcMessage>::Error("pl:u GetSharedMemoryAddressOffset: invalid font type");
            IpcMessage out = reply(r.command_id);
            put_u32(out.payload, font_offset(type));
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        default:
            return core::Result<IpcMessage>::Error("pl:u: unknown command");
    }
}

std::unique_ptr<IpcEndpoint> make_pl_service() { return std::make_unique<PlService>(); }

} // namespace lg::system
