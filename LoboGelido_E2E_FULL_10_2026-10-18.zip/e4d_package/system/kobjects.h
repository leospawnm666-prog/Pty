#pragma once
// P6.0 (P6_DISENO.md §3.1): the guest kernel's memory objects and resource limit.
//
// KSharedMemory (CreateSharedMemory, or created by an HLE service), KTransferMemory
// (CreateTransferMemory: the owner's pages locked and lent), KCodeMemory (CreateCodeMemory:
// heap pages locked and mapped again as code and as its writable owner view) and the process's
// KResourceLimit. Behaviour (validation order, Result codes, page-table states) follows the
// Horizon kernel as Atmosphère's mesosphere documents it (kern_svc_shared_memory.cpp,
// kern_k_transfer_memory.cpp, kern_svc_code_memory.cpp, kern_svc_resource_limit.cpp), the same
// reference as P3.2; the code is Lobo's own.
//
// The objects' lifetime: one reference per handle; a shared memory mapping holds one more
// (Horizon's KProcess::AddSharedMemory); the object dies with its last reference.
// Not internally synchronised: the guest-execution thread, under the coordinator lock.
#include <array>
#include <cstdint>
#include <functional>
#include <map>
#include <optional>
#include <vector>

#include "handle_table.h"
#include "vm_manager.h"
#include "../memory/address_space.h"

namespace lg::system {

/** svc::LimitableResource. */
enum class LimitableResource : uint32_t { PhysicalMemoryMax = 0, ThreadCountMax, EventCountMax, TransferMemoryCountMax,
                                          SessionCountMax, Count };

struct KernelObjectsConfig {
    uint64_t process_id{};
    HandleTable* handles{};
    VmManager* vm{};
    memory::AddressSpace* memory{};   // host access to the objects' pages (HLE services)
    /** Current counts the resource limit reports for threads, events and sessions (the
     *  kernel parts that own them); memory and transfer memories are counted here. */
    std::function<int64_t(LimitableResource)> current_count;
    /** Limits of the process's resource limit (D-P6.0-4: the emulator's own capacities). */
    std::array<int64_t, 5> limits{};
};

class KernelObjects {
public:
    static constexpr uint32_t PermDontCare = 1u << 28;   // svc::MemoryPermission_DontCare

    void reset() noexcept;
    bool begin(const KernelObjectsConfig& config);
    bool active() const noexcept { return active_; }

    // ---- SVCs (Result code; outputs by reference) ----------------------------------------
    uint32_t create_shared_memory(uint64_t size, uint32_t owner_perm, uint32_t remote_perm, uint32_t& out_handle);
    uint32_t map_shared_memory(uint32_t handle, uint64_t address, uint64_t size, uint32_t perm);
    uint32_t unmap_shared_memory(uint32_t handle, uint64_t address, uint64_t size);
    uint32_t create_transfer_memory(uint64_t address, uint64_t size, uint32_t perm, uint32_t& out_handle);
    uint32_t map_transfer_memory(uint32_t handle, uint64_t address, uint64_t size, uint32_t perm);
    uint32_t unmap_transfer_memory(uint32_t handle, uint64_t address, uint64_t size);
    uint32_t create_code_memory(uint64_t address, uint64_t size, uint32_t& out_handle);
    uint32_t control_code_memory(uint32_t handle, uint32_t operation, uint64_t address, uint64_t size, uint32_t perm);
    uint32_t create_resource_limit(uint32_t& out_handle);
    uint32_t get_resource_limit_value(uint32_t handle, uint32_t which, int kind /*0 limit 1 current 2 peak*/, int64_t& out);
    uint32_t set_resource_limit_value(uint32_t handle, uint32_t which, int64_t value);
    /** GetInfo(ResourceLimit): a new handle to the process's resource limit. */
    uint32_t open_process_resource_limit(uint32_t& out_handle);
    /** limit - current of the process's resource limit (GetInfo FreeThreadCount). */
    int64_t process_limit_free(LimitableResource r) const;
    /** Reserve / release against the process limit (CreateTransferMemory, the HLE side). */
    bool reserve(LimitableResource r, int64_t amount);
    void release(LimitableResource r, int64_t amount);

    void on_handle_closed(const KObjectRef& object);

    // ---- HLE services --------------------------------------------------------------------
    /** A shared memory owned by a system service (owner = the host): the guest maps it with
     *  `remote_perm`; the service writes it through host_view(). 0 if out of memory. */
    uint64_t create_host_shared_memory(uint64_t size, uint32_t remote_perm);
    /** A handle (one reference) to an object, for a copy handle of an IPC reply. */
    std::optional<uint32_t> add_handle(KObjectType type, uint64_t id);
    /** P6.0: one more reference for a handle someone else added (IPC copy handles). */
    bool add_ref(const KObjectRef& object);
    /** Host pointer to byte `offset` of a shared memory's pages; nullptr out of range. Pages
     *  are 64 KiB granules or less, so callers write within one page run at a time
     *  (shared_write/shared_read do it for them). */
    bool shared_write(uint64_t id, uint64_t offset, const void* data, uint64_t size);
    bool shared_read(uint64_t id, uint64_t offset, void* data, uint64_t size) const;
    uint64_t shared_size(uint64_t id) const;
    /** The transfer memory behind a handle the guest sent (copy handle): its id, size and the
     *  owner's address. nullopt for anything else. */
    struct TransferInfo { uint64_t id, address, size; uint32_t owner_perm; };
    std::optional<TransferInfo> transfer_from_handle(uint32_t handle) const;
    bool transfer_read(uint64_t id, uint64_t offset, void* data, uint64_t size) const;
    bool transfer_write(uint64_t id, uint64_t offset, const void* data, uint64_t size);
    /** A service keeps a transfer memory (one reference) until release_transfer(). */
    bool retain_transfer(uint64_t id);
    void release_transfer(uint64_t id);

    // ---- diagnostics / tests --------------------------------------------------------------
    size_t shared_count() const noexcept { return shared_.size(); }
    size_t transfer_count() const noexcept { return transfer_.size(); }
    size_t code_count() const noexcept { return code_.size(); }
    size_t limit_count() const noexcept { return limits_.size(); }
    /** "" when references, mappings and page groups agree. */
    std::string check_invariants() const;

private:
    struct Shared {
        uint64_t size{};
        VmManager::PageGroup pages;
        uint32_t owner_perm{}, remote_perm{};
        bool host_owned{};
        uint32_t refs{};
        std::vector<std::pair<uint64_t, uint64_t>> mappings;   // (address, size) in the process
    };
    struct Transfer {
        uint64_t address{}, size{};
        uint32_t owner_perm{};
        VmManager::PageGroup pages;   // the owner's pages (not owned)
        bool mapped{};
        uint64_t mapped_at{};
        uint32_t refs{};
    };
    struct Code {
        uint64_t address{}, size{};
        VmManager::PageGroup pages;
        bool owner_mapped{}, slave_mapped{};
        uint64_t owner_at{}, slave_at{};
        uint32_t refs{};
    };
    struct Limit {
        std::array<int64_t, 5> limit{}, current{}, peak{};
        uint32_t refs{};
    };

    uint32_t add_object_handle(KObjectType type, uint64_t id, uint32_t& out);
    template <class T> T* find(std::map<uint64_t, T>& m, uint32_t handle, KObjectType type);
    void destroy_shared_if_unused(uint64_t id);
    void destroy_transfer(uint64_t id);
    void destroy_code_if_unused(uint64_t id);
    static bool host_rw(memory::AddressSpace& mem, const VmManager::PageGroup& g, uint64_t offset, void* data, uint64_t size,
                        bool write);

    KernelObjectsConfig config_{};
    bool active_{false};
    uint64_t next_id_{1};
    std::map<uint64_t, Shared> shared_;
    std::map<uint64_t, Transfer> transfer_;
    std::map<uint64_t, Code> code_;
    std::map<uint64_t, Limit> limits_;
    uint64_t process_limit_{};   // id of the process's resource limit
};

} // namespace lg::system
