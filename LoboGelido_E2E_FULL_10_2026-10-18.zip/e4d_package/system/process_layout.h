#pragma once
// P3.0: address-space layout of a process built from a real executable (today: a real
// homebrew NRO). 36-bit layout (P3 decision D4): everything lies inside the 2^36 fastmem
// window of phase E.2b. Every region is 64 KiB aligned so that, with 16 KiB host pages,
// VA and PA share the same host-page phase and the fastmem window can map whole pages.
//
//   0x0800_0000  image: .text R-X | .rodata R | .data+.bss RW   (contiguous, like nx-hbloader)
//   0x4000_0000  64 KiB guard (unmapped)
//   0x4001_0000  main stack, 1 MiB RW (hbloader's main_thread_stack_size)
//   0x4011_0000  64 KiB guard (unmapped)
//   0x4012_0000  TLS page of the main thread, 4 KiB RW (TPIDRRO_EL0)
//   0x4014_0000  P3.1 exit stub, 4 KiB R-X: "svc #0x07 ; b ." (homebrew return address)
//   0x4016_0000  P3.1 loader configuration page, 4 KiB RW (ConfigEntry list + argv)
//   0x1_0000_0000 heap region (6 GiB of VA, unmapped until P3.2)
//   0x2_8000_0000 alias region (16 GiB of VA, unmapped until P3.2)
//
// Physical memory comes from the guest arena (phase D) through a bump allocator; the Mmu
// maps VA -> PA without identity. The arena is freshly zeroed by AddressSpace::map() on
// every prepare(), so .bss, the stack and the TLS are NOT written here (that would only
// raise RSS).
#include <array>
#include <cstdint>
#include <vector>
#include "../core/result.h"
#include "../loader/nro_loader.h"
#include "../loader/nso_loader.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"

namespace lg::system {

struct ProcessLayout {
    static constexpr uint64_t kAlign = 0x10000;                // 64 KiB
    static constexpr uint64_t kCodeBase = 0x0800'0000ull;
    static constexpr uint64_t kAslrBase = 0x0800'0000ull;
    static constexpr uint64_t kAslrEnd = 0x10'0000'0000ull;    // 2^36 (fastmem window)
    static constexpr uint64_t kStackRegion = 0x4000'0000ull;
    static constexpr uint64_t kStackRegionSize = 0x4000'0000ull;   // 1 GiB
    static constexpr uint64_t kGuardSize = 0x10000;
    static constexpr uint64_t kMainStackSize = 0x100000;          // 1 MiB (hbl.json)
    static constexpr uint64_t kTlsPageSize = 0x1000;
    static constexpr uint64_t kHeapRegion = 0x1'0000'0000ull;
    static constexpr uint64_t kHeapRegionSize = 0x1'8000'0000ull;  // 6 GiB of VA
    static constexpr uint64_t kAliasRegion = 0x2'8000'0000ull;
    static constexpr uint64_t kAliasRegionSize = 0x4'0000'0000ull; // 16 GiB of VA
    static constexpr uint8_t kMainThreadPriorityHz = 44;           // hbl.json
    // P3.1 (P3_1_DISENO.md §2.6): two more pages, each taking 64 KiB of the arena.
    static constexpr uint64_t kExitStubVa = 0x4014'0000ull;
    static constexpr uint64_t kConfigVa = 0x4016'0000ull;
    static constexpr uint64_t kSmallPageSize = 0x1000;
    static constexpr uint32_t kExitStubCode[2] = {0xD40000E1u, 0x14000000u};   // svc #0x07 ; b .

    uint64_t code_va{};        // image base = entry point
    uint64_t image_pa{};
    uint64_t mapped_size{};    // image + bss (4 KiB rounded)
    uint64_t stack_bottom_va{};
    uint64_t stack_top_va{};   // initial SP (16-byte aligned)
    uint64_t stack_pa{};
    uint64_t tls_va{};         // initial TPIDRRO_EL0
    uint64_t tls_pa{};
    uint64_t arena_used{};     // bytes of the arena taken by this layout
    uint64_t exit_stub_va{};   // P3.1: homebrew return address (x30 at entry of an NRO)
    uint64_t exit_stub_pa{};
    uint64_t config_va{};      // P3.1: loader configuration page (x0 at entry of an NRO)
    uint64_t config_pa{};
    /** P3.2: the image regions as mapped (.text, .rodata, .data+.bss; offsets from code_va,
     *  memory:: permissions; size 0 = not mapped). The VmManager seeds its blocks from them. */
    struct ImageRegion { uint64_t offset{}, size{}; uint32_t perms{}; };
    std::array<ImageRegion, 3> image_regions{};
};

/** Horizon priority (0 = highest .. 63 = lowest) -> Lobo ThreadManager priority (higher
 *  number wins). 0 -> 127, 44 -> 83, 63 -> 64 (the value the synthetic path already uses).
 *  Out-of-range input is clamped to 63. */
constexpr uint8_t hz_to_lobo_priority(uint8_t hz) noexcept {
    return static_cast<uint8_t>(127u - (hz > 63u ? 63u : hz));
}

/** Bump allocator over [base, base + size) of the guest arena (physical addresses). */
class PhysicalArenaAllocator {
public:
    PhysicalArenaAllocator(uint64_t base, uint64_t size) noexcept : base_(base), size_(size) {}
    /** Reserves `bytes` rounded up to 64 KiB, 64 KiB aligned. Error if it does not fit. */
    core::Result<uint64_t> allocate(uint64_t bytes) noexcept;
    uint64_t used() const noexcept { return next_; }
private:
    uint64_t base_{}, size_{}, next_{};
};

/** Places a validated NRO: copies file bytes [0, image_size) to fresh arena memory and maps
 *  the image, the main stack and the main TLS page in `mmu` (which the caller has cleared).
 *  `image` must come from loader::NroLoader::parse(`file`). Nothing is mapped on error. */
core::Result<ProcessLayout> build_nro_process(const loader::NroImage& image, const std::vector<uint8_t>& file,
                                              memory::AddressSpace& memory, memory::Mmu& mmu,
                                              uint64_t arena_base, uint64_t arena_size);

/** P3.0-A: places a real plaintext NSO (from loader::NsoLoader::parse) with the same map as
 *  an NRO: segments at kCodeBase + mem_off, page-rounded (NsoLoader::layout), .bss zero
 *  through the fresh arena, main stack and TLS as above. Nothing is mapped on error. */
core::Result<ProcessLayout> build_nso_process(const loader::NsoImage& image, memory::AddressSpace& memory,
                                              memory::Mmu& mmu, uint64_t arena_base, uint64_t arena_size);

} // namespace lg::system
