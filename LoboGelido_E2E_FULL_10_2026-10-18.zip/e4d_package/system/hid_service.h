#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include "ipc.h"

// HLE of the Switch HID service (nn::hid) — controller state.
//
// SCOPE: real nn::hid exposes NPad state through shared memory and applet
// resources. The Lobo IpcMessage transport is a simplified request/response
// channel, so this endpoint models the CONTROLLER STATE a shared-memory adapter
// would publish: a 64-bit button mask plus two analog sticks. The frontend
// injects input via SetButton/SetAnalog; the guest reads it via GetControllerState.
// Thread-safe: the render/input threads and the guest poll concurrently.
//
// Button bit indices follow nn::hid::NpadButton:
//   0 A  1 B  2 X  3 Y  4 StickL  5 StickR  6 L  7 R  8 ZL  9 ZR
//   10 Plus 11 Minus 12 Left 13 Up 14 Right 15 Down
//
//   0 GetControllerState -> [u64 buttons][i32 lx][i32 ly][i32 rx][i32 ry]
//   1 SetButton          <- [u32 button_index][u32 pressed]
//   2 SetAnalog          <- [i32 lx][i32 ly][i32 rx][i32 ry]
//   3 GetNpadStyleSet    -> [u32 style]   (bit0 = Pro Controller)

namespace lg::system {

class HidService final : public IpcEndpoint {
public:
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

    // Frontend input injection. The guest-facing GetControllerState reads the same state.
    void set_button(uint32_t index, bool pressed) noexcept;
    void set_analog(int32_t lx, int32_t ly, int32_t rx, int32_t ry) noexcept;

    // Introspection (for diagnostics/tests).
    uint64_t buttons() const noexcept;

private:
    mutable std::mutex mutex_;
    uint64_t buttons_{0};
    int32_t lx_{0}, ly_{0}, rx_{0}, ry_{0};
    uint32_t style_set_{1}; // bit0 = Pro Controller
};

std::unique_ptr<IpcEndpoint> make_hid_service();

} // namespace lg::system
