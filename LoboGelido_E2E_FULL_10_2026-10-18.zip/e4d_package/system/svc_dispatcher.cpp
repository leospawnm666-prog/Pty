#include "svc_dispatcher.h"

#include <algorithm>
#include <cinttypes>
#include <cstdio>
#include <random>
#include <vector>

namespace lg::system {
namespace {
std::string hex(uint64_t v) {
    char b[24];
    std::snprintf(b, sizeof b, "0x%" PRIx64, v);
    return b;
}
void set_w0(cpu::CpuState& ctx, uint32_t result) noexcept { ctx.x[0] = result; }   // writing W0 zero-extends
} // namespace

// ---- GuestLog ---------------------------------------------------------------------------

void GuestLog::append(std::string_view text) {
    total_ += text.size();
    if (text.size() >= kCapacity) {
        buf_.assign(text.substr(text.size() - kCapacity));
        return;
    }
    buf_.append(text);
    if (buf_.size() > kCapacity) buf_.erase(0, buf_.size() - kCapacity);
}

std::string GuestLog::last_line(size_t max_chars) const {
    size_t end = buf_.size();
    while (end > 0 && (buf_[end - 1] == '\n' || buf_[end - 1] == '\r')) --end;
    const size_t nl = end == 0 ? std::string::npos : buf_.rfind('\n', end - 1);
    const size_t begin = nl == std::string::npos ? 0 : nl + 1;
    std::string out;
    for (size_t i = begin; i < end; ++i) {
        const auto c = static_cast<unsigned char>(buf_[i]);
        char piece[8];
        if (c == '"' || c == '\\') { piece[0] = '\\'; piece[1] = static_cast<char>(c); piece[2] = 0; }
        else if (c >= 0x20 && c < 0x7F) { piece[0] = static_cast<char>(c); piece[1] = 0; }
        else std::snprintf(piece, sizeof piece, "\\x%02X", c);
        const size_t n = std::char_traits<char>::length(piece);
        if (out.size() + n > max_chars) {
            while (out.size() + 3 > max_chars && !out.empty()) out.pop_back();
            out += "...";
            break;
        }
        out += piece;
    }
    return out;
}

// ---- SvcDispatcher ----------------------------------------------------------------------

void SvcDispatcher::begin_session(const SvcSessionConfig& config) {
    config_ = config;
    handles_.clear();
    log_.clear();
    exit_ = {};
    last_ = {};
    calls_.fill(0);
    total_calls_ = invalid_calls_ = break_notifications_ = 0;
    unsafe_limit_ = unsafe_used_ = 0;
}

void SvcDispatcher::end_session() noexcept {
    handles_.clear();
    config_.clock = nullptr;   // the clock dies with the session
}

std::array<uint64_t, 4> SvcDispatcher::fresh_entropy() {
    std::random_device rd;
    std::seed_seq seq{rd(), rd(), rd(), rd(), rd(), rd(), rd(), rd()};
    std::mt19937_64 gen(seq);
    return {gen(), gen(), gen(), gen()};
}

std::string SvcDispatcher::result_text(uint32_t result) {
    char b[16];
    std::snprintf(b, sizeof b, "%04u-%04u", 2000u + (result & 0x1FFu), (result >> 9) & 0x1FFFu);
    return b;
}

const char* SvcDispatcher::break_reason_name(uint32_t reason) noexcept {
    switch (reason & 0x7FFFFFFFu) {
        case 0: return "Panic";
        case 1: return "Assert";
        case 2: return "User";
        case 3: return "PreLoadDll";
        case 4: return "PostLoadDll";
        case 5: return "PreUnloadDll";
        case 6: return "PostUnloadDll";
        case 7: return "CppException";
    }
    return nullptr;
}

SvcOutcome SvcDispatcher::handle(uint64_t thread, cpu::CpuState& ctx) {
    const uint32_t id = ctx.exception.syndrome;
    const uint64_t pc = ctx.exception.address;
    last_ = {true, id, pc, thread, ctx.x[0], ctx.x[1]};
    ++total_calls_;
    const SvcEntry* e = svc_entry(id);
    if (!e) {
        ++invalid_calls_;
        return SvcOutcome::fatal("SVC " + hex(id) + " inválida @" + hex(pc));
    }
    ++calls_[id];
    if (!e->handler) {   // D3: never an invented success
        char b[16];
        std::snprintf(b, sizeof b, "0x%02X", id);
        return SvcOutcome::fatal(std::string("SVC ") + b + " (" + e->name + ") no implementada @" + hex(pc));
    }
    SvcCall call{thread, ctx, id, pc};
    SvcOutcome out = e->handler(*this, call);
    if (out.kind == SvcOutcome::Kind::Continue || out.kind == SvcOutcome::Kind::Block) {
        // P3.3: a Block leaves the thread ready to resume after the SVC; whoever ends its
        // wait writes the final result registers (KernelThreads::end_wait).
        ctx.pc = pc + 4;
        ctx.exception = {};
        ctx.halted = false;
        ctx.reservation_valid = false;
    }
    return out;
}

// ---- Handlers ---------------------------------------------------------------------------

SvcOutcome SvcHandlers::exit_process(SvcDispatcher& d, SvcCall& c) {
    // svcExitProcess carries no code (A6). A homebrew NRO that returns from its entry point
    // (libnx: exit(rc) -> __nx_exit -> br to the loader's return address with x0 = rc, A5)
    // lands on Lobo's exit stub, whose SVC is this one: then x0 is the code.
    const bool from_stub = d.config_.exit_stub_va != 0 && c.pc == d.config_.exit_stub_va;
    d.exit_ = {true, from_stub, from_stub ? static_cast<int32_t>(static_cast<uint32_t>(c.ctx.x[0])) : 0, c.pc};
    return {SvcOutcome::Kind::ExitProcess, {}};
}

SvcOutcome SvcHandlers::close_handle(SvcDispatcher& d, SvcCall& c) {
    const auto handle = static_cast<uint32_t>(c.ctx.x[0]);
    const KObjectRef* stored = d.handles_.get(handle);
    const KObjectRef object = stored ? *stored : KObjectRef{};
    const bool closed = d.handles_.close(handle);
    // P3.3: the kernel object loses the reference the handle held.
    if (closed && d.config_.kthreads && d.config_.kthreads->active()) d.config_.kthreads->on_handle_closed(object);
    if (closed && d.config_.ipc && d.config_.ipc->active()) d.config_.ipc->on_handle_closed(object);   // P3.4
    if (closed && d.config_.kobjects && d.config_.kobjects->active()) d.config_.kobjects->on_handle_closed(object);   // P6.0
    set_w0(c.ctx, closed ? kresult::Success : kresult::InvalidHandle);   // pseudo-handles too
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::get_system_tick(SvcDispatcher& d, SvcCall& c) {
    // The same clock as MRS CNTPCT_EL0 on every engine (P3.0).
    c.ctx.x[0] = d.config_.clock ? d.config_.clock->ticks() : 0;
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::get_process_id(SvcDispatcher& d, SvcCall& c) {
    // Horizon: a process handle gives its id, a thread handle its owner's id.
    const auto handle = static_cast<uint32_t>(c.ctx.x[1]);
    const auto obj = d.handles_.resolve(handle, c.thread, d.config_.process_id);
    if (!obj || (obj->type != KObjectType::Process && obj->type != KObjectType::Thread)) {
        set_w0(c.ctx, kresult::InvalidHandle);
        c.ctx.x[1] = 0;
        return SvcOutcome::resume();
    }
    c.ctx.x[1] = obj->type == KObjectType::Process ? obj->id : d.config_.process_id;   // one process in P3.1
    set_w0(c.ctx, kresult::Success);
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::break_(SvcDispatcher& d, SvcCall& c) {
    const auto reason = static_cast<uint32_t>(c.ctx.x[0]);
    const uint64_t address = c.ctx.x[1];
    const uint64_t size = c.ctx.x[2];
    if (reason & 0x80000000u) {   // BreakReason_NotificationOnlyFlag: recorded, the thread goes on
        ++d.break_notifications_;
        set_w0(c.ctx, kresult::Success);
        return SvcOutcome::resume();
    }
    // D-P3.1-2: a real Break is a guest abort -> session Error, with the reason decoded.
    std::string msg = "guest_abort=";
    if (const char* name = SvcDispatcher::break_reason_name(reason)) msg += name;
    else msg += "reason_" + hex(reason);
    if (size == 4) {
        if (const auto r = d.memory_.read32(address)) {
            msg += " result=" + SvcDispatcher::result_text(*r) + " (" + hex(*r) + ")";
            return SvcOutcome::fatal(msg + " @" + hex(c.pc));
        }
    }
    msg += " addr=" + hex(address) + " size=" + hex(size);
    return SvcOutcome::fatal(msg + " @" + hex(c.pc));
}

SvcOutcome SvcHandlers::output_debug_string(SvcDispatcher& d, SvcCall& c) {
    const uint64_t ptr = c.ctx.x[0];
    const uint64_t len = c.ctx.x[1];
    if (len == 0) { set_w0(c.ctx, kresult::Success); return SvcOutcome::resume(); }   // as Horizon
    // D-P3.1-3: at most 64 KiB per call are copied (and validated); the rest is marked.
    const size_t n = static_cast<size_t>(std::min<uint64_t>(len, SvcDispatcher::kMaxDebugString));
    std::string text(n, '\0');
    if (ptr + len < ptr || !d.memory_.read(ptr, text.data(), n)) {
        set_w0(c.ctx, kresult::InvalidPointer);
        return SvcOutcome::resume();
    }
    if (len > n) text += " [truncated]";
    d.log_.append(text);
    if (d.sink_) d.sink_(text);
    set_w0(c.ctx, kresult::Success);
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::get_info(SvcDispatcher& d, SvcCall& c) {
    // Rules as in the Horizon kernel (Atmosphère mesosphere kern_svc_info.cpp): the process
    // ids take a process handle and subtype 0; DebuggerAttached and RandomEntropy take
    // INVALID_HANDLE (libnx's random.c calls GetInfo(RandomEntropy, INVALID_HANDLE, i)).
    const auto id0 = static_cast<uint32_t>(c.ctx.x[1]);
    const auto handle = static_cast<uint32_t>(c.ctx.x[2]);
    const uint64_t id1 = c.ctx.x[3];
    auto answer = [&](uint32_t result, uint64_t value) {
        set_w0(c.ctx, result);
        c.ctx.x[1] = result == kresult::Success ? value : 0;
        return SvcOutcome::resume();
    };
    switch (id0) {
        case 0:     // CoreMask
        case 1:     // PriorityMask
        case 18: {  // ProgramId
            if (id1 != 0) return answer(kresult::InvalidCombination, 0);
            const auto obj = d.handles_.resolve(handle, c.thread, d.config_.process_id);
            if (!obj || obj->type != KObjectType::Process) return answer(kresult::InvalidHandle, 0);
            if (id0 == 0) return answer(kresult::Success, SvcDispatcher::kCoreMask);
            if (id0 == 1) return answer(kresult::Success, SvcDispatcher::kPriorityMask);
            return answer(kresult::Success, d.config_.program_id);
        }
        case 8:     // DebuggerAttached
            if (handle != HandleTable::kInvalidHandle) return answer(kresult::InvalidHandle, 0);
            if (id1 != 0) return answer(kresult::InvalidCombination, 0);
            return answer(kresult::Success, 0);
        case 11:    // RandomEntropy
            if (handle != HandleTable::kInvalidHandle) return answer(kresult::InvalidHandle, 0);
            if (id1 >= 4) return answer(kresult::InvalidCombination, 0);
            return answer(kresult::Success, d.config_.entropy[static_cast<size_t>(id1)]);
        // P3.2: memory ids (process handle, subtype 0; D-P3.2-3 for the others).
        case 2: case 3: case 4: case 5: case 6: case 7: case 12: case 13: case 14: case 15:
        case 16: case 17: case 21: case 22: {
            const VmManager* vm = d.config_.vm;
            if (!vm || !vm->active()) return answer(kresult::InvalidEnumValue, 0);   // synthetic image
            if (id1 != 0) return answer(kresult::InvalidCombination, 0);
            const auto obj = d.handles_.resolve(handle, c.thread, d.config_.process_id);
            if (!obj || obj->type != KObjectType::Process) return answer(kresult::InvalidHandle, 0);
            const VmConfig& m = vm->config();
            switch (id0) {
                case 2: return answer(kresult::Success, m.alias_base);
                case 3: return answer(kresult::Success, m.alias_size);
                case 4: return answer(kresult::Success, m.heap_base);
                case 5: return answer(kresult::Success, m.heap_size);
                case 6: case 21: return answer(kresult::Success, vm->total_memory());
                case 7: case 22: return answer(kresult::Success, vm->used_memory());
                case 12: return answer(kresult::Success, m.space_begin);
                case 13: return answer(kresult::Success, m.space_end - m.space_begin);
                case 14: return answer(kresult::Success, m.stack_base);
                case 15: return answer(kresult::Success, m.stack_size);
                case 16: return answer(kresult::Success, m.system_resource_size);   // P6.0: the NPDM's (0 for NRO)
                default: return answer(kresult::Success, 0);   // 17 SystemResourceSizeUsed: Lobo's page tables are not taken from it
            }
        }
        case 25: {  // P3.3: ThreadTickCount (thread handle, subtype = core or -1)
            KernelThreads* kt = d.config_.kthreads;
            if (!kt || !kt->active()) return answer(kresult::InvalidEnumValue, 0);   // synthetic image
            uint64_t ticks = 0;
            const uint32_t rc = kt->thread_tick_count(handle, id1, d.config_.clock ? d.config_.clock->ticks() : 0, ticks);
            return answer(rc, ticks);
        }
        default:    // never an invented value
            if (SvcHandlers::get_info_p6(d, c, id0, handle, id1)) return SvcOutcome::resume();   // P6.0 ids
            return answer(kresult::InvalidEnumValue, 0);
    }
}

// ---- P3.2: process memory -----------------------------------------------------------------
namespace {
/** The memory SVCs need the P3.0 process map; a synthetic image has none (fail closed, D3). */
VmManager* process_memory(SvcDispatcher& d, SvcOutcome& fatal) {
    VmManager* vm = d.session().vm;
    if (!vm || !vm->active()) {
        fatal = SvcOutcome::fatal("memoria del proceso no disponible para imágenes sintéticas");
        return nullptr;
    }
    return vm;
}
SvcOutcome after(VmManager& vm, cpu::CpuState& ctx, uint32_t rc) {
    if (vm.broken()) return SvcOutcome::fatal("estado interno de memoria inconsistente (Mmu/AddressSpace)");
    set_w0(ctx, rc);
    return SvcOutcome::resume();
}
} // namespace

SvcOutcome SvcHandlers::set_heap_size(SvcDispatcher& d, SvcCall& c) {
    SvcOutcome fatal;
    VmManager* vm = process_memory(d, fatal);
    if (!vm) return fatal;
    uint64_t address = 0;
    const uint32_t rc = vm->set_heap_size(c.ctx.x[1], address);
    c.ctx.x[1] = address;
    return after(*vm, c.ctx, rc);
}

SvcOutcome SvcHandlers::set_memory_permission(SvcDispatcher& d, SvcCall& c) {
    SvcOutcome fatal;
    VmManager* vm = process_memory(d, fatal);
    if (!vm) return fatal;
    return after(*vm, c.ctx, vm->set_memory_permission(c.ctx.x[0], c.ctx.x[1], static_cast<uint32_t>(c.ctx.x[2])));
}

SvcOutcome SvcHandlers::set_memory_attribute(SvcDispatcher& d, SvcCall& c) {
    SvcOutcome fatal;
    VmManager* vm = process_memory(d, fatal);
    if (!vm) return fatal;
    return after(*vm, c.ctx, vm->set_memory_attribute(c.ctx.x[0], c.ctx.x[1], static_cast<uint32_t>(c.ctx.x[2]),
                                                      static_cast<uint32_t>(c.ctx.x[3])));
}

SvcOutcome SvcHandlers::map_memory(SvcDispatcher& d, SvcCall& c) {
    SvcOutcome fatal;
    VmManager* vm = process_memory(d, fatal);
    if (!vm) return fatal;
    return after(*vm, c.ctx, vm->map_memory(c.ctx.x[0], c.ctx.x[1], c.ctx.x[2]));
}

SvcOutcome SvcHandlers::unmap_memory(SvcDispatcher& d, SvcCall& c) {
    SvcOutcome fatal;
    VmManager* vm = process_memory(d, fatal);
    if (!vm) return fatal;
    return after(*vm, c.ctx, vm->unmap_memory(c.ctx.x[0], c.ctx.x[1], c.ctx.x[2]));
}

SvcOutcome SvcHandlers::query_memory(SvcDispatcher& d, SvcCall& c) {
    SvcOutcome fatal;
    VmManager* vm = process_memory(d, fatal);
    if (!vm) return fatal;
    const uint64_t out = c.ctx.x[0];
    // QueryProcessMemory: the output must be a safe user pointer before anything else.
    if (!d.memory_.accessible(out, sizeof(kmem::MemoryInfo), true)) {
        set_w0(c.ctx, kmem::result::InvalidPointer);
        return SvcOutcome::resume();
    }
    const kmem::MemoryInfo info = vm->query(c.ctx.x[2]);
    if (!d.memory_.write(out, &info, sizeof info)) {
        set_w0(c.ctx, kmem::result::InvalidPointer);
        return SvcOutcome::resume();
    }
    c.ctx.x[1] = 0;                                     // PageInfo.flags
    set_w0(c.ctx, kresult::Success);
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::flush_entire_data_cache(SvcDispatcher&, SvcCall& c) {
    set_w0(c.ctx, kresult::Success);                    // D-P3.2-4: no 1 ms wait
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::flush_data_cache(SvcDispatcher& d, SvcCall& c) {
    const uint64_t address = c.ctx.x[0], size = c.ctx.x[1];
    // mesosphere: size 0 succeeds; otherwise the range must be a safe user pointer.
    const bool ok = size == 0 || d.memory_.accessible(address, size, false);
    set_w0(c.ctx, ok ? kresult::Success : kmem::result::InvalidCurrentMemory);
    return SvcOutcome::resume();
}

// ---- P3.3: threads and synchronization ------------------------------------------------------
namespace {
/** The thread SVCs need the P3.3 kernel (native processes); a synthetic image has none. The
 *  calling thread must be the one the kernel is running (fail closed otherwise, D3). */
KernelThreads* kernel_threads(SvcDispatcher& d, const SvcCall& c, KThread*& self, SvcOutcome& fatal) {
    KernelThreads* kt = d.session().kthreads;
    if (!kt || !kt->active()) {
        fatal = SvcOutcome::fatal("hilos del kernel no disponibles para imágenes sintéticas");
        return nullptr;
    }
    self = kt->current();
    if (!self || self->id != c.thread) {
        fatal = SvcOutcome::fatal("estado interno de hilos inconsistente (SVC fuera del turno)");
        return nullptr;
    }
    return kt;
}
SvcOutcome result(cpu::CpuState& ctx, uint32_t rc) {
    set_w0(ctx, rc);
    return SvcOutcome::resume();
}
/** Waits end with their final registers written by the kernel; this is the provisional state. */
SvcOutcome wait_or_result(cpu::CpuState& ctx, uint32_t rc, bool blocked) {
    set_w0(ctx, rc);
    return blocked ? SvcOutcome::block() : SvcOutcome::resume();
}
#define LG_KT(d, c)                                    \
    KThread* self = nullptr;                           \
    SvcOutcome fatal_;                                 \
    KernelThreads* kt = kernel_threads(d, c, self, fatal_); \
    if (!kt) return fatal_;                            \
    (void)self
} // namespace

SvcOutcome SvcHandlers::create_thread(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    uint32_t handle = 0;
    const uint32_t rc = kt->create_thread(c.ctx.x[1], c.ctx.x[2], c.ctx.x[3], static_cast<int32_t>(c.ctx.x[4]),
                                          static_cast<int32_t>(c.ctx.x[5]), handle);
    c.ctx.x[1] = rc == kresult::Success ? handle : 0;
    return result(c.ctx, rc);
}

SvcOutcome SvcHandlers::start_thread(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->start_thread(static_cast<uint32_t>(c.ctx.x[0])));
}

SvcOutcome SvcHandlers::exit_thread(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    if (kt->exit_thread(*self)) {
        // D-P3.3-4: the last thread ended -> the process ends cleanly (no exit code).
        d.exit_ = {true, false, 0, c.pc};
        return {SvcOutcome::Kind::ExitProcess, {}};
    }
    return {SvcOutcome::Kind::ExitThread, {}};
}

SvcOutcome SvcHandlers::sleep_thread(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    // svcSleepThread returns nothing: the registers stay as the guest left them.
    return kt->sleep_thread(*self, static_cast<int64_t>(c.ctx.x[0])) ? SvcOutcome::block() : SvcOutcome::resume();
}

SvcOutcome SvcHandlers::get_thread_priority(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    int32_t prio = 0;
    const uint32_t rc = kt->get_thread_priority(static_cast<uint32_t>(c.ctx.x[1]), prio);
    c.ctx.x[1] = rc == kresult::Success ? static_cast<uint32_t>(prio) : 0;
    return result(c.ctx, rc);
}

SvcOutcome SvcHandlers::set_thread_priority(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->set_thread_priority(static_cast<uint32_t>(c.ctx.x[0]), static_cast<int32_t>(c.ctx.x[1])));
}

SvcOutcome SvcHandlers::get_thread_core_mask(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    int32_t core = 0;
    uint64_t mask = 0;
    const uint32_t rc = kt->get_thread_core_mask(static_cast<uint32_t>(c.ctx.x[2]), core, mask);
    c.ctx.x[1] = rc == kresult::Success ? static_cast<uint32_t>(core) : 0;
    c.ctx.x[2] = rc == kresult::Success ? mask : 0;
    return result(c.ctx, rc);
}

SvcOutcome SvcHandlers::set_thread_core_mask(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->set_thread_core_mask(static_cast<uint32_t>(c.ctx.x[0]), static_cast<int32_t>(c.ctx.x[1]),
                                                  c.ctx.x[2]));
}

SvcOutcome SvcHandlers::get_current_processor_number(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    c.ctx.x[0] = static_cast<uint32_t>(kt->current_core());
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::signal_event(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->signal_event(static_cast<uint32_t>(c.ctx.x[0])));
}

SvcOutcome SvcHandlers::clear_event(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->clear_event(static_cast<uint32_t>(c.ctx.x[0])));
}

SvcOutcome SvcHandlers::reset_signal(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->reset_signal(static_cast<uint32_t>(c.ctx.x[0])));
}

SvcOutcome SvcHandlers::wait_synchronization(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    int32_t index = -1;
    bool blocked = false;
    const uint32_t rc = kt->wait_synchronization(*self, c.ctx.x[1], static_cast<int32_t>(c.ctx.x[2]),
                                                 static_cast<int64_t>(c.ctx.x[3]), index, blocked);
    c.ctx.x[1] = static_cast<uint32_t>(index);
    return wait_or_result(c.ctx, rc, blocked);
}

SvcOutcome SvcHandlers::cancel_synchronization(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->cancel_synchronization(static_cast<uint32_t>(c.ctx.x[0])));
}

SvcOutcome SvcHandlers::arbitrate_lock(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    bool blocked = false;
    const uint32_t rc = kt->arbitrate_lock(*self, static_cast<uint32_t>(c.ctx.x[0]), c.ctx.x[1],
                                           static_cast<uint32_t>(c.ctx.x[2]), blocked);
    return wait_or_result(c.ctx, rc, blocked);
}

SvcOutcome SvcHandlers::arbitrate_unlock(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->arbitrate_unlock(*self, c.ctx.x[0]));
}

SvcOutcome SvcHandlers::wait_process_wide_key_atomic(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    bool blocked = false;
    const uint32_t rc = kt->wait_process_wide_key(*self, c.ctx.x[0], c.ctx.x[1], static_cast<uint32_t>(c.ctx.x[2]),
                                                  static_cast<int64_t>(c.ctx.x[3]), blocked);
    return wait_or_result(c.ctx, rc, blocked);
}

SvcOutcome SvcHandlers::signal_process_wide_key(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    kt->signal_process_wide_key(c.ctx.x[0], static_cast<int32_t>(c.ctx.x[1]));   // returns nothing
    return SvcOutcome::resume();
}

SvcOutcome SvcHandlers::get_thread_id(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    uint64_t id = 0;
    const uint32_t rc = kt->get_thread_id(static_cast<uint32_t>(c.ctx.x[1]), id);
    c.ctx.x[1] = rc == kresult::Success ? id : 0;
    return result(c.ctx, rc);
}

SvcOutcome SvcHandlers::wait_for_address(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    bool blocked = false;
    const uint32_t rc = kt->wait_for_address(*self, c.ctx.x[0], static_cast<uint32_t>(c.ctx.x[1]),
                                             static_cast<int64_t>(c.ctx.x[2]), static_cast<int64_t>(c.ctx.x[3]), blocked);
    return wait_or_result(c.ctx, rc, blocked);
}

SvcOutcome SvcHandlers::signal_to_address(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    return result(c.ctx, kt->signal_to_address(c.ctx.x[0], static_cast<uint32_t>(c.ctx.x[1]),
                                               static_cast<int32_t>(c.ctx.x[2]), static_cast<int32_t>(c.ctx.x[3])));
}

SvcOutcome SvcHandlers::create_event(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    uint32_t w = 0, r = 0;
    const uint32_t rc = kt->create_event(w, r);
    c.ctx.x[1] = w;
    c.ctx.x[2] = r;
    return result(c.ctx, rc);
}

// ---- P3.4: IPC ---------------------------------------------------------------------------------
SvcOutcome SvcHandlers::connect_to_named_port(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    KernelIpc* ipc = d.config_.ipc;
    if (!ipc || !ipc->active()) return SvcOutcome::fatal("IPC no disponible para imágenes sintéticas");
    uint32_t handle = 0;
    const uint32_t rc = ipc->connect_to_named_port(c.ctx.x[1], handle);
    c.ctx.x[1] = rc == kresult::Success ? handle : 0;
    return result(c.ctx, rc);
}

SvcOutcome SvcHandlers::send_sync_request(SvcDispatcher& d, SvcCall& c) {
    LG_KT(d, c);
    KernelIpc* ipc = d.config_.ipc;
    if (!ipc || !ipc->active()) return SvcOutcome::fatal("IPC no disponible para imágenes sintéticas");
    const auto r = ipc->send_sync_request(*self, static_cast<uint32_t>(c.ctx.x[0]));
    if (!r.fatal.empty()) return SvcOutcome::fatal(r.fatal);
    return wait_or_result(c.ctx, r.result, r.blocked);
}
#undef LG_KT

} // namespace lg::system
