#include "psm_service.h"

namespace lg::system {
namespace {
void put_u32(std::vector<uint8_t>& p, uint32_t v) {
    for (int i = 0; i < 4; ++i) p.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
}
bool get_u32(const std::vector<uint8_t>& p, size_t off, uint32_t& out) {
    if (off + 4 > p.size()) return false;
    out = 0;
    for (int i = 0; i < 4; ++i) out |= static_cast<uint32_t>(p[off + i]) << (8 * i);
    return true;
}
IpcMessage reply(uint32_t command_id) { IpcMessage m; m.command_id = command_id; return m; }
} // namespace

core::Result<IpcMessage> PsmService::dispatch(const IpcMessage& r) {
    switch (r.command_id) {
        case 0: { // GetBatteryChargePercentage
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u32(out.payload, charge_percent_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 1: { // GetChargerType
            IpcMessage out = reply(r.command_id);
            std::lock_guard lock(mutex_);
            put_u32(out.payload, charger_type_);
            return core::Result<IpcMessage>::Ok(std::move(out));
        }
        case 10: { // SetBatteryChargePercentage (frontend bridge)
            uint32_t pct{};
            if (!get_u32(r.payload, 0, pct)) return core::Result<IpcMessage>::Error("psm SetBatteryChargePercentage: short payload");
            if (pct > 100) return core::Result<IpcMessage>::Error("psm SetBatteryChargePercentage: out of range");
            { std::lock_guard lock(mutex_); charge_percent_ = pct; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        case 11: { // SetChargerType (frontend bridge)
            uint32_t type{};
            if (!get_u32(r.payload, 0, type)) return core::Result<IpcMessage>::Error("psm SetChargerType: short payload");
            if (type > 2) return core::Result<IpcMessage>::Error("psm SetChargerType: invalid type");
            { std::lock_guard lock(mutex_); charger_type_ = type; }
            return core::Result<IpcMessage>::Ok(reply(r.command_id));
        }
        default:
            return core::Result<IpcMessage>::Error("psm: unknown command");
    }
}

uint32_t PsmService::charge_percent() const noexcept { std::lock_guard lock(mutex_); return charge_percent_; }
uint32_t PsmService::charger_type() const noexcept { std::lock_guard lock(mutex_); return charger_type_; }

std::unique_ptr<IpcEndpoint> make_psm_service() { return std::make_unique<PsmService>(); }

} // namespace lg::system
