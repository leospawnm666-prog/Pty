#pragma once
#include <memory>
#include "ipc.h"
#include "display_server.h"

// HLE of the Switch display stack front-ends over the simplified IpcMessage transport.
//
//   vi (nn::vi window manager) — ViService, backed by a shared DisplayServer:
//     0 ListDisplays         -> [u32 count]
//     1 OpenDisplay          <- [utf8 name]            -> [u64 display_id]  (name: Default/Internal/External)
//     2 CloseDisplay         <- [u64 display_id]
//     3 GetDisplayResolution <- [u64 display_id]        -> [u32 width][u32 height]
//     4 OpenLayer            <- [u64 display_id]         -> [u64 layer_id]
//     5 CloseLayer           <- [u64 layer_id]
//     6 SetLayerScalingMode  <- [u64 layer_id][u32 mode]
//     7 GetDisplayVsyncEvent <- [u64 display_id]         -> [u64 vsync_count]
//     8 SignalVsync          <- [u64 display_id]         (Lobo extension: the presenter ticks vsync)
//
//   dispdrv (IHOSBinderDriver / nvnflinger BufferQueue) — DispdrvService, same DisplayServer:
//     0 DequeueBuffer   <- [u64 layer_id]            -> [i32 slot]   (-1 = none free)
//     1 QueueBuffer     <- [u64 layer_id][u32 slot]
//     2 CancelBuffer    <- [u64 layer_id][u32 slot]
//     3 AcquireBuffer   <- [u64 layer_id]            -> [i32 slot]   (-1 = none queued)
//     4 ReleaseBuffer   <- [u64 layer_id][u32 slot]
//     5 GetBufferCount  <- [u64 layer_id]            -> [u32 count]
//     6 SetBufferCount  <- [u64 layer_id][u32 count]
//     7 PresentedFrames <- [u64 layer_id]            -> [u64 count]
//
// A -1 slot from Dequeue/Acquire is a normal flow-control result (queue full/empty),
// so it is returned as Ok; only structural errors (short payload, unknown display or
// layer, unknown command) are reported as core::Result errors.

namespace lg::system {

class ViService final : public IpcEndpoint {
public:
    explicit ViService(std::shared_ptr<DisplayServer> server) : server_(std::move(server)) {}
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

private:
    std::shared_ptr<DisplayServer> server_;
};

class DispdrvService final : public IpcEndpoint {
public:
    explicit DispdrvService(std::shared_ptr<DisplayServer> server) : server_(std::move(server)) {}
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

private:
    std::shared_ptr<DisplayServer> server_;
};

std::shared_ptr<DisplayServer> make_display_server();
std::unique_ptr<IpcEndpoint> make_vi_service(std::shared_ptr<DisplayServer> server);
std::unique_ptr<IpcEndpoint> make_dispdrv_service(std::shared_ptr<DisplayServer> server);

} // namespace lg::system
