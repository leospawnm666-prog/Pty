// P6.0 (P6_DISENO.md §3.3): the SVCs of the memory objects and resource limits. Validation order
// and Result codes as the Horizon kernel (mesosphere: kern_svc_shared_memory.cpp,
// kern_svc_transfer_memory.cpp, kern_svc_code_memory.cpp, kern_svc_physical_memory.cpp,
// kern_svc_resource_limit.cpp); the effects live in KernelObjects and VmManager.
#include "svc_dispatcher.h"

namespace lg::system {
namespace {
namespace r = kmem::result;
constexpr bool aligned(uint64_t v) noexcept { return (v & (kmem::PageSize - 1)) == 0; }
void set_w0(cpu::CpuState& ctx, uint32_t result) noexcept { ctx.x[0] = result; }
SvcOutcome done(cpu::CpuState& ctx, uint32_t rc) { set_w0(ctx, rc); return SvcOutcome::resume(); }
uint32_t w(const cpu::CpuState& ctx, int i) noexcept { return static_cast<uint32_t>(ctx.x[i]); }

/** The P6.0 SVCs need a native process (VmManager + KernelObjects); synthetic images have none. */
KernelObjects* objects(SvcDispatcher& d, SvcOutcome& fatal) {
    KernelObjects* k = d.session().kobjects;
    if (!k || !k->active() || !d.session().vm || !d.session().vm->active()) {
        fatal = SvcOutcome::fatal("objetos del kernel no disponibles para imágenes sintéticas");
        return nullptr;
    }
    return k;
}
#define LG_KO(d)                                  \
    SvcOutcome fatal_;                            \
    KernelObjects* ko = objects(d, fatal_);       \
    if (!ko) return fatal_;                       \
    VmManager& vm = *d.session().vm;              \
    (void)vm
SvcOutcome after(VmManager& vm, cpu::CpuState& ctx, uint32_t rc) {
    if (vm.broken()) return SvcOutcome::fatal("estado interno de memoria inconsistente (Mmu/AddressSpace)");
    return done(ctx, rc);
}
} // namespace

// ---- shared memory ---------------------------------------------------------------------------
SvcOutcome SvcHandlers::map_shared_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    return after(vm, c.ctx, ko->map_shared_memory(w(c.ctx, 0), c.ctx.x[1], c.ctx.x[2], w(c.ctx, 3)));
}
SvcOutcome SvcHandlers::unmap_shared_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    return after(vm, c.ctx, ko->unmap_shared_memory(w(c.ctx, 0), c.ctx.x[1], c.ctx.x[2]));
}
SvcOutcome SvcHandlers::create_shared_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    uint32_t h = 0;
    const uint32_t rc = ko->create_shared_memory(c.ctx.x[1], w(c.ctx, 2), w(c.ctx, 3), h);
    c.ctx.x[1] = rc ? 0 : h;
    return after(vm, c.ctx, rc);
}

// ---- transfer memory -------------------------------------------------------------------------
SvcOutcome SvcHandlers::create_transfer_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    uint32_t h = 0;
    const uint32_t rc = ko->create_transfer_memory(c.ctx.x[1], c.ctx.x[2], w(c.ctx, 3), h);
    c.ctx.x[1] = rc ? 0 : h;
    return after(vm, c.ctx, rc);
}
SvcOutcome SvcHandlers::map_transfer_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    return after(vm, c.ctx, ko->map_transfer_memory(w(c.ctx, 0), c.ctx.x[1], c.ctx.x[2], w(c.ctx, 3)));
}
SvcOutcome SvcHandlers::unmap_transfer_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    return after(vm, c.ctx, ko->unmap_transfer_memory(w(c.ctx, 0), c.ctx.x[1], c.ctx.x[2]));
}

// ---- code memory -----------------------------------------------------------------------------
SvcOutcome SvcHandlers::create_code_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    uint32_t h = 0;
    const uint32_t rc = ko->create_code_memory(c.ctx.x[1], c.ctx.x[2], h);
    c.ctx.x[1] = rc ? 0 : h;
    return after(vm, c.ctx, rc);
}
SvcOutcome SvcHandlers::control_code_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    return after(vm, c.ctx, ko->control_code_memory(w(c.ctx, 0), w(c.ctx, 1), c.ctx.x[2], c.ctx.x[3], w(c.ctx, 4)));
}

// ---- physical memory ---------------------------------------------------------------------------
namespace {
uint32_t physical_checks(uint64_t address, uint64_t size) {
    if (!aligned(address)) return r::InvalidAddress;
    if (!aligned(size) || size == 0) return r::InvalidSize;
    if (address + size <= address) return r::InvalidMemoryRegion;
    return r::Success;
}
} // namespace
SvcOutcome SvcHandlers::map_physical_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    if (const uint32_t rc = physical_checks(c.ctx.x[0], c.ctx.x[1]); rc) return done(c.ctx, rc);
    // the process must have a system resource (NPDM); hbloader's processes have none
    if (vm.config().system_resource_size == 0) return done(c.ctx, r::InvalidState);
    if (!vm.in_alias_region(c.ctx.x[0], c.ctx.x[1])) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.map_physical_memory(c.ctx.x[0], c.ctx.x[1]));
}
SvcOutcome SvcHandlers::unmap_physical_memory(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    if (const uint32_t rc = physical_checks(c.ctx.x[0], c.ctx.x[1]); rc) return done(c.ctx, rc);
    if (vm.config().system_resource_size == 0) return done(c.ctx, r::InvalidState);
    if (!vm.in_alias_region(c.ctx.x[0], c.ctx.x[1])) return done(c.ctx, r::InvalidMemoryRegion);
    return after(vm, c.ctx, vm.unmap_physical_memory(c.ctx.x[0], c.ctx.x[1]));
}
// The unsafe pool (KUnsafeMemory): empty until SetUnsafeLimit gives it a size; its memory is
// mapped in the alias region (the "unsafe alias region" of 39-bit processes).
SvcOutcome SvcHandlers::set_unsafe_limit(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    const uint64_t limit = c.ctx.x[0];
    if (!aligned(limit)) return done(c.ctx, r::InvalidSize);
    if (limit > vm.total_memory()) return done(c.ctx, r::OutOfRange);
    if (limit < d.unsafe_used_) return done(c.ctx, r::LimitReached);   // KUnsafeMemory::SetLimitSize
    d.unsafe_limit_ = limit;
    return done(c.ctx, r::Success);
}
SvcOutcome SvcHandlers::map_physical_memory_unsafe(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    const uint64_t a = c.ctx.x[0], s = c.ctx.x[1];
    if (!aligned(a)) return done(c.ctx, r::InvalidAddress);
    if (!aligned(s) || s == 0) return done(c.ctx, r::InvalidSize);
    if (a + s <= a) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.in_alias_region(a, s)) return done(c.ctx, r::InvalidMemoryRegion);
    const uint64_t before = vm.physical_memory_mapped();
    // the bytes to map are at most `s`; the pool's limit is checked against them
    if (d.unsafe_used_ + s > d.unsafe_limit_) {
        // what is already mapped in the range does not count: measure precisely by trying
        // only when everything fits (KUnsafeMemory::TryReserve is all-or-nothing)
        return done(c.ctx, r::LimitReached);
    }
    const uint32_t rc = vm.map_physical_memory(a, s);
    if (rc == r::Success) d.unsafe_used_ += vm.physical_memory_mapped() - before;
    return after(vm, c.ctx, rc);
}
SvcOutcome SvcHandlers::unmap_physical_memory_unsafe(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    const uint64_t a = c.ctx.x[0], s = c.ctx.x[1];
    if (!aligned(a)) return done(c.ctx, r::InvalidAddress);
    if (!aligned(s) || s == 0) return done(c.ctx, r::InvalidSize);
    if (a + s <= a) return done(c.ctx, r::InvalidCurrentMemory);
    if (!vm.in_alias_region(a, s)) return done(c.ctx, r::InvalidMemoryRegion);
    const uint64_t before = vm.physical_memory_mapped();
    const uint32_t rc = vm.unmap_physical_memory(a, s);
    if (rc == r::Success) d.unsafe_used_ -= std::min(d.unsafe_used_, before - vm.physical_memory_mapped());
    return after(vm, c.ctx, rc);
}

// ---- resource limits ---------------------------------------------------------------------------
namespace {
SvcOutcome limit_value(SvcDispatcher& d, SvcCall& c, int kind) {
    LG_KO(d);
    int64_t v = 0;
    const uint32_t rc = ko->get_resource_limit_value(w(c.ctx, 1), w(c.ctx, 2), kind, v);
    c.ctx.x[1] = rc ? 0 : static_cast<uint64_t>(v);
    return done(c.ctx, rc);
}
} // namespace
SvcOutcome SvcHandlers::get_resource_limit_limit_value(SvcDispatcher& d, SvcCall& c) { return limit_value(d, c, 0); }
SvcOutcome SvcHandlers::get_resource_limit_current_value(SvcDispatcher& d, SvcCall& c) { return limit_value(d, c, 1); }
SvcOutcome SvcHandlers::get_resource_limit_peak_value(SvcDispatcher& d, SvcCall& c) { return limit_value(d, c, 2); }
SvcOutcome SvcHandlers::create_resource_limit(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    uint32_t h = 0;
    const uint32_t rc = ko->create_resource_limit(h);
    c.ctx.x[1] = rc ? 0 : h;
    return done(c.ctx, rc);
}
SvcOutcome SvcHandlers::set_resource_limit_limit_value(SvcDispatcher& d, SvcCall& c) {
    LG_KO(d);
    return done(c.ctx, ko->set_resource_limit_value(w(c.ctx, 0), w(c.ctx, 1), static_cast<int64_t>(c.ctx.x[2])));
}
#undef LG_KO

} // namespace lg::system
