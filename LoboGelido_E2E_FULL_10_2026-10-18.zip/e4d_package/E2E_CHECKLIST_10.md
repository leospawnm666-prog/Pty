# E2E Checklist 10 pasos — Lobo Gélido

## Host (0–3)

```bash
export ANDROID_HOME=...
export JAVA_HOME=...   # 17
export LOBO_APK=android/app/build/outputs/apk/debug/app-debug.apk

bash tools/run_e2e_checklist.sh
```

| Paso | Script | Criterio PASS |
|------|--------|----------------|
| 0 | runner | JDK/wrapper/SDK |
| 0b | `run_shader_oracle_host.sh` | ICD/tests preflight |
| 1 | runner | APK + arm64 `.so` listado |
| 2 | `verify_native_so.sh` | **sin TEXTREL**, ELF OK |
| 3 | `e2e_step3_adb.sh` | adb device + ABI |

## Dispositivo (4–10)

```bash
export LOBO_E2E_DEVICE=1
export LOBO_PROD_KEYS=/path/prod.keys
export LOBO_FIRMWARE=/path/firmware_dir_or_zip
export LOBO_GAME=/path/game.nsp_or_folder
export LOBO_APK=...          # si aún no instalada
export LOBO_E2E_INSTALL=1    # opcional en paso 3
export LOBO_LOGCAT_SECONDS=20

bash tools/run_e2e_checklist.sh
# o solo dispositivo:
bash tools/e2e_steps_4_10_device.sh
```

| Paso | Automatizado | Manual UI |
|------|----------------|-----------|
| 4 Keys | `adb push` a `/sdcard/LoboGelido_E2E/prod.keys` | Import en Ajustes |
| 5 FW | push dir/file | Import FW |
| 6 Games | push a `.../games` | Scan biblioteca |
| 7 Covers | — | Verificar UI |
| 8 Long-press | — | Mods/updates |
| 9 Play | launch app | Pulsar Jugar |
| 10 logcat | captura + heurística TEXTREL/dlopen | Revisar `lobo_e2e.log` |

Reporte host: `e2e_report.txt`  
Log dispositivo: `lobo_e2e.log`
