# P4 — GPU: auditoría, hoja de ruta y P4.1 (recompilador de *shaders* Maxwell)

Estado: **aprobada ("Hazlo", D-P4-1 a D-P4-6 como se recomendaban). P4.1 entregada (hito H7, ver `P4_1_INFORME.md`).**
Solo se ha preparado y probado la cadena de herramientas de verificación (§3), fuera del árbol.

**Encargo:** "llegar al 100 % de GPU *shader*". P3.7 (AdvSIMD/FP en el intérprete) queda
aplazado detrás de P4 (D-P4-1).

## 0. Resumen
- **Hoy el guest no tiene GPU.** Lo que existe en `gpu/` es la parte del *host* (Vulkan,
  presentador, caché de *pipelines*, registro de módulos SPIR-V) y una IR abstracta propia. No
  hay nada que lea comandos de la GPU de la Switch ni que traduzca sus *shaders*. En porcentaje
  honesto: **recompilador de *shaders* 0 %, GPU del guest ~0 %**.
- **"100 %" tiene que ser medible.** Propongo cuatro métricas (§2). El 100 % de P4 es el 100 % de
  esas métricas, no "todos los juegos": los *shaders* de un juego no llegan al recompilador hasta
  que exista el frente de la GPU (P5).
- **Se puede verificar aquí, de verdad.** He construido y probado en este entorno una cadena
  completa: GLSL → **uam** (el compilador de devkitPro/deko3d) → **binario Maxwell real**;
  **envydis/envyas** (desensamblador/ensamblador independiente); **SPIRV-Tools** y **glslang**;
  y **SwiftShader** (Vulkan por CPU) que ya **ejecuta *compute shaders*** aquí. Con eso cada
  instrucción traducida se compara contra una referencia que no escribo yo.
- **Primera fase, P4.1:** el núcleo del recompilador para *compute*: decodificador del ISA
  completo, IR, flujo de control, ALU entera y flotante, memoria y emisión de SPIR-V, con pruebas
  diferenciales. Hito **H7** (§6).

## 1. Auditoría
### 1.1 Lo que hay (`gpu/`, 3 774 líneas, todo del lado del *host*)
| Módulo | Qué hace | Sirve para P4 |
|---|---|---|
| `vk_dispatch`, `vulkan_library`, `android_vulkan_context`, `adreno_driver_loader` | carga Vulkan y *drivers* Adreno propios | sí, base de ejecución |
| `vulkan_presenter` | presenta un *clear* en la superficie de Android | sí, al final (P5) |
| `vulkan_pipeline`, `async_pipeline_cache`, `graphics/shader_cache` | *pipelines* y caché en disco | sí, para guardar el SPIR-V generado |
| `spirv_module`, `shader_program_manager` | valida cabecera SPIR-V, deduplica, reflexión de *bindings* | sí: recibe lo que emita el recompilador |
| `gpu_command_processor`, `guest_gpu_translator`, `render_graph` | IR propia de 8 operaciones (*viewport*, *draw*, *clear*...) | no traduce comandos reales; se conserva (Regla de Oro) |
| `system/nvdrv_service` (158 líneas) | abre `/dev/nvhost-*`, `nvmap` con tamaños | maqueta: sin GPFIFO, sin espacio de direcciones de GPU |

### 1.2 Lo que falta para que un juego dibuje (orden de dependencia)
1. **Recompilador de *shaders* Maxwell → SPIR-V** (P4).
2. **Frente de la GPU** (P5): `nvhost-gpu` (canal, GPFIFO), `nvhost-as-gpu` (MMU de la GPU),
   `nvmap` real, `nvhost-ctrl` (*syncpoints*), y el decodificador de *pushbuffers* con los
   motores 3D (B197), *compute* (B1C0), copia (B0B5) e *inline-to-memory*.
3. **Texturas y superficies**: *block-linear*, formatos, ASTC/BCn por software si el teléfono no
   los tiene, cachés de texturas y de *render targets*.
4. **Presentación**: `vi`, *binder*/`nvnflinger`, sincronización con *syncpoints*.

Cada punto es un bloque de trabajo. Este diseño cubre el 1 completo como hoja de ruta y especifica
en detalle su primera fase.

## 2. Qué significa "100 % de *shader*" (métricas)
| # | Métrica | Denominador | Cómo se mide |
|---|---|---|---|
| M1 | **Cobertura del ISA** | las **296** codificaciones (≈150 mnemónicos) de la tabla Maxwell GM107 de envytools | test que recorre la tabla: cada codificación decodifica y tiene traducción |
| M2 | **Corpus diferencial** | todos los *shaders* del corpus (§5.3) | mismo GLSL por dos caminos (uam→Maxwell→**nuestro** SPIR-V, y glslang→SPIR-V) ejecutados en SwiftShader: salidas iguales |
| M3 | **Etapas** | 6: VS, TCS, TES, GS, FS, CS | cada etapa con su corpus en M2 |
| M4 | **SPIR-V válido** | todo lo emitido | `spirv-val` sin errores, 100 % |

**Límites del 100 %:**
- M1 incluye instrucciones que uam nunca emite (las del compilador NVN de los juegos). Esas se
  prueban **una a una** (§5.2: ensambladas con envyas y comparadas con un modelo de referencia),
  no con programas reales.
- Las aproximaciones del hardware (`MUFU` sin, cos, rcp, rsq...) no son bit a bit iguales a las
  de un Vulkan; se comparan con una tolerancia en ULP fijada por instrucción.
- El informe de cada fase da el porcentaje real de M1–M4, aunque no sea 100.

## 3. Cadena de verificación (probada en este entorno)
Todo compilado desde fuentes con versiones fijadas; nada se copia al árbol de Lobo salvo los
*fixtures* generados.

| Herramienta | Origen y versión | Licencia | Uso |
|---|---|---|---|
| **uam** | github.com/devkitPro/uam `5a5afc2` | zlib + MIT (Mesa) | GLSL → binario Maxwell real (`-r`), incluidos `.dksh` |
| **envydis / envyas** | github.com/envytools/envytools `f102b82` | MIT | decodificador y ensamblador Maxwell **independientes**: oráculo del decodificador y generador de pruebas por instrucción |
| **SPIRV-Tools, SPIRV-Headers, glslang** | KhronosGroup, `vulkan-sdk-1.3.290.0` | Apache-2.0 / BSD | `spirv-val`, `spirv-dis`, GLSL → SPIR-V de referencia |
| **SwiftShader** | github.com/google/swiftshader `cddb5c9` (Subzero) | Apache-2.0 | Vulkan 1.3 por CPU: **ejecuta** los *shaders* |
| **Vulkan-Loader, Vulkan-Headers** | KhronosGroup, `vulkan-sdk-1.3.290.0` | Apache-2.0 | carga SwiftShader |
| flex 2.6.4, meson 1.4.0, mako | GitHub | BSD / Apache / MIT | solo para compilar uam y envytools |

**Prueba de concepto ejecutada:**
- uam compiló un *compute shader* (`sin`, `sqrt`, `abs`, UBO, SSBO) a 192 bytes de Maxwell;
- envydis lo desensambló (`mov $ctaidx`, `iscadd`, `i2f`, `fmul c2[0]`, `rro`, `mufu sin`,
  `ffma`, `iadd.x`, `stg`, `exit`, palabras de planificación);
- glslang generó el SPIR-V del mismo GLSL, `spirv-val` lo aceptó y SwiftShader lo ejecutó:
  `out[1] = 0.742066085` frente a 0.742073970 en doble precisión (diferencia de aproximación del
  seno: justo lo que la tolerancia por ULP debe cubrir).
- envydis no conoce todas las codificaciones (marcó un `mufu ???`), así que es un oráculo, no la
  verdad: las discrepancias se resuelven con el ensamblador y la documentación de Mesa/nouveau.

**Política de código limpio (D-P4-2):** el recompilador es código propio. Se consultan como
referencia fuentes MIT/zlib/Apache (envytools, Mesa/nouveau, uam, `open-gpu-doc` de NVIDIA). **No se
copia código de yuzu/Eden/Ryujinx** (GPL/MIT con condiciones distintas a las de Lobo); solo se
usan como lectura de comprobación de comportamiento cuando haga falta, nunca como fuente.

## 4. Arquitectura del recompilador
Biblioteca nueva `shader/` (`lobogelido_shader`), pura (sin estado global, sin Vulkan), segura
para compilar en hilos aparte (caché asíncrona). Entrada: palabras Maxwell + información del
contexto; salida: SPIR-V + interfaz de recursos para `ShaderProgramManager`.

| Módulo | Responsabilidad |
|---|---|
| `shader/maxwell/isa.{h,cpp}` | tabla de las 296 codificaciones (máscara/valor) y extracción de campos; palabras de planificación cada 4 |
| `shader/maxwell/decoder` | binario → lista de instrucciones con operandos tipados (registro, inmediato, `c[b][o]`, predicado, `CC`) |
| `shader/ir/` | IR propia: bloques básicos, valores tipados, predicación explícita; CFG |
| `shader/ir/cfg` + `structurize` | `SSY/SYNC`, `PBK/BRK`, `PCNT/CONT`, `BRA`, `EXIT`, `KIL`, `BRX/JMX` → CFG; luego CFG estructurado |
| `shader/spirv/builder` + `emit` | emisor SPIR-V propio (sin dependencias) |
| `shader/runtime_info` | etapa, cabecera SPH de las etapas gráficas (P4.2), modelo de *constbuffers*, texturas y memoria global |

**Decisiones de diseño:**
- **Registros como variables** (`OpVariable Function` por `R0..R254`, `P0..P6`, `CC`) en P4.1;
  los *drivers* las promueven a SSA. Más simple y correcto; la SSA propia llega en la fase de
  rendimiento (D-P4-3).
- **Flujo de control:** base siempre correcta con un despachador `loop + switch` sobre los
  bloques (vale para cualquier CFG, también irreducible); los grafos reducibles se convierten a
  `if/loop` estructurados en una pasada aparte, con el despachador como respaldo (D-P4-4).
- **Semántica flotante explícita:** FTZ, saturación, modos de redondeo, `NaN` en `FMNMX`,
  precisión de `MUFU`. Se usan las extensiones de *float controls* cuando el dispositivo las
  tiene; si no, se emula con código (riesgo R4).
- **Memoria global:** las direcciones de `LDG/STG/ATOM` se rastrean hasta su origen en un
  *constbuffer* para mapearlas a SSBO (idea conocida; implementación propia). Lo que no se pueda
  rastrear se marca y se informa, no se inventa.
- **Divergencia:** en SPIR-V cada invocación es independiente, así que `SSY/SYNC` no cambian los
  resultados salvo para operaciones de *warp* (`VOTE`, `SHFL`): esas usan *subgroups* (P4.4).

## 5. Pruebas
### 5.1 T1 — Decodificador contra envydis
Para cada palabra del corpus y de la tabla: nuestro decodificador y envydis deben coincidir en
mnemónico y operandos. Las salidas de envydis se generan una vez y se guardan como *fixture*
(los tests normales no necesitan envytools).

### 5.2 T2 — Una instrucción, un test
- envyas ensambla cada codificación con operandos variados; el test envuelve la instrucción en un
  programa mínimo (cargar entradas de un SSBO, la instrucción, guardar la salida).
- Se ejecuta con SwiftShader y se compara con un **modelo de referencia en C++** de la semántica
  de esa instrucción (escrito a partir de la documentación de nouveau/envytools).
- Entradas: casos límite (0, -0, ±inf, NaN, denormales, `INT_MIN`, desbordes) + aleatorias.

### 5.3 T3 — Corpus diferencial
- GLSL propios (sin código de terceros con copyright): aritmética, bucles, `break`/`continue`,
  `switch`, funciones, UBO/SSBO, compartida, atómicas, barreras; más un **generador aleatorio de
  expresiones** con semilla fija.
- Camino A: GLSL → uam → Maxwell → **recompilador** → SPIR-V. Camino B: GLSL → glslang → SPIR-V.
  Ambos en SwiftShader con las mismas entradas; salidas iguales (bit a bit en enteros; ULP en
  flotantes).
- Los binarios Maxwell, los SPIR-V de referencia y las salidas esperadas se guardan como
  *fixtures* generados con un *script*, como `nro_fixtures.h`.

### 5.4 Cómo corren
| Grupo | Necesita | En `ctest` |
|---|---|---|
| T1, M1, M4 (con SPIRV-Tools enlazado opcionalmente) | nada externo | siempre |
| T2, T3 (ejecución) | SwiftShader + *loader* | opción `LOBOGELIDO_SHADER_ORACLE=<ruta>`; aquí, siempre activada |

Más la matriz de siempre (ASan/LSan, TSan, compilación Android) y mutación del decodificador y del
emisor.

## 6. Fases e hitos
| Fase | Contenido | Hito |
|---|---|---|
| **P4.1** | ISA completo decodificado (M1 decodificación 100 %); traducción de ALU entera y flotante, conversiones, predicados, `CC`, memoria global/compartida/local, `LDC`, registros de sistema, barreras y flujo de control completo; solo *compute* | **H7:** M1-decodificación 100 %, M4 100 %, T2 de todas las instrucciones de P4.1 y corpus *compute* T3 100 % |
| P4.2 | Etapas gráficas: SPH, atributos (`ALD/AST/IPA`), salidas, `OUT` (GS), teselación | M3 5/6 → 6/6 |
| P4.3 | Texturas e imágenes: `TEX/TLD/TLD4/TXQ/TMML/TXD/TEXS...`, `SULD/SUST/SUATOM`, *bindless* | corpus de muestreo |
| P4.4 | *Warp* y raras: `VOTE`, `SHFL`, `ATOM/RED` completas, `VABSDIFF`, `VMAD`, `IDE`, `XMAD` completo, `HADD2/HFMA2`, dobles | **M1 100 %** |
| P4.5 | Rendimiento: SSA propia, estructuración sin despachador, caché persistente, compilación asíncrona; medir en Adreno | tiempo de compilación y de ejecución medidos |

Después: P5 (frente de la GPU) y P6 (texturas y presentación), cada uno con su diseño.

## 7. P4.1 en detalle
- **Decodificación:** las 296 codificaciones.
- **Traducción:** `MOV, MOV32I, S2R(mov sysreg), CS2R, SEL, IADD, IADD3, IADD32I, ISCADD,
  ISCADD32I, IMAD, IMAD32I, IMUL, IMUL32I, XMAD, IMNMX, LOP, LOP3, LOP32I, SHL, SHR, SHF, BFE, BFI,
  FLO, POPC, PRMT, LEA, ISETP, ISET, ICMP, FADD, FADD32I, FMUL, FMUL32I, FFMA, FFMA32I, FMNMX,
  FSETP, FSET, FCMP, MUFU, RRO, F2F, F2I, I2F, I2I, PSETP, PSET, P2R, R2P, LDG, STG, LDS/STS (`ld/st`
  de compartida), LDL/STL, LDC, ATOM/RED (globales básicas), BAR, MEMBAR, DEPBAR (sin efecto),
  BRA, BRX, SSY, SYNC, PBK, BRK, PCNT, CONT, EXIT, KIL, NOP`.
- **Interfaz con el resto:** `shader::translate(code, info) -> {spirv, resources, warnings}`,
  y `ShaderProgramManager::add_shader` recibe el resultado. **No se toca ningún módulo
  existente en P4.1** (todo aditivo; la integración con los motores de la GPU es de P5).
- **Diagnóstico:** instrucción no soportada → error con dirección y mnemónico (como el *fatal*
  de las SVC), nunca una traducción silenciosa.

## 8. Análisis de impacto
| Área | Cambio | Riesgo |
|---|---|---|
| `shader/` (nuevo) | la biblioteca entera | — |
| `CMakeLists.txt` (raíz y Android) | biblioteca y tests nuevos | bajo |
| `tests/` | T1–T3, *fixtures* generados | — |
| `tools/gpu_toolchain/` (nuevo) | *script* que reconstruye la cadena de §3 con versiones fijadas | — |
| **Sin cambios** | `gpu/` existente, CPU, kernel, IPC, cargadores, Android/Kotlin, `crypto/` | — |

## 9. Matriz de riesgos
| # | Riesgo | P | I | Mitigación | Detección |
|---|---|---|---|---|---|
| R1 | Semántica de una instrucción mal entendida (documentación pública incompleta) | A | A | T2 por instrucción con casos límite; tres fuentes cruzadas (envytools, nouveau, uam) | T2, T3, mutación |
| R2 | envydis no reconoce alguna codificación (ya visto con `MUFU`) | A | M | decodificador propio desde la tabla + envyas + Mesa; discrepancias documentadas | T1 lista las diferencias |
| R3 | CFG no reducible o saltos indirectos (`BRX`) | M | A | despachador `loop+switch` siempre correcto como respaldo | corpus con `switch` y *fuzzer* de CFG |
| R4 | Flotantes: FTZ, redondeo y `NaN` distintos entre SwiftShader y Adreno | A | M | *float controls* si existen; emulación si no; tolerancias explícitas | T2 con denormales y NaN; prueba en teléfono (P4.5) |
| R5 | El corpus de uam no representa lo que emite NVN | A | M | T2 cubre cada codificación aunque uam no la use; corpus aleatorio | M1 + T2 |
| R6 | Tamaño del trabajo ("100 %" del ISA es mucho) | A | M | fases cortas con hito medible; porcentajes reales en cada informe | M1–M4 por fase |
| R7 | Licencias | B | A | política §3; *fixtures* solo de código propio o permisivo | revisión en cada informe |
| R8 | Las herramientas (SwiftShader, etc.) no están en tu máquina | M | B | los tests de ejecución son opcionales en `ctest`; `tools/gpu_toolchain` las reconstruye | `ctest` sin la opción sigue verde |
| R9 | El entorno actual tiene 2 núcleos: compilar SwiftShader y correr el corpus es lento | M | B | herramientas ya construidas aquí; corpus por lotes | tiempos en el informe |

## 10. Decisiones que necesito
| # | Pregunta | Recomendación |
|---|---|---|
| D-P4-1 | ¿P4 (GPU *shader*) antes que P3.7 (AdvSIMD en el intérprete)? | **Sí**, como pides; P3.7 queda anotado |
| D-P4-2 | Política de código limpio (§3): nada de yuzu/Eden/Ryujinx como fuente | **Sí** |
| D-P4-3 | Registros como variables en P4.1, SSA propia en P4.5 | **Sí** |
| D-P4-4 | Despachador `loop+switch` como base de flujo de control, estructuración como optimización | **Sí** |
| D-P4-5 | Tests de ejecución con SwiftShader opcionales en `ctest` (activados aquí) | **Sí** |
| D-P4-6 | Empezar por *compute* (P4.1) y dejar gráficos y texturas para P4.2–P4.3 | **Sí**: es lo único que se puede verificar de punta a punta sin el frente de la GPU |
