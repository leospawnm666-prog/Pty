#include "resource_tracker.h"

namespace lg::memory {

const char* ResourceTracker::kind_name(ResourceKind k) {
    switch (k) {
        case ResourceKind::Texture: return "Texture";
        case ResourceKind::Buffer: return "Buffer";
        case ResourceKind::Sampler: return "Sampler";
        case ResourceKind::Pipeline: return "Pipeline";
        case ResourceKind::Framebuffer: return "Framebuffer";
        case ResourceKind::Other: return "Other";
        default: return "Unknown";
    }
}

uint64_t ResourceTracker::track(ResourceKind kind, uint64_t bytes, std::string tag) {
    std::lock_guard lock(mutex_);
    const uint64_t id = next_id_++;
    if (next_id_ == 0) next_id_ = 1; // never hand out id 0
    const size_t ki = static_cast<size_t>(kind);
    if (ki < kKinds) {
        ++count_by_kind_[ki];
        bytes_by_kind_[ki] += bytes;
    }
    cur_bytes_ += bytes;
    if (cur_bytes_ > peak_bytes_) peak_bytes_ = cur_bytes_;
    // Move tag in; empty string is SSO / cheap.
    live_.emplace(id, Res{kind, bytes, std::move(tag)});
    return id;
}

bool ResourceTracker::untrack(uint64_t id) {
    std::lock_guard lock(mutex_);
    auto it = live_.find(id);
    if (it == live_.end()) {
        ++double_frees_;
        return false;
    }
    const size_t ki = static_cast<size_t>(it->second.kind);
    if (ki < kKinds) {
        if (count_by_kind_[ki] > 0) --count_by_kind_[ki];
        if (bytes_by_kind_[ki] >= it->second.bytes) bytes_by_kind_[ki] -= it->second.bytes;
        else bytes_by_kind_[ki] = 0;
    }
    if (cur_bytes_ >= it->second.bytes) cur_bytes_ -= it->second.bytes;
    else cur_bytes_ = 0;
    live_.erase(it);
    return true;
}

size_t ResourceTracker::live_count() const {
    std::lock_guard lock(mutex_);
    return live_.size();
}

size_t ResourceTracker::live_count(ResourceKind kind) const {
    std::lock_guard lock(mutex_);
    const size_t ki = static_cast<size_t>(kind);
    return ki < kKinds ? static_cast<size_t>(count_by_kind_[ki]) : 0;
}

uint64_t ResourceTracker::live_bytes() const {
    std::lock_guard lock(mutex_);
    return cur_bytes_;
}

uint64_t ResourceTracker::live_bytes(ResourceKind kind) const {
    std::lock_guard lock(mutex_);
    const size_t ki = static_cast<size_t>(kind);
    return ki < kKinds ? bytes_by_kind_[ki] : 0;
}

uint64_t ResourceTracker::peak_bytes() const {
    std::lock_guard lock(mutex_);
    return peak_bytes_;
}

uint64_t ResourceTracker::double_frees() const {
    std::lock_guard lock(mutex_);
    return double_frees_;
}

std::string ResourceTracker::leak_report() const {
    std::lock_guard lock(mutex_);
    std::string out = "ResourceTracker: live=" + std::to_string(live_.size()) +
                      " bytes=" + std::to_string(cur_bytes_) +
                      " peak=" + std::to_string(peak_bytes_) +
                      " double_frees=" + std::to_string(double_frees_);
    if (!live_.empty()) {
        out += " | still-held:";
        size_t n = 0;
        for (const auto& [id, res] : live_) {
            if (n++ >= 12) {
                out += " ...";
                break;
            }
            out += " [";
            out += kind_name(res.kind);
            out += "#";
            out += std::to_string(id);
            out += " ";
            out += std::to_string(res.bytes);
            out += "B";
            if (!res.tag.empty()) {
                out += " ";
                out += res.tag;
            }
            out += "]";
        }
    }
    return out;
}

void ResourceTracker::reset() {
    std::lock_guard lock(mutex_);
    live_.clear();
    live_.rehash(0); // release buckets after a session
    count_by_kind_.fill(0);
    bytes_by_kind_.fill(0);
    cur_bytes_ = 0;
    // peak_bytes_ intentionally retained across sessions for diagnostics
    double_frees_ = 0;
    next_id_ = 1;
}

} // namespace lg::memory
