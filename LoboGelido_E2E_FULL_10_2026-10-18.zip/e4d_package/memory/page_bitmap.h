#pragma once
#include <algorithm>
#include <atomic>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <memory>

namespace lg::memory {

/**
 * One bit per guest page, backed by 64-bit atomic words.
 *
 * Replaces per-page hash containers for dense regions: 4 GiB of 4 KiB pages is
 * 1,048,576 bits = 16,384 words = 128 KiB, and range operations touch whole words.
 *
 * Concurrency: test()/any()/count() may run concurrently with set_range()/clear_range().
 * Readers use acquire loads, writers release stores / read-modify-writes, so a reader
 * that observes a set bit also observes everything the writer published before setting
 * it. Construction, move and destruction are NOT concurrent operations.
 *
 * Bounds: every index is checked against size(); out-of-range bits read as 0 and writes
 * to them are ignored, so a bad guest address can never index past the allocation.
 */
class AtomicPageBitmap {
public:
    AtomicPageBitmap() = default;
    explicit AtomicPageBitmap(std::size_t pages)
        : pages_(pages), words_(word_count(pages)),
          bits_(words_ ? std::make_unique<std::atomic<uint64_t>[]>(words_) : nullptr) {
        for (std::size_t i = 0; i < words_; ++i) bits_[i].store(0, std::memory_order_relaxed);
    }
    AtomicPageBitmap(const AtomicPageBitmap&) = delete;
    AtomicPageBitmap& operator=(const AtomicPageBitmap&) = delete;
    AtomicPageBitmap(AtomicPageBitmap&& o) noexcept
        : pages_(o.pages_), words_(o.words_), bits_(std::move(o.bits_)) { o.pages_ = o.words_ = 0; }
    AtomicPageBitmap& operator=(AtomicPageBitmap&& o) noexcept {
        if (this != &o) {
            pages_ = o.pages_; words_ = o.words_; bits_ = std::move(o.bits_);
            o.pages_ = o.words_ = 0;
        }
        return *this;
    }

    std::size_t size() const noexcept { return pages_; }
    std::size_t storage_bytes() const noexcept { return words_ * sizeof(uint64_t); }

    bool test(std::size_t page) const noexcept {
        if (page >= pages_) return false;
        return (bits_[page >> 6].load(std::memory_order_acquire) >> (page & 63)) & 1u;
    }

    void set_range(std::size_t first, std::size_t count) noexcept { update(first, count, true); }
    void clear_range(std::size_t first, std::size_t count) noexcept { update(first, count, false); }
    void clear_all() noexcept {
        for (std::size_t i = 0; i < words_; ++i) bits_[i].store(0, std::memory_order_release);
    }

    /** True if any bit in [first, first+count) is set. */
    bool any(std::size_t first, std::size_t count) const noexcept {
        std::size_t b = 0, e = 0;
        if (!clamp(first, count, b, e)) return false;
        while (b < e) {
            const std::size_t w = b >> 6;
            const unsigned lo = static_cast<unsigned>(b & 63);
            const std::size_t span = std::min<std::size_t>(64 - lo, e - b);
            if (bits_[w].load(std::memory_order_acquire) & mask(lo, span)) return true;
            b += span;
        }
        return false;
    }

    /** Number of set bits in [first, first+count). */
    std::size_t count(std::size_t first, std::size_t count_) const noexcept {
        std::size_t b = 0, e = 0, n = 0;
        if (!clamp(first, count_, b, e)) return 0;
        while (b < e) {
            const std::size_t w = b >> 6;
            const unsigned lo = static_cast<unsigned>(b & 63);
            const std::size_t span = std::min<std::size_t>(64 - lo, e - b);
            n += static_cast<std::size_t>(std::popcount(bits_[w].load(std::memory_order_acquire) & mask(lo, span)));
            b += span;
        }
        return n;
    }
    std::size_t count_all() const noexcept { return count(0, pages_); }

    /** Atomically sets one bit; returns whether it was already set (exactly one caller
     *  sees false). Added in P2 phase E.2b. */
    bool fetch_set(std::size_t page) noexcept {
        if (page >= pages_) return true;
        const uint64_t bit = uint64_t{1} << (page & 63);
        return (bits_[page >> 6].fetch_or(bit, std::memory_order_acq_rel) & bit) != 0;
    }

    /** Atomically clears one bit; returns whether it was set (exactly one caller wins). */
    bool fetch_clear(std::size_t page) noexcept {
        if (page >= pages_) return false;
        const uint64_t bit = uint64_t{1} << (page & 63);
        return (bits_[page >> 6].fetch_and(~bit, std::memory_order_acq_rel) & bit) != 0;
    }

    /** Calls fn(page) for every set bit in [first, first+count), in ascending order. */
    template <class F>
    void for_each_set(std::size_t first, std::size_t count_, F&& fn) const {
        std::size_t b = 0, e = 0;
        if (!clamp(first, count_, b, e)) return;
        while (b < e) {
            const std::size_t w = b >> 6;
            const unsigned lo = static_cast<unsigned>(b & 63);
            const std::size_t span = std::min<std::size_t>(64 - lo, e - b);
            uint64_t bits = bits_[w].load(std::memory_order_acquire) & mask(lo, span);
            while (bits) {
                const unsigned tz = static_cast<unsigned>(std::countr_zero(bits));
                fn((w << 6) + tz);
                bits &= bits - 1;
            }
            b += span;
        }
    }

private:
    static std::size_t word_count(std::size_t pages) noexcept { return (pages + 63) / 64; }
    // `span` bits starting at bit `lo` (1 <= span <= 64 - lo).
    static uint64_t mask(unsigned lo, std::size_t span) noexcept {
        const uint64_t ones = span >= 64 ? ~uint64_t{0} : ((uint64_t{1} << span) - 1);
        return ones << lo;
    }
    bool clamp(std::size_t first, std::size_t count, std::size_t& b, std::size_t& e) const noexcept {
        if (count == 0 || first >= pages_) return false;
        b = first;
        e = (count > pages_ - first) ? pages_ : first + count;
        return true;
    }
    void update(std::size_t first, std::size_t count, bool set) noexcept {
        std::size_t b = 0, e = 0;
        if (!clamp(first, count, b, e)) return;
        while (b < e) {
            const std::size_t w = b >> 6;
            const unsigned lo = static_cast<unsigned>(b & 63);
            const std::size_t span = std::min<std::size_t>(64 - lo, e - b);
            const uint64_t m = mask(lo, span);
            if (m == ~uint64_t{0}) {
                bits_[w].store(set ? ~uint64_t{0} : 0, std::memory_order_release);
            } else if (set) {
                bits_[w].fetch_or(m, std::memory_order_acq_rel);
            } else {
                bits_[w].fetch_and(~m, std::memory_order_acq_rel);
            }
            b += span;
        }
    }

    std::size_t pages_{0};
    std::size_t words_{0};
    std::unique_ptr<std::atomic<uint64_t>[]> bits_;
};

} // namespace lg::memory
