#include "fastmem_window.h"
#include "mmu.h"

#include <algorithm>
#include <limits>

#if defined(__linux__) || defined(__ANDROID__)
#  include <sys/mman.h>
#  define LG_WINDOW_MMAP 1
#else
#  define LG_WINDOW_MMAP 0
#endif

namespace lg::memory {
namespace {
constexpr uint64_t kWindowSize = uint64_t{1} << FastmemWindow::kAddressBits;
}

FastmemWindow::~FastmemWindow() {
#if LG_WINDOW_MMAP
    if (base_) ::munmap(base_, static_cast<size_t>(kWindowSize));
#endif
}

bool FastmemWindow::bind(const AddressSpace& as) noexcept {
#if LG_WINDOW_MMAP
    if (!base_) {
        void* p = ::mmap(nullptr, static_cast<size_t>(kWindowSize), PROT_NONE,
                         MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (p == MAP_FAILED) return false;
        base_ = static_cast<uint8_t*>(p);
    } else {
        clear();
    }
    fd_ = as.arena_fd();
    arena_base_ = as.fastmem_guest_base();
    arena_size_ = as.fastmem_size();
    host_page_ = std::max<uint64_t>(as.arena_host_page(), 4096);
    return fd_ >= 0;
#else
    (void)as;
    return false;
#endif
}

bool FastmemWindow::in_window(uint64_t va, uint64_t size) const noexcept {
    return base_ && size != 0 && va < kWindowSize;
}

void FastmemWindow::guard(uint64_t va_lo, uint64_t va_hi) noexcept {
#if LG_WINDOW_MMAP
    if (va_hi <= va_lo) return;
    ::mmap(base_ + va_lo, static_cast<size_t>(va_hi - va_lo), PROT_NONE,
           MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE | MAP_FIXED, -1, 0);
    ++mappings_;
#else
    (void)va_lo; (void)va_hi;
#endif
}

void FastmemWindow::map(uint64_t va, uint64_t pa, uint64_t size, uint32_t permissions) noexcept {
#if LG_WINDOW_MMAP
    if (!bound() || !in_window(va, size)) return;
    size = std::min(size, kWindowSize - va);
    // Physical part inside the arena.
    if (pa > std::numeric_limits<uint64_t>::max() - size) return;
    const uint64_t pa_lo = std::max(pa, arena_base_);
    const uint64_t pa_hi = std::min(pa + size, arena_base_ + arena_size_);
    if (pa_lo >= pa_hi) return;
    uint64_t va_lo = va + (pa_lo - pa);
    uint64_t off = pa_lo - arena_base_;
    uint64_t len = pa_hi - pa_lo;
    // mmap needs va and file offset at the same host-page phase, and whole host pages.
    const uint64_t hp = host_page_;
    if (va_lo % hp != off % hp) return;                     // incongruent: stays PROT_NONE
    const uint64_t head = (hp - va_lo % hp) % hp;
    if (head >= len) return;
    va_lo += head; off += head; len -= head;
    len = len / hp * hp;
    if (len == 0) return;
    int prot = PROT_NONE;
    if (permissions & Read) prot |= PROT_READ;
    if (permissions & Write) prot |= PROT_READ | PROT_WRITE;
    if (prot == PROT_NONE) { guard(va_lo, va_lo + len); return; }
    if (::mmap(base_ + va_lo, static_cast<size_t>(len), prot, MAP_SHARED | MAP_FIXED, fd_,
               static_cast<off_t>(off)) == MAP_FAILED)
        guard(va_lo, va_lo + len);                          // never leave a stale mapping
    ++mappings_;
#else
    (void)va; (void)pa; (void)size; (void)permissions;
#endif
}

void FastmemWindow::unmap(uint64_t va, uint64_t size) noexcept {
    if (!base_ || !in_window(va, size)) return;
    size = std::min(size, kWindowSize - va);
    const uint64_t hp = host_page_;
    guard(va / hp * hp, std::min(kWindowSize, (va + size + hp - 1) / hp * hp));
}

void FastmemWindow::clear() noexcept {
    if (base_) guard(0, kWindowSize);
}

} // namespace lg::memory
