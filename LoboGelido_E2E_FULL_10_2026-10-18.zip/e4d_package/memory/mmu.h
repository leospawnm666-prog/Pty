#pragma once
#include <cstdint>
#include <array>
#include <vector>
#include <unordered_map>   // kept: part of this header's historical include surface
#include "../core/result.h"

namespace lg::memory {

enum Permission : uint32_t { Read=1u, Write=2u, Execute=4u, User=8u };
struct Translation { uint64_t physical{}; uint32_t permissions{}; };

// P2 phase E.2b: notified after every successful map / unmap / clear, with the caller's
// arguments (before region merging). Used to keep the JIT's fastmem window in sync. Called
// on the thread that changes the Mmu (the Mmu itself is not internally synchronized).
class MmuObserver {
public:
    virtual ~MmuObserver() = default;
    virtual void mmu_mapped(uint64_t va, uint64_t pa, uint64_t size, uint32_t permissions) noexcept = 0;
    virtual void mmu_unmapped(uint64_t va, uint64_t size) noexcept = 0;
    virtual void mmu_cleared() noexcept = 0;
};

// Guest virtual -> physical translation.
//
// P2 phase C: the page table is a sorted array of REGIONS ({first VPN, pages, first PPN,
// permissions}), searched by binary search; a 4 GiB mapping is one entry instead of 1 M
// hash nodes. Adjacent regions that are
// contiguous in both VA and PA with equal permissions are merged; a partial unmap splits
// a region. Results are identical page by page to the previous per-page table (verified
// differentially against tests/reference/mmu_ref). The generation-stamped TLB in front of
// it is unchanged.
//
// Thread-safety (unchanged): not internally synchronized - translate() refills the
// mutable TLB. All callers run under RuntimeCoordinator's mutex.
class Mmu {
public:
    static constexpr uint64_t PageBits = 12;
    static constexpr uint64_t PageSize = 1ull << PageBits;
    static constexpr uint64_t PageMask = PageSize - 1;
    bool map(uint64_t virtual_base, uint64_t physical_base, uint64_t size, uint32_t permissions);
    bool unmap(uint64_t virtual_base, uint64_t size);
    void invalidate_all() noexcept;
    void clear() noexcept;
    void invalidate_page(uint64_t virtual_address) noexcept;
    uint64_t generation() const noexcept { return generation_; }
    core::Result<Translation> translate(uint64_t virtual_address, bool write, bool execute=false) const;
    /** Diagnostics (P2 phase C, additive): regions in the table / guest pages mapped. */
    std::size_t region_count() const noexcept { return regions_.size(); }
    uint64_t mapped_page_count() const noexcept { return mapped_pages_; }
    /** P2 E.2b: one observer (nullptr = none). The caller keeps it alive while set. */
    void set_observer(MmuObserver* observer) noexcept { observer_ = observer; }
    MmuObserver* observer() const noexcept { return observer_; }
    /** P2 E.2b: the region containing `va` (false if none). */
    bool find_region(uint64_t va, uint64_t& region_va, uint64_t& region_pa, uint64_t& region_size,
                     uint32_t& permissions) const noexcept;
    /** P2 E.2b: calls fn(va, pa, size, permissions) for every region, in VA order. */
    template <class F> void for_each_region(F&& fn) const {
        for (const Region& r : regions_)
            fn(r.first_vpn << PageBits, r.first_ppn << PageBits, r.pages << PageBits, r.permissions);
    }
private:
    struct Region { uint64_t first_vpn{}; uint64_t pages{}; uint64_t first_ppn{}; uint32_t permissions{}; };
    // Index of the last region whose first_vpn <= vpn, or regions_.size() if none.
    std::size_t region_at_or_before(uint64_t vpn) const noexcept;
    // Generation-stamped TLB: invalidate_all is O(1) (bump generation_), not O(1024).
    struct TlbEntry {
        uint64_t virtual_page{};
        uint64_t physical_page{};
        uint32_t permissions{};
        uint64_t gen{};
    };
    // Sorted by first_vpn; regions never overlap. Contiguous so the TLB-miss binary
    // search stays in cache (a node-based tree was ~5x slower with hundreds of regions).
    std::vector<Region> regions_;
    uint64_t mapped_pages_{};
    MmuObserver* observer_{};
    mutable std::array<TlbEntry, 1024> tlb_{};
    uint64_t generation_{1};
    static size_t slot(uint64_t vpn) noexcept { return static_cast<size_t>((vpn * 11400714819323198485ull) >> 54); }
};

} // namespace lg::memory
