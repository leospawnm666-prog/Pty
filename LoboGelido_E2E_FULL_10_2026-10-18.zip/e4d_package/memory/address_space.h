#pragma once
#include <cstdint>
#include <optional>
#include <unordered_map>
#include <unordered_set>   // kept: part of this header's historical include surface
#include <vector>          // kept: part of this header's historical include surface
#include <algorithm>
#include <atomic>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include "page_bitmap.h"
namespace lg::memory {
// Guest physical memory.
//
// Two backing stores:
//  * the fastmem ARENA - one contiguous anonymous mapping; which of its 4 KiB pages are
//    mapped is tracked by an AtomicPageBitmap (1 bit/page, 128 KiB for 4 GiB);
//  * SPARSE pages outside the arena, owned through PagePool and indexed by pages_.
//
// Thread-safety contract:
//  * map / unmap / clear are serialized by map_mutex_;
//  * enable_fastmem is a setup-time operation (no concurrent accesses);
//  * host_ptr / read* / write* may run concurrently with each other and with
//    map / unmap: arena lookups are lock-free (acquire load of the bitmap) and the arena
//    stays mapped for the AddressSpace lifetime, so a racing access never touches freed
//    memory; sparse lookups take a shared lock.
//
// Unmapped arena pages are returned to the OS (MADV_DONTNEED) or zeroed, so a page is
// zero-filled every time it is mapped, exactly like sparse pages from PagePool.
class AddressSpace { public:
    AddressSpace();
    explicit AddressSpace(uint64_t fastmem_size) : AddressSpace() { enable_fastmem(fastmem_size); }
    ~AddressSpace() { clear(); release_fastmem(); }

    AddressSpace(const AddressSpace&) = delete;
    AddressSpace& operator=(const AddressSpace&) = delete;
    AddressSpace(AddressSpace&&) = delete;
    AddressSpace& operator=(AddressSpace&&) = delete;

    bool map(uint64_t guest, uint64_t size); bool unmap(uint64_t guest, uint64_t size); void clear() noexcept;
    std::optional<uint8_t> read8(uint64_t a) const; std::optional<uint32_t> read32(uint64_t a) const; std::optional<uint64_t> read64(uint64_t a) const;
    void write8(uint64_t a,uint8_t v); void write32(uint64_t a,uint32_t v); void write64(uint64_t a,uint64_t v);
    uint8_t* host_ptr(uint64_t a); const uint8_t* host_ptr(uint64_t a) const;
    // Single-lookup stores (P2 phase B, additive): write and report whether the access
    // was performed as ONE in-page access. false = unmapped, or the access crosses a page
    // (the caller decides how to split it). Same side effects as write8/32/64 on success.
    bool try_write8(uint64_t a, uint8_t v); bool try_write32(uint64_t a, uint32_t v); bool try_write64(uint64_t a, uint64_t v);
    // Changes whenever the MAP changes (map/unmap/clear/enable_fastmem) and on every
    // successful compare_exchange(). Since P2 phase E.1 ordinary stores no longer move it:
    // exclusives are value-based (LDXR remembers the value, STXR is a CAS), which removed a
    // global atomic RMW from every guest store.
    uint64_t write_epoch() const noexcept { return write_epoch_.load(std::memory_order_relaxed); }

    // ---- Value-based exclusive monitor support (P2 phase E.1) -----------------------
    /** Atomically replaces `size` bytes (1, 2, 4, 8 or 16) at guest address `a` with
     *  `desired` iff they equal `expected`. true = swapped. false for unmapped memory, an
     *  access crossing a guest page or an unsupported size. Accesses whose host address is
     *  misaligned, and all 16-byte ones, are serialized with each other by a lock (still
     *  atomic with respect to every other compare_exchange). A successful swap is a guest
     *  store: it moves write_epoch() and invalidates code on a watched page. */
    bool compare_exchange(uint64_t a, unsigned size, const void* expected, const void* desired) noexcept;
    /** Atomic (acquire) load of `size` bytes (1, 2, 4, 8) into `out`; false as above. */
    bool atomic_load(uint64_t a, unsigned size, void* out) const noexcept;

    // Optional contiguous guest arena used by JIT fastmem backends. It is deliberately
    // separate from the page map so correctness never depends on fastmem being enabled.
    // Backed by anonymous mmap so untouched regions cost almost no physical RAM.
    bool enable_fastmem(uint64_t size, uint64_t guest_base = 0);

    // P2 phase E.2b. Backing of the arena: Private (anonymous memory, phase D: commits are
    // accounted, so the kernel can refuse them) or Shared (a memfd: the same physical pages
    // can ALSO be mapped at other addresses - the JIT's fastmem window - but shared memory
    // is not commit-accounted, so the RAM budget is the only limit). Same guards,
    // zero-fill and RAM return in both.
    enum class ArenaBacking { Private, Shared };
    bool enable_fastmem(uint64_t size, uint64_t guest_base, ArenaBacking backing);
    ArenaBacking arena_backing() const noexcept { return arena_fd_ >= 0 ? ArenaBacking::Shared : ArenaBacking::Private; }
    /** File descriptor of a Shared arena (offset = guest address - fastmem_guest_base()), or -1. */
    int arena_fd() const noexcept { return arena_fd_; }
    /** Changes every time the arena is created or released (consumers holding aliases rebind). */
    uint64_t arena_generation() const noexcept { return arena_generation_.load(std::memory_order_acquire); }
    /** Host page size the arena was created with (4 or 16 KiB). */
    uint64_t arena_host_page() const noexcept { return arena_host_page_; }
    bool has_fastmem() const noexcept { return fastmem_ != nullptr; }
    uint64_t fastmem_size() const noexcept { return fastmem_size_; }
    uint64_t fastmem_guest_base() const noexcept { return fastmem_guest_base_; }
    bool fastmem_contains(uint64_t a, uint64_t size = 1) const noexcept;
    uint8_t* fastmem_base() noexcept { return fastmem_; }
    const uint8_t* fastmem_base() const noexcept { return fastmem_; }

    // ---- Arena reservation / commit (P2 phase D) ------------------------------------
    // The arena is RESERVED with PROT_NONE (no RAM, no commit charge) and host pages are
    // COMMITTED (mprotect RW, accounted by the kernel) when map() first covers them. If
    // the kernel refuses the commit, map() returns false and changes nothing. Pages never
    // committed stay PROT_NONE: a direct access through fastmem_base() faults instead of
    // reading garbage. unmap() returns the RAM (madvise) but keeps the pages committed:
    // accessors racing an unmap read zeros instead of faulting (re-guarding needs the
    // JIT's fault handler, phase E). Commit is tracked per HOST page (4 or 16 KiB).
    /** Bytes of the arena currently committed (read/write). */
    uint64_t fastmem_committed_bytes() const noexcept;
    /** true when the arena is a PROT_NONE reservation with commit-on-map guards. */
    bool fastmem_has_guards() const noexcept { return arena_reserved_; }

    /** Diagnostics for the sparse page pool. */
    std::size_t sparse_page_count() const noexcept;

    /** Diagnostics: guest pages currently mapped (arena + sparse). Added in P2 phase A. */
    std::size_t mapped_page_count() const noexcept;

    /** Test hook: pretend the host page size is `bytes` (0 = use the real one). */
    static void set_host_page_size_for_testing(std::size_t bytes) noexcept;

    // ---- Code-page tracking (P2 phase B) -------------------------------------------
    // A consumer that caches anything derived from guest code (decoded instructions, JIT
    // translations) calls watch_code_page() BEFORE reading the code bytes. The first
    // write to a watched page un-watches it and appends the page to a change log. Every
    // consumer reads that log with its OWN cursor, so several consumers of one
    // AddressSpace (interpreter backend, block backend, JIT + fallback) never steal each
    // other's invalidations. write_epoch() is unaffected: it still serves the exclusive
    // monitor (LDXR/STXR).
    static constexpr std::size_t kCodeLogEntries = 1024;
    void watch_code_page(uint64_t address) noexcept;
    /** Same as watch_code_page(); returns the watch-log sequence of THIS call's
     *  not-watched -> watched transition, or 0 if the page was already watched / not
     *  mapped. Lets a consumer skip exactly its own entry in watches_since(). (E.2b) */
    uint64_t watch_code_page_seq(uint64_t address) noexcept;
    bool is_code_page(uint64_t address) const noexcept;
    /** Sequence number of the latest code change; equal to a cursor means nothing new. */
    uint64_t code_epoch() const noexcept { return code_seq_.load(std::memory_order_acquire); }
    /** Calls on_page(page_address) for each code page changed after `cursor` and advances
     *  it. Returns false when the consumer must drop EVERYTHING instead (log wrapped,
     *  clear(), enable_fastmem(), large unmap); the cursor is advanced in both cases. */
    template <class F> bool code_changes_since(uint64_t& cursor, F&& on_page) const;

    // ---- Newly watched pages (P2 phase E.2b) ----------------------------------------
    // Consumers that let generated code access guest memory DIRECTLY (the JIT's page
    // table and fastmem window) bypass note_write(), so they must stop writing a page
    // directly as soon as ANY consumer starts watching it (e.g. the fallback interpreter
    // decoding an instruction on a data page). watch_code_page() logs every not-watched
    // -> watched transition here; such consumers drain it with their own cursor at their
    // synchronisation points (same-thread: immediately after the fallback; cross-thread:
    // guest synchronisation points, as for code changes).
    static constexpr std::size_t kWatchLogEntries = 256;
    uint64_t watch_epoch() const noexcept { return watch_seq_.load(std::memory_order_acquire); }
    /** Calls on_page(page_address) for each page newly watched after `cursor` and
     *  advances it. false = log wrapped: re-check every page the consumer accesses directly. */
    template <class F> bool watches_since(uint64_t& cursor, F&& on_page) const;
    /** Calls fn(page_address) for every watched ARENA page in [address, address+size). */
    template <class F> void for_each_arena_code_page(uint64_t address, uint64_t size, F&& fn) const;
private:
    void release_fastmem() noexcept;
    // Zero-fills / returns to the OS the arena guest pages [first, first+count) that are
    // NOT mapped. Caller holds map_mutex_ and has already cleared their bitmap bits.
    void scrub_arena_pages(uint64_t first, uint64_t count) noexcept;
    // P2 phase D. Arena byte offsets; caller holds map_mutex_ (or is enable/release).
    bool commit_arena(uint64_t offset, uint64_t length) noexcept;
    void zero_arena(uint64_t offset, uint64_t length) noexcept;   // skips uncommitted pages
    struct SparsePage {
        explicit SparsePage(uint8_t* d) noexcept : data(d) {}
        uint8_t* data;
        std::atomic<uint8_t> flags{0};      // kCodeWatched; node-stable (unordered_map)
    };
    static constexpr uint8_t kCodeWatched = 1;
    struct CodeLogSlot {
        std::atomic<uint64_t> seq{0};       // 0 = being written; else the entry's sequence
        std::atomic<uint64_t> page{0};
    };

    const uint8_t* sparse_ptr(uint64_t a) const;
    const uint8_t* sparse_lookup(uint64_t a, std::atomic<uint8_t>** flags) const;
    static constexpr size_t kNoArenaIndex = ~size_t{0};
    // Host pointer for a store + where its code-watch state lives: the arena page index,
    // or the sparse page's flags. One lookup serves both the store and note_write().
    uint8_t* resolve(uint64_t a, std::atomic<uint8_t>*& sparse_flags, size_t& arena_idx);
    void note_write(uint64_t a, std::atomic<uint8_t>* sparse_flags, size_t arena_idx) noexcept;
    void log_code_change(uint64_t page) noexcept;
    void log_code_flush() noexcept;
    uint64_t log_watch(uint64_t page) noexcept;                    // P2 E.2b; returns seq
    void restamp_sparse() noexcept;   // caller holds the unique sparse lock

    // Sparse pages: host pointer owned by PagePool (not std::vector). The key set IS the
    // set of mapped sparse pages (the former mapped_pages_ duplicate is gone).
    std::unordered_map<uint64_t, SparsePage> pages_;
    mutable std::shared_mutex sparse_mutex_;
    // Globally unique stamp of the current sparse map state, re-stamped (under the unique
    // lock) by every sparse map/unmap/clear. Validates the per-thread lookup cache in
    // sparse_ptr(); unique across instances, so a new AddressSpace at a recycled address
    // can never hit entries cached for a destroyed one.
    std::atomic<uint64_t> sparse_generation_;
    std::mutex map_mutex_;

    uint8_t* fastmem_{nullptr};
    bool fastmem_is_mmap_{false};
    // P2 phase D: the raw reservation (fastmem_ is aligned inside it), its host page size
    // (captured at enable time) and the committed host pages.
    uint8_t* arena_reservation_{nullptr};
    uint64_t arena_reservation_size_{};
    uint64_t arena_host_page_{};
    bool arena_reserved_{false};
    AtomicPageBitmap arena_committed_;
    int arena_fd_{-1};                                   // P2 E.2b: memfd of a Shared arena
    std::atomic<uint64_t> arena_generation_{0};
    AtomicPageBitmap fastmem_mapped_;   // replaces std::vector<uint8_t> fastmem_mapped_pages_
    AtomicPageBitmap code_watch_;       // arena pages some consumer derived code from
    uint64_t fastmem_size_{};
    uint64_t fastmem_guest_base_{};
    static constexpr uint64_t P=4096;
    std::atomic<uint64_t> write_epoch_{0};

    std::unique_ptr<CodeLogSlot[]> code_log_;
    std::atomic<uint64_t> code_seq_{0};
    std::atomic<uint64_t> code_flush_seq_{0};
    std::unique_ptr<CodeLogSlot[]> watch_log_;                       // P2 E.2b
    std::atomic<uint64_t> watch_seq_{0};
};

template <class F>
bool AddressSpace::code_changes_since(uint64_t& cursor, F&& on_page) const {
    const uint64_t cur = code_seq_.load(std::memory_order_acquire);
    if (cur == cursor) return true;
    const uint64_t from = cursor;
    cursor = cur;
    if (cur < from) return false;                                        // defensive
    if (code_flush_seq_.load(std::memory_order_acquire) > from) return false;
    if (cur - from > kCodeLogEntries) return false;                      // log wrapped
    for (uint64_t seq = from + 1; seq <= cur; ++seq) {
        const CodeLogSlot& slot = code_log_[seq % kCodeLogEntries];
        // Seqlock read: the entry is valid only if its sequence is `seq` before and after.
        const uint64_t before = slot.seq.load(std::memory_order_acquire);
        const uint64_t page = slot.page.load(std::memory_order_relaxed);
        std::atomic_thread_fence(std::memory_order_acquire);
        const uint64_t after = slot.seq.load(std::memory_order_relaxed);
        if (before != seq || after != seq) return false;                 // unpublished/overwritten
        on_page(page);
    }
    return true;
}

template <class F>
bool AddressSpace::watches_since(uint64_t& cursor, F&& on_page) const {
    const uint64_t cur = watch_seq_.load(std::memory_order_acquire);
    if (cur == cursor) return true;
    const uint64_t from = cursor;
    cursor = cur;
    if (cur < from || cur - from > kWatchLogEntries) return false;
    for (uint64_t seq = from + 1; seq <= cur; ++seq) {
        const CodeLogSlot& slot = watch_log_[seq % kWatchLogEntries];
        const uint64_t before = slot.seq.load(std::memory_order_acquire);
        const uint64_t page = slot.page.load(std::memory_order_relaxed);
        std::atomic_thread_fence(std::memory_order_acquire);
        const uint64_t after = slot.seq.load(std::memory_order_relaxed);
        if (before != seq || after != seq) return false;
        on_page(page);
    }
    return true;
}

template <class F>
void AddressSpace::for_each_arena_code_page(uint64_t address, uint64_t size, F&& fn) const {
    if (!fastmem_ || size == 0) return;
    const uint64_t lo = std::max(address, fastmem_guest_base_);
    const uint64_t end = address + size < address ? ~uint64_t{0} : address + size;
    const uint64_t hi = std::min(end, fastmem_guest_base_ + fastmem_size_);
    if (lo >= hi) return;
    const uint64_t first = (lo - fastmem_guest_base_) / P;
    const uint64_t last = (hi - fastmem_guest_base_ + P - 1) / P;
    code_watch_.for_each_set(static_cast<size_t>(first), static_cast<size_t>(last - first),
                             [&](size_t idx) { fn(fastmem_guest_base_ + uint64_t(idx) * P); });
}
}
