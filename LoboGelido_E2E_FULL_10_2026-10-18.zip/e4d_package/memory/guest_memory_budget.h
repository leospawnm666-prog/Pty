#pragma once
#include <cstdint>

namespace lg::memory {

// Guest memory budget (P2 phase D).
//
// The emulated console has 4 GiB of DRAM. A phone must keep enough RAM for Android, the
// GPU driver and the app itself, so the guest arena is sized from the device's physical
// RAM instead of a fixed constant:
//
//   budget = physical RAM / 2, rounded down to 64 MiB, clamped to [16 MiB, 4 GiB]
//   (physical RAM unknown -> 16 MiB, the size used before phase D)
//
// e.g. 4 GB phone (~3.6 GiB visible) -> 1.75 GiB, 6 GB -> ~2.7 GiB, 8 GB -> ~3.6 GiB,
// 12 GB and up -> 4 GiB. Only the COMMIT is sized here; RAM is used as the guest touches
// it. The ratio is provisional until it is measured on devices.
inline constexpr uint64_t kGuestMemoryMax = 4ull << 30;
inline constexpr uint64_t kGuestMemoryMin = 16ull << 20;
inline constexpr uint64_t kGuestMemoryGranule = 64ull << 20;

/** Physical RAM of this device in bytes (sysconf), or 0 when it cannot be read. */
uint64_t physical_ram_bytes() noexcept;

/** Guest arena size for a device with `physical_ram` bytes (0 = unknown). */
constexpr uint64_t guest_memory_budget(uint64_t physical_ram) noexcept {
    if (physical_ram == 0) return kGuestMemoryMin;
    uint64_t budget = physical_ram / 2 / kGuestMemoryGranule * kGuestMemoryGranule;
    if (budget > kGuestMemoryMax) budget = kGuestMemoryMax;
    if (budget < kGuestMemoryMin) budget = kGuestMemoryMin;
    return budget;
}

} // namespace lg::memory
