#include <cstring>
#include <limits>
#include <algorithm>
#include <cerrno>
#include <new>
#include <mutex>

#if defined(__linux__) || defined(__ANDROID__)
#  include <sys/mman.h>
#  include <sys/syscall.h>
#  include <fcntl.h>
#  include <unistd.h>
#  define LOBO_HAS_MMAP 1
#else
#  define LOBO_HAS_MMAP 0
#endif

#include "address_space.h"
#include "page_pool.h"

namespace lg::memory {

namespace {

std::atomic<std::size_t> g_host_page_override{0};
std::atomic<uint64_t> g_sparse_stamp{0};   // source of globally unique generations

uint64_t next_sparse_stamp() noexcept { return g_sparse_stamp.fetch_add(1, std::memory_order_relaxed) + 1; }

// Per-thread direct-mapped cache of sparse page lookups (interpreter fetch + data pages
// alternate, so one entry would thrash). An entry is valid only while its generation
// equals the owner's current sparse_generation_.
struct SparseCacheEntry {
    const void* owner{nullptr};
    uint64_t generation{0};
    uint64_t page{~uint64_t{0}};
    const uint8_t* host{nullptr};
    void* flags{nullptr};          // std::atomic<uint8_t>* of the SparsePage
};
constexpr std::size_t kSparseCacheEntries = 16;
thread_local SparseCacheEntry t_sparse_cache[kSparseCacheEntries];

// Host (kernel) page size: 4 KiB or 16 KiB on Android 15+ devices. madvise works in
// host pages, guest pages are 4 KiB, so one host page may hold several guest pages.
std::size_t host_page_size() noexcept {
    const std::size_t forced = g_host_page_override.load(std::memory_order_relaxed);
    if (forced) return forced;
#if LOBO_HAS_MMAP
    static const std::size_t real = [] {
        const long v = ::sysconf(_SC_PAGESIZE);
        return v > 0 ? static_cast<std::size_t>(v) : std::size_t{4096};
    }();
    return real;
#else
    return 4096;
#endif
}

} // namespace

AddressSpace::AddressSpace()
    : sparse_generation_(next_sparse_stamp()),
      code_log_(std::make_unique<CodeLogSlot[]>(kCodeLogEntries)),
      watch_log_(std::make_unique<CodeLogSlot[]>(kWatchLogEntries)) {}

void AddressSpace::log_code_change(uint64_t page) noexcept {
    const uint64_t seq = code_seq_.fetch_add(1, std::memory_order_acq_rel) + 1;
    CodeLogSlot& slot = code_log_[seq % kCodeLogEntries];
    // Seqlock write: invalidate, publish the payload, then the sequence.
    slot.seq.store(0, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_release);
    slot.page.store(page, std::memory_order_relaxed);
    slot.seq.store(seq, std::memory_order_release);
}

uint64_t AddressSpace::log_watch(uint64_t page) noexcept {
    const uint64_t seq = watch_seq_.fetch_add(1, std::memory_order_acq_rel) + 1;
    CodeLogSlot& slot = watch_log_[seq % kWatchLogEntries];
    slot.seq.store(0, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_release);
    slot.page.store(page, std::memory_order_relaxed);
    slot.seq.store(seq, std::memory_order_release);
    return seq;
}

void AddressSpace::log_code_flush() noexcept {
    const uint64_t seq = code_seq_.fetch_add(1, std::memory_order_acq_rel) + 1;
    code_flush_seq_.store(seq, std::memory_order_release);
}

void AddressSpace::restamp_sparse() noexcept {
    sparse_generation_.store(next_sparse_stamp(), std::memory_order_release);
}

void AddressSpace::set_host_page_size_for_testing(std::size_t bytes) noexcept {
    g_host_page_override.store(bytes, std::memory_order_relaxed);
}

void AddressSpace::release_fastmem() noexcept {
    if (!fastmem_) return;
#if LOBO_HAS_MMAP
    if (arena_reserved_) {
        ::munmap(arena_reservation_, static_cast<size_t>(arena_reservation_size_));
    } else if (fastmem_is_mmap_) {
        ::munmap(fastmem_, static_cast<size_t>(fastmem_size_));
    } else
#endif
    {
        delete[] fastmem_;
    }
    fastmem_ = nullptr;
    fastmem_is_mmap_ = false;
    arena_reservation_ = nullptr;
    arena_reservation_size_ = 0;
    arena_host_page_ = 0;
    arena_reserved_ = false;
    arena_committed_ = AtomicPageBitmap{};
#if LOBO_HAS_MMAP
    if (arena_fd_ >= 0) ::close(arena_fd_);
#endif
    arena_fd_ = -1;
    arena_generation_.fetch_add(1, std::memory_order_acq_rel);
    fastmem_size_ = 0;
    fastmem_guest_base_ = 0;
    fastmem_mapped_ = AtomicPageBitmap{};
    code_watch_ = AtomicPageBitmap{};
    if (code_log_) log_code_flush();
}

bool AddressSpace::enable_fastmem(uint64_t size, uint64_t guest_base) {
    return enable_fastmem(size, guest_base, ArenaBacking::Private);
}

bool AddressSpace::enable_fastmem(uint64_t size, uint64_t guest_base, ArenaBacking backing) {
    if (size == 0 || (size & (P - 1)) != 0) return false;
    if (size > (1ull << 32)) return false; // bounded mobile-friendly arena

    release_fastmem();

    uint8_t* storage = nullptr;
    bool used_mmap = false;
#if LOBO_HAS_MMAP
    // P2 phase D: RESERVE only. PROT_NONE private anonymous memory is neither backed nor
    // charged; host pages are committed by map() (commit_arena). MAP_NORESERVE is NOT
    // used on purpose: with it the later mprotect(RW) is not accounted either, so the
    // kernel could never refuse a commit and the failure would surface as an OOM kill
    // instead of map() == false (measured: Committed_AS +0 vs +1024 MiB for 1 GiB).
    // The arena is aligned to kArenaAlign so both 4 and 16 KiB host pages tile it; the
    // extra reservation covers the alignment and the last partial host page.
    const uint64_t hp = std::max<uint64_t>(host_page_size(), P);
    const uint64_t align = std::max<uint64_t>(hp, uint64_t{64} * 1024);
    const uint64_t reserve = size + 2 * align;
    void* mapped = ::mmap(nullptr, static_cast<size_t>(reserve), PROT_NONE,
                          MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mapped != MAP_FAILED) {
        const auto raw = reinterpret_cast<uintptr_t>(mapped);
        storage = reinterpret_cast<uint8_t*>((raw + align - 1) & ~static_cast<uintptr_t>(align - 1));
        used_mmap = true;
        arena_reservation_ = static_cast<uint8_t*>(mapped);
        arena_reservation_size_ = reserve;
        arena_host_page_ = hp;
        arena_reserved_ = true;
        arena_committed_ = AtomicPageBitmap(static_cast<size_t>((size + hp - 1) / hp));
        if (backing == ArenaBacking::Shared) {
            // P2 E.2b: the arena's pages are a memfd mapped over the (aligned) reservation,
            // still PROT_NONE until committed. Sparse file: no RAM until touched.
            const uint64_t file_size = (size + hp - 1) / hp * hp;
            const int fd = static_cast<int>(::syscall(SYS_memfd_create, "lobogelido-guest", 1u /*MFD_CLOEXEC*/));
            bool ok = fd >= 0 && ::ftruncate(fd, static_cast<off_t>(file_size)) == 0;
            ok = ok && ::mmap(storage, static_cast<size_t>(file_size), PROT_NONE, MAP_SHARED | MAP_FIXED, fd, 0) != MAP_FAILED;
            if (!ok) {
                if (fd >= 0) ::close(fd);
                ::munmap(mapped, static_cast<size_t>(reserve));
                arena_reservation_ = nullptr;
                arena_reservation_size_ = 0;
                arena_reserved_ = false;
                arena_committed_ = AtomicPageBitmap{};
                return false;                              // the caller can fall back to Private
            }
            arena_fd_ = fd;
        }
    }
#else
    if (backing == ArenaBacking::Shared) return false;
#endif
    if (backing == ArenaBacking::Shared && arena_fd_ < 0) return false;   // never silently Private
    if (!storage) {
        storage = new (std::nothrow) uint8_t[static_cast<size_t>(size)];
        if (!storage) return false;
        std::memset(storage, 0, static_cast<size_t>(size));
    }

    fastmem_ = storage;
    fastmem_is_mmap_ = used_mmap;
    fastmem_size_ = size;
    fastmem_mapped_ = AtomicPageBitmap(static_cast<size_t>(size / P));
    code_watch_ = AtomicPageBitmap(static_cast<size_t>(size / P));
    log_code_flush();
    fastmem_guest_base_ = guest_base;
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    arena_generation_.fetch_add(1, std::memory_order_acq_rel);
    return true;
}

bool AddressSpace::fastmem_contains(uint64_t a, uint64_t size) const noexcept {
    if (!fastmem_ || size == 0 || a < fastmem_guest_base_) return false;
    const uint64_t off = a - fastmem_guest_base_;
    return off < fastmem_size_ && size <= fastmem_size_ - off;
}

bool AddressSpace::commit_arena(uint64_t offset, uint64_t length) noexcept {
    if (!arena_reserved_ || length == 0) return true;
#if LOBO_HAS_MMAP
    const uint64_t hp = arena_host_page_;
    const size_t first = static_cast<size_t>(offset / hp);
    const size_t last = static_cast<size_t>((offset + length - 1) / hp);   // inclusive
    const size_t count = last - first + 1;
    const auto protect = [&](size_t a, size_t n) {
        return ::mprotect(fastmem_ + uint64_t(a) * hp, static_cast<size_t>(uint64_t(n) * hp),
                          PROT_READ | PROT_WRITE) == 0;
    };
    if (arena_committed_.count(first, count) == count) return true;       // all committed
    if (!arena_committed_.any(first, count)) {                            // common: one call
        if (!protect(first, count)) return false;
        arena_committed_.set_range(first, count);
        return true;
    }
    // Mixed: commit each uncommitted run. Runs committed before a failure stay committed
    // (and are recorded): harmless, they are zero and simply available to later maps.
    for (size_t i = first; i <= last;) {
        if (arena_committed_.test(i)) { ++i; continue; }
        size_t j = i;
        while (j + 1 <= last && !arena_committed_.test(j + 1)) ++j;
        if (!protect(i, j - i + 1)) return false;
        arena_committed_.set_range(i, j - i + 1);
        i = j + 1;
    }
    return true;
#else
    (void)offset;
    return true;
#endif
}

void AddressSpace::zero_arena(uint64_t offset, uint64_t length) noexcept {
    if (length == 0) return;
    if (!arena_reserved_) { std::memset(fastmem_ + offset, 0, static_cast<size_t>(length)); return; }
    // Never-committed host pages are PROT_NONE and have never been written: they are
    // zero already, and touching them would fault.
    const uint64_t hp = arena_host_page_;
    const uint64_t end = offset + length;
    for (uint64_t h = offset / hp * hp; h < end; h += hp) {
        if (!arena_committed_.test(static_cast<size_t>(h / hp))) continue;
        const uint64_t b = std::max(h, offset), e = std::min(h + hp, end);
        std::memset(fastmem_ + b, 0, static_cast<size_t>(e - b));
    }
}

uint64_t AddressSpace::fastmem_committed_bytes() const noexcept {
    if (!fastmem_) return 0;
    if (!arena_reserved_) return fastmem_size_;
    return std::min<uint64_t>(uint64_t(arena_committed_.count_all()) * arena_host_page_, fastmem_size_);
}

namespace {
// Pages p_i = first + i*P, i in [0, pages). Returns the contiguous sub-range [lo, hi) of
// i for which fastmem_contains(p_i, P) holds, i.e. base <= p_i <= base + size - P.
// Equivalent to testing every page, in O(1).
struct ArenaSplit { uint64_t lo{0}, hi{0}; };
ArenaSplit split_arena(bool enabled, uint64_t base, uint64_t size, uint64_t first, uint64_t pages) noexcept {
    constexpr uint64_t PG = 4096;
    ArenaSplit r;
    if (!enabled || size < PG || pages == 0) return r;
    const uint64_t lo = first >= base ? 0 : (base - first + PG - 1) / PG;
    const uint64_t span = size - PG;
    const uint64_t lim = base > std::numeric_limits<uint64_t>::max() - span ? std::numeric_limits<uint64_t>::max() : base + span;
    const uint64_t hi = lim >= first ? (lim - first) / PG + 1 : 0;
    r.lo = std::min(lo, pages);
    r.hi = std::min(hi, pages);
    if (r.lo > r.hi) r.lo = r.hi;
    return r;
}
} // namespace

void AddressSpace::scrub_arena_pages(uint64_t first, uint64_t count) noexcept {
    if (!fastmem_ || count == 0) return;
    // Guest page p lives at arena bytes [p - base, p - base + P). With a page-unaligned
    // base that is (index * P + phase); only whole pages inside the arena are valid.
    const uint64_t phase = (P - (fastmem_guest_base_ % P)) % P;
    if (fastmem_size_ < phase + P) return;
    const uint64_t total = (fastmem_size_ - phase) / P;
    if (first >= total) return;
    count = std::min(count, total - first);

    const auto zero_guest_pages = [this, phase](uint64_t b, uint64_t n) {
        zero_arena(b * P + phase, n * P);                 // skips never-committed pages
    };
#if LOBO_HAS_MMAP
    const uint64_t hp = host_page_size();
    // madvise needs host-page-aligned ranges: only for an aligned arena (the runtime's).
    if (fastmem_is_mmap_ && phase == 0 && hp >= P && hp % P == 0) {
        const uint64_t per = hp / P;                      // guest pages per host page
        const uint64_t end = first + count;
        const auto release = [&](uint64_t gfirst, uint64_t gcount) {
            bool released = false;
            if (arena_fd_ >= 0) {
                // Shared arena: madvise would only drop THIS mapping's view; punching a
                // hole frees the file pages and makes every alias read zeros.
                released = ::fallocate(arena_fd_, 0x02 | 0x01 /*PUNCH_HOLE|KEEP_SIZE*/,
                                       static_cast<off_t>(gfirst * P), static_cast<off_t>(gcount * P)) == 0;
            } else {
                released = ::madvise(fastmem_ + gfirst * P, static_cast<size_t>(gcount * P), MADV_DONTNEED) == 0;
            }
            if (!released) zero_guest_pages(gfirst, gcount);   // fallback keeps the zero-fill contract
        };
        // A host page only partly inside [first, end): release it only if none of its
        // guest pages is still mapped, otherwise zero just the guest pages in range.
        const auto boundary = [&](uint64_t host_first) {
            const uint64_t seg_b = std::max(first, host_first);
            const uint64_t seg_e = std::min(end, host_first + per);
            if (host_first + per <= total &&
                !fastmem_mapped_.any(static_cast<size_t>(host_first), static_cast<size_t>(per)))
                release(host_first, per);
            else
                zero_guest_pages(seg_b, seg_e - seg_b);
        };
        const uint64_t h0 = (first + per - 1) / per * per; // first host-aligned page >= first
        const uint64_t h1 = end / per * per;               // last host-aligned page <= end
        if (h0 >= h1) {                                    // no whole host page inside
            const uint64_t a = first / per * per, b = (end - 1) / per * per;
            boundary(a);
            if (b != a) boundary(b);
        } else {
            if (first < h0) boundary(h0 - per);
            release(h0, h1 - h0);                          // interior: every bit already clear
            if (h1 < end) boundary(h1);
        }
        return;
    }
#endif
    zero_guest_pages(first, count);
}

bool AddressSpace::map(uint64_t g, uint64_t size) {
    if (!size || g > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t first = g & ~(P - 1);
    const uint64_t pages = ((size - 1) / P) + 1;
    if (pages - 1 > (std::numeric_limits<uint64_t>::max() - first) / P) return false;

    std::lock_guard map_lock(map_mutex_);
    const ArenaSplit arena = split_arena(fastmem_ != nullptr, fastmem_guest_base_, fastmem_size_, first, pages);
    const uint64_t arena_count = arena.hi - arena.lo;
    const uint64_t arena_first = arena_count ? (first + arena.lo * P - fastmem_guest_base_) / P : 0;
    // Overlap check: arena part word-wise; sparse keys only where they can exist.
    if (arena_count && fastmem_mapped_.any(static_cast<size_t>(arena_first), static_cast<size_t>(arena_count)))
        return false;
    {
        std::shared_lock sparse_lock(sparse_mutex_);
        if (!pages_.empty()) {
            if (pages_.size() < pages) {
                for (const auto& [key, _] : pages_)
                    if (key >= first && (key - first) / P < pages && (key - first) % P == 0) return false;
            } else {
                for (uint64_t i = 0; i < pages; ++i)
                    if (pages_.contains(first + i * P)) return false;
            }
        }
    }
    // Acquire sparse pages first so a mid-loop OOM does not leave a partial map.
    std::vector<std::pair<uint64_t, uint8_t*>> acquired;
    try {
        for (uint64_t i = 0; i < pages; ++i) {
            if (i == arena.lo && arena_count) { i = arena.hi - 1; continue; }   // skip arena run
            acquired.emplace_back(first + i * P, PagePool::instance().acquire());
        }
    } catch (...) {
        for (auto& [_, ptr] : acquired) PagePool::instance().release(ptr);
        return false;
    }
    // P2 phase D: commit the arena host pages before anything becomes visible; if the
    // kernel refuses, undo the sparse acquisition and fail with no state change.
    if (arena_count && !commit_arena(first + arena.lo * P - fastmem_guest_base_, arena_count * P)) {
        for (auto& [_, ptr] : acquired) PagePool::instance().release(ptr);
        return false;
    }
    if (!acquired.empty()) {
        std::unique_lock sparse_lock(sparse_mutex_);
        for (auto& [p, ptr] : acquired)
            pages_.emplace(std::piecewise_construct, std::forward_as_tuple(p), std::forward_as_tuple(ptr));
        restamp_sparse();
    }
    // Arena pages are already zero (fresh mapping, or scrubbed by unmap/clear).
    // Publishing the bits last makes them visible only once they are usable.
    if (arena_count) fastmem_mapped_.set_range(static_cast<size_t>(arena_first), static_cast<size_t>(arena_count));
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

bool AddressSpace::unmap(uint64_t g, uint64_t size) {
    if (!size || g > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t first = g & ~(P - 1);
    const uint64_t pages = ((size - 1) / P) + 1;
    if (pages - 1 > (std::numeric_limits<uint64_t>::max() - first) / P) return false;

    std::lock_guard map_lock(map_mutex_);
    const ArenaSplit arena = split_arena(fastmem_ != nullptr, fastmem_guest_base_, fastmem_size_, first, pages);
    const uint64_t arena_count = arena.hi - arena.lo;
    const uint64_t arena_first = arena_count ? (first + arena.lo * P - fastmem_guest_base_) / P : 0;
    {
        std::unique_lock sparse_lock(sparse_mutex_);
        if (!pages_.empty()) {
            if (pages_.size() < pages) {
                for (auto it = pages_.begin(); it != pages_.end();) {
                    const uint64_t key = it->first;
                    if (key >= first && (key - first) / P < pages && (key - first) % P == 0) {
                        if (it->second.flags.load(std::memory_order_acquire) & kCodeWatched) log_code_change(key);
                        PagePool::instance().release(it->second.data);
                        it = pages_.erase(it);
                    } else {
                        ++it;
                    }
                }
            } else {
                for (uint64_t i = 0; i < pages; ++i) {
                    auto it = pages_.find(first + i * P);
                    if (it != pages_.end()) {
                        if (it->second.flags.load(std::memory_order_acquire) & kCodeWatched) log_code_change(it->first);
                        PagePool::instance().release(it->second.data);
                        pages_.erase(it);
                    }
                }
            }
            restamp_sparse();
        }
    }
    if (arena_count) {
        // Consumers must drop code derived from pages that disappear.
        const size_t watched = code_watch_.count(static_cast<size_t>(arena_first), static_cast<size_t>(arena_count));
        if (watched > kCodeLogEntries / 2) {
            log_code_flush();
        } else if (watched) {
            const uint64_t page_phase = (first + arena.lo * P) - arena_first * P;   // page address of index 0
            code_watch_.for_each_set(static_cast<size_t>(arena_first), static_cast<size_t>(arena_count),
                                     [&](size_t idx) { log_code_change(page_phase + uint64_t(idx) * P); });
        }
        code_watch_.clear_range(static_cast<size_t>(arena_first), static_cast<size_t>(arena_count));
        // Hide first, then scrub: a racing reader either misses the page or reads zeros.
        fastmem_mapped_.clear_range(static_cast<size_t>(arena_first), static_cast<size_t>(arena_count));
        scrub_arena_pages(arena_first, arena_count);
    }
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

const uint8_t* AddressSpace::sparse_lookup(uint64_t a, std::atomic<uint8_t>** flags) const {
    const uint64_t page = a & ~(P - 1);
    SparseCacheEntry& e = t_sparse_cache[(page / P) % kSparseCacheEntries];
    if (e.owner == this && e.page == page &&
        e.generation == sparse_generation_.load(std::memory_order_acquire)) {
        if (flags) *flags = static_cast<std::atomic<uint8_t>*>(e.flags);
        return e.host + (a & (P - 1));                     // hit: no lock
    }
    std::shared_lock sparse_lock(sparse_mutex_);
    auto it = pages_.find(page);
    if (it == pages_.end()) return nullptr;
    auto* page_flags = const_cast<std::atomic<uint8_t>*>(&it->second.flags);
    // The stamp read under the shared lock matches the map state just observed.
    e = SparseCacheEntry{this, sparse_generation_.load(std::memory_order_relaxed), page, it->second.data, page_flags};
    if (flags) *flags = page_flags;
    return it->second.data + (a & (P - 1));
}

const uint8_t* AddressSpace::sparse_ptr(uint64_t a) const { return sparse_lookup(a, nullptr); }

[[gnu::noinline]] uint8_t* AddressSpace::resolve(uint64_t a, std::atomic<uint8_t>*& sparse_flags, size_t& arena_idx) {
    sparse_flags = nullptr;
    arena_idx = kNoArenaIndex;
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        const size_t idx = static_cast<size_t>(((a & ~(P - 1)) - fastmem_guest_base_) / P);
        if (fastmem_mapped_.test(idx)) { arena_idx = idx; return fastmem_ + (a - fastmem_guest_base_); }
    }
    return const_cast<uint8_t*>(sparse_lookup(a, &sparse_flags));
}

// Cross-thread note: "watch, then re-read code" (consumer) vs "store, then check watch"
// (writer) is a store-buffer pattern; without seq_cst fences on both sides two threads
// may miss each other. Same-thread SMC is always caught. Cross-core SMC is guaranteed at
// guest synchronization points (IC IVAU / DSB / ISB, handled by the JIT integration in
// phase B.2), exactly as on real ARM hardware; we do not pay a full fence per store.
[[gnu::always_inline]] inline void AddressSpace::note_write(uint64_t a, std::atomic<uint8_t>* sparse_flags, size_t arena_idx) noexcept {
    if (arena_idx != kNoArenaIndex) {
        if (code_watch_.test(arena_idx) && code_watch_.fetch_clear(arena_idx)) log_code_change(a & ~(P - 1));
        return;
    }
    // Only the writer that clears the flag logs the change (one entry per cycle).
    if (sparse_flags && (sparse_flags->load(std::memory_order_relaxed) & kCodeWatched) &&
        (sparse_flags->fetch_and(static_cast<uint8_t>(~kCodeWatched), std::memory_order_acq_rel) & kCodeWatched))
        log_code_change(a & ~(P - 1));
}

void AddressSpace::watch_code_page(uint64_t address) noexcept { (void)watch_code_page_seq(address); }

uint64_t AddressSpace::watch_code_page_seq(uint64_t address) noexcept {
    if (fastmem_ && address >= fastmem_guest_base_ && address - fastmem_guest_base_ < fastmem_size_) {
        const size_t idx = static_cast<size_t>(((address & ~(P - 1)) - fastmem_guest_base_) / P);
        if (fastmem_mapped_.test(idx)) {
            if (!code_watch_.test(idx) && !code_watch_.fetch_set(idx)) return log_watch(address & ~(P - 1));
            return 0;
        }
    }
    std::atomic<uint8_t>* flags = nullptr;
    if (sparse_lookup(address, &flags) && flags &&
        !(flags->fetch_or(kCodeWatched, std::memory_order_acq_rel) & kCodeWatched))
        return log_watch(address & ~(P - 1));
    return 0;
}

bool AddressSpace::is_code_page(uint64_t address) const noexcept {
    if (fastmem_ && address >= fastmem_guest_base_ && address - fastmem_guest_base_ < fastmem_size_) {
        const size_t idx = static_cast<size_t>(((address & ~(P - 1)) - fastmem_guest_base_) / P);
        if (fastmem_mapped_.test(idx)) return code_watch_.test(idx);
    }
    std::atomic<uint8_t>* flags = nullptr;
    return sparse_lookup(address, &flags) && flags && (flags->load(std::memory_order_acquire) & kCodeWatched);
}

// noinline: keeps write8/32/64 compact. Measured (x86 -O2): letting the compiler inline
// the arena branch into every write* grew write64 from 43 to 70 instructions and cost
// ~1 ns per write; out-of-line it matches the pre-bitmap code within noise.
[[gnu::noinline]] uint8_t* AddressSpace::host_ptr(uint64_t a) {
    // Same body as the const overload (kept separate, like the original).
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        const uint64_t page = a & ~(P - 1);
        if (fastmem_mapped_.test(static_cast<size_t>((page - fastmem_guest_base_) / P)))
            return fastmem_ + (a - fastmem_guest_base_);
    }
    return const_cast<uint8_t*>(sparse_ptr(a));   // sparse pages are owned mutable storage
}

const uint8_t* AddressSpace::host_ptr(uint64_t a) const {
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        // Same index as the original byte map: page-aligned address minus base. With an
        // unaligned base the page may start below it; the unsigned wrap then indexes past
        // the bitmap and test() returns false, exactly like the old bounds check.
        const uint64_t page = a & ~(P - 1);
        if (fastmem_mapped_.test(static_cast<size_t>((page - fastmem_guest_base_) / P)))
            return fastmem_ + (a - fastmem_guest_base_);
    }
    return sparse_ptr(a);
}

std::optional<uint8_t> AddressSpace::read8(uint64_t a) const {
    auto p = host_ptr(a);
    return p ? std::optional<uint8_t>(*p) : std::nullopt;
}

std::optional<uint32_t> AddressSpace::read32(uint64_t a) const {
    if (a > std::numeric_limits<uint64_t>::max() - 3) return std::nullopt;
    if (const auto* p = host_ptr(a); p && ((a & (P - 1)) <= P - 4)) {
        uint32_t value{};
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    uint32_t value{};
    for (unsigned i = 0; i < 4; ++i) {
        const auto byte = read8(a + i);
        if (!byte) return std::nullopt;
        value |= uint32_t(*byte) << (8 * i);
    }
    return value;
}

std::optional<uint64_t> AddressSpace::read64(uint64_t a) const {
    if (a > std::numeric_limits<uint64_t>::max() - 7) return std::nullopt;
    if (const auto* p = host_ptr(a); p && ((a & (P - 1)) <= P - 8)) {
        uint64_t value{};
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    uint64_t value{};
    for (unsigned i = 0; i < 8; ++i) {
        const auto byte = read8(a + i);
        if (!byte) return std::nullopt;
        value |= uint64_t(*byte) << (8 * i);
    }
    return value;
}

bool AddressSpace::try_write8(uint64_t a, uint8_t v) {
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    auto p = resolve(a, flags, idx);
    if (!p) return false;
    *p = v;
    note_write(a, flags, idx);
    return true;
}

bool AddressSpace::try_write32(uint64_t a, uint32_t v) {
    if (a > std::numeric_limits<uint64_t>::max() - 3 || (a & (P - 1)) > P - 4) return false;
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    auto p = resolve(a, flags, idx);
    if (!p) return false;
    std::memcpy(p, &v, 4);
    note_write(a, flags, idx);
    return true;
}

bool AddressSpace::try_write64(uint64_t a, uint64_t v) {
    if (a > std::numeric_limits<uint64_t>::max() - 7 || (a & (P - 1)) > P - 8) return false;
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    auto p = resolve(a, flags, idx);
    if (!p) return false;
    std::memcpy(p, &v, 8);
    note_write(a, flags, idx);
    return true;
}

void AddressSpace::write8(uint64_t a, uint8_t v) {
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    if (auto p = resolve(a, flags, idx)) {
        *p = v;
        note_write(a, flags, idx);
    }
}

void AddressSpace::write32(uint64_t a, uint32_t v) {
    if (a > std::numeric_limits<uint64_t>::max() - 3) return;
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    if (auto p = resolve(a, flags, idx); p && ((a & (P - 1)) <= P - 4)) {
        std::memcpy(p, &v, 4);
        note_write(a, flags, idx);
        return;
    }
    for (unsigned i = 0; i < 4; i++) write8(a + i, uint8_t(v >> (8 * i)));
}

void AddressSpace::write64(uint64_t a, uint64_t v) {
    if (a > std::numeric_limits<uint64_t>::max() - 7) return;
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    if (auto p = resolve(a, flags, idx); p && ((a & (P - 1)) <= P - 8)) {
        std::memcpy(p, &v, 8);
        note_write(a, flags, idx);
        return;
    }
    for (unsigned i = 0; i < 8; i++) write8(a + i, uint8_t(v >> (8 * i)));
}

namespace {
// Serializes the compare_exchange cases that cannot use one hardware atomic (16 bytes, or
// a misaligned host address). They stay atomic with respect to each other.
std::mutex g_wide_cas_mutex;

template <class T>
bool cas_native(uint8_t* p, const void* expected, const void* desired) noexcept {
    T e, d;
    std::memcpy(&e, expected, sizeof(T));
    std::memcpy(&d, desired, sizeof(T));
    return __atomic_compare_exchange_n(reinterpret_cast<T*>(p), &e, d, false,
                                       __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
}
template <class T>
void load_native(const uint8_t* p, void* out) noexcept {
    const T v = __atomic_load_n(reinterpret_cast<const T*>(p), __ATOMIC_ACQUIRE);
    std::memcpy(out, &v, sizeof(T));
}
bool valid_access(uint64_t a, unsigned size, uint64_t page) noexcept {
    if (size == 0 || a > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    return (a & (page - 1)) <= page - size;
}
} // namespace

bool AddressSpace::compare_exchange(uint64_t a, unsigned size, const void* expected, const void* desired) noexcept {
    if (!(size == 1 || size == 2 || size == 4 || size == 8 || size == 16) || !valid_access(a, size, P)) return false;
    std::atomic<uint8_t>* flags = nullptr;
    size_t idx = kNoArenaIndex;
    uint8_t* p = resolve(a, flags, idx);
    if (!p) return false;
    bool swapped = false;
    if (size <= 8 && (reinterpret_cast<uintptr_t>(p) & (size - 1)) == 0) {
        switch (size) {
            case 1: swapped = cas_native<uint8_t>(p, expected, desired); break;
            case 2: swapped = cas_native<uint16_t>(p, expected, desired); break;
            case 4: swapped = cas_native<uint32_t>(p, expected, desired); break;
            default: swapped = cas_native<uint64_t>(p, expected, desired); break;
        }
    } else {
        std::lock_guard lock(g_wide_cas_mutex);
        swapped = std::memcmp(p, expected, size) == 0;
        if (swapped) std::memcpy(p, desired, size);
    }
    if (swapped) {
        write_epoch_.fetch_add(1, std::memory_order_relaxed);
        note_write(a, flags, idx);
    }
    return swapped;
}

bool AddressSpace::atomic_load(uint64_t a, unsigned size, void* out) const noexcept {
    if (!(size == 1 || size == 2 || size == 4 || size == 8) || !valid_access(a, size, P)) return false;
    const uint8_t* p = host_ptr(a);
    if (!p) return false;
    if ((reinterpret_cast<uintptr_t>(p) & (size - 1)) != 0) {
        std::lock_guard lock(g_wide_cas_mutex);
        std::memcpy(out, p, size);
        return true;
    }
    switch (size) {
        case 1: load_native<uint8_t>(p, out); break;
        case 2: load_native<uint16_t>(p, out); break;
        case 4: load_native<uint32_t>(p, out); break;
        default: load_native<uint64_t>(p, out); break;
    }
    return true;
}

void AddressSpace::clear() noexcept {
    std::lock_guard map_lock(map_mutex_);
    {
        std::unique_lock sparse_lock(sparse_mutex_);
        for (auto& [_, page] : pages_) {
            PagePool::instance().release(page.data);
        }
        pages_.clear();
        restamp_sparse();
    }
    code_watch_.clear_all();
    log_code_flush();
    if (fastmem_) {
        fastmem_mapped_.clear_all();
        scrub_arena_pages(0, fastmem_size_ / P);
    }
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
}

std::size_t AddressSpace::sparse_page_count() const noexcept {
    std::shared_lock sparse_lock(sparse_mutex_);
    return pages_.size();
}

std::size_t AddressSpace::mapped_page_count() const noexcept {
    return fastmem_mapped_.count_all() + sparse_page_count();
}

} // namespace lg::memory
