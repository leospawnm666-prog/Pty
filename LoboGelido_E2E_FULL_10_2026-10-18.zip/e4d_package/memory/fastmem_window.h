#pragma once
#include <cstdint>
#include "address_space.h"

namespace lg::memory {

// P2 phase E.2b: the JIT's fastmem window.
//
// A 2^kAddressBits-byte PROT_NONE reservation where guest VIRTUAL address va lives at
// base() + va. Every Mmu region whose physical pages are in a Shared arena is mapped
// there from the arena's memfd (the same RAM the host code uses through AddressSpace),
// with the region's permissions: R -> PROT_READ, RW -> PROT_READ|PROT_WRITE. Everything
// else stays PROT_NONE: unmapped memory, sparse pages, execute-only pages, host pages only
// partly covered by a region (4 KiB guest pages on 16 KiB host pages), and pages the JIT
// write-protects because it translated code from them. Dynarmic's fastmem accesses the
// window directly; a fault there makes it fall back to its page table / memory callbacks,
// which apply the exact semantics. Host code never touches the window, so the phase A
// race contract of AddressSpace is unaffected.
//
// Not thread-safe: driven by the thread that changes the Mmu and runs the JIT.
class FastmemWindow {
public:
    static constexpr unsigned kAddressBits = 36;          // 64 GiB of guest VA (address space only)

    FastmemWindow() = default;
    ~FastmemWindow();
    FastmemWindow(const FastmemWindow&) = delete;
    FastmemWindow& operator=(const FastmemWindow&) = delete;

    /** Reserves the window (once) and binds it to `as`'s Shared arena; every previous
     *  mapping is removed. false = no Shared arena or the reservation failed. */
    bool bind(const AddressSpace& as) noexcept;
    bool bound() const noexcept { return base_ != nullptr && fd_ >= 0; }
    uint8_t* base() const noexcept { return base_; }

    /** Mirrors Mmu::map (va -> pa, size, Permission bits). Only host pages lying ENTIRELY
     *  inside [va, va+size), backed by the arena and at the same host-page phase in va and
     *  pa are mapped; the caller must pass one region (or a part of it). Also used to
     *  write-protect / restore pages the JIT watches as code (same region, other perms). */
    void map(uint64_t va, uint64_t pa, uint64_t size, uint32_t permissions) noexcept;
    /** Mirrors Mmu::unmap: host pages touching the range become PROT_NONE. */
    void unmap(uint64_t va, uint64_t size) noexcept;
    /** Mirrors Mmu::clear. */
    void clear() noexcept;

    uint64_t host_page() const noexcept { return host_page_; }
    uint64_t mappings() const noexcept { return mappings_; }     // diagnostics: mmap calls done

private:
    bool in_window(uint64_t va, uint64_t size) const noexcept;
    void guard(uint64_t va_lo, uint64_t va_hi) noexcept;          // [va_lo, va_hi) host-page aligned

    uint8_t* base_{};
    int fd_{-1};
    uint64_t arena_base_{};
    uint64_t arena_size_{};
    uint64_t host_page_{4096};
    uint64_t mappings_{};
};

} // namespace lg::memory
