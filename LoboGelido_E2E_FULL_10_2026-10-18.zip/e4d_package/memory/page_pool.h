#pragma once

#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <mutex>
#include <vector>
#include <new>

namespace lg::memory {

/**
 * Thread-safe freelist of fixed 4 KiB guest pages.
 *
 * Sparse AddressSpace maps previously allocated a fresh std::vector<uint8_t>(4096)
 * per page and released it on unmap — high allocator traffic on load/unload.
 * This pool reuses pages so map/unmap stays O(1) without touching the global heap
 * on the steady-state path.
 */
class PagePool {
public:
    static constexpr std::size_t kPageSize = 4096;

    static PagePool& instance() {
        // Immortal on purpose: namespace-scope objects that own an AddressSpace (e.g. the
        // JNI host `g_host`) are constructed BEFORE this function-local static and are
        // therefore destroyed AFTER it; their ~AddressSpace releases pages here. A
        // destructible pool would be used after destruction at process exit / library
        // unload. The idle freelist stays reachable from this pointer, so it is not a
        // leak either (the OS reclaims it with the process).
        static PagePool* const pool = new PagePool();
        return *pool;
    }

    /** Acquire a zeroed page. Never returns nullptr; throws std::bad_alloc on OOM. */
    uint8_t* acquire() {
        {
            std::lock_guard lock(mutex_);
            if (!free_.empty()) {
                uint8_t* p = free_.back();
                free_.pop_back();
                ++live_;
                // Only clear on reuse — freshly malloc'd pages are indeterminate.
                std::memset(p, 0, kPageSize);
                return p;
            }
        }
        void* raw = std::malloc(kPageSize);
        if (!raw) throw std::bad_alloc();
        std::memset(raw, 0, kPageSize);
        std::lock_guard lock(mutex_);
        ++live_;
        ++allocated_;
        return static_cast<uint8_t*>(raw);
    }

    void release(uint8_t* page) noexcept {
        if (!page) return;
        std::lock_guard lock(mutex_);
        if (live_ > 0) --live_;
        // Cap the freelist so a pathological unmap storm cannot pin unbounded RAM.
        constexpr std::size_t kMaxCached = 4096; // 16 MiB of idle pages
        if (free_.size() < kMaxCached) {
            free_.push_back(page);
        } else {
            std::free(page);
            if (allocated_ > 0) --allocated_;
        }
    }

    /** Drop all cached free pages back to the OS. Live pages stay with owners. */
    void shrink() noexcept {
        std::lock_guard lock(mutex_);
        for (uint8_t* p : free_) std::free(p);
        if (allocated_ >= free_.size()) allocated_ -= free_.size();
        else allocated_ = live_;
        free_.clear();
        free_.shrink_to_fit();
    }

    std::size_t live_pages() const {
        std::lock_guard lock(mutex_);
        return live_;
    }

    std::size_t cached_pages() const {
        std::lock_guard lock(mutex_);
        return free_.size();
    }

    std::size_t allocated_pages() const {
        std::lock_guard lock(mutex_);
        return allocated_;
    }

private:
    PagePool() { free_.reserve(256); }
    PagePool(const PagePool&) = delete;
    PagePool& operator=(const PagePool&) = delete;

    mutable std::mutex mutex_;
    std::vector<uint8_t*> free_;
    std::size_t live_{0};
    std::size_t allocated_{0};
};

} // namespace lg::memory
