#include "mmu.h"
#include <algorithm>
#include <cstddef>
#include <limits>
namespace lg::memory {

bool Mmu::map(uint64_t va, uint64_t pa, uint64_t size, uint32_t perms) {
    constexpr uint32_t ValidPermissions = Read | Write | Execute | User;
    if (!size || !perms || (perms & ~ValidPermissions) || (va & PageMask) || (pa & PageMask) ||
        va > std::numeric_limits<uint64_t>::max() - (size - 1) ||
        pa > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t pages = ((size - 1) >> PageBits) + 1;
    const uint64_t first_vpn = va >> PageBits;
    const uint64_t first_ppn = pa >> PageBits;
    if (pages - 1 > std::numeric_limits<uint64_t>::max() - first_vpn ||
        pages - 1 > std::numeric_limits<uint64_t>::max() - first_ppn) return false;
    const uint64_t last_vpn = first_vpn + (pages - 1);
    // Regions are disjoint and sorted: the only candidate for an overlap is the last
    // region starting at or before last_vpn.
    const std::size_t before = region_at_or_before(last_vpn);
    if (before != regions_.size() &&
        regions_[before].first_vpn + regions_[before].pages > first_vpn) return false;
    std::size_t at = before == regions_.size() ? 0 : before + 1;   // insertion index
    // Merge with neighbours contiguous in VA and PA with the same permissions (keeps the
    // table small when callers map page by page). Invisible to translate().
    const auto joins = [](const Region& a, const Region& b) {
        return a.first_vpn + a.pages == b.first_vpn && a.first_ppn + a.pages == b.first_ppn &&
               a.permissions == b.permissions;
    };
    Region region{first_vpn, pages, first_ppn, perms};
    const bool merge_prev = at > 0 && joins(regions_[at - 1], region);
    const bool merge_next = at < regions_.size() && joins(region, regions_[at]);
    if (merge_prev && merge_next) {
        regions_[at - 1].pages += pages + regions_[at].pages;
        regions_.erase(regions_.begin() + static_cast<std::ptrdiff_t>(at));
    } else if (merge_prev) {
        regions_[at - 1].pages += pages;
    } else if (merge_next) {
        regions_[at].first_vpn = first_vpn;
        regions_[at].first_ppn = first_ppn;
        regions_[at].pages += pages;
    } else {
        regions_.insert(regions_.begin() + static_cast<std::ptrdiff_t>(at), region);   // may throw: no change
    }
    mapped_pages_ += pages;
    invalidate_all();
    if (observer_) observer_->mmu_mapped(va, pa, size, perms);
    return true;
}

bool Mmu::unmap(uint64_t va, uint64_t size) {
    if (!size || (va & PageMask) || va > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t pages = ((size - 1) >> PageBits) + 1;
    const uint64_t first_vpn = va >> PageBits;
    if (pages - 1 > std::numeric_limits<uint64_t>::max() - first_vpn) return false;
    const uint64_t end_vpn = first_vpn + pages;           // exclusive; vpn < 2^52, no overflow
    std::size_t k = region_at_or_before(first_vpn);
    if (k == regions_.size()) k = 0;
    else if (regions_[k].first_vpn + regions_[k].pages <= first_vpn) ++k;
    while (k < regions_.size() && regions_[k].first_vpn < end_vpn) {
        const Region region = regions_[k];
        const uint64_t start = region.first_vpn, end = start + region.pages;
        mapped_pages_ -= std::min(end, end_vpn) - std::max(start, first_vpn);
        if (start < first_vpn && end > end_vpn) {
            // Hole in the middle: the only case that grows the table. Insert the right
            // remainder first (may throw: nothing modified yet), then shrink the left.
            try {
                regions_.insert(regions_.begin() + static_cast<std::ptrdiff_t>(k + 1),
                                Region{end_vpn, end - end_vpn, region.first_ppn + (end_vpn - start), region.permissions});
            } catch (...) {
                mapped_pages_ += std::min(end, end_vpn) - std::max(start, first_vpn);
                throw;
            }
            regions_[k].pages = first_vpn - start;
            break;
        }
        if (start < first_vpn) {                          // keep the left remainder
            regions_[k].pages = first_vpn - start;
            ++k;
        } else if (end > end_vpn) {                       // keep the right remainder
            regions_[k] = Region{end_vpn, end - end_vpn, region.first_ppn + (end_vpn - start), region.permissions};
            break;
        } else {
            regions_.erase(regions_.begin() + static_cast<std::ptrdiff_t>(k));
        }
    }
    invalidate_all();
    if (observer_) observer_->mmu_unmapped(va, size);
    return true;
}

void Mmu::invalidate_all() noexcept {
    // O(1): stale TLB entries fail the generation check on next lookup.
    ++generation_;
    if (generation_ == 0) {
        // Overflow: force-clear once every 2^64 invalidations (practically never).
        for (auto& e : tlb_) e.gen = 0;
        generation_ = 1;
    }
}

void Mmu::clear() noexcept {
    // Release the capacity too (as the old rehash(0) did) so a session's peak does not stick.
    std::vector<Region>().swap(regions_);
    mapped_pages_ = 0;
    invalidate_all();
    if (observer_) observer_->mmu_cleared();
}

void Mmu::invalidate_page(uint64_t va) noexcept {
    auto& e = tlb_[slot(va >> PageBits)];
    e.gen = 0;
}

bool Mmu::find_region(uint64_t va, uint64_t& region_va, uint64_t& region_pa, uint64_t& region_size,
                      uint32_t& permissions) const noexcept {
    const uint64_t vpn = va >> PageBits;
    const std::size_t k = region_at_or_before(vpn);
    if (k == regions_.size() || vpn - regions_[k].first_vpn >= regions_[k].pages) return false;
    region_va = regions_[k].first_vpn << PageBits;
    region_pa = regions_[k].first_ppn << PageBits;
    region_size = regions_[k].pages << PageBits;
    permissions = regions_[k].permissions;
    return true;
}

std::size_t Mmu::region_at_or_before(uint64_t vpn) const noexcept {
    // Branch-light binary search for the last first_vpn <= vpn.
    const Region* base = regions_.data();
    std::size_t n = regions_.size();
    if (n == 0 || base[0].first_vpn > vpn) return regions_.size();
    while (n > 1) {
        const std::size_t half = n / 2;
        base = base[half].first_vpn <= vpn ? base + half : base;
        n -= half;
    }
    return static_cast<std::size_t>(base - regions_.data());
}

core::Result<Translation> Mmu::translate(uint64_t va, bool write, bool execute) const {
    const uint64_t vpn = va >> PageBits;
    const auto idx = slot(vpn);
    const auto& t = tlb_[idx];
    if (t.gen == generation_ && t.virtual_page == vpn) {
        if ((write && !(t.permissions & Write)) ||
            (execute && !(t.permissions & Execute)) ||
            (!write && !execute && !(t.permissions & Read)))
            return core::Result<Translation>::Error("permission fault");
        return core::Result<Translation>::Ok(
            Translation{(t.physical_page << PageBits) | (va & PageMask), t.permissions});
    }
    // TLB miss: the region containing vpn is the last one starting at or before it.
    const std::size_t k = region_at_or_before(vpn);
    if (k == regions_.size() || vpn - regions_[k].first_vpn >= regions_[k].pages)
        return core::Result<Translation>::Error("translation fault");
    const uint64_t ppn = regions_[k].first_ppn + (vpn - regions_[k].first_vpn);
    const uint32_t permissions = regions_[k].permissions;
    if ((write && !(permissions & Write)) ||
        (execute && !(permissions & Execute)) ||
        (!write && !execute && !(permissions & Read)))
        return core::Result<Translation>::Error("permission fault");
    tlb_[idx] = TlbEntry{vpn, ppn, permissions, generation_};
    return core::Result<Translation>::Ok(
        Translation{(ppn << PageBits) | (va & PageMask), permissions});
}

} // namespace lg::memory
