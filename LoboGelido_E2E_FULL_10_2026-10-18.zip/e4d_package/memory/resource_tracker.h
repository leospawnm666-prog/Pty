#pragma once
#include <array>
#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>

// Lifetime ledger for GPU resources (textures, buffers, samplers, pipelines, framebuffers).
// Every create is track()ed and every destroy is untrack()ed; at shutdown has_leaks()/
// leak_report() name anything still live. It also detects double-frees (untrack of an
// unknown id) and tracks live/peak bytes per kind for memory auditing. Thread-safe, since
// GPU resources are created and destroyed from several threads.

namespace lg::memory {

enum class ResourceKind : uint8_t { Texture, Buffer, Sampler, Pipeline, Framebuffer, Other, Count };

class ResourceTracker {
public:
    // Registers a live resource; returns its tracking id (never 0).
    uint64_t track(ResourceKind kind, uint64_t bytes, std::string tag = {});
    // Marks a resource destroyed. Returns false if id is unknown (double-free / bad id).
    bool untrack(uint64_t id);

    size_t live_count() const;
    size_t live_count(ResourceKind kind) const;
    uint64_t live_bytes() const;
    uint64_t live_bytes(ResourceKind kind) const;
    uint64_t peak_bytes() const;
    uint64_t double_frees() const;

    bool has_leaks() const { return live_count() > 0; }
    std::string leak_report() const;
    void reset();

private:
    struct Res { ResourceKind kind; uint64_t bytes; std::string tag; };
    static constexpr size_t kKinds = static_cast<size_t>(ResourceKind::Count);

    mutable std::mutex mutex_;
    std::unordered_map<uint64_t, Res> live_;
    std::array<uint64_t, kKinds> count_by_kind_{};
    std::array<uint64_t, kKinds> bytes_by_kind_{};
    uint64_t next_id_{1};
    uint64_t cur_bytes_{0};
    uint64_t peak_bytes_{0};
    uint64_t double_frees_{0};

    static const char* kind_name(ResourceKind k);
};

} // namespace lg::memory
