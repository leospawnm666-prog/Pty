#include "guest_memory_budget.h"

#if defined(__linux__) || defined(__ANDROID__)
#  include <unistd.h>
#endif

namespace lg::memory {

uint64_t physical_ram_bytes() noexcept {
#if defined(__linux__) || defined(__ANDROID__)
    const long pages = ::sysconf(_SC_PHYS_PAGES);
    const long page = ::sysconf(_SC_PAGESIZE);
    if (pages > 0 && page > 0) return static_cast<uint64_t>(pages) * static_cast<uint64_t>(page);
#endif
    return 0;
}

} // namespace lg::memory
