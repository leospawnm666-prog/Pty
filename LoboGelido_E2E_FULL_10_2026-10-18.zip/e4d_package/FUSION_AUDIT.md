# Fusión UNIFICADO + parches Lobo Gélido

Base: LoboGelido_BETA_0.1_SETTINGS_WIRED_UNIFICADO_2026-10-16.zip
Fecha: 2026-10-16

## Parches aplicados
1. SafFacade.Request completo (FIRMWARE…GAME_CONTENT) — bug de comentario eliminado
2. recognizeKeys con conteo real de entradas en disco
3. pushGraphicsOptionsToNative + pushAudioOptionsToNative → RuntimeBridge
4. JNI setGraphicsOptions / setAudioOptions / trimNativeMemory
5. NativeRuntimeHost apply_graphics_options / apply_audio_options / trim_memory
6. AudioEngine volumen/mute/av-sync; AudioOutputBridge registrado
7. Frame pacing set_target_fps; GameSurfaceView budget + overlay FPS
8. CMake -fPIC + -Wl,-z,notext; eliminado recovery/
9. Logo ImageView con filtro de bitmap

## Boot / splash
La pantalla "Cargando módulos" sigue siendo UI de bienvenida (temporizadores).
Keys/firmware se validan de verdad en Sistema y al lanzar, no en los bullets del splash.

## Build
```bash
echo "sdk.dir=..." > local.properties
chmod +x gradlew
./gradlew :app:assembleDebug --no-daemon
```
