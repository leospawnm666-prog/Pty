# P4.3 — Informe: texturas e imágenes en el recompilador Maxwell (hito H9)

Estado: **P4.3 implementado y verificado. Hito H9 alcanzado en este entorno** (oráculos lavapipe
y SwiftShader; ver los límites en §7).

| Métrica (P4_3_DISENO.md §1) | Meta de P4.3 | Resultado |
|---|---|---|
| M1 — traducción | las 13 instrucciones de textura e imagen | **22/22** codificaciones de la lista de P4.3: las 13 instrucciones en sus filas *bound*, *bindless* y las 4 formas de `SUATOM`. Total: 206/296 (69,6 %; P4.2: 184) |
| M2 — corpus T3-T | A = B al 100 % en el oráculo | **12/12** en lavapipe: 6 *shaders* de *compute* y 6 tuberías VS+FS |
| M4 — SPIR-V válido | 100 % | **1014/1014** módulos aceptados por `spirv-val --target-env vulkan1.1` (P4.2: 812). Los 202 nuevos son: 13 programas M1 de textura que ahora se traducen, los 170 casos T2-T, los 6 de *compute* y las 12 etapas de T3-T, y un FS sintético con `TMML.B` |
| T2-T — instrucciones nuevas | todas las formas | **170/170** casos verificados. En lavapipe pasan 165 y se omiten 5; en SwiftShader pasan 164 y se omiten 6. Cada caso pasa en al menos un oráculo; cada omisión es un fallo conocido del oráculo (§4.3) |
| Regresión | ninguna | Los 812 módulos de P4.2 dan **el mismo SPIR-V byte a byte** (mismo *hash* con los dos traductores) |

Meta H9: "las 13 codificaciones traducidas (salvo las formas de §6 con error explícito), T3-T al
100 % en lavapipe, M4 al 100 % y T2-T de todas las formas". **Cumplida.**

**Contexto:**
- **Base:** `LoboGelido_beta_0.1_GLASS_PLAY_BUILD_FIX.zip` + la cadena hasta P4.2.
- **Especificación:** `P4_3_DISENO.md`. D-P4.3-1 a 7 se tomaron como se recomendaban. La única
  desviación es de pruebas: T3-T solo en lavapipe (§4.1).
- **Método:** protocolo de 12 pasos y Regla de Oro. No se ha eliminado ninguna clase, función ni
  *binding* nativo. Cambios en archivos existentes:
  - `translate.{h,cpp}`: solo añadidos (estado, despacho, inclusión del `.inc` nuevo).
  - `test_shader_static.cpp`: un caso E1 de P4.1 ("`TEX` fuera de alcance") se sustituye por
    `VOTE`, porque `TEX` ya se traduce. El caso sigue comprobando lo mismo (error explícito con
    dirección y mnemónico).
- **Política *clean-room* (D-P4-2):** todo es código propio. Referencias usadas, todas
  permisivas:
  - tablas de envydis (envytools, MIT);
  - emisor y bajadas GM107 de Mesa nv50_ir (MIT): orden de fuentes, tablas de las formas
    escalares;
  - especificaciones de SPIR-V y Vulkan;
  - uam (compilador de deko3d) solo como herramienta que genera el corpus.
  Nada de yuzu, Eden ni Ryujinx.
- **No se toca:** `crypto/`, cargadores NCA/NSP/XCI ni claves. P4.3 no tiene nada que ver con el
  descifrado.

## 1. Qué se entrega
| Archivo | Qué |
|---|---|
| `shader/translate_texture.inc` (nuevo, ~850 líneas) | Decodificación (`TexOp`, `SurfDec`), rastreo de *handles* y *offsets*, emisión SPIR-V de muestreo, consultas e imágenes |
| `shader/translate.{h,cpp}` | `ImageFormat`, `TextureState`, `ImageState`; `ShaderInfo::textures/images/texture_bank/texture_first_binding`; `ResourceUse` con texturas e imágenes (offset, dimensión, *array*, profundidad, MS, tipo, clase de acceso, tamaño crudo, formato); despacho de las 13 instrucciones |
| `shader/spirv/builder.{h,cpp}` | Tipos de imagen, *sampler* y *sampled image*; códigos de imagen y atómicas de texel; constantes compuestas |
| `tests/shader/vk_textures.h` (nuevo) | `TextureSet`: crea imágenes, vistas (también las de formato distinto para acceso crudo), *samplers*, carga y lectura |
| `tests/shader/tex_spec.h` (nuevo) | Directivas `// tex:` / `// img:` del corpus y correspondencia por offset del *handle* |
| `tests/shader/vk_compute.*`, `vk_graphics.*`, `t3_runner.h`, `t3g_runner.h` | Texturas e imágenes en los dos *harness* |
| `tests/test_shader_t2t.cpp`, `tests/shader/t2t_fixtures.h` (nuevos) | T2-T: 170 casos |
| `tests/test_shader_t3t.cpp`, `t3t_fixtures.h`, `t3tg_fixtures.h` (nuevos) | T3-T: corpus diferencial |
| `tests/data/shader/tcorpus/` (nuevo) | 6 *compute* (`x01`–`x06`) y 6 tuberías (`f01`–`f06`) |
| `tools/gpu_toolchain/gen_shader_t2t.py` (nuevo); `gen_shader_corpus.py`, `gen_shader_gcorpus.py` | Generadores (los dos últimos ganan un argumento opcional de *namespace*; sin él generan lo mismo que antes, comprobado) |
| `tests/test_shader_static.cpp` | M4/D1/M1/E1 de texturas |
| `tests/shader/tsan_oracle.supp` | Supresión de la libLLVM de lavapipe (§5.2) |
| `CMakeLists.txt`, `build_toolchain.sh` | Tests nuevos (`shader_t2t`, `shader_t2t_*`, `shader_t3t_lvp`) y regeneración |

## 2. Cómo traduce
### 2.1 Recursos (D-P4.3-1)
- **Identidad:** cada textura o imagen se identifica por el *handle* que la instrucción usa, es
  decir, el par (banco, offset) del constbuffer donde está su palabra TIC/TSC. Así lo hace deko3d:
  `c0[resbase + 4·binding]` para texturas y `c0[resbase + 0x80 + 4·binding]` para imágenes.
- **Descriptores:** el traductor declara un descriptor por cada (*handle*, uso), con *bindings*
  consecutivos desde `texture_first_binding`. Lo informa en `ResourceUse` con todo lo que P5
  necesita para crear la vista: dimensión, *array*, profundidad, MS, tipo, clase de acceso,
  tamaño crudo y formato.
- **Tipo de componente y formato:** no están en la instrucción. Vienen de
  `TextureState`/`ImageState`, como `GraphicsState` en P4.2. Por defecto: float, formato
  desconocido.

### 2.2 *Bindless* rastreable (D-P4.3-2)
- Las filas *bindless* (marca `N("b")` en envydis) toman el *handle* de un registro.
- Se acepta cuando ese registro, dentro del mismo bloque básico, viene de `MOV Rx, c[b][o]` o de
  `LDC.32 Rx, c[b][o]` con índice RZ. El resultado es un recurso estático (banco, offset).
- Cualquier otro caso es un error explícito (P4.4). También lo es una escritura predicada entre
  la definición y el uso.

### 2.3 Instrucciones
| Instrucción | SPIR-V |
|---|---|
| `TEX` (lz, lb, ll, implícito, aoffi, dc) | `OpImageSample{,Dref}{Implicit,Explicit}Lod`, `ConstOffset` |
| `TLD` (ll, ms, aoffi) | `OpImageFetch` con `Lod`/`Sample`/`ConstOffset` |
| `TLD4` (componente, aoffi, ptp, dc) | `OpImageGather`/`OpImageDrefGather`, `ConstOffset`, `Offset` (registro, 8 bits por componente) o `ConstOffsets` (ptp) |
| `TXD` (aoffi, *array*) | `Grad` |
| `TMML` | `OpImageQueryLod`, convertido al formato del *hardware* (8.8 en punto fijo: comp. 0 = LOD calculado s16, comp. 1 = nivel accedido u16) |
| `TXQ` (dimensiones) | `OpImageQuerySizeLod` + `OpImageQueryLevels`; con *handle* de imagen, `OpImageQuerySize` |
| `TEXS`, `TLDS`, `TLD4S` | Tablas de objetivo y máscara de Mesa; dos grupos de fuentes (R8, R20) y dos pares de destino (R0, R28) |
| `SULD`/`SUST` `.P` | `OpImageRead`/`OpImageWrite` con formato |
| `SULD`/`SUST` `.D` (u8 … b128) | Vista cruda R8ui/R16ui/R32ui/Rg32ui/Rgba32ui; extensión de signo para s8/s16; enmascarado para escrituras estrechas |
| `SUATOM` (4 formas, CAS), `SURED` | `OpImageTexelPointer` + atómica (add, min, max, and, or, xor, exch, CAS; con y sin signo) |

**Decisiones de modelo:**
- **LOD implícito fuera del FS (D-P4.3-4):** Vulkan no tiene derivadas fuera del FS. `TEX`
  implícito se traduce a LOD 0, y `.LB` a LOD = *bias*. Es lo que hace el *hardware* con
  derivadas nulas.
- **Imágenes fuera de rango (D-P4.3-5):** se comprueban los límites con `OpImageQuerySize`. Fuera
  de rango, las escrituras y atómicas se ignoran y las lecturas dan 0. Equivale al modo `ign`; el
  modo `trap` se trata igual, con aviso.
- **Atómicas:** sus operandos se leen antes de escribir el destino, que puede ser el mismo
  registro (CAS: R20 = comparador, R20+1 = valor).
- **`TXQ`:** las dimensiones que la textura no tiene dan 1; `w` = número de niveles. La forma de
  la textura sale de otro uso del mismo *handle* en el programa, o 2D con aviso si solo se
  consulta.
- **Comparación de profundidad:** el resultado va a cada componente pedido; los compiladores
  piden uno.
- **Tipo de `SUATOM` con *handle* inmediato:** sale de `ImageState`. En esa forma, los bits 36-38
  son del *handle*; ver §4.4, fallo de uam/Mesa.

## 3. Requisitos para P5 (integración)
- **Descriptores:** crear uno por cada `ResourceUse` de clase `Texture` o `Image`, con la vista
  que describe.
- **Acceso crudo:** necesita una vista de formato entero del tamaño del acceso (por ejemplo
  R32ui sobre una RGBA8 creada con `MUTABLE_FORMAT`). El tamaño del acceso tiene que coincidir con
  el tamaño del texel. El *harness* `TextureSet` ya lo hace así.
- **`TextureState`/`ImageState`:** se rellenan desde los descriptores TIC (tipo de componente y
  formato) en el momento del *draw* o *dispatch*.

## 4. Verificación
### 4.1 T3-T — corpus diferencial
- **Corpus:** GLSL propio. Las texturas se generan con un patrón determinista: varios niveles,
  capas, cubo, 3D, profundidad, enteros y *snorm*. *Samplers* `nearest`/`linear`, `clamp`/`repeat`
  y de comparación.
- **Caminos:** A (uam → traductor) y B (glslang), en el mismo oráculo.
- **Resultado:** **12/12 en lavapipe**.
  - *Compute* (6): `x01_fetch`, `x02_kinds` (tolerancia de filtrado), `x03_gather`, `x04_image`
    (imágenes con y sin formato, crudas, contador compartido sin carreras), `x05_int`,
    `x06_atomics`.
  - VS+FS (6): `f01_sample`, `f02_gather`, `f03_kinds`, `f04_grad` (con `textureQueryLod` en
    magnificación y más allá del último nivel), `f05_vs` (muestreo en VS), `f06_shadow`.
- **Por qué no SwiftShader (desviación de D-P4.3-6):** SwiftShader corrompe su propio *heap* al
  destruir *pipelines* de *compute* con *offsets* de texel. Lo reproduce un *shader* glslang mínimo
  (`texelFetchOffset` + `textureLodOffset`), sin el traductor. Además ignora el `Offset` no
  constante y los `ConstOffsets` de `OpImageGather`. T2-T sí corre en SwiftShader (§4.3).

### 4.2 T2-T — instrucciones nuevas
- **Qué:** 170 programas Maxwell generados por `gen_shader_t2t.py`, ensamblados con `envyas` o
  como palabras crudas cuando `envyas` no tiene la forma (*bindless*, escalares, CAS, `SULD`
  *bindless*).
- **Texturas "dirección = valor":** cada texel guarda sus coordenadas, nivel, capa y ranura:
  `(x+1000·l, y+1000·k, (3x+5y+7k+11l)&0xff, 0xb00+ranura)`. Así el resultado exacto se conoce.
  En profundidad, `((7x+3y+5k+l) mod 16)/16 + 1/32`.
- **Cobertura:** cada forma de cada instrucción:
  - destino y máscara;
  - las 14 entradas de la tabla de `TEXS` y 8 de las 9 válidas de `TLDS`, con las 8 máscaras de dos componentes y 3 de cuatro;
  - la capa de un *array* con basura en los 16 bits altos;
  - LOD;
  - *offsets* de 4 y 8 bits, incluidos los negativos;
  - `PTP`;
  - profundidad;
  - las 4 componentes del *gather*;
  - `TXQ` de cada forma;
  - `TMML`;
  - `TXD` con *array* y *offset*;
  - las imágenes en todos sus tamaños crudos y con formato, y fuera de rango (con basura previa en el destino);
  - todas las atómicas y CAS, también fuera de rango;
  - *bindless* de cada familia.

### 4.3 Fallos de los oráculos (omisiones declaradas)
| Oráculo | Fallo | Omitidos | Verificados en |
|---|---|---|---|
| lavapipe 24.3.4 | Ignora el LOD de `OpImageQuerySizeLod` en *compute* (`textureSize(t, 1)` de glslang da el tamaño del nivel 0) | `txq_*` salvo `txq_cube` (5) | SwiftShader, que lo hace bien |
| SwiftShader | Ignora el `Offset` no constante y los `ConstOffsets` de `OpImageGather` | `tld4s_*_aoffi`, `tld4_ptp` (6) | lavapipe |

### 4.4 Fallos de uam (el compilador del corpus) encontrados
- **Transformación de `gl_FragCoord.y`:** deja `STATE_FB_WPOS_Y_TRANSFORM` (cb1) a 0. Era
  conocido de P4.2; el *harness* lo rellena.
- **`SUATOM` con *handle* inmediato y min/max con signo:** uam (el emisor de Mesa) hace OR del
  tipo s32 sobre el *handle*, porque los dos campos se solapan en los bits 36-38 (`0x4c` →
  `0x4d`). El corpus evita esa combinación. El traductor no lee el tipo de esos bits, sino de
  `ImageState`.

### 4.5 Errores propios encontrados y corregidos durante P4.3
- **Detección de F16 invertida:** `TEXS`/`TLDS` son F16 con el bit 59 **a 0**; `TLD4S`, con el
  bit 55 a 1.
- **Detección *bindless*:** se hacía por ausencia de `U13_36`. Fallaba con `TXQ.B`, que lo lista
  en envydis; ahora se usa la marca `N("b")`.
- **`TXQ`:**
  - la forma de la textura se busca en todo el programa;
  - con *handle* de imagen usa el descriptor de la imagen.
- **`OpImageQueryLod`:** la coordenada no lleva la capa.
- **CAS:** el destino se ponía a 0 antes de leer los operandos.
- **Capacidades que pedía `spirv-val`:** `ImageGatherExtended` (`ConstOffsets`) y
  `StorageImageExtendedFormats` (R8ui, R16ui, Rg32ui).
- ***Harness*:**
  - `gdpa` nulo por una variable local que ocultaba el miembro;
  - colisión de *bindings* SSBO/imagen en el camino B;
  - carreras en el corpus de imágenes.

### 4.6 M4, D1, M1, E1
- **M4:** 1014/1014 módulos válidos con `spirv-val`.
- **D1:** misma salida con 4 hilos.
- **M1:** 206/296 codificaciones (69,6 %); lista de P4.3, 22/22.
- **E1:** errores explícitos con dirección y mnemónico para cada forma de §6.

## 5. Matriz
| Configuración | Resultado |
|---|---|
| *Host* (Release, oráculos) | **94/94** |
| JIT | **97/97** |
| ASan + UBSan (LSan activo) | **94/94** (*host*), **97/97** (JIT) |
| TSan | **94/94** (*host*), **97/97** (JIT) |
| Descarga de Dynarmic (*fetch*) | **97/97** |
| Android (NDK, 102 fuentes) | 100 OK; fallan los 2 de siempre (`aaudio_sink`, `android_display_adapter`: cabeceras del NDK que faltan aquí) |
| ARM64 (`translate.cpp`, `builder.cpp`, clang `--target=aarch64-linux-gnu`) | compila, sin avisos |

### 5.1 Mutación
Se aplicaron 35 mutantes a `translate_texture.inc`: decodificación, tablas escalares, rastreo,
emisión, imágenes y atómicas. Cada mutante se compila y se ejecuta contra:
- `test_shader_static` (M4 con `spirv-val`, E1);
- T2-T en lavapipe y en SwiftShader;
- T3-T y T3-G (`--require-all`) en lavapipe.

| Ronda | Matados | Notas |
|---|---|---|
| 1 | 27/35 | 8 supervivientes |
| 2 (con las pruebas añadidas) | **32/35** | 3 supervivientes explicados abajo |

**Pruebas añadidas por los supervivientes de la ronda 1:**
- capa con bits altos (T2-T);
- máscaras escalares `ra`/`ga` (T2-T);
- `SULD`/`SUATOM` fuera de rango con basura previa en el destino (T2-T);
- `textureQueryLod` con LOD calculado ≠ nivel accedido (T3-T, `f04_grad`). Antes LOD calculado
  y nivel accedido coincidían y el intercambio de componentes de `TMML` pasaba.

**Supervivientes que quedan:**
- **"Muestreador de comparación sin `Depth = 1`": equivalente.** Vulkan ignora el operando
  `Depth` de `OpTypeImage`; la comparación la decide la instrucción `Dref`.
- **"Componentes ausentes sin alfa = 1": código inalcanzable.** Todas las llamadas actuales
  pasan 4 componentes. Se conserva por la Regla de Oro y por las formas futuras de menos
  componentes.
- **"`TLD` con muestra y LOD en orden inverso": no decidible aquí.** Solo difiere si una
  instrucción lleva a la vez `.LL` y `.MS`. Ningún compilador emite esa forma (las texturas MS
  tienen un nivel). El orden implementado es el de Mesa; confirmar el contrario exigiría
  *hardware*.

### 5.2 Sanitizadores y descarga
- **ASan/UBSan/LSan:** sin hallazgos. La fijación de bibliotecas de P4.2 (contra el falso
  positivo de `dlclose`) cubre también las texturas.
- **TSan:** `shader_t3t_lvp` falló de forma intermitente (4 de 12 ejecuciones) con una carrera
  cuyos dos accesos están solo en `libLLVM.so.18.1`: el `new`/`delete` alineado de los hilos de
  compilación de lavapipe. `libLLVM` es una dependencia de `libvulkan_lvp.so` y nada de Lobo
  Gélido la enlaza (comprobado con `ldd`). La supresión de P4.2 (`race:libvulkan_lvp.so`) no
  la cubría porque las pilas de acceso no tienen marcos de lavapipe. Se añade
  `race:libLLVM.so` a `tests/shader/tsan_oracle.supp`, documentada. Después: 16/16 ejecuciones
  limpias y la batería completa en verde. No se suprime ningún marco de Lobo Gélido.
- **Descarga de Dynarmic:** sin cambios respecto a P4.2.

## 6. Qué queda fuera de P4.3 (error explícito)
| Forma | Fase |
|---|---|
| *Bindless* no rastreable (*handle* calculado, otro bloque), indexación dinámica | P4.4 |
| *Offset* no constante fuera de `TLD4` | P4.4 |
| `TXQ` distinto de dimensiones; `TXA`; `TLD.CL`; `TEX .LBA/.LLA` | P4.4 |
| Atómicas de imagen de 64 bits, f32 e `INC`/`DEC` con vuelta; imágenes de *buffer*; `SUST.D.BA`; `SUST.P` con máscara parcial | P4.4 |
| `TMML` fuera del FS; `TXD` de 3D/cubo (el compilador lo emula); `TLD4` de 1D | no existen |
| FP16 de las formas escalares (SM60) | no aplica a Tegra X1 |

## 7. Límites (honestos)
- **Oráculos de *software*:** lavapipe y SwiftShader no son una GPU Maxwell. Lo verificado es:
  - que el SPIR-V hace lo mismo que el GLSL original (T3-T);
  - que cada instrucción da el valor que dicen las tablas de Mesa y envydis (T2-T).
  Las diferencias de filtrado entre fabricantes (precisión bilineal, selección de LOD) no se
  pueden verificar sin *hardware*.
- **SwiftShader:** no ejecuta T3-T por su propio fallo (§4.1).
- **Fallos de oráculo:** los dos de §4.3 se sortean con omisiones declaradas, nunca en silencio.
- **Generador del corpus:** la combinación `SUATOM` inmediato + min/max con signo no se puede
  generar con uam; se cubre con palabras crudas en T2-T.
- **P5:** el modelo de recursos está probado en el *harness*, pero no con el estado TIC/TSC real
  de una partida, que llega en P5.

## 8. Siguiente fase
- **P4.4:** las formas de §6 (*bindless* general, *offsets* dinámicos, `TXQ` restantes, imágenes
  de *buffer*, atómicas de 64 bits) y el resto de M1 hasta el 100 %.
- **Alternativa:** integración mínima (P5): `TextureState`/`ImageState` desde TIC/TSC y creación
  de las vistas que pide `ResourceUse`.
