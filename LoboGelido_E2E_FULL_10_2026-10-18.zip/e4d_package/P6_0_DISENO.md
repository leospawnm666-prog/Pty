# P6.0 — Diseño: el núcleo de Horizon completo (SVC) y el marco de HLE

Estado: **implementado** (P6_DISENO.md §4, fase P6.0; pedido del 15-oct "completemos el 100 %",
por fases con prioridad para los juegos). Resultado en `P6_0_INFORME.md`.

Fuentes (D-P6-2): Atmosphère mesosphere se consulta **solo como documentación del
comportamiento** del kernel (orden de validación, códigos `Result`, valores de `KMemoryState`,
tamaños de las regiones). No se copia código: todo es propio. libnx (ISC) da los números, las
firmas y el ABI de registros (`svc.s`). Switchbrew completa lo que mesosphere no trae en la copia
local (SVC del kernel retail que son *stubs*, `ReadWriteRegister`).

## 1. Objetivo y medida
| Métrica | Antes (P4.4) | Meta P6.0 | Resultado |
|---|---|---|---|
| M-SVC: números de SVC asignados con manejador | 39/124 | 123 implementadas + 1 frontera | **123 + 1 frontera (`CallSecureMonitor`)** |
| M-SRV / M-CMD | 3/89, ≈13/1908 | sin cambio (P6.0 es el marco) | medido por herramienta: 3 empezadas, 0 completas; **11/1908** |

`tools/hle/hle_coverage.py` mide M-SRV/M-CMD desde el código (catálogo de §5): la cifra
anterior "≈13" era una estimación a mano; la medida exacta es 11.

## 2. El modelo de consola
| # | Decisión |
|---|---|
| **D-P6.0-1** | **Consola retail.** `KTargetSystem::IsDebugMode()` es falso y el proceso no tiene `force_debug_prod`. Por eso todas las SVC de depuración (0x60-0x6D, `GetProcessList`, `GetThreadList`) responden `NotImplemented`, y `GetLastThreadInfo`/`GetDebugFutureThreadInfo` responden `NoThread`, como en una consola de venta. Sustituye a P6_DISENO §3.3 ("GetProcessList devuelve el proceso emulado"): eso solo ocurre en modo depuración |
| **D-P6.0-2** | **Un solo proceso.** `CreateProcess` valida todos sus parámetros como Horizon (tabla `KAddressSpaceInfo`, alineación 2 MiB, capacidades `MapRegion`) y termina en `OutOfResource` (no hay ranura de `KProcess`). `StartProcess` sobre el propio proceso: `InvalidState`. `TerminateProcess` sobre el propio: `ExitProcess`. Las SVC de memoria de proceso operan sobre el propio con un *handle* real (no pseudo-*handle*), que se obtiene como hbloader: copiando `CUR_PROCESS_HANDLE` por IPC |
| **D-P6.0-3** | **Sin manejadores de excepción de usuario ni hilos fijados.** `ReturnFromException` y `SynchronizePreemptionState` no están en los permisos del hilo fuera de esos estados: la llamada es una excepción `UndefinedSystemCall` y el proceso termina (sesión en Error con ese texto). `MapDeviceAddressSpace` (0x5B) salió del kernel en 13.0.0: misma excepción |
| **D-P6.0-4** | **Hardware ausente = la respuesta del kernel sin ese hardware.** Sin SMMU (`CreateDeviceAddressSpace` → `NotImplemented`, como `board/generic`), sin *pools* PCIe (`CreateIoPool` → `NotFound`), sin capacidades de interrupción (`CreateInterruptEvent` → `NotFound`), sin registros MC/PMC (`ReadWriteRegister` → `NotImplemented`, `KSystemControlBase`). Las validaciones previas al dispositivo son las de Horizon, en orden. `KernelDebug`/`ChangeKernelTraceState` son *stubs* en el kernel retail (Switchbrew). `SleepSystem`: la consola emulada no tiene estado de energía ni fuente de despertar, así que vuelve al instante (se cuenta en `sleep_requests()`) |
| **D-P6.0-5** | **`GetSystemInfo`.** La DRAM emulada es un único *pool* de aplicación (el presupuesto del proceso): `Application` informa total/usado del proceso; `Applet`, `System`, `SystemNonSecure` informan 0. `InitialProcessIdRange` informa el rango reservado de `KProcess` [1, 0x50] (Lobo no arranca KIP). Desviación conocida y previa: el proceso emulado tiene el id 1 |
| **D-P6.0-6** | **`IsApplication`**: 1 para NCA/NSO, 0 para un NRO (hbloader es `application_type 2`) |
| **D-P6.0-7** | **Direcciones físicas**: PA del *arena* + `0x80000000` (la base de la DRAM del Tegra X1). `QueryPhysicalAddress` devuelve el tramo físicamente contiguo del bloque (modelo: Horizon lo calcula con los tamaños de bloque de su tabla de páginas) |
| **D-P6.0-8** | **`CallSecureMonitor` es FRONTERA (D-P6-3).** Se cumple la parte del kernel (traducir a físicas los registros marcados en el *function id*, 0 si la página no es RW de usuario) y la llamada falla como en un kernel sin monitor seguro: `x0 = 1`. Ninguna función del monitor (claves, AES, generación de claves) se emula ni se emulará |
| **D-P6.0-9** | **Versión del kernel: el más reciente documentado.** Las `InfoType` nuevas (23, 24, 26-28, 34, 36-38) responden aunque el entorno de homebrew diga HOS 5.1.0 (esa entrada es una pista de libnx, no la versión del kernel). Sustituye a D-P3.2-3. Ventaja para los juegos: un juego con SDK ≥ 11 que pide `FreeThreadCount` recibe respuesta |
| **D-P6.0-10** | **Servidores IPC del guest.** Horizon recibe la petición en el hilo servidor *después* de despertar; Lobo no tiene continuación tras un despertar, así que la petición se recibe **dentro** del hilo servidor que espera en el momento en que llega (`try_deliver`) y el hilo despierta con ella. El resultado observable es el mismo. Otras decisiones: una petición síncrona pendiente cuando otro hilo cierra el cliente termina con `SessionClosed` (Horizon la deja esperando); el resultado asíncrono se escribe en la palabra 2 del *buffer* (`SetAsyncResult`, modelo); una petición asíncrona a un servicio HLE no se admite (los HLE son síncronos) |

## 3. Las SVC por grupo
| Grupo | SVC | Comportamiento |
|---|---|---|
| Hilos | 0x32 `SetThreadActivity`, 0x33 `GetThreadContext3` | suspensión `SuspendType_Thread`, contexto de 0x320 bytes; `Busy` sobre el llamante |
| Excepciones | 0x28, 0x36 | D-P6.0-3 |
| Perfilado/depuración | 0x2E, 0x2F, 0x60-0x6D | D-P6.0-1 (`QueryDebugProcessMemory` comprueba antes su puntero de salida) |
| Proceso | 0x4F, 0x79-0x7C | D-P6.0-2; `GetProcessInfo` 0 = `Running` (2), 1 = *exit tag* 0 |
| Memoria de proceso | 0x5D-0x5F, 0x73-0x78 | sobre el propio proceso; caché: comprobaciones y nada más (el *host* es coherente) |
| Memoria física | 0x54, 0x55, 0x90, 0x91 | D-P6.0-7; `QueryMemoryMapping` → `NotFound` (no hay mapeos de E/S ni estáticos); memoria *insecure* en la región de alias de código |
| Hardware | 0x39, 0x3A, 0x46, 0x47, 0x4E, 0x53, 0x56-0x5C | D-P6.0-4 |
| Sistema | 0x3C, 0x3D, 0x4D, 0x6F | D-P6.0-4/5 |
| Monitor seguro | 0x7F | **frontera**, D-P6.0-8 |
| IPC del guest | 0x20, 0x22, 0x23, 0x40-0x44, 0x70-0x72 | §4 |
| (P6.0 antes de esta tanda) | 0x13-0x15, 0x2C, 0x2D, 0x30, 0x31, 0x37, 0x48-0x4C, 0x50-0x52, 0x7D, 0x7E | memoria compartida, de transferencia y de código; memoria física; límites de recursos |
| `GetInfo` | 9, 10, 16, 20, 23, 24, 26-28, 34, 36-38 | `ResourceLimit`, `IdleTickCount` (ticks del núcleo sin hilo), `SystemResourceSizeTotal` (el del NPDM), `UserExceptionContextAddress` (región local del proceso, reservada al primer uso), `IsApplication`, `FreeThreadCount`, `IsSvcPermitted`, `IoRegionHint`, `AliasRegionExtraSize`, `TransferMemoryHint`, `AddressSpaceSize`, *shadow stack* (0) |

## 4. IPC escrita por el guest
- **Objetos:** `KSession`/`KLightSession` (`CreateSession`), `KPort` (`CreatePort`, `ManageNamedPort` con la misma tabla de nombres que los puertos HLE: un nombre repetido es `InvalidState`, borrar un nombre HLE lo borra), sesiones por puerto (`ConnectToPort`, `ConnectToNamedPort`, `AcceptSession`), límite `SessionCountMax`, `OutOfSessions`, `PortClosed`. Referencias por *handle*; la sesión muere cuando no quedan *handles* ni está en la cola del puerto.
- **Mensajes** (`ReceiveRequest`/`SendReply`): cabecera, PID del emisor, *copy handles* (con referencia en su dueño: hilos, eventos, sesiones, puertos, memoria), *move handles* (solo en respuestas), X hacia la lista de recepción C (`ToMessageBuffer`, `ToSingleBuffer`, indexada), A/B/W mapeados en la región de alias del servidor (páginas completas compartidas; la primera y la última, parciales, copiadas a páginas nuevas y devueltas al cliente en B/W), datos en bruto. Errores: `InvalidCombination`, `MessageTooLarge`, `OutOfResource`, `ReceiveListBroken`, `SessionClosed`, `NotFound` (el servidor sigue esperando).
- **Bloqueo IPC del cliente** (`KMemoryBlock::LockForIpc`): las páginas completas de un *buffer* RW pierden el acceso de usuario y las de uno R la escritura, con atributo `IpcLocked` y contador `ipc_count` visible en `QueryMemory`.
- **`ReplyAndReceive*`**: primero los *handles*, luego la respuesta, luego la espera sobre cualquier objeto de sincronización (eventos, hilos, sesiones y puertos de servidor, puertos de cliente). `NotFound` vuelve a esperar. `SessionClosed` despierta a todos los que esperan. *Buffers* de usuario bloqueados durante la llamada (`LockForIpcUserBuffer`).
- **Asíncrona:** evento de kernel (reserva `EventCountMax`) señalado al responder.
- **Ligera:** 7 palabras en w1-w7, `ReplyFlag` en el bit 31 de w1, `InvalidState` si responde quien no recibió.
- **Marco HLE (P6_DISENO §3.1):** `HleRequest::copy_handle(i)` (entrada), `push_copy_handle`/`push_move_handle` (salida), `KernelIpc::create_service_event()` y señal/limpieza desde el *host*.

## 5. Catálogo y medición
Cada servicio HLE declara `(archivo de libnx, interfaz)` en `hle::catalog()`; `test_hle_catalog`
lo comprueba y lo imprime; `tools/hle/hle_coverage.py inv.json salida` calcula M-CMD (comando
contado si la clase catalogada lo implementa) y M-SRV (familias empezadas y completas).

## 6. Pruebas
| Prueba | Qué cubre |
|---|---|
| `test_p6_kernel` (nuevo) | un programa real de libnx (`tools/homebrew/p6_kernel`) con 40 comprobaciones: `GetInfo`, límites, respuestas retail, frontera SMC, *hardware* ausente, memoria compartida, JIT de libnx con memoria de código, actividad y contexto de hilos, servidor IPC del guest (PID, *copy*/*move*, X/C, A/B), *handle* propio por IPC, `MapProcessMemory`, *buffer* de usuario, asíncrona, puerto con nombre, IPC ligera, cierre, `CreateProcess`, tiempo ocioso por núcleo, bloqueos de *buffers* IPC, X indexado y al mensaje, límite de sesiones del puerto, respuesta tardía a un cliente cerrado, *timeout* con *buffer* de usuario y *buffer* de usuario hacia HLE. En los 3 motores JIT; en el intérprete se detiene en la primera instrucción AdvSIMD/FP (como H5) |
| `test_kipc` K11 (nuevo) | *copy handles* de entrada y *copy*/*move* de salida en servicios HLE; vida de los eventos de servicio |
| `test_hle_catalog` (nuevo) | catálogo bien formado |
| `test_svc_dispatch` | U1: los 124 números asignados tienen manejador, los 68 sin asignar no; *hints*; el *fuzz* de todos los números clasifica las nuevas |
| `test_svc_process` P1 (nuevo) | programa en ensamblador (`p6_svcs.S`) con 31 resultados de SVC de P6.0 que no necesitan un segundo hilo (`GetInfo` nuevas, respuestas retail, *hardware* ausente, frontera SMC, sesiones y puertos con nombre, `QueryPhysicalAddress`), en **los 5 motores** |
| `test_svc_process` | S2 con un número sin asignar (fixture `unassigned`, nuevo); S2b: el programa `unimpl` (0x2C) ya recibe `InvalidState` y continúa |
| `test_vm_manager`, `test_mem_process` | `GetInfo` 23/28 según D-P6.0-9; V10: gránulos compartidos (la reducción del *heap* no libera lo que `MapProcessMemory`/IPC sigue usando) |

## 7. Matriz de riesgos
| # | Riesgo | P | I | Mitigación |
|---|---|---|---|---|
| R1 | Semántica equivocada en SVC poco documentadas | M | M | Orden y códigos de mesosphere; decisiones explícitas donde se modela (D-P6.0-4/5/7/10) |
| R2 | Regresión del arranque H5 por las `InfoType` nuevas | M | A | `test_h5`, `test_mem_process` en los 5 motores; libnx trata igual el éxito y el error de 28 |
| R3 | Fugas de referencias (*handles* copiados entre subsistemas) | M | A | `retain`/`release` únicos en el coordinador; invariantes de `KernelIpc`/`KernelThreads`; K11 cuenta eventos |
| R4 | Páginas liberadas aún mapeadas (`MapProcessMemory`, IPC) | M | A | gránulos con referencias (`release_owned`/`collect_owned`); ASan |
| R5 | Bloqueos (servidor y cliente en el mismo proceso) | M | M | entrega en la llegada (D-P6.0-10); diagnóstico de esperas; pruebas con hilos reales |
| R6 | Cruzar la frontera DRM | B | A | `CallSecureMonitor` responde siempre `x0 = 1`; ninguna función del monitor existe |
| R7 | Seguridad: tamaños y punteros del guest | M | A | lectura y escritura por la tabla de páginas con comprobación de estado; ASan/UBSan; *fuzz* de SVC |

## 8. Análisis de impacto
| Área | Cambio (solo añadidos salvo lo indicado) |
|---|---|
| `system/svc_p6_system.cpp`, `svc_p6_ipc.cpp`, `kipc_guest.cpp` | nuevos |
| `system/svc_table.cpp`, `svc_dispatcher.{h,cpp}` | manejadores; `GetInfo` delega las ids nuevas; 16 devuelve el recurso del NPDM |
| `system/kthread.{h,cpp}` | objetos de sincronización externos, eventos del kernel, tiempo ocioso, región local; `wait_synchronization` reorganizada (mismo comportamiento); contexto de 0x320 bytes (corrección) |
| `system/kipc.{h,cpp}` | IPC del guest, *buffer* de usuario en HLE, *handles* en HLE, eventos de servicio; `session_count()` cuenta también las del guest |
| `system/vm_manager.{h,cpp}` | memoria *insecure*, de proceso, física, IPC (bloqueo de cliente, mapeo de servidor), gránulos compartidos; `reset()` limpia `physical_owned_` (corrección); los bloques llevan `ipc`/`orig_perm` |
| `system/kobjects.{h,cpp}`, `memory_state.h`, `hle/*` | `add_ref`, `process_limit_free`; estados `Insecure`/`Static` y resultados; catálogo |
| `runtime/runtime_coordinator.cpp` | `is_application`; `retain`/`release`/reservas; proveedor de sincronización |
| `tests/`, `tools/` | §6; `tools/hle/hle_coverage.py`; programa `tools/homebrew/p6_kernel` y su generador |
| **Sin cambios** | `crypto/`, cargadores de NCA/NSP/XCI, claves, `shader/`, capa IPC antigua |
