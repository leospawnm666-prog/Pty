# P4.4 — Informe: el resto de la ISA de Maxwell en el recompilador (hito H10)

Estado: **P4.4 implementado y verificado. Hito H10 alcanzado en este entorno** (oráculos lavapipe
y SwiftShader; ver los límites en §7). Con P4.4 termina el plan P4 de `P4_DISENO.md`.

| Métrica (P4_4_DISENO.md §1) | Meta de P4.4 | Resultado |
|---|---|---|
| M1 — traducción | 282/296: todas las codificaciones con semántica pública | **282/296** (95,3 %; P4.3: 206). Lista de P4.4: **76/76**. Las 14 restantes (§6) no tienen semántica utilizable en ninguna fuente pública: error explícito y razonado |
| Formas | las de §3 del diseño | Todas las que tienen semántica pública se traducen (§2.4); las demás, error razonado (§6) |
| M2 — corpus T3-X | A = B al 100 % | **6/6** en lavapipe (3 de *compute*, 3 tuberías) + **4/4** tuberías en SwiftShader (una, `f04_ipaoff_mix`, solo allí por un fallo de lavapipe, §4.3) |
| M4 — SPIR-V válido | 100 % | **1369/1369** módulos aceptados por `spirv-val --target-env vulkan1.1` (P4.3: 1014) |
| T2-X — formas nuevas | todas, con resultado calculado aparte | **257/257** casos verificados. lavapipe: 255 + 2 omitidos; SwiftShader: 181 + 76 omitidos (60 sin `shaderFloat64`, 15 sin atómicas de 64 bits, 1 fallo conocido). Ningún caso se omite en los dos |
| Regresión | SPIR-V de P4.3 idéntico | De los 1014 módulos de P4.3, **1013 idénticos byte a byte**. El que cambia es el programa sintético de M1 de `MOV` con máscara de carriles 0, por la corrección D-P4.4-17 |

Meta H10: "M1 282/296 con las 14 restantes razonadas, las formas de §3 traducidas o con error
razonado, el corpus diferencial al 100 % en lavapipe, M4 al 100 % y T2-X de todas las formas".
**Cumplida.**

**Contexto:**
- **Base:** `LoboGelido_beta_0.1_GLASS_PLAY_BUILD_FIX.zip` + la cadena hasta P4.3.
- **Especificación:** `P4_4_DISENO.md`. D-P4.4-1 a 13 se tomaron como se recomendaban. D-P4.4-14
  a 17 se añadieron al revisar fila a fila las formas de §3 (estaba previsto: "se revisan uno a
  uno").
- **Método:** protocolo de 12 pasos y Regla de Oro. No se ha eliminado ninguna clase, función ni
  *binding* nativo. Los cambios en archivos existentes son aditivos, salvo:
  - mensajes de error de formas que ahora se traducen o cuyo motivo cambió ("fuera de P4.1" →
    "sin semántica pública" / "requiere …");
  - la corrección de `MOV`/`MOV32I` (D-P4.4-17);
  - en `test_shader_static.cpp`, los casos E1 que empezaron a traducirse se sustituyeron por
    formas que siguen en error (`VOTE` → `TXA`, y los de texturas). Siguen comprobando lo mismo:
    error explícito con dirección y mnemónico.
- **Política *clean-room* (D-P4-2):** todo es código propio. Referencias usadas, todas
  permisivas:
  - envydis/envyas y la documentación de envytools (MIT): campos, orden de los *flags* de CC;
  - Mesa (MIT): `nv50_ir` (emisor GM107, bajadas de `interpolateAtOffset`, mín/máx de 64 bits)
    y NAK (`sm50.rs`, `from_nir.rs`, `nak_nir_lower_fs_inputs.c`): campos de `BAR`, `HSETP2`,
    `IPA`, `LDC.IS`, atómicas, `VOTE`, `PIXLD`;
  - NVIDIA: tabla de instrucciones de *CUDA Binary Utilities*, especificación PTX;
  - especificaciones de SPIR-V, GLSL.std.450 y Vulkan.

  Nada de yuzu, Eden ni Ryujinx.
- **No se toca:** `crypto/`, cargadores NCA/NSP/XCI ni claves.

## 1. Qué se entrega
| Archivo | Qué |
|---|---|
| `shader/translate_fp64.inc` (nuevo) | FP64: `DADD`, `DMUL`, `DFMA`, `DMNMX`, `DSET`, `DSETP`, `MUFU.RCP64H/RSQ64H`, `F2F`/`F2I`/`I2F` de 64 bits; modo `Lossy32` |
| `shader/translate_fp16.inc` (nuevo) | FP16x2: `HADD2`, `HMUL2`, `HFMA2`, `HSET2`, `HSETP2` y las formas `_32I` |
| `shader/translate_misc.inc` (nuevo) | flujo con destino en constbuffer, `PEXIT`/`PLONGJMP`/`LONGJMP`, `BPT`/`RTT`, `CSET`/`CSETP`, `FCHK`, `VOTE`, `PIXLD`, `BAR.ARV/RED` + `B2R`/`R2B`, `IMADSP`, `IDP`, `LEPC`, `GET/SETCRSPTR`, `GET/SETLMEMBASE`, `SAM`/`RAM`, `SHFL` general, máscara de carriles de `MOV` |
| `shader/translate.{h,cpp}` | `ShaderInfo::fp64`, `bindless`, `image_int64_atomics`, `int64_atomics`; `TextureState::buffer`; atómicas (D-P4.4-15); `IMNMX.XHI/XLO`, `P2R/R2P.CC`, `LEA.HI` con negación, `LDC.IS`, `F2I` desde f16 (D-P4.4-16) |
| `shader/translate_texture.inc` | *offsets* dinámicos, `TLD4.PTP` con registros, `TXQ` de muestras, *texel buffers*, `SUST.D.BA`, `SUST.P` parcial, atómicas de imagen `INC`/`DEC`/f32/64 bits, *bindless* general |
| `shader/translate_graphics.inc` | `IPA.OFFSET`, `IPA.SC`, `SHFL`/`FSWZADD` fuera del FS, `SR_LANEID` en FS |
| `shader/spirv/builder.{h,cpp}` | códigos de f64, *subgroup*, `InterpolateAtOffset`, `c_f64`, `c_u64`, extensiones |
| `tests/test_shader_t2x.cpp`, `tests/shader/t2x_fixtures.h`, `tools/gpu_toolchain/gen_shader_t2x.py` | T2-X: 257 casos con resultados calculados en Python/numpy sin pasar por el traductor |
| `tests/test_shader_t3x.cpp`, `tests/data/shader/xcorpus/`, `t3x_fixtures.h`, `t3xg_fixtures.h` | T3-X: `double`, *votes*, `PIXLD`, gradientes de cubo y 3D, `interpolateAtOffset` |
| `tests/shader/vk_compute.*`, `vk_textures.h`, `t3_runner.h` | `shaderFloat64`/`Int64`, `VK_EXT_descriptor_indexing`, `VK_KHR_shader_atomic_int64`, *texel buffers*, *samplers* sueltos, arrays de descriptores, *buffers* `double` |
| `tests/data/shader/oracle_bugs/` | reproducciones mínimas de los dos fallos de lavapipe encontrados (§4.3) |
| `P4_4_DISENO.md`, `P4_4_INFORME.md` | diseño (actualizado: D-P4.4-14..17) e informe |

## 2. Cómo traduce
### 2.1 FP64 y FP16 (D-P4.4-2/3)
- **FP64:** pares de registros (Rn bajo, Rn+1 alto). Nativo con `Float64`. `ShaderInfo::fp64 =
  Lossy32` calcula en f32 con conversión manual de bits, para los dispositivos sin
  `shaderFloat64`. Las conversiones f64 → f32/f16 redondean correctamente con lógica de bits: los
  *drivers* pliegan `f64(f32(x))` y un `FConvert` no basta. TwoSum con `NoContraction`.
- **FP16x2:** cada mitad en f32. Suma y producto: un solo redondeo correcto. FMA: TwoSum +
  redondeo a impar para evitar el doble redondeo.

### 2.2 *Warp* y sistema (D-P4.4-5..9)
- `VOTE` con `GroupNonUniformBallot`; la máscara se desplaza al carril del *warp* cuando el
  *subgroup* tiene menos de 32 carriles.
- `SHFL` general con `GroupNonUniformShuffle` (fórmula de PTX).
- `FCHK`: condición que contiene a la del *hardware*.
- `BAR.RED` con un contador compartido entre barreras.
- `IMADSP` e `IDP`; `LEPC`, punteros CRS y LMEMBASE como modelos con aviso.

### 2.3 Texturas e imágenes (D-P4.4-10..12)
- **Offsets dinámicos:** `TLD` los suma; `TEX`/`TXD` 1D/2D, `switch` sobre los valores posibles
  con `ConstOffset`.
- **`TLD4.PTP` con registros:** cuatro *gathers*.
- **Texel buffers:** `Dim Buffer`.
- **Bindless general:** tablas de descriptores indexadas por TIC y TSC con `NonUniform`. P4.4
  decora también la imagen cargada y los punteros de texel: lavapipe lo necesita (§4.5).
- **Atómicas de imagen:** `INC`/`DEC`/f32 por CAS; 64 bits con `Int64ImageEXT` + `Int64Atomics`.

### 2.4 Formas que P4.1–P4.3 dejaron fuera (revisión de §3)
| Forma | P4.4 | Fuente |
|---|---|---|
| `IPA.OFFSET` | `InterpolateAtOffset` con el desplazamiento en S0.12 | Mesa `nv50_ir`, NAK |
| `IPA.SC` | como `MULTIPLY`, con aviso (el sombreado plano del estado no se modela) | Mesa `nv50_ir` (modelo) |
| `ATOMS` `INC`/`DEC` | bucle CAS | PTX `atom.inc/dec` |
| `ATOMS` 64 bits y `CAS` de 64 | palabras de 64 bits en la memoria compartida (solo en esos programas) | NAK (empaquetado del CAS) |
| `ATOM`/`RED` 64 bits y `ATOM.CAS` de 64 | vista u64 del *buffer* | NAK |
| `ATOM`/`RED` f32 `ADD` | bucle CAS, RN, subnormales a cero | PTX `atom.add.f32` |
| `IMNMX.XHI`/`.XLO` | mín/máx de 64 bits en dos mitades | Mesa `nv50_ir` (modelo) |
| `P2R`/`R2P` `.CC` | Z S C O en los bits 0-3 | envytools (modelo) |
| `LEA.HI` con negación | se niega C:A de 64 bits | simetría con `LEA` (modelo) |
| `LDC.IS` | banco y desplazamiento del registro | NAK |
| `F2I` desde f16 | mitad por el bit 41 | campos de envydis, como `F2F` |
| `MOV`/`MOV32I` con máscara | se respeta (corrección de P4.1) | uam la emite al emular gradientes |

## 3. Requisitos para P5 (integración)
- **`ShaderInfo::fp64`:** `Native` si el dispositivo tiene `shaderFloat64`, si no `Lossy32`
  (pérdida de precisión documentada).
- **`ShaderInfo::bindless`:** tablas de imágenes muestreadas, *samplers* e imágenes de
  almacenamiento indexadas por TIC/TSC. Requieren `descriptorIndexing` (indexado no uniforme).
  Los *arrays* de cada tipo de imagen comparten el *binding*.
- **`ShaderInfo::int64_atomics`:** pide `shaderBufferInt64Atomics` y `shaderSharedInt64Atomics`.
- **`ShaderInfo::image_int64_atomics`:** pide `shaderImageInt64Atomics`.
- **`TextureState::buffer`:** desde el TIC (tipo de textura *buffer*).
- **Votes con *subgroups* < 32:** solo coinciden con el *hardware* en flujo uniforme por
  *subgroup*. P5 debe pedir `requiredSubgroupSize = 32` donde exista.

## 4. Verificación
### 4.1 T3-X — corpus diferencial
**6/6** en lavapipe y **4/4** tuberías en SwiftShader, recompilado (uam → traductor) = glslang:
- `x01_fp64`, `x02_fp64_div`: `double`, con tolerancia relativa 1e-5 en la división, porque uam
  usa `MUFU.RCP64H` + Newton;
- `x03_vote`: *ballot*, `anyInvocation`, `allInvocations`, `allInvocationsEqual`;
- `f01_pixld`: `gl_SampleID`, `gl_SampleMaskIn`;
- `f02_gradcube`: `textureGrad` de cubo y 3D (`SAM`/`RAM` y la máscara de carriles de `MOV`);
- `f03_ipaoff`: `interpolateAtOffset` con perspectiva y sin ella, con una w distinta por vértice;
- `f04_ipaoff_mix`: lo mismo leyendo además las entradas en el centro (solo SwiftShader, §4.3).

### 4.2 T2-X — formas nuevas
257 casos. Cada uno es un programa de *compute* con entradas por invocación y resultados
calculados en Python (numpy para f64/f16, aritmética entera de Python para atómicas, PTX para
`dp4a`/`dp2a`), nunca con el traductor. Incluyen, entre otros:
- casos límite de f64/f16: subnormales, ±0, infinitos, NaN, desbordamiento, empates en el
  redondeo;
- f64 en los dos modos (`Native` y `Lossy32`);
- *texel buffers*: `TLD`, `TXQ`, `SULD`/`SUST`/`SUATOM b1d`;
- *bindless* general: `TEX` con TIC y TSC distintos por invocación; `SULD` con tabla de imágenes;
- atómicas compartidas y globales de 64 bits, mezcla de accesos de 32 bits en un programa con
  palabras de 64 bits, `ATOM`/`RED` f32 con subnormales;
- `IMNMX.XHI/XLO` con y sin signo, `P2R/R2P.CC` con el acarreo usado después por `IADD.X`,
  `LEA.HI` con negación, `LDC.IS`, `F2I` desde f16 con `FTZ`.

### 4.3 Fallos de los oráculos (omisiones declaradas)
| Oráculo | Fallo | Casos | Reproducción |
|---|---|---|---|
| lavapipe (LLVM 18) | se cae compilando `HSETP2` con inmediato | `hsetp2_imm` (pasa en SwiftShader) | `oracle_bugs/lvp_llvm18_half_compare.spvasm` |
| lavapipe | `interpolateAtOffset` de una entrada leída también en el centro devuelve el valor del centro | `f04_ipaoff_mix` (pasa en SwiftShader) | `oracle_bugs/lvp_interp_at_offset_mixed.frag` |
| lavapipe | ignora el nivel de `OpImageQuerySizeLod` en *compute* (ya en P4.3) | `txq_type` | P4.3 |
| SwiftShader | ignora *offsets* no constantes de `OpImageGather` (ya en P4.3) | `tld4_ptp_dyn` | P4.3 |

### 4.4 Fallos de uam encontrados
Ninguno nuevo. Hallazgo útil: uam emite `MOV` con máscara de carriles al emular gradientes, y
P4.1 la ignoraba (D-P4.4-17).

### 4.5 Errores propios encontrados y corregidos durante P4.4
- Conversiones f64 → f32 plegadas por NIR → redondeo con lógica de bits.
- `DFMA` sin fusionar en lavapipe → expectativa alternativa declarada (`alt`).
- Campos de `BAR` mal decodificados (envydis mezcla el bit 39 con el modo) → campos de NAK.
- La máscara de `MOV` ignorada (corrección de P4.1).
- `SR_LANEID` cambiado en TES alteraba 5 módulos de P4.3 → solo en FS.
- *Bindless* de imágenes de almacenamiento: faltaba `NonUniform` en la imagen cargada. lavapipe
  leía siempre el elemento 0.
- Atómicas de imagen de 64 bits: faltaba la capacidad `Int64Atomics` (la detectó `spirv-val` al
  añadir el módulo estático).
- `Select` con operandos float/bool emitido con tipo `uint` (lo detectó `spirv-val`).
- Reordenación de instrucciones en `ATOMS` de 32 bits que cambiaba el SPIR-V de P4.3 (la detectó
  la comparación de *hashes*) → orden de P4.1 restaurado.

### 4.6 M4, D1, M1, E1
- **M4:** 1369/1369 módulos válidos con `spirv-val`.
- **D1:** 4 hilos idénticos.
- **M1:** 282/296.
- **E1:** errores explícitos con dirección y mnemónico.
- **Hash:** 1013/1014 módulos de P4.3 idénticos byte a byte (el que cambia, por D-P4.4-17).

## 5. Matriz
| Configuración | Resultado |
|---|---|
| *Host* (GCC, con oráculos) | **98/98** |
| JIT (Dynarmic, Release) | **101/101** |
| ASan + UBSan | **98/98** y **101/101** |
| TSan | **98/98** y **101/101** (con las opciones de siempre: supresión del oráculo y `report_signal_unsafe=0` en JIT) |
| Descarga de Dynarmic (*fetch*) | **101/101** |
| Android (NDK, compilación de las fuentes) | 100 OK; fallan los 2 de siempre (`aaudio_sink`, `android_display_adapter`: cabeceras del NDK que no hay aquí) |
| ARM64 (`clang --target=aarch64`) | `translate.cpp` y `builder.cpp` sin avisos |

ASan, TSan y la descarga se ejecutaron con el traductor final. Después solo cambiaron las pruebas
(los refuerzos de la mutación, §5.1) y se quitó una variable sin uso de `translate_fp16.inc`. Con
el árbol final se repitieron el *host* completo (98/98), la estática y T2-X en los dos oráculos, y
las compilaciones limpias desde el zip.

### 5.1 Mutación
37 mutantes sobre lo nuevo (`mut_p44.py`, mismo método que P4.3): FP64, FP16, condiciones de CC,
`FCHK`, `VOTE`, `IMADSP`, `IDP`, `BAR.RED`, pila CRS, `F2I` f16, `LEA.HI`, `LDC.IS`, `IMNMX`,
`P2R.CC`, atómicas compartidas/globales/f32/64 bits, memoria compartida de 64 bits, `IPA.OFFSET`,
*bindless* general y *texel buffers*. Pruebas: estática (M4/E1), T2-X en los dos oráculos y T3-X
(lavapipe; tuberías también en SwiftShader).
- **Primera pasada: 33/37.** Sobrevivieron 4, por huecos en las pruebas, no en el código:
  - `INC` sin vuelta en un programa con palabras de 64 bits: no había caso;
  - máscara del TIC y desplazamiento del TSC: los *handles* no tenían bits 16-19;
  - `b1d` declarado como imagen 1D: lavapipe lo aceptaba igual.
- **Correcciones:** caso `atoms_incdec_in64`, *handles* con TIC fuera de la tabla (se recorta a la
  última entrada) y comprobación en el *runner* de que un *texel buffer* se declara `Dim Buffer`.
- **Segunda pasada: 4/4. Total: 37/37 matados.**

## 6. Qué queda con error explícito (sin semántica pública)
- **Filas (14):** `TXA`, `VOTE.VTG`, `IDE`, `STP`, `LDG` con predicado de salida y las 9 de vídeo
  (`VADD`, `VABSDIFF`, `VABSDIFF4`, `VMAD`, `VMNMX`, `VSET`, `VSETP`, `VSHL`, `VSHR`). Motivo en
  `P4_4_DISENO.md` §2.4.
- **Sub-formas:**
  - `IMNMX.XMED`, `LDC.IL/.ISL`, `ATOMS.CAS` con subcódigos distintos de 4/5;
  - `ATOM` de 128 bits y tipos 6/7, f32 distinto de `ADD`, `INC`/`DEC` de 64 bits;
  - `I2I` de 64 bits, `LD/ST` genérico con predicado;
  - tipos reservados (código 0) de `F2F`/`F2I`/`I2F`;
  - `TXQ` de posición de muestra, filtro, LOD, *wrap* y borde; `TLD.CL`; `TEX.LBA/.LLA`;
  - `BAR.SCAN`; atómicas de imagen `sd32`/`sd64`;
  - condiciones de CC `CSM`/`RLE`/`RGT`.

  Ni Mesa ni NAK las emiten y ninguna fuente pública las describe: traducirlas sería adivinar.

## 7. Límites (honestos)
- **Modelos con aviso:** su semántica sale de una inferencia (simetría, uso en Mesa), no de una
  especificación: `PEXIT`/`PLONGJMP`, `IMADSP`, punteros de sistema, `IPA.SC`, `IMNMX.XHI/XLO`,
  `P2R/R2P.CC`, `LEA.HI` con negación, `FCHK` (condición más amplia que la del *hardware*). Son
  coherentes y deterministas, pero solo el *hardware* real puede confirmarlos.
- **Sin oráculo:** las atómicas de imagen de 64 bits se validan con `spirv-val`, pero ningún
  oráculo de aquí tiene `shaderImageInt64Atomics`.
- **Votes:** con *subgroups* < 32 solo son exactos en flujo uniforme por *subgroup* (lavapipe
  tiene 8 carriles; las pruebas son invariantes al tamaño).
- **Memoria compartida de 64 bits:** en los programas con `ATOMS` de 64 bits cada acceso de 32
  bits cuesta una o dos atómicas de 64. Afecta al rendimiento, no a la corrección, y solo en esos
  programas.
- **Hardware:** sin GPU Maxwell ni Switch real, nada se compara con el *hardware*. Los oráculos
  son implementaciones Vulkan.

## 8. Siguiente fase
P5: integrar el recompilador en `ShaderProgramManager` y en la tubería de Vulkan, llenando
`ShaderInfo`/`GraphicsState`/`TextureState` desde el estado del guest (registros 3D, TIC/TSC) y
las capacidades del dispositivo (§3).
