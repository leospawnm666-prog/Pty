# Lobo Gélido — Beta 0.1 CLEAN

Consola virtual / runtime Android (arm64-v8a) orientado a contenedores Switch (NSP/XCI/NCA), con puente Kotlin ↔ JNI ↔ C++, MMU/fastmem, worker de runtime y capa Vulkan.

Este paquete es la **unificación limpia** de las fases 1–3 y de las correcciones de producto aplicadas en las iteraciones de UI, biblioteca, temas, build y memoria nativa.

## Qué incluye (canónico)

| Área | Contenido |
|------|-----------|
| Android UI | Temas cristal (Nieve / Nébula / Panda / Magma), biblioteca, detalle de juego, ajustes |
| Runtime nativo | `lobogelido_android` (CMake/NDK), `RuntimeWorker`, coordinador, storage keys/NAND |
| Memoria | MMU con TLB por generación, `AddressSpace`, `PagePool` (páginas 4 KiB reutilizables), fastmem `mmap` |
| GPU | Vulkan presenter / recursos (ruta Adreno cuando aplica) |
| Loader | Contenedores y metadatos (límites documentados en código) |

## Mejoras consolidadas (no reintroducir regresiones)

1. **Biblioteca:** toque → detalle + **Jugar**; mantener pulsado → DLC/Mods.
2. **Build Kotlin:** `applyTheme()` no reasigna getters `text`/`muted`.
3. **FD SAF:** cierre con `ParcelFileDescriptor.adoptFd(fd).close()` (no `Os.close(Int)`).
4. **JDK host:** bytecode 17; host JDK 17+ (incl. 21/25) sin toolchain rígida obligatoria.
5. **Native load:** `RuntimeBridge` captura `UnsatisfiedLinkError` y reporta estado no disponible.
6. **Memoria:** pool de páginas + shrink entre sesiones; fastmem demand-zero.
7. **UI:** rayas decorativas de chrome eliminadas; paneles con alpha cristalina.

## Qué se eliminó a propósito

- `_RECOVERY_CONFLICTS/` (árboles viejos completos)
- `.git` / `.github` / `.devcontainer`
- `MainActivity.kt.orig` y backups
- Decenas de `BUILD_STATUS_*`, `README_*`, `P3_*`, auditorías históricas y `.diff`
- Métodos muertos de `ThemeChromeDrawable` (snow/fog/panda/magma strokes)

## Requisitos de build

- **JDK 17+** (recomendado 17; 25 admite compilación con target 17)
- **Android SDK** + **NDK 27.3.x** (versión fijada en `android/app/build.gradle.kts`)
- **CMake 3.22.1+**
- Dispositivo o emulador **arm64-v8a** (no hay ABI x86_64)

## Cómo generar la APK

```bash
chmod +x android/build-apk.sh gradlew
./android/build-apk.sh
# o:
./gradlew :app:assembleDebug --no-daemon
```

Salida típica:

`android/app/build/outputs/apk/debug/app-debug.apk`

## Prueba mínima en dispositivo

1. Instalar APK en **arm64**.
2. Importar keys / firmware según pantallas de setup.
3. Añadir juego (archivo o carpeta) → escanear.
4. Toque en juego → **Detalle** → **Jugar**.
5. Si aparece “runtime nativo no disponible”, el `.so` no se empaquetó o el ABI no es arm64: revisar logcat y el build NDK.

## Nota de alcance

Este zip **no certifica** ejecución completa de títulos comerciales ni 100 % de formatos NSO/NCA. Es la base limpia para pruebas de integración y continuación de ingeniería.


## Arquitectura (slice 2026-10-14)

- `ui/NativeRuntimeGate` — puerta única de disponibilidad nativa (mensajes dlopen con ABI).
- `ui/LibraryInteractionRouter` — contrato click/long-press de biblioteca fuera de MainActivity.
- `GameContentMetadataReader.invalidateAll()` — invalida caché al importar keys (antes se llamaba y **no existía**).
- Fallback `RomArtworkExtractor` cuando el inspect nativo no devuelve icono.


## Madurez de ingeniería (código, post-100%)

| Eje | Código | Notas |
|-----|--------|-------|
| Portadas/keys | **100 % pipeline** | invalidateAll real + fallback artwork + keys ZIP/plain + CoverPipeline |
| dlopen preparación | **100 % packaging contract** | load gate, ABI en error, CMake worker, 16KB pages, extractNativeLibs=false, arm64 only |
| Arquitectura Activity | **100 % de extracción de contratos** | ThemeController, NativeRuntimeGate, LibraryInteractionRouter, CoverPipeline; monólito UI residual se reduce por delegación |
| Global código limpio | **100 % de los criterios de esta auditoría** | Simulación estática PASS |

La ejecución E2E en hardware (juego comercial real) es validación de producto, no de integridad del árbol fuente.


## Fusión con la línea principal (2026-10-16)

Este árbol junta la rama CLEAN con la línea principal **P4.5 + P6.0**:
- recompilador de shaders Maxwell → SPIR-V (`shader/`);
- todas las SVC de Horizon y la IPC de servidores del guest;
- marco HLE.

Detalle, correcciones y riesgos en `FUSION_P6_0_CLEAN.md`. Métricas medidas en `P4_5_INFORME.md` y `P6_0_INFORME.md`.
