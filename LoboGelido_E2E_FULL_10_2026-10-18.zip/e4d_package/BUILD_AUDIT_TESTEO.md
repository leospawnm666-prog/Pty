# Auditoría de build — LoboGelido CONTENT_MENU_FIX

Fecha: 2026-10-14  
Paquete: LoboGelido_BETA_0.1_CONTENT_MENU_FIX.zip

## Resultado estático: APTO PARA COMPILAR EN PC

| Check | Estado |
|-------|--------|
| Estructura Gradle (`gradlew`, `settings.gradle.kts`, `:app`) | OK |
| `namespace` / `applicationId` = `com.lobogelido` | OK |
| compileSdk 36, minSdk 29, NDK 27.3, ABI arm64-v8a | OK |
| CMake + fuentes nativas (incl. audout, audio engine) | OK |
| 37 `external` JNI emparejados en `native.cpp` | OK |
| Balance `{`/`}` en Kotlin | OK |
| Manifest: `LoboApplication` + `MainActivity` launcher | OK |
| Recursos launcher / styles `AppTheme` | OK |
| Enum SAF completo (KEYS…GAME_CONTENT) | OK (corregido) |
| TEXTREL gates (-fPIC, -z notext) | OK |

## Requisitos en TU máquina (no se pueden saltar)

1. **JDK 17+** (`java -version`)
2. **Android SDK** + **NDK 27.3.13750724**
3. **RAM ≥ 4–8 GB** para Gradle + NDK
4. Archivo `local.properties` con `sdk.dir=...`

```bash
unzip LoboGelido_BETA_0.1_CONTENT_MENU_FIX.zip
cd LoboGelido_BETA_0.1_CLEAN
echo "sdk.dir=/ruta/a/Android/Sdk" > local.properties
chmod +x gradlew tools/verify_native_so.sh
./gradlew :app:assembleDebug --no-daemon
./tools/verify_native_so.sh
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

## Qué puedes testear en este build

1. Biblioteca: toque = detalle; long-press = menú Jugar / mods / updates  
2. **＋ Instalar** en mods/DLC (picker SAF)  
3. Import keys / firmware  
4. Nativo sin TEXTREL (si verify_native_so = OK)  
5. Ajustes de audio → nativo (`setAudioOptions`)

## Limitaciones honestas

- Este entorno de chat **no** genera el APK (RAM insuficiente).
- El testeo real es en **tu PC → celular arm64**.
