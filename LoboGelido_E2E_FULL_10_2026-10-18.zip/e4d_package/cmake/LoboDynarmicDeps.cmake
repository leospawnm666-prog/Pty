# Lobo Gélido - Dynarmic + Boost provisioning (P2 phase B.2).
#
# Used by android/app/src/main/cpp/CMakeLists.txt when LOBOGELIDO_ENABLE_DYNARMIC=ON,
# and by the root CMakeLists.txt when LOBOGELIDO_FETCH_DYNARMIC=ON (host verification
# of this exact code path).
#
# Why this file exists:
#  * github.com/merryhime/dynarmic is no longer reachable (git asks for credentials, the
#    answer GitHub gives for a missing/private repository). The build now uses the
#    yuzu-mirror copy pinned to ONE commit, so every clean build gets the same sources.
#  * Dynarmic vendors all of its externals (fmt, mcl, oaknut, xbyak, zydis, ...) EXCEPT
#    Boost, which it requires with find_package(Boost 1.57 REQUIRED). It only uses
#    header-only libraries (boost::icl and what icl includes), so the official Boost
#    release tarball is fetched, verified by SHA-256 and exposed as a header-only
#    Boost::boost target. Nothing from Boost is compiled.
#
# Everything below can be overridden at configure time (-D...), e.g. to point at an
# internal mirror or at a local file:///... copy of the same archives.

include_guard(GLOBAL)
include(FetchContent)

set(LOBOGELIDO_DYNARMIC_REPOSITORY "https://github.com/yuzu-mirror/dynarmic.git" CACHE STRING
    "Git repository Dynarmic is fetched from")
# yuzu-mirror/dynarmic @ 2024-03-05 "Replace some more dead repo references" (0BSD).
set(LOBOGELIDO_DYNARMIC_COMMIT "9d4582339990d4eae53f1dc7160686920fc2075c" CACHE STRING
    "Exact Dynarmic commit (40-hex SHA). Pinned for reproducible builds.")

set(LOBOGELIDO_BOOST_URL
    "https://github.com/boostorg/boost/releases/download/boost-1.83.0/boost-1.83.0.tar.xz"
    CACHE STRING "Boost release archive (headers are used; nothing is compiled)")
set(LOBOGELIDO_BOOST_SHA256
    "c5a0688e1f0c05f354bbd0b32244d36085d9ffc9f932e8a18983a9908096f614"
    CACHE STRING "SHA-256 of LOBOGELIDO_BOOST_URL")

# Makes Boost::boost (header-only) available and primes FindBoost so that Dynarmic's
# find_package(Boost 1.57 REQUIRED) succeeds without searching the (cross) sysroot.
function(lobogelido_provide_boost_headers)
    if (TARGET Boost::boost)
        return()
    endif()
    FetchContent_Declare(lg_boost
        URL "${LOBOGELIDO_BOOST_URL}"
        URL_HASH "SHA256=${LOBOGELIDO_BOOST_SHA256}"
        # No such directory in the archive: MakeAvailable only downloads + extracts, it
        # never add_subdirectory()s Boost's own CMake project.
        SOURCE_SUBDIR "lobogelido-headers-only")
    FetchContent_MakeAvailable(lg_boost)
    FetchContent_GetProperties(lg_boost SOURCE_DIR _lg_boost_src)

    # Modular layout of the release archive: libs/<lib>/include and
    # libs/numeric/<lib>/include.
    file(GLOB _lg_boost_includes LIST_DIRECTORIES true
         "${_lg_boost_src}/libs/*/include" "${_lg_boost_src}/libs/numeric/*/include")
    if (NOT EXISTS "${_lg_boost_src}/libs/config/include/boost/version.hpp" OR
        NOT EXISTS "${_lg_boost_src}/libs/icl/include/boost/icl/interval_set.hpp")
        message(FATAL_ERROR "Lobo Gélido: ${LOBOGELIDO_BOOST_URL} does not have the expected "
                            "modular Boost layout (libs/<lib>/include)")
    endif()

    add_library(Boost::boost INTERFACE IMPORTED GLOBAL)
    set_target_properties(Boost::boost PROPERTIES INTERFACE_INCLUDE_DIRECTORIES "${_lg_boost_includes}")
    if (NOT TARGET Boost::headers)
        add_library(Boost::headers ALIAS Boost::boost)
    endif()

    # FindBoost: take this include dir (it reads boost/version.hpp from it), do not look
    # for BoostConfig.cmake or in system paths, and keep our Boost::boost target.
    set(Boost_INCLUDE_DIR "${_lg_boost_src}/libs/config/include" CACHE PATH "" FORCE)
    set(Boost_NO_BOOST_CMAKE ON CACHE BOOL "" FORCE)
    set(Boost_NO_SYSTEM_PATHS ON CACHE BOOL "" FORCE)
    message(STATUS "Lobo Gélido: Boost headers from ${LOBOGELIDO_BOOST_URL}")
endfunction()

# Fetches the pinned Dynarmic (A64 frontend only) and adds its `dynarmic` target.
function(lobogelido_fetch_dynarmic)
    if (TARGET dynarmic)
        return()
    endif()
    string(LENGTH "${LOBOGELIDO_DYNARMIC_COMMIT}" _lg_sha_len)
    if (NOT _lg_sha_len EQUAL 40 OR NOT LOBOGELIDO_DYNARMIC_COMMIT MATCHES "^[0-9a-f]+$")
        message(FATAL_ERROR "LOBOGELIDO_DYNARMIC_COMMIT must be a full 40-hex commit SHA "
                            "(got '${LOBOGELIDO_DYNARMIC_COMMIT}'); branches are not reproducible")
    endif()
    lobogelido_provide_boost_headers()

    set(DYNARMIC_TESTS OFF CACHE BOOL "" FORCE)
    set(DYNARMIC_USE_LLVM OFF CACHE BOOL "" FORCE)
    set(DYNARMIC_WARNINGS_AS_ERRORS OFF CACHE BOOL "" FORCE)
    set(DYNARMIC_FRONTENDS "A64" CACHE STRING "" FORCE)
    # All externals from Dynarmic's own tree (required when cross-compiling).
    set(DYNARMIC_USE_BUNDLED_EXTERNALS ON CACHE BOOL "" FORCE)

    FetchContent_Declare(dynarmic
        GIT_REPOSITORY "${LOBOGELIDO_DYNARMIC_REPOSITORY}"
        GIT_TAG "${LOBOGELIDO_DYNARMIC_COMMIT}"
        # An arbitrary commit cannot be fetched shallowly; the externals are vendored in
        # the tree (no submodules).
        GIT_SHALLOW FALSE
        GIT_PROGRESS TRUE)
    FetchContent_MakeAvailable(dynarmic)
    message(STATUS "Lobo Gélido: Dynarmic ${LOBOGELIDO_DYNARMIC_COMMIT} from ${LOBOGELIDO_DYNARMIC_REPOSITORY}")
endfunction()
