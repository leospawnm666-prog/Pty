# Avance de capas (post-max) — Lobo Gélido vs Eden

## Estimación de madurez tras este paquete

| Capa | Antes | Ahora (código) | Eden (ref.) | Nota |
|------|-------|----------------|-------------|------|
| Shaders / pipelines | ~30 % | **~55–65 %** | ~90 % | Async + disco + prioridad + diagnósticos |
| Audio jugable | ~35–45 % | **~55–65 %** | ~90 % | AudOut ampliado + volumen + registro sm |
| Keys + firmware UI | ~75–85 % | **~90–95 %** | ~95 % | Conteo entradas + revalidar + gate boot |
| Loader NSP/XCI/NCA | ~45–55 % | **~60–70 %** | ~95 % | format_name + inspect_summary |
| Input táctil/mando | ~50–60 % | **~75–85 %** | ~90–95 % | InputMapper + deadzone + pad físico |
| UI / shell Android | ~70–80 % | **~85–90 %** | ~75–85 % | Gate real + crystal + cableado ajustes |

**Global estimado Lobo: ~48–55 %** (sube desde ~38–45 %).  
**Eden global: ~88–92 %.**  
Aún **no** supera a Eden en emulación real; **sí** se acerca o supera en **shell UI** y **import keys/firmware UX**.

## Honestidad técnica
- Superar a Eden en shaders/audio/loader requiere años de HLE por título.
- Este paquete maximiza la **infraestructura** de cada capa, no la paridad de catálogo.
