#pragma once
// P4.1 (P4_DISENO.md §4, §7): Maxwell (Tegra X1) shader -> SPIR-V. Pure: no global state, no
// Vulkan; safe to call from several threads at once.
// P4.2 (P4_2_DISENO.md): the graphics stages (VS, TCS, TES, GS, FS).
// P4.3 (P4_3_DISENO.md): textures and images.
#include <array>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace lg::shader {

enum class Stage : uint32_t { Compute = 0, Vertex, TessControl, TessEval, Geometry, Fragment };

/** Component type of a vertex attribute, a varying or a render target. */
enum class AttribType : uint8_t { Float = 0, Sint, Uint };

/** The Shader Program Header of the graphics stages (20 words before the code; NVIDIA
 *  open-gpu-doc "Shader Program Header"), with the fields the recompiler uses. */
struct Sph {
    uint32_t sph_type{0};           // 1 VTG, 2 PS
    uint32_t shader_type{0};        // 1 VS, 2 TCS, 3 TES, 4 GS, 5 PS
    bool kills_pixels{false};
    uint32_t local_mem_bytes{0};    // ShaderLocalMemoryLowSize
    uint32_t per_patch_attribs{0};
    uint32_t threads_per_input_primitive{0};   // TCS: output vertices; GS: invocations
    uint32_t output_topology{0};    // GS: 1 points, 6 line strip, 7 triangle strip
    uint32_t max_output_vertices{0};
    // VTG: one bit per generic component (32 generics x 4), inputs and outputs
    std::array<uint32_t, 4> vtg_imap_generic{};
    std::array<uint32_t, 4> vtg_omap_generic{};
    uint32_t imap_sysvals_ab{0}, omap_sysvals_ab{0};
    uint32_t imap_sysvals_c{0}, omap_sysvals_c{0};
    // PS: two bits per generic component (0 unused, 1 constant, 2 perspective, 3 screen linear)
    std::array<uint8_t, 32> ps_imap_generic{};
    uint32_t ps_omap_target{0};     // 4 bits per render target (8 targets)
    bool ps_omap_sample_mask{false};
    bool ps_omap_depth{false};
};
/** Parses the 20 SPH words; false if the type fields make no sense. */
bool parse_sph(std::span<const uint32_t> words, Sph& out);

/** Pipeline state the SPH does not carry (in the hardware it lives in GPU registers; P5 fills
 *  it from the guest's state). */
struct GraphicsState {
    std::array<AttribType, 32> vertex_attrib_types{};   // VS inputs by location
    std::array<AttribType, 32> varying_types{};         // generic varyings by location (both sides)
    std::array<AttribType, 8> render_target_types{};    // FS outputs
    bool instance_id_includes_base{false};             // a[0x2f8]: InstanceIndex (true) or minus BaseInstance
    uint32_t patch_input_vertices{32};                 // TCS/TES per-vertex input array size
    enum class TessDomain : uint8_t { Triangles, Quads, Isolines } tess_domain{TessDomain::Triangles};
    enum class TessSpacing : uint8_t { Equal, FractionalEven, FractionalOdd } tess_spacing{TessSpacing::Equal};
    bool tess_ccw{true};
    bool tess_point_mode{false};
    enum class GsInput : uint8_t { Points, Lines, LinesAdjacency, Triangles, TrianglesAdjacency } gs_input{GsInput::Triangles};
};

/** A table of 64-bit buffer addresses in a constant buffer (NVN/deko3d driver constant buffer).
 *  Entry i is at c[cbuf_bank][offset + i * stride]: u64 address, then (if size_offset != kNoSize)
 *  a u32 size at +size_offset; tables without sizes use fixed_size. Global memory accesses whose
 *  address falls inside entry i's buffer go to the storage buffer at binding first_binding + i. */
struct GlobalBufferTable {
    static constexpr uint32_t kNoSize = ~0u;
    uint32_t cbuf_bank{0};
    uint32_t offset{0x140};
    uint32_t stride{16};
    uint32_t count{16};
    uint32_t size_offset{8};
    uint32_t fixed_size{0x10000};
    uint32_t first_binding{16};
};

/** deko3d (uam) compute layout of the driver constant buffer c0: storage buffers at 0x140
 *  (u64 address, u32 size; stride 16) and uniform buffers 6+ at 0x20 (u64 address; stride 8). */
inline std::vector<GlobalBufferTable> deko3d_compute_tables(uint32_t ssbo_first_binding, uint32_t ubo_first_binding) {
    return {GlobalBufferTable{0, 0x140, 16, 16, 8, 0x10000, ssbo_first_binding},
            GlobalBufferTable{0, 0x20, 8, 16, GlobalBufferTable::kNoSize, 0x10000, ubo_first_binding}};
}

struct CbufBinding { uint32_t bank; uint32_t binding; };

/** P4.3 (P4_3_DISENO.md D-P4.3-1/5): what the instruction does not say about a bound texture or
 *  image, by the cbuf word of its handle (in P5: from the TIC format). Absent: float, unknown format. */
enum class ImageFormat : uint8_t { Unknown = 0, Rgba32f, Rgba16f, R32f, Rgba8, Rgba8Snorm, Rg32f, Rg16f, R16f,
                                   Rgba32i, Rgba16i, Rgba8i, R32i, Rgba32ui, Rgba16ui, Rgba8ui, R32ui, Rg32ui };
struct TextureState {
    uint32_t cbuf_bank{0};
    uint32_t offset{0};            // byte offset of the 32-bit handle in the bank
    AttribType type{AttribType::Float};
    bool buffer{false};            // P4.4: a texel buffer (samplerBuffer; TLD and TXQ)
};
struct ImageState {
    uint32_t cbuf_bank{0};
    uint32_t offset{0};
    ImageFormat format{ImageFormat::Unknown};   // formatted access (SULD.P/SUST.P)
    AttribType type{AttribType::Float};         // with an unknown format
};

struct ShaderInfo {
    Stage stage{Stage::Compute};
    uint32_t local_size[3]{1, 1, 1};
    uint32_t shared_memory_bytes{0};
    uint32_t local_memory_bytes{0};
    std::vector<CbufBinding> cbufs;      // constant buffer bank -> binding (set `descriptor_set`)
    std::vector<GlobalBufferTable> global_tables{deko3d_compute_tables(16, 48)};
    uint32_t descriptor_set{0};
    // graphics stages (P4.2): the program's SPH and the pipeline state it lacks
    std::array<uint32_t, 20> sph{};
    GraphicsState graphics;
    // textures and images (P4.3): the cbuf bank of the bound handles, per-handle state, and the
    // first binding of the descriptors (one per handle and use, in order of first use)
    uint32_t texture_bank{0};
    std::vector<TextureState> textures;
    std::vector<ImageState> images;
    uint32_t texture_first_binding{64};
    // P4.4 (P4_4_DISENO.md D-P4.4-2): double precision. Native needs the device's shaderFloat64;
    // Lossy32 computes in f32 (precision and range of f32) for devices without it.
    enum class Fp64Mode : uint8_t { Native, Lossy32 };
    Fp64Mode fp64{Fp64Mode::Native};
    /** When true, body opcodes without a SPIR-V path become NOP + warning instead of hard fail.
     *  Raises playable-shader hit rate on commercial titles at the cost of visual correctness. */
    bool soft_unknown_as_nop{true};
    /** When true, undecodable instruction words are replaced by a decoded NOP (warn) instead of abort. */
    bool soft_undecodable_as_skip{true};
    // P4.4 (D-P4.4-10): general bindless. When a texture or image handle cannot be traced to a
    // constant buffer word, it is resolved at run time in descriptor arrays indexed by the TIC
    // (handle bits 0-19) and the TSC (bits 20-31); absent (count 0): the explicit error of P4.3.
    struct BindlessTables {
        uint32_t texture_binding{0};    // sampled images (one array per image type, aliased)
        uint32_t sampler_binding{0};    // samplers
        uint32_t image_binding{0};      // storage images
        uint32_t tic_count{0};          // array lengths (0: disabled)
        uint32_t tsc_count{0};
    } bindless;
    // P4.4: 64-bit image atomics need the device's shaderImageInt64Atomics
    bool image_int64_atomics{false};
    // P4.4: 64-bit ATOM/RED (global) and ATOMS (shared) need shaderBufferInt64Atomics and
    // shaderSharedInt64Atomics (Vulkan 1.2 / VK_KHR_shader_atomic_int64); absent: explicit error
    bool int64_atomics{false};
};

struct ResourceUse {
    enum class Kind : uint32_t { ConstantBuffer, StorageBuffer, Texture, Image } kind;
    uint32_t binding;
    uint32_t index;   // cbuf bank (also of a texture/image handle), or entry index in its global buffer table
    uint32_t table{0};   // StorageBuffer: index in ShaderInfo::global_tables
    // P4.3, Texture (combined image sampler) and Image (storage image): the handle is at
    // c[index][offset]; the SPIR-V image type the descriptor must match
    enum class Access : uint8_t { Sampled, Formatted, Raw, Atomic };
    uint32_t offset{0};
    uint32_t dim{1};              // SPIR-V Dim: 0 1D, 1 2D, 2 3D, 3 cube
    bool arrayed{false};
    bool shadow{false};
    bool multisample{false};
    AttribType type{AttribType::Float};
    Access access{Access::Sampled};
    uint32_t raw_bytes{0};        // Raw: bytes per texel of the access (the view P5 creates: R8ui..RGBA32ui)
    ImageFormat format{ImageFormat::Unknown};
};

struct TranslationResult {
    bool ok{false};
    std::string error;                    // first error (instruction address + reason)
    std::vector<uint32_t> spirv;
    std::vector<ResourceUse> resources;
    std::vector<std::string> warnings;
    uint32_t instructions{0};             // decoded (non-scheduling) instructions
    uint32_t soft_skipped{0};             // body opcodes emitted as NOP under soft_unknown_as_nop
    uint32_t undecoded_soft{0};           // words forced to NOP under soft_undecodable_as_skip
};

/** `code`: the program's 64-bit words from its first scheduling word (byte 0); for the graphics
 *  stages the code that follows the SPH (which goes in `info.sph`). */
TranslationResult translate(std::span<const uint64_t> code, const ShaderInfo& info);

/** Static ISA vs emit_body dispatch surface (mnemonics only; not semantic correctness). */
struct CoverageReport {
    uint32_t isa_encodings{0};
    uint32_t isa_unique_mnemonics{0};
    uint32_t translator_body_mnemonics{0};
    std::string summary;   // one-line diagnostics for logs/UI
};
CoverageReport coverage_report() noexcept;

} // namespace lg::shader
