#include "isa.h"

namespace lg::shader::maxwell {
namespace {
constexpr Encoding kTable[] = {
#include "isa_table.inc"
};
} // namespace

bool Encoding::has(std::string_view token) const noexcept {
    const std::string_view ops(operands);
    for (size_t pos = ops.find(token); pos != std::string_view::npos; pos = ops.find(token, pos + 1)) {
        const bool start_ok = pos == 0 || ops[pos - 1] == ' ' || ops[pos - 1] == ',';
        const size_t end = pos + token.size();
        const bool end_ok = end == ops.size() || ops[end] == ',' || ops[end] == ' ';
        if (start_ok && end_ok) return true;
    }
    return false;
}

std::span<const Encoding> encodings() noexcept { return {kTable, sizeof kTable / sizeof kTable[0]}; }

const Encoding* find_encoding(uint64_t word) noexcept {
    for (const auto& e : kTable)
        if ((word & e.mask) == e.value) return &e;
    return nullptr;
}

size_t encoding_index(const Encoding* e) noexcept { return static_cast<size_t>(e - kTable); }

} // namespace lg::shader::maxwell
