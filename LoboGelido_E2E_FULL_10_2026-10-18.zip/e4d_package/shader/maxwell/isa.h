#pragma once
// P4.1 (P4_DISENO.md §4): the Maxwell (GM107/GM20B, Tegra X1) instruction encodings.
// The table is generated from envytools' opcode table (MIT; see ENVYTOOLS_LICENSE) by
// tools/gpu_toolchain/gen_maxwell_isa.py. Decoding = first row whose (word & mask) == value.
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace lg::shader::maxwell {

struct Encoding {
    uint64_t value;
    uint64_t mask;
    const char* mnemonic;   // envydis' name ("fadd", "iadd32i", ...)
    const char* operands;   // envydis' operand tokens, e.g. "REG_00, REG_08, C34_RZ_O14_20"
    int min_sm;             // 0: every Maxwell; 60: marked Pascal-only by envytools
    bool predicated;        // has the guard predicate (bits 16..19); PBK/SSY/PCNT/CAL... do not
    /** True when `token` appears among the operand tokens (whole token match). */
    bool has(std::string_view token) const noexcept;
};

/** Every encoding, in matching order (296 rows). */
std::span<const Encoding> encodings() noexcept;
/** The encoding of an instruction word, or nullptr (unknown word).
 *  Callers that must keep translating commercial shaders may substitute a NOP
 *  when ShaderInfo::soft_undecodable_as_skip is set (see translate.h). */
const Encoding* find_encoding(uint64_t word) noexcept;
/** Index of `e` in encodings() (for coverage counts). */
size_t encoding_index(const Encoding* e) noexcept;

/** Bits [pos, pos + len) of a word. */
constexpr uint64_t bits(uint64_t w, unsigned pos, unsigned len) noexcept {
    return len >= 64 ? (w >> pos) : ((w >> pos) & ((uint64_t{1} << len) - 1));
}
constexpr bool bit(uint64_t w, unsigned pos) noexcept { return (w >> pos) & 1; }

/** Every 4th 64-bit word of a Maxwell program (index % 4 == 0) is a scheduling word. */
constexpr bool is_sched_slot(size_t word_index) noexcept { return (word_index & 3) == 0; }

} // namespace lg::shader::maxwell
