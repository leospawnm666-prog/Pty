#pragma once
// P4.1: a small SPIR-V 1.3 module builder (own code; opcode numbers from the public SPIR-V
// specification). Types and constants are deduplicated; instructions go to the current block.
#include <cstdint>
#include <map>
#include <string>
#include <tuple>
#include <vector>

namespace lg::shader::spirv {

using Id = uint32_t;

namespace op {   // the opcodes used by the recompiler (SPIR-V spec, section 3.42)
enum : uint16_t {
    Nop = 0, Name = 5, Extension = 10, ExtInstImport = 11, ExtInst = 12, MemoryModel = 14, EntryPoint = 15,
    ExecutionMode = 16, Capability = 17, TypeVoid = 19, TypeBool = 20, TypeInt = 21, TypeFloat = 22, TypeVector = 23,
    TypeArray = 28, TypeRuntimeArray = 29, TypeStruct = 30, TypePointer = 32, TypeFunction = 33,
    ConstantTrue = 41, ConstantFalse = 42, Constant = 43, ConstantComposite = 44,
    Function = 54, FunctionParameter = 55, FunctionEnd = 56, FunctionCall = 57, Variable = 59, Load = 61, Store = 62, AccessChain = 65,
    Decorate = 71, MemberDecorate = 72, VectorExtractDynamic = 77, CompositeConstruct = 80, CompositeExtract = 81, ConvertFToU = 109, ConvertFToS = 110,
    ConvertSToF = 111, ConvertUToF = 112, UConvert = 113, SConvert = 114, FConvert = 115, Bitcast = 124,
    SNegate = 126, FNegate = 127, IAdd = 128, FAdd = 129, ISub = 130, FSub = 131, IMul = 132, FMul = 133,
    UDiv = 134, SDiv = 135, FDiv = 136, UMod = 137, IsNan = 156, IsInf = 157, LogicalEqual = 164,
    LogicalNotEqual = 165, LogicalOr = 166, LogicalAnd = 167, LogicalNot = 168, Select = 169, IEqual = 170,
    INotEqual = 171, UGreaterThan = 172, SGreaterThan = 173, UGreaterThanEqual = 174, SGreaterThanEqual = 175,
    ULessThan = 176, SLessThan = 177, ULessThanEqual = 178, SLessThanEqual = 179, FOrdEqual = 180,
    FUnordEqual = 181, FOrdNotEqual = 182, FUnordNotEqual = 183, FOrdLessThan = 184, FUnordLessThan = 185,
    FOrdGreaterThan = 186, FUnordGreaterThan = 187, FOrdLessThanEqual = 188, FUnordLessThanEqual = 189,
    FOrdGreaterThanEqual = 190, FUnordGreaterThanEqual = 191, ShiftRightLogical = 194,
    ShiftRightArithmetic = 195, ShiftLeftLogical = 196, BitwiseOr = 197, BitwiseXor = 198, BitwiseAnd = 199,
    Not = 200, BitFieldInsert = 201, BitFieldSExtract = 202, BitFieldUExtract = 203, BitReverse = 204,
    BitCount = 205, ControlBarrier = 224, MemoryBarrier = 225, AtomicExchange = 229,
    AtomicCompareExchange = 230, AtomicIAdd = 234, AtomicSMin = 236, AtomicUMin = 237, AtomicSMax = 238,
    AtomicUMax = 239, AtomicAnd = 240, AtomicOr = 241, AtomicXor = 242, Phi = 245, LoopMerge = 246,
    SelectionMerge = 247, Label = 248, Branch = 249, BranchConditional = 250, Switch = 251, Kill = 252,
    Return = 253, ReturnValue = 254, EmitVertex = 218, EndPrimitive = 219, GroupNonUniformQuadBroadcast = 365,
    // P4.3: images and sampling
    TypeImage = 25, TypeSampler = 26, TypeSampledImage = 27, SampledImage = 86, ImageSampleImplicitLod = 87,
    ImageSampleExplicitLod = 88, ImageSampleDrefImplicitLod = 89, ImageSampleDrefExplicitLod = 90, ImageFetch = 95,
    ImageGather = 96, ImageDrefGather = 97, ImageRead = 98, ImageWrite = 99, Image = 100, ImageQuerySizeLod = 103,
    ImageQuerySize = 104, ImageQueryLod = 105, ImageQueryLevels = 106, ImageTexelPointer = 60, AtomicIIncrement = 232,
    AtomicIDecrement = 233, Unreachable = 255, AtomicLoad = 227, AtomicStore = 228, IAddCarry = 149, ISubBorrow = 150, UMulExtended = 151, SMulExtended = 152,
    // P4.4: subgroup votes and ballots, texel buffers
    GroupNonUniformElect = 333, GroupNonUniformAll = 334, GroupNonUniformAny = 335, GroupNonUniformAllEqual = 336,
    GroupNonUniformBroadcast = 337, GroupNonUniformBallot = 339, ImageQuerySamples = 107, AtomicFAddEXT = 6035,
    GroupNonUniformShuffle = 345,
};
}
namespace glsl {   // GLSL.std.450 extended instructions
enum : uint32_t {
    Round = 1, RoundEven = 2, Trunc = 3, FAbs = 4, SAbs = 5, FSign = 6, Floor = 8, Ceil = 9, Fract = 10, Sin = 13, Cos = 14,
    Exp2 = 29, Log2 = 30, Sqrt = 31, InverseSqrt = 32, FMin = 37, UMin = 38, SMin = 39, FMax = 40, UMax = 41,
    SMax = 42, FClamp = 43, Fma = 50, PackHalf2x16 = 58, UnpackHalf2x16 = 62, FindILsb = 73, FindSMsb = 74, FindUMsb = 75, NMin = 79, NMax = 80,
    Ldexp = 53, PackDouble2x32 = 59, UnpackDouble2x32 = 60, InterpolateAtOffset = 78,
};
}

class Builder {
public:
    Builder();

    Id id() noexcept { return next_id_++; }
    // ---- module level ----
    void capability(uint32_t cap);
    void extension(const std::string& name);   // P4.4: OpExtension (deduplicated)
    Id glsl_std();
    void memory_model(uint32_t addressing, uint32_t model);
    void entry_point(uint32_t model, Id fn, const char* name, const std::vector<Id>& interface);
    void execution_mode(Id fn, uint32_t mode, const std::vector<uint32_t>& args);
    void name(Id target, const std::string& n);
    void decorate(Id target, uint32_t decoration, const std::vector<uint32_t>& args = {});
    void member_decorate(Id type, uint32_t member, uint32_t decoration, const std::vector<uint32_t>& args = {});
    // ---- types (deduplicated) ----
    Id t_void();
    Id t_bool();
    Id t_int(uint32_t width, bool is_signed);
    Id t_u32() { return t_int(32, false); }
    Id t_s32() { return t_int(32, true); }
    Id t_f32();
    Id t_f64();   // P4.4 (the caller declares the Float64 capability)
    Id t_vec(Id component, uint32_t count);
    Id t_array(Id element, uint32_t length);   // not deduplicated by stride decoration: callers decorate
    Id t_runtime_array(Id element);            // a new type each call (it gets its own ArrayStride)
    Id t_struct(const std::vector<Id>& members);   // a new type each call (decorations differ)
    Id t_ptr(uint32_t storage, Id pointee);
    Id t_fn(Id ret, const std::vector<Id>& params);
    // P4.3: OpTypeImage (dim, depth, arrayed, ms, sampled 1/2, format) and OpTypeSampledImage
    Id t_image(Id sampled_type, uint32_t dim, uint32_t depth, uint32_t arrayed, uint32_t ms, uint32_t sampled, uint32_t format);
    Id t_sampled_image(Id image);
    Id t_sampler();   // P4.4: OpTypeSampler
    // ---- constants (deduplicated) ----
    Id c_u32(uint32_t v);
    Id c_s32(int32_t v) { return c_u32(static_cast<uint32_t>(v)); }   // the same 32-bit pattern, typed u32
    Id c_f32(float v);
    Id c_f64(double v);   // P4.4
    Id c_bool(bool v);
    /** P4.3: a 32-bit constant of any scalar type (e.g. signed int), and a constant composite. */
    Id c_typed(Id type, uint32_t bits);
    Id c_u64(uint64_t v);   // P4.4: a 64-bit unsigned constant (two literal words)
    Id c_composite(Id type, const std::vector<Id>& parts);
    // ---- globals ----
    Id global_var(Id ptr_type, uint32_t storage);
    // ---- functions and blocks ----
    Id begin_function(Id ret, Id fn_type);
    /** Starts a function whose result id was reserved earlier with id() (forward calls). */
    void begin_function_with_id(Id fn, Id ret, Id fn_type);
    Id param(Id type);   // OpFunctionParameter: after begin_function, before the first label
    void end_function();
    Id new_label() { return id(); }
    void label(Id l);
    Id local_var(Id ptr_type);   // goes to the function's first block
    Id local_var(Id ptr_type, Id initializer);
    Id global_var(Id ptr_type, uint32_t storage, Id initializer);
    /** Emits `opcode` with a result type and a new result id; returns the id. */
    Id emit(uint16_t opcode, Id type, const std::vector<uint32_t>& operands);
    /** Emits `opcode` without a result. */
    void emit_void(uint16_t opcode, const std::vector<uint32_t>& operands);
    Id ext(Id type, uint32_t inst, const std::vector<Id>& args);
    bool block_open() const noexcept { return block_open_; }

    std::vector<uint32_t> finish() const;

private:
    static void put(std::vector<uint32_t>& out, uint16_t opcode, const std::vector<uint32_t>& operands);
    static void put_string(std::vector<uint32_t>& out, const std::string& s);
    std::vector<uint32_t> caps_, exts_, imports_, memmodel_, entries_, modes_, names_, decos_, types_, body_;
    std::vector<uint32_t> fn_header_, fn_vars_, fn_blocks_;
    Id next_id_{1};
    Id glsl_{0};
    bool block_open_{false};
    bool first_block_{true};
    std::map<std::vector<uint32_t>, Id> type_cache_;
    std::map<std::pair<Id, uint32_t>, Id> const_cache_;
    Id true_{0}, false_{0};
};

// Enumerants used by the recompiler (SPIR-V spec, section 3).
namespace storage { enum : uint32_t { UniformConstant = 0, Input = 1, Uniform = 2, Output = 3, Workgroup = 4,
    Private = 6, Function = 7, PushConstant = 9, Image = 11, StorageBuffer = 12 }; }
namespace deco { enum : uint32_t { Block = 2, BufferBlock = 3, ArrayStride = 6, BuiltIn = 11, NoPerspective = 13,
    Flat = 14, Patch = 15, Centroid = 16, NonWritable = 24, Location = 30, Component = 31, Binding = 33,
    DescriptorSet = 34, Offset = 35 }; }
namespace builtin { enum : uint32_t { Position = 0, PointSize = 1, ClipDistance = 3, PrimitiveId = 7,
    InvocationId = 8, Layer = 9, ViewportIndex = 10, TessLevelOuter = 11, TessLevelInner = 12, TessCoord = 13,
    FragCoord = 15, PointCoord = 16, FrontFacing = 17, SampleMask = 20, FragDepth = 22, NumWorkgroups = 24,
    WorkgroupSize = 25, WorkgroupId = 26, LocalInvocationId = 27, GlobalInvocationId = 28, LocalInvocationIndex = 29,
    SubgroupLocalInvocationId = 41, VertexIndex = 42, InstanceIndex = 43, BaseInstance = 4425 }; }
// P4.3: image enumerants (SPIR-V spec 3.8 Dim, 3.11 Image Format, 3.14 Image Operands)
namespace dim { enum : uint32_t { D1 = 0, D2 = 1, D3 = 2, Cube = 3, Buffer = 5 }; }
namespace imgop { enum : uint32_t { Bias = 0x1, Lod = 0x2, Grad = 0x4, ConstOffset = 0x8, Offset = 0x10,
    ConstOffsets = 0x20, Sample = 0x40 }; }
namespace imgfmt { enum : uint32_t { Unknown = 0, Rgba32f = 1, Rgba16f = 2, R32f = 3, Rgba8 = 4, Rgba8Snorm = 5,
    Rg32f = 6, Rg16f = 7, R16f = 9, Rgba16 = 10, Rg8 = 13, R8 = 15, Rgba32i = 21, Rgba16i = 22, Rgba8i = 23, R32i = 24,
    Rg32i = 25, Rgba32ui = 30, Rgba16ui = 31, Rgba8ui = 32, R32ui = 33, Rg32ui = 35, R16ui = 38, R8ui = 39 }; }
namespace scope { enum : uint32_t { Device = 1, Workgroup = 2, Subgroup = 3, Invocation = 4 }; }
namespace semantics { enum : uint32_t { None = 0, AcquireRelease = 0x8, UniformMemory = 0x40,
    WorkgroupMemory = 0x100 }; }

} // namespace lg::shader::spirv
