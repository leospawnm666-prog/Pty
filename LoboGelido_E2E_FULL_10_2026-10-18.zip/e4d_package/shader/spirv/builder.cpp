#include "builder.h"

#include <cstring>

namespace lg::shader::spirv {

Builder::Builder() = default;

void Builder::put(std::vector<uint32_t>& out, uint16_t opcode, const std::vector<uint32_t>& operands) {
    out.push_back((static_cast<uint32_t>(operands.size() + 1) << 16) | opcode);
    out.insert(out.end(), operands.begin(), operands.end());
}

void Builder::put_string(std::vector<uint32_t>& out, const std::string& s) {
    const size_t words = s.size() / 4 + 1;
    const size_t at = out.size();
    out.resize(at + words, 0);
    std::memcpy(out.data() + at, s.data(), s.size());
}

void Builder::capability(uint32_t cap) {
    for (size_t i = 0; i < caps_.size(); i += 2)
        if (caps_[i + 1] == cap) return;
    put(caps_, op::Capability, {cap});
}

void Builder::extension(const std::string& name) {
    std::vector<uint32_t> w;
    put_string(w, name);
    for (size_t i = 0; i < exts_.size();) {
        const uint32_t wc = exts_[i] >> 16;
        if (std::vector<uint32_t>(exts_.begin() + static_cast<long>(i) + 1, exts_.begin() + static_cast<long>(i + wc)) == w) return;
        i += wc;
    }
    put(exts_, op::Extension, w);
}

Id Builder::glsl_std() {
    if (glsl_) return glsl_;
    glsl_ = id();
    std::vector<uint32_t> ops{glsl_};
    put_string(ops, "GLSL.std.450");
    put(imports_, op::ExtInstImport, ops);
    return glsl_;
}

void Builder::memory_model(uint32_t addressing, uint32_t model) { put(memmodel_, op::MemoryModel, {addressing, model}); }

void Builder::entry_point(uint32_t model, Id fn, const char* name, const std::vector<Id>& interface) {
    std::vector<uint32_t> ops{model, fn};
    put_string(ops, name);
    ops.insert(ops.end(), interface.begin(), interface.end());
    put(entries_, op::EntryPoint, ops);
}

void Builder::execution_mode(Id fn, uint32_t mode, const std::vector<uint32_t>& args) {
    std::vector<uint32_t> ops{fn, mode};
    ops.insert(ops.end(), args.begin(), args.end());
    put(modes_, op::ExecutionMode, ops);
}

void Builder::name(Id target, const std::string& n) {
    std::vector<uint32_t> ops{target};
    put_string(ops, n);
    put(names_, op::Name, ops);
}

void Builder::decorate(Id target, uint32_t decoration, const std::vector<uint32_t>& args) {
    std::vector<uint32_t> ops{target, decoration};
    ops.insert(ops.end(), args.begin(), args.end());
    put(decos_, op::Decorate, ops);
}

void Builder::member_decorate(Id type, uint32_t member, uint32_t decoration, const std::vector<uint32_t>& args) {
    std::vector<uint32_t> ops{type, member, decoration};
    ops.insert(ops.end(), args.begin(), args.end());
    put(decos_, op::MemberDecorate, ops);
}

namespace {
template <class F> Id cached(std::map<std::vector<uint32_t>, Id>& cache, std::vector<uint32_t> key, F make) {
    auto it = cache.find(key);
    if (it != cache.end()) return it->second;
    const Id r = make();
    cache.emplace(std::move(key), r);
    return r;
}
} // namespace

Id Builder::t_void() {
    return cached(type_cache_, {op::TypeVoid}, [&] { Id r = id(); put(types_, op::TypeVoid, {r}); return r; });
}
Id Builder::t_bool() {
    return cached(type_cache_, {op::TypeBool}, [&] { Id r = id(); put(types_, op::TypeBool, {r}); return r; });
}
Id Builder::t_int(uint32_t width, bool is_signed) {
    return cached(type_cache_, {op::TypeInt, width, is_signed ? 1u : 0u}, [&] {
        Id r = id(); put(types_, op::TypeInt, {r, width, is_signed ? 1u : 0u}); return r; });
}
Id Builder::t_f32() {
    return cached(type_cache_, {op::TypeFloat, 32}, [&] { Id r = id(); put(types_, op::TypeFloat, {r, 32}); return r; });
}
Id Builder::t_f64() {
    return cached(type_cache_, {op::TypeFloat, 64}, [&] { Id r = id(); put(types_, op::TypeFloat, {r, 64}); return r; });
}
Id Builder::t_vec(Id component, uint32_t count) {
    return cached(type_cache_, {op::TypeVector, component, count}, [&] {
        Id r = id(); put(types_, op::TypeVector, {r, component, count}); return r; });
}
Id Builder::t_array(Id element, uint32_t length) {
    const Id len = c_u32(length);
    Id r = id();
    put(types_, op::TypeArray, {r, element, len});
    return r;
}
Id Builder::t_runtime_array(Id element) {
    Id r = id();
    put(types_, op::TypeRuntimeArray, {r, element});
    return r;
}
Id Builder::t_struct(const std::vector<Id>& members) {
    Id r = id();
    std::vector<uint32_t> ops{r};
    ops.insert(ops.end(), members.begin(), members.end());
    put(types_, op::TypeStruct, ops);
    return r;
}
Id Builder::t_ptr(uint32_t storage_class, Id pointee) {
    return cached(type_cache_, {op::TypePointer, storage_class, pointee}, [&] {
        Id r = id(); put(types_, op::TypePointer, {r, storage_class, pointee}); return r; });
}
Id Builder::t_image(Id sampled_type, uint32_t dim, uint32_t depth, uint32_t arrayed, uint32_t ms, uint32_t sampled,
                    uint32_t format) {
    return cached(type_cache_, {op::TypeImage, sampled_type, dim, depth, arrayed, ms, sampled, format}, [&] {
        Id r = id();
        put(types_, op::TypeImage, {r, sampled_type, dim, depth, arrayed, ms, sampled, format});
        return r;
    });
}
Id Builder::t_sampled_image(Id image) {
    return cached(type_cache_, {op::TypeSampledImage, image}, [&] {
        Id r = id(); put(types_, op::TypeSampledImage, {r, image}); return r; });
}
Id Builder::t_sampler() {
    return cached(type_cache_, {op::TypeSampler}, [&] { Id r = id(); put(types_, op::TypeSampler, {r}); return r; });
}
Id Builder::t_fn(Id ret, const std::vector<Id>& params) {
    std::vector<uint32_t> key{op::TypeFunction, ret};
    key.insert(key.end(), params.begin(), params.end());
    return cached(type_cache_, key, [&] {
        Id r = id();
        std::vector<uint32_t> ops{r, ret};
        ops.insert(ops.end(), params.begin(), params.end());
        put(types_, op::TypeFunction, ops);
        return r;
    });
}

Id Builder::c_u32(uint32_t v) {
    const Id t = t_u32();
    auto it = const_cache_.find({t, v});
    if (it != const_cache_.end()) return it->second;
    Id r = id();
    put(types_, op::Constant, {t, r, v});
    const_cache_.emplace(std::make_pair(t, v), r);
    return r;
}
Id Builder::c_typed(Id t, uint32_t v) {
    auto it = const_cache_.find({t, v});
    if (it != const_cache_.end()) return it->second;
    Id r = id();
    put(types_, op::Constant, {t, r, v});
    const_cache_.emplace(std::make_pair(t, v), r);
    return r;
}
Id Builder::c_composite(Id t, const std::vector<Id>& parts) {
    std::vector<uint32_t> key{op::ConstantComposite, t};
    key.insert(key.end(), parts.begin(), parts.end());
    return cached(type_cache_, key, [&] {
        Id r = id();
        std::vector<uint32_t> ops{t, r};
        ops.insert(ops.end(), parts.begin(), parts.end());
        put(types_, op::ConstantComposite, ops);
        return r;
    });
}
Id Builder::c_f32(float v) {
    const Id t = t_f32();
    uint32_t bitsv;
    std::memcpy(&bitsv, &v, 4);
    auto it = const_cache_.find({t, bitsv});
    if (it != const_cache_.end()) return it->second;
    Id r = id();
    put(types_, op::Constant, {t, r, bitsv});
    const_cache_.emplace(std::make_pair(t, bitsv), r);
    return r;
}
Id Builder::c_u64(uint64_t v) {
    const Id t = t_int(64, false);
    const uint32_t lo = static_cast<uint32_t>(v), hi = static_cast<uint32_t>(v >> 32);
    return cached(type_cache_, {op::Constant, t, lo, hi}, [&] {
        Id r = id();
        put(types_, op::Constant, {t, r, lo, hi});
        return r;
    });
}
Id Builder::c_f64(double v) {
    const Id t = t_f64();
    uint64_t bitsv;
    std::memcpy(&bitsv, &v, 8);
    const uint32_t lo = static_cast<uint32_t>(bitsv), hi = static_cast<uint32_t>(bitsv >> 32);
    return cached(type_cache_, {op::Constant, t, lo, hi}, [&] {
        Id r = id();
        put(types_, op::Constant, {t, r, lo, hi});
        return r;
    });
}
Id Builder::c_bool(bool v) {
    Id& slot = v ? true_ : false_;
    if (!slot) {
        slot = id();
        put(types_, v ? op::ConstantTrue : op::ConstantFalse, {t_bool(), slot});
    }
    return slot;
}

Id Builder::global_var(Id ptr_type, uint32_t storage_class) {
    Id r = id();
    put(types_, op::Variable, {ptr_type, r, storage_class});
    return r;
}

Id Builder::begin_function(Id ret, Id fn_type) {
    Id f = id();
    fn_header_.clear(); fn_vars_.clear(); fn_blocks_.clear();
    put(fn_header_, op::Function, {ret, f, 0, fn_type});
    first_block_ = true;
    return f;
}

void Builder::begin_function_with_id(Id f, Id ret, Id fn_type) {
    fn_header_.clear(); fn_vars_.clear(); fn_blocks_.clear();
    put(fn_header_, op::Function, {ret, f, 0, fn_type});
    first_block_ = true;
}

Id Builder::param(Id type) {
    Id r = id();
    put(fn_header_, op::FunctionParameter, {type, r});
    return r;
}

void Builder::end_function() {
    // The first block's label is in fn_header_; its OpVariables must come right after it.
    body_.insert(body_.end(), fn_header_.begin(), fn_header_.end());
    body_.insert(body_.end(), fn_vars_.begin(), fn_vars_.end());
    body_.insert(body_.end(), fn_blocks_.begin(), fn_blocks_.end());
    put(body_, op::FunctionEnd, {});
    block_open_ = false;
}

void Builder::label(Id l) {
    if (first_block_) { put(fn_header_, op::Label, {l}); first_block_ = false; }
    else put(fn_blocks_, op::Label, {l});
    block_open_ = true;
}

Id Builder::local_var(Id ptr_type) {
    Id r = id();
    put(fn_vars_, op::Variable, {ptr_type, r, storage::Function});
    return r;
}

Id Builder::local_var(Id ptr_type, Id initializer) {
    Id r = id();
    put(fn_vars_, op::Variable, {ptr_type, r, storage::Function, initializer});
    return r;
}

Id Builder::global_var(Id ptr_type, uint32_t storage_class, Id initializer) {
    Id r = id();
    put(types_, op::Variable, {ptr_type, r, storage_class, initializer});
    return r;
}

Id Builder::emit(uint16_t opcode, Id type, const std::vector<uint32_t>& operands) {
    Id r = id();
    std::vector<uint32_t> ops{type, r};
    ops.insert(ops.end(), operands.begin(), operands.end());
    put(fn_blocks_, opcode, ops);
    return r;
}

void Builder::emit_void(uint16_t opcode, const std::vector<uint32_t>& operands) {
    put(fn_blocks_, opcode, operands);
    switch (opcode) {
        case op::Branch: case op::BranchConditional: case op::Switch: case op::Kill: case op::Return: case op::ReturnValue:
        case op::Unreachable:
            block_open_ = false;
            break;
        default:
            break;
    }
}

Id Builder::ext(Id type, uint32_t inst, const std::vector<Id>& args) {
    std::vector<uint32_t> ops{glsl_std(), inst};
    ops.insert(ops.end(), args.begin(), args.end());
    return emit(op::ExtInst, type, ops);
}

std::vector<uint32_t> Builder::finish() const {
    std::vector<uint32_t> out{0x07230203u, 0x00010300u, 0x4C4F424Fu /* "LOBO" generator */, next_id_, 0};
    for (const auto* section : {&caps_, &exts_, &imports_, &memmodel_, &entries_, &modes_, &names_, &decos_, &types_, &body_})
        out.insert(out.end(), section->begin(), section->end());
    return out;
}

} // namespace lg::shader::spirv
