// P4.1 (P4_DISENO.md §4, §7): Maxwell compute shader -> SPIR-V 1.3.
//
// Clean-room implementation (D-P4-2). Instruction semantics come from public documentation:
// envytools' gm107 opcode table (MIT), the nouveau GM107 emitter and its IR comments (MIT) and
// NVIDIA's public PTX documentation (PRMT modes). No code from other emulators.
//
// Structure of the generated module (P4.1 base, always correct for any CFG, D-P4-4):
//   - registers R0..R254, P0..P6 and the CC flags are Function variables (D-P4-3);
//   - control flow is a dispatcher: `loop { switch (pc) { case block: ...; } } while (pc != EXIT)`,
//     one case per basic block, keyed by the block's byte address;
//   - the CRS stack of SSY/PBK/PCNT/CAL is emulated per invocation (Private array): SYNC pops to
//     the SSY entry, BRK through the PBK entry, CONT through the PCNT entry, RET through the CAL
//     entry;
//   - constant buffers are uniform buffers (`uvec4 data[4096]`), global memory goes through
//     helper functions that find the storage buffer containing a 64-bit address by comparing it
//     with the guest's buffer table (driver constant buffer), shared memory is a Workgroup array
//     and local memory a per-invocation array.
// Anything outside P4.1 is reported as an error with its address and mnemonic, never translated
// silently (P4_DISENO.md §7).
#include "translate.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <functional>
#include <limits>
#include <map>
#include <mutex>
#include <set>
#include <tuple>
#include <string_view>
#include <unordered_set>

#include "maxwell/isa.h"
#include "spirv/builder.h"

namespace lg::shader {
namespace {

using maxwell::bit;
using maxwell::bits;
using maxwell::Encoding;
using spirv::Builder;
using spirv::Id;
namespace op = spirv::op;
namespace glsl = spirv::glsl;
namespace sc = spirv::storage;

constexpr uint32_t kExit = 0xFFFFFFFFu;
constexpr unsigned kRZ = 255;
constexpr unsigned kPT = 7;
constexpr uint32_t kCrsDepth = 64;
enum CrsKind : uint32_t { kSsy = 0, kPbk = 1, kPcnt = 2, kCal = 3, kPexit = 4, kPlongjmp = 5 };   // 4, 5: P4.4

// ---- operand tokens of an encoding ("REG_00, ON(31, p), C34_RZ_O14_20" -> 3 tokens) ----
const std::vector<std::vector<std::string_view>>& token_table() {
    static const std::vector<std::vector<std::string_view>> table = [] {
        std::vector<std::vector<std::string_view>> t;
        for (const Encoding& e : maxwell::encodings()) {
            std::vector<std::string_view> toks;
            std::string_view s(e.operands);
            if (const size_t c = s.find("/*"); c != std::string_view::npos) s = s.substr(0, c);
            int depth = 0;
            size_t start = 0;
            auto push = [&](size_t end) {
                std::string_view tok = s.substr(start, end - start);
                while (!tok.empty() && tok.front() == ' ') tok.remove_prefix(1);
                while (!tok.empty() && tok.back() == ' ') tok.remove_suffix(1);
                if (!tok.empty()) toks.push_back(tok);
            };
            for (size_t i = 0; i < s.size(); ++i) {
                if (s[i] == '(') ++depth;
                else if (s[i] == ')') --depth;
                else if (s[i] == ',' && depth == 0) { push(i); start = i + 1; }
            }
            push(s.size());
            t.push_back(std::move(toks));
        }
        return t;
    }();
    return table;
}

bool is_value_token(std::string_view t) {
    return t == "REG_20" || t == "REG_39" || t == "C34_RZ_O14_20" || t == "S20_20" || t == "F20_20" ||
           t == "U32_20" || t == "S32_20" || t == "F32_20" || t == "U16_20" || t == "U06_20" || t == "D20_20";
}

struct Insn {
    uint32_t addr{0};   // byte address from the start of the program
    uint64_t w{0};
    const Encoding* e{nullptr};
    const std::vector<std::string_view>* toks{nullptr};
    std::vector<std::string_view> vals;   // value tokens (B, C) in operand order
    std::string_view name() const { return e->mnemonic; }
    bool has(std::string_view t) const {
        for (auto x : *toks) if (x == t) return true;
        return false;
    }
    uint32_t f(unsigned pos, unsigned len) const { return static_cast<uint32_t>(bits(w, pos, len)); }
    bool b(unsigned pos) const { return bit(w, pos); }
};

int32_t sext(uint32_t v, unsigned width) {
    const uint32_t m = 1u << (width - 1);
    return static_cast<int32_t>((v ^ m) - m);
}

// The 20-bit immediate of the "_20" forms: bits 20..38 plus the sign at bit 56.
uint32_t imm20_raw(uint64_t w) { return static_cast<uint32_t>(bits(w, 20, 19) | (bits(w, 56, 1) << 19)); }

// A branch target on a scheduling word means the instruction after it (nouveau places block
// labels before the scheduling word that opens the block).
uint32_t norm_target(uint32_t t) { return ((t >> 3) & 3) == 0 ? t + 8 : t; }

bool is_branch_like(std::string_view n) {
    return n == "bra" || n == "brx" || n == "jmp" || n == "jmx" || n == "sync" || n == "brk" || n == "cont" ||
           n == "exit" || n == "kil" || n == "ret" || n == "cal" || n == "jcal" ||
           n == "longjmp" || n == "rtt" || n == "bpt";   // P4.4
}

class Translator {
public:
    Translator(std::span<const uint64_t> code, const ShaderInfo& info) : code_(code), info_(info) {}
    TranslationResult run();

private:
    // ---- diagnostics ----
    void fail(const Insn& in, const std::string& why) {
        if (!error_.empty()) return;
        char buf[64];
        std::snprintf(buf, sizeof buf, "0x%04x: %s: ", in.addr, in.e ? in.e->mnemonic : "?");
        error_ = buf + why;
    }
    void fail(const std::string& why) { if (error_.empty()) error_ = why; }
    void warn(const Insn& in, const std::string& why) {
        char buf[64];
        std::snprintf(buf, sizeof buf, "0x%04x: %s: ", in.addr, in.e->mnemonic);
        std::string s = buf + why;
        if (std::find(warnings_.begin(), warnings_.end(), s) == warnings_.end()) warnings_.push_back(s);
    }

    // ---- phases ----
    bool decode();
    void find_blocks();
    void scan_resources();
    void declare_module();
    void emit_main();
    void emit_helpers();

    // ---- types and small emit helpers ----
    Id U() { return tu_; }
    Id S() { return ts_; }
    Id F() { return tf_; }
    Id B() { return tb_; }
    Id cu(uint32_t v) { return b_.c_u32(v); }
    Id cf(float v) { return b_.c_f32(v); }
    Id cb(bool v) { return b_.c_bool(v); }
    Id e2(uint16_t o, Id t, Id x, Id y) { return b_.emit(o, t, {x, y}); }
    Id e1(uint16_t o, Id t, Id x) { return b_.emit(o, t, {x}); }
    Id add(Id x, Id y) { return e2(op::IAdd, U(), x, y); }
    Id sub(Id x, Id y) { return e2(op::ISub, U(), x, y); }
    Id band(Id x, Id y) { return e2(op::BitwiseAnd, U(), x, y); }
    Id bor(Id x, Id y) { return e2(op::BitwiseOr, U(), x, y); }
    Id bxor(Id x, Id y) { return e2(op::BitwiseXor, U(), x, y); }
    Id bnot(Id x) { return e1(op::Not, U(), x); }
    Id shl(Id x, Id y) { return e2(op::ShiftLeftLogical, U(), x, y); }
    Id shr(Id x, Id y) { return e2(op::ShiftRightLogical, U(), x, y); }
    Id sar(Id x, Id y) { return e2(op::ShiftRightArithmetic, U(), x, y); }
    Id ieq(Id x, Id y) { return e2(op::IEqual, B(), x, y); }
    Id ine(Id x, Id y) { return e2(op::INotEqual, B(), x, y); }
    Id ult(Id x, Id y) { return e2(op::ULessThan, B(), x, y); }
    Id uge(Id x, Id y) { return e2(op::UGreaterThanEqual, B(), x, y); }
    Id lnot(Id x) { return e1(op::LogicalNot, B(), x); }
    Id land(Id x, Id y) { return e2(op::LogicalAnd, B(), x, y); }
    Id lor(Id x, Id y) { return e2(op::LogicalOr, B(), x, y); }
    Id sel(Id c, Id x, Id y, Id t = 0) { return b_.emit(op::Select, t ? t : U(), {c, x, y}); }
    Id selb(Id c, Id x, Id y) { return b_.emit(op::Select, B(), {c, x, y}); }
    Id tof(Id u) { return e1(op::Bitcast, F(), u); }
    Id tou(Id f) { return e1(op::Bitcast, U(), f); }
    Id b2u(Id c) { return sel(c, cu(1), cu(0)); }
    Id ext(uint32_t inst, Id t, std::vector<Id> args) { return b_.ext(t, inst, args); }
    Id load(Id t, Id ptr) { return e1(op::Load, t, ptr); }
    void store(Id ptr, Id v) { b_.emit_void(op::Store, {ptr, v}); }
    Id chain(Id ptr_t, Id base, std::vector<Id> idx) {
        std::vector<uint32_t> ops{base};
        ops.insert(ops.end(), idx.begin(), idx.end());
        return b_.emit(op::AccessChain, ptr_t, ops);
    }
    Id pair_type() {
        if (!t_pair_) t_pair_ = b_.t_struct({U(), U()});
        return t_pair_;
    }
    // Shift by an amount that may be >= 32 without undefined behaviour.
    Id safe_shl(Id x, Id s) { return sel(uge(s, cu(32)), cu(0), shl(x, band(s, cu(31)))); }
    Id safe_shr(Id x, Id s) { return sel(uge(s, cu(32)), cu(0), shr(x, band(s, cu(31)))); }
    Id safe_sar(Id x, Id s) { return sar(x, ext(glsl::UMin, U(), {s, cu(31)})); }

    // Structured "if (c) { body }" in the current block.
    template <class Fn> void if_then(Id c, Fn&& body) {
        const Id then_l = b_.new_label(), merge = b_.new_label();
        b_.emit_void(op::SelectionMerge, {merge, 0});
        b_.emit_void(op::BranchConditional, {c, then_l, merge});
        b_.label(then_l);
        body();
        if (b_.block_open()) b_.emit_void(op::Branch, {merge});
        b_.label(merge);
    }

    // ---- guest state ----
    Id reg_var(unsigned r);
    Id ld_r(unsigned r) { return r == kRZ ? cu(0) : load(U(), reg_var(r)); }
    void st_r(unsigned r, Id v) { if (r != kRZ) store(reg_var(r), v); }
    // P4.4: MOV/MOV32I write only the quad lanes of their 4-bit mask (0xf: all)
    void st_r_lanes(unsigned r, Id v, unsigned mask);
    Id pred_var(unsigned p);
    Id ld_p(unsigned p, bool neg = false) {
        Id v = p == kPT ? cb(true) : load(B(), pred_var(p));
        return neg ? lnot(v) : v;
    }
    void st_p(unsigned p, Id v) { if (p != kPT) store(pred_var(p), v); }
    Id flag_var(int i);   // 0 ZF, 1 SF, 2 CF, 3 OF
    Id ld_flag(int i) { return load(B(), flag_var(i)); }
    void set_cc_int(Id r, Id carry, Id overflow, bool extended = false) {
        Id z = ieq(r, cu(0));
        if (extended) z = land(z, ld_flag(0));
        store(flag_var(0), z);
        store(flag_var(1), e2(op::SLessThan, B(), r, cu(0)));
        store(flag_var(2), carry ? carry : cb(false));
        store(flag_var(3), overflow ? overflow : cb(false));
    }
    void set_cc_float(Id f) {
        store(flag_var(0), e2(op::FOrdEqual, B(), f, cf(0.f)));
        store(flag_var(1), e2(op::FOrdLessThan, B(), f, cf(0.f)));
        store(flag_var(2), cb(false));
        store(flag_var(3), e1(op::IsNan, B(), f));
    }

    // ---- operands ----
    Id value(const Insn& in, size_t k);       // k-th value token as u32
    Id cbuf_load(unsigned bank, uint32_t byte_off);
    Id cbuf_load_dyn(unsigned bank, Id byte_addr);
    Id cbuf_var(unsigned bank);
    Id sysreg(const Insn& in, unsigned sr);

    // ---- float helpers ----
    Id ftz(Id f);
    Id fsat(Id f);
    Id to_half(Id f);   // f32 -> f16 bits (RN), NaN -> 0x7fff, overflow -> inf
    Id fneg_abs(Id f, bool neg, bool abs) {
        if (abs) f = ext(glsl::FAbs, F(), {f});
        if (neg) f = e1(op::FNegate, F(), f);
        return f;
    }
    Id fcmp(unsigned cond, Id a, Id b);
    Id icmp(unsigned cond, bool is_signed, Id a, Id b);
    Id icmp_x(unsigned cond, bool is_signed, Id a, Id b);
    Id bool_op(unsigned bop, Id a, Id b);
    Id cc_cond(const Insn& in, unsigned cond);

    // ---- memory ----
    Id gaddr_lo(const Insn& in, unsigned reg, int32_t imm, bool e, Id* hi_out);
    Id global_load(Id lo, Id hi);
    void global_store(Id lo, Id hi, Id v, Id mask);
    Id global_atomic(uint32_t opk, Id lo, Id hi, Id v, Id v2);
    Id shared_ptr(Id byte_addr);
    // P4.4: with 64-bit ATOMS (and ShaderInfo::int64_atomics) shared memory is an array of 64-bit
    // words (shared64_): 32-bit stores are two 64-bit atomics on their half, 32-bit atomics a CAS loop
    Id shared64_ptr(Id byte_addr);
    Id shared64_half(Id byte_addr);   // the shift of the 32-bit word in its 64-bit word (0 or 32)
    Id shared64_load(Id byte_addr);
    void shared64_store(Id byte_addr, Id v, Id mask);
    Id shared64_atomic32(Id byte_addr, const std::function<Id(Id)>& next);
    Id u64_of(Id lo, Id hi);
    Id u64_lo(Id v);
    Id u64_hi(Id v);
    Id global_atomic64(uint32_t opk, Id lo, Id hi, Id v, Id v2);
    void op_imnmx_ext(const Insn& in, uint32_t xm);
    Id local_ptr(Id byte_addr);
    Id extract_sized(Id word, Id byte_addr, unsigned size);   // u8/s8/u16/s16 from a word
    void load_words(const Insn& in, unsigned dst, unsigned size, const std::function<Id(Id word_addr)>& ld_word, Id addr);

    // ---- per-instruction ----
    void emit_insn(const Insn& in);
    void emit_body(const Insn& in);
    void emit_flow(const Insn& in);
    void op_iadd(const Insn& in);
    void op_iadd32i(const Insn& in);
    void op_iadd3(const Insn& in);
    void op_iscadd(const Insn& in);
    void op_lea(const Insn& in);
    void op_imad(const Insn& in);
    void op_imul(const Insn& in);
    void op_xmad(const Insn& in);
    void op_imnmx(const Insn& in);
    void op_lop(const Insn& in);
    void op_lop3(const Insn& in);
    void op_shifts(const Insn& in);
    void op_shf(const Insn& in);
    void op_bitfield(const Insn& in);
    void op_prmt(const Insn& in);
    void op_isetp(const Insn& in);
    void op_fadd(const Insn& in);
    void op_fmul(const Insn& in);
    void op_ffma(const Insn& in);
    void op_fmnmx(const Insn& in);
    void op_fsetp(const Insn& in);
    void op_mufu(const Insn& in);
    void op_f2f(const Insn& in);
    void op_f2i(const Insn& in);
    void op_i2f(const Insn& in);
    void op_i2i(const Insn& in);
    void op_pred(const Insn& in);
    void op_mem(const Insn& in);
    void op_atom(const Insn& in);
    void op_barrier(const Insn& in);
    Id hi_mul(Id a, Id b, bool sa, bool sb, Id* lo_out);

    // ---- control-flow helpers ----
    void crs_push(uint32_t kind, Id target);
    Id crs_pop_call(uint32_t kind);
    Id crs_pop_fn_[6]{};
    // P4.4: the CRS entry tag takes 2 bits (kinds 0..3) or 3 (PEXIT/PLONGJMP present): bit 30 or 29
    uint32_t crs_shift_{30};
    bool has_pexit_{false};

    // ---- graphics stages (P4.2, translate_graphics.inc) ----
    enum class IoDir : int { In = 0, Out = 1, PatchIn = 2, PatchOut = 3 };
    struct IoVar {
        Id var{0};
        Id scalar{0};
        uint32_t inner{1};        // components (vector) or elements (array)
        bool arrayed{false};      // per-vertex array
        bool is_bool{false};
        bool single_array{false}; // T[1] accessed at [0]
        uint32_t storage{0};
        AttribType type{AttribType::Float};
        uint32_t interp{2};       // FS: 1 constant, 2 perspective, 3 screen linear
    };
    struct BuiltinKey {
        uint32_t builtin{~0u};
        Id scalar{0};
        uint32_t inner{1};
        bool inner_array{false};
        bool is_bool{false};
        bool patch{false};
        bool flat_in_fs{false};
        const char* name{""};
        uint32_t comp{0};
    };
    uint32_t gs_input_vertices() const;
    IoDir io_dir(const Insn& in) const;
    bool arrayed(IoDir d) const;
    uint32_t array_len(IoDir d) const;
    void scan_graphics_io();
    Id scalar_type(AttribType t);
    uint32_t storage_of(IoDir d) const;
    IoVar make_io(IoDir d, Id scalar, uint32_t inner, bool inner_array, const std::string& name);
    void declare_graphics();
    BuiltinKey builtin_key(IoDir dir, uint32_t a) const;
    Id io_ptr(const IoVar& v, Id vertex, uint32_t comp, Id dyn_comp);
    Id io_load_bits(const IoVar& v, Id vertex, uint32_t comp);
    void io_store_bits(const IoVar& v, Id vertex, uint32_t comp, Id bits);
    Id tou_any(Id x);
    Id attr_word(const Insn& in, IoDir d, uint32_t a, Id vertex);
    void attr_store_word(const Insn& in, IoDir d, uint32_t a, Id vertex, Id bits);
    Id attr_word_dyn(IoDir d, Id addr, Id vertex);
    void attr_store_dyn(IoDir d, Id addr, Id vertex, Id bits);
    void op_attr(const Insn& in);
    void op_ipa(const Insn& in);
    bool it_is_float(uint32_t a) const;
    void op_out(const Insn& in);
    void op_shfl(const Insn& in);
    void plan_tcs_barriers();
    // ---- P4.3 textures and images (translate_texture.inc)
    struct TexKey {
        uint32_t bank{0}, offset{0}, dim{1};
        bool arrayed{false}, shadow{false}, ms{false};
        uint8_t type{0}, access{0};
        uint32_t raw_bytes{0};
        uint8_t format{0};
        bool operator<(const TexKey& o) const {
            return std::tie(bank, offset, dim, arrayed, shadow, ms, type, access, raw_bytes, format) <
                   std::tie(o.bank, o.offset, o.dim, o.arrayed, o.shadow, o.ms, o.type, o.access, o.raw_bytes, o.format);
        }
    };
    struct TexOp {
        enum Kind { Sample, Fetch, Gather, Grad, QueryLod, QuerySize } kind{Sample};
        enum Lod { Implicit, Zero, Bias, Explicit } lod{Implicit};
        uint32_t dim{1};
        bool array{false}, shadow{false}, ms{false}, query_any_type{false};
        std::vector<Id> coords;
        Id layer{0}, lodv{0}, sample{0}, dref{0};
        Id dx[3]{}, dy[3]{};
        bool has_off{false};
        int32_t off[3]{};
        bool ptp{false};
        int32_t ptp_off[4][2]{};
        Id dyn_off{0};
        bool dyn_any{false};     // P4.4: a non-constant offset outside TLD4 (D-P4.4-11)
        Id ptp_dyn[2]{};         // P4.4: TLD4.PTP with non-constant offsets
        Id dyn_handle{0};        // P4.4: a handle resolved at run time (D-P4.4-10)
        bool query_type{false};  // P4.4: TXQ texture type
        uint32_t comp{0};
        unsigned dst[4]{kRZ, kRZ, kRZ, kRZ};
        uint32_t bank{0}, offset{0};
    };
    std::map<TexKey, std::pair<Id, Id>> tex_vars_;   // descriptor -> (variable, pointee type)
    static uint32_t tex_coord_count(uint32_t dim);
    AttribType texture_type(uint32_t bank, uint32_t offset) const;
    std::pair<Id, Id> texture_var(const TexKey& k);
    uint32_t spirv_image_format(ImageFormat f, Id& sampled_type);
    const Insn* reaching_def(const Insn& at, unsigned reg);
    bool trace_const(const Insn& at, unsigned reg, uint32_t& value);
    bool trace_cbuf(const Insn& at, unsigned reg, uint32_t& bank, uint32_t& off);
    Id rr(unsigned base, unsigned k);
    Id ld_r_or0(unsigned r);
    bool tex_handle(const Insn& in, TexOp& t, bool bindless, unsigned handle_reg);
    bool tex_offsets(const Insn& in, TexOp& t, unsigned reg, bool gather);
    bool tex_scalar(const Insn& in, TexOp& t);
    bool tex_shape(const Insn& in, uint32_t& bank, uint32_t& off, uint32_t& dim, bool& arr, bool& ms);
    void op_texture(const Insn& in);
    void emit_tex(const Insn& in, TexOp& t);
    struct SurfaceAtomic { bool cas{false}; uint32_t op{0}; bool is_signed{false}; bool is_float{false}; };
    struct SurfDec {
        enum Kind { Load, Store, Atomic, Reduce } kind{Load};
        TexKey key;
        bool raw{false}, arrayed{false};
        uint32_t raw_bytes{0}, comp_mask{0}, size_code{0}, dim{1};
        ImageFormat fmt{ImageFormat::Unknown};
        SurfaceAtomic sa;
        bool byte_addr{false};   // P4.4: .BA (x in bytes)
        Id dyn_handle{0};        // P4.4: general bindless
    };
    bool surface_decode(const Insn& in, SurfDec& d);
    // P4.4 (translate_texture.inc)
    bool texture_is_buffer(uint32_t bank, uint32_t offset) const;
    Id bindless_image(uint32_t dim, bool arrayed, bool ms, bool shadow, AttribType t, bool storage, uint32_t fmt, Id handle,
                      Id& img_t);
    Id bindless_sampler(Id handle);
    std::map<std::tuple<uint32_t, bool, bool, bool, uint8_t, bool, uint32_t>, Id> bindless_vars_;
    Id bindless_samplers_{0};
    Id atomic_cas_loop(Id ptr, Id st, Id scope, const std::function<Id(Id)>& next);
    AttribType image_type(uint32_t bank, uint32_t offset, ImageFormat& fmt) const;
    void op_surface(const Insn& in);
    void op_fswzadd(const Insn& in);
    Id quad_index();
    bool value_is_nonzero_const(const Insn& in) const;
    void fs_write_outputs();
    Id graphics_sysreg(const Insn& in, unsigned sr, bool& handled);
    void declare_entry_and_modes();
    // ---- P4.4 double precision (translate_fp64.inc)
    Id D();
    Id dconst(double v);
    Id d_from_bits(Id lo, Id hi);
    void d_to_bits(Id d, Id& lo, Id& hi);
    Id ld_d(unsigned r);
    void st_d(unsigned r, Id d);
    Id dvalue(const Insn& in, size_t k);
    Id dneg_abs(Id d, bool neg, bool abs);
    void set_cc_double(Id d);
    void op_double(const Insn& in);
    Id f32_from_d(Id s, Id err, bool odd);
    Id exact_op(uint16_t o, Id x, Id y);
    // ---- P4.4 packed half precision (translate_fp16.inc)
    void h_pair(Id word, unsigned swz, bool neg, bool abs, bool ftz_in, Id out[2]);
    Id h_ftz(Id f);
    Id h_bits(Id f, bool ftz_out);
    void op_half(const Insn& in);
    Id f32_add_odd(Id x, Id y);
    // ---- P4.4 flow, warp, system (translate_misc.inc)
    void flow_cbuf(const Insn& in, Id cond);
    void flow_trap(const Insn& in);
    Id cc_test(const Insn& in, unsigned cond);
    void op_cset(const Insn& in);
    void op_fchk(const Insn& in);
    Id warp_lane();
    Id subgroup_sid();
    Id subgroup_size();
    Id warp_ballot(Id p);
    void op_vote(const Insn& in);
    void op_pixld(const Insn& in);
    void op_imadsp(const Insn& in);
    // P4.5: scalar video instructions (translate_video.inc)
    struct P64 { Id lo, hi; };
    P64 v_ext(Id v, bool sgn);
    P64 v_add(P64 a, P64 b);
    P64 v_neg(P64 a);
    P64 v_mul(P64 a, P64 b);
    P64 v_shl(P64 a, Id n);
    P64 v_shr(P64 a, Id n, bool arith);
    Id v_slt(P64 a, P64 b);
    Id v_sat(P64 a, bool sgn, unsigned bits);
    void op_video(const Insn& in);
    void op_idp(const Insn& in);
    void op_system(const Insn& in);
    void op_bar_ext(const Insn& in, uint32_t mode);
    void op_shfl_general(const Insn& in);
    Id subgroup_size_{0}, sample_id_{0}, sample_mask_in_{0}, lmem_base_{0}, bar_count_{0}, bar_result_{0};
    bool conv64(const Insn& in);
    void op_mufu64(const Insn& in, unsigned fn);
    Id t_d_{0};

    Stage stage_{Stage::Compute};
    Sph sph_;
    std::map<uint32_t, uint32_t> gen_comps_[4];
    std::set<uint32_t> io_builtins_[4];
    bool io_dynamic_[4]{};
    std::set<uint32_t> centroid_locs_;
    std::map<uint32_t, IoVar> generics_[4];
    std::map<std::pair<int, uint32_t>, IoVar> builtins_;
    std::vector<Id> interface_;
    std::vector<std::pair<uint32_t, IoVar>> fs_targets_;
    uint32_t fs_after_color_reg_{0};
    IoVar fs_sample_mask_, fs_depth_;
    Id invocation_id_{0};
    Id subgroup_lane_{0};   // SubgroupLocalInvocationId (quad operations), created on first use
    std::set<size_t> tcs_barrier_before_;               // TCS: barrier before these instructions
    size_t tcs_barrier_after_{~size_t{0}};              // TCS: barrier after this one (end of the uniform prefix)

    std::span<const uint64_t> code_;
    const ShaderInfo& info_;
    Builder b_;
    std::string error_;
    uint32_t soft_skipped_{0};
    uint32_t undecoded_soft_{0};
    std::vector<std::string> warnings_;
    std::vector<Insn> insns_;
    std::map<uint32_t, size_t> by_addr_;   // byte address -> index in insns_
    std::set<uint32_t> leaders_;
    bool has_brx_{false};
    // types
    Id tu_{}, ts_{}, tf_{}, tb_{}, t_pair_{};
    Id t_ptr_fu_{}, t_ptr_fb_{};
    // variables
    std::map<unsigned, Id> regs_, preds_;
    Id flags_[4]{};
    Id pc_{}, crs_stack_{}, crs_sp_{};
    Id t_ptr_priv_u_{};
    std::map<unsigned, Id> cbuf_vars_;
    Id t_ptr_uni_u_{};
    std::set<unsigned> cbuf_banks_;
    std::set<std::pair<uint32_t, uint32_t>> ssbo_entries_;   // (table, entry)
    std::map<std::pair<uint32_t, uint32_t>, Id> ssbo_vars_;
    Id t_ptr_ssbo_u_{};
    bool uses_global_{false};
    Id shared_{}, t_ptr_wg_u_{};
    uint32_t shared_words_{0};
    Id local_{};
    uint32_t local_words_{0};
    Id in_local_id_{}, in_group_id_{}, in_local_index_{};
    Id t_ptr_in_v3_{}, t_ptr_in_u_{};
    // helper functions (emitted after main)
    Id fn_gld_{}, fn_gst_{};
    std::map<uint32_t, Id> fn_gatom_;
    std::map<uint32_t, Id> fn_gatom64_;   // P4.4: 64-bit global atomics (u64 views of the SSBOs)
    bool shared64_{false};
    Id t_u64_{0};
    Id main_fn_{};
    std::vector<ResourceUse> result_resources_;
};

// =====================================================================================
// Decoding and CFG
// =====================================================================================
bool Translator::decode() {
    const auto& toks = token_table();
    if (code_.empty()) { fail("programa vacío"); return false; }
    for (size_t i = 0; i < code_.size(); ++i) {
        if (maxwell::is_sched_slot(i)) continue;
        Insn in;
        in.addr = static_cast<uint32_t>(i * 8);
        in.w = code_[i];
        in.e = maxwell::find_encoding(in.w);
        if (!in.e) {
            if (info_.soft_undecodable_as_skip) {
                // Keep address space intact: map to a real NOP encoding when possible.
                for (const auto& e : maxwell::encodings()) {
                    if (std::string_view(e.mnemonic) == "nop") { in.e = &e; break; }
                }
                if (!in.e) {
                    char buf[80];
                    std::snprintf(buf, sizeof buf, "0x%04x: palabra no decodificable 0x%016llx", in.addr,
                                  static_cast<unsigned long long>(in.w));
                    fail(buf);
                    return false;
                }
                char buf[96];
                std::snprintf(buf, sizeof buf, "0x%04x: palabra 0x%016llx no en ISA; tratada como NOP (soft)",
                              in.addr, static_cast<unsigned long long>(in.w));
                if (std::find(warnings_.begin(), warnings_.end(), buf) == warnings_.end())
                    warnings_.push_back(buf);
                ++undecoded_soft_;
            } else {
                char buf[80];
                std::snprintf(buf, sizeof buf, "0x%04x: palabra no decodificable 0x%016llx", in.addr,
                              static_cast<unsigned long long>(in.w));
                fail(buf);
                return false;
            }
        }
        in.toks = &toks[maxwell::encoding_index(in.e)];
        for (auto t : *in.toks) if (is_value_token(t)) in.vals.push_back(t);
        by_addr_[in.addr] = insns_.size();
        insns_.push_back(std::move(in));
    }
    return true;
}

void Translator::find_blocks() {
    leaders_.insert(insns_.front().addr);
    for (size_t i = 0; i < insns_.size(); ++i) {
        const Insn& in = insns_[i];
        const std::string_view n = in.name();
        if (n == "brx" || n == "jmx") has_brx_ = true;
        // P4.4: a target read from a constant buffer may be any instruction; PEXIT/PLONGJMP need the
        // 3-bit CRS tags
        if (in.has("C36_RZ_S16_20") || ((n == "brx" || n == "jmx") && in.has("C36_08_S16_20"))) has_brx_ = true;
        if (n == "pexit" || n == "plongjmp" || n == "longjmp") crs_shift_ = 29;
        if (n == "pexit") has_pexit_ = true;
        if (in.has("BTARG")) {
            const uint32_t t = norm_target(static_cast<uint32_t>(static_cast<int64_t>(in.addr) + 8 + sext(in.f(20, 24), 24)));
            if (by_addr_.count(t)) leaders_.insert(t);
        }
        if ((n == "jmp" || n == "jcal") && in.has("U32_20")) {
            const uint32_t t = norm_target(in.f(20, 32));
            if (by_addr_.count(t)) leaders_.insert(t);
        }
        if (is_branch_like(n) && i + 1 < insns_.size()) leaders_.insert(insns_[i + 1].addr);
    }
    if (has_brx_)
        for (const Insn& in : insns_) leaders_.insert(in.addr);
}

// Which constant buffer banks are read, which entries of the global buffer tables are used.
void Translator::scan_resources() {
    const auto& tables = info_.global_tables;
    bool dyn_table_read = false;
    auto note_table_read = [&](unsigned bank, uint32_t off) {
        for (uint32_t t = 0; t < tables.size(); ++t) {
            const GlobalBufferTable& gb = tables[t];
            if (bank == gb.cbuf_bank && off >= gb.offset && off < gb.offset + gb.count * gb.stride)
                ssbo_entries_.insert({t, (off - gb.offset) / gb.stride});
        }
    };
    for (const Insn& in : insns_) {
        const std::string_view n = in.name();
        if (in.has("C34_RZ_O14_20")) {
            const unsigned bank = in.f(34, 5);
            cbuf_banks_.insert(bank);
            note_table_read(bank, in.f(20, 14) * 4);
        }
        if (in.has("C36_RZ_S16_20") || (in.has("C36_08_S16_20") && n != "ld"))   // P4.4: flow targets
            cbuf_banks_.insert(in.f(36, 5));
        if (in.has("C36_08_S16_20") && n == "ld" && in.f(44, 2) == 2)   // P4.4: LDC.IS, any bank
            for (const CbufBinding& cb : info_.cbufs) cbuf_banks_.insert(cb.bank);
        if (in.has("C36_08_S16_20") && n == "ld") {
            const unsigned bank = in.f(36, 5);
            cbuf_banks_.insert(bank);
            if (in.f(8, 8) == kRZ) note_table_read(bank, static_cast<uint32_t>(sext(in.f(20, 16), 16)));
            else for (const auto& gb : tables) if (gb.cbuf_bank == bank) dyn_table_read = true;
        }
        if (n == "ldg" || n == "stg" || n == "red" || (n == "atom") ||
            ((n == "ld" || n == "st") && in.has("GMEM")))
            uses_global_ = true;
    }
    if (uses_global_) {
        if (dyn_table_read)
            for (uint32_t t = 0; t < tables.size(); ++t)
                for (uint32_t i = 0; i < tables[t].count; ++i) ssbo_entries_.insert({t, i});
        for (const auto& gb : tables) cbuf_banks_.insert(gb.cbuf_bank);   // the helpers read the tables
    }
}

// =====================================================================================
// Module-level declarations
// =====================================================================================
void Translator::declare_module() {
    b_.capability(1 /* Shader */);
    b_.glsl_std();
    b_.memory_model(0 /* Logical */, 1 /* GLSL450 */);
    tu_ = b_.t_u32();
    ts_ = b_.t_s32();
    tf_ = b_.t_f32();
    tb_ = b_.t_bool();
    t_ptr_fu_ = b_.t_ptr(sc::Function, tu_);
    t_ptr_fb_ = b_.t_ptr(sc::Function, tb_);
    t_ptr_priv_u_ = b_.t_ptr(sc::Private, tu_);
    t_ptr_uni_u_ = b_.t_ptr(sc::Uniform, tu_);
    t_ptr_ssbo_u_ = b_.t_ptr(sc::StorageBuffer, tu_);
    t_ptr_wg_u_ = b_.t_ptr(sc::Workgroup, tu_);

    // Built-in inputs (compute; the graphics stages declare theirs in declare_graphics()).
    const Id v3 = b_.t_vec(tu_, 3);
    t_ptr_in_v3_ = b_.t_ptr(sc::Input, v3);
    t_ptr_in_u_ = b_.t_ptr(sc::Input, tu_);
    if (stage_ == Stage::Compute) {
    in_local_id_ = b_.global_var(t_ptr_in_v3_, sc::Input);
    b_.decorate(in_local_id_, spirv::deco::BuiltIn, {spirv::builtin::LocalInvocationId});
    in_group_id_ = b_.global_var(t_ptr_in_v3_, sc::Input);
    b_.decorate(in_group_id_, spirv::deco::BuiltIn, {spirv::builtin::WorkgroupId});
    in_local_index_ = b_.global_var(t_ptr_in_u_, sc::Input);
    b_.decorate(in_local_index_, spirv::deco::BuiltIn, {spirv::builtin::LocalInvocationIndex});
    } else {
        declare_graphics();
    }

    // Dispatcher state (Private: the helper functions see it too).
    const Id t_stack = b_.t_array(tu_, kCrsDepth);
    const Id t_ptr_stack = b_.t_ptr(sc::Private, t_stack);
    crs_stack_ = b_.global_var(t_ptr_stack, sc::Private);
    b_.name(crs_stack_, "crs");
    crs_sp_ = b_.global_var(t_ptr_priv_u_, sc::Private, cu(0));
    b_.name(crs_sp_, "crs_sp");

    // Constant buffers.
    for (unsigned bank : cbuf_banks_) {
        uint32_t binding = ~0u;
        for (const auto& cb : info_.cbufs) if (cb.bank == bank) binding = cb.binding;
        if (binding == ~0u) {
            char buf[96];
            std::snprintf(buf, sizeof buf, "constbuffer c%u sin binding en ShaderInfo::cbufs", bank);
            fail(buf);
            return;
        }
        const Id v4 = b_.t_vec(tu_, 4);
        const Id arr = b_.t_array(v4, 4096);
        b_.decorate(arr, spirv::deco::ArrayStride, {16});
        const Id st = b_.t_struct({arr});
        b_.decorate(st, spirv::deco::Block);
        b_.member_decorate(st, 0, spirv::deco::Offset, {0});
        const Id var = b_.global_var(b_.t_ptr(sc::Uniform, st), sc::Uniform);
        b_.decorate(var, spirv::deco::DescriptorSet, {info_.descriptor_set});
        b_.decorate(var, spirv::deco::Binding, {binding});
        b_.name(var, "c" + std::to_string(bank));
        cbuf_vars_[bank] = var;
        result_resources_.push_back({ResourceUse::Kind::ConstantBuffer, binding, bank});
    }
    // Storage buffers of the global buffer table.
    if (uses_global_) {
        if (ssbo_entries_.empty()) {
            fail("acceso a memoria global sin lectura de la tabla de buffers (no rastreable)");
            return;
        }
        for (const auto& key : ssbo_entries_) {
            const auto [t, i] = key;
            const Id arr = b_.t_runtime_array(tu_);
            b_.decorate(arr, spirv::deco::ArrayStride, {4});
            const Id st = b_.t_struct({arr});
            b_.decorate(st, spirv::deco::Block);
            b_.member_decorate(st, 0, spirv::deco::Offset, {0});
            const Id var = b_.global_var(b_.t_ptr(sc::StorageBuffer, st), sc::StorageBuffer);
            const uint32_t binding = info_.global_tables[t].first_binding + i;
            b_.decorate(var, spirv::deco::DescriptorSet, {info_.descriptor_set});
            b_.decorate(var, spirv::deco::Binding, {binding});
            b_.name(var, "g" + std::to_string(t) + "_" + std::to_string(i));
            ssbo_vars_[key] = var;
            result_resources_.push_back({ResourceUse::Kind::StorageBuffer, binding, i, t});
        }
        fn_gld_ = b_.id();
        fn_gst_ = b_.id();
    }
    // Shared and local memory (+1 word: out-of-range accesses land there instead of being UB).
    shared_words_ = (info_.shared_memory_bytes + 3) / 4;
    if (shared_words_ && info_.int64_atomics)
        for (const Insn& o : insns_)
            if (o.name() == "atoms" && ((o.e->value >> 48) == 0xee00 ? o.b(52) : o.f(28, 2) >= 2)) shared64_ = true;
    if (shared_words_ && shared64_) {   // P4.4: 64-bit words (+1: out-of-range accesses)
        b_.capability(11 /* Int64 */);
        b_.capability(12 /* Int64Atomics */);
        t_u64_ = b_.t_int(64, false);
        const Id arr = b_.t_array(t_u64_, (shared_words_ + 1) / 2 + 1);
        shared_ = b_.global_var(b_.t_ptr(sc::Workgroup, arr), sc::Workgroup);
        b_.name(shared_, "smem64");
    } else if (shared_words_) {
        const Id arr = b_.t_array(tu_, shared_words_ + 1);
        shared_ = b_.global_var(b_.t_ptr(sc::Workgroup, arr), sc::Workgroup);
        b_.name(shared_, "smem");
    }
    local_words_ = (info_.local_memory_bytes + 3) / 4;
    if (local_words_) {
        const Id arr = b_.t_array(tu_, local_words_ + 1);
        local_ = b_.global_var(b_.t_ptr(sc::Private, arr), sc::Private);
        b_.name(local_, "lmem");
    }
}

Id Translator::reg_var(unsigned r) {
    auto it = regs_.find(r);
    if (it != regs_.end()) return it->second;
    const Id v = b_.local_var(t_ptr_fu_, cu(0));
    b_.name(v, "r" + std::to_string(r));
    regs_.emplace(r, v);
    return v;
}

Id Translator::pred_var(unsigned p) {
    auto it = preds_.find(p);
    if (it != preds_.end()) return it->second;
    const Id v = b_.local_var(t_ptr_fb_, cb(false));
    b_.name(v, "p" + std::to_string(p));
    preds_.emplace(p, v);
    return v;
}

Id Translator::flag_var(int i) {
    if (!flags_[i]) {
        flags_[i] = b_.local_var(t_ptr_fb_, cb(false));
        static const char* names[] = {"zf", "sf", "cf", "of"};
        b_.name(flags_[i], names[i]);
    }
    return flags_[i];
}

// =====================================================================================
// Operands
// =====================================================================================
Id Translator::cbuf_var(unsigned bank) {
    auto it = cbuf_vars_.find(bank);
    return it == cbuf_vars_.end() ? 0 : it->second;
}

Id Translator::cbuf_load(unsigned bank, uint32_t byte_off) {
    const Id var = cbuf_var(bank);
    if (!var) return cu(0);
    if (byte_off >= 0x10000) return cu(0);
    const Id p = chain(t_ptr_uni_u_, var, {cu(0), cu(byte_off >> 4), cu((byte_off >> 2) & 3)});
    return load(U(), p);
}

Id Translator::cbuf_load_dyn(unsigned bank, Id addr) {
    const Id var = cbuf_var(bank);
    if (!var) return cu(0);
    const Id in_range = ult(addr, cu(0x10000));
    const Id a = band(addr, cu(0xfffc));
    const Id p = chain(t_ptr_uni_u_, var, {cu(0), shr(a, cu(4)), band(shr(a, cu(2)), cu(3))});
    return sel(in_range, load(U(), p), cu(0));
}

Id Translator::value(const Insn& in, size_t k) {
    if (k >= in.vals.size()) { fail(in, "falta el operando " + std::to_string(k)); return cu(0); }
    const std::string_view t = in.vals[k];
    if (t == "REG_20") return ld_r(in.f(20, 8));
    if (t == "REG_39") return ld_r(in.f(39, 8));
    if (t == "C34_RZ_O14_20") return cbuf_load(in.f(34, 5), in.f(20, 14) * 4);
    if (t == "S20_20") return cu(static_cast<uint32_t>(sext(imm20_raw(in.w), 20)));
    if (t == "F20_20") return cu(imm20_raw(in.w) << 12);
    if (t == "U32_20" || t == "S32_20" || t == "F32_20") return cu(in.f(20, 32));
    if (t == "U16_20") return cu(in.f(20, 16));
    if (t == "U06_20") return cu(in.f(20, 6));
    fail(in, "operando " + std::string(t) + " fuera de P4.1 (doble precisión)");
    return cu(0);
}

Id Translator::sysreg(const Insn& in, unsigned sr) {
    if (stage_ != Stage::Compute) {
        bool handled = false;
        const Id r = graphics_sysreg(in, sr, handled);
        if (handled) return r;
        if (sr == 0x01 || (sr >= 0x50 && sr <= 0x53)) {
            warn(in, "reloj del sistema: se devuelve 0 (sin equivalente portable)");
            return cu(0);
        }
        char buf[64];
        std::snprintf(buf, sizeof buf, "registro de sistema 0x%02x fuera de P4.2 en esta etapa", sr);
        fail(in, buf);
        return cu(0);
    }
    auto comp = [&](Id var, uint32_t i) {
        return load(U(), chain(t_ptr_in_u_, var, {cu(i)}));
    };
    auto lane = [&] { return band(load(U(), in_local_index_), cu(31)); };
    switch (sr) {
        case 0x00: return lane();
        case 0x20: {   // combined tid: x | y << 16 | z << 26
            return bor(bor(comp(in_local_id_, 0), shl(comp(in_local_id_, 1), cu(16))), shl(comp(in_local_id_, 2), cu(26)));
        }
        case 0x21: case 0x22: case 0x23: return comp(in_local_id_, sr - 0x21);
        case 0x25: case 0x26: case 0x27: return comp(in_group_id_, sr - 0x25);
        case 0x28:
            return cu(info_.local_size[0] | (info_.local_size[1] << 16) | (info_.local_size[2] << 26));
        case 0x32: return cu(info_.shared_memory_bytes);
        case 0x38: return shl(cu(1), lane());
        case 0x39: return sub(shl(cu(1), lane()), cu(1));
        case 0x3a: return sub(safe_shl(cu(1), add(lane(), cu(1))), cu(1));
        case 0x3b: return bnot(sub(safe_shl(cu(1), add(lane(), cu(1))), cu(1)));
        case 0x3c: return bnot(sub(shl(cu(1), lane()), cu(1)));
        case 0x01: case 0x50: case 0x51: case 0x52: case 0x53:
            warn(in, "reloj del sistema: se devuelve 0 (sin equivalente portable en P4.1)");
            return cu(0);
        default: break;
    }
    char buf[48];
    std::snprintf(buf, sizeof buf, "registro de sistema 0x%02x fuera de P4.1", sr);
    fail(in, buf);
    return cu(0);
}

// =====================================================================================
// Float helpers
// =====================================================================================
Id Translator::ftz(Id f) {
    const Id u = tou(f);
    const Id den = ieq(band(u, cu(0x7f800000)), cu(0));
    return tof(sel(den, band(u, cu(0x80000000)), u));
}

Id Translator::to_half(Id f) {
    const Id v2 = b_.emit(op::CompositeConstruct, b_.t_vec(F(), 2), {f, cf(0.f)});
    Id r = band(ext(glsl::PackHalf2x16, U(), {v2}), cu(0xffff));
    const Id sign = band(shr(tou(f), cu(16)), cu(0x8000));
    const Id big = e2(op::FOrdGreaterThanEqual, B(), ext(glsl::FAbs, F(), {f}), cf(65520.f));
    r = sel(big, bor(sign, cu(0x7c00)), r);
    return sel(e1(op::IsNan, B(), f), cu(0x7fff), r);
}

Id Translator::fsat(Id f) {
    // NaN saturates to 0 (ordered comparisons are false for NaN).
    const Id gt0 = e2(op::FOrdGreaterThan, B(), f, cf(0.f));
    const Id lt1 = e2(op::FOrdLessThan, B(), f, cf(1.f));
    return sel(gt0, sel(lt1, f, cf(1.f), F()), cf(0.f), F());
}

Id Translator::fcmp(unsigned cond, Id a, Id b) {
    static const uint16_t ops[16] = {0, op::FOrdLessThan, op::FOrdEqual, op::FOrdLessThanEqual, op::FOrdGreaterThan,
                                     op::FOrdNotEqual, op::FOrdGreaterThanEqual, 0, 0, op::FUnordLessThan,
                                     op::FUnordEqual, op::FUnordLessThanEqual, op::FUnordGreaterThan,
                                     op::FUnordNotEqual, op::FUnordGreaterThanEqual, 0};
    switch (cond & 15) {
        case 0: return cb(false);
        case 15: return cb(true);
        case 7: return land(lnot(e1(op::IsNan, B(), a)), lnot(e1(op::IsNan, B(), b)));
        case 8: return lor(e1(op::IsNan, B(), a), e1(op::IsNan, B(), b));
        default: return e2(ops[cond & 15], B(), a, b);
    }
}

Id Translator::icmp(unsigned cond, bool s, Id a, Id b) {
    switch (cond & 7) {
        case 0: return cb(false);
        case 1: return e2(s ? op::SLessThan : op::ULessThan, B(), a, b);
        case 2: return ieq(a, b);
        case 3: return e2(s ? op::SLessThanEqual : op::ULessThanEqual, B(), a, b);
        case 4: return e2(s ? op::SGreaterThan : op::UGreaterThan, B(), a, b);
        case 5: return ine(a, b);
        case 6: return e2(s ? op::SGreaterThanEqual : op::UGreaterThanEqual, B(), a, b);
        default: return cb(true);
    }
}

// ISETP/ISET/ICMP .X: compares the high words of a 64-bit pair whose low words were subtracted
// earlier with CC (ZF: low difference was zero, CF: no borrow).
Id Translator::icmp_x(unsigned cond, bool s, Id a, Id b) {
    const Id eq = ieq(a, b);
    const Id lt = e2(s ? op::SLessThan : op::ULessThan, B(), a, b);
    const Id gt = e2(s ? op::SGreaterThan : op::UGreaterThan, B(), a, b);
    const Id zf = ld_flag(0), cf = ld_flag(2);
    const Id borrow = lnot(cf);
    switch (cond & 7) {
        case 0: return cb(false);
        case 1: return lor(lt, land(eq, borrow));
        case 2: return land(eq, zf);
        case 3: return lor(lt, land(eq, lor(borrow, zf)));
        case 4: return lor(gt, land(eq, land(cf, lnot(zf))));
        case 5: return lnot(land(eq, zf));
        case 6: return lor(gt, land(eq, cf));
        default: return cb(true);
    }
}

Id Translator::bool_op(unsigned bop, Id a, Id b) {
    switch (bop & 3) {
        case 0: return land(a, b);
        case 1: return lor(a, b);
        case 2: return e2(op::LogicalNotEqual, B(), a, b);
        default: return land(a, b);
    }
}

// Condition-code test of the flow instructions (T(f0f8_0)): 15 = always.
Id Translator::cc_cond(const Insn& in, unsigned cond) {
    if (cond == 15) return cb(true);
    if (cond == 0) return cb(false);
    const Id zf = ld_flag(0), sf = ld_flag(1), of = ld_flag(3);
    const Id lt = e2(op::LogicalNotEqual, B(), sf, of);
    switch (cond) {
        case 1: case 9: return land(lt, lnot(zf));
        case 2: case 10: return zf;
        case 3: case 11: return lor(lt, zf);
        case 4: case 12: return land(lnot(lt), lnot(zf));
        case 5: case 13: return lnot(zf);
        case 6: case 14: return lor(lnot(lt), zf);
        default: break;
    }
    fail(in, "condición de CC " + std::to_string(cond) + " fuera de P4.1");
    return cb(false);
}

// =====================================================================================
// Memory
// =====================================================================================
Id Translator::shared_ptr(Id addr) {
    const Id idx = shr(addr, cu(2));
    const Id safe = sel(ult(idx, cu(shared_words_)), idx, cu(shared_words_));
    return chain(t_ptr_wg_u_, shared_, {safe});
}

// P4.4: shared memory as 64-bit words (shared64_)
Id Translator::shared64_ptr(Id addr) {
    const uint32_t n = (shared_words_ + 1) / 2;
    const Id idx = shr(addr, cu(3));
    const Id safe = sel(ult(idx, cu(n)), idx, cu(n));
    return chain(b_.t_ptr(sc::Workgroup, t_u64_), shared_, {safe});
}
Id Translator::shared64_half(Id addr) { return shl(band(addr, cu(4)), cu(3)); }
Id Translator::u64_of(Id lo, Id hi) {
    return e1(op::Bitcast, t_u64_ ? t_u64_ : b_.t_int(64, false), b_.emit(op::CompositeConstruct, b_.t_vec(U(), 2), {lo, hi}));
}
Id Translator::u64_lo(Id v) { return b_.emit(op::CompositeExtract, U(), {e1(op::Bitcast, b_.t_vec(U(), 2), v), 0}); }
Id Translator::u64_hi(Id v) { return b_.emit(op::CompositeExtract, U(), {e1(op::Bitcast, b_.t_vec(U(), 2), v), 1}); }
Id Translator::shared64_load(Id addr) {
    const Id w = load(t_u64_, shared64_ptr(addr));
    return e1(op::UConvert, U(), e2(op::ShiftRightLogical, t_u64_, w, shared64_half(addr)));
}
// a store of the bits `mask` of the 32-bit word: clear and set them in the 64-bit word (atomics: the
// other half may be written at the same time by another invocation)
void Translator::shared64_store(Id addr, Id v, Id mask) {
    const Id p = shared64_ptr(addr);
    const Id sh = shared64_half(addr);
    const Id m64 = e2(op::ShiftLeftLogical, t_u64_, e1(op::UConvert, t_u64_, mask), sh);
    const Id v64 = e2(op::ShiftLeftLogical, t_u64_, e1(op::UConvert, t_u64_, band(v, mask)), sh);
    const Id wg = cu(spirv::scope::Workgroup), none = cu(0);
    b_.emit(op::AtomicAnd, t_u64_, {p, wg, none, e1(op::Not, t_u64_, m64)});
    b_.emit(op::AtomicOr, t_u64_, {p, wg, none, v64});
}
// a 32-bit atomic read-modify-write as a 64-bit compare-and-swap loop; returns the old word
Id Translator::shared64_atomic32(Id addr, const std::function<Id(Id)>& next) {
    const Id p = shared64_ptr(addr);
    const Id sh = shared64_half(addr);
    const Id keep = e1(op::Not, t_u64_, e2(op::ShiftLeftLogical, t_u64_, b_.c_u64(0xffffffffu), sh));
    const Id old64 = atomic_cas_loop(p, t_u64_, cu(spirv::scope::Workgroup), [&](Id cur) {
        const Id old = e1(op::UConvert, U(), e2(op::ShiftRightLogical, t_u64_, cur, sh));
        const Id nv = e2(op::ShiftLeftLogical, t_u64_, e1(op::UConvert, t_u64_, next(old)), sh);
        return e2(op::BitwiseOr, t_u64_, e2(op::BitwiseAnd, t_u64_, cur, keep), nv);
    });
    return e1(op::UConvert, U(), e2(op::ShiftRightLogical, t_u64_, old64, sh));
}

Id Translator::local_ptr(Id addr) {
    const Id idx = shr(addr, cu(2));
    const Id safe = sel(ult(idx, cu(local_words_)), idx, cu(local_words_));
    return chain(t_ptr_priv_u_, local_, {safe});
}

Id Translator::extract_sized(Id word, Id addr, unsigned size) {
    // size: 0 u8, 1 s8, 2 u16, 3 s16
    const bool is16 = size >= 2;
    const Id shift = shl(band(addr, cu(is16 ? 2 : 3)), cu(3));
    const Id width = cu(is16 ? 16 : 8);
    if (size & 1) return b_.emit(op::BitFieldSExtract, U(), {word, shift, width});
    return b_.emit(op::BitFieldUExtract, U(), {word, shift, width});
}

Id Translator::gaddr_lo(const Insn& in, unsigned reg, int32_t imm, bool e, Id* hi_out) {
    const Id base_lo = ld_r(reg);
    const Id base_hi = e && reg != kRZ ? ld_r(reg + 1) : cu(0);
    const Id res = b_.emit(op::IAddCarry, pair_type(), {base_lo, cu(static_cast<uint32_t>(imm))});
    const Id lo = b_.emit(op::CompositeExtract, U(), {res, 0});
    const Id carry = b_.emit(op::CompositeExtract, U(), {res, 1});
    const Id sign_ext = cu(imm < 0 ? 0xffffffffu : 0u);
    *hi_out = e ? add(add(base_hi, sign_ext), carry) : cu(0);
    (void)in;
    return lo;
}

Id Translator::global_load(Id lo, Id hi) {
    return b_.emit(op::FunctionCall, U(), {fn_gld_, lo, hi});
}

void Translator::global_store(Id lo, Id hi, Id v, Id mask) {
    b_.emit(op::FunctionCall, b_.t_void(), {fn_gst_, lo, hi, v, mask});
}

Id Translator::global_atomic(uint32_t opk, Id lo, Id hi, Id v, Id v2) {
    auto it = fn_gatom_.find(opk);
    Id fn;
    if (it == fn_gatom_.end()) { fn = b_.id(); fn_gatom_.emplace(opk, fn); }
    else fn = it->second;
    return b_.emit(op::FunctionCall, U(), {fn, lo, hi, v, v2});
}

// Loads `size` (ef58sz/eed0sz codes: 0 u8 .. 4 b32, 5 b64, 6 b128) at addr into dst.., using
// ld_word(word_address) for each 32-bit word.
void Translator::load_words(const Insn& in, unsigned dst, unsigned size, const std::function<Id(Id)>& ld_word, Id addr) {
    if (size <= 3) {
        const Id w = ld_word(band(addr, cu(~3u)));
        st_r(dst, extract_sized(w, addr, size));
        return;
    }
    const unsigned n = size == 4 ? 1 : size == 5 ? 2 : 4;
    if (size > 6 && size != 7) { fail(in, "tamaño de acceso no válido"); return; }
    std::vector<Id> words;
    for (unsigned i = 0; i < n; ++i) words.push_back(ld_word(add(addr, cu(4 * i))));
    for (unsigned i = 0; i < n; ++i)
        if (dst != kRZ) st_r(dst + i, words[i]);
}

// =====================================================================================
// Control-flow helpers
// =====================================================================================
void Translator::crs_push(uint32_t kind, Id target) {
    const Id sp = load(U(), crs_sp_);
    const Id slot = chain(t_ptr_priv_u_, crs_stack_, {band(sp, cu(kCrsDepth - 1))});
    store(slot, bor(target, cu(kind << crs_shift_)));
    store(crs_sp_, add(sp, cu(1)));
}

Id Translator::crs_pop_call(uint32_t kind) {
    if (!crs_pop_fn_[kind]) crs_pop_fn_[kind] = b_.id();
    return b_.emit(op::FunctionCall, U(), {crs_pop_fn_[kind]});
}

// =====================================================================================
// Integer ALU
// =====================================================================================
void Translator::op_iadd(const Insn& in) {
    const bool neg_a = in.b(49), neg_b = in.b(48), sat = in.b(50), x = in.b(43), cc = in.b(47);
    Id a = ld_r(in.f(8, 8)), b = value(in, 0);
    if (neg_a) a = bnot(a);
    if (neg_b) b = bnot(b);
    const Id cin = x ? b2u(ld_flag(2)) : cu(static_cast<uint32_t>(neg_a) + static_cast<uint32_t>(neg_b));
    const Id s1 = b_.emit(op::IAddCarry, pair_type(), {a, b});
    const Id r1 = b_.emit(op::CompositeExtract, U(), {s1, 0});
    const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r1, cin});
    Id r = b_.emit(op::CompositeExtract, U(), {s2, 0});
    const Id carry = ine(bor(b_.emit(op::CompositeExtract, U(), {s1, 1}), b_.emit(op::CompositeExtract, U(), {s2, 1})), cu(0));
    const Id of = e2(op::SLessThan, B(), band(bxor(a, r), bxor(b, r)), cu(0));
    if (sat) r = sel(of, bxor(sar(a, cu(31)), cu(0x7fffffff)), r);
    if (cc) set_cc_int(r, carry, of, x);
    st_r(in.f(0, 8), r);
}

void Translator::op_iadd32i(const Insn& in) {
    const bool po = in.e->value == 0x1d80000000000000ull;
    const bool neg_a = !po && in.b(56), sat = in.b(54), x = in.b(53), cc = in.b(52);
    Id a = ld_r(in.f(8, 8));
    const Id b = cu(in.f(20, 32));
    if (neg_a) a = bnot(a);
    const Id cin = x ? b2u(ld_flag(2)) : cu(static_cast<uint32_t>(neg_a) + (po ? 1u : 0u));
    const Id s1 = b_.emit(op::IAddCarry, pair_type(), {a, b});
    const Id r1 = b_.emit(op::CompositeExtract, U(), {s1, 0});
    const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r1, cin});
    Id r = b_.emit(op::CompositeExtract, U(), {s2, 0});
    const Id carry = ine(bor(b_.emit(op::CompositeExtract, U(), {s1, 1}), b_.emit(op::CompositeExtract, U(), {s2, 1})), cu(0));
    const Id of = e2(op::SLessThan, B(), band(bxor(a, r), bxor(b, r)), cu(0));
    if (sat) r = sel(of, bxor(sar(a, cu(31)), cu(0x7fffffff)), r);
    if (cc) set_cc_int(r, carry, of, x);
    st_r(in.f(0, 8), r);
}

void Translator::op_iadd3(const Insn& in) {
    const bool reg_form = (in.e->mask >> 48) == 0xfff0 && (in.e->value >> 48) == 0x5cc0;
    const bool na = in.b(51), nb = in.b(50), nc = in.b(49), x = in.b(48), cc = in.b(47);
    Id a = ld_r(in.f(8, 8)), b = value(in, 0), c = value(in, 1);
    unsigned mode = 0;
    if (reg_form) {
        mode = in.f(37, 2);
        auto half = [&](Id v, unsigned h) {
            if (h == 1) return band(v, cu(0xffff));
            if (h == 2) return shr(v, cu(16));
            return v;
        };
        a = half(a, in.f(35, 2));
        b = half(b, in.f(33, 2));
        c = half(c, in.f(31, 2));
    }
    if (na) a = bnot(a);
    if (nb) b = bnot(b);
    if (nc) c = bnot(c);
    const uint32_t nneg = static_cast<uint32_t>(na) + nb + nc;
    Id ab = add(a, b);
    Id carry1 = ult(ab, a);
    if (mode == 1) { ab = shr(ab, cu(16)); carry1 = cb(false); }
    if (mode == 2) { ab = shl(ab, cu(16)); carry1 = cb(false); }
    if (mode == 3) fail(in, "modo de IADD3 reservado");
    const Id s1 = b_.emit(op::IAddCarry, pair_type(), {ab, c});
    Id r = b_.emit(op::CompositeExtract, U(), {s1, 0});
    Id carry = lor(carry1, ine(b_.emit(op::CompositeExtract, U(), {s1, 1}), cu(0)));
    const Id cin = x ? b2u(ld_flag(2)) : cu(nneg);
    const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r, cin});
    r = b_.emit(op::CompositeExtract, U(), {s2, 0});
    carry = lor(carry, ine(b_.emit(op::CompositeExtract, U(), {s2, 1}), cu(0)));
    if (cc) set_cc_int(r, carry, 0, x);
    st_r(in.f(0, 8), r);
}

void Translator::op_iscadd(const Insn& in) {
    const bool is32i = in.name() == "iscadd32i";
    Id a = ld_r(in.f(8, 8));
    Id b = value(in, 0);
    const unsigned shift = is32i ? in.f(53, 5) : in.f(39, 5);
    const bool cc = is32i ? in.b(52) : in.b(47);
    if (!is32i) {
        if (in.b(49)) a = sub(cu(0), a);
        if (in.b(48)) b = sub(cu(0), b);
    }
    const Id sa = shl(a, cu(shift));
    const Id r = add(sa, b);
    if (cc) set_cc_int(r, ult(r, sa), 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_lea(const Insn& in) {
    const bool hi = in.has("N(\"hi\")");
    const unsigned dst = in.f(0, 8);
    const unsigned pdst = in.f(48, 3);
    Id a = ld_r(in.f(8, 8));
    Id r, carry;
    if (!hi) {
        const bool neg = in.b(45), x = in.b(46);
        if (neg) a = sub(cu(0), a);
        const Id b = value(in, 0);
        const Id sa = shl(a, cu(in.f(39, 5)));
        const Id s1 = b_.emit(op::IAddCarry, pair_type(), {sa, b});
        r = b_.emit(op::CompositeExtract, U(), {s1, 0});
        carry = b_.emit(op::CompositeExtract, U(), {s1, 1});
        if (x) {
            const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r, b2u(ld_flag(2))});
            r = b_.emit(op::CompositeExtract, U(), {s2, 0});
            carry = bor(carry, b_.emit(op::CompositeExtract, U(), {s2, 1}));
        }
    } else {
        const bool reg_form = (in.e->value >> 48) == 0x5bd8;
        const bool neg = reg_form ? in.b(37) : in.b(56);
        const bool x = reg_form ? in.b(38) : in.b(57);
        const unsigned s = reg_form ? in.f(28, 5) : in.f(51, 5);
        const Id b = value(in, 0);
        Id c = value(in, 1);
        if (neg) {   // P4.4 (model): the 64-bit value C:A negated, as LEA negates A
            warn(in, "LEA.HI con negación: se niega el valor de 64 bits C:A (modelo)");
            c = add(bnot(c), b2u(ieq(a, cu(0))));
            a = sub(cu(0), a);
        }
        // B + ((C:A) << s) >> 32
        const Id hiw = s == 0 ? c : bor(shl(c, cu(s)), shr(a, cu(32 - s)));
        const Id s1 = b_.emit(op::IAddCarry, pair_type(), {hiw, b});
        r = b_.emit(op::CompositeExtract, U(), {s1, 0});
        carry = b_.emit(op::CompositeExtract, U(), {s1, 1});
        if (x) {
            const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r, b2u(ld_flag(2))});
            r = b_.emit(op::CompositeExtract, U(), {s2, 0});
            carry = bor(carry, b_.emit(op::CompositeExtract, U(), {s2, 1}));
        }
    }
    const Id cbool = ine(carry, cu(0));
    if (in.b(47)) set_cc_int(r, cbool, 0);
    st_p(pdst, cbool);
    st_r(dst, r);
}

// High 32 bits of a 32x32 product with independent signedness; *lo_out gets the low word.
Id Translator::hi_mul(Id a, Id b, bool sa, bool sb, Id* lo_out) {
    const Id m = b_.emit(op::UMulExtended, pair_type(), {a, b});
    if (lo_out) *lo_out = b_.emit(op::CompositeExtract, U(), {m, 0});
    Id hi = b_.emit(op::CompositeExtract, U(), {m, 1});
    if (sa) hi = sub(hi, sel(e2(op::SLessThan, B(), a, cu(0)), b, cu(0)));
    if (sb) hi = sub(hi, sel(e2(op::SLessThan, B(), b, cu(0)), a, cu(0)));
    return hi;
}

void Translator::op_imad(const Insn& in) {
    const bool is32i = in.name() == "imad32i";
    const unsigned dst = in.f(0, 8);
    Id a = ld_r(in.f(8, 8));
    Id b = value(in, 0);
    Id c = is32i ? ld_r(dst) : value(in, 1);
    bool sa, sb, hi, sat = false, x = false, cc, neg_ab, neg_c;
    if (is32i) {
        sa = in.b(54); sb = in.b(57); hi = in.b(53); cc = in.b(52); neg_ab = in.b(56); neg_c = in.b(55);
    } else {
        sa = in.b(48); sb = in.b(53); hi = in.b(54); sat = in.b(50); x = in.b(49); cc = in.b(47);
        neg_ab = in.b(52); neg_c = in.b(51);
    }
    Id lo;
    const Id h = hi_mul(a, b, sa, sb, &lo);
    Id p = hi ? h : lo;
    if (neg_ab) p = sub(cu(0), p);
    if (neg_c) c = sub(cu(0), c);
    const Id s1 = b_.emit(op::IAddCarry, pair_type(), {p, c});
    Id r = b_.emit(op::CompositeExtract, U(), {s1, 0});
    Id carry = b_.emit(op::CompositeExtract, U(), {s1, 1});
    if (x) {
        const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r, b2u(ld_flag(2))});
        r = b_.emit(op::CompositeExtract, U(), {s2, 0});
        carry = bor(carry, b_.emit(op::CompositeExtract, U(), {s2, 1}));
    }
    const Id of = e2(op::SLessThan, B(), band(bxor(p, r), bxor(c, r)), cu(0));
    if (sat) r = sel(of, bxor(sar(p, cu(31)), cu(0x7fffffff)), r);
    if (cc) set_cc_int(r, ine(carry, cu(0)), of, x);
    st_r(dst, r);
}

void Translator::op_imul(const Insn& in) {
    const bool is32i = in.name() == "imul32i";
    const Id a = ld_r(in.f(8, 8)), b = value(in, 0);
    const bool sa = is32i ? in.b(54) : in.b(40);
    const bool sb = is32i ? in.b(55) : in.b(41);
    const bool hi = is32i ? in.b(53) : in.b(39);
    const bool cc = is32i ? in.b(52) : in.b(47);
    Id lo;
    const Id h = hi_mul(a, b, sa, sb, &lo);
    const Id r = hi ? h : lo;
    if (cc) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_xmad(const Insn& in) {
    const uint32_t top = static_cast<uint32_t>(in.e->value >> 48);
    const bool reg_form = top == 0x5b00, imm_form = top == 0x3600, cbufb = top == 0x4e00, cbufc = top == 0x5100;
    bool psl = false, mrg = false, x, h1b = false;
    unsigned cmode;
    if (reg_form || imm_form) {
        psl = in.b(36); mrg = in.b(37); cmode = in.f(50, 3); x = in.b(38);
        if (reg_form) h1b = in.b(35);
    } else {
        cmode = in.f(50, 2); x = in.b(54); h1b = in.b(52);
        if (cbufb) { psl = in.b(55); mrg = in.b(56); }
    }
    (void)cbufc;
    const bool sa = in.b(48), sb = in.b(49), h1a = in.b(53);
    const Id A = ld_r(in.f(8, 8));
    const Id Bv = value(in, 0);
    const Id C = value(in, 1);
    auto half = [&](Id v, bool h1, bool s) {
        if (s) return b_.emit(op::BitFieldSExtract, U(), {v, cu(h1 ? 16 : 0), cu(16)});
        return b_.emit(op::BitFieldUExtract, U(), {v, cu(h1 ? 16 : 0), cu(16)});
    };
    const Id a16 = half(A, h1a, sa);
    const Id b16 = imm_form ? half(Bv, false, sb) : half(Bv, h1b, sb);
    Id prod = e2(op::IMul, U(), a16, b16);
    if (psl) prod = shl(prod, cu(16));
    Id c = C;
    switch (cmode) {
        case 0: break;
        case 1: c = band(C, cu(0xffff)); break;                      // clo
        case 2: c = shr(C, cu(16)); break;                           // chi
        case 3: {                                                    // csfu
            const Id both = land(ine(a16, cu(0)), ine(b16, cu(0)));
            Id adj = cu(0);
            if (sa) adj = add(adj, sel(e2(op::SLessThan, B(), a16, cu(0)), cu(0x10000), cu(0)));
            if (sb) adj = add(adj, sel(e2(op::SLessThan, B(), b16, cu(0)), cu(0x10000), cu(0)));
            c = sub(C, sel(both, adj, cu(0)));
            break;
        }
        case 4:                                                      // cbcc
            c = add(C, shl(Bv, cu(16)));
            break;
        default: fail(in, "modo C de XMAD reservado"); return;
    }
    const Id s1 = b_.emit(op::IAddCarry, pair_type(), {prod, c});
    Id r = b_.emit(op::CompositeExtract, U(), {s1, 0});
    Id carry = b_.emit(op::CompositeExtract, U(), {s1, 1});
    if (x) {
        const Id s2 = b_.emit(op::IAddCarry, pair_type(), {r, b2u(ld_flag(2))});
        r = b_.emit(op::CompositeExtract, U(), {s2, 0});
        carry = bor(carry, b_.emit(op::CompositeExtract, U(), {s2, 1}));
    }
    if (mrg) r = bor(band(r, cu(0xffff)), shl(Bv, cu(16)));
    if (in.b(47)) set_cc_int(r, ine(carry, cu(0)), 0, x);
    st_r(in.f(0, 8), r);
}

void Translator::op_imnmx(const Insn& in) {
    if (in.f(43, 2) != 0) { op_imnmx_ext(in, in.f(43, 2)); return; }   // P4.4
    const bool s = in.b(48);
    const Id a = ld_r(in.f(8, 8)), b = value(in, 0);
    const Id p = ld_p(in.f(39, 3), in.b(42));
    const Id mn = ext(s ? glsl::SMin : glsl::UMin, U(), {a, b});
    const Id mx = ext(s ? glsl::SMax : glsl::UMax, U(), {a, b});
    const Id r = sel(p, mn, mx);
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

// P4.4: IMNMX.XHI / .XLO, the halves of a 64-bit minimum/maximum (Mesa's nv50_ir: XHI on the
// high words with the type's sign and .CC, then XLO on the low words, unsigned, with the flags).
// Model (warning): XHI leaves Z = (high words equal) and S = (a < b); XLO takes the min/max of the
// low words if Z and else the low word of the operand whose high word won. XMED: never emitted
// by Mesa or NAK, no public semantics.
void Translator::op_imnmx_ext(const Insn& in, uint32_t xm) {
    if (xm == 2) { fail(in, "IMNMX.XMED sin semántica pública (ni Mesa ni NAK la emiten)"); return; }
    warn(in, "IMNMX extendido (mitades de un mínimo/máximo de 64 bits como en Mesa): modelo");
    const bool s = in.b(48);
    const Id a = ld_r(in.f(8, 8)), b = value(in, 0);
    const Id p = ld_p(in.f(39, 3), in.b(42));   // true: minimum
    const Id mn = ext(s ? glsl::SMin : glsl::UMin, U(), {a, b});
    const Id mx = ext(s ? glsl::SMax : glsl::UMax, U(), {a, b});
    Id r;
    if (xm == 3) {
        r = sel(p, mn, mx);
        if (in.b(47)) {
            store(flag_var(0), ieq(a, b));
            store(flag_var(1), e2(s ? op::SLessThan : op::ULessThan, B(), a, b));
            store(flag_var(2), cb(false));
            store(flag_var(3), cb(false));
        }
    } else {
        const Id a_wins = selb(p, ld_flag(1), lnot(ld_flag(1)));
        r = sel(ld_flag(0), sel(p, mn, mx), sel(a_wins, a, b));
        if (in.b(47)) set_cc_int(r, 0, 0);
    }
    st_r(in.f(0, 8), r);
}

void Translator::op_lop(const Insn& in) {
    const bool is32i = in.name() == "lop32i";
    Id a = ld_r(in.f(8, 8));
    Id b = is32i ? cu(in.f(20, 32)) : value(in, 0);
    const unsigned lop = is32i ? in.f(53, 2) : in.f(41, 2);
    const bool inv_a = is32i ? in.b(55) : in.b(39);
    const bool inv_b = is32i ? in.b(56) : in.b(40);
    const bool cc = is32i ? in.b(52) : in.b(47);
    if (inv_a) a = bnot(a);
    if (inv_b) b = bnot(b);
    Id r;
    switch (lop) {
        case 0: r = band(a, b); break;
        case 1: r = bor(a, b); break;
        case 2: r = bxor(a, b); break;
        default: r = b; break;   // pass_b
    }
    if (!is32i) {
        const unsigned pop = in.f(44, 2), pd = in.f(48, 3);
        if (pd != kPT || pop != 0) {
            Id pv = cb(false);
            if (pop == 1) pv = cb(true);
            if (pop == 2) pv = ieq(r, cu(0));
            if (pop == 3) pv = ine(r, cu(0));
            st_p(pd, pv);
        }
    }
    if (cc) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_lop3(const Insn& in) {
    const uint32_t top = static_cast<uint32_t>(in.e->value >> 48);
    const bool reg_form = top == 0x5be0;
    const bool imm_form = (in.e->value >> 58) == (0x3c00ull >> 10);
    const unsigned lut = reg_form ? in.f(28, 8) : in.f(48, 8);
    const Id A = ld_r(in.f(8, 8));
    const Id Bv = value(in, 0);
    // The immediate form keeps C in REG_39 (envydis does not print it; see P4_1_INFORME.md).
    const Id C = imm_form ? ld_r(in.f(39, 8)) : value(in, 1);
    Id r = cu(0);
    if (lut == 0xff) r = cu(0xffffffff);
    else if (lut != 0) {
        const Id na = bnot(A), nb = bnot(Bv), nc = bnot(C);
        bool first = true;
        for (unsigned i = 0; i < 8; ++i) {
            if (!((lut >> i) & 1)) continue;
            const Id t = band(band((i & 4) ? A : na, (i & 2) ? Bv : nb), (i & 1) ? C : nc);
            r = first ? t : bor(r, t);
            first = false;
        }
    }
    if (reg_form) {
        const unsigned pop = in.f(36, 2), pd = in.f(48, 3);
        if (pd != kPT || pop != 0) {
            Id pv = cb(false);
            if (pop == 1) pv = cb(true);
            if (pop == 2) pv = ieq(r, cu(0));
            if (pop == 3) pv = ine(r, cu(0));
            st_p(pd, pv);
        }
    }
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_shifts(const Insn& in) {
    const std::string_view n = in.name();
    Id a = ld_r(in.f(8, 8));
    const Id s = value(in, 0);
    const bool wrap = in.b(39);
    Id r;
    if (n == "shl") {
        if (in.b(43)) warn(in, "SHL.X tratado como SHL");
        r = wrap ? shl(a, band(s, cu(31))) : safe_shl(a, s);
    } else {
        const bool sgn = in.b(48);
        if (in.b(44)) warn(in, "SHR.X tratado como SHR");
        if (in.b(40)) a = e1(op::BitReverse, U(), a);
        if (wrap) r = sgn ? sar(a, band(s, cu(31))) : shr(a, band(s, cu(31)));
        else r = sgn ? safe_sar(a, s) : safe_shr(a, s);
    }
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_shf(const Insn& in) {
    const bool left = in.has("N(\"l\")");
    const bool wrap = in.b(50);
    const unsigned type = in.f(37, 2);   // 0: 32-bit, 2: u64, 3: s64
    const unsigned hx = in.f(48, 2);     // bit 48: hi
    const bool want_hi = hx & 1;
    if (hx & 2) warn(in, "SHF.X tratado como SHF");
    const bool is64 = type >= 2, sgn = type == 3;
    const Id A = ld_r(in.f(8, 8));   // low word
    const Id C = ld_r(in.f(39, 8));  // high word
    Id s = value(in, 0);
    if (wrap) s = band(s, cu(is64 ? 63 : 31));
    else s = ext(glsl::UMin, U(), {s, cu(is64 ? 64 : 32)});
    const Id s31 = band(s, cu(31));
    const Id ge32 = uge(s, cu(32)), ge64 = uge(s, cu(64)), zero = ieq(s, cu(0));
    const Id inv = band(sub(cu(32), s31), cu(31));   // 32 - s for 0 < s < 32
    Id lo, hi;
    if (left) {
        // {C:A} << s
        const Id lo_small = shl(A, s31);
        const Id hi_small = sel(ieq(s31, cu(0)), C, bor(shl(C, s31), shr(A, inv)));
        lo = sel(ge32, cu(0), lo_small);
        hi = sel(ge64, cu(0), sel(ge32, shl(A, s31), hi_small));
        (void)zero;
    } else {
        const Id fill = sgn ? sar(C, cu(31)) : cu(0);
        const Id hi_shift = sgn ? sar(C, s31) : shr(C, s31);
        const Id lo_small = sel(ieq(s31, cu(0)), A, bor(shr(A, s31), shl(C, inv)));
        lo = sel(ge64, fill, sel(ge32, hi_shift, lo_small));
        hi = sel(ge32, fill, hi_shift);
    }
    const Id r = want_hi ? hi : lo;
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_bitfield(const Insn& in) {
    const std::string_view n = in.name();
    const unsigned dst = in.f(0, 8);
    if (n == "popc") {
        Id v = value(in, 0);
        if (in.b(40)) v = bnot(v);
        st_r(dst, e1(op::BitCount, U(), v));
        return;
    }
    if (n == "flo") {
        Id v = value(in, 0);
        const bool sgn = in.b(48);
        if (in.b(40)) v = bnot(v);
        Id r = ext(sgn ? glsl::FindSMsb : glsl::FindUMsb, U(), {v});
        if (in.b(41)) r = sel(ieq(r, cu(0xffffffff)), r, sub(cu(31), r));
        if (in.b(47)) set_cc_int(r, 0, 0);
        st_r(dst, r);
        return;
    }
    if (n == "bfe") {
        Id a = ld_r(in.f(8, 8));
        const Id bv = value(in, 0);
        const bool sgn = in.b(48);
        if (in.b(40)) a = e1(op::BitReverse, U(), a);
        const Id pos = band(bv, cu(0xff));
        const Id len = band(shr(bv, cu(8)), cu(0xff));
        // pos >= 32: sign fill / 0. Otherwise extract min(len, 32 - pos) bits.
        const Id pos_ok = ult(pos, cu(32));
        const Id p31 = band(pos, cu(31));
        const Id avail = sub(cu(32), p31);
        const Id n_eff = ext(glsl::UMin, U(), {len, avail});
        const Id shifted = sgn ? sar(a, p31) : shr(a, p31);
        // keep n_eff bits (n_eff in 1..32), sign-extend when signed
        const Id lshift = band(sub(cu(32), n_eff), cu(31));
        const Id full = ieq(n_eff, cu(32));
        Id ext_v = sgn ? sar(shl(shifted, lshift), lshift) : shr(shl(shifted, lshift), lshift);
        ext_v = sel(full, shifted, ext_v);
        const Id fill = sgn ? sar(a, cu(31)) : cu(0);
        Id r = sel(pos_ok, ext_v, fill);
        r = sel(ieq(len, cu(0)), cu(0), r);
        if (in.b(47)) set_cc_int(r, 0, 0);
        st_r(dst, r);
        return;
    }
    if (n == "bfi") {
        const Id ins = ld_r(in.f(8, 8));
        const Id bv = value(in, 0);
        const Id base = value(in, 1);
        const Id pos = band(bv, cu(0xff));
        const Id len = band(shr(bv, cu(8)), cu(0xff));
        const Id pos_ok = ult(pos, cu(32));
        const Id p31 = band(pos, cu(31));
        const Id n_eff = ext(glsl::UMin, U(), {len, sub(cu(32), p31)});
        const Id ones = sel(uge(n_eff, cu(32)), cu(0xffffffff), sub(shl(cu(1), band(n_eff, cu(31))), cu(1)));
        const Id mask = shl(ones, p31);
        Id r = bor(band(base, bnot(mask)), band(shl(ins, p31), mask));
        r = sel(pos_ok, r, base);
        if (in.b(47)) set_cc_int(r, 0, 0);
        st_r(dst, r);
        return;
    }
}

void Translator::op_prmt(const Insn& in) {
    const Id A = ld_r(in.f(8, 8));
    const Id sel_v = value(in, 0);
    const Id C = value(in, 1);
    const unsigned mode = in.f(48, 4);
    if (mode > 6) { fail(in, "modo de PRMT reservado"); return; }
    auto byte_of = [&](Id idx) {   // byte idx (0..7) of {C:A}
        const Id i7 = band(idx, cu(7));
        const Id word = sel(ult(i7, cu(4)), A, C);
        return band(shr(word, shl(band(i7, cu(3)), cu(3))), cu(0xff));
    };
    Id r = cu(0);
    const Id s = band(sel_v, cu(3));
    for (unsigned i = 0; i < 4; ++i) {
        Id byte;
        switch (mode) {
            case 0: {
                const Id nib = band(shr(sel_v, cu(4 * i)), cu(0xf));
                byte = byte_of(nib);
                const Id msb = ine(band(nib, cu(8)), cu(0));
                const Id rep = sel(ine(band(byte, cu(0x80)), cu(0)), cu(0xff), cu(0));
                byte = sel(msb, rep, byte);
                break;
            }
            case 1: byte = byte_of(add(s, cu(i))); break;                          // f4e
            case 2: byte = byte_of(sub(s, cu(i))); break;                          // b4e
            case 3: byte = byte_of(s); break;                                      // rc8
            case 4: byte = byte_of(ext(glsl::UMax, U(), {s, cu(i)})); break;        // ecl
            case 5: byte = byte_of(ext(glsl::UMin, U(), {s, cu(i)})); break;        // ecr
            default: byte = byte_of(add(shl(band(s, cu(1)), cu(1)), cu(i & 1))); break;   // rc16
        }
        r = bor(r, shl(byte, cu(8 * i)));
    }
    st_r(in.f(0, 8), r);
}

void Translator::op_isetp(const Insn& in) {
    const std::string_view n = in.name();
    const unsigned cond = in.f(49, 3);
    const bool sgn = in.b(48), x = in.b(43);
    const Id a = ld_r(in.f(8, 8));
    if (n == "icmp") {
        const Id b = value(in, 0), c = value(in, 1);
        const Id t = icmp(cond, sgn, c, cu(0));
        st_r(in.f(0, 8), sel(t, a, b));
        return;
    }
    const Id b = value(in, 0);
    const Id t = x ? icmp_x(cond, sgn, a, b) : icmp(cond, sgn, a, b);
    const unsigned bop = in.f(45, 2);
    const Id p = ld_p(in.f(39, 3), in.b(42));
    if (n == "isetp") {
        st_p(in.f(3, 3), bool_op(bop, t, p));
        st_p(in.f(0, 3), bool_op(bop, lnot(t), p));
        return;
    }
    // iset
    const Id res = bool_op(bop, t, p);
    const Id r = sel(res, in.b(44) ? cu(0x3f800000) : cu(0xffffffff), cu(0));
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

// =====================================================================================
// Float ALU
// =====================================================================================
void Translator::op_fadd(const Insn& in) {
    const bool is32i = in.name() == "fadd32i";
    Id a = tof(ld_r(in.f(8, 8)));
    Id b = tof(is32i ? cu(in.f(20, 32)) : value(in, 0));
    bool na, aa, nb, ab, ftz_, sat = false, cc;
    unsigned rnd = 0;
    if (is32i) { na = in.b(56); aa = in.b(54); nb = in.b(53); ab = in.b(57); ftz_ = in.b(55); cc = in.b(52); }
    else { na = in.b(48); aa = in.b(46); nb = in.b(45); ab = in.b(49); ftz_ = in.b(44); sat = in.b(50); cc = in.b(47); rnd = in.f(39, 2); }
    if (rnd) warn(in, "modo de redondeo no RN aproximado con RN");
    if (ftz_) { a = ftz(a); b = ftz(b); }
    a = fneg_abs(a, na, aa);
    b = fneg_abs(b, nb, ab);
    Id r = e2(op::FAdd, F(), a, b);
    if (ftz_) r = ftz(r);
    if (sat) r = fsat(r);
    if (cc) set_cc_float(r);
    st_r(in.f(0, 8), tou(r));
}

void Translator::op_fmul(const Insn& in) {
    const bool is32i = in.name() == "fmul32i";
    Id a = tof(ld_r(in.f(8, 8)));
    Id b = tof(is32i ? cu(in.f(20, 32)) : value(in, 0));
    unsigned fz, scale = 0, rnd = 0;
    bool neg = false, sat, cc;
    if (is32i) { fz = in.f(53, 2); sat = in.b(55); cc = in.b(52); }
    else { fz = in.f(44, 2); scale = in.f(41, 3); rnd = in.f(39, 2); neg = in.b(48); sat = in.b(50); cc = in.b(47); }
    if (rnd) warn(in, "modo de redondeo no RN aproximado con RN");
    if (fz) { a = ftz(a); b = ftz(b); }
    if (neg) b = e1(op::FNegate, F(), b);
    Id r = e2(op::FMul, F(), a, b);
    static const float scales[8] = {1.f, 0.5f, 0.25f, 0.125f, 8.f, 4.f, 2.f, 1.f};
    if (scale == 7) { fail(in, "escala de FMUL reservada"); return; }
    if (scale) r = e2(op::FMul, F(), r, cf(scales[scale]));
    if (fz == 2) {   // FMZ: 0 * anything = +0
        const Id z = lor(e2(op::FOrdEqual, B(), a, cf(0.f)), e2(op::FOrdEqual, B(), b, cf(0.f)));
        r = sel(z, cf(0.f), r, F());
    }
    if (fz) r = ftz(r);
    if (sat) r = fsat(r);
    if (cc) set_cc_float(r);
    st_r(in.f(0, 8), tou(r));
}

void Translator::op_ffma(const Insn& in) {
    const bool is32i = in.name() == "ffma32i";
    const unsigned dst = in.f(0, 8);
    Id a = tof(ld_r(in.f(8, 8)));
    Id b = tof(is32i ? cu(in.f(20, 32)) : value(in, 0));
    Id c = tof(is32i ? ld_r(dst) : value(in, 1));
    const unsigned fz = in.f(53, 2);
    bool neg_ab, neg_c, sat, cc;
    unsigned rnd = 0;
    if (is32i) { neg_ab = in.b(56); neg_c = in.b(57); sat = in.b(55); cc = in.b(52); }
    else { neg_ab = in.b(48); neg_c = in.b(49); sat = in.b(50); cc = in.b(47); rnd = in.f(51, 2); }
    if (rnd) warn(in, "modo de redondeo no RN aproximado con RN");
    if (fz) { a = ftz(a); b = ftz(b); c = ftz(c); }
    if (neg_ab) b = e1(op::FNegate, F(), b);
    if (neg_c) c = e1(op::FNegate, F(), c);
    Id r = ext(glsl::Fma, F(), {a, b, c});
    if (fz == 2) {
        const Id z = lor(e2(op::FOrdEqual, B(), a, cf(0.f)), e2(op::FOrdEqual, B(), b, cf(0.f)));
        r = sel(z, e2(op::FAdd, F(), cf(0.f), c), r, F());
    }
    if (fz) r = ftz(r);
    if (sat) r = fsat(r);
    if (cc) set_cc_float(r);
    st_r(dst, tou(r));
}

void Translator::op_fmnmx(const Insn& in) {
    Id a = tof(ld_r(in.f(8, 8)));
    Id b = tof(value(in, 0));
    if (in.b(44)) { a = ftz(a); b = ftz(b); }
    a = fneg_abs(a, in.b(48), in.b(46));
    b = fneg_abs(b, in.b(45), in.b(49));
    const Id p = ld_p(in.f(39, 3), in.b(42));
    // Maxwell returns the non-NaN operand (IEEE 754-2008 minNum/maxNum): NMin/NMax.
    const Id r = sel(p, ext(glsl::NMin, F(), {a, b}), ext(glsl::NMax, F(), {a, b}), F());
    if (in.b(47)) set_cc_float(r);
    st_r(in.f(0, 8), tou(r));
}

void Translator::op_fsetp(const Insn& in) {
    const std::string_view n = in.name();
    const unsigned cond = in.f(48, 4);
    Id a = tof(ld_r(in.f(8, 8)));
    if (n == "fcmp") {
        const Id b = value(in, 0);
        Id c = tof(value(in, 1));
        if (in.b(47)) c = ftz(c);
        const Id t = fcmp(cond, c, cf(0.f));
        st_r(in.f(0, 8), sel(t, tou(a), b));
        return;
    }
    Id b = tof(value(in, 0));
    const bool is_set = n == "fset";
    const bool ftz_ = is_set ? in.b(55) : in.b(47);
    if (ftz_) { a = ftz(a); b = ftz(b); }
    if (is_set) {
        a = fneg_abs(a, in.b(43), in.b(54));
        b = fneg_abs(b, in.b(53), in.b(44));
    } else {
        a = fneg_abs(a, in.b(43), in.b(7));
        b = fneg_abs(b, in.b(6), in.b(44));
    }
    const Id t = fcmp(cond, a, b);
    const unsigned bop = in.f(45, 2);
    const Id p = ld_p(in.f(39, 3), in.b(42));
    if (!is_set) {
        st_p(in.f(3, 3), bool_op(bop, t, p));
        st_p(in.f(0, 3), bool_op(bop, lnot(t), p));
        return;
    }
    const Id res = bool_op(bop, t, p);
    const Id r = sel(res, in.b(52) ? cu(0x3f800000) : cu(0xffffffff), cu(0));
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

// MUFU model (P4_1_INFORME.md): denormal inputs and results flush to zero (the hardware unit
// is FTZ); the special cases are explicit because SPIR-V/Vulkan leave them undefined
// (log2(0), 1/0, exp2(NaN)...); SIN/COS reduce the argument to [-pi, pi] first (the RRO + MUFU
// pair works on the fraction of x / 2pi), so drivers only see the range where their precision is
// defined. RRO itself is a pass-through.
void Translator::op_mufu(const Insn& in) {
    const unsigned fn = in.f(20, 4);
    if (fn == 6 || fn == 7) { op_mufu64(in, fn); return; }   // P4.4: RCP64H / RSQ64H (translate_fp64.inc)
    Id a = ftz(fneg_abs(tof(ld_r(in.f(8, 8))), in.b(48), in.b(46)));
    const Id nan = tof(cu(0x7fffffff));
    const Id inf = cf(std::numeric_limits<float>::infinity());
    const Id is_nan = e1(op::IsNan, B(), a), is_inf = e1(op::IsInf, B(), a);
    const Id is_zero = e2(op::FOrdEqual, B(), a, cf(0.f));
    const Id is_neg = e2(op::FOrdLessThan, B(), a, cf(0.f));
    const Id signed_inf = tof(bor(band(tou(a), cu(0x80000000)), cu(0x7f800000)));
    const Id signed_zero = tof(band(tou(a), cu(0x80000000)));
    Id r;
    switch (fn) {
        case 0: case 1: {
            const float two_pi = 6.28318530717958647692f, inv_two_pi = 0.159154943091895335769f;
            // fraction of x / 2pi (0 once |x / 2pi| >= 2^23, where floats have no fraction left)
            const Id y = e2(op::FMul, F(), a, cf(inv_two_pi));
            const Id red = e2(op::FMul, F(), e2(op::FSub, F(), y, ext(glsl::RoundEven, F(), {y})), cf(two_pi));
            r = ext(fn == 0 ? glsl::Cos : glsl::Sin, F(), {red});
            r = sel(lor(is_nan, is_inf), nan, r, F());
            break;
        }
        case 2:
            r = sel(is_nan, nan, ext(glsl::Exp2, F(), {a}), F());
            break;
        case 3:
            r = ext(glsl::Log2, F(), {a});
            r = sel(is_inf, a, r, F());                                   // +inf (-inf is < 0 below)
            r = sel(is_zero, e1(op::FNegate, F(), inf), r, F());
            r = sel(lor(is_neg, is_nan), nan, r, F());
            break;
        case 4:
            r = e2(op::FDiv, F(), cf(1.f), a);
            r = sel(is_zero, signed_inf, sel(is_inf, signed_zero, r, F()), F());
            r = sel(is_nan, nan, r, F());
            break;
        case 5:
            r = ext(glsl::InverseSqrt, F(), {a});
            r = sel(is_inf, cf(0.f), r, F());
            r = sel(is_zero, signed_inf, r, F());
            r = sel(lor(land(is_neg, lnot(is_zero)), is_nan), nan, r, F());
            break;
        case 8:
            r = ext(glsl::Sqrt, F(), {a});
            r = sel(lor(is_zero, is_inf), a, r, F());
            r = sel(lor(land(is_neg, lnot(is_zero)), is_nan), nan, r, F());
            break;
        default: fail(in, "MUFU " + std::to_string(fn) + " (doble precisión o reservado) fuera de P4.1"); return;
    }
    r = ftz(r);
    if (in.b(50)) r = fsat(r);
    st_r(in.f(0, 8), tou(r));
}

void Translator::op_f2f(const Insn& in) {
    const unsigned dt = in.f(8, 2), st = in.f(10, 2);
    const unsigned mode = in.f(39, 2);
    const bool to_int = in.b(42);
    if (dt == 0 || st == 0) { fail(in, "F2F con tipo reservado (código 0): sin semántica pública"); return; }
    if (dt == 3 || st == 3) { fail(in, "F2F con f64 fuera de P4.1"); return; }   // (conv64 takes them)
    Id v = value(in, 0);
    Id f;
    if (st == 1) {   // f16 source: low half, or high half with bit 41
        const Id h = in.b(41) ? shr(v, cu(16)) : band(v, cu(0xffff));
        const Id v2 = ext(glsl::UnpackHalf2x16, b_.t_vec(F(), 2), {h});
        f = b_.emit(op::CompositeExtract, F(), {v2, 0});
    } else {
        f = tof(v);
    }
    if (in.b(44)) f = ftz(f);
    f = fneg_abs(f, in.b(45), in.b(49));
    if (to_int) {
        switch (mode) {
            case 0: f = ext(glsl::RoundEven, F(), {f}); break;
            case 1: f = ext(glsl::Floor, F(), {f}); break;
            case 2: f = ext(glsl::Ceil, F(), {f}); break;
            default: f = ext(glsl::Trunc, F(), {f}); break;
        }
    } else if (mode != 0 && !(mode == 3 && st == dt)) {
        warn(in, "modo de redondeo de F2F no RN aproximado con RN");
    }
    if (in.b(50)) f = fsat(f);
    if (in.b(44)) f = ftz(f);
    const Id r = dt == 1 ? to_half(f) : tou(f);
    if (in.b(47)) set_cc_float(f);
    st_r(in.f(0, 8), r);
}

void Translator::op_f2i(const Insn& in) {
    const unsigned isz = in.f(8, 2), st = in.f(10, 2);
    const bool sgn = in.b(12);
    if (st == 0) { fail(in, "F2I con tipo de fuente reservado (código 0): sin semántica pública"); return; }
    if (isz == 3 || st == 3) { fail(in, "F2I con 64 bits fuera de P4.1"); return; }   // (conv64 takes them)
    Id f;
    if (st == 1) {   // P4.4: an f16 source (half selected by bit 41, as in F2F), exact in f32
        const Id v = value(in, 0);
        const Id h = in.b(41) ? shr(v, cu(16)) : band(v, cu(0xffff));
        f = b_.emit(op::CompositeExtract, F(), {ext(glsl::UnpackHalf2x16, b_.t_vec(F(), 2), {h}), 0});
        if (in.b(44)) {   // FTZ: f16 subnormals
            const Id small = e2(op::FOrdLessThan, B(), ext(glsl::FAbs, F(), {f}), cf(6.103515625e-05f));
            f = b_.emit(op::Select, F(), {small, e2(op::FMul, F(), f, cf(0.0f)), f});
        }
    } else {
        f = tof(value(in, 0));
        if (in.b(44)) f = ftz(f);
    }
    f = fneg_abs(f, in.b(45), in.b(49));
    switch (in.f(39, 2)) {
        case 0: f = ext(glsl::RoundEven, F(), {f}); break;
        case 1: f = ext(glsl::Floor, F(), {f}); break;
        case 2: f = ext(glsl::Ceil, F(), {f}); break;
        default: f = ext(glsl::Trunc, F(), {f}); break;
    }
    // Saturating conversion (NaN -> 0), as the hardware does.
    double lo_d, hi_d;
    uint32_t lo_i, hi_i;
    const unsigned width = isz == 0 ? 8 : isz == 1 ? 16 : 32;
    if (sgn) {
        lo_d = -static_cast<double>(1ull << (width - 1));
        hi_d = static_cast<double>((1ull << (width - 1)) - 1);
        lo_i = static_cast<uint32_t>(-(int64_t{1} << (width - 1)));
        hi_i = static_cast<uint32_t>((uint64_t{1} << (width - 1)) - 1);
    } else {
        lo_d = 0;
        hi_d = static_cast<double>((1ull << width) - 1);
        lo_i = 0;
        hi_i = static_cast<uint32_t>((uint64_t{1} << width) - 1);
    }
    const Id is_nan = e1(op::IsNan, B(), f);
    const Id below = e2(op::FOrdLessThanEqual, B(), f, cf(static_cast<float>(lo_d)));
    // hi_d may not be representable (2^31-1): compare with >= 2^31 (or 2^32) instead.
    const Id above = e2(op::FOrdGreaterThanEqual, B(), f, cf(static_cast<float>(hi_d + 1.0)));
    const Id clamped = sel(below, cf(static_cast<float>(lo_d)), f, F());
    const Id conv = sgn ? b_.emit(op::ConvertFToS, U(), {sel(above, cf(0.f), clamped, F())})
                        : b_.emit(op::ConvertFToU, U(), {sel(above, cf(0.f), clamped, F())});
    Id r = sel(above, cu(hi_i), sel(below, cu(lo_i), conv));
    r = sel(is_nan, cu(0), r);
    if (in.b(47)) set_cc_int(r, 0, 0);
    st_r(in.f(0, 8), r);
}

void Translator::op_i2f(const Insn& in) {
    const unsigned dt = in.f(8, 2);
    const unsigned isz = in.f(10, 2);
    const bool sgn = in.b(13);
    if (dt == 0) { fail(in, "I2F con tipo de destino reservado (código 0): sin semántica pública"); return; }
    if (dt == 3 || isz == 3) { fail(in, "I2F con 64 bits fuera de P4.1"); return; }   // (conv64 takes them)
    if (in.f(39, 2)) warn(in, "modo de redondeo de I2F no RN aproximado con RN");
    Id v = value(in, 0);
    const unsigned bsel = in.f(41, 2);
    if (isz == 0) v = b_.emit(sgn ? op::BitFieldSExtract : op::BitFieldUExtract, U(), {v, cu(8 * bsel), cu(8)});
    else if (isz == 1) v = b_.emit(sgn ? op::BitFieldSExtract : op::BitFieldUExtract, U(), {v, cu(8 * (bsel & 2)), cu(16)});
    if (in.b(49) && sgn) v = ext(glsl::SAbs, U(), {v});
    if (in.b(45)) v = sub(cu(0), v);
    Id f;
    if (sgn) {
        // operand typed s32: some drivers (SwiftShader) fold a u32-typed constant as unsigned
        f = b_.emit(op::ConvertSToF, F(), {e1(op::Bitcast, S(), v)});
    } else {
        // u32 -> f32 correctly rounded on any driver: hi * 65536 and lo are exact, the add rounds once
        const Id hi = b_.emit(op::ConvertUToF, F(), {shr(v, cu(16))});
        const Id lo = b_.emit(op::ConvertUToF, F(), {band(v, cu(0xffff))});
        f = e2(op::FAdd, F(), e2(op::FMul, F(), hi, cf(65536.f)), lo);
    }
    const Id r = dt == 1 ? to_half(f) : tou(f);
    if (in.b(47)) set_cc_float(f);
    st_r(in.f(0, 8), r);
}

void Translator::op_i2i(const Insn& in) {
    const unsigned dsz = in.f(8, 2), ssz = in.f(10, 2);
    const bool dsg = in.b(12), ssg = in.b(13);
    if (dsz == 3 || ssz == 3) { fail(in, "I2I de 64 bits sin semántica pública (ni Mesa ni NAK la emiten)"); return; }
    Id v = value(in, 0);
    const unsigned bsel = in.f(41, 2);
    const unsigned sw = ssz == 0 ? 8 : ssz == 1 ? 16 : 32;
    if (sw < 32)
        v = b_.emit(ssg ? op::BitFieldSExtract : op::BitFieldUExtract, U(), {v, cu(sw == 8 ? 8 * bsel : 8 * (bsel & 2)), cu(sw)});
    if (in.b(49) && ssg) v = ext(glsl::SAbs, U(), {v});
    if (in.b(45)) v = sub(cu(0), v);
    const unsigned dw = dsz == 0 ? 8 : dsz == 1 ? 16 : 32;
    const bool src_signed = ssg || in.b(45);
    if (in.b(50)) {   // saturate to the destination range
        int64_t lo = dsg ? -(int64_t{1} << (dw - 1)) : 0;
        int64_t hi = dsg ? (int64_t{1} << (dw - 1)) - 1 : (int64_t{1} << dw) - 1;
        if (src_signed) {
            if (dsg) {
                v = ext(glsl::SMax, U(), {v, cu(static_cast<uint32_t>(lo))});
                v = ext(glsl::SMin, U(), {v, cu(static_cast<uint32_t>(hi))});
            } else {
                v = ext(glsl::SMax, U(), {v, cu(0)});
                if (dw < 32) v = ext(glsl::UMin, U(), {v, cu(static_cast<uint32_t>(hi))});
            }
        } else {
            v = ext(glsl::UMin, U(), {v, cu(static_cast<uint32_t>(hi))});
        }
    }
    if (dw < 32) v = b_.emit(dsg ? op::BitFieldSExtract : op::BitFieldUExtract, U(), {v, cu(0), cu(dw)});
    if (in.b(47)) set_cc_int(v, 0, 0);
    st_r(in.f(0, 8), v);
}

// =====================================================================================
// Predicates
// =====================================================================================
void Translator::op_pred(const Insn& in) {
    const std::string_view n = in.name();
    if (n == "psetp" || n == "pset") {
        const Id a = ld_p(in.f(12, 3), in.b(15));
        const Id bb = ld_p(in.f(29, 3), in.b(32));
        const Id c = ld_p(in.f(39, 3), in.b(42));
        const Id ab = bool_op(in.f(24, 2), a, bb);
        const unsigned bop2 = in.f(45, 2);
        if (n == "psetp") {
            st_p(in.f(3, 3), bool_op(bop2, ab, c));
            st_p(in.f(0, 3), bool_op(bop2, lnot(ab), c));
        } else {
            const Id r = sel(bool_op(bop2, ab, c), in.b(44) ? cu(0x3f800000) : cu(0xffffffff), cu(0));
            if (in.b(47)) set_cc_int(r, 0, 0);
            st_r(in.f(0, 8), r);
        }
        return;
    }
    const unsigned byte = in.f(41, 2);
    const Id mask = band(value(in, 0), cu(0xff));
    if (in.b(40)) {   // P4.4: .CC: the flags Z S C O (bits 0-3, envytools' order of $c) instead of P0-P6
        warn(in, "P2R/R2P sobre CC: los flags Z, S, C y O como bits 0-3 (modelo)");
        if (n == "p2r") {
            Id packed = cu(0);
            for (unsigned i = 0; i < 4; ++i) packed = bor(packed, shl(b2u(ld_flag(static_cast<int>(i))), cu(i)));
            const Id m = shl(mask, cu(8 * byte));
            const Id a = ld_r(in.f(8, 8));
            st_r(in.f(0, 8), bor(band(a, bnot(m)), band(shl(packed, cu(8 * byte)), m)));
            return;
        }
        const Id a = ld_r(in.f(8, 8));
        for (unsigned i = 0; i < 4; ++i) {
            const Id on = ine(band(mask, cu(1u << i)), cu(0));
            const Id v = ine(band(a, cu(1u << (8 * byte + i))), cu(0));
            store(flag_var(static_cast<int>(i)), selb(on, v, ld_flag(static_cast<int>(i))));
        }
        return;
    }
    if (n == "p2r") {
        Id packed = cu(0);
        for (unsigned i = 0; i < 7; ++i) packed = bor(packed, shl(b2u(ld_p(i)), cu(i)));
        packed = bor(packed, cu(0x80));   // PT
        const Id m = shl(mask, cu(8 * byte));
        const Id a = ld_r(in.f(8, 8));
        st_r(in.f(0, 8), bor(band(a, bnot(m)), band(shl(packed, cu(8 * byte)), m)));
        return;
    }
    // r2p
    const Id a = ld_r(in.f(8, 8));
    for (unsigned i = 0; i < 7; ++i) {
        const Id on = ine(band(mask, cu(1u << i)), cu(0));
        const Id v = ine(band(a, cu(1u << (8 * byte + i))), cu(0));
        st_p(i, selb(on, v, ld_p(i)));
    }
}

// =====================================================================================
// Memory instructions
// =====================================================================================
void Translator::op_mem(const Insn& in) {
    const std::string_view n = in.name();
    const unsigned dst = in.f(0, 8);
    const unsigned areg = in.f(8, 8);
    // ---- LDC ----
    if (n == "ld" && in.has("C36_08_S16_20")) {
        const unsigned mode = in.f(44, 2);
        if (mode == 1 || mode == 3) { fail(in, "LDC.IL/.ISL sin semántica pública (NAK no los emite)"); return; }
        const unsigned bank = in.f(36, 5);
        const unsigned size = in.f(48, 3);
        if (mode == 2) {   // P4.4: LDC.IS (NAK): bank = imm + R[31:16], offset = imm + R[15:0]
            const Id r = ld_r(areg);
            const Id dyn_bank = add(cu(bank), shr(r, cu(16)));
            const Id addr = add(band(r, cu(0xffff)), cu(static_cast<uint32_t>(sext(in.f(20, 16), 16))));
            load_words(in, dst, size, [&](Id a) {
                Id v = cu(0);
                for (const CbufBinding& cb : info_.cbufs)
                    if (cbuf_banks_.count(cb.bank)) v = sel(ieq(dyn_bank, cu(cb.bank)), cbuf_load_dyn(cb.bank, a), v);
                return v;
            }, addr);
            return;
        }
        const Id addr = add(ld_r(areg), cu(static_cast<uint32_t>(sext(in.f(20, 16), 16))));
        load_words(in, dst, size, [&](Id a) { return cbuf_load_dyn(bank, a); }, addr);
        return;
    }
    if (in.has("AMEM")) { op_attr(in); return; }
    // ---- shared ----
    if (in.has("SMEM")) {
        if (!shared_) { fail(in, "memoria compartida sin tamaño en ShaderInfo"); return; }
        const unsigned size = in.f(48, 3);
        const Id addr = add(ld_r(areg), cu(static_cast<uint32_t>(sext(in.f(20, 24), 24))));
        if (shared64_) {   // P4.4: 64-bit words
            if (n == "ld") {
                load_words(in, dst, size, [&](Id a) { return shared64_load(a); }, addr);
            } else if (size <= 3) {
                const unsigned w = size >= 2 ? 16 : 8;
                const Id shift = shl(band(addr, cu(w == 16 ? 2 : 3)), cu(3));
                const Id mask = shl(cu(w == 16 ? 0xffff : 0xff), shift);
                shared64_store(addr, shl(ld_r(dst), shift), mask);
            } else {
                const unsigned cnt = size == 4 ? 1 : size == 5 ? 2 : 4;
                for (unsigned i = 0; i < cnt; ++i)
                    shared64_store(add(addr, cu(4 * i)), ld_r(dst == kRZ ? kRZ : dst + i), cu(0xffffffffu));
            }
            return;
        }
        if (n == "ld") {
            load_words(in, dst, size, [&](Id a) { return load(U(), shared_ptr(a)); }, addr);
        } else {
            if (size <= 3) {
                const unsigned w = size >= 2 ? 16 : 8;
                const Id shift = shl(band(addr, cu(w == 16 ? 2 : 3)), cu(3));
                const Id mask = shl(cu(w == 16 ? 0xffff : 0xff), shift);
                const Id v = band(shl(ld_r(dst), shift), mask);
                const Id p = shared_ptr(addr);
                b_.emit(op::AtomicAnd, U(), {p, cu(spirv::scope::Workgroup), cu(0), bnot(mask)});
                b_.emit(op::AtomicOr, U(), {p, cu(spirv::scope::Workgroup), cu(0), v});
            } else {
                const unsigned cnt = size == 4 ? 1 : size == 5 ? 2 : 4;
                for (unsigned i = 0; i < cnt; ++i)
                    store(shared_ptr(add(addr, cu(4 * i))), ld_r(dst == kRZ ? kRZ : dst + i));
            }
        }
        return;
    }
    // ---- local ----
    if (in.has("LMEM")) {
        if (!local_) { fail(in, "memoria local sin tamaño en ShaderInfo"); return; }
        const unsigned size = in.f(48, 3);
        const Id addr = add(ld_r(areg), cu(static_cast<uint32_t>(sext(in.f(20, 24), 24))));
        if (n == "ld") {
            load_words(in, dst, size, [&](Id a) { return load(U(), local_ptr(a)); }, addr);
        } else {
            if (size <= 3) {
                const unsigned w = size >= 2 ? 16 : 8;
                const Id shift = shl(band(addr, cu(w == 16 ? 2 : 3)), cu(3));
                const Id mask = shl(cu(w == 16 ? 0xffff : 0xff), shift);
                const Id p = local_ptr(addr);
                const Id old = load(U(), p);
                store(p, bor(band(old, bnot(mask)), band(shl(ld_r(dst), shift), mask)));
            } else {
                const unsigned cnt = size == 4 ? 1 : size == 5 ? 2 : 4;
                for (unsigned i = 0; i < cnt; ++i)
                    store(local_ptr(add(addr, cu(4 * i))), ld_r(dst == kRZ ? kRZ : dst + i));
            }
        }
        return;
    }
    // ---- global: ldg/stg (NCGMEM, e at 45) and generic ld/st (GMEM, e at 52) ----
    bool e;
    int32_t imm;
    unsigned size;
    if (n == "ldg" || n == "stg") {
        if (in.has("NCGMEM_20")) {
            warn(in, "LDG predicado: se emite carga; predicado de destino ignorado (best-effort)");
        }
        e = in.b(45);
        imm = sext(in.f(20, 24), 24);
        size = in.f(48, 3);
    } else if (in.has("GMEM")) {
        e = in.b(52);
        imm = static_cast<int32_t>(in.f(20, 32));
        size = in.f(53, 3);
        if (in.f(58, 3) != kPT) { fail(in, "LD/ST genérico con predicado sin semántica pública (ni Mesa ni NAK lo emiten)"); return; }
    } else {
        fail(in, "forma de acceso a memoria fuera de P4.1");
        return;
    }
    Id hi;
    const Id lo = gaddr_lo(in, areg, imm, e, &hi);
    const bool is_load = n == "ldg" || n == "ld";
    if (is_load) {
        if (size == 7) size = 6;   // ldg.u.b128 (uniform hint)
        if (size <= 3) {           // the aligned word never crosses into the next 4 GiB
            st_r(dst, extract_sized(global_load(band(lo, cu(~3u)), hi), lo, size));
            return;
        }
        load_words(in, dst, size, [&](Id a) {
            // a = lo + 4k: the high word takes the carry of the +4k
            const Id carry = b2u(ult(a, lo));
            return global_load(a, add(hi, carry));
        }, lo);
        return;
    }
    if (size <= 3) {
        const unsigned w = size >= 2 ? 16 : 8;
        const Id shift = shl(band(lo, cu(w == 16 ? 2 : 3)), cu(3));
        const Id mask = shl(cu(w == 16 ? 0xffff : 0xff), shift);
        global_store(lo, hi, band(shl(ld_r(dst), shift), mask), mask);
        return;
    }
    const unsigned cnt = size == 4 ? 1 : size == 5 ? 2 : 4;
    for (unsigned i = 0; i < cnt; ++i) {
        const Id a = add(lo, cu(4 * i));
        global_store(a, add(hi, b2u(ult(a, lo))), ld_r(dst == kRZ ? kRZ : dst + i), cu(0xffffffff));
    }
}

// Atomic op kinds for the helpers: ATOM/RED op code (0 add .. 8 exch) | type << 8, 15 = CAS.
void Translator::op_atom(const Insn& in) {
    const std::string_view n = in.name();
    const unsigned dst = in.f(0, 8);
    const unsigned areg = in.f(8, 8);
    if (n == "atoms") {
        if (!shared_) { fail(in, "ATOMS sin memoria compartida en ShaderInfo"); return; }
        const Id addr = add(ld_r(areg), cu(static_cast<uint32_t>(sext(in.f(30, 22), 22) * 4)));
        const unsigned vreg = in.f(20, 8);
        auto vr = [&](unsigned k) { return ld_r(vreg == kRZ ? kRZ : vreg + k); };
        const Id sc_wg = cu(spirv::scope::Workgroup), none = cu(0);
        const bool cas = (in.e->value >> 48) == 0xee00;
        // P4.4: the wide forms (NAK: CAS sub-op 5, types 2 u64 / 3 s64), on 64-bit words
        const bool wide = cas ? in.b(52) : in.f(28, 2) >= 2;
        if (cas && in.f(53, 2) != 2) { fail(in, "ATOMS.CAS con sub-código " + std::to_string(in.f(52, 4)) + " sin semántica pública (NAK: 4 y 5)"); return; }
        if (wide) {
            if (!info_.int64_atomics) { fail(in, "ATOMS de 64 bits: requiere shaderSharedInt64Atomics (ShaderInfo::int64_atomics)"); return; }
            const Id p = shared64_ptr(addr);
            Id r;
            if (cas) {   // packed: R20:R21 comparator, R22:R23 new value (NAK)
                const Id cmp = u64_of(vr(0), vr(1)), nv = u64_of(vr(2), vr(3));
                r = b_.emit(op::AtomicCompareExchange, t_u64_, {p, sc_wg, none, none, nv, cmp});
            } else {
                const unsigned aop = in.f(52, 4);
                const bool sgn = in.f(28, 2) == 3;
                static const uint16_t ops[9] = {op::AtomicIAdd, 0, 0, 0, 0, op::AtomicAnd, op::AtomicOr, op::AtomicXor, op::AtomicExchange};
                uint16_t o = aop < 9 ? ops[aop] : 0;
                if (aop == 1) o = sgn ? op::AtomicSMin : op::AtomicUMin;
                if (aop == 2) o = sgn ? op::AtomicSMax : op::AtomicUMax;
                if (!o) { fail(in, "ATOMS " + std::to_string(aop) + " de 64 bits sin semántica pública (inc/dec: solo u32 en PTX)"); return; }
                r = b_.emit(o, t_u64_, {p, sc_wg, none, u64_of(vr(0), vr(1))});
            }
            const Id lo = u64_lo(r), hi = u64_hi(r);
            st_r(dst, lo);
            if (dst != kRZ) st_r(dst + 1, hi);
            return;
        }
        if (shared64_) {   // P4.4: 32-bit atomics on the 64-bit words: compare-and-swap loops
            const Id v = ld_r(vreg);
            Id r;
            if (cas) {
                const Id nv = vr(1);
                r = shared64_atomic32(addr, [&](Id old) { return sel(ieq(old, v), nv, old); });
            } else {
                const unsigned aop = in.f(52, 4);
                const bool sgn = in.f(28, 2) == 1;
                if (aop > 8) { fail(in, "operación atómica reservada"); return; }
                r = shared64_atomic32(addr, [&](Id old) -> Id {
                    switch (aop) {
                        case 0: return add(old, v);
                        case 1: return ext(sgn ? glsl::SMin : glsl::UMin, U(), {old, v});
                        case 2: return ext(sgn ? glsl::SMax : glsl::UMax, U(), {old, v});
                        case 3: return sel(uge(old, v), cu(0), add(old, cu(1)));
                        case 4: return sel(lor(ieq(old, cu(0)), e2(op::UGreaterThan, B(), old, v)), v, sub(old, cu(1)));
                        case 5: return band(old, v);
                        case 6: return bor(old, v);
                        case 7: return bxor(old, v);
                        default: return v;
                    }
                });
            }
            st_r(dst, r);
            return;
        }
        const Id p = shared_ptr(addr);   // (P4.1's order: the pointer, then the value)
        const Id v = ld_r(vreg);
        if (cas) {
            const Id nv = ld_r(in.f(20, 8) == kRZ ? kRZ : in.f(20, 8) + 1);
            st_r(dst, b_.emit(op::AtomicCompareExchange, U(), {p, sc_wg, none, none, nv, v}));
            return;
        }
        const unsigned type = in.f(28, 2);
        const unsigned aop = in.f(52, 4);
        static const uint16_t ops[9] = {op::AtomicIAdd, 0, 0, 0, 0, op::AtomicAnd, op::AtomicOr, op::AtomicXor, op::AtomicExchange};
        uint16_t o = aop < 9 ? ops[aop] : 0;
        if (aop == 1) o = type == 1 ? op::AtomicSMin : op::AtomicUMin;
        if (aop == 2) o = type == 1 ? op::AtomicSMax : op::AtomicUMax;
        if (aop == 3 || aop == 4) {   // P4.4: INC/DEC with wrap (PTX atom.inc/dec, u32): a CAS loop
            st_r(dst, atomic_cas_loop(p, U(), sc_wg, [&](Id old) {
                return aop == 3 ? sel(uge(old, v), cu(0), add(old, cu(1)))
                                : sel(lor(ieq(old, cu(0)), e2(op::UGreaterThan, B(), old, v)), v, sub(old, cu(1)));
            }));
            return;
        }
        if (!o) { fail(in, "operación atómica reservada"); return; }
        st_r(dst, b_.emit(o, U(), {p, sc_wg, none, v}));
        return;
    }
    // global
    const bool is_red = n == "red";
    const bool cas = !is_red && (in.e->value >> 48) == 0xeef0;
    const bool e = in.b(48);
    unsigned aop, type;
    if (cas) { aop = 15; type = in.b(49) ? 2 : 0; }
    else if (is_red) { aop = in.f(23, 3); type = in.f(20, 3); }
    else { aop = in.f(52, 4); type = in.f(49, 3); }
    // P4.4 types (NAK): 0 u32, 1 s32, 2 u64, 3 f32 (ADD; PTX: RN, subnormals flushed), 5 s64;
    // 4 (128 bits) and 6/7 have no public semantics
    if (type == 4 || type > 5) { fail(in, "ATOM/RED de tipo " + std::to_string(type) + " sin semántica pública"); return; }
    if (aop > 8 && aop != 15) { fail(in, "operación atómica reservada"); return; }
    if (type == 3 && aop != 0) { fail(in, "ATOM/RED f32 distinta de ADD sin semántica pública"); return; }
    const bool wide = type == 2 || type == 5;
    if (wide && !info_.int64_atomics) { fail(in, "ATOM/RED de 64 bits: requiere shaderBufferInt64Atomics (ShaderInfo::int64_atomics)"); return; }
    if (wide && (aop == 3 || aop == 4)) { fail(in, "INC/DEC de 64 bits sin semántica pública (PTX: solo u32)"); return; }
    Id hi;
    const Id lo = gaddr_lo(in, areg, sext(in.f(28, 20), 20), e, &hi);
    const unsigned vreg = is_red ? dst : in.f(20, 8);
    if (wide) {   // P4.4: R20:R21 the value; CAS packed: R20:R21 comparator, R22:R23 new value (NAK)
        auto vr = [&](unsigned k) { return ld_r(vreg == kRZ ? kRZ : vreg + k); };
        if (!t_u64_) t_u64_ = b_.t_int(64, false);
        b_.capability(11 /* Int64 */);
        b_.capability(12 /* Int64Atomics */);
        const Id v = u64_of(vr(0), vr(1));
        const Id v2 = cas ? u64_of(vr(2), vr(3)) : b_.c_u64(0);
        const Id r = global_atomic64(aop | (type << 8), lo, hi, v, v2);
        if (!is_red) {
            const Id rlo = u64_lo(r), rhi = u64_hi(r);
            st_r(dst, rlo);
            if (dst != kRZ) st_r(dst + 1, rhi);
        }
        return;
    }
    const Id v = ld_r(vreg);
    const Id v2 = cas ? ld_r(vreg == kRZ ? kRZ : vreg + 1) : cu(0);
    const Id r = global_atomic(aop | (type << 8), lo, hi, v, v2);
    if (!is_red) st_r(dst, r);
}

Id Translator::global_atomic64(uint32_t opk, Id lo, Id hi, Id v, Id v2) {
    auto it = fn_gatom64_.find(opk);
    Id fn;
    if (it == fn_gatom64_.end()) { fn = b_.id(); fn_gatom64_.emplace(opk, fn); }
    else fn = it->second;
    return b_.emit(op::FunctionCall, t_u64_, {fn, lo, hi, v, v2});
}

void Translator::op_barrier(const Insn& in) {
    const std::string_view n = in.name();
    if (n == "bar") {
        const uint32_t mode = in.f(32, 8) & 0x9b;
        if (mode != 0x80) { op_bar_ext(in, mode); return; }   // P4.4: ARV, RED (translate_misc.inc)
        const unsigned form = in.f(43, 2);
        // barrier id / thread count: default (RZ/RZ or 0) is a whole-workgroup barrier
        const bool id_imm = form & 2, cnt_imm = form & 1;
        const bool def_count = cnt_imm ? in.f(20, 12) == 0 : in.f(20, 8) == kRZ;
        if (!def_count) warn(in, "BAR con número de hilos: se trata como barrera de grupo completo");
        if (!(id_imm ? in.f(8, 8) == 0 : in.f(8, 8) == kRZ)) warn(in, "BAR con identificador distinto de 0");
        if (stage_ == Stage::TessControl) {   // TCS barrier(): outputs of the patch
            b_.emit_void(op::ControlBarrier, {cu(spirv::scope::Workgroup), cu(spirv::scope::Invocation), cu(0)});
            return;
        }
        if (stage_ != Stage::Compute) { fail(in, "BAR fuera de compute y TCS"); return; }
        b_.emit_void(op::ControlBarrier, {cu(spirv::scope::Workgroup), cu(spirv::scope::Workgroup),
                                          cu(spirv::semantics::AcquireRelease | spirv::semantics::WorkgroupMemory)});
        return;
    }
    // membar
    const unsigned lvl = in.f(8, 2);
    const uint32_t sem = spirv::semantics::AcquireRelease | spirv::semantics::UniformMemory | spirv::semantics::WorkgroupMemory;
    b_.emit_void(op::MemoryBarrier, {cu(lvl == 0 ? spirv::scope::Workgroup : spirv::scope::Device), cu(sem)});
}

// =====================================================================================
// Per-instruction dispatch
// =====================================================================================
void Translator::emit_body(const Insn& in) {
    const std::string_view n = in.name();
    const unsigned dst = in.f(0, 8);
    if (n == "mov") {
        if (in.has("SYS_20")) st_r(dst, sysreg(in, in.f(20, 8)));
        else st_r_lanes(dst, value(in, 0), in.f(39, 4));   // P4.4: the quad lane mask (nouveau emitMOV)
    } else if (n == "mov32i") st_r_lanes(dst, cu(in.f(20, 32)), in.f(12, 4));
    else if (n == "cs2r") st_r(dst, sysreg(in, in.f(20, 8)));
    else if (n == "sel") st_r(dst, sel(ld_p(in.f(39, 3), in.b(42)), ld_r(in.f(8, 8)), value(in, 0)));
    else if (n == "iadd") op_iadd(in);
    else if (n == "iadd32i") op_iadd32i(in);
    else if (n == "iadd3") op_iadd3(in);
    else if (n == "iscadd" || n == "iscadd32i") op_iscadd(in);
    else if (n == "lea") op_lea(in);
    else if (n == "imad" || n == "imad32i") op_imad(in);
    else if (n == "imul" || n == "imul32i") op_imul(in);
    else if (n == "xmad") op_xmad(in);
    else if (n == "imnmx") op_imnmx(in);
    else if (n == "lop" || n == "lop32i") op_lop(in);
    else if (n == "lop3") op_lop3(in);
    else if (n == "shl" || n == "shr") op_shifts(in);
    else if (n == "shf") op_shf(in);
    else if (n == "bfe" || n == "bfi" || n == "flo" || n == "popc") op_bitfield(in);
    else if (n == "prmt") op_prmt(in);
    else if (n == "isetp" || n == "iset" || n == "icmp") op_isetp(in);
    else if (n == "fadd" || n == "fadd32i") op_fadd(in);
    else if (n == "fmul" || n == "fmul32i") op_fmul(in);
    else if (n == "ffma" || n == "ffma32i") op_ffma(in);
    else if (n == "fmnmx") op_fmnmx(in);
    else if (n == "fsetp" || n == "fset" || n == "fcmp") op_fsetp(in);
    else if (n == "mufu") op_mufu(in);
    else if (n == "rro") {
        Id f = tof(value(in, 0));
        f = fneg_abs(f, in.b(45), in.b(49));
        st_r(dst, tou(f));   // range reduction is folded into MUFU (exact functions)
    } else if (n == "f2f") { if (!conv64(in)) op_f2f(in); }   // P4.4: 64-bit forms in conv64
    else if (n == "f2i") { if (!conv64(in)) op_f2i(in); }
    else if (n == "i2f") { if (!conv64(in)) op_i2f(in); }
    else if (n == "dadd" || n == "dmul" || n == "dfma" || n == "dmnmx" || n == "dset" || n == "dsetp") op_double(in);
    else if (n == "hadd2" || n == "hmul2" || n == "hfma2" || n == "hset2" || n == "hsetp2" || n == "hadd2_32i" ||
             n == "hmul2_32i" || n == "hfma2_32i") op_half(in);
    else if (n == "cset" || n == "csetp") op_cset(in);
    else if (n == "fchk") op_fchk(in);
    else if (n == "vote") op_vote(in);
    else if (n == "pixld") op_pixld(in);
    else if (n == "imadsp") op_imadsp(in);
    else if (n == "idp") op_idp(in);
    else if (n == "lepc" || n == "getcrsptr" || n == "setcrsptr" || n == "getlmembase" || n == "setlmembase" ||
             n == "b2r" || n == "r2b" || n == "sam" || n == "ram") op_system(in);
    else if (n == "vadd" || n == "vabsdiff" || n == "vmad" || n == "vsetp" || n == "vshl" || n == "vshr") op_video(in);   // P4.5
    else if (n == "ide") {
        warn(in, "IDE: MOV best-effort");
        st_r(in.f(0, 8), ld_r(in.f(8, 8)));
    } else if (n == "stp") {
        warn(in, "STP: barrier best-effort (full store encoding deferred)");
        // Minimal effect: no fail in strict mode for this mnemonic family.
        (void)in;
    } else if (n == "vabsdiff4") {
        // |Ra-Rb| on 4 packed bytes approximated as scalar absdiff of low bytes.
        warn(in, "VABSDIFF4: absdiff escalar best-effort");
        Id a = ld_r(in.f(8, 8)), b = ld_r(in.f(20, 8));
        Id diff = sub(a, b);
        Id neg = sub(cu(0), diff);
        Id lt = slt(diff, cu(0));
        st_r(in.f(0, 8), b_.emit(op::Select, U(), {lt, neg, diff}));
    } else if (n == "vmnmx") {
        warn(in, "VMNMX: UMin/UMax best-effort");
        Id a = ld_r(in.f(8, 8)), b = ld_r(in.f(20, 8));
        const bool is_max = in.b(55);  // heuristic flag
        st_r(in.f(0, 8), is_max ? ext(glsl::UMax, U(), {a, b}) : ext(glsl::UMin, U(), {a, b}));
    } else if (n == "vset") {
        warn(in, "VSET: comparación U32 → 0/-1 best-effort");
        Id a = ld_r(in.f(8, 8)), b = ld_r(in.f(20, 8));
        Id cmp = ieq(a, b);
        st_r(in.f(0, 8), b_.emit(op::Select, U(), {cmp, cu(0xffffffffu), cu(0)}));
    } else if (n == "txa") {
        warn(in, "TXA: identity on Rd best-effort");
        st_r(in.f(0, 8), ld_r(in.f(0, 8)));
    } else if (n == "ld" || n == "st" || n == "ldg" || n == "stg") op_mem(in);
    else if (n == "atom" || n == "atoms" || n == "red") op_atom(in);
    else if (n == "bar" || n == "membar") op_barrier(in);
    else if (n == "depbar" || n == "nop" || n == "cctl" || n == "cctll" || n == "cctlt") { /* no effect */ }
    else if (n == "ipa") op_ipa(in);
    else if (n == "out") op_out(in);
    else if (n == "shfl") op_shfl(in);
    else if (n == "tex" || n == "texs" || n == "tld" || n == "tlds" || n == "tld4" || n == "tld4s" || n == "txd" ||
             n == "tmml" || n == "txq") op_texture(in);
    else if (n == "suld" || n == "sust" || n == "suatom" || n == "sured") op_surface(in);
    else if (n == "fswzadd") op_fswzadd(in);
    else if (n == "isberd") st_r(dst, ld_r(in.f(8, 8)));   // logical -> physical vertex: identity
    else if (n == "al2p") {                                  // attribute -> physical address: a + imm
        st_r(dst, add(ld_r(in.f(8, 8)), cu(static_cast<uint32_t>(sext(in.f(20, 11), 11)))));
        st_p(in.f(44, 3), cb(false));
    }
    else if (info_.soft_unknown_as_nop) {
        warn(in, "opcode sin path SPIR-V; NOP (soft_unknown_as_nop)");
        ++soft_skipped_;
    } else {
        fail(in, "instrucción fuera de P4.1");
    }
}

void Translator::emit_flow(const Insn& in) {
    const std::string_view n = in.name();
    auto btarget = [&]() -> uint32_t {
        return norm_target(static_cast<uint32_t>(static_cast<int64_t>(in.addr) + 8 + sext(in.f(20, 24), 24)));
    };
    auto check_target = [&](uint32_t t) {
        if (!by_addr_.count(t)) {
            char buf[64];
            std::snprintf(buf, sizeof buf, "destino 0x%x fuera del programa", t);
            fail(in, buf);
        }
    };
    const Id cond = in.has("T(f0f8_0)") ? cc_cond(in, in.f(0, 5)) : cb(true);
    auto when = [&](auto&& body) {
        if (in.has("T(f0f8_0)") && in.f(0, 5) != 15) {
            if_then(cond, body);
        } else {
            body();
        }
    };
    // P4.4 (D-P4.4-4): a target read from a constant buffer at run time
    if (in.has("C36_RZ_S16_20") || ((n == "brx" || n == "jmx") && in.has("C36_08_S16_20"))) {
        flow_cbuf(in, cond);
        return;
    }
    if (n == "pexit" || n == "plongjmp") {   // P4.4: push the exit / long-jump target (model)
        const uint32_t t = btarget();
        check_target(t);
        warn(in, n == "pexit" ? "PEXIT: modelo (EXIT salta a su destino)" : "PLONGJMP: modelo (LONGJMP salta a su destino)");
        crs_push(n == "pexit" ? kPexit : kPlongjmp, cu(t));
        return;
    }
    if (n == "longjmp") {
        warn(in, "LONGJMP: modelo (desapila hasta la entrada de PLONGJMP)");
        when([&] { store(pc_, crs_pop_call(kPlongjmp)); });
        return;
    }
    if (n == "rtt" || n == "bpt") {
        flow_trap(in);
        return;
    }
    if (n == "ssy" || n == "pbk" || n == "pcnt" || n == "pret") {
        const uint32_t t = btarget();
        check_target(t);
        const uint32_t kind = n == "ssy" ? kSsy : n == "pbk" ? kPbk : n == "pcnt" ? kPcnt : kCal;
        crs_push(kind, cu(t));
        return;
    }
    if (n == "bra") {
        const uint32_t t = btarget();
        check_target(t);
        when([&] { store(pc_, cu(t)); });
        return;
    }
    if (n == "jmp") {
        const uint32_t t = norm_target(in.f(20, 32));
        check_target(t);
        when([&] { store(pc_, cu(t)); });
        return;
    }
    if (n == "brx" || n == "jmx") {
        const Id r = ld_r(in.f(8, 8));
        const Id raw = n == "brx" ? add(r, cu(static_cast<uint32_t>(static_cast<int64_t>(in.addr) + 8 + sext(in.f(20, 24), 24))))
                                  : add(r, cu(in.f(20, 32)));
        const Id t = add(raw, sel(ieq(band(raw, cu(0x18)), cu(0)), cu(8), cu(0)));
        warn(in, "salto indirecto: destinos fuera del programa terminan la invocación");
        when([&] { store(pc_, t); });
        return;
    }
    if (n == "cal" || n == "jcal") {
        const uint32_t t = n == "cal" ? btarget() : norm_target(in.f(20, 32));
        check_target(t);
        // NOINC: CAL encodes it as bit 6 clear (envytools ZN(6)), JCAL as bit 6 set (ON(6))
        if (n == "cal" ? !in.b(6) : in.b(6)) warn(in, "CAL.NOINC tratado como CAL");
        crs_push(kCal, cu(in.addr + 8));
        store(pc_, cu(t));
        return;
    }
    if (n == "sync" || n == "brk" || n == "cont" || n == "ret") {
        const uint32_t kind = n == "sync" ? kSsy : n == "brk" ? kPbk : n == "cont" ? kPcnt : kCal;
        when([&] { store(pc_, crs_pop_call(kind)); });
        return;
    }
    if (n == "kil" && stage_ == Stage::Fragment) {   // discard
        when([&] { b_.emit_void(op::Kill, {}); });
        return;
    }
    if (n == "exit" && has_pexit_) {   // P4.4: EXIT goes to a pending PEXIT target, if any
        when([&] {
            const Id t = crs_pop_call(kPexit);
            if (stage_ == Stage::Fragment) if_then(ieq(t, cu(kExit)), [&] { fs_write_outputs(); });
            store(pc_, t);
        });
        return;
    }
    if (n == "exit" || n == "kil") {
        when([&] {
            if (stage_ == Stage::Fragment) fs_write_outputs();
            store(pc_, cu(kExit));
        });
        return;
    }
    fail(in, "instrucción de flujo fuera de P4.1");
}

void Translator::emit_insn(const Insn& in) {
    // Encodings without a guard predicate (PBK, SSY, PCNT, CAL...) use bits 16..19 for operands.
    const unsigned p = in.e->predicated ? in.f(16, 3) : kPT;
    const bool neg = in.e->predicated && in.b(19);
    if (p == kPT && neg) return;   // never executes
    const std::string_view n = in.name();
    const bool flow = is_branch_like(n) || n == "ssy" || n == "pbk" || n == "pcnt" || n == "pret" || n == "pexit" ||
                      n == "plongjmp";
    auto body = [&] { if (flow) emit_flow(in); else emit_body(in); };
    if (p == kPT) body();
    else if_then(ld_p(p, neg), body);
}

// =====================================================================================
// main(): the dispatcher
// =====================================================================================
void Translator::emit_main() {
    const Id tvoid = b_.t_void();
    main_fn_ = b_.begin_function(tvoid, b_.t_fn(tvoid, {}));
    b_.name(main_fn_, "main");
    const Id entry = b_.new_label(), header = b_.new_label(), body = b_.new_label(), sw_merge = b_.new_label(),
             cont = b_.new_label(), merge = b_.new_label(), def = b_.new_label();
    b_.label(entry);
    pc_ = b_.local_var(t_ptr_fu_, cu(insns_.front().addr));
    b_.name(pc_, "pc");
    b_.emit_void(op::Branch, {header});
    b_.label(header);
    b_.emit_void(op::LoopMerge, {merge, cont, 0});
    b_.emit_void(op::Branch, {body});
    b_.label(body);
    const Id pcv = load(U(), pc_);
    // case labels
    std::vector<std::pair<uint32_t, Id>> cases;
    for (uint32_t a : leaders_) cases.emplace_back(a, b_.new_label());
    std::vector<uint32_t> sw{pcv, def};
    for (auto& c : cases) { sw.push_back(c.first); sw.push_back(c.second); }
    b_.emit_void(op::SelectionMerge, {sw_merge, 0});
    b_.emit_void(op::Switch, sw);
    for (size_t ci = 0; ci < cases.size() && error_.empty(); ++ci) {
        b_.label(cases[ci].second);
        const uint32_t start = cases[ci].first;
        const uint32_t end = ci + 1 < cases.size() ? cases[ci + 1].first : ~0u;
        size_t i = by_addr_.at(start);
        // fall-through pc: the next block (or EXIT past the end)
        uint32_t next_pc = kExit;
        {
            size_t j = i;
            while (j < insns_.size() && insns_[j].addr < end) ++j;
            if (j < insns_.size()) next_pc = insns_[j].addr;
        }
        store(pc_, cu(next_pc));
        for (; i < insns_.size() && insns_[i].addr < end && error_.empty(); ++i) {
            if (tcs_barrier_before_.count(i))   // P4.2: see plan_tcs_barriers()
                b_.emit_void(op::ControlBarrier, {cu(spirv::scope::Workgroup), cu(spirv::scope::Invocation), cu(0)});
            emit_insn(insns_[i]);
            if (i == tcs_barrier_after_)
                b_.emit_void(op::ControlBarrier, {cu(spirv::scope::Workgroup), cu(spirv::scope::Invocation), cu(0)});
        }
        if (b_.block_open()) b_.emit_void(op::Branch, {sw_merge});
    }
    if (!error_.empty()) return;
    b_.label(def);
    store(pc_, cu(kExit));
    b_.emit_void(op::Branch, {sw_merge});
    b_.label(sw_merge);
    b_.emit_void(op::Branch, {cont});
    b_.label(cont);
    const Id go = ine(load(U(), pc_), cu(kExit));
    b_.emit_void(op::BranchConditional, {go, header, merge});
    b_.label(merge);
    b_.emit_void(op::Return, {});
    b_.end_function();
}

// =====================================================================================
// Helper functions (emitted after main; called by forward reference)
// =====================================================================================
void Translator::emit_helpers() {
    const Id tvoid = b_.t_void();
    // ---- CRS pops: pop entries until one of `kind` is popped; return its target (or EXIT) ----
    for (uint32_t kind = 0; kind < 6; ++kind) {
        if (!crs_pop_fn_[kind]) continue;
        b_.begin_function_with_id(crs_pop_fn_[kind], U(), b_.t_fn(U(), {}));
        const Id entry = b_.new_label(), header = b_.new_label(), bodyl = b_.new_label(), cont = b_.new_label(),
                 merge = b_.new_label();
        b_.label(entry);
        b_.emit_void(op::Branch, {header});
        b_.label(header);
        const Id sp = load(U(), crs_sp_);
        const Id nonempty = ine(sp, cu(0));
        b_.emit_void(op::LoopMerge, {merge, cont, 0});
        b_.emit_void(op::BranchConditional, {nonempty, bodyl, merge});
        b_.label(bodyl);
        const Id nsp = sub(sp, cu(1));
        store(crs_sp_, nsp);
        const Id ent = load(U(), chain(t_ptr_priv_u_, crs_stack_, {band(nsp, cu(kCrsDepth - 1))}));
        if_then(ieq(shr(ent, cu(crs_shift_)), cu(kind)), [&] {
            b_.emit_void(op::ReturnValue, {band(ent, cu((1u << crs_shift_) - 1))});
        });
        b_.emit_void(op::Branch, {cont});
        b_.label(cont);
        b_.emit_void(op::Branch, {header});
        b_.label(merge);
        b_.emit_void(op::ReturnValue, {cu(kExit)});
        b_.end_function();
    }
    if (!uses_global_) return;
    // For each mapped buffer: if the address falls inside it, run `fn(ptr_to_word)`.
    auto for_each_buffer = [&](Id lo, Id hi, const std::function<void(Id ptr)>& fn) {
        for (const auto& key : ssbo_entries_) {
            const GlobalBufferTable& gb = info_.global_tables[key.first];
            const uint32_t off = gb.offset + key.second * gb.stride;
            const Id base_lo = cbuf_load(gb.cbuf_bank, off);
            const Id base_hi = cbuf_load(gb.cbuf_bank, off + 4);
            const Id size = gb.size_offset == GlobalBufferTable::kNoSize ? cu(gb.fixed_size)
                                                                         : cbuf_load(gb.cbuf_bank, off + gb.size_offset);
            const Id d = b_.emit(op::ISubBorrow, pair_type(), {lo, base_lo});
            const Id d_lo = b_.emit(op::CompositeExtract, U(), {d, 0});
            const Id borrow = b_.emit(op::CompositeExtract, U(), {d, 1});
            const Id d_hi = sub(sub(hi, base_hi), borrow);
            const Id inside = land(ieq(d_hi, cu(0)), ult(d_lo, size));
            if_then(inside, [&] {
                const Id p = chain(t_ptr_ssbo_u_, ssbo_vars_.at(key), {cu(0), shr(d_lo, cu(2))});
                fn(p);
            });
        }
    };
    // uint gld(uint lo, uint hi)
    {
        b_.begin_function_with_id(fn_gld_, U(), b_.t_fn(U(), {U(), U()}));
        const Id lo = b_.param(U()), hi = b_.param(U());
        b_.label(b_.new_label());
        for_each_buffer(lo, hi, [&](Id p) { b_.emit_void(op::ReturnValue, {load(U(), p)}); });
        b_.emit_void(op::ReturnValue, {cu(0)});
        b_.end_function();
    }
    // void gst(uint lo, uint hi, uint v, uint mask)
    {
        b_.begin_function_with_id(fn_gst_, tvoid, b_.t_fn(tvoid, {U(), U(), U(), U()}));
        const Id lo = b_.param(U()), hi = b_.param(U()), v = b_.param(U()), mask = b_.param(U());
        b_.label(b_.new_label());
        for_each_buffer(lo, hi, [&](Id p) {
            const Id full = ieq(mask, cu(0xffffffff));
            const Id t = b_.new_label(), f = b_.new_label(), m = b_.new_label();
            b_.emit_void(op::SelectionMerge, {m, 0});
            b_.emit_void(op::BranchConditional, {full, t, f});
            b_.label(t);
            store(p, v);
            b_.emit_void(op::Branch, {m});
            b_.label(f);
            const Id dev = cu(spirv::scope::Device), none = cu(0);
            b_.emit(op::AtomicAnd, U(), {p, dev, none, bnot(mask)});
            b_.emit(op::AtomicOr, U(), {p, dev, none, band(v, mask)});
            b_.emit_void(op::Branch, {m});
            b_.label(m);
            b_.emit_void(op::Return, {});
        });
        b_.emit_void(op::Return, {});
        b_.end_function();
    }
    // uint gatom_<op>(uint lo, uint hi, uint v, uint v2)
    for (auto& [key, fn] : fn_gatom_) {
        const uint32_t aop = key & 0xff, type = key >> 8;
        b_.begin_function_with_id(fn, U(), b_.t_fn(U(), {U(), U(), U(), U()}));
        const Id lo = b_.param(U()), hi = b_.param(U()), v = b_.param(U()), v2 = b_.param(U());
        b_.label(b_.new_label());
        for_each_buffer(lo, hi, [&](Id p) {
            const Id dev = cu(spirv::scope::Device), none = cu(0);
            Id r;
            if (type == 3) {   // P4.4: f32 ADD (PTX atom.add.f32: RN, subnormal inputs and result flushed)
                auto ftz = [&](Id f) {
                    const Id small = e2(op::FOrdLessThan, B(), ext(glsl::FAbs, F(), {f}), cf(1.17549435e-38f));
                    return b_.emit(op::Select, F(), {small, e2(op::FMul, F(), f, cf(0.0f)), f});
                };
                const Id fv = ftz(e1(op::Bitcast, F(), v));
                r = atomic_cas_loop(p, U(), dev, [&](Id cur) {
                    const Id sum = e2(op::FAdd, F(), ftz(e1(op::Bitcast, F(), cur)), fv);
                    return e1(op::Bitcast, U(), ftz(sum));
                });
                b_.emit_void(op::ReturnValue, {r});
                return;
            }
            switch (aop) {
                case 0: r = b_.emit(op::AtomicIAdd, U(), {p, dev, none, v}); break;
                case 1: r = b_.emit(type == 1 ? op::AtomicSMin : op::AtomicUMin, U(), {p, dev, none, v}); break;
                case 2: r = b_.emit(type == 1 ? op::AtomicSMax : op::AtomicUMax, U(), {p, dev, none, v}); break;
                case 3: case 4: {
                    // inc: old >= v ? 0 : old + 1;  dec: (old == 0 || old > v) ? v : old - 1  (CAS loop)
                    const Id header = b_.new_label(), bodyl = b_.new_label(), cont = b_.new_label(), merge = b_.new_label();
                    b_.emit_void(op::Branch, {header});
                    b_.label(header);
                    b_.emit_void(op::LoopMerge, {merge, cont, 0});
                    b_.emit_void(op::Branch, {bodyl});
                    b_.label(bodyl);
                    const Id old = b_.emit(op::AtomicLoad, U(), {p, dev, none});
                    const Id nv = aop == 3 ? sel(uge(old, v), cu(0), add(old, cu(1)))
                                           : sel(lor(ieq(old, cu(0)), e2(op::UGreaterThan, B(), old, v)), v, sub(old, cu(1)));
                    const Id got = b_.emit(op::AtomicCompareExchange, U(), {p, dev, none, none, nv, old});
                    if_then(ieq(got, old), [&] { b_.emit_void(op::ReturnValue, {old}); });
                    b_.emit_void(op::Branch, {cont});
                    b_.label(cont);
                    b_.emit_void(op::Branch, {header});
                    b_.label(merge);
                    b_.emit_void(op::Unreachable, {});
                    return;
                }
                case 5: r = b_.emit(op::AtomicAnd, U(), {p, dev, none, v}); break;
                case 6: r = b_.emit(op::AtomicOr, U(), {p, dev, none, v}); break;
                case 7: r = b_.emit(op::AtomicXor, U(), {p, dev, none, v}); break;
                case 8: r = b_.emit(op::AtomicExchange, U(), {p, dev, none, v}); break;
                default: r = b_.emit(op::AtomicCompareExchange, U(), {p, dev, none, none, v2, v}); break;   // 15: CAS
            }
            b_.emit_void(op::ReturnValue, {r});
        });
        b_.emit_void(op::ReturnValue, {cu(0)});
        b_.end_function();
    }
    // P4.4: u64 gatom64_<op>(uint lo, uint hi, u64 v, u64 v2) on a 64-bit view of each buffer
    // (another variable at the same binding)
    std::map<std::pair<uint32_t, uint32_t>, Id> views;
    for (auto& [key, fn] : fn_gatom64_) {
        const uint32_t aop = key & 0xff, type = key >> 8;
        b_.begin_function_with_id(fn, t_u64_, b_.t_fn(t_u64_, {U(), U(), t_u64_, t_u64_}));
        const Id lo = b_.param(U()), hi = b_.param(U()), v = b_.param(t_u64_), v2 = b_.param(t_u64_);
        b_.label(b_.new_label());
        for (const auto& k : ssbo_entries_) {
            Id& view = views[k];
            if (!view) {
                const Id arr = b_.t_runtime_array(t_u64_);
                b_.decorate(arr, spirv::deco::ArrayStride, {8});
                const Id st = b_.t_struct({arr});
                b_.decorate(st, spirv::deco::Block);
                b_.member_decorate(st, 0, spirv::deco::Offset, {0});
                view = b_.global_var(b_.t_ptr(sc::StorageBuffer, st), sc::StorageBuffer);
                b_.decorate(view, spirv::deco::DescriptorSet, {info_.descriptor_set});
                b_.decorate(view, spirv::deco::Binding, {info_.global_tables[k.first].first_binding + k.second});
                b_.name(view, "g" + std::to_string(k.first) + "_" + std::to_string(k.second) + "_u64");
            }
            const GlobalBufferTable& gb = info_.global_tables[k.first];
            const uint32_t off = gb.offset + k.second * gb.stride;
            const Id base_lo = cbuf_load(gb.cbuf_bank, off);
            const Id base_hi = cbuf_load(gb.cbuf_bank, off + 4);
            const Id size = gb.size_offset == GlobalBufferTable::kNoSize ? cu(gb.fixed_size)
                                                                         : cbuf_load(gb.cbuf_bank, off + gb.size_offset);
            const Id d = b_.emit(op::ISubBorrow, pair_type(), {lo, base_lo});
            const Id d_lo = b_.emit(op::CompositeExtract, U(), {d, 0});
            const Id borrow = b_.emit(op::CompositeExtract, U(), {d, 1});
            const Id d_hi = sub(sub(hi, base_hi), borrow);
            const Id inside = land(ieq(d_hi, cu(0)), ult(d_lo, size));
            if_then(inside, [&] {
                const Id p = chain(b_.t_ptr(sc::StorageBuffer, t_u64_), view, {cu(0), shr(d_lo, cu(3))});
                const Id dev = cu(spirv::scope::Device), none = cu(0);
                const bool sgn = type == 5;
                Id r;
                switch (aop) {
                    case 0: r = b_.emit(op::AtomicIAdd, t_u64_, {p, dev, none, v}); break;
                    case 1: r = b_.emit(sgn ? op::AtomicSMin : op::AtomicUMin, t_u64_, {p, dev, none, v}); break;
                    case 2: r = b_.emit(sgn ? op::AtomicSMax : op::AtomicUMax, t_u64_, {p, dev, none, v}); break;
                    case 5: r = b_.emit(op::AtomicAnd, t_u64_, {p, dev, none, v}); break;
                    case 6: r = b_.emit(op::AtomicOr, t_u64_, {p, dev, none, v}); break;
                    case 7: r = b_.emit(op::AtomicXor, t_u64_, {p, dev, none, v}); break;
                    case 8: r = b_.emit(op::AtomicExchange, t_u64_, {p, dev, none, v}); break;
                    default: r = b_.emit(op::AtomicCompareExchange, t_u64_, {p, dev, none, none, v2, v}); break;   // 15: CAS
                }
                b_.emit_void(op::ReturnValue, {r});
            });
        }
        b_.emit_void(op::ReturnValue, {b_.c_u64(0)});
        b_.end_function();
    }
}

#include "translate_graphics.inc"
#include "translate_texture.inc"
#include "translate_fp64.inc"
#include "translate_fp16.inc"
#include "translate_misc.inc"
#include "translate_video.inc"

TranslationResult Translator::run() {
    TranslationResult res;
    stage_ = info_.stage;
    if (stage_ != Stage::Compute) {
        if (!parse_sph(info_.sph, sph_)) {
            res.error = "SPH no válida";
            return res;
        }
        static const uint32_t expected[] = {0, 1, 2, 3, 4, 5};
        if (sph_.shader_type != expected[static_cast<int>(stage_)]) {
            res.error = "la SPH no corresponde a la etapa pedida";
            return res;
        }
    }
    if (decode()) {
        res.instructions = static_cast<uint32_t>(insns_.size());
        find_blocks();
        scan_resources();
        if (stage_ != Stage::Compute) scan_graphics_io();
        if (stage_ == Stage::TessControl && error_.empty()) plan_tcs_barriers();
        if (error_.empty()) declare_module();
        if (error_.empty()) emit_main();
        if (error_.empty()) emit_helpers();
    }
    if (!error_.empty()) {
        res.error = error_;
        res.warnings = warnings_;
        res.soft_skipped = soft_skipped_;
        res.undecoded_soft = undecoded_soft_;
        return res;
    }
    // Entry point and execution modes (interface: Input/Output variables, SPIR-V 1.3).
    declare_entry_and_modes();
    res.ok = true;
    res.spirv = b_.finish();
    res.resources = result_resources_;
    res.warnings = warnings_;
    res.soft_skipped = soft_skipped_;
    res.undecoded_soft = undecoded_soft_;
    return res;
}

}  // namespace

bool parse_sph(std::span<const uint32_t> w, Sph& o) {
    if (w.size() < 20) return false;
    o = Sph{};
    o.sph_type = w[0] & 0x1f;
    o.shader_type = (w[0] >> 10) & 0xf;
    o.kills_pixels = (w[0] >> 15) & 1;
    o.local_mem_bytes = w[1] & 0xffffff;
    o.per_patch_attribs = w[1] >> 24;
    o.threads_per_input_primitive = w[2] >> 24;
    o.output_topology = (w[3] >> 24) & 0xf;
    o.max_output_vertices = w[4] & 0xfff;
    o.imap_sysvals_ab = w[5];
    // bytes of the header (little endian), for the packed byte-granular fields
    uint8_t b[80];
    for (int i = 0; i < 20; ++i) for (int k = 0; k < 4; ++k) b[4 * i + k] = static_cast<uint8_t>(w[i] >> (8 * k));
    auto rd16 = [&](int at) { return static_cast<uint32_t>(b[at] | (b[at + 1] << 8)); };
    auto rd32 = [&](int at) { return static_cast<uint32_t>(b[at] | (b[at + 1] << 8) | (b[at + 2] << 16) | (static_cast<uint32_t>(b[at + 3]) << 24)); };
    if (o.sph_type == 1) {          // VTG
        for (int i = 0; i < 4; ++i) o.vtg_imap_generic[i] = rd32(0x18 + 4 * i);
        o.imap_sysvals_c = rd16(0x2a);
        o.omap_sysvals_ab = rd32(0x32);
        for (int i = 0; i < 4; ++i) o.vtg_omap_generic[i] = rd32(0x36 + 4 * i);
        o.omap_sysvals_c = rd16(0x48);
        if (o.shader_type < 1 || o.shader_type > 4) return false;
    } else if (o.sph_type == 2) {   // PS
        for (int i = 0; i < 32; ++i) o.ps_imap_generic[i] = b[0x18 + i];
        o.imap_sysvals_c = rd16(0x3a);
        o.ps_omap_target = rd32(0x48);
        o.ps_omap_sample_mask = b[0x4c] & 1;
        o.ps_omap_depth = (b[0x4c] >> 1) & 1;
        if (o.shader_type != 5) return false;
    } else {
        return false;
    }
    return true;
}

TranslationResult translate(std::span<const uint64_t> code, const ShaderInfo& info) {
    Translator t(code, info);
    return t.run();
}

CoverageReport coverage_report() noexcept {
    CoverageReport r;
    const auto enc = maxwell::encodings();
    r.isa_encodings = static_cast<uint32_t>(enc.size());
    std::unordered_set<std::string> mnem;
    mnem.reserve(enc.size());
    for (const auto& e : enc) mnem.insert(e.mnemonic ? e.mnemonic : "?");
    r.isa_unique_mnemonics = static_cast<uint32_t>(mnem.size());
    // Body surface handled by emit_body (keep in sync with Translator::emit_body).
    static const char* kBody[] = {
        "mov","mov32i","cs2r","sel","iadd","iadd32i","iadd3","iscadd","iscadd32i","lea",
        "imad","imad32i","imul","imul32i","xmad","imnmx","lop","lop32i","lop3","shl","shr","shf",
        "bfe","bfi","flo","popc","prmt","isetp","iset","icmp","fadd","fadd32i","fmul","fmul32i",
        "ffma","ffma32i","fmnmx","fsetp","fset","fcmp","mufu","rro","f2f","f2i","i2f",
        "dadd","dmul","dfma","dmnmx","dset","dsetp","hadd2","hmul2","hfma2","hset2","hsetp2",
        "hadd2_32i","hmul2_32i","hfma2_32i","cset","csetp","fchk","vote","imadsp","idp",
        "lepc","getcrsptr","setcrsptr","getlmembase","setlmembase","b2r","r2b","sam","ram",
        "vadd","vabsdiff","vmad","vsetp","vshl","vshr","vabsdiff4","vmnmx","vset","ide","stp","txa","i2i","psetp","pset","p2r","r2p",
        "ld","st","ldg","stg","atom","atoms","red","bar","membar","depbar","nop","cctl","cctll","cctlt",
        "ipa","out","shfl","tex","texs","tld","tlds","tld4","tld4s","txd","tmml","txq",
        "suld","sust","suatom","sured","fswzadd","isberd","al2p"
    };
    std::unordered_set<std::string> body;
    body.reserve(sizeof kBody / sizeof kBody[0]);
    for (const char* name : kBody) body.emplace(name);
    for (const auto& name : body)
        if (mnem.count(name)) ++r.translator_body_mnemonics;
    char buf[192];
    std::snprintf(buf, sizeof buf,
        "isaEnc=%u;isaMnem=%u;dispatchMnem=%u;dispatchSurface≈%u%% (mnemonics, not semantics)",
        r.isa_encodings, r.isa_unique_mnemonics, r.translator_body_mnemonics,
        r.isa_unique_mnemonics ? (100u * r.translator_body_mnemonics / r.isa_unique_mnemonics) : 0u);
    r.summary = buf;
    return r;
}


}  // namespace lg::shader
