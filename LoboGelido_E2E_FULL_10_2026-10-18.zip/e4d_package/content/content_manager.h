#pragma once
#include <cstdint>
#include <string>
#include "../core/result.h"
#include "../runtime/runtime_storage.h"

namespace lg::content {

enum class ContentState { Validated, Installed, Ready, Failed };

struct InstallResult {
    ContentState state{ContentState::Failed};
    std::string title_id;
    std::string title;
    std::string version;
    std::string publisher;
    std::string format;
    std::string sha256;
    std::string installed_path;
    uint64_t size_bytes{};
    std::string diagnostic;
};

class ContentManager final {
public:
    static core::Result<InstallResult> validate_fd(int fd, const runtime::RuntimeStorage& storage);
    static core::Result<InstallResult> validate_and_install_fd(
        int fd, const std::string& storage_root, const runtime::RuntimeStorage& storage);
};

} // namespace lg::content
