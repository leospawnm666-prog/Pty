#include "content_manager.h"
#include "../loader/content_loader.h"
#include "../loader/content_metadata.h"
#include "../loader/nca_loader.h"
#include "../crypto/sha256.h"
#include <algorithm>
#include <array>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

namespace lg::content {
namespace {
namespace fs = std::filesystem;

std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return s;
}
std::string hex(const std::array<uint8_t, 32>& d) {
    static constexpr char h[] = "0123456789abcdef";
    std::string o(64, '0');
    for (size_t i = 0; i < d.size(); ++i) {
        o[i * 2] = h[d[i] >> 4];
        o[i * 2 + 1] = h[d[i] & 15];
    }
    return o;
}
std::string safe_component(std::string s) {
    std::string o;
    for (char c : s) {
        bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.';
        o += ok ? c : '_';
    }
    return o.empty() || o == "." || o == ".." ? "content" : o;
}
struct Candidate {
    loader::NcaSource source;
    std::string name;
};
std::vector<Candidate> candidates(const loader::ContentInfo& i) {
    std::vector<Candidate> out;
    if (i.format == loader::Format::Nca) {
        out.push_back({{i.path, 0, i.size}, fs::path(i.path).filename().string()});
        return out;
    }
    for (const auto& e : i.entries) {
        auto n = lower(e.name);
        if (n.size() >= 4 && n.ends_with(".nca")) out.push_back({{i.path, e.offset, e.size}, e.name});
    }
    return out;
}
core::Result<void> validate_nca(const Candidate& c, const runtime::RuntimeStorage& storage, std::string& title_id) {
    auto image = loader::NcaLoader::inspect(c.source, storage);
    if (!image.ok()) return core::Result<void>::Error(image.error());
    if (title_id.empty() && image.value().program_id != 0 && image.value().program_id != ~uint64_t{0}) {
        std::ostringstream o;
        o << std::hex << std::setfill('0') << std::setw(16) << image.value().program_id;
        title_id = o.str();
    }
    for (uint8_t i = 0; i < image.value().section_count; ++i) {
        auto section = loader::NcaLoader::load_section(c.source, i, storage);
        if (!section.ok()) return core::Result<void>::Error(section.error());
    }
    return core::Result<void>::Ok();
}
core::Result<InstallResult> validation_failed(const std::string& message) {
    InstallResult r{};
    r.state = ContentState::Failed;
    r.diagnostic = message;
    return core::Result<InstallResult>::Ok(std::move(r));
}
} // namespace

core::Result<InstallResult> ContentManager::validate_fd(int fd, const runtime::RuntimeStorage& storage) {
    if (fd < 0) return validation_failed("content manager: invalid source descriptor");
    const int owned = ::dup(fd);
    if (owned < 0) return validation_failed("content manager: cannot duplicate source descriptor");
    const std::string source = "/proc/self/fd/" + std::to_string(owned);
    auto info = loader::ContentLoader::inspect(source);
    if (!info.valid) {
        ::close(owned);
        return validation_failed("content manager: invalid container magic or bounds");
    }

    InstallResult result{};
    result.state = ContentState::Validated;
    result.size_bytes = info.size;
    result.format = info.format == loader::Format::Nsp   ? "NSP"
                    : info.format == loader::Format::Xci ? "XCI"
                    : info.format == loader::Format::Nca ? "NCA"
                                                         : "OTHER";

    // Soft path: commercial containers with valid PFS0/HFS0 structure are accepted for
    // launch pipeline even when deep NCA decrypt is incomplete. Hard-fail only when the
    // container itself is unreadable.
    std::string title_id;
    std::string soft_note;

    if (info.secure_container) {
        auto list = candidates(info);
        if (list.empty()) {
            // Structure OK but no .nca names — still allow structure-validated launch.
            soft_note = "structure-ok;no-nca-names";
        } else if (!storage.keys_ready()) {
            soft_note = "structure-ok;keys-pending";
        } else {
            bool any_ok = false;
            std::string last_err;
            for (const auto& c : list) {
                auto v = validate_nca(c, storage, title_id);
                if (v.ok()) {
                    any_ok = true;
                    break;
                }
                last_err = v.error();
            }
            if (!any_ok) {
                // Keys present but decrypt failed: still structure-validate so UI can start
                // the session path; runtime will report a clearer error if execution fails.
                soft_note = "structure-ok;nca-soft-fail:" + last_err;
            }
        }
    }

    ::close(owned);
    result.title_id = title_id;
    if (!soft_note.empty()) {
        result.diagnostic = soft_note;
    } else {
        result.diagnostic = "validated";
    }
    return core::Result<InstallResult>::Ok(std::move(result));
}

core::Result<InstallResult> ContentManager::validate_and_install_fd(int fd,
                                                                   const std::string& storage_root,
                                                                   const runtime::RuntimeStorage& storage) {
    auto validated = validate_fd(fd, storage);
    if (!validated.ok()) return validated;

    InstallResult result = validated.value();
    int owned = ::dup(fd);
    if (owned < 0) return validation_failed("content manager: source descriptor disappeared after validation");
    const std::string source = "/proc/self/fd/" + std::to_string(owned);
    auto info = loader::ContentLoader::inspect(source);
    if (!info.valid) {
        ::close(owned);
        return validation_failed("content manager: source changed after validation");
    }

    std::string source_name = fs::path(info.path).filename().string();
    if (source_name.empty()) source_name = "content." + lower(result.format);
    const std::string safe_name = safe_component(source_name);
    const fs::path title_dir = fs::path(storage_root) / "content" / "installed" /
                               (result.title_id.empty() ? "pending" : safe_component(result.title_id));
    const fs::path metadata_dir = fs::path(storage_root) / "game_metadata";

    std::error_code ec;
    fs::create_directories(title_dir, ec);
    if (ec) {
        ::close(owned);
        return validation_failed("content manager: cannot create installation directory");
    }

    const auto nonce = static_cast<unsigned long long>(::getpid()) ^
                       static_cast<unsigned long long>(std::chrono::steady_clock::now().time_since_epoch().count());
    const fs::path target = title_dir / safe_name;
    const fs::path temp = title_dir / (safe_name + ".partial." + std::to_string(nonce));

    try {
        std::ifstream in(source, std::ios::binary);
        if (!in) {
            ::close(owned);
            return validation_failed("content manager: cannot reopen validated source");
        }
        std::ofstream out(temp, std::ios::binary | std::ios::trunc);
        if (!out) {
            ::close(owned);
            return validation_failed("content manager: cannot create staging file");
        }
        // Fusion (2026-10-16): main-line install guarantees restored on top of the CLEAN soft
        // validation path. Kotlin (ContentManager.kt) only accepts state READY with a real
        // installedPath; the CLEAN version returned INSTALLED with an empty path, so every
        // install was reported as failed. Hash + size check + atomic commit + directory fsync
        // come back; ExeFS/Control metadata is parsed exactly as before, but only when the
        // NCAs were fully validated (no soft note), so the soft path keeps working.
        std::vector<uint8_t> chunk(4 * 1024 * 1024);
        crypto::Sha256 sha;
        uint64_t copied = 0;
        while (in) {
            in.read(reinterpret_cast<char*>(chunk.data()), static_cast<std::streamsize>(chunk.size()));
            const auto got = in.gcount();
            if (got <= 0) break;
            out.write(reinterpret_cast<const char*>(chunk.data()), got);
            if (!out) {
                out.close();
                fs::remove(temp, ec);
                ::close(owned);
                return validation_failed("content manager: staged write failed");
            }
            sha.update(chunk.data(), static_cast<size_t>(got));
            copied += static_cast<uint64_t>(got);
        }
        out.flush();
        if (!out) {
            out.close();
            fs::remove(temp, ec);
            ::close(owned);
            return validation_failed("content manager: incomplete write to staging");
        }
        out.close();
        in.close();
        ::close(owned);
        owned = -1;

        if (copied != info.size) {
            fs::remove(temp, ec);
            return validation_failed("content manager: source size changed during copy");
        }
        result.sha256 = hex(sha.final());
        if (result.sha256.size() != 64) {
            fs::remove(temp, ec);
            return validation_failed("content manager: SHA-256 finalization failed");
        }

        const bool fully_validated = result.diagnostic == "validated";
        if (fully_validated) {
            auto meta = loader::ContentMetadataInspector::inspect(temp.string(), storage, metadata_dir.string());
            if (!meta.ok()) {
                fs::remove(temp, ec);
                return validation_failed("content manager: staged metadata validation failed: " + meta.error());
            }
            if (meta.value().title_id.empty() && result.title_id.empty()) {
                fs::remove(temp, ec);
                return validation_failed("content manager: metadata has no stable title id");
            }
            result.title_id = meta.value().title_id.empty() ? result.title_id : meta.value().title_id;
            result.title = meta.value().title;
            result.version = meta.value().version;
            result.publisher = meta.value().publisher;
            result.diagnostic = meta.value().diagnostic;
        }

        fs::rename(temp, target, ec);
        if (ec) {
            fs::remove(temp, ec);
            return validation_failed("content manager: cannot commit installation");
        }
        const int dir_fd = ::open(title_dir.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
        if (dir_fd >= 0) {
            if (::fsync(dir_fd) != 0 && result.diagnostic.empty())
                result.diagnostic = "atomic commit complete; directory durability fsync failed";
            ::close(dir_fd);
        } else if (result.diagnostic.empty()) {
            result.diagnostic = "atomic commit complete; directory fsync unavailable";
        }

        result.state = ContentState::Ready;
        result.installed_path = target.string();
        return core::Result<InstallResult>::Ok(std::move(result));
    } catch (const std::exception& e) {
        fs::remove(temp, ec);
        if (owned >= 0) ::close(owned);
        return validation_failed(std::string("content manager: installation exception: ") + e.what());
    } catch (...) {
        fs::remove(temp, ec);
        if (owned >= 0) ::close(owned);
        return validation_failed("content manager: install exception");
    }
}

} // namespace lg::content
