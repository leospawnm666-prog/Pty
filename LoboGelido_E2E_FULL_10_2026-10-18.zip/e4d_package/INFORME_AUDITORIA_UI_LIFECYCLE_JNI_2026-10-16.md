# Lobo Gélido — auditoría estática UI / Lifecycle / JNI

Fecha: 2026-10-16

## Alcance y procedencia

Se inspeccionó el candidato disponible `LoboGelido_BETA_0.1_UI_CIERRE_FASE3_UI_VISUAL_2026-10-16.zip`. Este paquete **no se certifica como la base autorizada oficial** `LoboGelido_BETA_0.1_BASE_ACTUALIZADA_2026-09-28.zip`; esa base no estaba disponible en el espacio de trabajo. No se sustituyó silenciosamente la base ni se eliminaron archivos de código.

## Resultado verificable

- Archivo fuente: `RuntimeBridge.kt` declara 36 métodos `external`, con 36 nombres únicos.
- `native.cpp` contiene 36 exportaciones JNI correspondientes por nombre; no se detectaron nombres sin pareja ni duplicados en la comprobación estática.
- `GameSurfaceView.surfaceDestroyed()` delega el teardown en `stopAndShutdownPresentation()` y no invoca directamente `stopSession()`. Esto respeta la separación de responsabilidades Surface/presentación frente a sesión de runtime a nivel de fuente.
- El script reproducible `tools_lifecycle_jni_audit.py` automatiza esas comprobaciones.
- El ZIP original pasó la comprobación de integridad ZIP en la inspección previa.

## Bloqueos y límites

- Faltan `android/gradle/wrapper/gradle-wrapper.properties` y `android/gradle/wrapper/gradle-wrapper.jar`; no es posible ejecutar el wrapper incluido tal como está empaquetado.
- La correspondencia por nombre **no** certifica descriptores JNI, tipos/orden de parámetros, símbolos resueltos en el binario, carga de `.so`, compilación Kotlin/C++, ownership real de `ANativeWindow`/Vulkan, ni ejecución en dispositivo.
- No se declara `BUILD SUCCESSFUL`, PASS E2E ni 100% para ningún bloque. No se ejecutó compilación Android ni prueba en dispositivo en esta auditoría.
- La UI no puede certificarse al 100% sin inspección visual de APK en dispositivo y recorridos funcionales reales (SAF, metadatos, carátulas, foco/mandos y temas).

## Siguiente criterio de aceptación

1. Repetir este script sobre la base oficial exacta y registrar su SHA-256.
2. Restaurar/validar el wrapper desde la base autorizada, sin inventar versiones ni reemplazar archivos de build a ciegas.
3. Compilar con JDK 17, Android SDK 36, NDK 27.3.13750724 y CMake 3.22.1; conservar logs completos.
4. Ejecutar pruebas de ciclo de vida en dispositivo: pause/resume, recreación de Surface, rotación/retorno, fallo parcial de Vulkan y cierre mientras se lanza contenido.
5. Certificar por separado UI, SAF/portadas y runtime/JNI con evidencia de dispositivo.
