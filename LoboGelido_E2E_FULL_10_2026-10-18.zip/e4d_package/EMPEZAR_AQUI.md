# Lobo Gélido — Empezar a crear la aplicación

Paquete: **BUILD_START** (P6 CODE_FIXED + auditoría + gates conectados)

## Requisitos

- **JDK 17** (no 21/25)
- Android SDK + **NDK 27.3.13750724**
- CMake 3.22+
- Dispositivo/emulador **arm64-v8a**, Android ≥ 29
- RAM recomendada del PC de build: **≥ 8 GiB**

## Crear el APK (3 pasos)

```bash
cd e4d_package

# 1) SDK
cp local.properties.example local.properties
# Edita local.properties:
#   sdk.dir=/ruta/absoluta/a/tu/Android/Sdk
cp local.properties android/local.properties

# 2) Compilar
cd android
./gradlew :app:assembleDebug --no-daemon

# 3) Verificar nativo (obligatorio)
bash ../tools/verify_native_so.sh app/build/outputs/apk/debug/app-debug.apk
```

Salida esperada del paso 3: **OK … without TEXTREL**

APK:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Instalar limpio

```bash
adb uninstall com.lobogelido
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Tras instalar

1. Abrir app (shell + temas)
2. Importar **prod.keys** y firmware
3. Carpeta con 1–2 NSP
4. Biblioteca → Reextraer carátulas (si hace falta)
5. Jugar + `adb logcat` si falla

O checklist automatizada (pasos 1–3):

```bash
export JAVA_HOME=... ANDROID_HOME=...
bash tools/run_e2e_checklist.sh
```

## Qué incluye este ZIP (conectado)

| Componente | Estado |
|------------|--------|
| UI / temas / rail | Conectado |
| Keys / firmware / biblioteca SAF | Conectado |
| JNI RuntimeBridge (39 símbolos) | Conectado |
| Loader NSP/XCI/NCA + soft validate | Conectado |
| MMU / PagePool / trim | Conectado |
| Vulkan + async pipeline cache | Conectado |
| AAudio host | Conectado |
| Cover pipeline + artwork loader | Conectado |
| Anti-TEXTREL CMake | Conectado |
| gradle-wrapper.jar | Incluido |
| verify_native_so.sh | Incluido |

## applicationId

`com.lobogelido` · minSdk 29 · targetSdk 36 · NDK 27.3.13750724

## Integración 2026-10-18 (UI / carátulas / firmware)

- Biblioteca: carrusel horizontal con escala y centrado (`LibraryCarouselBinder`).
- Perfiles: portadas vía `LibraryArtworkLoader` (no `setImageURI` en hilo UI).
- Firmware: validación estricta (NCA / system / package1|2); rechaza ZIP arbitrarios.
- Logos: PNG + `LAYER_TYPE_SOFTWARE` / `FIT_CENTER` (sin cambio de fondos JPG).
