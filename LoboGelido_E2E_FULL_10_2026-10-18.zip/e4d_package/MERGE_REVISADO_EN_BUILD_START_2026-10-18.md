# Merge: REVISADO auditado → BUILD_START_MEJORADO

**Origen de mejoras:** `LoboGelido_SOFTWARE_VULKAN_V6_REVISADO_AUDITADO_2026-10-18`  
**Base destino:** `LoboGelido_BUILD_START_MEJORADO_UI_FW` (árbol de producto para crear la APK)

## Incorporado

### Software Vulkan (SwiftShader / Lavapipe)
- `gpu/software_vulkan_backend.{h,cpp}` — classify, score, resolve en capas, ICD JSON
- `vulkan_driver_policy` — bypass Adreno para ICD software
- `android_vulkan_context` — LOBO_FORCE_SOFTWARE, device score, diagnostics `software=`
- UI: `GpuDriverManager`, `GameSurfaceView`, `MainActivity`, facade
- `tools/setup_software_vulkan.sh`, `test_software_vulkan_policy`, `SOFTWARE_VULKAN.md`

### Shaders (métricas honestas + soft/strict)
- `translate.{h,cpp}` — soft NOP, coverage_report = dispatch surface
- `translate_texture.inc` — fix warning atomic wide
- Tests M1 estrictos + regresiones soft
- CMake: `lobogelido_core PUBLIC lobogelido_shader`, CTest software policy

### Documentación
- REVISION_TECNICA_GPU_HLE, SHADER_MAX, AUDITORIA_REVISADO

## Conservado del BUILD_START
- UI/carrusel, carátulas, firmware estricto, temas, loader, resto del árbol e4d_package no listado arriba.
