#pragma once
#include <cstdint>
#include <string>
#include "../core/result.h"
#include "../runtime/runtime_storage.h"

namespace lg::loader {
struct ContentMetadata {
    std::string format;
    std::string title_id;
    std::string serial;
    std::string title;
    std::string publisher;
    std::string version;
    std::string control_nacp_path;
    std::string icon_path;
    bool keys_available{};
    bool control_decrypted{};
    std::string diagnostic;
};
class ContentMetadataInspector final {
public:
    static core::Result<ContentMetadata> inspect(const std::string& path,
                                                  const runtime::RuntimeStorage& storage,
                                                  const std::string& output_dir);
};
}
