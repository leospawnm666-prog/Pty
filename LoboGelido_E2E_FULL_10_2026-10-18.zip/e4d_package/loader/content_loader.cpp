#include "content_loader.h"
#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <limits>
#include <string>
#include "../crypto/sha256.h"
#include "nro_loader.h"
#include "nso_loader.h"
namespace lg::loader {
namespace {
uint32_t u32(const uint8_t* b, size_t o){ return uint32_t(b[o])|uint32_t(b[o+1])<<8|uint32_t(b[o+2])<<16|uint32_t(b[o+3])<<24; }
uint64_t u64(const uint8_t* b, size_t o){ return uint64_t(u32(b,o)) | (uint64_t(u32(b,o+4))<<32); }

bool read_at(std::ifstream& f, uint64_t offset, void* dst, std::size_t size) {
    if (offset > static_cast<uint64_t>(std::numeric_limits<std::streamoff>::max())) return false;
    f.clear();
    f.seekg(static_cast<std::streamoff>(offset), std::ios::beg);
    return bool(f.read(reinterpret_cast<char*>(dst), static_cast<std::streamsize>(size)));
}

bool parse_pfs0(std::ifstream& f, uint64_t base, uint64_t file_size, std::vector<ContainerEntry>& entries) {
    std::array<uint8_t, 0x10> h{};
    if (base > file_size || file_size - base < h.size() || !read_at(f, base, h.data(), h.size())) return false;
    if (std::memcmp(h.data(), "PFS0", 4) != 0) return false;
    const uint32_t count = u32(h.data(), 4);
    const uint32_t string_size = u32(h.data(), 8);
    constexpr uint64_t entry_size = 0x18;
    const uint64_t table = base + 0x10;
    const uint64_t strings = table + uint64_t(count) * entry_size;
    if (count > 65536 || strings > file_size || string_size > file_size - strings) return false;
    std::vector<uint8_t> string_table(string_size);
    if (string_size && !read_at(f, strings, string_table.data(), string_table.size())) return false;
    entries.clear();
    entries.reserve(count);
    for (uint32_t i = 0; i < count; ++i) {
        std::array<uint8_t, entry_size> e{};
        if (!read_at(f, table + uint64_t(i) * entry_size, e.data(), e.size())) return false;
        const uint64_t rel_offset = u64(e.data(), 0);
        const uint64_t size = u64(e.data(), 8);
        const uint32_t name_offset = u32(e.data(), 16);
        if (rel_offset > file_size - strings - string_size || size > file_size - (strings + string_size + rel_offset)) return false;
        if (name_offset >= string_table.size()) return false;
        const char* name = reinterpret_cast<const char*>(string_table.data() + name_offset);
        const auto remaining = string_table.size() - name_offset;
        const void* nul = std::memchr(name, '\0', remaining);
        if (!nul) return false;
        entries.push_back({std::string(name), strings + string_size + rel_offset, size, 0, {}, false});
    }
    return true;
}


bool parse_hfs0(std::ifstream& f, uint64_t base, uint64_t file_size, std::vector<ContainerEntry>& entries) {
    std::array<uint8_t, 0x10> h{};
    if (base > file_size || file_size - base < h.size() || !read_at(f, base, h.data(), h.size())) return false;
    if (std::memcmp(h.data(), "HFS0", 4) != 0) return false;
    const uint32_t count = u32(h.data(), 4);
    const uint32_t string_size = u32(h.data(), 8);
    constexpr uint64_t entry_size = 0x40;
    const uint64_t table = base + 0x10;
    const uint64_t strings = table + uint64_t(count) * entry_size;
    const uint64_t data_base = strings + string_size;
    if (count > 65536 || strings > file_size || string_size > file_size - strings) return false;
    std::vector<uint8_t> string_table(string_size);
    if (string_size && !read_at(f, strings, string_table.data(), string_table.size())) return false;
    entries.clear(); entries.reserve(count);
    for (uint32_t i=0;i<count;i++) {
        std::array<uint8_t, entry_size> e{};
        if (!read_at(f, table + uint64_t(i)*entry_size, e.data(), e.size())) return false;
        const uint64_t rel_offset=u64(e.data(),0), size=u64(e.data(),8);
        const uint32_t name_offset=u32(e.data(),16);
        const uint32_t hashed_size=u32(e.data(),20);
        if (rel_offset > file_size-data_base || size > file_size-data_base-rel_offset || name_offset >= string_table.size() || hashed_size > size) return false;
        const char* name=reinterpret_cast<const char*>(string_table.data()+name_offset);
        if (!std::memchr(name,'\0',string_table.size()-name_offset)) return false;
                std::array<uint8_t,32> hash{}; std::copy_n(e.data()+0x20, 32, hash.data());
        entries.push_back({std::string(name), data_base+rel_offset, size, hashed_size, hash, true});
    }
    return true;
}

[[maybe_unused]] bool find_pfs0(std::ifstream& f, uint64_t file_size, uint64_t& base, std::vector<ContainerEntry>& entries) {
    constexpr uint64_t kScanLimit = 16ull * 1024ull * 1024ull;
    constexpr std::size_t kChunk = 1024 * 1024;
    const uint64_t limit = std::min(file_size, kScanLimit);
    std::vector<uint8_t> buf(kChunk);
    for (uint64_t cursor = 0; cursor < limit;) {
        const std::size_t want = static_cast<std::size_t>(std::min<uint64_t>(buf.size(), limit - cursor));
        if (!read_at(f, cursor, buf.data(), want)) return false;
        for (std::size_t i = 0; i + 4 <= want; ++i) {
            if (std::memcmp(buf.data() + i, "PFS0", 4) != 0) continue;
            const uint64_t candidate = cursor + i;
            if (parse_pfs0(f, candidate, file_size, entries)) { base = candidate; return true; }
        }
        if (want < buf.size()) break;
        cursor += want - 3; // overlap the magic across chunk boundaries.
    }
    return false;
}
}


bool validate_hfs_hashes(std::ifstream& f, const std::vector<ContainerEntry>& entries) {
    std::vector<uint8_t> bytes;
    for (const auto& e : entries) {
        if (!e.has_hash) continue;
        if (e.hashed_size == 0) continue;
        bytes.resize(e.hashed_size);
        if (!read_at(f, e.offset, bytes.data(), bytes.size())) return false;
        const auto digest = crypto::Sha256::digest(bytes);
        if (digest != e.hash) return false;
    }
    return true;
}

bool ContentLoader::read_file(const std::string&p,std::vector<uint8_t>&o){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)return false;auto n=f.tellg();if(n<0)return false;o.resize(size_t(n));f.seekg(0);return bool(f.read(reinterpret_cast<char*>(o.data()),n));}

ContentInfo ContentLoader::inspect(const std::string&p){
    ContentInfo i{}; i.path=p;
    std::ifstream f(p,std::ios::binary|std::ios::ate); if(!f)return i; auto n=f.tellg(); if(n<0)return i; i.size=uint64_t(n); f.seekg(0);
    std::array<uint8_t,0x400> b{}; f.read(reinterpret_cast<char*>(b.data()),b.size()); if(f.gcount()<4)return i;
    const std::string magic(reinterpret_cast<char*>(b.data()),4);
    if(magic=="NRO0") {
        i.format=Format::Nro; i.valid=i.size>=0x80;
        if(i.valid){ for(int k=0;k<3;k++){ const size_t o=0x10+size_t(k)*0x10; const uint64_t off=u64(b.data(),o), sz=u64(b.data(),o+8); if(sz){const uint32_t perms=k==0?(memory::Read|memory::Execute|memory::User):(k==1?(memory::Read|memory::User):(memory::Read|memory::Write|memory::User)); i.segments.push_back({off,sz,0x100000ull+uint64_t(k)*0x1000000ull,perms});}}}
    } else if(magic=="NSO0" && [&]{
        // P3.0-A: the real format first. The synthetic reader below accepts almost anything,
        // real NSOs included (as garbage segments), so it can only be the fallback.
        if(i.size<0x100 || i.size>NsoLoader::kMaxImageSize) return false;
        std::vector<uint8_t> file(static_cast<size_t>(i.size));
        if(!read_at(f,0,file.data(),file.size())) return false;
        const auto parsed=NsoLoader::parse(file);
        if(!parsed.ok() || !NsoLoader::layout(parsed.value()).ok()) return false;
        i.format=Format::Nso; i.valid=true; i.native_nso=true;
        for(const auto& s: parsed.value().segments)
            i.segments.push_back({0,s.bytes.size(),s.memory_offset,s.permissions});   // relative to the image base
        return true;
    }()) {
        // real NSO: filled by the lambda above
    } else if(magic=="NSO0") {
        i.format=Format::Nso; i.valid=i.size>=0x100;
        if(i.valid){ for(int k=0;k<3;k++){ const size_t o=0x10+size_t(k)*8; const uint64_t off=u32(b.data(),o), sz=u32(b.data(),o+4), load=u64(b.data(),0x20+size_t(k)*8); if(sz){const uint32_t perms=k==0?(memory::Read|memory::Execute|memory::User):(k==1?(memory::Read|memory::User):(memory::Read|memory::Write|memory::User)); i.segments.push_back({off,sz,load,perms});}}}
    } else if(magic=="NCA3"||magic=="NCA2") { i.format=Format::Nca; i.valid=i.size>=0x4000; i.secure_container=true; }
    else if(NroLoader::looks_like(b.data(), size_t(f.gcount()))) {
        // P3.0: real NRO. Only the image [0, size) is read and validated (assets such as a
        // RomFS may follow and can be large); the synthetic format above is checked first.
        i.format=Format::Nro; i.native_nro=true;
        const uint64_t declared=u32(b.data(),0x18);
        if(declared>=NroLoader::kHeaderEnd && declared<=i.size && declared<=NroLoader::kMaxMappedSize){
            std::vector<uint8_t> image(static_cast<size_t>(declared));
            if(read_at(f,0,image.data(),image.size())){
                const auto parsed=NroLoader::parse(image);
                if(parsed.ok()){
                    const auto& m=parsed.value();
                    i.valid=true; i.nro_bss_size=m.bss_size;
                    i.segments.push_back({m.text.offset,m.text.size,m.text.offset,memory::Read|memory::Execute|memory::User});
                    i.segments.push_back({m.ro.offset,m.ro.size,m.ro.offset,memory::Read|memory::User});
                    i.segments.push_back({m.data.offset,m.data.size,m.data.offset,memory::Read|memory::Write|memory::User});
                }
            }
        }
    }
    else {
        std::vector<ContainerEntry> entries; [[maybe_unused]] uint64_t pfs_base=0;
        if (parse_pfs0(f, 0, i.size, entries)) { i.format=Format::Nsp; i.valid=!entries.empty(); i.entries=std::move(entries); i.secure_container=true; }
        else if (std::string(reinterpret_cast<char*>(b.data()+0x100), 4) == "HEAD") {
            std::vector<ContainerEntry> root_entries;
            if (parse_hfs0(f, 0x10000, i.size, root_entries)) {
                if (!validate_hfs_hashes(f, root_entries)) return i;
                // XCI's root HFS0 contains normal/update/logo/secure partitions.
                // Prefer the secure partition because it contains the program NCAs.
                for (const auto& part : root_entries) {
                    if (part.name == "secure" || part.name == "Secure") {
                        std::vector<ContainerEntry> secure_entries;
                        if (parse_hfs0(f, part.offset, i.size, secure_entries) && validate_hfs_hashes(f, secure_entries)) entries = std::move(secure_entries);
                        break;
                    }
                }
                if (entries.empty()) entries = std::move(root_entries);
            }
            if (!entries.empty()) { i.format=Format::Xci; i.valid=true; i.entries=std::move(entries); i.secure_container=true; }
        }
    }
    return i;
}

core::Result<ContainerEntry> ContentLoader::find_program_nca(const ContentInfo& info) {
    if (!info.valid || (info.format != Format::Nsp && info.format != Format::Xci))
        return core::Result<ContainerEntry>::Error("content is not an NSP/XCI container");
    // Score NCA candidates without decrypting headers:
    //  - Prefer names without "cnmt" / "control" / "manual" / "html" / "legal" (meta/control content)
    //  - Prefer larger size (Program NCAs dominate)
    //  - Prefer *.nca over *.ncz
    const ContainerEntry* best = nullptr;
    int best_score = -1;
    for (const auto& e : info.entries) {
        if (e.name.size() < 4 || e.size == 0) continue;
        std::string n = e.name;
        std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        const bool is_nca = n.size() >= 4 && (n.ends_with(".nca") || n.ends_with(".ncz"));
        if (!is_nca) continue;
        int score = 0;
        if (n.ends_with(".nca")) score += 10;
        if (n.find("cnmt") != std::string::npos) score -= 50;
        if (n.find("control") != std::string::npos) score -= 40;
        if (n.find("manual") != std::string::npos) score -= 40;
        if (n.find("html") != std::string::npos) score -= 40;
        if (n.find("legal") != std::string::npos) score -= 40;
        if (n.find("program") != std::string::npos) score += 30;
        // Size tiers: Program NCAs are typically >> 1 MiB
        if (e.size >= 8ull * 1024ull * 1024ull) score += 25;
        else if (e.size >= 1024ull * 1024ull) score += 15;
        else if (e.size >= 64ull * 1024ull) score += 5;
        else score -= 5;
        if (score > best_score) {
            best_score = score;
            best = &e;
        }
    }
    if (!best) return core::Result<ContainerEntry>::Error("container contains no NCA entries");
    return core::Result<ContainerEntry>::Ok(*best);
}

bool ContentLoader::load_plaintext(const ContentInfo& info, memory::AddressSpace& memory, LoadResult& out) {
    out={}; if(!info.valid || (info.format!=Format::Nro && info.format!=Format::Nso) || info.segments.empty()) return false;
    if(info.native_nro) return false;   // P3.0: real NROs are mapped by system::ProcessLayout
    if(info.native_nso) return false;   // P3.0-A: real NSOs too (system::build_nso_process)
    std::vector<uint8_t> file; if(!read_file(info.path,file)) return false;
    uint64_t min_addr=std::numeric_limits<uint64_t>::max(), max_addr=0;
    for(const auto& s: info.segments){ if(!s.file_size || s.file_offset>file.size() || s.file_size>file.size()-s.file_offset) return false; if(s.load_address>std::numeric_limits<uint64_t>::max()-s.file_size)return false; if(!s.permissions)return false; min_addr=std::min(min_addr,s.load_address); max_addr=std::max(max_addr,s.load_address+s.file_size); }
    const uint64_t page=4096, base=min_addr&~(page-1), end=(max_addr+page-1)&~(page-1); if(end<=base||!memory.map(base,end-base))return false;
    for(const auto&s:info.segments){for(uint64_t n=0;n<s.file_size;){const uint64_t chunk=std::min<uint64_t>(s.file_size-n,4096);for(uint64_t j=0;j<chunk;j++)memory.write8(s.load_address+n+j,file[size_t(s.file_offset+n+j)]);n+=chunk;}}
    out.image_base=base;out.image_size=end-base;out.segment_count=uint32_t(info.segments.size());out.entry_point=info.segments.front().load_address;return true;
}

// Fusion fix (2026-10-16): these helpers are declared in lg::loader (content_loader.h) and were
// defined after the namespace had been closed, so the file did not compile.
const char* format_name(Format f) noexcept {
    switch (f) {
    case Format::Nro: return "NRO";
    case Format::Nso: return "NSO";
    case Format::Nca: return "NCA";
    case Format::Nsp: return "NSP";
    case Format::Xci: return "XCI";
    case Format::RomFsContainer: return "RomFS";
    default: return "Unknown";
    }
}

std::string inspect_summary(const ContentInfo& info) {
    std::string s = format_name(info.format);
    s += " size=";
    s += std::to_string(info.size);
    s += " segs=";
    s += std::to_string(info.segments.size());
    s += " entries=";
    s += std::to_string(info.entries.size());
    size_t nca = 0, meta = 0, control = 0;
    for (const auto& e : info.entries) {
        std::string n = e.name;
        std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        if (n.size() >= 4 && (n.ends_with(".nca") || n.ends_with(".ncz"))) {
            ++nca;
            if (n.find("cnmt") != std::string::npos) ++meta;
            if (n.find("control") != std::string::npos) ++control;
        }
    }
    if (nca) {
        s += " nca=";
        s += std::to_string(nca);
        if (meta) { s += " cnmt="; s += std::to_string(meta); }
        if (control) { s += " control="; s += std::to_string(control); }
    }
    if (info.secure_container) s += " secure";
    if (info.native_nro) s += " native_nro";
    if (info.native_nso) s += " native_nso";
    s += info.valid ? " valid" : " invalid";
    return s;
}
} // namespace lg::loader
