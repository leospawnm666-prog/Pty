#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "../core/result.h"

namespace lg::loader {
struct RomFsEntry { std::string path; uint64_t offset{}; uint64_t size{}; bool directory{}; };
class RomFsImage final {
public:
    static core::Result<RomFsImage> parse(const std::vector<uint8_t>& image);
    const std::vector<RomFsEntry>& entries() const noexcept { return entries_; }
    core::Result<std::vector<uint8_t>> read_file(const std::string& path) const;
    core::Result<std::vector<uint8_t>> find_file(const std::string& basename) const;
private:
    std::vector<uint8_t> image_;
    std::vector<RomFsEntry> entries_;
};
}
