#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

#include "../core/result.h"
#include "../memory/address_space.h"

namespace lg::loader {

struct NsoSegmentImage {
    std::string name;
    uint64_t memory_offset{};
    uint64_t memory_size{};
    uint32_t permissions{};
    std::vector<uint8_t> bytes;
};

struct NsoImage {
    uint32_t flags{};
    std::array<uint8_t, 0x20> module_id{};
    std::vector<NsoSegmentImage> segments;
    uint64_t image_base{};
    uint64_t image_size{};
    uint64_t entry_point{};
};

// P3.0-A: page-rounded placement of a real NSO relative to its image base (see
// P3_0_A_DISENO.md 3.1). text/ro/rw are [begin, end) with 4 KiB-rounded ends.
struct NsoLayout {
    struct Range { uint64_t begin{}, end{}; };
    Range text, ro, rw;        // rw = .data + .bss
    uint64_t data_end{};       // end of the .data file bytes (start of .bss)
    uint64_t bss_end{};        // data_end + .bss size (unrounded)
    uint64_t extent{};         // bytes to reserve from the image base (= rw.end)
};

class NsoLoader final {
public:
    static constexpr uint64_t kMaxSegmentSize = 1ull << 30;   // P3.0-A (D-A-2)
    static constexpr uint64_t kMaxImageSize = 1ull << 30;
    /** P3.0-A: strict placement rules for loading a plaintext NSO into a process (only
     *  the new path uses them; parse() keeps accepting what it accepted). Pure. */
    static core::Result<NsoLayout> layout(const NsoImage& image);
    static core::Result<NsoImage> parse(const std::vector<uint8_t>& file);
    static core::Result<void> map_into_memory(const NsoImage& image, memory::AddressSpace& memory, uint64_t load_base);
};

} // namespace lg::loader
