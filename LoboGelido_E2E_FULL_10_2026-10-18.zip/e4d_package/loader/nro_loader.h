#pragma once
// P3.0: real homebrew NRO executables (the format written by switch-tools/elf2nro and
// loaded by nx-hbloader on the console).
//
//   0x00 NroStart  { u32 unused (a branch over the header); u32 mod0_offset; u8 pad[8] }
//   0x10 NroHeader { "NRO0"; u32 version; u32 size; u32 flags;
//                    {u32 file_off, u32 size} text, ro, data;   // file offset == memory offset
//                    u32 bss_size; u32 unk; u8 build_id[0x20]; u8 pad[0x20] }       // ends 0x80
//   [size ...]     optional asset section ("ASET": icon, NACP, RomFS), not part of the image
//
// nx-hbloader maps [0, size + bss) contiguously (rounded to 4 KiB): .text R-X, .rodata R,
// .data + .bss RW, and enters at the start of the image. parse() is PURE: it validates the
// header with 64-bit arithmetic and never touches guest memory, so it can be fuzzed alone.
//
// This is not the synthetic "NRO0 at offset 0" format used by Lobo's own tests; that one
// is still handled, unchanged, by ContentLoader.
#include <array>
#include <cstdint>
#include <vector>
#include "../core/result.h"

namespace lg::loader {

struct NroSegment {
    uint64_t offset{};   // file offset == offset from the image base
    uint64_t size{};
};

struct NroImage {
    NroSegment text, ro, data;
    uint64_t bss_size{};
    uint64_t image_size{};    // header "size": file bytes that belong to the image
    uint64_t mapped_size{};   // image_size + bss_size, rounded up to 4 KiB
    uint64_t rw_size{};       // .data + .bss, rounded up to 4 KiB (hbloader's rw_size)
    uint32_t mod0_offset{};
    bool mod0_valid{};        // "MOD0" found at mod0_offset inside the image (diagnostic only)
    bool has_assets{};        // an "ASET" section follows the image
    std::array<uint8_t, 0x20> build_id{};
};

class NroLoader final {
public:
    static constexpr uint64_t kHeaderEnd = 0x80;
    static constexpr uint64_t kPage = 0x1000;
    /** Sanity cap on the mapped image (the largest known homebrew is tens of MiB). The
     *  caller also checks it against the guest memory budget. */
    static constexpr uint64_t kMaxMappedSize = 1ull << 30;

    /** True if `bytes` start like a real NRO ("NRO0" at 0x10). Cheap, no validation. */
    static bool looks_like(const uint8_t* bytes, size_t size) noexcept;
    static core::Result<NroImage> parse(const std::vector<uint8_t>& file);
};

} // namespace lg::loader
