#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include "../core/result.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"
namespace lg::loader {
enum class Format { Unknown, Nro, Nso, Nca, Nsp, Xci, RomFsContainer };
struct Segment {
    uint64_t file_offset{}, file_size{}, load_address{};
    uint32_t permissions{};
};
struct ContainerEntry {
    std::string name;
    uint64_t offset{};
    uint64_t size{};
    uint32_t hashed_size{};
    std::array<uint8_t,32> hash{};
    bool has_hash{};
};
struct ContentInfo {
    Format format{Format::Unknown};
    uint64_t size{};
    std::string path;
    std::vector<Segment> segments;
    std::vector<ContainerEntry> entries;
    bool valid{};
    bool secure_container{};
    // P3.0: a real homebrew NRO ("NRO0" at 0x10, as written by elf2nro). Its segments hold
    // file offsets/sizes and load_address RELATIVE to the image base; the process builder
    // (system/process_layout) maps it. load_plaintext() refuses it. False for the synthetic
    // "NRO0 at offset 0" format, which keeps its old meaning.
    bool native_nro{};
    uint64_t nro_bss_size{};
    // P3.0-A: a real plaintext NSO (the format written by elf2nso), accepted by
    // NsoLoader::parse AND NsoLoader::layout. Mapped by system::build_nso_process;
    // load_plaintext() refuses it. Lobo's synthetic NSO format keeps native_nso == false.
    bool native_nso{};
};
struct LoadResult { uint64_t entry_point{}; uint64_t image_base{}; uint64_t image_size{}; uint32_t segment_count{}; };
const char* format_name(Format f) noexcept;
/** Human-readable one-line summary for UI / diagnostics. */
std::string inspect_summary(const ContentInfo& info);
class ContentLoader {
public:
    static core::Result<ContainerEntry> find_program_nca(const ContentInfo& info);
    static ContentInfo inspect(const std::string& path);
    static bool read_file(const std::string& path,std::vector<uint8_t>& out);
    // Loads only plaintext executable segments described by the container header.
    static bool load_plaintext(const ContentInfo& info, memory::AddressSpace& memory, LoadResult& out);
};
}
