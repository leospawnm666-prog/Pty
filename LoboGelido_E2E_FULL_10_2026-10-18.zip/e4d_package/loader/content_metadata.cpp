#include "content_metadata.h"
#include "content_loader.h"
#include "nca_loader.h"
#include "romfs.h"
#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <cstring>

namespace lg::loader {
namespace {
namespace fs = std::filesystem;

std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return s;
}

std::string hex64(uint64_t v) {
    std::ostringstream o;
    o << std::hex << std::setfill('0') << std::setw(16) << v;
    return o.str();
}

[[maybe_unused]] std::string clean(const std::vector<uint8_t>& b, size_t off, size_t max) {
    if (off >= b.size()) return {};
    const size_t n = std::min(max, b.size() - off);
    size_t e = 0;
    while (e < n && b[off + e] != 0) ++e;
    return std::string(reinterpret_cast<const char*>(b.data() + off), e);
}

[[maybe_unused]] std::string json_escape(const std::string& s) {
    std::string o;
    for (char c : s) {
        switch (c) {
            case '\\': o += "\\\\"; break;
            case '"': o += "\\\""; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default: o += c; break;
        }
    }
    return o;
}

struct NcaCandidate { NcaSource source; };

std::vector<NcaCandidate> candidates(const ContentInfo& i) {
    std::vector<NcaCandidate> out;
    if (i.format == Format::Nca) {
        out.push_back({{i.path, 0, i.size}});
        return out;
    }
    for (const auto& e : i.entries) {
        const auto n = lower(e.name);
        if (n.size() >= 4 && n.substr(n.size() - 4) == ".nca")
            out.push_back({{i.path, e.offset, e.size}});
    }
    return out;
}

bool write_atomic(const fs::path& target, const std::vector<uint8_t>& bytes) {
    std::error_code ec;
    fs::create_directories(target.parent_path(), ec);
    if (ec) return false;

    fs::path tmp = target;
    tmp += ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return false;
        if (!bytes.empty())
            out.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        out.flush();
        if (!out) {
            out.close();
            fs::remove(tmp, ec);
            return false;
        }
    }

    fs::rename(tmp, target, ec);
    if (ec) {
        fs::remove(tmp, ec);
        return false;
    }
    return true;
}

std::string trim_utf8_fixed(const std::vector<uint8_t>& b, size_t off, size_t max) {
    if (off >= b.size()) return {};
    const size_t n = std::min(max, b.size() - off);
    size_t e = 0;
    while (e < n && b[off + e] != 0) ++e;
    while (e > 0 && (b[off + e - 1] == ' ' || b[off + e - 1] == '\0')) --e;
    return std::string(reinterpret_cast<const char*>(b.data() + off), e);
}

std::string nacp_field(const std::vector<uint8_t>& b, size_t off, size_t max) {
    return trim_utf8_fixed(b, off, max);
}

void parse_nacp(const std::vector<uint8_t>& b, ContentMetadata& out) {
    if (b.size() < 0x3070) return;
    static constexpr int preferred[] = {5, 6, 0, 1, 2, 3, 4, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    for (int lang : preferred) {
        const size_t off = size_t(lang) * 0x300;
        if (off + 0x300 > b.size()) continue;
        if (out.title.empty()) out.title = nacp_field(b, off, 0x200);
        if (out.publisher.empty()) out.publisher = nacp_field(b, off + 0x200, 0x100);
        if (!out.title.empty() && !out.publisher.empty()) break;
    }
    if (out.serial.empty()) out.serial = nacp_field(b, 0x3000, 0x25);
    if (out.version.empty()) out.version = nacp_field(b, 0x3060, 0x10);
}

} // namespace

core::Result<ContentMetadata> ContentMetadataInspector::inspect(
    const std::string& path, const runtime::RuntimeStorage& storage, const std::string& output_dir) {
    try {
        const auto info = ContentLoader::inspect(path);
        if (!info.valid)
            return core::Result<ContentMetadata>::Error("content metadata: invalid container");

        ContentMetadata out{};
        out.format = info.format == Format::Nsp ? "NSP" :
                     info.format == Format::Xci ? "XCI" :
                     info.format == Format::Nca ? "NCA" : "OTHER";
        std::string last;

        for (const auto& c : candidates(info)) {
            auto h = NcaLoader::inspect(c.source, storage);
            if (!h.ok()) { last = h.error(); continue; }
            const auto image = h.value();
            if (out.title_id.empty() && image.program_id != 0 && image.program_id != ~0ull)
                out.title_id = hex64(image.program_id);
            if (image.content_type != 2) continue;
            out.control_decrypted = false;

            for (uint8_t si = 0; si < image.section_count; ++si) {
                if (image.sections[si].fs_type != 0) continue;
                auto sec = NcaLoader::load_section(c.source, si, storage);
                if (!sec.ok()) { last = sec.error(); continue; }
                auto rom = RomFsImage::parse(sec.value().data);
                if (!rom.ok()) { last = rom.error(); continue; }
                out.control_decrypted = true;

                auto nacp = rom.value().find_file("control.nacp");
                if (nacp.ok()) {
                    parse_nacp(nacp.value(), out);
                    const fs::path base = fs::path(output_dir);
                    const auto stem = out.title_id.empty() ? "control" : out.title_id;
                    const fs::path np = base / (stem + ".nacp");
                    if (!write_atomic(np, nacp.value())) {
                        last = "content metadata: failed to atomically write control.nacp";
                    } else if (fs::exists(np)) {
                        out.control_nacp_path = np.string();
                    }
                }

                const std::vector<std::string> preferred_icons = {
                    "icon_americanenglish.dat", "icon_europeanenglish.dat", "icon_japanese.dat"};
                std::string selected;
                for (const auto& e : rom.value().entries()) {
                    if (e.directory) continue;
                    const auto slash = e.path.find_last_of('/');
                    const auto name = lower(e.path.substr(slash == std::string::npos ? 0 : slash + 1));
                    if (name.rfind("icon_", 0) != 0 || !name.ends_with(".dat")) continue;
                    if (selected.empty()) selected = e.path;
                    if (std::find(preferred_icons.begin(), preferred_icons.end(), name) != preferred_icons.end()) {
                        selected = e.path;
                        break;
                    }
                }

                if (!selected.empty()) {
                    auto bytes = rom.value().read_file(selected);
                    if (bytes.ok() && bytes.value().size() >= 3) {
                        const auto& v = bytes.value();
                        std::string ext = "jpg";
                        if (v.size() >= 8 && v[0] == 0x89 && v[1] == 'P' && v[2] == 'N' && v[3] == 'G')
                            ext = "png";
                        else if (v.size() >= 12 && v[0] == 'R' && v[1] == 'I' && v[2] == 'F' && v[3] == 'F' &&
                                 v[8] == 'W' && v[9] == 'E' && v[10] == 'B' && v[11] == 'P')
                            ext = "webp";
                        const fs::path base = fs::path(output_dir);
                        const fs::path ip = base / ((out.title_id.empty() ? "game" : out.title_id) + "." + ext);
                        if (!write_atomic(ip, v)) {
                            last = "content metadata: failed to atomically write embedded icon";
                        } else if (fs::exists(ip)) {
                            out.icon_path = ip.string();
                        }
                    }
                }
            }
        }

        if (out.title_id.empty() && last.empty()) last = "no Program/Control NCA metadata found";
        out.keys_available = storage.keys_ready();
        out.diagnostic = last;
        return core::Result<ContentMetadata>::Ok(std::move(out));
    } catch (const std::exception& e) {
        return core::Result<ContentMetadata>::Error(
            std::string("content metadata: exception while reading ExeFS/NSO/Control: ") + e.what());
    } catch (...) {
        return core::Result<ContentMetadata>::Error(
            "content metadata: unknown exception while reading ExeFS/NSO/Control");
    }
}

} // namespace lg::loader
