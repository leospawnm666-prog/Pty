#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

#include "../core/result.h"
#include "../runtime/runtime_storage.h"
#include "nso_loader.h"

namespace lg::loader {

struct NcaSource {
    std::string path;
    uint64_t offset{};
    uint64_t size{};
};

struct NcaSection {
    uint64_t offset{};
    uint64_t size{};
    uint8_t fs_type{};
    uint8_t hash_type{};
    uint8_t encryption_type{};
    std::array<uint8_t, 8> section_ctr{};
};

struct NcaSectionImage {
    NcaSection section{};
    std::vector<uint8_t> data;
    std::vector<std::string> pfs_entries;
};

struct NcaImage {
    uint8_t distribution_type{};
    uint8_t content_type{};
    uint8_t key_generation{};
    uint8_t crypto_generation{};
    uint8_t fs_hash_type{};
    uint8_t fs_encryption_type{};
    uint8_t key_area_index{};
    uint64_t program_id{};
    std::array<uint8_t, 16> rights_id{};
    std::array<NcaSection, 4> sections{};
    uint8_t section_count{};
    std::vector<uint8_t> exefs;
    NsoImage main_nso;
    std::vector<std::string> exefs_entries;
};

class NcaLoader final {
public:
    static core::Result<NcaImage> load_program(const NcaSource& source,
                                                 const runtime::RuntimeStorage& storage);
    static core::Result<NcaImage> inspect(const NcaSource& source,
                                          const runtime::RuntimeStorage& storage);
    static core::Result<NcaSectionImage> load_section(const NcaSource& source, uint8_t section_index,
                                                       const runtime::RuntimeStorage& storage);
};

} // namespace lg::loader
