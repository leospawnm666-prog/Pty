#include "nro_loader.h"

#include <cstring>

namespace lg::loader {
namespace {
uint32_t rd32(const std::vector<uint8_t>& b, size_t o) {
    return uint32_t(b[o]) | uint32_t(b[o + 1]) << 8 | uint32_t(b[o + 2]) << 16 | uint32_t(b[o + 3]) << 24;
}
core::Result<NroImage> fail(const char* why) {
    return core::Result<NroImage>::Error((std::string("NRO: ") + why).c_str());
}
constexpr bool aligned(uint64_t v) { return (v & (NroLoader::kPage - 1)) == 0; }
constexpr uint64_t round_up(uint64_t v) { return (v + NroLoader::kPage - 1) & ~(NroLoader::kPage - 1); }
} // namespace

bool NroLoader::looks_like(const uint8_t* bytes, size_t size) noexcept {
    return bytes && size >= 0x14 && std::memcmp(bytes + 0x10, "NRO0", 4) == 0;
}

core::Result<NroImage> NroLoader::parse(const std::vector<uint8_t>& file) {
    // 1. header present and signed
    if (file.size() < kHeaderEnd) return fail("file is smaller than the 0x80-byte header");
    if (!looks_like(file.data(), file.size())) return fail("missing NRO0 magic at 0x10");

    NroImage img{};
    img.mod0_offset = rd32(file, 0x04);
    img.image_size = rd32(file, 0x18);
    const uint32_t flags = rd32(file, 0x1C);
    (void)flags;   // no flag is defined for executables; kept for diagnostics only
    // 2. declared size inside the file (all arithmetic below is 64-bit: no overflow)
    if (img.image_size < kHeaderEnd) return fail("declared size is smaller than the header");
    if (img.image_size > file.size()) return fail("declared size exceeds the file");

    NroSegment* segs[3] = {&img.text, &img.ro, &img.data};
    const char* names[3] = {"text", "rodata", "data"};
    for (int i = 0; i < 3; ++i) {
        segs[i]->offset = rd32(file, 0x20 + size_t(i) * 8);
        segs[i]->size = rd32(file, 0x24 + size_t(i) * 8);
        // 3. nx-hbloader's own checks
        if (segs[i]->offset >= img.image_size || segs[i]->size > img.image_size ||
            segs[i]->offset + segs[i]->size > img.image_size)
            return fail((std::string(names[i]) + " segment lies outside the image").c_str());
        // 4. stricter than hbloader: page aligned
        if (!aligned(segs[i]->offset) || !aligned(segs[i]->size))
            return fail((std::string(names[i]) + " segment is not 4 KiB aligned").c_str());
    }
    // 4. stricter than hbloader: ordered, contiguous layout ending exactly at "size"
    if (img.text.offset != 0) return fail("text segment does not start at the image base");
    if (img.text.size == 0) return fail("text segment is empty");
    if (img.ro.offset < img.text.offset + img.text.size) return fail("rodata overlaps text");
    if (img.data.offset < img.ro.offset + img.ro.size) return fail("data overlaps rodata");
    if (img.data.offset + img.data.size != img.image_size)
        return fail("data segment does not end at the declared size (bss would be misplaced)");

    // 5. bss
    img.bss_size = rd32(file, 0x38);
    if (!aligned(img.bss_size)) return fail("bss size is not 4 KiB aligned");

    // 6. sizes the loader will reserve
    img.mapped_size = round_up(img.image_size + img.bss_size);
    img.rw_size = round_up(img.data.size + img.bss_size);
    if (img.mapped_size > kMaxMappedSize) return fail("image + bss exceeds the 1 GiB sanity limit");

    std::memcpy(img.build_id.data(), file.data() + 0x40, img.build_id.size());
    // 7. MOD0: diagnostic only (crt0 finds it by itself; hbloader does not check it)
    img.mod0_valid = img.mod0_offset >= kHeaderEnd && uint64_t(img.mod0_offset) + 4 <= img.image_size &&
                     std::memcmp(file.data() + img.mod0_offset, "MOD0", 4) == 0;
    img.has_assets = file.size() >= img.image_size + 4 &&
                     std::memcmp(file.data() + img.image_size, "ASET", 4) == 0;
    return core::Result<NroImage>::Ok(img);
}

} // namespace lg::loader
