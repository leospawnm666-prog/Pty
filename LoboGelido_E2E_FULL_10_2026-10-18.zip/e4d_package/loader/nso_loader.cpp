#include "nso_loader.h"

#include <algorithm>
#include <cstring>
#include <limits>
#include "../memory/mmu.h"

namespace lg::loader {
namespace {
uint32_t u32(const uint8_t* p) { return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24); }

core::Result<std::vector<uint8_t>> lz4_decompress_block(const uint8_t* src, size_t src_size, size_t dst_size) {
    std::vector<uint8_t> dst(dst_size);
    size_t si = 0, di = 0;
    while (si < src_size) {
        const uint8_t token = src[si++];
        size_t literal_len = token >> 4;
        if (literal_len == 15) {
            uint8_t b = 255;
            while (b == 255) {
                if (si >= src_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 literal length is truncated");
                b = src[si++]; literal_len += b;
            }
        }
        if (literal_len > src_size - si || literal_len > dst_size - di)
            return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 literal exceeds section bounds");
        std::memcpy(dst.data() + di, src + si, literal_len);
        si += literal_len; di += literal_len;
        if (si == src_size) break;
        if (si + 2 > src_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match offset is truncated");
        const uint16_t offset = uint16_t(src[si]) | (uint16_t(src[si + 1]) << 8); si += 2;
        if (offset == 0 || offset > di) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match offset is invalid");
        size_t match_len = token & 0x0F;
        if (match_len == 15) {
            uint8_t b = 255;
            while (b == 255) {
                if (si >= src_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match length is truncated");
                b = src[si++]; match_len += b;
            }
        }
        match_len += 4;
        if (match_len > dst_size - di) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 match exceeds section bounds");
        for (size_t n = 0; n < match_len; ++n) { const uint8_t value = dst[di - offset]; dst[di++] = value; }
    }
    if (di != dst_size) return core::Result<std::vector<uint8_t>>::Error("NSO LZ4 output size does not match header");
    return core::Result<std::vector<uint8_t>>::Ok(std::move(dst));
}

core::Result<std::vector<uint8_t>> section(const std::vector<uint8_t>& file, uint32_t file_offset, uint32_t file_size, uint32_t memory_size, bool compressed, const char* name) {
    if (uint64_t(file_offset) > file.size() || uint64_t(file_size) > file.size() - file_offset)
        return core::Result<std::vector<uint8_t>>::Error((std::string("NSO ") + name + " file range is invalid").c_str());
    if (memory_size == 0) return core::Result<std::vector<uint8_t>>::Ok({});
    if (!compressed) {
        if (file_size != memory_size) return core::Result<std::vector<uint8_t>>::Error((std::string("NSO ") + name + " uncompressed size mismatch").c_str());
        return core::Result<std::vector<uint8_t>>::Ok(std::vector<uint8_t>(file.begin() + file_offset, file.begin() + file_offset + file_size));
    }
    return lz4_decompress_block(file.data() + file_offset, file_size, memory_size);
}
}

core::Result<NsoImage> NsoLoader::parse(const std::vector<uint8_t>& file) {
    if (file.size() < 0x100 || std::memcmp(file.data(), "NSO0", 4) != 0)
        return core::Result<NsoImage>::Error("invalid NSO header");
    const uint32_t version = u32(file.data() + 4);
    const uint32_t flags = u32(file.data() + 0x0C);
    if (version != 0) return core::Result<NsoImage>::Error("unsupported NSO version");
    if (flags & (1u << 7)) return core::Result<NsoImage>::Error("NSO ZBIC compression is not implemented in this loader");

    // P3.0-A fix: .data's fourth header field (0x3C) is the .bss size. It used to be added
    // to .data's size (in 32 bits, which could wrap) and passed to LZ4 / the uncompressed
    // copy as the expected output, so every NSO with a .bss was rejected ("LZ4 output size
    // does not match header"). Now the file holds .data only; .bss is memory to be zeroed.
    const uint64_t bss_size = u32(file.data()+0x3C);
    struct H { uint32_t fo, mo, size, csize; const char* name; uint32_t perms; } h[3] = {
        {u32(file.data()+0x10), u32(file.data()+0x14), u32(file.data()+0x18), u32(file.data()+0x60), "text", memory::Read|memory::Execute|memory::User},
        {u32(file.data()+0x20), u32(file.data()+0x24), u32(file.data()+0x28), u32(file.data()+0x64), "rodata", memory::Read|memory::User},
        {u32(file.data()+0x30), u32(file.data()+0x34), u32(file.data()+0x38), u32(file.data()+0x68), "data", memory::Read|memory::Write|memory::User}
    };
    NsoImage image{}; image.flags = flags; std::memcpy(image.module_id.data(), file.data()+0x40, 0x20);
    uint64_t base = std::numeric_limits<uint64_t>::max(), end = 0;
    for (int i=0;i<3;i++) {
        const uint64_t extra = i == 2 ? bss_size : 0;                 // .bss follows .data
        const uint64_t memory_size = uint64_t(h[i].size) + extra;       // 64-bit: cannot wrap
        if (memory_size == 0) continue;
        if ((h[i].mo & 0xFFFu) != 0) return core::Result<NsoImage>::Error("NSO segment memory offset is not page aligned");
        if (uint64_t(h[i].mo) + h[i].size < h[i].mo) return core::Result<NsoImage>::Error("NSO segment address overflow");
        const bool compressed = (flags & (1u << i)) != 0;
        // P3.0-A (D-A-2): refuse implausible output sizes BEFORE allocating. LZ4 cannot
        // expand beyond ~255:1, and no segment is larger than 1 GiB; a hostile header used
        // to make the loader reserve up to 4 GiB before failing.
        if (compressed && (h[i].size > kMaxSegmentSize ||
                           uint64_t(h[i].size) > uint64_t(h[i].csize) * 255u + 16u))
            return core::Result<NsoImage>::Error((std::string("NSO ") + h[i].name + " decompressed size is implausible for LZ4").c_str());
        auto bytes = section(file, h[i].fo, h[i].csize, h[i].size, compressed, h[i].name);
        if (!bytes.ok()) return core::Result<NsoImage>::Error(bytes.error().c_str());
        NsoSegmentImage seg{}; seg.name=h[i].name; seg.memory_offset=h[i].mo; seg.memory_size=memory_size; seg.permissions=h[i].perms; seg.bytes=std::move(bytes.value());
        image.segments.push_back(std::move(seg)); base=std::min(base,uint64_t(h[i].mo)); end=std::max(end,uint64_t(h[i].mo)+memory_size);
    }
    if (image.segments.empty() || end <= base) return core::Result<NsoImage>::Error("NSO has no loadable segments");
    image.image_base=base; image.image_size=end-base; image.entry_point=image.segments.front().memory_offset;
    return core::Result<NsoImage>::Ok(std::move(image));
}

core::Result<NsoLayout> NsoLoader::layout(const NsoImage& image) {
    auto fail = [](const char* why) { return core::Result<NsoLayout>::Error((std::string("NSO layout: ") + why).c_str()); };
    constexpr uint64_t P = 0x1000;
    auto page = [](uint64_t v) { return (v + P - 1) & ~(P - 1); };
    if ((image.flags & ~0x3Fu) != 0) return fail("unknown header flags");
    if (image.segments.size() != 3 || image.segments[0].name != "text" || image.segments[1].name != "rodata" ||
        image.segments[2].name != "data")
        return fail("expected .text, .rodata and .data");
    const auto& t = image.segments[0];
    const auto& r = image.segments[1];
    const auto& d = image.segments[2];
    if (t.memory_offset != 0) return fail(".text does not start at the image base");
    if (t.bytes.empty()) return fail(".text is empty");
    NsoLayout l{};
    l.text = {t.memory_offset, page(t.memory_offset + t.memory_size)};
    l.ro = {r.memory_offset, page(r.memory_offset + r.memory_size)};
    l.data_end = d.memory_offset + d.bytes.size();
    l.bss_end = d.memory_offset + d.memory_size;                    // = data_end + .bss
    l.rw = {d.memory_offset, page(l.bss_end)};
    l.extent = l.rw.end;
    if (l.text.end > l.ro.begin) return fail(".rodata overlaps .text");
    if (l.ro.end > l.rw.begin) return fail(".data overlaps .rodata");
    if (l.extent > kMaxImageSize) return fail("image + .bss exceeds the 1 GiB sanity limit");
    return core::Result<NsoLayout>::Ok(l);
}

core::Result<void> NsoLoader::map_into_memory(const NsoImage& image, memory::AddressSpace& memory, uint64_t load_base) {
    for (const auto& seg : image.segments) {
        const uint64_t page = 4096;
        const uint64_t load_address = load_base + seg.memory_offset;
        if (load_address < load_base) return core::Result<void>::Error("NSO relocated address overflow");
        const uint64_t base = load_address & ~(page - 1);
        const uint64_t end_unaligned = load_address + seg.memory_size;
        const uint64_t end = (end_unaligned + page - 1) & ~(page - 1);
        if (end <= base || !memory.map(base, end - base)) return core::Result<void>::Error("failed to map NSO segment");
        for (size_t i=0;i<seg.bytes.size();++i) memory.write8(load_address+i, seg.bytes[i]);
        for (uint64_t i=seg.bytes.size(); i<seg.memory_size; ++i) memory.write8(load_address+i, 0);
    }
    return core::Result<void>::Ok();
}
} // namespace lg::loader
