#include "romfs.h"
#include <algorithm>
#include <cstring>
#include <limits>
#include <functional>
#include <unordered_set>
namespace lg::loader { namespace {
uint32_t u32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;} uint64_t u64(const uint8_t*p){return uint64_t(u32(p))|(uint64_t(u32(p+4))<<32);} constexpr uint32_t kInvalid=0xFFFFFFFFu;
std::string utf16le(const uint8_t* p,uint32_t bytes){std::string s; if(bytes%2)return s; for(uint32_t i=0;i<bytes;i+=2){uint32_t cp=uint32_t(p[i])|(uint32_t(p[i+1])<<8); if(cp==0)break; if(cp>=0xD800&&cp<=0xDFFF){s.push_back('?');continue;} if(cp<0x80)s.push_back(char(cp)); else if(cp<0x800){s.push_back(char(0xC0|(cp>>6)));s.push_back(char(0x80|(cp&63)));} else {s.push_back(char(0xE0|(cp>>12)));s.push_back(char(0x80|((cp>>6)&63)));s.push_back(char(0x80|(cp&63)));}} return s;}
}
core::Result<RomFsImage> RomFsImage::parse(const std::vector<uint8_t>& d){
 if(d.size()<0x28)return core::Result<RomFsImage>::Error("RomFS header is truncated");
 const uint32_t hlen=u32(d.data()); if(hlen!=0x28)return core::Result<RomFsImage>::Error("unsupported RomFS header length");
 const uint64_t dh=u32(d.data()+4), dhl=u32(d.data()+8), dm=u32(d.data()+12), dml=u32(d.data()+16), fh=u32(d.data()+20), fhl=u32(d.data()+24), fm=u32(d.data()+28), fml=u32(d.data()+32), fd=u32(d.data()+36);
 auto valid=[&](uint64_t o,uint64_t n){return o<=d.size()&&n<=d.size()-o;}; if(!valid(dh,dhl)||!valid(dm,dml)||!valid(fh,fhl)||!valid(fm,fml)||fd>d.size())return core::Result<RomFsImage>::Error("RomFS table bounds are invalid");

 RomFsImage out; out.image_=d;
 std::unordered_set<uint32_t> visited_dirs, visited_files;
 std::function<void(uint32_t,const std::string&)> dirs; dirs=[&](uint32_t off,const std::string& parent){
   if (out.entries_.size() > 1000000u) return;
   if (!visited_dirs.insert(off).second) return;
   if(off==kInvalid) return;
   if(off>=dml||off+0x18>dml||off%4) return;
   const auto*p=d.data()+dm+off; const uint32_t child=u32(p+8), file=u32(p+12), nameLen=u32(p+20); if(nameLen> dml-off-0x18 || nameLen%2)return; std::string name=utf16le(p+0x18,nameLen); std::string path=parent; if(!name.empty()){if(path!="/")path+='/';path+=name;} if(path.empty())path="/"; out.entries_.push_back({path,0,0,true});
   std::function<void(uint32_t)> files=[&](uint32_t fo){if(fo==kInvalid)return;if(!visited_files.insert(fo).second)return;if(fo>=fml||fo+0x20>fml||fo%4)return;const auto*q=d.data()+fm+fo;const uint32_t dir=u32(q),sib=u32(q+4); (void)dir;const uint64_t ro=u64(q+8),sz=u64(q+16);const uint32_t nl=u32(q+28);if(nl>fml-fo-0x20||nl%2||ro>d.size()-fd||sz>d.size()-fd-ro)return;std::string fn=utf16le(q+0x20,nl);std::string fp=path;if(fp!="/")fp+='/';fp+=fn;out.entries_.push_back({fp,fd+ro,sz,false});files(sib);};
   files(file); dirs(child,path); dirs(u32(p+4),parent);
 };
 dirs(0,"/");
 if(out.entries_.empty())return core::Result<RomFsImage>::Error("RomFS has no root directory");
 return core::Result<RomFsImage>::Ok(std::move(out));
}
core::Result<std::vector<uint8_t>> RomFsImage::read_file(const std::string& path) const {for(const auto&e:entries_)if(!e.directory&&e.path==path){if(e.size>std::numeric_limits<size_t>::max())return core::Result<std::vector<uint8_t>>::Error("RomFS file is too large");return core::Result<std::vector<uint8_t>>::Ok(std::vector<uint8_t>(image_.begin()+e.offset,image_.begin()+e.offset+e.size));}return core::Result<std::vector<uint8_t>>::Error("RomFS file not found");}
core::Result<std::vector<uint8_t>> RomFsImage::find_file(const std::string& basename) const {for(const auto&e:entries_)if(!e.directory&&e.path.size()>=basename.size()&&e.path.substr(e.path.size()-basename.size())==basename)return read_file(e.path);return core::Result<std::vector<uint8_t>>::Error("RomFS basename not found");}
}
