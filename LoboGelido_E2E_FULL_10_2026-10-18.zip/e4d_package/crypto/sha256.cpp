#include "sha256.h"
#include <cstring>

namespace lg::crypto {
namespace {
constexpr uint32_t K[64] = {
0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u};
inline uint32_t rotr(uint32_t x, uint32_t n){ return (x>>n)|(x<<(32-n)); }
inline uint32_t ch(uint32_t x,uint32_t y,uint32_t z){return (x&y)^(~x&z);} inline uint32_t maj(uint32_t x,uint32_t y,uint32_t z){return (x&y)^(x&z)^(y&z);}
inline uint32_t bs0(uint32_t x){return rotr(x,2)^rotr(x,13)^rotr(x,22);} inline uint32_t bs1(uint32_t x){return rotr(x,6)^rotr(x,11)^rotr(x,25);}
inline uint32_t ss0(uint32_t x){return rotr(x,7)^rotr(x,18)^(x>>3);} inline uint32_t ss1(uint32_t x){return rotr(x,17)^rotr(x,19)^(x>>10);}
inline uint32_t be32(const uint8_t* p){return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|uint32_t(p[3]);}
inline void putbe(uint8_t* p,uint32_t v){p[0]=uint8_t(v>>24);p[1]=uint8_t(v>>16);p[2]=uint8_t(v>>8);p[3]=uint8_t(v);}
}
Sha256::Sha256() noexcept : state_{0x6a09e667u,0xbb67ae85u,0x3c6ef372u,0xa54ff53au,0x510e527fu,0x9b05688cu,0x1f83d9abu,0x5be0cd19u} {}
void Sha256::transform(const uint8_t* b) noexcept {
    uint32_t w[64]; for(int i=0;i<16;i++) w[i]=be32(b+i*4); for(int i=16;i<64;i++) w[i]=ss1(w[i-2])+w[i-7]+ss0(w[i-15])+w[i-16];
    uint32_t a=state_[0],bb=state_[1],c=state_[2],d=state_[3],e=state_[4],f=state_[5],g=state_[6],h=state_[7];
    for(int i=0;i<64;i++){uint32_t t1=h+bs1(e)+ch(e,f,g)+K[i]+w[i],t2=bs0(a)+maj(a,bb,c);h=g;g=f;f=e;e=d+t1;d=c;c=bb;bb=a;a=t1+t2;}
    state_[0]+=a;state_[1]+=bb;state_[2]+=c;state_[3]+=d;state_[4]+=e;state_[5]+=f;state_[6]+=g;state_[7]+=h;
}
void Sha256::update(const uint8_t* data,std::size_t size) noexcept { bit_count_ += uint64_t(size)*8; while(size){const auto n=std::min<std::size_t>(size,64-buffered_);std::memcpy(buffer_.data()+buffered_,data,n);buffered_+=n;data+=n;size-=n;if(buffered_==64){transform(buffer_.data());buffered_=0;}} }
std::array<uint8_t,32> Sha256::final() noexcept { const uint64_t bits=bit_count_; buffer_[buffered_++]=0x80; if(buffered_>56){while(buffered_<64)buffer_[buffered_++]=0;transform(buffer_.data());buffered_=0;} while(buffered_<56)buffer_[buffered_++]=0; for(int i=7;i>=0;i--)buffer_[buffered_++]=uint8_t(bits>>(i*8)); transform(buffer_.data()); std::array<uint8_t,32> out{};for(int i=0;i<8;i++)putbe(out.data()+i*4,state_[i]); return out; }
std::array<uint8_t,32> Sha256::digest(const uint8_t* data,std::size_t size) noexcept {Sha256 s;s.update(data,size);return s.final();}
}
