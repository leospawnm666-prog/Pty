#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace lg::crypto {

using Aes128Key = std::array<uint8_t, 16>;

class Aes128 final {
public:
    explicit Aes128(const Aes128Key& key);
    void encrypt_block(const uint8_t in[16], uint8_t out[16]) const noexcept;
    void decrypt_block(const uint8_t in[16], uint8_t out[16]) const noexcept;

private:
    std::array<uint8_t, 176> round_keys_{};
};

void aes128_ctr_xor(const Aes128Key& key, uint8_t* data, std::size_t size,
                    std::array<uint8_t, 16> counter, uint64_t skip_bytes = 0);

void aes128_xts_encrypt(const std::array<uint8_t, 32>& key, uint8_t* data,
                        std::size_t size, uint64_t sector_number,
                        std::size_t sector_size = 0x200);

void aes128_xts_decrypt(const std::array<uint8_t, 32>& key, uint8_t* data,
                        std::size_t size, uint64_t sector_number,
                        std::size_t sector_size = 0x200);

} // namespace lg::crypto
