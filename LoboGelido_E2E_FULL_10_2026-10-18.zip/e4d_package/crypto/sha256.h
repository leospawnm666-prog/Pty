#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace lg::crypto {
class Sha256 final {
public:
    Sha256() noexcept;
    void update(const uint8_t* data, std::size_t size) noexcept;
    std::array<uint8_t,32> final() noexcept;
    static std::array<uint8_t,32> digest(const uint8_t* data, std::size_t size) noexcept;
    static std::array<uint8_t,32> digest(const std::vector<uint8_t>& data) noexcept { return digest(data.data(), data.size()); }
private:
    void transform(const uint8_t* block) noexcept;
    uint64_t bit_count_{0};
    std::array<uint8_t,64> buffer_{};
    std::size_t buffered_{0};
    std::array<uint32_t,8> state_{};
};
}
