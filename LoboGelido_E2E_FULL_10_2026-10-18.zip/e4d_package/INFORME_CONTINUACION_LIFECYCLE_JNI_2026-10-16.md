# Continuación técnica — Lifecycle / JNI / Vulkan

Fecha: 2026-10-16

## Base y límites

Este informe se agrega al paquete `LoboGelido_BETA_0.1_AUDITORIA_UI_LIFECYCLE_JNI_2026-10-16.zip`, cuyo árbol fuente procede del candidato UI Fase 3 disponible. No es la base oficial `LoboGelido_BETA_0.1_BASE_ACTUALIZADA_2026-09-28.zip`. No se modificó código de producción ni se reemplazó la base por inferencia.

## Reproducción ejecutada

Comando: `python tools_lifecycle_jni_audit.py`

Salida observada:

- Kotlin external declarations: 36 (36 unique)
- C++ JNI exports by name: 36 (36 unique)
- Unmatched Kotlin names: []
- Unmatched C++ names: []
- Surface/runtime separation check: PASS
- Gradle wrapper properties present: False
- Gradle wrapper JAR present: False
- Android build: NOT RUN (wrapper incompleto)

## Hallazgos de código para el siguiente cambio controlado

### LIF-01 — Barrera de teardown estricta

`GameSurfaceView.stopRendering()` pone `running=false`, interrumpe el hilo y hace `join()` hasta que el hilo termina. Esto evita liberar Vulkan mientras un render thread sigue en JNI, pero puede bloquear indefinidamente si una operación nativa no retorna. No se debe reemplazar por un timeout seguido de liberación de Vulkan: eso permitiría uso concurrente de recursos destruidos. La corrección requiere revisar si las operaciones nativas son cancelables y definir un protocolo explícito de parada/cancelación antes de tocar el teardown.

### LIF-02 — Resultado de teardown ignorado en callbacks

`surfaceDestroyed()` y `onDetachedFromWindow()` llaman `stopAndShutdownPresentation()` sin comprobar el Boolean de retorno. El método puede devolver `false` si se invoca desde el propio render thread. Aunque los callbacks normales de Surface/View se producen habitualmente en el hilo UI, el contrato debería hacer explícito qué propietario reintenta el cierre y cómo se registra un fallo; no afirmar cierre exitoso cuando el método indica que no completó.

### LIF-03 — Estado local tras excepción de shutdown

`stopAndShutdownPresentation()` captura cualquier `Throwable` de `RuntimeBridge.shutdownVulkan()` y luego fija `vulkanInitialized=false` en `finally`. La frontera nativa declara `shutdown_vulkan() noexcept` y también captura excepciones. Aun así, el contrato `void` no permite distinguir cierre real de fallo defensivo. Antes de cambiarlo hay que comprobar idempotencia de `VulkanPresenter::shutdown()` y `VulkanContext::shutdown()`, estados parciales y posibilidad de reintento. No se hizo un parche especulativo.

### JNI-01 — Pareja por nombre no equivale a ABI validado

La prueba compara nombres exportados, no descriptores JNI completos, tipos, orden de parámetros, resolución de símbolos del `.so` ni carga de biblioteca en Android. Aceptación pendiente: compilar Kotlin/C++, inspeccionar símbolos del binario y ejecutar una llamada por cada frontera crítica.

## Próximos criterios de aceptación

1. Recuperar y verificar SHA-256 de la base oficial autorizada.
2. Revisar firmas JNI completas y símbolos después de una compilación arm64-v8a real.
3. Añadir pruebas deterministas para destrucción/recreación de Surface y parada concurrente, sin `sleep`/`yield` como sincronización.
4. Confirmar idempotencia y recuperación de fallos parciales en presenter/context Vulkan.
5. Ejecutar pruebas en dispositivo: pausa/reanudación, salir durante preparación, recreación de Surface y fallo de inicialización.

## Estado

Auditoría estática reproducida. No se declara compilación, E2E, ni 100% de UI o Lifecycle/JNI. No se cambió código de producción porque el árbol autorizado exacto no está confirmado y el teardown necesita pruebas de propiedad/cancelación antes de un parche seguro.
