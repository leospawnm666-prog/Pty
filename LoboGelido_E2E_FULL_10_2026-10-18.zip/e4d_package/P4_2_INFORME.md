# P4.2 — Informe: etapas gráficas del recompilador Maxwell (hito H8)

Estado: **P4.2 implementado y verificado. Hito H8 alcanzado en este entorno** (oráculo gráfico
lavapipe más SwiftShader; ver los límites en §7).

| Métrica (P4_2_DISENO.md §1) | Meta de P4.2 | Resultado |
|---|---|---|
| M3 — etapas | 6/6 | **6/6**: VS, TCS, TES, GS, FS (nuevas) y CS, cada una ejecutada en el corpus |
| M2 — corpus gráfico diferencial | 100 % | **25/25** tuberías en lavapipe (14 VS+FS, 6 VS+GS+FS, 5 VS+TCS+TES+FS), con el camino A, el B y **cada mezcla de una sola etapa**; en SwiftShader, **12/12** de las que puede ejecutar (13 omitidas y declaradas: no tiene GS, teselación ni `shaderDrawParameters`) |
| M2 — corpus *compute* (P4.1) | se mantiene | **50/50** en SwiftShader y también **50/50 en lavapipe** |
| M4 — SPIR-V válido | 100 % | **812/812** módulos aceptados por `spirv-val --target-env vulkan1.1`: los 733 de P4.1, las 66 etapas del corpus gráfico y los 13 casos T2-G |
| M1 — decodificación | 100 % | **296/296** (sin cambios) |
| M1 — traducción | (100 % es la meta de P4.4) | 184/296 codificaciones (62,2 %; P4.1: 175); de la lista de P4.2, **11/11** |
| T2-G — instrucciones nuevas | todas | **13/13** casos en lavapipe (`ld`/`st a[]` de todos los tamaños y con índice dinámico, `AL2P`, `ISBERD`, `OUT` en sus 3 codificaciones, `IPA` en todos los modos e indexada, `KIL`, `SHFL` en un *quad* con su predicado, `FSWZADD` con máscaras simétricas y asimétricas, id de vértice e instancia) |

Meta H8: "M3 6/6, el corpus gráfico al 100 % en el oráculo, M4 al 100 % y T2 de las
instrucciones nuevas". **Cumplida.**

**Contexto:**
- **Base:** `LoboGelido_beta_0.1_GLASS_PLAY_BUILD_FIX.zip` + la cadena hasta P4.1.
- **Especificación:** `P4_2_DISENO.md`. D-P4.2-1 a 7 se tomaron como se recomendaban. Durante la
  ejecución se añadieron D-P4.2-8 (operaciones de *quad*) y D-P4.2-9 (barreras del TCS), §3.
- **Método:** protocolo de 12 pasos y Regla de Oro. No se ha eliminado ninguna clase, función ni
  *binding*. Las líneas quitadas de archivos existentes son sustituciones correctivas:
  - la guarda "solo compute en P4.1";
  - el error "atributos fuera de P4.1";
  - la declaración del punto de entrada de *compute*, que pasa a `declare_entry_and_modes()`.
  El SPIR-V de *compute* es **idéntico byte a byte** al de P4.1: los 571 módulos de T2 y T3 dan
  el mismo *hash* con los dos traductores.
- **Política *clean-room* (D-P4-2):** todo es código propio. Referencias usadas, todas permisivas:
  - el formato de la SPH (NVIDIA open-gpu-doc, MIT);
  - el espacio de atributos (`nv_attributes.h` de uam, MIT);
  - la semántica de `FSWZADD` (Mesa nv50_ir, MIT: `QUADOP(UL, UR, LL, LR)` y su uso en las
    derivadas y en TXD);
  - la definición de `shfl` de PTX;
  - la especificación de SPIR-V y Vulkan.
  Nada de yuzu, Eden ni Ryujinx.
- **No se ha tocado:** `gpu/`, CPU, kernel, IPC, cargadores, Android/Kotlin, `crypto/`. La
  integración con el motor 3D es de P5.

## 1. Qué se entrega
| Pieza | Contenido |
|---|---|
| `shader/translate.h` | `Stage` (6 etapas), `AttribType`, `Sph` + `parse_sph()`, `GraphicsState` (lo que la SPH no lleva: tipos de atributos, *varyings* y RT, base de instancia, vértices del *patch*, dominio/espaciado/orden/modo punto del TES, primitiva de entrada del GS); `ShaderInfo` gana `sph` y `graphics` con valores por defecto (el código de P4.1 no cambia) |
| `shader/translate_graphics.inc` (nuevo) | las etapas gráficas: variables de interfaz, `a[]`, `IPA`, `OUT`, salidas del FS, `SHFL`/`FSWZADD`, barreras del TCS, modos de ejecución |
| `shader/translate.cpp` | integración: SPH, despacho de las instrucciones nuevas, `KIL` como `OpKill`, `EXIT` del FS escribe las salidas, `BAR` del TCS |
| `shader/spirv/builder.h` | códigos de operación y decoraciones nuevos |
| `tests/test_shader_t3g.cpp`, `tests/shader/t3g_runner.h`, `t3g_fixtures.h` | T3-G (§4.2) |
| `tests/test_shader_t2g.cpp`, `tests/shader/t2g_fixtures.h` | T2-G (§4.3) |
| `tests/shader/vk_graphics.{h,cpp}` | ejecución de tuberías gráficas en Vulkan cargado con `dlopen` (64×64, RGBA32 F/SINT/UINT, D32, búferes); solo tests |
| `tests/shader/dksh.h` | lector de programas gráficos del `.dksh` (SPH + código) |
| `tests/test_shader_static.cpp` | M4/D1 sobre las etapas gráficas, M1 de P4.2, E1 de SPH/etapa/atributos y la comprobación estructural de las barreras del TCS |
| `tests/data/shader/gcorpus/` | las 25 tuberías del corpus gráfico (GLSL) |
| `tools/gpu_toolchain/build_lavapipe.sh` (nuevo), `build_toolchain.sh` | construcción del oráculo gráfico (§4.1); `build_toolchain.sh` lo llama al final |
| `tools/gpu_toolchain/gen_shader_gcorpus.py`, `gen_shader_t2g.py` | generadores de los *fixtures* |
| `CMakeLists.txt` | `LOBOGELIDO_SHADER_ORACLE_GFX_ICD`; tests `shader_t2g`, `shader_t3g` y, con lavapipe, `shader_{t2,t3,t2g,t3g}_lvp` (los gráficos con `--require-all`) |
| `tests/shader/tsan_oracle.supp` | + la biblioteca de lavapipe (§5.2) |
| `tests/data/shader/corpus/c01, c07, c15, c22` | solo la tolerancia: lavapipe redondea distinto que SwiftShader (§4.2) |

## 2. Cómo traduce
### 2.1 Interfaz
- **Entrada:** el código y `ShaderInfo`, que ahora lleva:
  - `stage` (VS, TCS, TES, GS, FS o CS);
  - las 20 palabras de la **SPH**;
  - `GraphicsState`.
- **Comprobaciones:** la SPH se valida y su tipo de etapa debe coincidir con la pedida (error
  explícito si no). Si falta un dato de estado necesario, también hay error.
- **Salida:** la misma que en P4.1: SPIR-V 1.3, recursos y avisos.

### 2.2 Interfaz de etapas (D-P4.2-3)
- **Genéricos:** una variable por ubicación de 16 bytes (`Location n`), del tipo que da
  `GraphicsState`, con tantas componentes como use el programa (SPH + código).
  - Con índice dinámico, la ubicación se declara entera.
  - Por vértice (*arrays*) en las entradas de TCS/TES/GS y en las salidas del TCS.
  - `Patch` en los genéricos de *patch*.
- ***Built-ins* por dirección** (tabla de `P4_2_DISENO.md` §2.2), declarados sueltos (sin bloque
  `gl_PerVertex`). Las tuberías mixtas con glslang (que sí usa bloques) funcionan en los dos
  oráculos, lo que responde a la pregunta abierta del diseño.
- **`ClipDistance`** se declara con tantas distancias como use el programa. Un *array* de 8 con
  6 sin escribir recorta con valores indefinidos; SwiftShader lo mostró (§4.4).
- **Interpolación (D-P4.2-4):** desde el `imap` de la SPH: `Flat`, `NoPerspective` o la normal;
  `Centroid` si alguna `IPA` lo pide.
  - `IPA.MUL` da el valor ya corregido.
  - `IPA.PASS` de un genérico con perspectiva da valor·`FragCoord.w`.
  - `IPA.PASS a[0x70..0x7c]` es `FragCoord`, con w = 1/w de recorte.
- **Salidas del FS:** al ejecutar `EXIT`, los registros se escriben en las salidas: 4 por RT
  activo en `omap_target`, en orden de RT, y después la máscara de muestras y la profundidad
  (modelo de `nvc0_fp_assign_output_slots`). `DepthReplacing` si hay profundidad.
- **Id de instancia (D-P4.2-6):** `InstanceIndex − BaseInstance` (semántica GL/NVN), con la
  opción `instance_id_includes_base`.
- **`invocation_info`:** se sintetiza con los vértices por primitiva en los bits 0–7 y la
  primitiva 0. La aritmética `prim·verts + vértice` que emite el compilador da entonces el vértice
  lógico, que `ISBERD` (identidad) pasa a `ld a[]`.
- **GS (D-P4.2-5):** `OUT` → `OpEmitVertex`/`OpEndPrimitive` en sus 3 codificaciones. El
  *stream* 0 es exacto. Con un *stream* que no se conoce en tiempo de traducción (forma de
  *constbuffer*) se avisa y se usa el 0. El *handle* devuelto es sintético.
- **Modos de ejecución:**
  - del GS (entrada, invocaciones, topología y máximo de vértices de salida) y del TCS (vértices
    de salida), desde la SPH;
  - del TES, desde `GraphicsState`;
  - del FS, `OriginUpperLeft`.

### 2.3 Instrucciones nuevas
- `ld`/`st a[]` (ALD/AST) de b32 a b128, con vértice (`REG_39`), bits `o` (salidas) y `p`
  (*patch*), e índice dinámico `a[R + imm]` (cadena de selección al leer, de `if` al escribir).
- `AL2P` e `ISBERD`.
- `IPA`: modos `pass`/`multiply`/`constant`, `centroid`, `sat` e indexada. `IPA.SC` y la de
  desplazamiento dan error explícito (P4.4).
- `OUT`.
- `S2R` de `invocation_id`, `invocation_info`, `laneid` (en el TCS, la invocación) e `y_direction`.
- `KIL` en el FS → `OpKill`.
- `BAR` en el TCS.
- `SHFL` y `FSWZADD` en el FS (D-P4.2-8, §3).

## 3. Decisiones añadidas durante la ejecución
### 3.1 D-P4.2-8: operaciones de *quad* (derivadas)
- uam (y el compilador de NVIDIA) compilan `dFdx`/`dFdy`/`fwidth` como `SHFL.BFLY` dentro de un
  *quad* + `FSWZADD`.
- **`SHFL`** con segmento de 4 (`c = 0x1c03`), cualquier modo (`idx/up/down/bfly`):
  - 4 `OpGroupNonUniformQuadBroadcast` y selección por el índice de *quad*
    (`SubgroupLocalInvocationId & 3`), con el predicado de salida de PTX.
  - Con otro segmento, error (P4.4).
- **`FSWZADD`:** operación por carril según la máscara.
  - Carril 0 (arriba a la izquierda) en los bits 6–7, carril 3 en los bits 0–1.
  - Operaciones: 0 a+b, 1 b−a, 2 a−b, 3 b. Fuente: Mesa nv50_ir.
  - Primero se implementó con la lectura simétrica (carril 0 en los bits 0–1, 1 = a−b). Da lo
    mismo con las máscaras de las derivadas (0x99/0xa5), así que T3 no podía distinguirlas. Se
    corrigió contrastando con el uso de máscaras asimétricas en TXD de Mesa (validado en
    *hardware*), y T2-G comprueba ahora máscaras asimétricas.
- Fuera del FS (`quadOperationsInAllStages`), error explícito (P4.4).

### 3.2 D-P4.2-9: barreras del TCS
- **El problema:**
  - En el *hardware* las invocaciones de un *patch* van en *lock-step*. uam elimina el
    `barrier()` de GLSL y lee las salidas de otras invocaciones (`ld a[] .o`) sin `BAR`.
  - En Vulkan no van en *lock-step*: sin `OpControlBarrier` la lectura compite con la escritura.
  - lavapipe no lo muestra porque ejecuta el *patch* en carriles SIMD. Se descubrió analizando un
    mutante superviviente (§5.1).
- **La solución:** el traductor calcula el **prefijo uniforme**, el bloque de entrada hasta la
  primera instrucción de flujo. Si algo salta a la entrada, el prefijo queda vacío.
  - Una lectura de salidas dentro del prefijo lleva una barrera justo antes, si se escribieron
    salidas desde la anterior.
  - Una lectura fuera del prefijo, por ejemplo el patrón habitual
    `if (gl_InvocationID == 0) { …gl_out[i]… }`, lleva una barrera al final del prefijo si este
    escribe salidas.
  - Si hay salidas escritas fuera del prefijo antes de esa lectura, no se pueden ordenar: se
    avisa.
- **Comprobación:** `shader_static` verifica que todo TCS del corpus que lee salidas lleva la
  barrera (2 de 5). El corpus incluye los dos patrones (`t02_quad`, `t05_outread`).

## 4. Verificación
### 4.1 El oráculo gráfico (D-P4.2-1, riesgo R2)
- **lavapipe:** Mesa 24.3.4 (llvmpipe) con el LLVM 18 del sistema; tiene todas las etapas.
- **Por qué no basta SwiftShader:** no tiene GS, teselación ni `shaderDrawParameters`. Sigue como
  segundo oráculo de VS+FS y de *compute*.
- **`tools/gpu_toolchain/build_lavapipe.sh`:**
  - clona Mesa desde un espejo de GitHub;
  - usa las cabeceras de `llvmorg-18.1.3` (solo `llvm/include`, clon disperso) y genera aquí lo
    que falta: `llvm/Config/*` y los `.inc` de `llvm-tblgen`;
  - usa un `llvm-config` mínimo para meson;
  - hace dos cambios locales al `meson.build` de Mesa, solo para el oráculo (sin libdrm).
- **Comprobado de principio a fin** en un prefijo vacío: el lavapipe que construye el *script*
  pasa T3-G 25/25, T2-G 13/13 y T3 50/50. La primera ejecución encontró que faltaba `flex` en
  el prefijo de prueba; ahora el *script* lo comprueba y muestra el registro de meson si falla.

### 4.2 T3-G — corpus gráfico diferencial
25 tuberías GLSL propias. El mismo texto sirve para uam y glslang, con `#ifdef VULKAN` para
`gl_VertexIndex`/`gl_InstanceIndex`. La preparación va en comentarios del VS: dibujo, atributos,
RT, profundidad, búferes, teselación, primitiva de entrada del GS, tolerancia, `needs:`.
- **VS+FS (14):**
  - *varyings* con y sin perspectiva (w ≠ 1), planos enteros y flotantes;
  - `FragCoord` (xyzw), `FrontFacing`, `discard`, `gl_FragDepth`, `gl_SampleMask`;
  - 4 RT de tipos mezclados; UBO en VS y FS; SSBO y atómicas desde VS y FS;
  - instancias con base, puntos con `gl_PointSize`/`gl_PointCoord`, líneas, `gl_ClipDistance`;
  - índice dinámico de *varyings* en VS y FS, `gl_PrimitiveID`;
  - derivadas (`dFdx`, `dFdy`, `fwidth`);
  - bucles y saltos en VS y FS.
- **VS+GS+FS (6):** triángulos, puntos → *sprites*, líneas → *line strip*, invocaciones (SSBO
  desde el GS), bucles de emisión con `EndPrimitive`, triángulos con adyacencia.
- **VS+TCS+TES+FS (5):**
  - dominios triángulo, cuadrado (`fractional_odd`, `cw`) e isolíneas;
  - modo punto (`fractional_even`);
  - genéricos de *patch*;
  - lectura de salidas de otras invocaciones, con y sin flujo divergente.
- **Caminos:**
  - A: todas las etapas traducidas.
  - B: todas de glslang.
  - Mezclas: una sola etapa traducida y las demás de glslang, para localizar el fallo por etapa.
- **Comparación:** RT, profundidad y SSBO; enteros bit a bit, flotantes con la tolerancia del
  caso. El *harness* comprobó además que cada caso cubre píxeles de verdad.
- **Cobertura:** 2 101 instrucciones Maxwell, 46 mnemónicos, 63 codificaciones.
- **Problemas de uam** (no del traductor; documentados en los casos):
  - `STATE_FB_WPOS_Y_TRANSFORM` (el signo de `dFdy`) queda a 0 en el *constbuffer* 1, porque lo
    rellena el *driver* GL. El caso lo fija con la directiva `cb1:`.
  - `gl_PrimitiveID` en el FS es indefinido si el GS no lo escribe; los casos lo escriben.
- **Tolerancias:** las de cuatro *shaders* del corpus *compute* se ampliaron porque lavapipe
  redondea distinto que SwiftShader (el SPIR-V es el mismo).

### 4.3 T2-G — instrucciones nuevas
- **Cada caso:** una sola etapa Maxwell ensamblada con `envyas`, con la SPH construida por el
  generador. Las formas que `envyas` no escribe (`IPA` indexada, `OUT` con *stream* inmediato o
  de *constbuffer*) se emiten como palabras crudas derivadas de la codificación real de uam.
- **Esperado:** el RT0 (RGBA32UI) lo calcula el generador **desde la semántica documentada**, sin
  usar el traductor. Los demás píxeles deben quedar a 0.
- **Casos:**
  - VS (puntos, uno por píxel): tamaños b32–b128 de `ld/st a[]`, índice dinámico con `AL2P`, id
    de vértice e instancia en las dos semánticas.
  - GS: `ISBERD`, `ld a[]` por vértice, `OUT emit` / `emit_then_cut` / `cut` en las 3
    codificaciones.
  - FS (cuadrado de 16×16 con w = 2 y z ≠ 1/w, para distinguir `FragCoord.w`):
    - `IPA` en todos los modos, también `sat`, `centroid` e indexada;
    - `IPA.PASS` sobre perspectiva;
    - `KIL`;
    - `SHFL` en sus 4 modos con predicado;
    - `FSWZADD` con máscaras simétricas y asimétricas.
- **Resultado:** 13/13 en lavapipe. En SwiftShader, 11/13, con 2 omitidos (GS y
  `shaderDrawParameters`).

### 4.4 Errores encontrados y corregidos durante P4.2
| Error | Cómo se encontró |
|---|---|
| `ClipDistance[8]` con distancias sin escribir | SwiftShader (segundo oráculo) recortaba píxeles |
| Convención de carriles/operaciones de `FSWZADD` invertida | revisión contra Mesa antes de escribir T2-G (T3 no la distingue) |
| Barreras del TCS ausentes | mutante superviviente → análisis del código de uam |
| `IPA` indexada (`IPA.IDX`) sin traducir | corpus (`g10_dynidx`) |
| Tipo de `InvocationId` (int) cargado como uint | `spirv-val` |
| Tipos de la cadena de selección de `FSWZADD` | `spirv-val` |
| `FSWZADD` en *compute* sin el *built-in* en la interfaz | `spirv-val` sobre M1 (ahora: error explícito fuera del FS) |

### 4.5 M4, D1, E1, M1
- **M4:** 812/812 módulos pasan `spirv-val --target-env vulkan1.1`.
- **D1:** las 66 etapas gráficas traducidas por 4 hilos dan el mismo resultado (también bajo
  TSan).
- **E1:** error explícito para:
  - SPH no válida;
  - SPH de otra etapa;
  - atributos en *compute*;
  - `IPA` fuera del FS y `OUT` fuera del GS;
  - *built-in* que no existe en la etapa;
  - `SHFL`/`FSWZADD` fuera del FS o con otro segmento.
- **M1:** 184/296 codificaciones traducidas en algún programa; lista de P4.2, 11/11.

## 5. Matriz
| *Build* | Resultado |
|---|---|
| *Host*, sin JIT, con los dos oráculos | **91/91** (85 de P4.1 + `shader_t2g`, `shader_t3g` y los 4 `_lvp`) |
| JIT (Release, Dynarmic) | **94/94** |
| ASan + UBSan (*host* / JIT) | **91/91** / **94/94** |
| TSan (*host* / JIT) | **91/91** / **94/94** |
| Dynarmic descargado (`LOBOGELIDO_FETCH_DYNARMIC`) | **94/94** |
| Compilación modo Android (`-Wall -Wextra -Wpedantic`) | 100 archivos OK, `translate.cpp` sin avisos; los 2 de siempre fallan por falta de cabeceras del NDK aquí |
| ARM64 (`clang --target=aarch64`, solo compilación) | el traductor y el intérprete compilan sin avisos |
| Mutación | **31/32** (§5.1) |

### 5.1 Mutación
32 mutantes del código gráfico. Cada uno se compiló y se contrastó con `shader_static` + T2-G y
T3-G en lavapipe (`--require-all`) y en SwiftShader:

| Resultado | Mutantes |
|---|---|
| **Matados (31)** | `ld .o` del TCS que lee entradas*; `IPA.PASS` sin ·w; sin `NoPerspective`; flotante constante sin `Flat`*; registro de profundidad; *stride* de RT; id de instancia con base; `OUT.CUT` ignorado; ranura de primitiva de `invocation_info`*; barrera antes de la lectura del TCS*; barrera al final del prefijo*; salida del TCS al vértice 0; dirección de componente en lectura dinámica; componente de `FragCoord`; `ClipDistance[8]`; carril de `SHFL.BFLY`; predicado de `SHFL.DOWN`*; orden de carriles de `FSWZADD`; `SUB`/`SUBR` intercambiados; genérico de *patch* leído como 0; componente de `TessCoord`; `fractional_even` como `odd`; *line strip* como *triangle strip*; `FrontFacing` invertido; `IPA.SAT` ignorado; tamaño de `ALD/AST`; desplazamiento del `imap` de la SPH; registro de la máscara de muestras; `SAT` de `IPA.IDX`*; dirección de escritura dinámica; `IPA.PASS` por `FragCoord.z`* |
| **Equivalente por diseño (1)** | *handle* de `OUT` sin avanzar: el *handle* es sintético y las escrituras de atributos lo ignoran (un vértice de salida a la vez) |

\* Sobrevivieron a la primera pasada (24/30) y llevaron a añadir o reforzar pruebas:
- `t02_quad` con las salidas de todas las invocaciones;
- el caso de flotante plano en `g02`;
- `fs_quad_predicates`, `fs_ipa_indexed`, `fs_ipa_pass_perspective`;
- z ≠ 1/w en T2-G;
- la comprobación estructural de barreras.

Además se descubrió D-P4.2-9 (§3.2). El mutante de `invocation_info` original (número de vértices
en otro campo) era equivalente en nuestro modelo (primitiva 0) y se cambió por el de la ranura de
primitiva.

### 5.2 Sanitizadores y descarga
- **ASan:**
  - Con lavapipe, LeakSanitizer informaba de 112 bytes en 2 bloques. No estaban en ningún objeto
    del *harness*: se comprobó que destruye todo lo que crea, y que con las bibliotecas cargadas
    no hay ninguna fuga.
  - Eran memoria referenciada solo desde los datos estáticos de lavapipe/LLVM. El cargador de
    Vulkan descarga el ICD en `vkDestroyInstance` y LSan ya no puede recorrerlos.
  - Corrección, solo en el *harness*: `vk_graphics.cpp` fija con `RTLD_NODELETE` las bibliotecas
    cargadas una vez creado el dispositivo.
- **TSan:** informa de carreras **dentro** de `libvulkan_lvp.so` (`lp_fence_destroy` frente al
  `cnd_broadcast` de su propia valla), sin instrumentar como SwiftShader. Se suprimen solo sus
  *frames*. Una supresión de `libLLVM` que se había añadido por precaución se quitó al comprobar
  que no hacía falta. El traductor, con 4 hilos (D1), está limpio.

## 6. Qué queda fuera de P4.2 (error explícito)
| Forma | Fase |
|---|---|
| Texturas e imágenes (`TEX`, `TLD`, `TLD4`, `TXQ`, `SULD/SUST`…) | P4.3 |
| `IPA.SC`, `IPA` con desplazamiento, `interpolateAtSample/Offset` | P4.4 |
| *Streams* del GS distintos de 0 | P4.4 |
| `SHFL` fuera de un *quad* o del FS, `FSWZADD` fuera del FS, `VOTE` | P4.4 |
| Capa y *viewport* (`a[0x64]`/`a[0x68]`): se declaran, pero el corpus no los ejecuta (necesitan destinos con capas) | P4.4 / P5 |
| Lo que ya quedaba fuera en P4.1 (64 bits, dobles, FP16…) | P4.4 |

## 7. Límites (honestos)
- **Los oráculos son lavapipe y SwiftShader** (Vulkan en la CPU), no Adreno ni un Maxwell real.
  - Rasterización, interpolación y precisión difieren entre ellos. Por eso se compara A con B en
    el mismo oráculo, con tolerancias por caso.
  - lavapipe ejecuta los *patches* en carriles SIMD: no puede mostrar la falta de una barrera en
    el TCS. Eso se comprueba de forma estructural.
- **`shaderDrawParameters`** es opcional en Vulkan. Sin él, el id de instancia con semántica GL
  no se puede traducir así; SwiftShader no lo tiene. **Para P5:** pasar la base de instancia por
  *push constant* si el dispositivo no lo ofrece.
- **Operaciones de *quad*:** dependen de que las invocaciones auxiliares (*helper*) participen,
  como exige Vulkan para las derivadas. Tras un `discard` en flujo divergente, las derivadas son
  indefinidas también en GLSL.
- **Barreras del TCS:** las escrituras de salidas en flujo divergente que otra invocación lee
  después no se pueden ordenar (aviso). El caso común (escribir en el prefijo, leer en
  `if (id == 0)`) está cubierto.
- **Estado de la tubería:** `GraphicsState` lo da quien llama. En P5 saldrá de los registros del
  motor 3D (tipos de atributos, de RT, teselación, primitiva del GS).
- **La semántica sale de documentación pública y de lo que emite uam** (nouveau), no del
  compilador de NVIDIA. Los juegos usan el de NVIDIA, que puede emitir formas que uam no
  (`IPA.SC`, *streams*, etc.): están con error explícito, no se traducen en silencio.
- **Lo que solo se puede comprobar en el teléfono:** compilación real con el NDK y ejecución en
  Adreno.

## 8. Siguiente fase
P4.3 (texturas e imágenes: `TEX`/`TLD`/`TLD4`/`TXQ`/`SULD`/`SUST`, descriptores TIC/TSC) con su
diseño, o la integración mínima del traductor en el motor 3D (P5) para ver los primeros
*shaders* de juego.
