@echo off
setlocal
set ROOT_DIR=%~dp0
if "%JAVA_HOME%"=="" (
  echo ERROR: Configura JAVA_HOME apuntando a JDK 17.
  exit /b 2
)
"%JAVA_HOME%\bin\java.exe" -version 2>&1 | findstr /C:"version \"17" >nul
if errorlevel 1 (
  echo ERROR: Lobo Gelido requiere JDK 17 para AGP 8.13.2.
  exit /b 2
)
if "%LOBO_GRADLE_HOME%"=="" set LOBO_GRADLE_HOME=%USERPROFILE%\.gradle\lobo-gelido\gradle-8.13
if not exist "%LOBO_GRADLE_HOME%\bin\gradle.bat" (
  echo Gradle 8.13 no esta instalado en %LOBO_GRADLE_HOME%.
  echo Descarga Gradle 8.13 y extraelo ahi, o ejecuta la construccion desde Android Studio.
  exit /b 3
)
cd /d "%ROOT_DIR%"
if "%~1"=="" (
  call "%LOBO_GRADLE_HOME%\bin\gradle.bat" --no-daemon --stacktrace assembleDebug
) else (
  call "%LOBO_GRADLE_HOME%\bin\gradle.bat" --no-daemon --stacktrace %*
)
exit /b %ERRORLEVEL%
