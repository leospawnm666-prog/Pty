# Shader stack max — 2026-10-18

## Estado medido en el ZIP revisado

Se reemplazan las bandas estimadas de la versión anterior: una traducción que termina por
reemplazar instrucciones por NOP no equivale a soporte semántico.

| Capa | Medición | Alcance |
|------|----------|---------|
| Decoder Maxwell | **296/296 (100 %)** | 2368 palabras comparadas con los golden de envydis |
| Traductor semántico | **288/296 (97,3 %)** | Corpus estático acumulado, con ambos fallbacks soft desactivados para puntuar |
| Formas semánticas pendientes | **8** | `ldg` (predicado), `stp.wait`, `ide`, `txa`, `vote.vtg`, `vabsdiff4`, `vset`, `vmnmx` |
| M4 SPIR-V | **tests estructurales pasan** | `spirv-val` no está instalado; esto no acredita validación externa ni ejecución Vulkan |
| Integración del traductor al runtime | **0 call sites encontrados** | En este snapshot `shader::translate()` no lo invoca el pipeline de producción; el 97,3 % es cobertura del traductor probado, no del renderizador end-to-end |

El modo productivo soft sigue siendo el default deliberado. `soft_skipped` y
`undecoded_soft` exponen las instrucciones reemplazadas; el harness ya no las cuenta
como cobertura semántica. Cambiar ese default a strict requiere decidir explícitamente
entre fidelidad y tolerancia/playability.

`coverage_report()` informa ahora la **superficie de despacho por mnemónico** y la
etiqueta como tal; no se debe usar como porcentaje de semántica implementada.
