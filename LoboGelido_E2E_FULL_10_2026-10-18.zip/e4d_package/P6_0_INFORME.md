# P6.0 — Informe: el núcleo de Horizon completo (SVC) y el marco de HLE (hito H11)

Estado: **P6.0 implementado y verificado. Hito H11 alcanzado** (diseño: `P6_0_DISENO.md`).

| Métrica | P4.4 | Meta P6.0 | Resultado |
|---|---|---|---|
| **M-SVC** (números de SVC asignados) | 39/124 (31,5 %) | 123 + 1 frontera | **124/124 con manejador: 123 implementadas (99,2 %) + 1 frontera (`CallSecureMonitor`)**. Los 68 números sin asignar siguen siendo un error |
| M-SRV (familias de libnx) | 3/89 | sin cambio | 3 empezadas, 0 completas (medido por herramienta) |
| M-CMD (comandos de libnx) | ≈13/1908 | sin cambio | **11/1908** (0,6 %), medido; el "≈13" anterior era una cuenta a mano |
| Pruebas | — | cada SVC con prueba | programa libnx (40 comprobaciones, 3 motores JIT) + programa en ensamblador (31 resultados, **5 motores**) + pruebas *host* |
| Mutación | — | — | **32/32** mutantes matados (§4) |

**Contexto:**
- **Base:** `LoboGelido_beta_0.1_GLASS_PLAY_BUILD_FIX.zip` + la cadena hasta P4.4, + P4.5 (entregado junto).
- **Método:** protocolo de 12 pasos, Regla de Oro (no se elimina ninguna clase, función ni *binding*
  nativo; cambios aditivos o correctivos), especificación + matriz de riesgos + impacto en
  `P6_0_DISENO.md`.
- **Fuentes:** mesosphere de Atmosphère solo como documentación del comportamiento del kernel;
  libnx (ISC) para números, firmas y ABI; Switchbrew. **Nada de código de yuzu, Eden ni Ryujinx.**
- **Frontera DRM:** `CallSecureMonitor` responde siempre como un kernel sin monitor seguro
  (`x0 = 1`). No se emula ninguna función del monitor. No se tocan `crypto/`, cargadores de
  NCA/NSP/XCI ni claves.

## 1. Qué se entrega
| Archivo | Qué |
|---|---|
| `system/svc_p6_system.cpp` (nuevo) | hilos (0x32, 0x33), excepciones (0x28, 0x36), perfilado y depuración retail (0x2E, 0x2F, 0x60-0x6D), proceso (0x4F, 0x79-0x7C), memoria de proceso (0x5D-0x5F, 0x73-0x78), memoria física e *insecure* (0x54, 0x55, 0x90, 0x91), *hardware* ausente (0x39, 0x3A, 0x46, 0x47, 0x4E, 0x53, 0x56-0x5C), sistema (0x3C, 0x3D, 0x4D, 0x6F), frontera (0x7F), `GetInfo` 9/10/20/23/24/26-28/34/36-38 |
| `system/svc_p6_ipc.cpp`, `system/kipc_guest.cpp` (nuevos) | servidores IPC escritos por el guest: sesiones, puertos, puertos con nombre, `ReplyAndReceive*`, *buffers* de usuario, IPC asíncrona y ligera; transferencia de mensajes completa |
| `system/svc_p6.cpp` (de la primera tanda de P6.0) | memoria compartida, de transferencia y de código; memoria física; límites de recursos |
| `system/kobjects.{h,cpp}` (de la primera tanda) | `KSharedMemory`, `KTransferMemory`, `KCodeMemory`, `KResourceLimit` |
| `system/kthread.*`, `kipc.*`, `vm_manager.*`, `svc_dispatcher.*`, `svc_table.cpp`, `memory_state.h`, `hle/*`, `runtime/runtime_coordinator.cpp` | ver `P6_0_DISENO.md` §8 |
| `tools/homebrew/p6_kernel/`, `tests/data/nro/p6/` | programa de prueba con libnx y su generador |
| `tests/data/nro/p6_svcs.S`, `unassigned.S` | *fixtures* en ensamblador |
| `tests/test_p6_kernel.cpp`, `test_hle_catalog.cpp` (nuevos); `test_svc_dispatch`, `test_svc_process`, `test_kipc`, `test_vm_manager`, `test_mem_process` | pruebas |
| `tools/hle/hle_coverage.py` (nuevo) | M-SRV / M-CMD desde el código |

## 2. Correcciones encontradas por el camino
- `GetThreadContext3` escribía 0x330 bytes; `svc::ThreadContext` mide **0x320**: pisaba 16 bytes
  de la pila del guest (lo detectó el programa de libnx: el *handle* del hilo quedaba corrompido).
- `VmManager::reset()` no limpiaba los gránulos de `MapPhysicalMemory`.
- `GetInfo(16)` devolvía 0 aunque el proceso tuviera recurso de sistema.
- La reducción del *heap* liberaba gránulos que otra asignación (`MapProcessMemory`, IPC) seguía
  usando: ahora se mantienen mientras haya referencias (Horizon cuenta referencias por página).

## 3. Verificación
| Matriz | Resultado |
|---|---|
| *Host* (intérpretes) | **100/100** |
| JIT (dynarmic) | **103/103** |
| ASan + UBSan (*host* / JIT) | **100/100**, **103/103** |
| TSan (*host* / JIT, `report_signal_unsafe=0`) | **100/100**, **103/103** |
| dynarmic descargado (`fetch`) | **103/103** |
| Android (compilación de las fuentes del CMake de Android) / ARM64 | **105 OK** (100 de P4.4 + los 5 archivos nuevos) + los 2 FAIL de siempre (`aaudio_sink`, `android_display_adapter`: necesitan cabeceras del NDK que aquí no hay); los archivos nuevos compilan sin avisos con `-Wall -Wextra -Wpedantic`. ARM64: `clang --target=aarch64-linux-gnu -fsyntax-only -Wall -Wextra` sobre los 11 archivos tocados del kernel y `shader/translate.cpp`, sin errores ni avisos (con las cabeceras de libstdc++ del *host*: no hay *sysroot* ARM64 aquí, así que no se enlaza ni se ejecuta en ARM64) |

Pruebas que cubren cada grupo: ver `P6_0_DISENO.md` §6. El programa de libnx pasa sus 40
comprobaciones en JIT, JIT + *fastmem* y JIT + *fastmem* con páginas de 16 KiB; en los dos
intérpretes se detiene en la primera instrucción AdvSIMD/FP, como H5. El programa en ensamblador
pasa en los 5 motores.

## 4. Mutación
`/tmp/claude-0/mut_p60.py` (árbol aparte, compilación JIT): cada mutante cambia una regla y se
ejecutan `test_svc_dispatch`, `test_svc_process`, `test_kipc`, `test_vm_manager`,
`test_mem_process` y `test_p6_kernel`.

| Mutante | Resultado |
|---|---|
| SetProcessActivity: own process not Busy | MATADO |
| GetProcessInfo: state | MATADO |
| SMC frontier answers success | MATADO |
| debug SVCs succeed on retail | MATADO |
| GetLastThreadInfo result | MATADO |
| GetThreadContext3: no pointer check | MATADO tras reforzar la prueba (el programa libnx pasa un puntero no mapeado y espera InvalidPointer) |
| GetInfo P6 ids: no handle check | MATADO |
| IsApplication always 1 | MATADO |
| CreateIoPool succeeds | MATADO |
| MapProcessMemory accepts pseudo-handles | MATADO |
| CreateProcess succeeds | MATADO |
| IPC lock keeps the client permission | MATADO |
| IPC unlock restores R | MATADO |
| IPC server head page not copied | MATADO |
| IPC server mapping read-only | MATADO |
| heap shrink frees shared granules | MATADO |
| request pid not written | MATADO |
| copy handle without reference | MATADO |
| move handle not removed from the server | MATADO |
| X receive: index ignored | MATADO |
| ToMessageBuffer alignment | MATADO |
| B head page not copied back | MATADO |
| reply to closed client succeeds | MATADO |
| closed client does not signal | MATADO tras reforzar la prueba (el servidor espera en la sesión y debe despertar al cerrarse el cliente) |
| request to a closed server queued | MATADO |
| light: last word lost (delivered) | MATADO |
| port: no session limit | MATADO |
| named port shadows an HLE name | MATADO |
| HLE copy handle without reference | MATADO |
| wait end not reported | MATADO |
| idle ticks count busy time | MATADO |
| user buffer never unlocked (HLE) | MATADO |

**32/32 matados** (30 en la primera pasada; los 2 supervivientes revelaron huecos de las pruebas, que se cubrieron y se volvieron a comprobar).

## 5. Límites (honestidad)
- **Modelos** donde Horizon depende del *hardware* o de su organización interna: direcciones
  físicas (D-P6.0-7), *pools* de `GetSystemInfo` (D-P6.0-5), `SleepSystem` (D-P6.0-4), la
  entrega de peticiones en la llegada (D-P6.0-10), el resultado asíncrono en la palabra 2.
- **Consola retail de un proceso:** las SVC de depuración, procesos nuevos, E/S, interrupciones y
  SMMU responden lo que Horizon responde en esa consola; no "hacen" nada más. Es el
  comportamiento correcto para un juego o un *homebrew*, no una emulación de módulos del sistema.
- P6.0 no implementa servicios: M-SRV/M-CMD siguen bajos. Son P6.1-P6.4.
- El proceso emulado tiene el id 1 (en una consola, ≥ 0x51): desviación anterior a P6.0.
